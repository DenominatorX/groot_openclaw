#!/usr/bin/env node
/**
 * Mission Control Server Manager
 * Reads port from data/settings.json, starts Next.js on that port.
 * The /api/server/restart endpoint writes new port and signals this process.
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const SETTINGS_PATH = path.join(__dirname, 'data', 'settings.json');
const LOCK_FILE = path.join(__dirname, '.mc-server.pid');

function readPort() {
  try {
    const s = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    return s.port || 4000;
  } catch { return 4000; }
}

let child = null;
let restarting = false;

function startNext(port) {
  console.log(`[MC] Starting Next.js on port ${port}...`);
  child = spawn('npx', ['next', 'start', '-p', String(port)], {
    cwd: __dirname,
    stdio: 'inherit',
    env: { ...process.env, PORT: String(port), DEBUG: '*', NEXTAUTH_DEBUG: 'true', NODE_ENV: 'production' }
  });
  child.on('exit', (code) => {
    if (restarting) {
      restarting = false;
      startNext(readPort());
    } else {
      console.log(`[MC] Next.js exited with code ${code}`);
      process.exit(code || 0);
    }
  });
}

// Write PID so API can signal us
fs.writeFileSync(LOCK_FILE, String(process.pid));

// Handle restart signal (SIGUSR2)
process.on('SIGUSR2', () => {
  console.log('[MC] Received restart signal, reloading with new port...');
  restarting = true;
  if (child) child.kill('SIGTERM');
});

process.on('SIGTERM', () => {
  fs.unlinkSync(LOCK_FILE);
  if (child) child.kill('SIGTERM');
  process.exit(0);
});

process.on('SIGINT', () => {
  fs.unlinkSync(LOCK_FILE);
  if (child) child.kill('SIGTERM');
  process.exit(0);
});

// Auto-register agents in OpenClaw World after startup
function registerAgentsInWorld() {
  const http = require('http');
  const AGENTS_PATH = path.join(__dirname, 'data', 'agents.json');
  let agents;
  try {
    const data = JSON.parse(fs.readFileSync(AGENTS_PATH, 'utf8'));
    agents = (data.agents || []).filter(a => a.id !== 'kevin');
  } catch (e) {
    console.log('[MC] Could not read agents.json for world registration:', e.message);
    return;
  }

  agents.forEach((agent, i) => {
    // Spread agents in a circle so they don't stack
    const angle = (i / agents.length) * Math.PI * 2;
    const radius = 4 + (i % 3); // Vary radius a bit
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;

    const payload = JSON.stringify({
      command: 'register',
      args: {
        agentId: agent.id,
        name: agent.displayName || agent.name,
        avatarType: agent.avatarType || 'lobster',
        color: agent.color || '#6366f1',
      }
    });

    const req = http.request({
      hostname: '127.0.0.1',
      port: 18800,
      path: '/ipc',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      timeout: 3000,
    }, res => {
      console.log(`[MC] Registered ${agent.id} in World: ${res.statusCode}`);
      res.resume();
      // Move agent to spread position
      const posPayload = JSON.stringify({
        command: 'position',
        args: { agentId: agent.id, x, y: 0, z, rotation: -angle }
      });
      const posReq = http.request({
        hostname: '127.0.0.1', port: 18800, path: '/ipc', method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(posPayload) },
        timeout: 3000,
      }, posRes => { posRes.resume(); });
      posReq.on('error', () => {});
      posReq.on('timeout', () => posReq.destroy());
      posReq.write(posPayload);
      posReq.end();
    });
    req.on('error', () => {}); // Silently ignore if World isn't running
    req.on('timeout', () => req.destroy());
    req.write(payload);
    req.end();
  });
  console.log(`[MC] Sent ${agents.length} agent registrations to OpenClaw World`);
}

// Register agents 3s after startup to give World time
setTimeout(registerAgentsInWorld, 3000);

startNext(readPort());
