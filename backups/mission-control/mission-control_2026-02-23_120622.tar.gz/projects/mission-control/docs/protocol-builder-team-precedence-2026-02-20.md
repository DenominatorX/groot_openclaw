# Protocol Builder vs Assigned Team Precedence

**Date:** 2026-02-20  
**Purpose:** Clean implementation of precedence rules for Protocol Builder team suggestions vs Assigned Project Team in Mission Control

---

## Summary

This implementation establishes clear precedence rules between the Protocol Builder's team suggestions and the Assigned Project Team:

- **Assigned Project Team is the source of truth by default**
- **Protocol Builder acts as a helper/suggester only**
- **Builder suggestions only replace team via explicit user action (confirm/apply)**
- **All decisions are audited with metadata (who, when, source)**

---

## Files Changed

### Backend

| File | Change |
|------|--------|
| `lib/protocol-builder/types.ts` | Added `TeamDecision`, `TeamSuggestion`, `ProjectTeamMember` interfaces for type safety |
| `lib/protocol-builder/team.ts` | Implemented `generateTeamSuggestions()`, `saveTeamDecision()`, `getTeamDecision()` for suggestion generation and audit trail |
| `app/api/projects/[id]/protocol-builder/route.ts` | Added `includeTeamSuggestions` query param, team action handlers (`apply-suggestions`, `keep-assigned`) |

### Frontend

| File | Change |
|------|--------|
| `components/ProtocolBuilder/ProtocolBuilderTab.tsx` | Added team suggestion UI with explicit actions: "Apply Suggested Team" and "Keep Assigned Team" |

---

## Precedence Rules

| Scenario | Behavior |
|----------|----------|
| **Team already assigned** | Protocol Builder auto-generates suggestions from that team context; UI shows both assigned and suggested teams |
| **No team assigned** | Builder may suggest team + protocol based on project name/description |
| **User applies suggestion** | Builder suggestion replaces assigned team; decision is persisted with `source: "builder-suggested"` |
| **User keeps assigned** | Assigned team remains; decision is persisted with `source: "assigned"` |

---

## UI Behavior

### When Team Is Already Assigned
- Shows **Current Assigned Team** (green badge) with "(source of truth)" label
- Shows **Suggested Team** (yellow badge) from Protocol Builder
- Two explicit action buttons:
  - **Apply Suggested Team** - Replaces assigned team with builder suggestion
  - **Keep Assigned Team** - Retains current team, dismisses suggestions

### When No Team Assigned
- Shows **Suggested Team** from Protocol Builder
- Single action button: **Apply Suggested Team**
- Protocol Builder acts as initializer

---

## Auditability

All team decisions are persisted to `TEAM_DECISION.json` in the project directory:

```json
{
  "source": "builder-suggested" | "assigned" | "auto-generated" | "manual",
  "timestamp": "2026-02-20T18:30:00.000Z",
  "madeBy": "user-id-or-system",
  "appliedFromSuggestion": true | false,
  "originalTeam": [...]
}
```

The last 10 decisions are retained for audit trail.

---

## API Changes

### GET `/api/projects/[id]/protocol-builder`

**Query Parameters:**
- `includeTeamSuggestions=true` - Include team suggestions in response

**Response additions:**
- `assignedTeam` - Current assigned team members
- `suggestedTeam` - Protocol Builder suggestions
- `teamDecision` - Last decision metadata
- `hasPendingSuggestions` - Whether user needs to decide

### PUT `/api/projects/[id]/protocol-builder`

**New body options:**

```json
{
  "action": "apply-suggestions",
  "team": [{ "agentId": "...", "role": "..." }]
}
```

```json
{
  "action": "keep-assigned"
}
```

---

## Validation

- `npm run build` ✅ **PASSES**

---

## Decision Matrix

| Condition | Assigned Team | Suggested Team | Action Options |
|-----------|---------------|----------------|----------------|
| Has assigned + has suggestions | Shown | Shown | Apply Suggested / Keep Assigned |
| No assigned + has suggestions | — | Shown | Apply Suggested |
| Has assigned + no suggestions | Shown | — | (no action needed) |
| No assigned + no suggestions | — | — | (cannot generate) |

---

## Implementation Notes

1. **Team is loaded from project data** via `getProjectTeam()` which reads from SQLite database
2. **Suggestions generated from project metadata** using keyword matching on project name/description
3. **Protocol auto-generated from team** via `generateProtocolFromTeam()` which maps team roles to protocol steps
4. **Frontend polling** for team suggestions is not required - data loads on tab activation
5. **Decision metadata persists** even if team is later modified manually
