# MaxTarget Review — Maverick Steele, CMO
### February 16, 2026

---

## Verdict: This Isn't a Marketing Platform. It's a Decorated TODO List.

I've spent the last hour going through every line of MaxTarget. Here's the truth Andy doesn't want to hear but needs to: **this thing is 95% facade.** It looks like a marketing suite. It has 17 tabs. It has the right words — "Pipeline," "Campaigns," "ABM," "Automation." But behind those tabs? Almost nothing works.

Let me be specific.

---

## The Core 7 Tabs: A Disaster Tour

### 1. Pipeline / Leads — Grade: D-
**What it does:** Shows stage counts and a lead list. Adding a lead? `prompt('Company name:')`. That's right — the primary data entry mechanism for a B2B marketing platform is a **browser prompt() dialog**. No form validation. No field types. No required fields. You can create a lead with zero information.

**What's broken:**
- `leads.json` is literally `[]` — empty. Zero seed data.
- Lead scoring is manual — you type a number into a prompt box. There's no algorithm, no weighting, no automation.
- No search, no filtering, no sorting. With 50+ leads this is unusable.
- Stage changes via `prompt()` — user has to *type* the exact stage name. One typo and nothing happens.
- No lead source tracking beyond a text field.
- No activity history, no engagement tracking, no timeline.

**The fix:** Proper modal forms with dropdowns, validation, and auto-populated fields. Seed data with 15-20 realistic SpecTarget leads. Add search/filter. Lead scoring should be calculated from engagement signals, not manually typed.

### 2. Campaigns — Grade: D
**What it does:** Shows campaign cards with name, type, status, budget/spent, and basic metrics. Creating a campaign? Another `prompt()`. The only editable field post-creation is status — also via prompt.

**What's broken:**
- `campaigns.json` has ONE campaign called "Andy" with $5K budget, $0 spent, zero everything. Test data that was never replaced.
- No budget utilization visualization. No burn rate. No pacing indicators.
- Metrics are all zeros. No way to enter or simulate performance data.
- No date range display. No channel breakdown. No ROI calculation.
- Campaign type defaults to 'email' with no way to change it.
- No campaign detail view — everything is crammed into a card.

**The fix:** Seed with 8-10 realistic SpecTarget campaigns across multiple types (programmatic, geo-fence, IP targeting, social, email). Add budget progress bars, status indicators with color coding, real metrics. Replace prompt() with modal forms.

### 3. Analytics — Grade: F
**What it does:** Shows summary cards (Total Leads, MQLs, SQLs, Closed Won) and a "Top Performing Campaigns" section. That's it.

**What's broken:**
- All values come from an API that just counts the JSON files — which are empty. So everything shows 0.
- No charts. No graphs. No trends. No time-series data. Nothing visual.
- No date range selection. No comparison periods.
- "Top Performing Campaigns" section shows nothing because campaigns have zero metrics.
- This is a dashboard that dashboards nothing.

**The fix:** Add CSS bar charts for pipeline stages, campaign performance, and channel breakdown. Add a funnel visualization. Add month-over-month trend indicators. Compute real metrics from the seeded data.

### 4. Competitors — Grade: D+
**What it does:** Renders competitor cards with strengths/weaknesses. The data in `competitors.json` is generic placeholder stuff — "Programmatic B2B," "ExactDrive," "FireFly Marketing" — mostly names with vague descriptions and zero weaknesses listed.

**What's broken:**
- We literally have a 21-competitor deep research report sitting in the docs folder and this tab doesn't use ANY of it.
- No threat level indicators. No comparison matrix. No market positioning map.
- No link between competitor data and campaign strategy.
- Weaknesses arrays are all empty — so the weakness column shows nothing.

**The fix:** Replace competitors.json with the top 10 from my research report. Include real strengths, real weaknesses, real market positions, URLs, and threat levels. Wire the tab to actually display useful competitive intelligence.

### 5. Audiences (ICPs) — Grade: D-
One test entry called "Test" in industry "test 123." Arrays for job titles, geography, tech stack, intent signals, and pain points are all empty. Another prompt()-based creation flow. No ICP templates, no audience sizing, no overlap analysis.

### 6. Content — Grade: D-
One entry called "test" with empty body. prompt() creation. No content calendar, no workflow states, no version history, no AI generation integration.

### 7. Sequences — Grade: F
Empty. `sequences.json = []`. Creation via prompt(). No sequence builder, no step editor, no timing controls, no preview.

---

## The 10 Module Panels: AI Wrapper Theatre

Every single panel (SEO, Social, Email, Ads, Research, Reporting, Brand, Conversion, ABM, Automation) follows the exact same pattern:

1. User types something into a text field
2. App sends it to an API endpoint
3. API calls an AI model
4. Response gets displayed in a text box
5. User can "copy to clipboard"

That's it. **Every panel is a glorified ChatGPT wrapper with a copy button.** There's no:
- Data persistence (generated content disappears on refresh)
- Integration with campaigns or leads
- Workflow or approval process
- Historical tracking
- Real tool functionality (no actual SEO crawling, no actual email sending, no actual ad management)

These panels are 3,660 lines of code that could be replaced by a single generic "Ask AI" component with a topic dropdown.

---

## Data Layer: A Ghost Town

| File | Contents |
|------|----------|
| `leads.json` | `[]` |
| `campaigns.json` | 1 test campaign called "Andy" |
| `audiences.json` | 1 test entry called "Test" |
| `content.json` | 1 test entry called "test" |
| `competitors.json` | 6 generic entries, no weaknesses |
| `sequences.json` | `[]` |

**Total real data across the entire platform: Zero.**

---

## The Good News

It's not all bad. The architecture is actually solid underneath:
- Clean TypeScript interfaces for all data types
- Proper API routes with CRUD operations
- Consistent dark theme aesthetic that looks professional
- The tab structure and component organization is good
- API routes handle POST/PUT/DELETE properly

The foundation is there. The house just has no furniture, no plumbing, and the doors are made of prompt() dialogs.

---

## Priority Fixes (In Order)

1. **Kill every prompt() in the app.** Replace with proper modal forms. This is a professional tool, not a 2003 JavaScript tutorial.
2. **Seed real data.** Every JSON file needs realistic SpecTarget demo data. Empty states are demoralizing.
3. **Wire the competitive intel.** We spent hours researching 21 competitors. That data should be IN the app, not sitting in a markdown file.
4. **Add the Intel tab.** The exec summary and full report need to be viewable inside MaxTarget. Andy should open one app and see everything.
5. **Analytics needs charts.** Summary cards showing zeros aren't analytics. Add visual representations of the pipeline, campaign performance, and trends.
6. **Campaigns need real metrics.** Budget tracking, status indicators, performance visualization. Not just a grid of cards showing $0.

---

## What I Refuse to Accept

- A marketing platform where the primary UX pattern is `window.prompt()`
- An analytics dashboard that shows no analytics
- A competitor tracker that doesn't use our own competitor research
- 3,660 lines of AI wrapper panels that are all identical in function
- JSON data files that are literally empty arrays

This platform should make Andy feel like he has a command center. Right now it makes him feel like he's using a prototype from a hackathon that ran out of time.

Let's fix it.

— **Maverick Steele**
