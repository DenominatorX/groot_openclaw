# MaxTarget Architecture Plan
### The Architect — February 16, 2026

---

## Current State

MaxTarget is a monolithic React component (`MaxTargetApp.tsx`, ~650 lines) with 10 child panel components (~3,660 lines total) backed by flat JSON files via Next.js API routes. The architecture is functional but has significant scaling and usability limitations.

**What works:**
- Clean TypeScript interfaces for all entities
- Consistent API route pattern (CRUD via JSON files)
- Dark theme component styling is consistent
- Tab-based navigation structure is appropriate for the feature count

**What doesn't:**
- Main component is a God Component — all state, forms, and rendering in one file
- Data layer is flat JSON files with no relationships or indexing
- All 10 panel components are identical AI-wrapper patterns with no persistence
- No shared component library (modals, forms, tables are ad-hoc)
- No client-side caching or optimistic updates

---

## Phase 1: Foundation (LOE: 2-3 days) ✅ PARTIALLY COMPLETE

### 1.1 Data Model Improvements
**Status: Done** — JSON files seeded with realistic SpecTarget data.

Current schema is adequate for MVP but needs these additions:

```typescript
// leads.json — Add these fields
interface Lead {
  // existing fields...
  engagementHistory: Array<{
    date: string;
    type: 'email_open' | 'page_visit' | 'form_submit' | 'meeting' | 'call';
    detail: string;
  }>;
  assignedTo: string;
  estimatedValue: number;
  tags: string[];
}

// campaigns.json — Add these fields
interface Campaign {
  // existing fields...
  dailyMetrics: Array<{ date: string; impressions: number; clicks: number; conversions: number; spent: number }>;
  goals: { targetConversions: number; targetCPA: number; targetROAS: number };
  creativeAssets: string[];
  notes: string;
}

// NEW: activities.json — Cross-entity activity log
interface Activity {
  id: string;
  entityType: 'lead' | 'campaign' | 'content';
  entityId: string;
  action: string;
  detail: string;
  timestamp: string;
  userId: string;
}
```

### 1.2 Component Extraction
Extract from MaxTargetApp.tsx into separate files:

```
components/apps/maxtarget/
├── Pipeline/
│   ├── PipelinePanel.tsx       (main view)
│   ├── LeadCard.tsx            (individual lead display)
│   ├── LeadForm.tsx            (add/edit modal form)
│   ├── PipelineFunnel.tsx      (funnel visualization)
│   └── LeadFilters.tsx         (search + stage filter bar)
├── Campaigns/
│   ├── CampaignPanel.tsx       (main view)
│   ├── CampaignCard.tsx        (individual campaign)
│   ├── CampaignForm.tsx        (add/edit modal form)
│   └── BudgetBar.tsx           (budget progress component)
├── Analytics/
│   ├── AnalyticsPanel.tsx      (main view)
│   ├── KPICard.tsx             (reusable metric card)
│   ├── BarChart.tsx            (CSS bar chart component)
│   └── FunnelChart.tsx         (pipeline funnel)
├── Competitors/
│   ├── CompetitorPanel.tsx     (main view)
│   └── CompetitorCard.tsx      (individual competitor)
├── shared/
│   ├── Modal.tsx               (reusable modal)
│   ├── FormField.tsx           (label + input wrapper)
│   ├── StatusBadge.tsx         (colored status pills)
│   └── ProgressBar.tsx         (reusable progress bar)
├── IntelPanel.tsx              ✅ DONE
├── SEOPanel.tsx                (existing)
├── SocialPanel.tsx             (existing)
├── EmailPanel.tsx              (existing)
├── AdPanel.tsx                 (existing)
├── ResearchPanel.tsx           (existing)
├── ReportingPanel.tsx          (existing)
├── BrandPanel.tsx              (existing)
├── ConversionPanel.tsx         (existing)
├── ABMPanel.tsx                (existing)
└── AutomationPanel.tsx         (existing)
```

### 1.3 Modal System ✅ DONE
Extracted inline `Modal` component. Next step: move to `shared/Modal.tsx` for reuse across panels.

---

## Phase 2: API Route Fixes (LOE: 2-3 days)

### Current API Routes
All routes follow the same pattern:
```
app/api/apps/maxtarget/[entity]/route.ts
  GET  → read JSON file, return array
  POST → append to array, write file
  PUT  → find by id, merge updates, write file
  DELETE → filter out by id, write file
```

### Required Fixes

**2.1 Analytics Route** — Currently returns raw counts from files. Should compute:
- Pipeline velocity (avg days per stage)
- Conversion rates between stages
- Campaign performance trends (daily/weekly aggregates)
- Lead source ROI (which sources produce Closed Won)
- Channel-level spend efficiency

**2.2 Relationships** — API routes need cross-entity queries:
- `GET /api/apps/maxtarget/leads?campaign=camp-001` — leads attributed to a campaign
- `GET /api/apps/maxtarget/campaigns?status=active` — filtered queries
- `GET /api/apps/maxtarget/analytics/pipeline` — computed pipeline metrics

**2.3 Bulk Operations**
- `POST /api/apps/maxtarget/leads/bulk` — import multiple leads
- `PUT /api/apps/maxtarget/leads/bulk-stage` — move multiple leads to a stage

**2.4 Search**
- `GET /api/apps/maxtarget/search?q=healthcare` — cross-entity search

### Data Persistence Strategy
For now, JSON files are fine (no DB needed). But add:
- File locking for concurrent writes
- Backup on write (keep last 5 versions)
- Max file size limits (warn at 1MB)

---

## Phase 3: AI Integration Points (LOE: 3-5 days)

The 10 existing panels are pure AI wrappers — they generate text and offer "copy to clipboard." Here's where real AI should be used:

### 3.1 Lead Scoring (Priority: HIGH)
**Where:** Pipeline → automatic on lead creation/update
**What:** AI analyzes company name, industry, engagement signals → returns 0-100 score + reasoning
**Implementation:** `POST /api/apps/maxtarget/ai/score-lead` called after lead save

### 3.2 Campaign Recommendations (Priority: HIGH)
**Where:** Campaign detail view → sidebar suggestion panel
**What:** Given campaign performance data, AI suggests budget adjustments, audience expansions, creative changes
**Implementation:** `POST /api/apps/maxtarget/ai/campaign-insights` with campaign + metrics data

### 3.3 Competitor Monitoring (Priority: MEDIUM)
**Where:** Competitors tab → "Refresh Intel" button
**What:** AI researches a competitor URL, extracts key changes, updates the competitor record
**Implementation:** `POST /api/apps/maxtarget/ai/research-competitor` with competitor URL

### 3.4 Content Generation (Priority: MEDIUM)
**Where:** Content tab → "Generate" button on content creation
**What:** AI generates content based on type, audience, and campaign context — with brand voice consistency
**Implementation:** Already exists in panels but needs persistence and campaign linkage

### 3.5 Pipeline Predictions (Priority: LOW)
**Where:** Analytics → "Predictions" section
**What:** Based on historical pipeline data, predict next month's MQLs, SQLs, revenue
**Implementation:** Requires at least 3 months of data — defer until data exists

### Integration Pattern
All AI calls should:
1. Use the existing `/api/apps/maxtarget/[module]` routes with `action: 'ai-*'`
2. Store results alongside the entity (not ephemeral)
3. Include a "confidence" score
4. Be manually triggerable (not automatic on every page load)

---

## Phase 4: Panel Consolidation (LOE: 3-4 days)

The 10 AI wrapper panels (SEO, Social, Email, Ads, Research, Reporting, Brand, Conversion, ABM, Automation) should be consolidated:

### Option A: Merge into 4 Super-Panels
- **Channels Panel** — SEO + Social + Email + Ads (channel-specific tools)
- **Intelligence Panel** — Research + Competitors + Intel (analysis tools)
- **Creative Panel** — Brand + Content (content creation with brand voice)
- **Operations Panel** — Automation + ABM + Conversion (execution tools)

### Option B: Keep Tabs but Add Data Persistence
Each panel gets a "saved outputs" section showing previous AI generations stored in a new `ai-outputs.json` file. This is simpler and doesn't break the current nav.

**Recommendation: Option B for now.** Less risk, preserves existing functionality, and adds the missing persistence layer.

---

## Phase 5: Advanced Features (LOE: 5-8 days)

### 5.1 Activity Timeline
Every entity (lead, campaign, content) gets a chronological activity log showing all actions taken. Stored in `activities.json`.

### 5.2 Dashboard View
New "Dashboard" tab as the default landing showing:
- Pipeline health at a glance
- Active campaign performance
- Recent activity feed
- Alerts (budget overspend, stale leads, campaign ending soon)

### 5.3 Client Reporting
The Reporting panel should generate actual PDF-style reports combining campaign data, analytics, and competitor intelligence. Render as a printable HTML view.

### 5.4 Email Integration
Connect the Email panel to actual email sending (via API key for SendGrid/Postmark). Store sent emails and track opens/clicks.

---

## LOE Summary

| Phase | Scope | Effort | Dependencies |
|-------|-------|--------|-------------|
| Phase 1 | Data + Components + Modals | 2-3 days | None |
| Phase 2 | API Routes + Relationships | 2-3 days | Phase 1 |
| Phase 3 | AI Integration | 3-5 days | Phase 2 |
| Phase 4 | Panel Consolidation | 3-4 days | Phase 1 |
| Phase 5 | Advanced Features | 5-8 days | Phases 1-3 |
| **Total** | **Full Overhaul** | **15-23 days** | |

---

## Technical Constraints
- No new npm packages — use built-in React, CSS, and SVG for visualizations
- JSON file storage is acceptable for current scale (<100 entities per type)
- AI calls use existing OpenAI/Anthropic integration in the MC codebase
- All new components must follow the dark theme (bg-gray-900/800, #DC143C accents, white text)
- TypeScript strict mode — all new code must be fully typed

---

## What Was Done Today (Feb 16, 2026)

1. ✅ **Maverick's Review** — `MAXTARGET_REVIEW.md` — brutal assessment of current state
2. ✅ **Intel Panel** — New `IntelPanel.tsx` component + "Intel" tab in MaxTargetApp
3. ✅ **Pipeline Fix** — Replaced all `prompt()` with proper modal forms, added search/filter, funnel viz, color-coded stages and scores
4. ✅ **Campaigns Fix** — Added summary cards, budget progress bars, full metrics grid, status controls, channel tags
5. ✅ **Analytics Fix** — Added pipeline funnel chart, spend-by-type bars, lead source bars, top campaigns ranking, aggregate KPIs
6. ✅ **Competitors Fix** — Wired to real research data (10 competitors from report), threat level grouping, "what they do better" callouts
7. ✅ **Data Seeding** — 15 leads, 10 campaigns, 10 competitors with realistic SpecTarget data
8. ✅ **Architecture Plan** — This document

— **The Architect**
