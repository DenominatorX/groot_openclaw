# Discord Project Meeting Configuration

## Overview

This document describes the Discord integration for Project Meetings (PM) in Mission Control. The system routes project meeting threads to configured Discord channels.

## Configuration

### Accessing Settings

1. Navigate to **Settings** in Mission Control
2. Click **Discord Config** in the quick links section
3. Configure the following fields:

### Settings Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| **PM Channel IDs** | 3 text fields | `[empty, empty, empty]` | Discord channel IDs for routing project meetings |
| **Default PM Agent** | text | `gork` | Agent ID to assign as PM for new projects |
| **Channel Name Template** | text | `Project - {{projectId}}` | Template for auto-generated channel names |
| **Auto-pin Requirements** | toggle | `false` | Automatically pin requirements messages |
| **Compact Policy** | dropdown | `manual` | `manual` or `threshold` - how messages are handled |

### Finding Discord Channel IDs

1. Enable Developer Mode in Discord (User Settings → Advanced → Developer Mode)
2. Right-click on a channel
3. Select "Copy Channel ID"

## Verification Script

A utility script is available to verify the channel configuration:

```bash
# Basic verification (read-only)
./workspace/tools/discord-pm-verify.sh

# Send test pings to configured channels
./workspace/tools/discord-pm-verify.sh --test-ping
```

### Script Output

The script will:
1. Read configuration from the Mission Control database
2. Display current settings
3. Validate channel IDs (must be numeric)
4. Optionally send test messages to configured channels

## Operator Workflow

### Setting Up for a New Project

1. **Configure Channels** (one-time setup):
   - Go to Settings → Discord Config
   - Enter 3 PM channel IDs (e.g., for different project tiers)
   - Set default PM agent
   - Save

2. **For Each New Project**:
   - Create the project in Mission Control
   - System will auto-route to configured PM channel based on template
   - Default PM agent is assigned automatically

3. **During Project Execution**:
   - Check the Discord channel for updates
   - If Auto-pin is enabled: requirements are auto-pinned
   - If Compact Policy = threshold: X messages trigger compact summary

### Channel Routing Logic

```
Project Created → Extract tier/priority → Select PM Channel (1/2/3) → Create thread
```

The system selects which of the 3 configured channels to use based on:
- Project priority (high → channel 1, medium → channel 2, low → channel 3)
- Or round-robin if no priority mapping

## API Endpoints

### GET /api/settings/discord

Returns the current Discord configuration.

```json
{
  "discord": {
    "pmChannelIds": ["123456789", "987654321", "456123789"],
    "defaultPmAgent": "gork",
    "channelNameTemplate": "Project - {{projectId}}",
    "autoPinRequirements": false,
    "compactPolicy": "manual"
  }
}
```

### PUT /api/settings/discord

Updates Discord configuration.

```json
{
  "pmChannelIds": ["123456789", "987654321", "456123789"],
  "defaultPmAgent": "gork",
  "channelNameTemplate": "Project - {{projectId}}",
  "autoPinRequirements": true,
  "compactPolicy": "threshold"
}
```

## Limitations (Phase 1)

- **No automatic channel creation**: Channels must exist before configuration
- **No channel rename API**: Template is stored but renaming requires manual or future API integration
- **Basic routing**: Priority-based routing only (no advanced rules)
- **No Discord webhook**: Uses bot token only (webhooks coming Phase 2)
- **No message compacting**: Threshold policy defined but not implemented

## Future Phases

- Phase 2: Auto-create channels from template
- Phase 2: Discord webhook integration for richer messages
- Phase 3: Advanced routing rules (by project type, tags, etc.)
- Phase 3: Message compacting automation
