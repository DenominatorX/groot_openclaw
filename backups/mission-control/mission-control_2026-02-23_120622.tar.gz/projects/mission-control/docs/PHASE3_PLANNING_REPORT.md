# Phase 3 Technical Specification: Brain Orchestration Engine
## Brain Intelligence System — Research & Planning Report

**Created:** 2026-02-14  
**Status:** PLANNING PHASE — NOT IMPLEMENTED  
**Model:** MiniMax M2.5

---

## Executive Summary

This document provides a comprehensive technical specification for Phase 3 (Brain Orchestration Engine) of the Brain Intelligence System, along with security analysis and recommendations for remaining phases. The existing system has foundational infrastructure in place that Phase 3 can build upon.

---

## 1. Current System State Analysis

### 1.1 Existing Agent Infrastructure

**Agent Registry (`data/agents.json`):**
- **27 registered agents** across multiple tiers (0-6)
- Executive Board: Kevin, Groot, Jimmy T, CEO, Dr. Al, Dirty Bird, Brain
- Specialized agents: Viper (trading), Oracle (analysis), Sentinel (quality), memory agents (Archivist, Interrogator, Therapist)
- Tier hierarchy with model assignment (Opus 4.6 → MiniMax → Grok → Ollama)
- Capabilities-based routing system in place

**Agent Capabilities:**
- `orchestration`, `coding`, `research`, `automation`, `problem-solving`
- `project-management`, `task-delegation`, `cost-optimization`
- `health`, `diagnostics`, `supplements`, `exercise-protocol`
- `legal`, `compliance`, `contracts`, `risk-assessment`
- `synthesis`, `analysis`, `reasoning`, `pattern-recognition`

### 1.2 Existing Brain API (`/api/brain/orchestrate`)

The system already has partial Phase 3 functionality:

```
✅ handleDelegate(topic, agents, context) - Task delegation with LLM-based agent selection
✅ handleMeeting(topic, agents, context) - Meeting transcript generation
✅ handleConsensus(topic, agents, context) - Multi-perspective synthesis
✅ Meeting storage in data/brain/meetings.json
✅ Agent selection using Claude Haiku for capability matching
```

**Current Limitations:**
- Meetings are simulated (not real-time agent-to-agent)
- No live agent communication infrastructure
- No persistent meeting sessions
- No real-time delegation execution
- Consensus is synthetic (LLM模拟) not agent-negotiated

### 1.3 Room System (`data/rooms.json`)

10 meeting spaces defined:
- The Boardroom, Doctor's Office, Law Office, CEO's Suite
- The Office, Dev Studio, Break Room
- Memory Room (Archivist, Interrogator, Therapist)
- Brain Room (synthesis chamber)
- Trading Floor

---

## 2. Phase 3 Technical Specification

### 2.1 Core Requirements

| Requirement | Current State | Implementation Needed |
|-------------|---------------|----------------------|
| Brain reads all agents | Partial (can read agent list) | Full agent state awareness |
| Runs meetings | Simulated (LLM-generated transcripts) | Real-time multi-agent sessions |
| Delegates across specialists | Basic (capability matching) | Execution pipeline with tracking |
| Consensus building protocol | Synthetic (LLM synthesis) | Agent negotiation framework |

### 2.2 Architecture Design

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Brain Orchestration Layer                    │
├─────────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌──────────┐ │
│  │   Brain     │  │  Meeting    │  │  Delegation │  │ Consensus│ │
│  │  Monitor   │  │  Manager    │  │   Engine    │  │  Builder │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └──────────┘ │
├─────────────────────────────────────────────────────────────────────┤
│                      Agent Communication Bus                         │
├─────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    Agent Registry (Single Source of Truth)     │  │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐            │  │
│  │  │ Status  │ │Context  │ │History  │ │ Capabil │            │  │
│  │  │ Tracker │ │ Store   │ │         │ │ ities   │            │  │
│  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘            │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

### 2.3 Component Specifications

#### 2.3.1 Brain Monitor (`BrainMonitor.ts`)

**Purpose:** Real-time awareness of all agent states

**Data to Track:**
```typescript
interface AgentState {
  id: string;
  status: 'idle' | 'active' | 'busy' | 'meeting' | 'error';
  currentTask?: string;
  lastHeartbeat: number;
  context: string[]; // Topics currently being discussed
  capabilities: string[];
  availability: 'free' | 'busy' | 'do-not-disturb';
  location?: string; // Room/space
}
```

**API Endpoints:**
- `GET /api/brain/agents/status` - All agent states
- `GET /api/brain/agents/:id/status` - Single agent state
- `POST /api/brain/agents/:id/heartbeat` - Agent check-in

#### 2.3.2 Meeting Manager (`MeetingManager.ts`)

**Purpose:** Orchestrate real-time multi-agent meetings

**Meeting Lifecycle:**
```
Created → Scheduled → In Progress → Completed/Cancelled
```

**Data Model:**
```typescript
interface Meeting {
  id: string;
  topic: string;
  agenda: string[];
  participants: AgentParticipant[];
  noteTaker?: string;
  room: string;
  status: MeetingStatus;
  transcript: TranscriptEntry[];
  actionItems: ActionItem[];
  decisions: Decision[];
  startedAt?: Date;
  endedAt?: Date;
  createdBy: string;
}

interface AgentParticipant {
  agentId: string;
  role: 'facilitator' | 'contributor' | 'observer';
  joinedAt?: Date;
  contributions: Contribution[];
}
```

**API Endpoints:**
- `POST /api/brain/meetings` - Create meeting
- `GET /api/brain/meetings` - List meetings
- `GET /api/brain/meetings/:id` - Get meeting details
- `POST /api/brain/meetings/:id/start` - Start meeting
- `POST /api/brain/meetings/:id/message` - Agent message in meeting
- `POST /api/brain/meetings/:id/end` - End meeting

#### 2.3.3 Delegation Engine (`DelegationEngine.ts`)

**Purpose:** Route tasks to appropriate specialists

**Delegation Algorithm:**
1. Analyze task requirements (complexity, domain, urgency)
2. Query agent capabilities for match scoring
3. Consider availability and current workload
4. Route to best-fit agent
5. Track execution and report results

**Data Model:**
```typescript
interface Delegation {
  id: string;
  task: Task;
  assignedAgent: string;
  reasoning: string; // Why this agent was selected
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
  result?: any;
  executedAt: Date;
  completedAt?: Date;
  delegationChain: DelegationStep[]; // If sub-delegation occurs
}
```

**API Endpoints:**
- `POST /api/brain/delegations` - Create delegation
- `GET /api/brain/delegations` - List delegations
- `GET /api/brain/delegations/:id` - Get delegation status
- `POST /api/brain/delegations/:id/cancel` - Cancel delegation

#### 2.3.4 Consensus Builder (`ConsensusBuilder.ts`)

**Purpose:** Facilitate multi-agent decision making

**Consensus Protocol:**
1. Present topic to selected agents
2. Collect initial positions
3. Facilitate discussion (multiple rounds)
4. Identify areas of agreement/disagreement
5. Synthesize consensus view
6. Document dissent (if any)
7. Generate recommendation

**Data Model:**
```typescript
interface ConsensusProcess {
  id: string;
  topic: string;
  participants: string[];
  rounds: ConsensusRound[];
  consensusView?: string;
  dissentingViews?: string[];
  confidence: number; // 0-100
  recommendation: string;
  status: 'gathering' | 'discussing' | 'resolved' | 'deadlocked';
}
```

**API Endpoints:**
- `POST /api/brain/consensus` - Start consensus process
- `GET /api/brain/consensus/:id` - Get consensus status
- `POST /api/brain/consensus/:id/position` - Agent submits position
- `POST /api/brain/consensus/:id/resolve` - Resolve consensus

### 2.4 Implementation Priority

| Priority | Component | Complexity | Estimate |
|----------|-----------|------------|----------|
| P0 | Brain Monitor (read agents) | Low | 2 hrs |
| P1 | Meeting Manager UI | Medium | 4 hrs |
| P2 | Delegation Engine | Medium | 4 hrs |
| P3 | Consensus Builder | High | 6 hrs |
| P4 | Real-time Agent Communication | High | 8 hrs |

### 2.5 Frontend Components Needed

```tsx
// New components for Phase 3
components/
├── brain/
│   ├── BrainDashboard.tsx        // Main brain overview
│   ├── AgentStatusGrid.tsx      // Real-time agent status
│   ├── MeetingRoom.tsx          // Active meeting view
│   ├── MeetingList.tsx          // Past meetings
│   ├── DelegationTracker.tsx    // Track delegations
│   ├── ConsensusBoard.tsx       // Active consensus processes
│   └── BrainControls.tsx        // Mood/behavior controls
```

---

## 3. Security & Privacy Analysis

### ⚠️ SECURITY CONCERNS IDENTIFIED

#### 3.1 Agent-to-Agent Communication Risks

| Risk | Severity | Description |
|------|----------|-------------|
| **Context Leakage** | 🔴 HIGH | Agents sharing sensitive context (Kevin's health data, financial info) with unauthorized parties |
| **Prompt Injection** | 🔴 HIGH | Malicious input injected into agent conversations affecting downstream agents |
| **Capability Escalation** | 🟠 MEDIUM | Agents using other agents' capabilities beyond intended scope |
| **Data Aggregation** | 🟠 MEDIUM | Brain aggregating context from multiple agents could expose private information |
| **Meeting Eavesdropping** | 🟡 LOW | Unintended agents joining or listening to meetings |

#### 3.2 Specific Concerns for Phase 3

**🚨 CONCERN #1: Unrestricted Context Aggregation**
- Brain can read ALL agent data including:
  - Kevin's private preferences and communication style
  - Health data (Dr. Al's domain)
  - Financial data (Viper's trading)
  - Legal matters (Dirty Bird's contracts)
- **RISK:** Context aggregation could leak sensitive information across agents who shouldn't have it
- **MITIGATION NEEDED:** Role-based context filtering, data classification labels

**🚨 CONCERN #2: Meeting Transcript Storage**
- Meeting transcripts stored in plaintext JSON
- Contains agent deliberations, potentially sensitive discussions
- **MITIGATION NEEDED:** Encryption at rest, access controls

**🚨 CONCERN #3: Delegation Chain Exploitation**
- If Agent A delegates to Agent B, Agent B inherits Agent A's context
- Could be chained maliciously to escalate access
- **MITIGATION NEEDED:** Delegation depth limits, context scoping

**🚨 CONCERN #4: Consensus Manipulation**
- A single compromised agent could skew consensus
- No verification of agent identity
- **MITIGATION NEEDED:** Agent authentication, consensus quorum requirements

#### 3.3 Recommended Security Controls

```typescript
// Security middleware for agent communication
interface SecurityPolicy {
  // Context filtering
  allowedContextFields: Record<string, string[]>; // Agent -> allowed fields
  forbiddenPatterns: RegExp[];
  
  // Delegation limits
  maxDelegationDepth: number; // Default: 2
  requireApprovalForExternal: boolean;
  
  // Meeting controls
  requireExplicitInvite: boolean;
  maxParticipants: number;
  transcriptRetentionDays: number;
  
  // Consensus
  minParticipantsForConsensus: number; // Default: 2
  requireDissentDocumentation: boolean;
}
```

---

## 4. Research: Remaining Phases (4-13)

Based on `MASTER_PLAN.md` and existing documentation:

### Phase 4: Agent Hierarchy & Model Tiering
**Status:** Partial implementation (tiers exist in agents.json)
**Implementation:**
- UI for tier management (`/settings/agent-tiers`)
- Cost tracking dashboard
- Auto-delegation based on task complexity scoring
- Sub-agent spawning UI

### Phase 5: Projects, Roles & Reports
**Status:** Partial (projects and reports exist)
**Implementation:**
- Role templates per project
- Report generation pipeline
- Analytics charts (Recharts/Chart.js)
- Project burn rate tracking

### Phase 6: Agent World Themes & Weather
**Status:** Not started
**Implementation:**
- Theme selector UI
- Weather API integration (wttr.in)
- Skybox/environment switching
- Particle effects for weather

### Phase 7: Voice Integration
**Status:** Not started
**Implementation:**
- ElevenLabs API integration
- Per-agent voice profiles
- TTS for meeting messages
- Voice toggle per meeting

### Phases 8-13: Not Documented
The MASTER_PLAN.md only covers phases 1-7. Additional phases would need to be defined.

---

## 5. Recommendations

### 5.1 For Phase 3 Implementation

1. **Start with Brain Monitor** - It's the foundation and lowest risk
2. **Build Meeting UI incrementally** - Start with read-only, then add real-time
3. **Implement security controls FIRST** - Before enabling agent-to-agent communication
4. **Use existing infrastructure** - Extend `/api/brain/orchestrate` rather than rebuild

### 5.2 Security Recommendations

| Priority | Action |
|----------|--------|
| 🔴 CRITICAL | Implement context filtering — agents only see relevant context |
| 🔴 CRITICAL | Add meeting access controls with explicit invites |
| 🟠 HIGH | Add delegation depth limits and require approval |
| 🟠 HIGH | Encrypt stored meeting transcripts |
| 🟡 MEDIUM | Add agent identity verification |
| 🟡 MEDIUM | Implement audit logging for all agent interactions |

### 5.3 Privacy Recommendations

1. **Data Classification** - Label data as PUBLIC/INTERNAL/CONFIDENTIAL/PRIVATE
2. **Context Scoping** - Only provide necessary context to agents
3. **Retention Policies** - Auto-delete old meeting transcripts
4. **Access Logs** - Track who accessed what data

---

## 6. Conclusion

Phase 3 has a solid foundation to build upon with the existing orchestration API. The main work is:

1. **Building real-time agent communication** (currently simulated)
2. **Creating the UI** for meetings, delegations, and consensus
3. **Implementing security controls** before enabling agent-to-agent communication

**Key Risk:** The agent-to-agent communication infrastructure could leak sensitive information if not properly secured. **This should be flagged as a concern and addressed before enabling live agent interactions.**

---

*Report generated for Phase 3 planning. This is a planning document — no code has been implemented.*
