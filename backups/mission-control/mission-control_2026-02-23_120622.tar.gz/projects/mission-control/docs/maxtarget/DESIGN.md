# MaxTarget Marketing Dashboard — Design Document

## Architecture Overview

### Tech Stack
- **Frontend**: React/Next.js with TypeScript
- **Styling**: Tailwind CSS (dark theme: #1a1a1a, #2d2d2d, red accent #DC143C)
- **State Management**: React useState/useEffect + Context for global state
- **API**: Next.js API Routes
- **Data Persistence**: JSON files in `data/apps/maxtarget/`
- **AI**: OpenAI integration via existing `/api/apps/maxtarget/*` routes

### High-Level Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    MaxTargetApp.tsx                         │
│  (Main Container - Tab Routing, Shared State)              │
├──────────┬──────────┬──────────┬──────────┬──────────────┤
│ Pipeline │Campaigns │Audiences │ Content  │ Analytics    │
│  (Core)  │  (Core)  │  (Core)  │  (Core)  │   (Core)    │
├──────────┴──────────┴──────────┴──────────┴──────────────┤
│                    Module Panels                             │
├──────────┬──────────┬──────────┬──────────┬──────────────┤
│   SEO    │  Social  │  Email   │   Ads    │    ABM       │
├──────────┼──────────┼──────────┼──────────┼──────────────┤
│Automation│  Brand   │Conversion│ Research │  Reporting   │
└──────────┴──────────┴──────────┴──────────┴──────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    API Routes Layer                         │
│  /api/apps/maxtarget/{module}                              │
│  - GET/POST/PUT/DELETE for CRUD                          │
│  - POST for AI generation                                 │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Data Layer                                │
│  data/apps/maxtarget/{module}.json                        │
└─────────────────────────────────────────────────────────────┘
```

---

## Component Hierarchy

```
MaxTargetApp (Page)
├── Header (Logo + Title)
├── TabNavigation (17 tabs)
├── TabContent
│   ├── PipelineView (inline)
│   ├── CampaignsView (inline)
│   ├── AudiencesView (inline)
│   ├── ContentView (inline)
│   ├── AnalyticsView (inline)
│   ├── CompetitorsView (inline)
│   ├── SequencesView (inline)
│   └── [Module Panels - separate components]
│       ├── SEOPanel
│       │   ├── KeywordsTab
│       │   ├── AnalyzerTab
│       │   ├── GapTab
│       │   ├── PreviewTab
│       │   └── MetaTab
│       ├── SocialPanel
│       │   ├── GeneratorTab
│       │   ├── CalendarTab
│       │   ├── HashtagsTab
│       │   ├── CaptionsTab
│       │   ├── AdsTab
│       │   └── TemplatesTab
│       ├── EmailPanel
│       │   ├── SubjectsTab
│       │   ├── TemplateTab
│       │   ├── ABTestsTab
│       │   ├── ColdOutreachTab
│       │   ├── NewsletterTab
│       │   └── SpamCheckTab
│       ├── AdPanel
│       │   ├── CopyTab
│       │   ├── GoogleTab
│       │   ├── FacebookTab
│       │   ├── LinkedInTab
│       │   ├── LandingTab
│       │   └── UTMTab
│       ├── ABMPanel
│       │   ├── IntelligenceTab
│       │   ├── OutreachTab
│       │   ├── ScorecardTab
│       │   ├── CampaignTab
│       │   └── HealthTab
│       ├── AutomationPanel
│       │   ├── BuilderTab
│       │   ├── TemplatesTab
│       │   └── SimulatorTab
│       ├── BrandPanel
│       │   ├── VoiceTab
│       │   ├── MessagingTab
│       │   ├── AuditTab
│       │   ├── NamingTab
│       │   └── TaglinesTab
│       ├── ConversionPanel
│       │   ├── AuditTab
│       │   ├── CTATab
│       │   ├── FormTab
│       │   ├── ProofTab
│       │   └── PricingTab
│       ├── ResearchPanel
│       │   ├── IndustryTab
│       │   ├── SWOTTab
│       │   ├── PersonaTab
│       │   ├── ValuePropTab
│       │   ├── CompetitorsTab
│       │   ├── MarketTab
│       │   └── TrendsTab
│       └── ReportingPanel
│           ├── ClientReportTab
│           ├── ProposalTab
│           ├── CaseStudyTab
│           ├── ROITab
│           ├── PitchDeckTab
│           ├── ReviewTab
│           └── InvoiceTab
└── Shared Components (to be extracted)
    ├── DataTable
    ├── Card
    ├── Modal
    ├── Form
    ├── Button
    └── Badge
```

---

## API Route Design

### Core CRUD Routes
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/apps/maxtarget/leads` | List all leads |
| POST | `/api/apps/maxtarget/leads` | Create lead |
| PUT | `/api/apps/maxtarget/leads` | Update lead |
| DELETE | `/api/apps/maxtarget/leads` | Delete lead |
| GET | `/api/apps/maxtarget/campaigns` | List all campaigns |
| POST | `/api/apps/maxtarget/campaigns` | Create campaign |
| PUT | `/api/apps/maxtarget/campaigns` | Update campaign |
| DELETE | `/api/apps/maxtarget/campaigns` | Delete campaign |
| GET | `/api/apps/maxtarget/audiences` | List audiences |
| POST | `/api/apps/maxtarget/audiences` | Create audience |
| PUT | `/api/apps/maxtarget/audiences` | Update audience |
| DELETE | `/api/apps/maxtarget/audiences` | Delete audience |
| GET | `/api/apps/maxtarget/content` | List content |
| POST | `/api/apps/maxtarget/content` | Create content |
| PUT | `/api/apps/maxtarget/content` | Update content |
| DELETE | `/api/apps/maxtarget/content` | Delete content |

### Module-Specific Routes
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/apps/maxtarget/seo/keywords` | Generate keywords |
| POST | `/api/apps/maxtarget/seo/analyze` | Analyze page |
| POST | `/api/apps/maxtarget/social/post` | Generate social post |
| POST | `/api/apps/maxtarget/email/send` | Send email (mock) |
| POST | `/api/apps/maxtarget/email/templates` | Save template |
| POST | `/api/apps/maxtarget/abm/accounts` | Manage accounts |
| POST | `/api/apps/maxtarget/automation/flows` | CRUD flows |
| POST | `/api/apps/maxtarget/automation/enroll` | Enroll contact |
| POST | `/api/apps/maxtarget/brand/identity` | Save brand identity |
| POST | `/api/apps/maxtarget/abtest` | Create A/B test |
| GET | `/api/apps/maxtarget/analytics/summary` | Get analytics |

### Data Flow

```
User Action
    │
    ▼
React Component (useState)
    │
    ▼
fetch('/api/apps/maxtarget/...')
    │
    ▼
API Route Handler
    │
    ├──► AI Service (for generation)
    │         │
    │         ▼
    │     OpenAI API
    │         │
    │         ▼
    │     Return generated content
    │
    └──► File System (for persistence)
              │
              ▼
        data/apps/maxtarget/*.json
```

---

## Phase Plan

### Phase 1: Foundation (Weeks 1-2)
**Goal:** Core data models and CRUD operations working

| Task | Description |
|------|-------------|
| 1.1 | Update data models in code (add all fields) |
| 1.2 | Create CRUD API routes for all modules |
| 1.3 | Build lead pipeline with scoring |
| 1.4 | Build campaign management with budget tracking |
| 1.5 | Build audience/ICP management |
| 1.6 | Build content management |
| 1.7 | Connect analytics to real data |

### Phase 2: Marketing Suite (Weeks 3-4)
**Goal:** Working marketing tools

| Task | Description |
|------|-------------|
| 2.1 | Email marketing: contacts, templates, sending (mock) |
| 2.2 | Social: calendar, scheduling, library |
| 2.3 | SEO: keyword tracking, site auditor |
| 2.4 | ABM: account management, scoring |
| 2.5 | Automation: flow builder with execution |

### Phase 3: Advanced Features (Weeks 5-6)
**Goal:** Enterprise features

| Task | Description |
|------|-------------|
| 3.1 | A/B testing with results tracking |
| 3.2 | Advanced analytics with charts |
| 3.3 | Reporting: templates, scheduling |
| 3.4 | Brand asset management |
| 3.5 | Conversion optimization tools |

### Phase 4: Integration (Weeks 7-8)
**Goal:** External integrations and polish

| Task | Description |
|------|-------------|
| 4.1 | Ad platform integrations (mock) |
| 4.2 | Email sending integration |
| 4.3 | UI/UX polish |
| 4.4 | Mobile responsiveness |
| 4.5 | Performance optimization |

---

## Key Decisions

### Data Persistence
- Use JSON files for simplicity
- Structure: `data/apps/maxtarget/{module}.json`
- Migration path: Can move to database later

### AI Integration
- Keep existing AI routes working
- Add new endpoints as needed
- Focus on practical generation, not just demo

### Component Architecture
- Extract shared components early
- Use consistent patterns across panels
- Build form components once, reuse

### State Management
- Local state for panel-specific data
- Parent component for cross-panel data (leads, campaigns)
- Context for global settings (brand identity)
