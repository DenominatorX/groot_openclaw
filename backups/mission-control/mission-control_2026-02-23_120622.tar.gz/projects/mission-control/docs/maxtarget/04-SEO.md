# SEO Tools — Requirements Document

## Current State

**What exists now:**
- `SEOPanel.tsx` with 5 tabs: Keywords, Analyzer, Gap, SERP Preview, Meta Tags
- Keyword Research: Enter topic → AI generates keyword suggestions with difficulty, search intent, content angle
- On-Page Analyzer: Enter URL/HTML → AI analyzes (mock returns sample data)
- Content Gap: Enter your site + competitor → AI identifies missing topics
- SERP Preview: Live preview of title, URL, meta description
- Meta Tags: AI generates title + meta description from topic

**What it actually does:**
- Returns AI-generated mock data (not real search data)
- No integration with Google API, Ahrefs, SEMrush, etc.
- No rank tracking, no site crawling, no real metrics

**Missing:**
- Real keyword data (search volume, difficulty from APIs)
- Rank tracking and monitoring
- Site crawling/auditing
- Backlink analysis
- Competitor analysis with real data

---

## Gap Analysis

| Feature | Current | Semrush/Ahrefs | Gap |
|---------|---------|----------------|-----|
| Keyword Data | Mock AI generation | Real search volume, CPC, difficulty | HIGH |
| Rank Tracking | Not supported | Track positions over time | HIGH |
| Site Audit | Mock analysis | Technical SEO issues | HIGH |
| Backlink Analysis | Not supported | Backlink profile, toxic links | HIGH |
| Competitor Research | Gap analysis (mock) | Real competitor keywords, traffic | HIGH |
| Content Optimization | Suggestions only | TF-IDF, semantic analysis | MEDIUM |
| Local SEO | Not supported | Google Business Profile | MEDIUM |
| Rank Widgets | Not supported | Google Search Console integration | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Keyword Research Tool**
   - Input seed keywords → get keyword suggestions
   - Show search volume (from API or estimates)
   - Difficulty score (1-100)
   - Search intent classification
   - CPC estimates
   - Related keywords, questions, comparisons

2. **Rank Tracker**
   - Add keywords to track
   - Record positions over time (manual entry initially)
   - Trend charts (up/down)
   - Domain overview dashboard
   - Export to CSV

3. **Site Auditor (Basic)**
   - Input URL → crawl page
   - Report: title, meta, H1, images, links, schema
   - Issues list with severity
   - Recommendations

4. **On-Page SEO Checker**
   - Input URL + target keyword
   - Analyze: title, content, headings, links, images
   - Score (0-100) with breakdown
   - Specific fixes

### P2 — Should Have
5. **Competitor Analysis**
   - Input competitor domain
   - Show: estimated traffic, top keywords, rankings
   - Gap analysis: keywords they rank for that you don't

6. **Backlink Overview**
   - Input domain → show backlink count
   - Top referring domains
   - Anchor text distribution

7. **SERP Features Tracker**
   - Track featured snippets, people also ask
   - Opportunities identification

### P3 — Nice to Have
8. **Content Optimizer** — AI content writing with SEO focus
9. **Local SEO** — Google Business Profile management
10. **API Integrations** — Google Search Console, Google Analytics

---

## Data Model

```typescript
interface TrackedKeyword {
  id: string;
  keyword: string;
  domain: string;
  location?: string;
  device?: 'desktop' | 'mobile';
  currentPosition?: number;
  previousPosition?: number;
  searchVolume?: number;
  difficulty?: number;
  cpc?: number;
  intent?: 'informational' | 'commercial' | 'transactional' | 'navigational';
  trackedSince: string;
  positionHistory: Array<{
    date: string;
    position: number;
  }>;
}

interface SeoAudit {
  id: string;
  url: string;
  score: number;
  issues: SeoIssue[];
  checkedAt: string;
}

interface SeoIssue {
  type: 'error' | 'warning' | 'info';
  category: 'title' | 'meta' | 'content' | 'images' | 'links' | 'schema' | 'performance';
  message: string;
  recommendation: string;
  element?: string;
}

interface CompetitorAnalysis {
  id: string;
  domain: string;
  estimatedTraffic: number;
  organicKeywords: number;
  paidKeywords: number;
  topKeywords: Array<{
    keyword: string;
    position: number;
    traffic: number;
  }>;
  gapKeywords: string[];
  checkedAt: string;
}

interface BacklinkProfile {
  domain: string;
  totalBacklinks: number;
  uniqueDomains: number;
  topReferrers: Array<{
    domain: string;
    backlinks: number;
  }>;
  anchorTextDistribution: Record<string, number>;
  checkedAt: string;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Keyword Suggestions** | Current: Generate mock. Improve: Real data + AI categorization | P1 |
| **Content Optimization** | AI suggests improvements for target keyword | P1 |
| **Audit Analysis** | AI explains issues and prioritizes fixes | P1 |
| **Competitor Insights** | AI analyzes competitor gaps and opportunities | P2 |
| **Title/Meta Generation** | Current: Generate. Improve: Test variations | P1 |

---

## UI/UX Recommendations

### Keyword Research
- Table with sortable columns
- Filter by difficulty, volume, intent
- Add to tracker button
- Export selected

### Rank Tracker Dashboard
- Overview cards: total keywords, avg position, traffic estimate
- Position distribution chart
- Table: keyword, position, change, volume
- Trend sparklines

### Site Audit
- Score gauge (0-100)
- Issues grouped by severity
- Expand each issue for details
- Fix button → open in editor

---

## Acceptance Criteria

- [ ] Keyword research returns data with volume, difficulty, intent
- [ ] Can add keywords to rank tracking
- [ ] Rank tracker shows position history chart
- [ ] Site auditor analyzes URL and reports issues
- [ ] On-page checker scores content for target keyword
- [ ] Competitor analysis shows gap keywords
- [ ] AI generates SEO recommendations
- [ ] Data persists to database
- [ ] Export functionality (CSV)
