# Brand Management — Requirements Document

## Current State

**What exists now:**
- `BrandPanel.tsx` with 5 tabs: Voice, Messaging, Audit, Naming, Taglines
- **Voice Tab**: Input brand values + target audience → AI generates voice guide (tone, language, personality)
- **Messaging Tab**: Input brand name + segments → AI generates messaging framework (positioning, value props, taglines)
- **Audit Tab**: Static checklist of 10 brand consistency items (checkbox UI, no persistence)
- **Naming Tab**: Input concept + industry → AI generates name suggestions
- **Taglines Tab**: Input brand + mission → AI generates tagline options

**What it actually does:**
- AI generates brand content → copy to clipboard
- Audit checklist is interactive but not saved
- No asset management, no guidelines enforcement, no real brand tracking

**Missing:**
- Brand asset library (logos, colors, fonts)
- Brand guidelines document management
- Compliance checking
- Version control for brand assets

---

## Gap Analysis

| Feature | Current | Bynder/Frontify | Gap |
|---------|---------|-----------------|-----|
| Asset Library | Not supported | Store logos, images, templates | HIGH |
| Brand Guidelines | Not supported | Document brand standards | MEDIUM |
| Asset Versioning | Not supported | Version history, rollback | MEDIUM |
| Compliance | Checklist only | Automated checking | HIGH |
| Distribution | Copy only | Share links, permissions | MEDIUM |
| Usage Tracking | Not supported | Where assets are used | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Brand Identity Setup**
   - Company name, logo upload, tagline
   - Color palette (primary, secondary, accent)
   - Typography (headings, body, accent)
   - Store in database

2. **Asset Library**
   - Upload logos (multiple formats/sizes)
   - Upload images, icons, templates
   - Organize by folder/category
   - Search and filter

3. **Brand Guidelines Document**
   - AI-generated from identity (current functionality)
   - Editable content
   - Version history

4. **Messaging Framework**
   - AI-generated (current functionality)
   - Save and edit
   - Tagline and value proposition library

### P2 — Should Have
5. **Asset Usage Tracking**
   - Track where assets are used
   - Identify outdated versions

6. **Brand Audit Dashboard**
   - Current: Static checklist
   - Improve: Track completion over time
   - Assign tasks to team members

7. **Naming Tool (Enhanced)**
   - Current: AI generation
   - Add: Save favorites, check domain availability (mock)

### P3 — Nice to Have
8. **Approval Workflows** — Request/approve brand changes
9. **Distribution Portal** — Share assets with external parties
10. **Compliance Alerts** — Warn on inconsistent usage

---

## Data Model

```typescript
interface BrandIdentity {
  id: string;
  companyName: string;
  tagline?: string;
  
  // Visual Identity
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background?: string;
    text?: string;
  };
  fonts: {
    headings: string;
    body: string;
    accent?: string;
  };
  logoUrl?: string;
  logoDarkUrl?: string;
  
  // Voice & Tone
  voiceDescription?: string;
  toneGuidelines?: string;
  doAndDonts?: string;
  
  updatedDate: string;
}

interface BrandAsset {
  id: string;
  name: string;
  type: 'logo' | 'image' | 'icon' | 'template' | 'document' | 'video';
  category?: string;
  url: string;
  thumbnailUrl?: string;
  version: number;
  previousVersions?: string[];
  
  // Metadata
  uploadedBy?: string;
  uploadedDate: string;
  fileSize?: number;
  dimensions?: { width: number; height: number };
  
  // Usage
  usedIn?: string[]; // Content IDs, campaign IDs
}

interface MessagingFramework {
  id: string;
  brandId: string;
  name: string; // e.g., "Primary Messaging", "Enterprise Segment"
  
  positioning?: string;
  valueProps?: string[];
  keyMessages?: string[];
  taglines?: string[];
  
  audienceSegments?: string[];
  
  createdDate: string;
  updatedDate: string;
}

interface BrandAudit {
  id: string;
  name: string;
  items: AuditItem[];
  completedCount: number;
  totalCount: number;
  assignees?: string[];
  dueDate?: string;
  status: 'pending' | 'in_progress' | 'completed';
}

interface AuditItem {
  id: string;
  category: string;
  description: string;
  checked: boolean;
  notes?: string;
  completedBy?: string;
  completedDate?: string;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Voice Guide Generation** | Current: Generate. Add: Edit and version | P1 |
| **Messaging Framework** | Current: Generate. Add: Segment-specific variants | P1 |
| **Naming Suggestions** | Current: Generate. Add: Domain check, trademark search (mock) | P1 |
| **Tagline Testing** | AI evaluates taglines for fit | P2 |
| **Asset Suggestions** | AI recommends images based on content | P2 |

---

## UI/UX Recommendations

### Brand Dashboard
- Header: Company name, logo preview
- Quick actions: Edit Identity, View Guidelines, Upload Asset

### Asset Library
- Grid/list view toggle
- Drag-and-drop upload
- Filter by type, category
- Preview modal with details

### Guidelines Document
- Sectioned document view
- Edit inline
- Preview as end-user

---

## Acceptance Criteria

- [ ] Can define brand identity (name, colors, fonts, logo)
- [ ] Can upload and manage brand assets
- [ ] Can generate and edit voice/messaging guides
- [ ] Can generate taglines and save favorites
- [ ] Brand audit checklist tracks completion
- [ ] AI generates brand content
- [ ] Data persists to database
- [ ] Mobile-responsive asset library view
