# Campaign Management — Requirements Document

## Current State

**What exists now:**
- `renderCampaigns()` in MaxTargetApp.tsx (lines ~210-260)
- Create campaign via `prompt()` dialogs — no form
- Display campaign cards with: name, type, status, budget, spent, conversions, ROAS
- Edit status via `prompt()` — validates against ['draft', 'active', 'paused', 'completed']
- Data stored in `/api/apps/maxtarget/campaigns` with basic CRUD
- Persisted to `data/apps/maxtarget/campaigns.json`

**What it actually does:**
- Lists campaigns from API
- Allows creating new campaigns with default values (budget: 5000, type: 'email')
- Allows changing status only
- No budget editing, no metrics tracking, no channel management
- No campaign performance visualization

**Code snippet:**
```tsx
const formData: Omit<Campaign, 'id' | 'createdDate'> = {
  name,
  type: 'email',
  status: 'draft',
  budget: 5000,
  spent: 0,
  startDate: new Date().toISOString().split('T')[0],
  endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  targetAudience: '',
  channels: [],
  metrics: { impressions: 0, clicks: 0, conversions: 0 },
};
```

---

## Gap Analysis

| Feature | Current | HubSpot/Google Ads | Gap |
|---------|---------|-------------------|-----|
| Campaign Creation | prompt() with defaults | Full form with channels, budget, audience | HIGH |
| Budget Management | Display only | Track spend, set alerts, optimize | HIGH |
| Multi-channel | Not supported | Coordinate email, social, ads, display | HIGH |
| Performance Metrics | Basic display | Real-time CTR, CPA, ROAS, attribution | HIGH |
| Campaign Types | Enum only | Advanced targeting, lookalikes, retargeting | MEDIUM |
| Scheduling | Start/end dates only | Dayparting, frequency capping | MEDIUM |
| A/B Testing | Not supported | Variant testing with statistical significance | MEDIUM |
| Attribution | Not tracked | Multi-touch attribution models | HIGH |
| Creative Management | Not supported | Ad creative library, versioning | MEDIUM |
| Reporting | Basic card view | Custom reports, dashboards, exports | HIGH |

---

## Requirements

### P1 — Must Have
1. **Campaign CRUD Form** — Replace prompt() with proper form modal
   - Name, type, status, budget, start/end dates
   - Target audience selection (link to Audiences)
   - Channel selection (email, social, search, display, programmatic)
   
2. **Budget Tracking** — Real-time spend vs budget
   - Input actual spend manually or via API
   - Budget alerts at 75%, 90%, 100%
   - Projected spend based on daily burn rate
   
3. **Metrics Dashboard** — Per-campaign analytics
   - Impressions, clicks, conversions
   - Calculated: CTR, CPC, CPA, ROAS
   - Trend indicators (up/down vs previous period)

4. **Campaign Status Workflow**
   - Draft → Active → Paused → Completed
   - Archive option for old campaigns

### P2 — Should Have
5. **Multi-channel Coordination**
   - Link sub-campaigns (email sequence, social posts, ads)
   - Unified metrics across channels
   
6. **Campaign Templates**
   - Pre-built campaign structures by goal
   - Clone existing campaigns

7. **Scheduling Enhancements**
   - Set specific days/times for campaign activities
   - Recurring campaigns

### P3 — Nice to Have
8. **A/B Testing** — Create variants, track winner
9. **Attribution** — First-touch, last-touch, linear models
10. **Creative Library** — Store and manage ad creatives

---

## Data Model

```typescript
interface Campaign {
  id: string;
  name: string;
  description?: string;
  type: 'email' | 'display' | 'social' | 'search' | 'programmatic' | 'ABM' | 'content' | 'event';
  status: 'draft' | 'active' | 'paused' | 'completed' | 'archived';
  
  // Budget & Finance
  budget: number;
  spent: number;
  currency: string;
  budgetAlertThreshold: number; // percentage
  
  // Scheduling
  startDate: string;
  endDate: string;
  timezone: string;
  dayparting?: {
    [day: string]: { start: string; end: string }[];
  };
  
  // Targeting
  targetAudience?: string; // links to Audience ID
  targetChannels: string[];
  geography?: string[];
  industry?: string[];
  
  // Metrics (updated periodically)
  metrics: {
    impressions: number;
    clicks: number;
    conversions: number;
    revenue?: number;
    // Calculated
    ctr?: number;
    cpc?: number;
    cpa?: number;
    roas?: number;
  };
  
  // Relationships
  ownerId?: string;
  createdBy?: string;
  createdDate: string;
  updatedDate: string;
  
  // Sub-campaigns
  childCampaigns?: string[];
  
  // Notes
  notes?: string;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Campaign Optimization** | AI suggests budget reallocation, audience adjustments based on performance | P1 |
| **Content Recommendations** | AI recommends content types that perform well for similar campaigns | P2 |
| **Audience Insights** | AI analyzes target audience and suggests refinements | P2 |
| **Performance Predictions** | AI predicts campaign outcomes based on historical data | P2 |
| **Budget Suggestions** | AI recommends optimal budget split across channels | P2 |

---

## UI/UX Recommendations

### Campaign List View
- Card grid or table toggle
- Status badges (color-coded)
- Quick metrics (conversions, ROAS)
- Actions: Edit, Pause/Resume, Clone, Archive

### Campaign Detail/Edit Modal
- Tabbed interface: Overview, Budget, Targeting, Metrics, Settings
- Real-time budget progress bar
- Channel configuration with toggle switches

### Analytics Widget
- Sparkline trends for each metric
- Comparison to previous period
- Export to CSV/PDF

---

## Acceptance Criteria

- [ ] Can create campaign with full form (name, type, budget, dates, channels, audience)
- [ ] Can edit all campaign fields
- [ ] Budget shows spent vs total with visual indicator
- [ ] Metrics display calculated values (CTR, CPA, ROAS)
- [ ] Can change campaign status with proper workflow
- [ ] Campaigns persist to database
- [ ] AI provides optimization suggestions (at least one)
- [ ] Mobile-responsive campaign list
