# Ad Campaign Management — Requirements Document

## Current State

**What exists now:**
- `AdPanel.tsx` with 6 tabs: Copy, Google, Facebook, LinkedIn, Landing, UTM
- **Copy Tab**: Generate ad copy (product, audience, platform) → returns variants
- **Google Tab**: Generate Google Ads (product, keywords) → returns headlines, descriptions
- **Facebook/LinkedIn**: Static placeholder text (no functionality)
- **Landing Tab**: Generate landing page copy from headline + description
- **UTM Tab**: Generate UTM URLs from campaign/source/medium inputs

**What it actually does:**
- AI generates ad copy variants
- Copy to clipboard functionality
- No ad platform integration (Google Ads, Facebook Ads, LinkedIn Ads)
- No campaign management, no budget tracking, no performance data

**Missing:**
- Real ad platform API connections
- Campaign creation/management within platforms
- Budget management
- Performance tracking
- Creative management

---

## Gap Analysis

| Feature | Current | Google Ads | Gap |
|---------|---------|------------|-----|
| Platform Connection | Not supported | OAuth integration | HIGH |
| Campaign Management | Not supported | Full CRUD | HIGH |
| Ad Creation | AI copy only | Visual ad builder | HIGH |
| Budget Control | Not supported | Budget rules, pacing | HIGH |
| Performance Data | Not supported | Impressions, clicks, conversions | HIGH |
| Keyword Management | Not supported | Keyword planner, match types | HIGH |
| Audience Targeting | Not supported | Custom audiences, lookalikes | MEDIUM |
| A/B Testing | Not supported | Ad variants, experiments | HIGH |
| Reporting | Not supported | Performance dashboards | HIGH |

---

## Requirements

### P1 — Must Have
1. **Ad Copy Generator (Enhanced)**
   - Current functionality + save to library
   - A/B variant creation
   - Character limit validation per platform
   - CTA suggestions

2. **Campaign Management**
   - Create campaigns per platform
   - Set budgets, dates, bidding strategy
   - Define target audiences
   - Status management (draft, active, paused)

3. **UTM Builder**
   - Current functionality + save templates
   - Parameter validation
   - Link to campaign tracking

4. **Creative Library**
   - Store ad copy variants
   - Organize by campaign, platform
   - Version history

### P2 — Should Have
5. **Platform Integration (Mock)**
   - Simulate campaign sync
   - Mock performance data import

6. **Keyword Tools**
   - Keyword suggestions for search ads
   - Match type selection
   - Negative keywords

7. **Audience Builder**
   - Create custom audiences
   - Define targeting rules
   - Save audience segments

### P3 — Nice to Have
8. **Real API Integration** — Google Ads, LinkedIn Ads, Facebook Ads
9. **Bidding Strategies** — Manual, automated, target CPA/ROAS
10. **Automated Rules** — Pause at budget, scale at performance

---

## Data Model

```typescript
interface AdCampaign {
  id: string;
  platform: 'google' | 'facebook' | 'linkedin' | 'instagram';
  name: string;
  status: 'draft' | 'active' | 'paused' | 'completed';
  
  // Budget
  budget: number;
  budgetType: 'daily' | 'total';
  biddingStrategy: 'manual' | 'max_clicks' | 'max_conversions' | 'target_cpa' | 'target_roas';
  
  // Targeting
  audienceId?: string;
  geography?: string[];
  demographics?: {
    age?: [number, number];
    gender?: 'male' | 'female' | 'all';
  };
  
  // Dates
  startDate?: string;
  endDate?: string;
  
  // Metrics (updated from platform)
  metrics: {
    impressions: number;
    clicks: number;
    conversions: number;
    spend: number;
    ctr: number;
    cpc: number;
    cpa: number;
  };
  
  createdDate: string;
  updatedDate: string;
}

interface AdCreative {
  id: string;
  campaignId: string;
  platform: string;
  type: 'text' | 'image' | 'video' | 'carousel';
  name: string;
  
  // Content varies by type
  headlines?: string[];
  descriptions?: string[];
  primaryText?: string;
  cta?: string;
  mediaUrl?: string;
  
  status: 'draft' | 'active' | 'paused';
  metrics?: {
    impressions: number;
    clicks: number;
    conversions: number;
  };
  
  createdDate: string;
}

interface AdAudience {
  id: string;
  name: string;
  platform: string;
  rules: TargetingRule[];
  estimatedReach?: number;
  createdDate: string;
}

interface TargetingRule {
  field: string;
  operator: 'equals' | 'contains' | 'in' | 'not_in' | 'greater_than' | 'less_than';
  value: any;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Ad Copy Generation** | Current: Generate variants. Add: Best practices per platform | P1 |
| **Keyword Suggestions** | AI recommends keywords for search campaigns | P1 |
| **Audience Insights** | AI analyzes and suggests audience refinements | P2 |
| **Budget Optimization** | AI suggests budget reallocation based on performance | P2 |
| **Creative Testing** | AI recommends which variants to test | P2 |

---

## UI/UX Recommendations

### Campaign List
- Table with platform icons
- Status badges, budget progress bars
- Quick actions: Edit, Pause, Duplicate

### Ad Builder
- Step wizard: Campaign → Ad Group → Creatives
- Live preview per platform
- Character count warnings

### Performance Dashboard
- Platform tabs
- KPI cards: Spend, Impressions, Clicks, Conversions, CPA
- Trend charts
- Top performing ads table

---

## Acceptance Criteria

- [ ] Can create ad campaigns per platform
- [ ] Can set budget and bidding strategy
- [ ] Can create ad creatives with copy variants
- [ ] UTM builder generates valid URLs
- [ ] Creative library stores and retrieves ads
- [ ] AI generates platform-optimized ad copy
- [ ] Campaign performance displays (mock data OK)
- [ ] Data persists to database
