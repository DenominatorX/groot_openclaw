# Email Marketing — Requirements Document

## Current State

**What exists now:**
- `EmailPanel.tsx` with 6 tabs: Subjects, Template, A/B Tests, Cold Email, Newsletter, Spam Check
- AI generation for subject lines, cold email sequences, newsletters
- Spam score checker (mock analysis)
- Template editor with placeholder variables
- No email sending, no list management, no campaign integration

**What it actually does:**
- Generate subject lines via AI → copy to clipboard
- Generate cold email sequences → copy to clipboard
- Generate newsletters → copy to clipboard
- Check spam score (mock) → display report
- Create basic templates with variables

**Missing:**
- No email service integration (SendGrid, Mailgun, etc.)
- No contact lists
- No email sending
- No open/click tracking
- No automation execution
- No template library

---

## Gap Analysis

| Feature | Current | Mailchimp/Breed | Gap |
|---------|---------|-----------------|-----|
| Contact Management | Not supported | Full CRM with segments, tags | HIGH |
| Email Sending | Not supported | Transactional + bulk | HIGH |
| Templates | Basic editor | Visual builder, responsive | MEDIUM |
| Automation | Not executed | Trigger-based sequences | HIGH |
| Analytics | None | Opens, clicks, bounces, unsubscribes | HIGH |
| A/B Testing | "Coming Soon" placeholder | Subject, content, send time | HIGH |
| Personalization | Variable placeholders | Dynamic content, conditional | MEDIUM |
| List Hygiene | Not supported | Bounce handling, suppressions | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Contact List Management**
   - Create/edit/delete contact lists
   - Import contacts (CSV, manual entry)
   - Contact fields: name, email, company, phone, tags, source
   - Segment by tags, company size, industry

2. **Template System**
   - Rich text editor for email body
   - Variable substitution: {{first_name}}, {{company}}, etc.
   - Save templates to library
   - Preview with sample data

3. **Email Campaigns**
   - Select list, select template, configure subject
   - Schedule send (or send now)
   - Track sends, opens, clicks (mock initially)

4. **Basic Automation Triggers**
   - Trigger: Contact added to list
   - Action: Send welcome email
   - Wait: X days between steps

### P2 — Should Have
5. **Advanced Automation**
   - Multiple trigger types (form submit, page visit, score threshold)
   - Conditional branching (if opened, if clicked)
   - Action: Add tag, remove tag, update score

6. **A/B Testing**
   - Test subject lines
   - Test send times
   - Statistical significance indicator

7. **Analytics Dashboard**
   - Open rate, click rate, bounce rate
   - Per-campaign breakdown
   - Trend charts

### P3 — Nice to Have
8. **Real Email Sending** — Integration with SendGrid/Mailgun
9. **Behavioral Triggers** — Page visits, link clicks
10. **Personalization Engine** — Dynamic content blocks

---

## Data Model

```typescript
interface ContactList {
  id: string;
  name: string;
  description?: string;
  contactCount: number;
  tags: string[];
  createdDate: string;
  updatedDate: string;
}

interface Contact {
  id: string;
  listId: string;
  email: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  phone?: string;
  source: string;
  tags: string[];
  customFields: Record<string, string>;
  createdDate: string;
  updatedDate: string;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  preheader?: string;
  body: string; // HTML
  variables: string[]; // ['first_name', 'company']
  category: 'welcome' | 'promotional' | 'newsletter' | 'transactional' | 'custom';
  createdDate: string;
  updatedDate: string;
}

interface EmailCampaign {
  id: string;
  name: string;
  listId: string;
  templateId: string;
  subject: string;
  status: 'draft' | 'scheduled' | 'sending' | 'sent' | 'cancelled';
  scheduledAt?: string;
  sentAt?: string;
  metrics: {
    sent: number;
    delivered: number;
    opens: number;
    clicks: number;
    bounces: number;
    unsubscribes: number;
  };
  createdDate: string;
}

interface EmailAutomation {
  id: string;
  name: string;
  trigger: {
    type: 'contact_added' | 'contact_tagged' | 'form_submit' | 'score_threshold' | 'manual';
    config: Record<string, any>;
  };
  steps: Array<{
    order: number;
    type: 'email' | 'wait' | 'condition' | 'action';
    config: Record<string, any>;
  }>;
  status: 'draft' | 'active' | 'paused';
  enrolledCount: number;
  createdDate: string;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Subject Line Generation** | Current: Generate options. Improve: A/B test recommendations | P1 |
| **Content Optimization** | AI suggests improvements for opens/clicks | P1 |
| **Send Time Optimization** | AI predicts optimal send time per contact | P2 |
| **Personalization** | AI generates dynamic content based on contact data | P2 |
| **Subject Line Scoring** | AI predicts spam score and open likelihood | P1 |

---

## UI/UX Recommendations

### Contact Management
- Table view with search/filter
- Bulk actions (tag, delete, export)
- Quick add contact modal

### Template Editor
- Split-pane: Editor | Preview
- Variable insertion toolbar
- Desktop/mobile preview toggle

### Campaign Builder
- Step wizard: List → Template → Subject → Schedule → Send
- Preview with sample contact
- Validation before send

### Automation Builder
- Visual flow editor (see AutomationPanel)
- Drag-and-drop step addition

---

## Acceptance Criteria

- [ ] Can create and manage contact lists
- [ ] Can add/edit/delete contacts with fields
- [ ] Can create email templates with variables
- [ ] Can build and "send" email campaign (mock)
- [ ] Can view campaign metrics (sent, opens, clicks)
- [ ] Can create basic automation (trigger → email)
- [ ] AI generates subject lines and content
- [ ] Templates persist to database
- [ ] Mobile-responsive views
