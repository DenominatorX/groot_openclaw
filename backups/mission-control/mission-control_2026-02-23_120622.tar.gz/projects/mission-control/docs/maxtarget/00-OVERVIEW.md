# MaxTarget Marketing Dashboard — Requirements Overview

**Project:** MaxTarget Marketing Dashboard Overhaul  
**Status:** Planning  
**Priority:** High  
**Brand Context:** MaxTarget = "SpecTarget on steroids" — Andy Walton's B2B programmatic marketing company

---

## Executive Summary

MaxTarget is currently a **lightweight marketing dashboard** with placeholder UI and minimal CRUD operations. The app includes 17 tabs with various marketing-related functionality, but most panels are **AI generation wrappers** with no real data persistence or workflow management.

**Current State Assessment:**
- 10 functional panels (SEOPanel, SocialPanel, EmailPanel, AdPanel, ResearchPanel, ReportingPanel, BrandPanel, ConversionPanel, ABMPanel, AutomationPanel)
- 7 core tabs in main app (Pipeline, Campaigns, Audiences, Content, Analytics, Competitors, Sequences)
- Basic API routes exist but data persistence is minimal (leads.json = `[]`)
- Most "functionality" is AI text generation with copy-to-clipboard
- No real campaign management, no email sending, no ad platform integration, no automation execution

**Vision:** Transform MaxTarget into an **enterprise-grade marketing suite** with real CRUD operations, data models, AI-powered insights, and actionable workflows comparable to HubSpot, Mailchimp, Semrush, Hootsuite, and Google Ads.

---

## Current Architecture

```
MaxTargetApp.tsx (Main Container)
├── Core Tabs (built into app)
│   ├── Pipeline (Lead Management)
│   ├── Campaigns
│   ├── Audiences (ICPs)
│   ├── Content
│   ├── Analytics
│   ├── Competitors
│   └── Sequences (Email Automation)
└── Module Panels (separate components)
    ├── SEOPanel
    ├── SocialPanel
    ├── EmailPanel
    ├── AdPanel
    ├── ResearchPanel
    ├── ReportingPanel
    ├── BrandPanel
    ├── ConversionPanel
    ├── ABMPanel
    └── AutomationPanel
```

### Data Files (data/apps/maxtarget/)
- `leads.json` — Empty array
- `campaigns.json` — Basic campaign list
- `audiences.json` — ICP definitions
- `content.json` — Content pieces
- `competitors.json` — Competitive intelligence

### API Routes (app/api/apps/maxtarget/)
- `/leads` — Lead CRUD
- `/campaigns` — Campaign CRUD
- `/audiences` — Audience CRUD
- `/content` — Content CRUD
- `/competitors` — Competitor CRUD
- `/sequences` — Email sequence CRUD
- `/analytics` — Aggregated metrics
- `/seo`, `/social`, `/email`, `/ads`, `/research`, `/reporting`, `/brand`, `/conversion`, `/abm`, `/automation` — AI generation endpoints

---

## Gap Analysis Summary

| Module | Current State | Gap vs Real Tools |
|--------|---------------|-------------------|
| **Campaigns** | Create via prompt(), status edit only | No budget tracking, no performance metrics, no multi-channel coordination |
| **Email** | AI subject line generation + copy | No email sending, no list management, no templates library, no automation execution |
| **Social** | AI post generation + copy | No posting, no scheduling, no engagement tracking, no multi-platform management |
| **SEO** | AI keyword/content generation | No real排名 tracking, no site crawling, no position monitoring |
| **Ads** | AI ad copy generation | No ad platform integration, no budget management, no performance tracking |
| **ABM** | AI account research + outreach plans | No account tracking, no engagement scoring, no campaign execution |
| **Automation** | Visual flow builder (UI only) | No execution engine, no trigger handling, no real-time运营 |
| **Analytics** | Basic summary cards | No real data, no charts, no custom reports |
| **Leads/Pipeline** | Basic CRUD with prompts | No scoring algorithm, no enrichment, no workflow |
| **Content** | Create with type selection | No versioning, no approval workflow, no distribution |

---

## Requirements by Priority

### P1 — Must Have (MVP)
1. **Campaign Management** — Full CRUD with budget, channels, metrics
2. **Lead Pipeline** — Scoring, stages, enrichment, source tracking
3. **Email Marketing** — List management, templates, sending (mock), automation triggers
4. **Analytics Dashboard** — Real KPI tracking, charts, custom reports

### P2 — Should Have (Growth)
5. **Social Media Management** — Post scheduling, multi-platform, engagement metrics
6. **SEO Tools** — Keyword tracking, site analysis, position monitoring
7. **ABM Platform** — Account intelligence, engagement scoring, campaign coordination
8. **Marketing Automation** — Flow builder with execution, triggers, actions

### P3 — Nice to Have (Enterprise)
9. **Ad Platform Integration** — Google Ads, LinkedIn Ads, Facebook Ads APIs
10. **Brand Management** — Asset library, guidelines enforcement
11. **Conversion Optimization** — A/B testing, form optimization, heatmaps
12. **Reporting** — Client reports, proposals, invoices

---

## Data Models Required

### Lead
```
- id, companyName, contactName, email, phone
- source, score, stage, notes
- createdDate, lastTouched
- engagementHistory[], activities[]
```

### Campaign
```
- id, name, type, status, budget, spent
- startDate, endDate, targetAudience
- channels[], metrics {impressions, clicks, conversions, ctr, cpa, roas}
- createdDate, ownerId
```

### Audience (ICP)
```
- id, name, industry, companySize
- jobTitles[], geography[], revenueRange
- techStack[], intentSignals[], painPoints[]
- createdDate
```

### Content
```
- id, title, type, status, body
- targetAudience, campaignLink
- seoMetadata, createdDate, publishedDate
```

### Automation Flow
```
- id, name, trigger, steps[]
- status (draft/active/paused)
- createdDate, lastRun
```

---

## AI Integration Points

| Module | Current | Required |
|--------|---------|----------|
| **Campaigns** | None | AI campaign optimization suggestions, budget recommendations |
| **Leads** | Score manual entry | AI lead scoring, enrichment, intent prediction |
| **Email** | Subject line generation | AI template optimization, send time optimization, content personalization |
| **Social** | Post generation | AI content calendar, engagement prediction, trending topics |
| **SEO** | Keyword suggestions | AI content optimization, competitor analysis, trend prediction |
| **ABM** | Company research | AI account insights, outreach personalization, engagement预测 |
| **Automation** | Flow descriptions | AI flow builder, condition suggestions, optimization |

---

## UI/UX Recommendations

### Brand Colors
- Primary: Red (#DC143C)
- Background: Dark gray (#1a1a1a / #2d2d2d)
- Text: White (#ffffff) / Gray (#a0a0a0)

### Component Patterns
- Card-based layouts for entities
- Data tables with sorting/filtering
- Modal forms for CRUD operations
- Sidebar for quick actions
- Dashboard widgets for analytics

### Responsive Design
- Mobile: Single column, stacked cards
- Tablet: 2-column grids
- Desktop: Full dashboard with sidebar

---

## Phase Plan

### Phase 1: Foundation (Weeks 1-2)
- Data model implementation
- Core CRUD for Campaigns, Leads, Audiences
- Basic Analytics dashboard

### Phase 2: Marketing Suite (Weeks 3-4)
- Email marketing module with automation
- Social media scheduling
- SEO tools with tracking

### Phase 3: Advanced Features (Weeks 5-6)
- ABM platform
- Marketing automation engine
- Advanced reporting

### Phase 4: Enterprise (Weeks 7-8)
- Ad platform integrations
- Brand management
- Advanced conversion optimization

---

## Acceptance Criteria

- [ ] All P1 modules have full CRUD with data persistence
- [ ] Analytics shows real data from campaigns/leads
- [ ] Email module can create, store, and "send" emails (mock)
- [ ] Pipeline shows lead progression with scoring
- [ ] At least one AI integration per major module
- [ ] UI follows brand guidelines (red/white/black theme)
- [ ] Mobile-responsive layouts
