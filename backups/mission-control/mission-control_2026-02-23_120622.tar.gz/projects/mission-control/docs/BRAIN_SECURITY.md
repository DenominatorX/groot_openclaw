# Brain Orchestration Security - Phase 3 Implementation

## Overview
Implemented comprehensive security features for the Brain orchestration system to address:
1. Context Leakage
2. Meeting Transcript Storage Security
3. Delegation Chain Exploitation
4. Consensus Manipulation

---

## Files Created/Modified

### 1. `/lib/brain-security.ts` (NEW)
**Purpose:** Core security module implementing all 4 security features

#### Features Implemented:

**A. Role-Based Context Filtering**
- `filterContextByRole()` - Filters sensitive data based on agent tier
- `filterAgentData()` - Removes sensitive fields before sharing between agents
- Automatic redaction of:
  - Personal info (SSN, credit cards, emails, phones)
  - Financial data (salary, compensation, portfolio)
  - Business confidential (strategy, IP, client lists)
  - Private/Kevin-specific data

**B. Encrypted Meeting Storage**
- `encryptMeetingData()` - AES-256-GCM encryption
- `decryptMeetingData()` - Decryption with auth tag verification
- `createSecureMeeting()` - Creates encrypted meeting records
- `getDecryptedTranscript()` - Access-controlled decryption
- Classification levels: PUBLIC, INTERNAL, CONFIDENTIAL, RESTRICTED

**C. Capability-Based Delegation Limits**
- `TIER_DELEGATION_LIMITS` - Per-tier delegation rules:
  - Tier 0 (Owner): Unlimited depth, no approval needed
  - Tier 1 (Executive): 4 depth levels
  - Tier 2 (VP): 3 depth levels
  - Tier 3-4: Limited capabilities blocked
  - Tier 5-6: Severe restrictions
- `checkDelegationAllowed()` - Validates delegation permissions
- `validateDelegationChain()` - Prevents circular/excessive chains
- Blocked capabilities: security, admin, financial, owner

**D. Consensus Verification & Randomization**
- `verifyConsensus()` - Detects manipulation patterns
  - Single-agent dominance detection
  - Suspicious voting patterns
  - Tier-weighted manipulation checks
- `applyConsensusRandomization()` - Fisher-Yates shuffle
- `calculateWeightedConsensus()` - Inverse-tier weighted voting
- `generateVerifiedConsensus()` - Full verification with hash

**E. Audit Logging**
- `logBrainAction()` - Tracks all security-relevant actions
- Tracks: delegation, meetings, consensus, filtering, encryption

---

### 2. `/app/api/brain/orchestrate/route.ts` (MODIFIED)
**Purpose:** Updated Brain orchestration API to use security features

#### Changes:
- Integrated context filtering before passing to agents
- Applied delegation limit checks
- Added meeting encryption
- Added consensus randomization and verification
- Added security response headers in results

---

### 3. `/app/api/brain/meetings/route.ts` (NEW)
**Purpose:** Secure meeting retrieval with access control

#### Endpoints:
- `GET /api/brain/meetings` - List meetings with access control
- `GET /api/brain/meetings?id=X` - Get specific meeting (decrypted if authorized)
- `DELETE /api/brain/meetings?id=X` - Delete meeting (owner only)

#### Access Control:
- Meetings include `minTierToView` field
- Transcripts decrypted only if requester tier >= minTierToView
- Action items hidden for unauthorized access

---

## Security Summary

| Feature | Implementation |
|---------|---------------|
| Context Leakage | Agent tier-based filtering, sensitive pattern redaction |
| Meeting Storage | AES-256-GCM encryption, classification-based access |
| Delegation Exploitation | Tier-based limits, chain validation, capability blocking |
| Consensus Manipulation | Randomization, manipulation detection, tier-weighted voting |

---

## Configuration

The security module uses:
- Encryption key derived from settings hash (production should use env var `BRAIN_ENCRYPTION_KEY`)
- Agent tiers from existing system (0-6)
- Default limits for unspecified tiers

---

## Usage Examples

### Filtering Context
```typescript
const result = filterContextByRole(context, agentRole);
// Returns: { filtered, hadSensitive, redactedItems }
```

### Encrypted Meeting
```typescript
const meeting = createSecureMeeting({
  id: 'mtg-1',
  topic: 'Budget Review',
  agents: [...],
  transcript: '...',
  actionItems: [],
  createdAt: new Date().toISOString(),
}, 'CONFIDENTIAL');
// Automatically sets minTierToView based on classification
```

### Delegation Check
```typescript
const check = checkDelegationAllowed(sourceRole, targetRole, 'coding');
// Returns: { allowed, reason?, requiresApproval? }
```

### Consensus Verification
```typescript
const result = generateVerifiedConsensus(votes, agentTiers, consensus, recommendation);
// Returns full verification with manipulation detection
```
