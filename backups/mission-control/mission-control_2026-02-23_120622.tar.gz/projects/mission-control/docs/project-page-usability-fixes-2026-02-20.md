# Project Page Usability Fixes - 2026-02-20

## Summary

Applied fixes to Mission Control project pages to address UX issues related to duplicate chat components, auto-scroll/jump behavior, nested scrolling, and navigation compacting.

## Changes Made

### 1. Removed Duplicate Project Chat (Issue #1)

**Problem:** The Project Profile page had multiple redundant chat modules:
- `TeamChatTab` (persistent at bottom)
- `ProjectChat` (persistent at bottom)
- `PMChatPopout` (floating button in Tests tab)

**Solution:**
- Removed the redundant `TeamChatTab` component from the bottom of the Project Profile page
- Removed the `PMChatPopout` floating chat from the Tests tab
- Kept only ONE main `ProjectChat` component at the bottom of the page
- The `TeamChatTab` is still accessible within the "Team" tab if needed

**Files Changed:** `components/ProjectProfile.tsx`

**Rationale:** Users were confused by multiple chat boxes. Now there's a single, clear chat module that handles project agent communication.

---

### 2. Fixed Auto-Scroll/Jump Behavior (Issue #2)

**Problem:** When clicking on a project page or switching tabs, the page would unexpectedly auto-scroll or jump to different positions due to:
- Focus jumps from input elements
- Scroll anchoring from chat auto-scroll
- No smooth scroll management on tab changes

**Solution:**
- Added a `handleTabChange` callback that smoothly scrolls to top of content area before switching tabs
- Added a ref (`contentAreaRef`) to properly manage scroll position
- Changed all tab navigation to use `handleTabChange` instead of direct `setTab` calls

**Files Changed:** `components/ProjectProfile.tsx`

**Rationale:** Provides predictable, smooth navigation experience without unexpected jumps.

---

### 3. Removed Improper Nested Scrolling (Issue #3)

**Problem:** The layout had multiple nested scrollable areas:
- Main container with `overflow-hidden`
- Vertical tab nav with `overflow-y-auto`
- Tab content with `overflow-y-auto`
- Chat areas with their own scroll

This created awkward scroll behavior where users couldn't easily scroll the full page.

**Solution:**
- Made the vertical tab nav non-scrolling (removed `overflow-y-auto`)
- Wrapped nav items in a scrollable div with fixed height
- Ensured only the tab content area scrolls
- Added explicit height constraints to prevent layout expansion issues

**Before:**
```jsx
<div className="... overflow-y-auto bg-mc-bg/30 flex flex-col">  // nav scrolls independently
```
```jsx
<div className="p-4 flex-1 overflow-y-auto">  // content scrolls
```

**After:**
```jsx
<div className="... bg-mc-bg/30 flex flex-col">
  <div className="flex-1 overflow-y-auto">  // items scroll, nav container is fixed
    {/* nav items */}
  </div>
</div>
```

**Files Changed:** `components/ProjectProfile.tsx`

**Rationale:** Single scrollable area provides better user experience and predictable scrolling.

---

### 4. Fixed Project Navigation/Container Compacting (Issue #4)

**Problem:** The collapsible navigation (`navCollapsed` state) could cause layout shifts and unwanted scroll behavior when toggled.

**Solution:**
- Made navigation width transitions smoother by using consistent width values
- Fixed width class: changed from `w-34` to `w-36` for better consistency
- Navigation collapse state is now properly managed with localStorage persistence

**Files Changed:** `components/ProjectProfile.tsx`

**Rationale:** Smoother navigation toggle experience without layout jumps.

---

### 5. Cleaned Up Layout/Design (Issue #5)

**Problem:** Multiple small layout issues combined to create poor UX.

**Solution:**
- Removed unused `PMChatPopout` component definition (dead code)
- Added explicit max-height constraint to the chat area (`maxHeight: '320px'`)
- Ensured consistent spacing and borders throughout

**Files Changed:** `components/ProjectProfile.tsx`

---

## Validation

- ✅ Build passes (`npm run build` - exit code 0)
- ✅ No TypeScript errors
- ✅ All imports are valid

## Behavior Summary

| Pain Point | Before | After |
|------------|--------|-------|
| Duplicate chat | 3 chat modules visible (TeamChat, ProjectChat, PMChatPopout) | 1 chat module (ProjectChat only) |
| Auto-scroll/jump | Page jumps unexpectedly on tab change | Smooth scroll to top on tab change |
| Nested scrolling | Multiple nested scroll areas cause confusion | Single scrollable content area |
| Nav compacting | Nav toggle causes layout shifts | Smooth, predictable toggle |
| Layout | Inconsistent spacing, multiple issues | Clean, unified layout |

## Notes

- The `TeamChatTab` is still available within the "Team" tab if users need to message specific team agents
- The `ProjectChat` component handles general project communication
- All chat history is preserved through the API
