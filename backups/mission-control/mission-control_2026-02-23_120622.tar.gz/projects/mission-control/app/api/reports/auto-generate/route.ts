import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { checkAuth } from '@/lib/api-auth';

const REPORTS_PATH = path.join(process.cwd(), 'data', 'reports.json');
const SETTINGS_PATH = path.join(process.cwd(), 'data', 'settings.json');
const HEALTH_PATH = path.join(process.cwd(), 'data', 'health');
const AGENT_USAGE_PATH = path.join(process.cwd(), 'data', 'agent-usage.json');
const ACTIVITY_PATH = path.join(process.cwd(), 'data', 'activity.json');
const PROJECTS_PATH = path.join(process.cwd(), 'data', 'projects.json');

function readJSON(p: string): any {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return {}; }
}

function writeJSON(p: string, data: any) {
  fs.writeFileSync(p, JSON.stringify(data, null, 2));
}

function readReports() {
  try { return JSON.parse(fs.readFileSync(REPORTS_PATH, 'utf8')); }
  catch { return { reports: [] }; }
}

function writeReports(data: any) {
  fs.writeFileSync(REPORTS_PATH, JSON.stringify(data, null, 2));
}

// ═══════════════════════════════════════════════════════════════
// DATA GATHERING FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function gatherHealthData() {
  const supplementsPath = path.join(HEALTH_PATH, 'supplements.json');
  const exercisePath = path.join(HEALTH_PATH, 'exercise.json');
  
  const supplements = readJSON(supplementsPath);
  const exercise = readJSON(exercisePath);
  
  return {
    protocol: supplements.protocol || 'Daily Supplement Stack',
    supplements: supplements.items || [],
    exercise: exercise,
    context: {
      conditions: [
        { name: 'AMPD1', mutation: 'c.133C>T', description: 'Adenosine monophosphate deaminase deficiency' },
        { name: 'AGK', mutation: 'c.445A>G + c.764C>T', description: 'Multiple mutations affecting protein function' },
      ],
      atp_deficit: true,
      special_notes: 'ATP production impaired; exercise must be carefully monitored to prevent rhabdomyolysis'
    }
  };
}

function gatherSystemData() {
  const usage = readJSON(AGENT_USAGE_PATH);
  const activity = readJSON(ACTIVITY_PATH);
  const projects = readJSON(PROJECTS_PATH);
  
  // System stats
  const memUsage = process.memoryUsage();
  const sysFreeMem = os.freemem();
  const sysTotalMem = os.totalmem();
  
  // Cost calculation
  let totalCost = 0;
  const costByAgent: Record<string, { count: number; cost: number }> = {};
  
  (usage.entries || []).forEach((e: any) => {
    if (!costByAgent[e.agentId]) {
      costByAgent[e.agentId] = { count: 0, cost: 0 };
    }
    costByAgent[e.agentId].count += 1;
    costByAgent[e.agentId].cost += e.cost || 0;
    totalCost += e.cost || 0;
  });
  
  return {
    timestamp: new Date().toISOString(),
    system: {
      platform: os.platform(),
      arch: os.arch(),
      cpus: os.cpus().length,
      totalMemory: `${(sysTotalMem / 1024 / 1024 / 1024).toFixed(1)} GB`,
      freeMemory: `${(sysFreeMem / 1024 / 1024 / 1024).toFixed(1)} GB`,
      nodeMemory: `${(memUsage.heapUsed / 1024 / 1024).toFixed(1)} MB / ${(memUsage.heapTotal / 1024 / 1024).toFixed(1)} MB`,
    },
    ports: {
      port_3001: 'Mission Control API',
      port_3002: 'Secondary Service',
      port_18800: 'Cloudflare Tunnel',
    },
    agents: {
      active_tasks: (activity.entries || []).filter((e: any) => {
        const ts = new Date(e.timestamp);
        const now = new Date();
        return (now.getTime() - ts.getTime()) < 3600000; // Last hour
      }).length,
      total_entries: (activity.entries || []).length,
    },
    costs: {
      total: totalCost,
      byAgent: costByAgent,
      entryCount: (usage.entries || []).length,
    },
    projects: {
      total: (projects.projects || []).length,
      byStatus: {
        'in-progress': (projects.projects || []).filter((p: any) => p.status === 'in-progress').length,
        'complete': (projects.projects || []).filter((p: any) => p.status === 'complete' || p.status === 'completed').length,
        'on-hold': (projects.projects || []).filter((p: any) => p.status === 'on-hold').length,
      },
    },
  };
}

// ═══════════════════════════════════════════════════════════════
// HEALTH REPORT GENERATORS
// ═══════════════════════════════════════════════════════════════

async function generateHealthReport(type: string, apiKey: string): Promise<string> {
  const data = gatherHealthData();
  
  const prompts: Record<string, string> = {
    'daily-health-summary': `Generate a daily health summary for Kevin Lane based on this data. Include: Supplement adherence status, Exercise readiness assessment (considering AMPD1 + AGK), Current ATP status, Recommendations for today. Keep it concise and actionable.`,
    'weekly-health-trends': `Generate a weekly health trends analysis for Kevin Lane. Analyze: Supplement compliance patterns, Exercise patterns and safety, Energy levels trends (inferred from ATP production), Recovery metrics. Suggest optimizations.`,
    'supplement-compliance': `Generate a supplement compliance report for Kevin Lane. Calculate: Total items, adherence percentage (0% shown), Timing patterns, Efficacy analysis (especially for AMPD1/AGK support), Missing doses analysis.`,
    'mayo-clinic-prep': `Generate a Mayo Clinic appointment preparation report for Kevin Lane. Context: Feb 17, 2026 appointment in Jacksonville FL for AMPD1 + AGK genetic defects. Include: Current supplement regimen, Exercise limitations, Key symptoms/concerns to discuss, Questions for doctors, Medical records needed, Travel preparation.`,
    'exercise-safety': `Generate an exercise safety report for Kevin Lane. Safe limits: 20-30min @ 40-60% VO2max, 48h recovery required. Analyze: Current exercise log, Safety compliance, Risk assessment, Recommendations, Red flags to watch.`,
    'genetic-condition-overview': `Generate a genetic condition overview for Kevin Lane. Summarize: AMPD1 c.133C>T (adenosine monophosphate deaminase deficiency), AGK c.445A>G + c.764C>T (protein function mutations), ATP production deficit, Metabolic implications, Lifestyle adjustments needed.`,
    'nutrition-analysis': `Generate a nutrition analysis for Kevin Lane based on current supplements. Include: ATP production support (D-Ribose, L-Carnitine, CoQ10, Creatine), Mitochondrial health, Energy sustainability, Diet pattern suggestions, Hydration and electrolyte needs.`,
  };

  const systemPrompt = `You are a professional health analyst for Kevin Lane. Generate detailed, evidence-based reports using markdown with headers, bullet points, and tables. Use the health data provided to create specific, actionable recommendations. Be precise with medical terminology while maintaining clarity. Do not use placeholder text — use real data or reasonable inferences.`;

  return await callClaude(apiKey, systemPrompt, prompts[type] || `Generate a ${type} report`, data);
}

// ═══════════════════════════════════════════════════════════════
// LEGAL REPORT GENERATORS
// ═══════════════════════════════════════════════════════════════

async function generateLegalReport(type: string, apiKey: string): Promise<string> {
  const prompts: Record<string, string> = {
    'medical-malpractice': `Generate a medical malpractice assessment for Kevin Lane. Context: 2 rhabdomyolysis events, AMPD1 + AGK genetic conditions initially missed/delayed diagnosis, potential gaps in medical care. Include: Timeline of events, Standard of care analysis, Liability assessment, Documentation review checklist, Recommended action steps.`,
    'legal-action-checklist': `Generate a legal action checklist for Kevin Lane's potential medical malpractice case. Include: Critical deadlines (statute of limitations), Evidence gathering tasks, Medical records needed, Expert witness types, Cost considerations, Settlement vs. litigation analysis.`,
    'rights-benefits-review': `Generate a rights and benefits review for Kevin Lane. Context: Federal employee (IRS IR-04), FMLA eligibility, potential disability benefits. Include: Available benefits, Qualification criteria, Application process, Deadlines, Tax implications, Strategic recommendations.`,
    'contract-review': `Generate a contract review template for Kevin Lane. Include: Key sections checklist, Red flags, Negotiation points, Risk assessment framework, Legal terminology glossary, Professional review recommendations.`,
    'ip-status': `Generate an IP status report for Kevin Lane's projects. Summary: DenominatorX project, RhabdoReducer trademark status, App ownership clarification. Include: Current status, Protection strategies, Next steps, Registration deadlines, Monitoring needs.`,
    'privacy-compliance': `Generate a privacy compliance review for Kevin Lane's health data applications. Topics: HIPAA adjacency considerations, Data handling best practices, Security requirements, User consent documentation, Breach notification protocols, Regulatory checkpoints.`,
  };

  const systemPrompt = `You are a professional legal analyst specializing in medical law and privacy. Generate detailed, actionable legal reports in markdown format. Include headers, bullet points, tables, and checklists. Be specific about deadlines, processes, and recommendations. Provide practical guidance while noting when professional legal counsel is needed.`;

  return await callClaude(apiKey, systemPrompt, prompts[type] || `Generate a ${type} legal report`, {});
}

// ═══════════════════════════════════════════════════════════════
// SYSTEM REPORT GENERATORS
// ═══════════════════════════════════════════════════════════════

async function generateSystemReport(type: string, apiKey: string): Promise<string> {
  const data = gatherSystemData();
  
  const prompts: Record<string, string> = {
    'daily-system-health': `Generate a daily system health report. Include: System metrics (RAM, CPU, storage), Active services status, Port health check results, Database connectivity, API availability, Recommendations for optimization.`,
    'api-usage-cost': `Generate an API usage and cost report. Analyze agent usage data and calculate costs. Include: Cost breakdown by agent, Model efficiency, Cost trends, Optimization recommendations, Budget forecasting.`,
    'agent-performance': `Generate an agent performance report analyzing activity and usage patterns. Include: Agent utilization metrics, Task completion rates, Cost per agent, Performance rankings, Recommendations for resource allocation.`,
    'security-audit': `Generate a security audit report. Check: Authentication status, Authorization controls, Data encryption, Access logs, Vulnerability assessment, Recommendations for hardening.`,
    'infrastructure-status': `Generate an infrastructure status report. Check: Service availability (ports 3001, 3002, 18800), Cloudflare tunnel status, Database health, Backup status, Scaling capacity, Incident history.`,
    'project-progress': `Generate a project progress report summarizing all active projects. Include: Phase breakdown, Completion percentages, Resource allocation, Timeline adherence, Blockers, Next milestones.`,
  };

  const systemPrompt = `You are a systems engineer generating operational reports. Create detailed, data-driven reports in markdown. Include: Executive summary, Key metrics, Status breakdowns, Trend analysis, Risk assessment, Recommendations. Use tables for data presentation. Be specific and actionable.`;

  return await callClaude(apiKey, systemPrompt, prompts[type] || `Generate a ${type} system report`, data);
}

// ═══════════════════════════════════════════════════════════════
// CLAUDE API CALL
// ═══════════════════════════════════════════════════════════════

async function callClaude(apiKey: string, systemPrompt: string, userPrompt: string, data: any): Promise<string> {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5',
        max_tokens: 2000,
        system: systemPrompt,
        messages: [{
          role: 'user',
          content: data && Object.keys(data).length > 0 
            ? `${userPrompt}\n\nContext Data:\n${JSON.stringify(data, null, 2)}`
            : userPrompt,
        }],
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return `# Error\n\nClaude API Error: ${result.error?.message || 'Unknown error'}`;
    }

    if (result.content?.[0]?.text) {
      return result.content[0].text;
    }

    return `# Error\n\nNo content in response`;
  } catch (e: any) {
    return `# Error\n\nFailed to call Claude: ${e.message}`;
  }
}

// ═══════════════════════════════════════════════════════════════
// MAIN HANDLER
// ═══════════════════════════════════════════════════════════════

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { category, type } = body;

    if (!category || !type) {
      return NextResponse.json(
        { error: 'Missing required fields: category and type' },
        { status: 400 }
      );
    }

    const settings = readJSON(SETTINGS_PATH);
    const apiKey = settings.apiKeys?.anthropic;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'Anthropic API key not configured in settings' },
        { status: 400 }
      );
    }

    let content = '';

    // Generate report based on category
    if (category === 'personal-health') {
      content = await generateHealthReport(type, apiKey);
    } else if (category === 'legal') {
      content = await generateLegalReport(type, apiKey);
    } else if (category === 'system-health') {
      content = await generateSystemReport(type, apiKey);
    } else {
      return NextResponse.json(
        { error: `Unknown category: ${category}` },
        { status: 400 }
      );
    }

    // Save report to reports.json
    const reportsData = readReports();
    const timestamp = Date.now();
    const report = {
      id: `rpt-auto-${timestamp}`,
      title: generateReportTitle(category, type),
      type,
      category,
      content,
      createdAt: new Date().toISOString(),
      createdBy: 'System',
      autoGenerated: true,
    };

    reportsData.reports.unshift(report);
    writeReports(reportsData);

    return NextResponse.json({
      ok: true,
      report,
    });
  } catch (e: any) {
    return NextResponse.json(
      { error: e.message },
      { status: 500 }
    );
  }
}

// Helper to generate nice report titles
function generateReportTitle(category: string, type: string): string {
  const categoryNames: Record<string, string> = {
    'personal-health': '❤️ Personal Health',
    'legal': '⚖️ Legal',
    'system-health': '🖥️ System Health',
  };

  const typeNames: Record<string, string> = {
    'daily-health-summary': 'Daily Health Summary',
    'weekly-health-trends': 'Weekly Health Trends',
    'supplement-compliance': 'Supplement Compliance',
    'mayo-clinic-prep': 'Mayo Clinic Preparation',
    'exercise-safety': 'Exercise Safety Assessment',
    'genetic-condition-overview': 'Genetic Condition Overview',
    'nutrition-analysis': 'Nutrition Analysis',
    'medical-malpractice': 'Medical Malpractice Assessment',
    'legal-action-checklist': 'Legal Action Checklist',
    'rights-benefits-review': 'Rights & Benefits Review',
    'contract-review': 'Contract Review Template',
    'ip-status': 'IP Status Report',
    'privacy-compliance': 'Privacy Compliance Review',
    'daily-system-health': 'Daily System Health',
    'api-usage-cost': 'API Usage & Cost Report',
    'agent-performance': 'Agent Performance Report',
    'security-audit': 'Security Audit Report',
    'infrastructure-status': 'Infrastructure Status',
    'project-progress': 'Project Progress Report',
  };

  const catName = categoryNames[category] || category;
  const typeName = typeNames[type] || type;

  return `${catName} — ${typeName}`;
}
