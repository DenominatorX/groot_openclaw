import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';

const REPORTS_PATH = path.join(process.cwd(), 'data', 'reports.json');

interface AddToTestPlanRequest {
  featureName: string;
  pageId: string;
  testStatus: string;
  description: string;
}

function readReports(): any {
  try {
    return JSON.parse(fs.readFileSync(REPORTS_PATH, 'utf8'));
  } catch {
    return { reports: [] };
  }
}

function writeReports(data: any) {
  fs.writeFileSync(REPORTS_PATH, JSON.stringify(data, null, 2));
}

export async function POST(request: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body: AddToTestPlanRequest = await request.json();
    const { featureName, pageId, testStatus, description } = body;

    if (!featureName || !pageId) {
      return NextResponse.json(
        { error: 'featureName and pageId are required' },
        { status: 400 }
      );
    }

    const reports = readReports();
    const testPlanReport = reports.reports.find(
      (r: any) => r.id === 'rpt-comprehensive-test-plan-feb14'
    );

    if (!testPlanReport) {
      return NextResponse.json(
        { error: 'Test plan report not found' },
        { status: 404 }
      );
    }

    // Generate a test case row
    // Find the next test number by looking for the highest X.Y pattern
    const content = testPlanReport.content || '';
    const existingNumbers = content.match(/(\d+)\.\d+/g) || [];
    let nextSection = 10; // Default to section 10 (MC-031)
    let nextNumber = 1;
    
    if (existingNumbers.length > 0) {
      const maxNum = Math.max(...existingNumbers.map((n: string) => parseInt(n.split('.')[0])));
      nextSection = maxNum + 1;
      // Count existing tests in the highest section
      const sectionMatches = content.match(new RegExp(`^${nextSection}\\.(\\d+)`, 'gm')) || [];
      nextNumber = sectionMatches.length + 1;
    }

    // Create the test case row
    const testCaseRow = `\n| ${nextSection}.${nextNumber} | ${featureName} | ${description || 'Test the feature functionality'} | Feature works as expected | ⬜ |`;

    // Check if we need to add a new section header
    let newSection = '';
    if (!content.includes(`### ${nextSection}. MC-`) && !content.includes(`#### `)) {
      // Check if the last character is a newline
      const ending = content.endsWith('\n') ? '' : '\n\n';
      newSection = `${ending}### ${nextSection}. New Features (Added ${new Date().toLocaleDateString()})\n\n| # | Feature | Test | Expected Result | Status |\n|---|---------|------|-----------------|--------|`;
    }

    // Append to the content
    testPlanReport.content = content + newSection + testCaseRow;

    // Save back
    writeReports(reports);

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('Error adding to test plan:', error);
    return NextResponse.json(
      { error: 'Failed to add to test plan' },
      { status: 500 }
    );
  }
}