import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';

const DATA_DIR = path.join(process.cwd(), 'data');

function readJSON(f: string) {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, f), 'utf8')); } catch { return null; }
}

export async function POST() {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  const projectsData = readJSON('projects.json') || { projects: [] };
  const projects: any[] = projectsData.projects || [];
  const risksDir = path.join(DATA_DIR, 'risks');

  // Collect prerequisites: projectId -> [dependsOn projectIds]
  const deps: Record<string, string[]> = {};
  const allIds = new Set(projects.map((p: any) => p.id));

  for (const p of projects) {
    deps[p.id] = [];
    const riskFile = path.join(risksDir, `${p.id}.json`);
    if (fs.existsSync(riskFile)) {
      try {
        const rd = JSON.parse(fs.readFileSync(riskFile, 'utf8'));
        const prereqs = Array.isArray(rd) ? [] : (rd.prerequisites || []);
        for (const pr of prereqs) {
          const depId = pr.projectId || pr.dependsOn;
          if (depId && allIds.has(depId)) deps[p.id].push(depId);
        }
      } catch {}
    }
  }

  // Topological sort via Kahn's algorithm
  const inDeg: Record<string, number> = {};
  for (const id of allIds) inDeg[id] = 0;
  for (const [id, d] of Object.entries(deps)) {
    for (const dep of d) inDeg[id] = (inDeg[id] || 0) + 1;
  }

  const queue: string[] = [];
  for (const [id, deg] of Object.entries(inDeg)) {
    if (deg === 0) queue.push(id);
  }

  const ranks: Record<string, number> = {};
  let rank = 1;
  const visited = new Set<string>();

  while (queue.length > 0) {
    const batch = [...queue];
    queue.length = 0;
    for (const id of batch) {
      ranks[id] = rank;
      visited.add(id);
    }
    rank++;
    // Find nodes whose deps are all visited
    for (const id of allIds) {
      if (visited.has(id)) continue;
      if (deps[id].every(d => visited.has(d))) {
        if (!queue.includes(id)) queue.push(id);
      }
    }
  }

  // Assign remaining (cycles) the max rank
  for (const id of allIds) {
    if (!ranks[id]) ranks[id] = rank;
  }

  const projectRanks = projects.map((p: any) => ({
    id: p.id,
    title: p.title || p.name,
    prereqRank: ranks[p.id] || rank,
    status: p.status,
    priority: p.priority,
  }));

  // Read reports and attach ranks
  const reportsData = readJSON('reports.json') || { reports: [] };
  const reports = (reportsData.reports || []).map((r: any) => ({
    ...r,
    prereqRank: r.projectId ? (ranks[r.projectId] || 999) : 999,
    projectTitle: r.projectId ? projects.find((p: any) => p.id === r.projectId)?.title || '' : '',
  }));

  return NextResponse.json({ ok: true, projectRanks, reports });
}
