import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';
import { getUserFromSession } from '@/lib/auth';

const REPORTS_PATH = path.join(process.cwd(), 'data', 'reports.json');
const SETTINGS_PATH = path.join(process.cwd(), 'data', 'settings.json');
const TASKS_PATH = path.join(process.cwd(), 'data', 'tasks.json');
const AGENTS_PATH = path.join(process.cwd(), 'data', 'agents.json');
const PROJECTS_PATH = path.join(process.cwd(), 'data', 'projects.json');
const ACTIVITY_PATH = path.join(process.cwd(), 'data', 'activity.json');
const SESSIONS_PATH = path.join(process.cwd(), 'data', 'agent-sessions.json');

function readJSON(p: string): any {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return {}; }
}

function writeJSON(p: string, data: any) {
  fs.writeFileSync(p, JSON.stringify(data, null, 2));
}

function readReports() {
  try { return JSON.parse(fs.readFileSync(REPORTS_PATH, 'utf8')); }
  catch { return { reports: [] }; }
}

function writeReports(data: any) {
  fs.writeFileSync(REPORTS_PATH, JSON.stringify(data, null, 2));
}

// Filter reports by user_id - admin sees all, others see only their own
function filterReportsByUser(reports: any[], userId: string, isAdmin: boolean): any[] {
  if (isAdmin) return reports; // Admin sees all
  return reports.filter((r: any) => r.user_id === userId || !r.user_id); // Show user's reports and reports without user_id
}

function logActivity(agent: string, action: string, detail: string) {
  const activity = readJSON(ACTIVITY_PATH);
  const entries = activity.entries || activity.activities || [];
  entries.push({ id: Date.now().toString(36), agent, action, detail, timestamp: new Date().toISOString() });
  fs.writeFileSync(ACTIVITY_PATH, JSON.stringify({ entries }, null, 2));
}

function pickAgentForReport(type: string): { id: string; name: string; model: string } {
  // Complex reports → use Swift (Sonnet, Tier 2) for best cost/quality balance
  // Simple reports → use Scout (Haiku, Tier 4) for speed/cost
  const complex = ['prd', 'design', 'tech-spec', 'agent-performance', 'cost-analysis'];
  const agents = readJSON(AGENTS_PATH);
  
  if (complex.includes(type)) {
    // Use Swift (Sonnet) or fall back to first tier-2 agent
    const swift = (agents.agents || []).find((a: any) => a.id === 'swift' || a.tier === 2);
    if (swift) return { id: swift.id, name: swift.displayName || swift.name, model: swift.model || 'anthropic/claude-sonnet-4-5' };
  }
  
  // Use Scout (Haiku) for simpler reports
  const scout = (agents.agents || []).find((a: any) => a.id === 'scout' || a.tier === 4);
  if (scout) return { id: scout.id, name: scout.displayName || scout.name, model: scout.model || 'anthropic/claude-haiku-4-5' };
  
  return { id: 'scout', name: 'Scout', model: 'anthropic/claude-haiku-4-5' };
}

async function generateWithAI(type: string, projectTitle: string, context: any): Promise<string> {
  const settings = readJSON(SETTINGS_PATH);
  const apiKey = settings.apiKeys?.anthropic;
  if (!apiKey) return `# ${type} — ${projectTitle}\n\n*No Anthropic API key configured. Add one in Settings > API Keys to enable AI-generated reports.*`;

  const tasks = readJSON(TASKS_PATH);
  const agents = readJSON(AGENTS_PATH);
  const projects = readJSON(PROJECTS_PATH);
  const activity = readJSON(ACTIVITY_PATH);

  const project = (projects.projects || []).find((p: any) => p.id === context.projectId);
  const projectTasks = (tasks.tasks || []).filter((t: any) => t.projectId === context.projectId || !context.projectId);
  const recentActivity = (activity.entries || []).slice(-20);

  const dataContext = `
Project: ${projectTitle}
${project ? `Status: ${project.status}, Phases: ${JSON.stringify(project.phases || [])}` : ''}
${project?.description ? `Description: ${project.description}` : ''}

Tasks (${projectTasks.length} total):
${projectTasks.slice(0, 15).map((t: any) => `- [${t.column}] ${t.title} (${t.assignee || 'unassigned'}, ${t.priority || 'normal'})`).join('\n')}

Agents (${(agents.agents || []).length}):
${(agents.agents || []).map((a: any) => `- ${a.name} (Tier ${a.tier}, ${a.role}, ${a.status})`).join('\n')}

Recent Activity:
${recentActivity.map((e: any) => `- ${e.agent}: ${e.action} — ${e.detail || e.details || ''}`).join('\n')}
`;

  const typePrompts: Record<string, string> = {
    'prd': `Write a detailed Product Requirements Document for "${projectTitle}". Include: Overview, Goals, User Stories, Functional Requirements, Non-Functional Requirements, Success Metrics, Timeline, and Risks.`,
    'design': `Write a Design Document for "${projectTitle}". Include: Design Goals, Architecture Overview, Component Structure, Data Model, UI/UX Considerations, API Design, and Open Questions.`,
    'tech-spec': `Write a Technical Specification for "${projectTitle}". Include: Tech Stack, Architecture, API Endpoints, Database Schema, Deployment Strategy, Security, and Performance Considerations.`,
    'status': `Write a Status Report for "${projectTitle}". Include: Executive Summary, Completed Items, In Progress, Blockers, Risks, and Next Steps.`,
    'meeting': `Write Meeting Notes for a project review of "${projectTitle}". Include: Attendees (use the agent names), Agenda, Key Discussion Points, Decisions Made, Action Items with owners, and Next Meeting date.`,
    'weekly-summary': `Write a Weekly Summary Report. Include: Task Overview (by status), Key Accomplishments, Agent Activity Summary, Blockers, and Priorities for Next Week.`,
    'agent-performance': `Write an Agent Performance Report. Analyze each agent's activity, tier, model usage, and tasks completed. Include recommendations for optimization.`,
    'cost-analysis': `Write a Cost Analysis Report. Break down estimated API costs by agent tier. Tier costs: Executive(Opus)=$15/1M, VP(Sonnet)=$3/1M, Director(Grok)=$3/1M, Sr.Manager(Haiku)=$0.80/1M, Manager/Frontline(Ollama)=free. Include optimization recommendations.`,
    'health-report': `Write a System Health Report. Cover: system metrics, agent utilization, task velocity, data growth, and recommendations.`,
  };

  const prompt = typePrompts[type] || `Write a ${type} report for "${projectTitle}".`;

  const agent = pickAgentForReport(type);
  const modelId = (agent.model || 'anthropic/claude-haiku-4-5').replace('anthropic/', '');

  // Mark agent as working
  const sessions = readJSON(SESSIONS_PATH);
  if (!sessions.sessions) sessions.sessions = {};
  sessions.sessions[agent.id] = { ...(sessions.sessions[agent.id] || {}), status: 'working', currentTask: `Generating ${type} report: ${projectTitle}`, lastTaskAt: new Date().toISOString() };
  writeJSON(SESSIONS_PATH, sessions);

  // Update agent status
  const agentsData = readJSON(AGENTS_PATH);
  const agentIdx = (agentsData.agents || []).findIndex((a: any) => a.id === agent.id);
  if (agentIdx >= 0) { agentsData.agents[agentIdx].status = 'active'; agentsData.agents[agentIdx].lastActive = new Date().toISOString(); writeJSON(AGENTS_PATH, agentsData); }

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: modelId,
        max_tokens: 2000,
        system: `You are ${agent.name}, a professional report writer for Mission Control, Kevin Lane's AI command center. Write detailed, well-formatted reports using markdown. Use headers (##, ###), tables, bullet points, and bold text. Be specific and data-driven using the context provided. Do not include placeholder text — fill everything with real data or reasonable analysis based on the context.`,
        messages: [{
          role: 'user',
          content: `${prompt}\n\nHere is the current project data:\n${dataContext}`,
        }],
      }),
    });
    const data = await resp.json();

    // Mark agent as idle
    sessions.sessions[agent.id].status = 'idle';
    sessions.sessions[agent.id].currentTask = null;
    sessions.sessions[agent.id].tasksCompleted = (sessions.sessions[agent.id].tasksCompleted || 0) + 1;
    writeJSON(SESSIONS_PATH, sessions);
    if (agentIdx >= 0) { agentsData.agents[agentIdx].status = 'idle'; writeJSON(AGENTS_PATH, agentsData); }

    if (data.content?.[0]?.text) return `*Generated by ${agent.name} (${modelId})*\n\n${data.content[0].text}`;
    return `# ${type} — ${projectTitle}\n\n*Error generating report: ${data.error?.message || 'Unknown error'}*`;
  } catch (e: any) {
    // Reset agent status on error
    sessions.sessions[agent.id].status = 'idle'; sessions.sessions[agent.id].currentTask = null;
    writeJSON(SESSIONS_PATH, sessions);
    if (agentIdx >= 0) { agentsData.agents[agentIdx].status = 'idle'; writeJSON(AGENTS_PATH, agentsData); }
    return `# ${type} — ${projectTitle}\n\n*Error: ${e.message}*`;
  }
}

export async function GET() {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  
  // Get current user for filtering
  const user = await getUserFromSession();
  if (!user) return new Response('Unauthorized', { status: 401 });
  
  const data = readReports();
  const filteredReports = filterReportsByUser(data.reports || [], user.id, user.role === 'admin');
  
  return NextResponse.json({ reports: filteredReports });
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  // Get current user for filtering
  const user = await getUserFromSession();
  if (!user) return new Response('Unauthorized', { status: 401 });

  try {
    const body = await req.json();

    if (body.action === 'create') {
      // If content provided (from client template), use it. Otherwise generate with AI.
      let content = body.content;
      if (!content || content.length < 50) {
        content = await generateWithAI(body.type, body.title || 'General', {
          projectId: body.projectId,
        });
      }

      const data = readReports();
      const report = {
        id: `rpt-${Date.now()}`,
        title: body.title || 'Untitled Report',
        type: body.type || 'status',
        projectId: body.projectId || null,
        content,
        createdAt: new Date().toISOString(),
        createdBy: body.createdBy || 'System',
        user_id: user.id, // Associate with current user
      };
      data.reports.unshift(report);
      writeReports(data);

      logActivity('System', 'report-generated', `${report.title}`);

      return NextResponse.json({ ok: true, report });
    }

    if (body.action === 'delete') {
      const data = readReports();
      // Check ownership
      const report = data.reports.find((r: any) => r.id === body.id);
      if (report && user.role !== 'admin' && report.user_id && report.user_id !== user.id) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
      }
      data.reports = data.reports.filter((r: any) => r.id !== body.id);
      writeReports(data);
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  // Get current user for filtering
  const user = await getUserFromSession();
  if (!user) return new Response('Unauthorized', { status: 401 });

  try {
    const { id, content, title, testResults } = await req.json();
    if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });

    const data = readReports();
    const report = data.reports.find((r: any) => r.id === id);
    if (!report) return NextResponse.json({ error: 'Report not found' }, { status: 404 });

    // Check ownership
    if (user.role !== 'admin' && report.user_id && report.user_id !== user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    if (content !== undefined) report.content = content;
    if (title !== undefined) report.title = title;
    if (testResults !== undefined) report.testResults = testResults;
    report.updatedAt = new Date().toISOString();
    writeReports(data);

    return NextResponse.json({ ok: true, report });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
