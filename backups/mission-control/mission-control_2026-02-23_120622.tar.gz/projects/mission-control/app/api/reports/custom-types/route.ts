import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';

const FILE = path.join(process.cwd(), 'data', 'custom-report-types.json');

function readTypes(): any[] {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf-8')); } catch { return []; }
}

export async function GET() {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  return NextResponse.json({ types: readTypes() });
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  const body = await req.json();
  const { id, label, icon, category } = body;
  if (!id || !label) return NextResponse.json({ error: 'Missing id or label' }, { status: 400 });
  const types = readTypes();
  if (types.find((t: any) => t.id === id)) return NextResponse.json({ types });
  types.push({ id, label, icon: icon || '✏️', category: category || 'project' });
  fs.writeFileSync(FILE, JSON.stringify(types, null, 2));
  return NextResponse.json({ ok: true, types });
}
