import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/database';

// XP thresholds for levels (PRD: 7 tiers)
const XP_PER_LEVEL = 1000;

// Role multipliers from PRD
const ROLE_MULTIPLIERS: Record<string, number> = {
  'gork': 0.8,      // PM/Orchestrator - high cost role
  'pixel': 1.0,     // Senior Frontend
  'forge': 1.0,     // Senior Backend
  'sentinel': 1.0,   // QA
  'spark': 1.5,     // Junior - punch above weight
  'runner': 1.5,    // Junior
  'archivist': 1.0, // Memory
  'maverick': 1.0,  // CMO Review
};

// Base XP per task type from PRD
const BASE_XP: Record<string, number> = {
  'planning': 50,
  'coding': 100,
  'qa': 40,
  'review': 60,
  'memory': 20,
  'research': 30,
  'default': 50,
};

// Quality factors from PRD
const QUALITY_FACTORS = {
  'success': 1.0,
  'first_try': 1.0,
  'downstream_enable': 1.2,
  'rollback': 0.5,
  'security_issue': 0.2,
  'partial': 0.7,
};

// Negative XP penalties from PRD
const NEGATIVE_XP = {
  'rollback': -20,
  'security_issue': -50,
  'groot_wake': -10,
  'timeout': -30,
  'lockup': -40,
  'hard_fail': -25,
  'incomplete': -15,
  'retry': -10, // retry tax
};

function calculateLevel(xp: number): number {
  return Math.floor(xp / XP_PER_LEVEL) + 1;
}

function calculateProgress(xp: number): number {
  return (xp % XP_PER_LEVEL) / XP_PER_LEVEL * 100;
}

function getLevelLabel(level: number): string {
  const labels: Record<number, string> = {
    1: 'Unranked',
    2: 'Operative',
    3: 'Specialist',
    4: 'Expert',
    5: 'Senior Operator',
    6: 'Principal',
    7: 'Legend',
  };
  return labels[level] || `Level ${level}`;
}

/**
 * Full XP Calculation per PRD Formula:
 * XP = BaseXP × RoleMultiplier × EfficiencyBonus × QualityFactor
 */
function calculateXP(
  baseXP: number,
  role: string,
  actualCost: number,
  qualityFactor: string,
  peerAvgCost?: number
): number {
  // Role multiplier
  const roleMultiplier = ROLE_MULTIPLIERS[role] || 1.0;
  
  // Efficiency bonus: expectedCost / actualCost (capped 0.5-3.0)
  const expectedCost = peerAvgCost || actualCost * 1.2; // Default if no benchmark
  const efficiencyBonus = Math.max(0.5, Math.min(3.0, expectedCost / actualCost));
  
  // Quality factor
  const quality = QUALITY_FACTORS[qualityFactor] || 1.0;
  
  // Calculate final XP
  const xp = Math.round(baseXP * roleMultiplier * efficiencyBonus * quality);
  
  return Math.max(0, xp); // Floor at 0
}

/**
 * Get peer benchmark for task type and role group
 */
function getPeerBenchmark(db: any, taskType: string, roleGroup: string): number | null {
  try {
    const row = db.prepare(
      'SELECT rolling_avg_cost FROM peer_benchmarks WHERE task_type = ? AND role_group = ?'
    ).get(taskType, roleGroup) as { rolling_avg_cost: number } | undefined;
    return row?.rolling_avg_cost || null;
  } catch {
    return null;
  }
}

/**
 * Update peer benchmark after task completion
 */
function updatePeerBenchmark(db: any, taskType: string, roleGroup: string, actualCost: number): void {
  try {
    const existing = db.prepare(
      'SELECT rolling_avg_cost, sample_count FROM peer_benchmarks WHERE task_type = ? AND role_group = ?'
    ).get(taskType, roleGroup) as { rolling_avg_cost: number; sample_count: number } | undefined;
    
    if (existing) {
      // Running average: new_avg = (old_avg * n + new_cost) / (n + 1)
      const n = existing.sample_count;
      const newAvg = (existing.rolling_avg_cost * n + actualCost) / (n + 1);
      db.prepare(
        'UPDATE peer_benchmarks SET rolling_avg_cost = ?, sample_count = ?, updated_at = datetime("now") WHERE task_type = ? AND role_group = ?'
      ).run(newAvg, n + 1, taskType, roleGroup);
    } else {
      // Insert new benchmark
      db.prepare(
        'INSERT INTO peer_benchmarks (task_type, role_group, rolling_avg_cost, sample_count) VALUES (?, ?, ?, 1)'
      ).run(taskType, roleGroup, actualCost);
    }
  } catch (e) {
    console.error('Error updating peer benchmark:', e);
  }
}

// GET - Fetch XP data for an agent or project
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const agentId = searchParams.get('agentId');
  const projectId = searchParams.get('projectId');

  if (!agentId && !projectId) {
    return NextResponse.json({ error: 'agentId or projectId required' }, { status: 400 });
  }

  try {
    const db = getDb();

    if (agentId) {
      // Fetch agent XP data
      const agent = db.prepare('SELECT data FROM agents WHERE id = ?').get(agentId) as { data: any } | undefined;
      
      let xp = 0;
      let efficiency = 0;
      let totalTasks = 0;
      let completedTasks = 0;

      if (agent?.data) {
        xp = agent.data.xp || 0;
        totalTasks = agent.data.stats?.totalTasks || 0;
        completedTasks = agent.data.stats?.completedTasks || 0;
        efficiency = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
      }

      // Generate mock data if no XP exists (for demo)
      if (xp === 0) {
        // Mock XP based on agent ID hash for consistency
        const hash = agentId.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0);
        xp = Math.abs(hash % 15000) + 100;
        totalTasks = Math.abs(hash % 50) + 10;
        completedTasks = Math.floor(totalTasks * (0.6 + (Math.abs(hash % 40) / 100)));
        efficiency = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
      }

      const level = calculateLevel(xp);
      const progress = calculateProgress(xp);

      return NextResponse.json({
        agentId,
        xp,
        level,
        levelLabel: getLevelLabel(level),
        progress,
        xpToNextLevel: XP_PER_LEVEL - (xp % XP_PER_LEVEL),
        efficiency,
        stats: { totalTasks, completedTasks },
      });
    }

    if (projectId) {
      // Fetch project XP data
      const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId) as any;
      
      let xp = 0;
      let efficiency = 0;
      let totalTasks = 0;
      let completedTasks = 0;

      if (project?.data) {
        const projectData = typeof project.data === 'string' ? JSON.parse(project.data) : project.data;
        xp = projectData.xp || 0;
        totalTasks = projectData.stats?.totalTasks || 0;
        completedTasks = projectData.stats?.completedTasks || 0;
        efficiency = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
      }

      // Generate mock data if no XP exists (for demo)
      if (xp === 0) {
        const hash = projectId.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0);
        xp = Math.abs(hash % 8000) + 50;
        totalTasks = Math.abs(hash % 30) + 5;
        completedTasks = Math.floor(totalTasks * (0.5 + (Math.abs(hash % 50) / 100)));
        efficiency = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
      }

      const level = calculateLevel(xp);
      const progress = calculateProgress(xp);

      return NextResponse.json({
        projectId,
        xp,
        level,
        levelLabel: getLevelLabel(level),
        progress,
        xpToNextLevel: XP_PER_LEVEL - (xp % XP_PER_LEVEL),
        efficiency,
        stats: { totalTasks, completedTasks },
      });
    }

    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  } catch (error) {
    console.error('XP API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PATCH - Update XP for an agent
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { agentId, xpDelta = 0, completedTasks = 0, totalTasks = 0, isStreak = false, isCollaboration = false, isFirstBlood = false } = body;

    if (!agentId) {
      return NextResponse.json({ error: 'agentId required' }, { status: 400 });
    }

    const db = getDb();
    const agent = db.prepare('SELECT data FROM agents WHERE id = ?').get(agentId) as { data: any } | undefined;

    let currentXp = 0;
    let data: any = {};

    if (agent?.data) {
      data = typeof agent.data === 'string' ? JSON.parse(agent.data) : agent.data;
      currentXp = data.xp || 0;
    }

    // Calculate bonuses
    let totalDelta = xpDelta;
    
    // Streak bonus: min(streak * 2, 20) if this is a streak completion
    if (isStreak && data.streakCount) {
      const streakBonus = Math.min(data.streakCount * 2, 20);
      totalDelta += streakBonus;
    }
    
    // Collaboration bonus: +10 XP
    if (isCollaboration) {
      totalDelta += 10;
    }
    
    // First blood bonus: +25 XP
    if (isFirstBlood) {
      totalDelta += 25;
    }

    // Update streak: if completed today, increment; otherwise reset
    const today = new Date().toISOString().split('T')[0];
    const lastComplete = data.lastCompleteDate;
    
    if (completedTasks > 0) {
      if (lastComplete === today) {
        data.streakCount = (data.streakCount || 0) + 1;
      } else {
        data.streakCount = 1; // Start new streak
      }
      data.lastCompleteDate = today;
    }

    const newXp = Math.max(0, currentXp + totalDelta);
    data.xp = newXp;
    data.stats = {
      ...data.stats,
      totalTasks: (data.stats?.totalTasks || 0) + totalTasks,
      completedTasks: (data.stats?.completedTasks || 0) + completedTasks,
    };

    db.prepare('UPDATE agents SET data = ?, updated_at = datetime("now") WHERE id = ?').run(JSON.stringify(data), agentId);

    const level = calculateLevel(newXp);
    const progress = calculateProgress(newXp);
    const efficiency = data.stats.totalTasks > 0 
      ? Math.round((data.stats.completedTasks / data.stats.totalTasks) * 100) 
      : 0;

    return NextResponse.json({
      agentId,
      xp: newXp,
      level,
      levelLabel: getLevelLabel(level),
      progress,
      xpToNextLevel: XP_PER_LEVEL - (newXp % XP_PER_LEVEL),
      efficiency,
      streakCount: data.streakCount || 0,
      bonuses: {
        streak: isStreak ? Math.min((data.streakCount || 1) * 2, 20) : 0,
        collaboration: isCollaboration ? 10 : 0,
        firstBlood: isFirstBlood ? 25 : 0,
      },
      stats: data.stats,
    });
  } catch (error) {
    console.error('XP PATCH error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
