import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';
import { checkAuth } from '@/lib/api-auth';

const INVOICES_FILE = path.join(process.cwd(), 'data/apps/invoice/invoices.json');

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const invoiceId = params.id;
    const body = await req.json();
    let data = JSON.parse(fs.readFileSync(INVOICES_FILE, 'utf-8'));
    data = data.map((invoice: any) => (invoice.id === invoiceId ? { ...invoice, ...body } : invoice));
    fs.writeFileSync(INVOICES_FILE, JSON.stringify(data, null, 2));
    return NextResponse.json(body);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update invoice' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const invoiceId = params.id;
    let data = JSON.parse(fs.readFileSync(INVOICES_FILE, 'utf-8'));
    data = data.filter((invoice: any) => invoice.id !== invoiceId);
    fs.writeFileSync(INVOICES_FILE, JSON.stringify(data, null, 2));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete invoice' }, { status: 500 });
  }
}
