import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';
import { logActivity } from '@/lib/activity';
import { getSettings } from '@/lib/settings';

const RAW_PATH = path.join(process.cwd(), 'data', 'apps', 'import', 'chatgpt-raw.json');
const INSIGHTS_PATH = path.join(process.cwd(), 'data', 'apps', 'import', 'chatgpt-insights.json');

interface Insights {
  topics: string[];
  decisions: string[];
  preferences: string[];
  facts: string[];
  summary: string;
  importedAt: string;
  conversationCount: number;
}

function writeRaw(data: any) {
  fs.mkdirSync(path.dirname(RAW_PATH), { recursive: true });
  fs.writeFileSync(RAW_PATH, JSON.stringify(data, null, 2));
}

function writeInsights(data: Insights) {
  fs.mkdirSync(path.dirname(INSIGHTS_PATH), { recursive: true });
  fs.writeFileSync(INSIGHTS_PATH, JSON.stringify(data, null, 2));
}

// Extract text from ChatGPT conversation structure
function extractConversationText(conversations: any[]): string {
  let text = '';
  
  for (const conv of conversations) {
    if (conv.title) text += `Topic: ${conv.title}\n`;
    if (conv.messages && Array.isArray(conv.messages)) {
      for (const msg of conv.messages) {
        if (msg.content && typeof msg.content === 'string') {
          text += `${msg.content}\n`;
        } else if (msg.content && Array.isArray(msg.content)) {
          for (const part of msg.content) {
            if (typeof part === 'string') {
              text += `${part}\n`;
            } else if (part.text) {
              text += `${part.text}\n`;
            }
          }
        }
      }
    }
  }
  
  return text;
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { conversations } = body;

    if (!conversations || !Array.isArray(conversations)) {
      return NextResponse.json({ error: 'Conversations array is required' }, { status: 400 });
    }

    // Save raw data
    const rawData = {
      conversations,
      importedAt: new Date().toISOString(),
      conversationCount: conversations.length
    };
    writeRaw(rawData);

    // Extract conversation text
    const conversationText = extractConversationText(conversations);

    // Call Haiku to extract insights
    const settings = getSettings();
    const apiKey = settings.apiKeys.anthropic;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5',
        max_tokens: 2000,
        messages: [
          {
            role: 'user',
            content: `Extract key facts, preferences, decisions, and important context from these ChatGPT conversations. Return as structured JSON with these keys: topics (array of unique topics), decisions (array of decisions made), preferences (array of preferences expressed), facts (array of important facts), and summary (brief overall summary).

Conversations:
${conversationText.substring(0, 10000)}` // Limit to 10k chars to avoid token limits
          }
        ]
      })
    });

    if (!response.ok) {
      const error: any = await response.json();
      return NextResponse.json({ error: `Anthropic API error: ${error.error?.message || 'Unknown error'}` }, { status: 500 });
    }

    const result: any = await response.json();
    let insights: Insights;

    try {
      // Try to parse the response as JSON
      const content = result.content[0].text;
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        insights = {
          topics: parsed.topics || [],
          decisions: parsed.decisions || [],
          preferences: parsed.preferences || [],
          facts: parsed.facts || [],
          summary: parsed.summary || content,
          importedAt: new Date().toISOString(),
          conversationCount: conversations.length
        };
      } else {
        // Fallback if response isn't valid JSON
        insights = {
          topics: [],
          decisions: [],
          preferences: [],
          facts: [],
          summary: content,
          importedAt: new Date().toISOString(),
          conversationCount: conversations.length
        };
      }
    } catch (e) {
      // If parsing fails, use the raw response as summary
      insights = {
        topics: [],
        decisions: [],
        preferences: [],
        facts: [],
        summary: result.content[0].text,
        importedAt: new Date().toISOString(),
        conversationCount: conversations.length
      };
    }

    writeInsights(insights);
    logActivity('Kevin', 'Imported ChatGPT conversations', `${conversations.length} conversations`);

    return NextResponse.json({ success: true, insights });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
