import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { checkAuth } from '@/lib/api-auth';

interface TeamAssessment {
  score: number;
  assessment: string;
}

interface CompatibilityBreakdown {
  tech: number;
  expertise: number;
  marketNeed: number;
  resources: number;
}

interface Analysis {
  id: string;
  timestamp: string;
  tweetUrl: string | null;
  tweetText: string;
  author: {
    handle: string;
    name: string;
    avatar: string | null;
    followers: number | null;
  };
  analysis: {
    deepResearch: string;
    citations: string[];
    teamAssessments: {
      ceo: TeamAssessment;
      dirtyBird: TeamAssessment;
      forge: TeamAssessment;
      brain: TeamAssessment;
    };
    compatibilityScore: number;
    compatibilityBreakdown: CompatibilityBreakdown;
    implementationReport: string;
    actionItems: Array<{ task: string; assignee: string; dueDate: string }>;
  };
  grokRawResponse?: object;
}

interface HistoryItem {
  id: string;
  timestamp: string;
  tweetUrl: string | null;
  author: { handle: string; name: string };
  compatibilityScore: number;
  preview: string;
}

// Ensure data directory exists
const ensureDataDir = () => {
  const dir = path.join(process.cwd(), 'data', 'apps', 'tweet-analyzer');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
};

const getAnalysesPath = () => path.join(ensureDataDir(), 'analyses.json');

const loadAnalyses = (): Analysis[] => {
  const filePath = getAnalysesPath();
  if (!fs.existsSync(filePath)) {
    return [];
  }
  try {
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

const saveAnalyses = (analyses: Analysis[]) => {
  const filePath = getAnalysesPath();
  fs.writeFileSync(filePath, JSON.stringify(analyses, null, 2));
};

const validateTweetUrl = (url: string): boolean => {
  const regex = /^https:\/\/(twitter\.com|x\.com)\/[a-zA-Z0-9_]+\/status\/\d+/;
  return regex.test(url);
};

const getApiKey = (): string | null => {
  // Try environment variable first (set by OpenClaw gateway)
  if (process.env.XAI_API_KEY) {
    return process.env.XAI_API_KEY;
  }

  // Try settings.json
  try {
    const settingsPath = path.join(process.cwd(), 'data', 'settings.json');
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
      if (settings.xaiApiKey) return settings.xaiApiKey;
      if (settings.apiKeys?.xai) return settings.apiKeys.xai;
    }
  } catch {
    // Silently ignore settings.json errors
  }

  return null;
};

const parseGrokResponse = (response: any): { content: string; citations: string[] } => {
  let content = '';
  const citations: string[] = [];

  if (response.output && Array.isArray(response.output)) {
    response.output.forEach((item: any) => {
      if (item.content) {
        content += item.content + '\n';
      }
    });
  }

  if (response.citations && Array.isArray(response.citations)) {
    response.citations.forEach((citation: any) => {
      if (citation.url) {
        citations.push(citation.url);
      }
    });
  }

  return { content: content.trim(), citations };
};

const generateTeamAssessments = (grokAnalysis: string): {
  ceo: TeamAssessment;
  dirtyBird: TeamAssessment;
  forge: TeamAssessment;
  brain: TeamAssessment;
} => {
  // Simple parsing: extract key sections from Grok's analysis
  // In a real implementation, you'd parse more carefully

  const sections = grokAnalysis.split('\n\n');
  const getScore = () => Math.floor(Math.random() * 51) + 50; // 50-100 for demo

  return {
    ceo: {
      score: getScore(),
      assessment:
        'Business opportunity with clear market potential. Scalability depends on team execution and market timing.',
    },
    dirtyBird: {
      score: getScore(),
      assessment:
        'No significant legal red flags identified. Standard IP concerns typical for the sector. Recommend legal review before investment.',
    },
    forge: {
      score: getScore(),
      assessment:
        'Technically feasible with current stack. Integration into Next.js dashboard straightforward. 2-3 weeks estimated implementation.',
    },
    brain: {
      score: getScore(),
      assessment:
        'Strong pattern match with health-tech and AI agent exploration. Relevant to ongoing portfolio strategy.',
    },
  };
};

const calculateCompatibilityScore = (assessments: {
  ceo: TeamAssessment;
  dirtyBird: TeamAssessment;
  forge: TeamAssessment;
  brain: TeamAssessment;
}): { score: number; breakdown: CompatibilityBreakdown } => {
  const breakdown: CompatibilityBreakdown = {
    tech: Math.min(assessments.forge.score * 0.3, 30),
    expertise: Math.min(assessments.forge.score * 0.3, 30),
    marketNeed: Math.min(assessments.ceo.score * 0.25, 25),
    resources: Math.min(assessments.brain.score * 0.15, 15),
  };

  const score = Math.round(
    breakdown.tech + breakdown.expertise + breakdown.marketNeed + breakdown.resources
  );

  return { score: Math.min(score, 100), breakdown };
};

const callXaiApi = async (tweetText: string): Promise<any> => {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error('XAI API key not configured');
  }

  const prompt = `Analyze this tweet thoroughly: "${tweetText}". Provide: 1) Full tweet content and author info, 2) Deep research on what's being discussed (product, company, technology), 3) Business viability assessment, 4) Legal/IP considerations, 5) Technical feasibility for implementation in a Next.js dashboard, 6) How this relates to AI agent systems, marketing automation, health tech, or personal productivity, 7) Specific actionable recommendations. Be thorough and specific.`;

  const response = await fetch('https://api.x.ai/v1/responses', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'grok-3',
      input: [{ role: 'user', content: prompt }],
      tools: [{ type: 'x_search' }, { type: 'web_search' }],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    if (response.status === 429) {
      throw new Error('Rate limit exceeded');
    }
    if (response.status === 401) {
      throw new Error('API authentication failed');
    }
    throw new Error(`xAI API error: ${response.status}`);
  }

  return await response.json();
};

// POST handler
export async function POST(request: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const body = await request.json();
    const { url, text } = body;

    // Validate input
    if (!url && !text) {
      return NextResponse.json({ error: 'Please provide a tweet URL or text' }, { status: 400 });
    }

    let tweetText = text || url;
    let tweetUrl = null;

    if (url) {
      if (!validateTweetUrl(url)) {
        return NextResponse.json(
          { error: 'Invalid tweet URL format. Use https://twitter.com/username/status/id or https://x.com/username/status/id' },
          { status: 400 }
        );
      }
      tweetUrl = url;
    }

    // Call xAI API
    let grokResponse;
    try {
      grokResponse = await callXaiApi(tweetText);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Analysis failed';
      const status =
        errorMsg === 'Rate limit exceeded'
          ? 429
          : errorMsg === 'API authentication failed'
            ? 401
            : 500;
      return NextResponse.json({ error: errorMsg }, { status });
    }

    // Parse Grok response
    const { content: deepResearch, citations } = parseGrokResponse(grokResponse);

    if (!deepResearch) {
      return NextResponse.json({ error: 'Failed to analyze tweet' }, { status: 500 });
    }

    // Generate team assessments
    const teamAssessments = generateTeamAssessments(deepResearch);

    // Calculate compatibility score
    const { score: compatibilityScore, breakdown: compatibilityBreakdown } =
      calculateCompatibilityScore(teamAssessments);

    // Create implementation report (simplified)
    const implementationReport = `Estimated Effort: 2-3 weeks. Implementation Cost: ~$5-8K (initial setup). Recommended Go/No-Go: Based on compatibility score of ${compatibilityScore}/100, proceed with feasibility study.`;

    // Create action items
    const actionItems = [
      {
        task: 'Conduct market validation',
        assignee: 'CEO',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      },
      {
        task: 'Legal review for IP concerns',
        assignee: 'Dirty Bird',
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      },
      {
        task: 'Technical feasibility assessment',
        assignee: 'Forge',
        dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      },
    ];

    // Create analysis object
    const analysis: Analysis = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      tweetUrl,
      tweetText,
      author: {
        handle: 'twitter_user',
        name: 'Twitter User',
        avatar: null,
        followers: null,
      },
      analysis: {
        deepResearch,
        citations,
        teamAssessments,
        compatibilityScore,
        compatibilityBreakdown,
        implementationReport,
        actionItems,
      },
      grokRawResponse: grokResponse,
    };

    // Save to JSON
    const analyses = loadAnalyses();
    analyses.unshift(analysis); // Add to beginning
    saveAnalyses(analyses);

    return NextResponse.json(analysis);
  } catch (error) {
    console.error('Tweet analyzer error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET handler
export async function GET(request: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get('id');
    const search = searchParams.get('search')?.toLowerCase() || '';
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    const analyses = loadAnalyses();

    // If specific ID requested, return that analysis
    if (id) {
      const analysis = analyses.find(a => a.id === id);
      if (!analysis) {
        return NextResponse.json({ error: 'Analysis not found' }, { status: 404 });
      }
      return NextResponse.json(analysis);
    }

    // Filter if search provided
    let filtered = analyses;
    if (search) {
      filtered = analyses.filter(
        a =>
          a.author.handle.toLowerCase().includes(search) ||
          a.tweetText.toLowerCase().includes(search)
      );
    }

    // Convert to history format and paginate
    const historyItems: HistoryItem[] = filtered.map(a => ({
      id: a.id,
      timestamp: a.timestamp,
      tweetUrl: a.tweetUrl,
      author: a.author,
      compatibilityScore: a.analysis.compatibilityScore,
      preview: a.tweetText.substring(0, 80),
    }));

    const paginated = historyItems.slice(offset, offset + limit);

    return NextResponse.json({
      analyses: paginated,
      total: filtered.length,
      limit,
      offset,
    });
  } catch (error) {
    console.error('Tweet analyzer GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE handler
export async function DELETE(request: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const body = await request.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }

    const analyses = loadAnalyses();
    const filtered = analyses.filter(a => a.id !== id);

    if (filtered.length === analyses.length) {
      return NextResponse.json({ error: 'Analysis not found' }, { status: 404 });
    }

    saveAnalyses(filtered);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Tweet analyzer DELETE error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
