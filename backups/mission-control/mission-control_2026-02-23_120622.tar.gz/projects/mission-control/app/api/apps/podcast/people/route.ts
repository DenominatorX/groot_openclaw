import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';
import { logActivity } from '@/lib/activity';

const PEOPLE_PATH = path.join(process.cwd(), 'data', 'apps', 'podcast', 'people.json');

interface SocialLinks {
  [key: string]: string;
}

interface Person {
  id: string;
  name: string;
  role: 'host' | 'guest' | 'specialist' | 'wishlist';
  bio: string;
  photoUrl: string;
  shows?: string[];
  socialLinks?: SocialLinks;
  expertiseAreas?: string[];
  availability?: string;
  contact?: string;
  pastAppearances?: string[];
  bookingStatus?: string;
  outreachStatus?: 'not-contacted' | 'reached-out' | 'confirmed' | 'declined';
  why?: string;
}

interface PeopleData {
  people: Person[];
  recurringGuests: Person[];
  specialists: Person[];
  wishlist: Person[];
}

function readPeople(): PeopleData {
  if (!fs.existsSync(PEOPLE_PATH)) {
    return { people: [], recurringGuests: [], specialists: [], wishlist: [] };
  }
  return JSON.parse(fs.readFileSync(PEOPLE_PATH, 'utf8'));
}

function writePeople(data: PeopleData) {
  fs.mkdirSync(path.dirname(PEOPLE_PATH), { recursive: true });
  fs.writeFileSync(PEOPLE_PATH, JSON.stringify(data, null, 2));
}

export async function GET(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const { searchParams } = new URL(req.url);
    const role = searchParams.get('role');
    const expertise = searchParams.get('expertise');

    const data = readPeople();
    let people = data.people;

    if (role) {
      people = people.filter(p => p.role === role);
    }
    if (expertise) {
      people = people.filter(p => 
        p.expertiseAreas?.some(a => a.toLowerCase().includes(expertise.toLowerCase()))
      );
    }

    return NextResponse.json({
      people,
      recurringGuests: data.recurringGuests,
      specialists: data.specialists,
      wishlist: data.wishlist
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { name, role, bio, photoUrl, shows, socialLinks, expertiseAreas, availability, contact, outreachStatus, why } = body;

    if (!name || !role) {
      return NextResponse.json({ error: 'Name and role are required' }, { status: 400 });
    }

    const data = readPeople();
    
    const person: Person = {
      id: name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
      name,
      role,
      bio: bio || '',
      photoUrl: photoUrl || '',
      shows: shows || [],
      socialLinks: socialLinks || {},
      expertiseAreas: expertiseAreas || [],
      availability: availability || 'flexible',
      contact: contact || '',
      outreachStatus: outreachStatus || 'not-contacted',
      why: why || ''
    };

    // Add to appropriate list
    data.people.push(person);
    if (role === 'guest') data.recurringGuests.push(person);
    if (role === 'specialist') data.specialists.push(person);
    if (role === 'wishlist') data.wishlist.push(person);

    writePeople(data);

    logActivity('Kevin', `Added ${role} to podcast directory`, name);

    return NextResponse.json(person, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'Person ID is required' }, { status: 400 });
    }

    const data = readPeople();
    const personIndex = data.people.findIndex(p => p.id === id);

    if (personIndex === -1) {
      return NextResponse.json({ error: 'Person not found' }, { status: 404 });
    }

    data.people[personIndex] = { ...data.people[personIndex], ...updates };
    
    // Update in specialized lists
    const person = data.people[personIndex];
    if (person.role === 'guest') {
      const guestIndex = data.recurringGuests.findIndex(p => p.id === id);
      if (guestIndex !== -1) data.recurringGuests[guestIndex] = person;
    }
    if (person.role === 'specialist') {
      const specIndex = data.specialists.findIndex(p => p.id === id);
      if (specIndex !== -1) data.specialists[specIndex] = person;
    }
    if (person.role === 'wishlist') {
      const wishIndex = data.wishlist.findIndex(p => p.id === id);
      if (wishIndex !== -1) data.wishlist[wishIndex] = person;
    }

    writePeople(data);

    logActivity('Kevin', 'Updated person in podcast directory', person.name);

    return NextResponse.json(person);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'Person ID is required' }, { status: 400 });
    }

    const data = readPeople();
    const index = data.people.findIndex(p => p.id === id);

    if (index === -1) {
      return NextResponse.json({ error: 'Person not found' }, { status: 404 });
    }

    const deletedPerson = data.people.splice(index, 1)[0];
    
    // Remove from specialized lists
    data.recurringGuests = data.recurringGuests.filter(p => p.id !== id);
    data.specialists = data.specialists.filter(p => p.id !== id);
    data.wishlist = data.wishlist.filter(p => p.id !== id);

    writePeople(data);

    logActivity('Kevin', 'Removed person from podcast directory', deletedPerson.name);

    return NextResponse.json({ success: true, deleted: deletedPerson });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
