import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';
import { checkAuth } from '@/lib/api-auth';

const INVOICES_FILE = path.join(process.cwd(), 'data/apps/invoice/invoices.json');

function ensureFile() {
  if (!fs.existsSync(INVOICES_FILE)) {
    fs.writeFileSync(INVOICES_FILE, JSON.stringify([]));
  }
}

export async function GET(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    ensureFile();
    const data = fs.readFileSync(INVOICES_FILE, 'utf-8');
    return NextResponse.json(JSON.parse(data));
  } catch (error) {
    return NextResponse.json([]);
  }
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    ensureFile();
    const body = await req.json();
    const data = JSON.parse(fs.readFileSync(INVOICES_FILE, 'utf-8'));
    data.push(body);
    fs.writeFileSync(INVOICES_FILE, JSON.stringify(data, null, 2));
    return NextResponse.json(body);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create invoice' }, { status: 500 });
  }
}
