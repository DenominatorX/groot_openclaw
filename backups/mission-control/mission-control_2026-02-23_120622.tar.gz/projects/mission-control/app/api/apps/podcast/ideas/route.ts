import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';
import { logActivity } from '@/lib/activity';

const IDEAS_PATH = path.join(process.cwd(), 'data', 'apps', 'podcast', 'ideas.json');

interface Idea {
  id: string;
  title: string;
  description: string;
  category: string;
  source: 'conversation' | 'news' | 'request' | 'brainstorm';
  priority: 'low' | 'medium' | 'high';
  linkedShow?: string;
  stars: number;
  createdAt: string;
}

interface IdeasData {
  ideas: Idea[];
}

function readIdeas(): IdeasData {
  if (!fs.existsSync(IDEAS_PATH)) {
    return { ideas: [] };
  }
  return JSON.parse(fs.readFileSync(IDEAS_PATH, 'utf8'));
}

function writeIdeas(data: IdeasData) {
  fs.mkdirSync(path.dirname(IDEAS_PATH), { recursive: true });
  fs.writeFileSync(IDEAS_PATH, JSON.stringify(data, null, 2));
}

export async function GET(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const { searchParams } = new URL(req.url);
    const showId = searchParams.get('showId');
    const priority = searchParams.get('priority');
    const sortBy = searchParams.get('sortBy') || 'stars';

    const data = readIdeas();
    let ideas = data.ideas;

    if (showId) {
      ideas = ideas.filter(i => i.linkedShow === showId);
    }
    if (priority) {
      ideas = ideas.filter(i => i.priority === priority);
    }

    // Sort
    if (sortBy === 'stars') {
      ideas.sort((a, b) => b.stars - a.stars);
    } else if (sortBy === 'date') {
      ideas.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return NextResponse.json(ideas);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { title, description, category, source, priority, linkedShow } = body;

    if (!title) {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 });
    }

    const data = readIdeas();
    
    const idea: Idea = {
      id: `idea-${Date.now()}`,
      title,
      description: description || '',
      category: category || 'general',
      source: source || 'brainstorm',
      priority: priority || 'medium',
      linkedShow: linkedShow || undefined,
      stars: 0,
      createdAt: new Date().toISOString()
    };

    data.ideas.push(idea);
    writeIdeas(data);

    logActivity('Kevin', 'Added podcast idea', title);

    return NextResponse.json(idea, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'Idea ID is required' }, { status: 400 });
    }

    const data = readIdeas();
    const index = data.ideas.findIndex(i => i.id === id);

    if (index === -1) {
      return NextResponse.json({ error: 'Idea not found' }, { status: 404 });
    }

    data.ideas[index] = { ...data.ideas[index], ...updates };
    writeIdeas(data);

    logActivity('Kevin', 'Updated podcast idea', data.ideas[index].title);

    return NextResponse.json(data.ideas[index]);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'Idea ID is required' }, { status: 400 });
    }

    const data = readIdeas();
    const index = data.ideas.findIndex(i => i.id === id);

    if (index === -1) {
      return NextResponse.json({ error: 'Idea not found' }, { status: 404 });
    }

    const deletedIdea = data.ideas.splice(index, 1)[0];
    writeIdeas(data);

    logActivity('Kevin', 'Deleted podcast idea', deletedIdea.title);

    return NextResponse.json({ success: true, deleted: deletedIdea });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
