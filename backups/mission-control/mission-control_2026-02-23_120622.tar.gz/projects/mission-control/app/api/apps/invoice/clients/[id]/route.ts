import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';
import { checkAuth } from '@/lib/api-auth';

const CLIENTS_FILE = path.join(process.cwd(), 'data/apps/invoice/clients.json');

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const clientId = params.id;
    const body = await req.json();
    let data = JSON.parse(fs.readFileSync(CLIENTS_FILE, 'utf-8'));
    data = data.map((client: any) => (client.id === clientId ? body : client));
    fs.writeFileSync(CLIENTS_FILE, JSON.stringify(data, null, 2));
    return NextResponse.json(body);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update client' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;
  try {
    const clientId = params.id;
    let data = JSON.parse(fs.readFileSync(CLIENTS_FILE, 'utf-8'));
    data = data.filter((client: any) => client.id !== clientId);
    fs.writeFileSync(CLIENTS_FILE, JSON.stringify(data, null, 2));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete client' }, { status: 500 });
  }
}
