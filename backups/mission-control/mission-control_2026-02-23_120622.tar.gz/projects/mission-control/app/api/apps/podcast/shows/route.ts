import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';
import { logActivity } from '@/lib/activity';

const SHOWS_PATH = path.join(process.cwd(), 'data', 'apps', 'podcast', 'shows.json');

interface Show {
  id: string;
  name: string;
  description: string;
  hosts: string[];
  coverArtUrl: string;
  rssFeedUrl: string;
  status: 'active' | 'hiatus' | 'development' | 'archived';
  category: string;
  episodeCount: number;
  launchDate: string | null;
  frequency?: string;
}

interface ShowsData {
  shows: Show[];
}

function readShows(): ShowsData {
  if (!fs.existsSync(SHOWS_PATH)) {
    return { shows: [] };
  }
  return JSON.parse(fs.readFileSync(SHOWS_PATH, 'utf8'));
}

function writeShows(data: ShowsData) {
  fs.mkdirSync(path.dirname(SHOWS_PATH), { recursive: true });
  fs.writeFileSync(SHOWS_PATH, JSON.stringify(data, null, 2));
}

export async function GET() {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const data = readShows();
    return NextResponse.json(data.shows);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { name, description, hosts, coverArtUrl, rssFeedUrl, status, category, frequency } = body;

    if (!name) {
      return NextResponse.json({ error: 'Show name is required' }, { status: 400 });
    }

    const data = readShows();
    
    const show: Show = {
      id: name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
      name,
      description: description || '',
      hosts: hosts || [],
      coverArtUrl: coverArtUrl || '',
      rssFeedUrl: rssFeedUrl || '',
      status: status || 'development',
      category: category || 'general',
      episodeCount: 0,
      launchDate: null,
      frequency: frequency || 'weekly'
    };

    data.shows.push(show);
    writeShows(data);

    logActivity('Kevin', 'Created new podcast show', name);

    return NextResponse.json(show, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'Show ID is required' }, { status: 400 });
    }

    const data = readShows();
    const index = data.shows.findIndex(s => s.id === id);

    if (index === -1) {
      return NextResponse.json({ error: 'Show not found' }, { status: 404 });
    }

    data.shows[index] = { ...data.shows[index], ...updates };
    writeShows(data);

    logActivity('Kevin', 'Updated podcast show', data.shows[index].name);

    return NextResponse.json(data.shows[index]);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  try {
    const body = await req.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'Show ID is required' }, { status: 400 });
    }

    const data = readShows();
    const index = data.shows.findIndex(s => s.id === id);

    if (index === -1) {
      return NextResponse.json({ error: 'Show not found' }, { status: 404 });
    }

    const deletedShow = data.shows.splice(index, 1)[0];
    writeShows(data);

    logActivity('Kevin', 'Deleted podcast show', deletedShow.name);

    return NextResponse.json({ success: true, deleted: deletedShow });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
