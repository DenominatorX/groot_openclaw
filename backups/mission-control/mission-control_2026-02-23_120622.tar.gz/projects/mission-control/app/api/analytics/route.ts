import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { checkAuth } from '@/lib/api-auth';

const DATA = (f: string) => path.join(process.cwd(), 'data', f);

function readJSON(file: string) {
  try { return JSON.parse(fs.readFileSync(DATA(file), 'utf8')); }
  catch { return {}; }
}

export async function GET() {
  const auth = await checkAuth();
  if (!auth.authenticated) return auth.error!;

  const tasks = readJSON('tasks.json');
  const agents = readJSON('agents.json');
  const activity = readJSON('activity.json');
  const projects = readJSON('projects.json');
  const reports = readJSON('reports.json');

  const allTasks = tasks.tasks || [];
  const allAgents = agents.agents || [];
  const allActivity = activity.entries || [];
  const allProjects = projects.projects || [];
  const allReports = reports.reports || [];

  // Task breakdown by column
  const tasksByStatus: Record<string, number> = {};
  for (const t of allTasks) {
    tasksByStatus[t.column] = (tasksByStatus[t.column] || 0) + 1;
  }

  // Agent activity counts (from activity.json)
  const agentActions: Record<string, number> = {};
  const now = Date.now();
  const sevenDaysAgo = now - 7 * 86400000;
  for (const e of allActivity) {
    const ts = new Date(e.timestamp).getTime();
    if (ts >= sevenDaysAgo) {
      agentActions[e.agent] = (agentActions[e.agent] || 0) + 1;
    }
  }

  // Activity per day (last 7 days)
  const dailyActivity: Record<string, number> = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now - i * 86400000);
    const key = d.toISOString().slice(0, 10);
    dailyActivity[key] = 0;
  }
  for (const e of allActivity) {
    const key = new Date(e.timestamp).toISOString().slice(0, 10);
    if (key in dailyActivity) dailyActivity[key]++;
  }

  // Messages today
  const todayStr = new Date().toISOString().slice(0, 10);
  const messagesToday = allActivity.filter((e: any) => new Date(e.timestamp).toISOString().slice(0, 10) === todayStr).length;

  // Projects in progress
  const projectsInProgress = allProjects.filter((p: any) => p.status === 'in-progress').length;

  // Active agents
  const activeAgents = allAgents.filter((a: any) => a.status === 'active' || a.status === 'online').length;

  // Reports generated
  const reportsGenerated = allReports.length;

  // Task velocity: tasks completed per week (last 4 weeks mock based on complete count)
  const completedTasks = allTasks.filter((t: any) => t.column === 'complete').length;
  // We'll generate a simple trend from activity data
  const weeklyVelocity: { week: string; count: number }[] = [];
  for (let w = 3; w >= 0; w--) {
    const weekStart = now - (w + 1) * 7 * 86400000;
    const weekEnd = now - w * 7 * 86400000;
    const count = allActivity.filter((e: any) => {
      const ts = new Date(e.timestamp).getTime();
      return ts >= weekStart && ts < weekEnd && (
        e.action?.toLowerCase().includes('complete') ||
        e.action?.toLowerCase().includes('moved task')
      );
    }).length;
    const d = new Date(weekStart);
    weeklyVelocity.push({ week: `${d.getMonth() + 1}/${d.getDate()}`, count });
  }

  // Cost estimate (rough: based on agent tiers and message counts)
  const tierCosts: Record<number, number> = { 0: 0, 1: 0.015, 2: 0.003, 3: 0.005, 4: 0.0008, 5: 0.0002, 6: 0.0001 };
  let totalCostEstimate = 0;
  for (const agent of allAgents) {
    const msgs = agent.stats?.messagesExchanged || 0;
    const tokensEst = msgs * 500;
    totalCostEstimate += (tokensEst / 1000) * (tierCosts[agent.tier] || 0);
  }

  return NextResponse.json({
    summary: {
      totalTasks: allTasks.length,
      tasksByStatus,
      activeAgents,
      totalAgents: allAgents.length,
      projectsInProgress,
      totalProjects: allProjects.length,
      messagesToday,
      reportsGenerated,
      estimatedCostToday: totalCostEstimate,
    },
    agentActions,
    dailyActivity,
    weeklyVelocity,
    agents: allAgents.map((a: any) => ({
      id: a.id, name: a.name, color: a.color, tier: a.tier,
      messages: a.stats?.messagesExchanged || 0,
      tasks: a.stats?.tasksCompleted || 0,
      sessions: a.stats?.sessionsStarted || 0,
    })),
    projects: allProjects.map((p: any) => ({
      id: p.id, title: p.title, status: p.status,
      phases: (p.phases || []).length,
      completedPhases: (p.phases || []).filter((ph: any) => ph.status === 'complete' || ph.status === 'done').length,
    })),
  });
}
