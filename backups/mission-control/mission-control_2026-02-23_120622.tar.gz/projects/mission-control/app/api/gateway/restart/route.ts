import { NextRequest, NextResponse } from 'next/server';
import { checkAuth } from '@/lib/api-auth';
import { exec as execCb } from 'child_process';
import { promisify } from 'util';

const exec = promisify(execCb);

export async function POST(req: NextRequest) {
  const auth = await checkAuth();
  if (!auth.authenticated) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { stdout, stderr } = await exec('openclaw gateway restart');
    console.log('Gateway restart:', stdout, stderr);
    return NextResponse.json({ success: true, stdout, stderr });
  } catch (error: any) {
    console.error('Gateway restart failed:', error);
    return NextResponse.json({ error: error.message, stderr: error.stderr }, { status: 500 });
  }
}