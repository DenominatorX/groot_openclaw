'use client';
import { useState, useEffect } from 'react';
import { useSession, signIn } from 'next-auth/react';
import { usePathname, useRouter } from 'next/navigation';
import StatusBar from '@/components/StatusBar';
import KanbanBoard from '@/components/KanbanBoard';
import HealthPanel from '@/components/HealthPanel';
import QuickActions from '@/components/QuickActions';
import SettingsPanel from '@/components/SettingsPanel';
import AgentsSidebar from '@/components/AgentsSidebar';
import AgentProfile from '@/components/AgentProfile';
import ActivityFeed from '@/components/ActivityFeed';
import ReportsPanel from '@/components/ReportsPanel';
import AnalyticsPanel from '@/components/AnalyticsPanel';
import ChatRoom from '@/components/ChatRoom';
import WorldTab from '@/components/WorldTab';
import AgentCraftTab from '@/components/AgentCraftTab';
import MyStuffShell from '@/components/MyStuff/MyStuffShell';
import OrgChart from '@/components/OrgChart';
import ProjectsTab from '@/components/ProjectsTab';
import TeamsTab from '@/components/TeamsTab';
import AppsTab from '@/components/AppsTab';
import GamesTab from '@/components/GamesTab';
import TradingDashboard from '@/components/TradingDashboard';
import TabNavSidebar, { Tab } from '@/components/TabNavSidebar';
import GlobalChat from '@/components/GlobalChat';
import IssuesLog from '@/components/IssuesLog';
import FeaturesPanel from '@/components/FeaturesPanel';
import VcbPanel from '@/components/vcb/VcbPanel';
import HomeScreen from '@/components/HomeScreen';
import TestsDashboard from '@/components/TestsDashboard';
import BrainOrchestration from '@/components/BrainOrchestration';
import ErrorBoundary from '@/components/ErrorBoundary';
import dynamic from 'next/dynamic';
const VRMode = dynamic(() => import('@/components/VRMode'), { ssr: false, loading: () => <div className="flex items-center justify-center h-64 text-mc-muted">Loading VR...</div> });

// Map pathname to tab and component
const PATH_TAB_MAP: Record<string, Tab> = {
  '/': 'dashboard',
  '/brain': 'brain',
  '/kanban': 'kanban',
  '/projects': 'projects',
  '/teams': 'teams',
  '/issues': 'issues',
  '/reports': 'reports',
  '/analytics': 'analytics',
  '/chat': 'chat',
  '/health': 'health',
  '/home': 'home',
  '/world': 'world',
  '/agentcraft': 'agentcraft',
  '/my-stuff': 'my-stuff',
  '/apps': 'apps',
  '/games': 'games',
  '/trading': 'trading',
  '/features': 'features',
  '/vr': 'vr',
  '/tests': 'tests',
  '/vcb': 'vcb',
};

// Tab title map for h1
const TAB_TITLES: Record<Tab, string> = {
  dashboard: '🧠 Home',
  kanban: '📋 Task Board',
  trading: '📈 Trading',
  projects: '📁 Projects',
  teams: '👥 Project Teams',
  issues: '🛡️ Issues Log',
  reports: '📄 Reports',
  analytics: '📊 Analytics',
  chat: '💬 Chat',
  health: '❤️ Health Dashboard',
  home: '💡 Smart Home',
  world: '🌍 Agent World',
  agentcraft: '🏰 AgentCraft',
  'my-stuff': '🗂️ My Stuff',
  apps: '📱 Apps',
  games: '🎮 Games',
  features: '🧩 Features & Config',
  vr: '🥽 VR Mode',
  tests: '🧪 Tests',
  vcb: '🌿 Visual Branching',
  brain: '🧠 Brain',
};

export default function Dashboard() {
  const { data: session, status: sessionStatus } = useSession();
  const pathname = usePathname();
  const router = useRouter();
  
  // Derive tab from pathname
  const activeTab: Tab = PATH_TAB_MAP[pathname] || 'dashboard';
  
  const setTab = (t: Tab) => {
    localStorage.setItem('mc-active-tab', t);
    router.push(`/${t === 'dashboard' ? '' : t}`);
  };
  
  const [showSettings, setShowSettings] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(true);
  const [feedCollapsed, setFeedCollapsed] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [showOrgChart, setShowOrgChart] = useState(false);
  const [showNewIdea, setShowNewIdea] = useState(false);
  const [newIdea, setNewIdea] = useState('');
  const [currentContext, setCurrentContext] = useState('');

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // Auto-detect VR headset (Quest, Vision Pro) and default to VR tab
  useEffect(() => {
    const detectVR = async () => {
      // Check user agent for Quest browser
      const ua = navigator.userAgent.toLowerCase();
      const isQuest = ua.includes('oculusbrowser') || ua.includes('quest');
      if (isQuest) { setTab('vr' as Tab); return; }
      // Check WebXR support
      if ('xr' in navigator) {
        try {
          const supported = await (navigator as any).xr.isSessionSupported('immersive-vr');
          if (supported) setTab('vr' as Tab);
        } catch {}
      }
    };
    detectVR();
  }, []);

  // Auth is handled via useSession — gated below
  useEffect(() => {
    setAuthChecked(true);
  }, []);

  // ── Loading state ──
  if (sessionStatus === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-mc-bg">
        <div className="text-mc-muted text-sm animate-pulse">⚡ Loading...</div>
      </div>
    );
  }

  // ── Unauthenticated landing page ──
  if (!session) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-mc-bg text-mc-text px-4">
        <div className="max-w-lg w-full text-center space-y-8">
          {/* Brand */}
          <div className="space-y-2">
            <div className="text-5xl font-black text-mc-accent tracking-tight">⚡ Mission Control</div>
            <p className="text-mc-muted text-sm">Your personal AI command center</p>
          </div>

          {/* Feature teaser */}
          <div className="grid grid-cols-3 gap-4 py-4">
            {[
              { icon: '🤖', label: 'AI Agents' },
              { icon: '📋', label: 'Task Board' },
              { icon: '❤️', label: 'Health' },
              { icon: '📊', label: 'Analytics' },
              { icon: '💬', label: 'Chat' },
              { icon: '🌍', label: 'Agent World' },
            ].map(f => (
              <div key={f.label} className="bg-mc-surface border border-mc-border rounded-lg p-3 flex flex-col items-center gap-1.5 opacity-60">
                <span className="text-2xl">{f.icon}</span>
                <span className="text-[11px] text-mc-muted">{f.label}</span>
              </div>
            ))}
          </div>

          {/* Sign in */}
          <div className="space-y-3">
            <button
              onClick={() => signIn()}
              className="w-full py-3 px-6 bg-mc-accent hover:bg-mc-accent/90 text-white font-semibold rounded-lg text-sm transition-colors shadow-lg"
            >
              🔐 Sign In to Mission Control
            </button>
            <p className="text-[11px] text-mc-muted">Authorized access only.</p>
          </div>
        </div>
      </div>
    );
  }

  // Derive title from pathname
  const pageTitle = TAB_TITLES[activeTab] || '🧠 Home';

  return (
    <div className="min-h-screen flex flex-col">
      <StatusBar />
      
      {/* Tab Navigation Sidebar */}
      <TabNavSidebar activeTab={activeTab} onTabChange={(t) => {
        if (t === '_new' as Tab) { setShowNewIdea(true); return; }
        setTab(t); setCurrentContext(''); document.querySelector('main')?.scrollTo(0, 0);
      }} isMobile={isMobile} pathname={pathname} />

      {/* Top Control Bar */}
      <div className="flex items-center justify-between px-2 md:px-4 py-1.5 bg-mc-surface border-b border-mc-border transition-all duration-300 md:ml-16">
        <h1 className="text-sm md:text-base font-bold text-mc-text whitespace-nowrap">
          {pageTitle}
        </h1>
        <div className="flex gap-1 md:gap-2 flex-shrink-0">
          {isMobile ? (
            <button onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="px-2 py-1.5 text-sm text-mc-muted hover:text-mc-text rounded">
              ☰
            </button>
          ) : (
            <>
              <button onClick={() => setSidebarCollapsed(c => !c)}
                className="px-2 py-1.5 text-xs text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
                title="Toggle agents sidebar">
                👥
              </button>
              <button onClick={() => setFeedCollapsed(c => !c)}
                className="px-2 py-1.5 text-xs text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
                title="Toggle activity feed">
                📡
              </button>
              <button onClick={() => setShowOrgChart(true)}
                className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors" title="Org Chart">
                🏢
              </button>
              <button onClick={() => setShowSettings(true)}
                className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
                title="Settings">
                ⚙️
              </button>
              <button onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.href = '/login'; }}
                className="px-3 py-1.5 text-sm text-mc-muted hover:text-red-400 hover:bg-mc-bg rounded transition-colors"
                title="Logout">
                🔒
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile menu dropdown */}
      {isMobile && showMobileMenu && (
        <div className="bg-mc-surface border-b border-mc-border px-4 py-2 flex flex-wrap gap-2">
          <button onClick={() => { setSidebarCollapsed(c => !c); setShowMobileMenu(false); }}
            className="px-3 py-1.5 text-xs bg-mc-bg border border-mc-border rounded">👥 Agents</button>
          <button onClick={() => { setFeedCollapsed(c => !c); setShowMobileMenu(false); }}
            className="px-3 py-1.5 text-xs bg-mc-bg border border-mc-border rounded">📡 Activity</button>
          <button onClick={() => { setShowSettings(true); setShowMobileMenu(false); }}
            className="px-3 py-1.5 text-xs bg-mc-bg border border-mc-border rounded">⚙️ Settings</button>
          <button onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.href = '/login'; }}
            className="px-3 py-1.5 text-xs bg-mc-bg border border-mc-border rounded text-red-400">🔒 Logout</button>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden transition-all duration-300 md:ml-16">
        {!isMobile && <AgentsSidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(c => !c)} onSelectAgent={setSelectedAgentId} onShowOrgChart={() => setShowOrgChart(true)} />}
        
        <main className={`flex-1 p-2 md:p-3 overflow-y-auto ${isMobile ? 'pb-20' : ''}`}>
          <ErrorBoundary>
          {activeTab === 'dashboard' && <HomeScreen onNavigate={(t) => setTab(t as Tab)} />}
          {activeTab === 'kanban' && (
            <div>
              <KanbanBoard />
            </div>
          )}
          {activeTab === 'trading' && (
            <div>
              <TradingDashboard />
            </div>
          )}
          {activeTab === 'projects' && (
            <div>
              <ProjectsTab />
            </div>
          )}
          {activeTab === 'teams' && (
            <div>
              <TeamsTab />
            </div>
          )}
          {activeTab === 'apps' && (
            <div>
              <AppsTab />
            </div>
          )}
          {activeTab === 'reports' && <ReportsPanel />}
          {activeTab === 'analytics' && <AnalyticsPanel />}
          {activeTab === 'chat' && <ChatRoom />}
          {activeTab === 'health' && <HealthPanel />}
          {activeTab === 'home' && <QuickActions />}
          {activeTab === 'world' && (
            <WorldTab onSelectAgent={setSelectedAgentId} />
          )}
          {activeTab === 'my-stuff' && <MyStuffShell />}
          {activeTab === 'agentcraft' && (
            <div className="p-4 text-mc-muted">AgentCraft moved to My Stuff → 🗂️</div>
          )}
          {activeTab === 'games' && (
            <div>
              <GamesTab />
            </div>
          )}
          {activeTab === 'issues' && (
            <div>
              <IssuesLog />
            </div>
          )}
          {activeTab === 'brain' && <BrainOrchestration />}
          {activeTab === 'vcb' && <VcbPanel />}
          {activeTab === 'tests' && (
            <div>
              <TestsDashboard />
            </div>
          )}
          {activeTab === 'features' && (
            <div>
              <FeaturesPanel />
            </div>
          )}
          {activeTab === 'vr' && (
            <VRMode />
          )}
          </ErrorBoundary>
        </main>

        {!isMobile && <ActivityFeed collapsed={feedCollapsed} onToggle={() => setFeedCollapsed(c => !c)} />}
      </div>

      {/* Mobile slide-out panels */}
      {isMobile && !sidebarCollapsed && (
        <div className="fixed inset-0 z-40 bg-black/60" onClick={() => setSidebarCollapsed(true)}>
          <div className="absolute left-0 top-0 bottom-0 w-64 bg-mc-surface border-r border-mc-border overflow-y-auto" onClick={e => e.stopPropagation()}>
            <AgentsSidebar collapsed={false} onToggle={() => setSidebarCollapsed(true)} onSelectAgent={setSelectedAgentId} onShowOrgChart={() => { setSidebarCollapsed(true); setShowOrgChart(true); }} />
          </div>
        </div>
      )}
      {isMobile && !feedCollapsed && (
        <div className="fixed inset-0 z-40 bg-black/60" onClick={() => setFeedCollapsed(true)}>
          <div className="absolute right-0 top-0 bottom-0 w-72 bg-mc-surface border-l border-mc-border overflow-y-auto" onClick={e => e.stopPropagation()}>
            <ActivityFeed collapsed={false} onToggle={() => setFeedCollapsed(true)} />
          </div>
        </div>
      )}

      {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} />}

      {/* Org Chart Modal */}
      {showOrgChart && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setShowOrgChart(false)}>
          <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-5xl max-h-[90vh] overflow-auto shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-3 border-b border-mc-border">
              <h2 className="text-lg font-bold">📊 Organization Chart</h2>
              <button onClick={() => setShowOrgChart(false)} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
            </div>
            <OrgChart onSelectAgent={(id) => { setShowOrgChart(false); setSelectedAgentId(id); }} />
          </div>
        </div>
      )}

      {/* Agent Profile Modal — rendered at root level for proper z-index */}
      {selectedAgentId && <AgentProfile agentId={selectedAgentId} onClose={() => setSelectedAgentId(null)} onSelectAgent={(id) => setSelectedAgentId(id)} />}

      {/* Global Floating Chat */}
      <GlobalChat currentTab={activeTab} currentContext={currentContext} />

      {/* New Idea Dialog */}
      {showNewIdea && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center" onClick={() => setShowNewIdea(false)}>
          <div className="bg-mc-surface border border-mc-border rounded-lg w-[500px] max-w-[90vw] shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="px-4 py-3 border-b border-mc-border flex items-center justify-between">
              <h2 className="font-bold">💡 New Idea</h2>
              <button onClick={() => setShowNewIdea(false)} className="text-mc-muted hover:text-mc-text">✕</button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-xs text-mc-muted">Describe your idea and the Design Agent will help build it into a new MC page.</p>
              <textarea value={newIdea} onChange={e => setNewIdea(e.target.value)}
                rows={5} placeholder="I want a page that..." autoFocus
                className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm resize-none" />
              <div className="flex gap-2">
                <button onClick={() => {
                  if (newIdea.trim()) {
                    // Save as an enhancement issue for Sentinel to work
                    fetch('/api/issues', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        action: 'create',
                        title: `New Page Idea: ${newIdea.slice(0, 60)}`,
                        description: newIdea,
                        category: 'enhancement',
                        priority: 'medium',
                      }),
                    }).then(() => {
                      setNewIdea(''); setShowNewIdea(false);
                      setTab('issues'); // Navigate to issues to see it
                    });
                  }
                }} className="px-4 py-2 bg-mc-accent text-white rounded text-sm hover:bg-mc-accent/80">
                  🚀 Submit Idea
                </button>
                <button onClick={() => setShowNewIdea(false)} className="px-4 py-2 text-mc-muted text-sm">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}