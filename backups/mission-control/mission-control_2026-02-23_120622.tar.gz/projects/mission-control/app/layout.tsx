import type { Metadata } from 'next'
import './globals.css'
import { ToastDisplay } from '@/lib/error-handling/toast-display'
import { Providers } from '@/components/Providers'
import dynamic from 'next/dynamic'
import { cookies } from 'next/headers'

// Dynamic import for GlobalSearch to avoid SSR issues
const GlobalSearch = dynamic(() => import('@/components/GlobalSearch'), { ssr: false })

export const metadata: Metadata = {
  title: 'Mission Control v3',
  description: 'Personal command center',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Read theme cookie server-side so the HTML is rendered with the correct theme
  // before any JS runs — eliminates the dark flash entirely
  const cookieStore = cookies()
  const initialTheme = cookieStore.get('mc-theme')?.value || 'dark'

  return (
    <html lang="en" data-theme={initialTheme} suppressHydrationWarning>
      <body className="min-h-screen">
        <script dangerouslySetInnerHTML={{ __html: `
          try {
            var ls = localStorage.getItem('mc-theme');
            if (ls) {
              document.documentElement.setAttribute('data-theme', ls);
              document.cookie = 'mc-theme=' + ls + '; path=/; max-age=31536000; SameSite=Lax';
            } else {
              fetch('/api/settings').then(function(r){return r.json();}).then(function(d){
                var t = (d.raw && d.raw.theme) || (d.settings && d.settings.theme);
                if (t) {
                  document.documentElement.setAttribute('data-theme', t);
                  try { localStorage.setItem('mc-theme', t); } catch(e){}
                  document.cookie = 'mc-theme=' + t + '; path=/; max-age=31536000; SameSite=Lax';
                }
              }).catch(function(){});
            }
          } catch(e){}
        `}} />
        <Providers>
          {children}
        </Providers>
        <ToastDisplay />
        <GlobalSearch />
      </body>
    </html>
  )
}
