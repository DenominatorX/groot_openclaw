'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Legacy login page - redirects to new Google OAuth sign-in
 * Keeping this route for backwards compatibility
 */
export default function LoginPage() {
  const router = useRouter();

  useEffect(() => {
    // Redirect to new Google OAuth sign-in
    router.replace('/auth/signin');
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-mc-bg">
      <div className="text-mc-muted">Redirecting to sign-in...</div>
    </div>
  );
}
