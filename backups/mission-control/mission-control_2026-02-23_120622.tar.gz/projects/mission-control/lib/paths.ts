import * as path from 'path';
import * as os from 'os';

// All configurable paths — override via environment variables
export const PATHS = {
  // OpenClaw workspace
  OPENCLAW_WORKSPACE: process.env.OPENCLAW_WORKSPACE || path.join(os.homedir(), '.openclaw', 'workspace'),
  
  // OpenClaw config
  OPENCLAW_CONFIG: process.env.OPENCLAW_CONFIG || path.join(os.homedir(), '.openclaw', 'openclaw.json'),
  
  // Mission Control data directory
  MC_DATA_DIR: process.env.MC_DATA_DIR || path.join(process.cwd(), 'data'),
  
  // Mission Control project root
  MC_ROOT: process.env.MC_ROOT || process.cwd(),
  
  // User home directory
  HOME: os.homedir(),
};

// Helper to resolve a path relative to openclaw workspace
export function workspacePath(...segments: string[]): string {
  return path.join(PATHS.OPENCLAW_WORKSPACE, ...segments);
}

// Helper to resolve a path relative to MC data dir
export function dataPath(...segments: string[]): string {
  return path.join(PATHS.MC_DATA_DIR, ...segments);
}

// Helper to resolve a path relative to MC root
export function mcPath(...segments: string[]): string {
  return path.join(PATHS.MC_ROOT, ...segments);
}
