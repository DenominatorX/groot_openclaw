/**
 * Migration script: JSON to SQLite
 * Reads existing JSON files from data/ and inserts them into SQLite.
 * Idempotent - skips if data already exists.
 */
import fs from 'fs';
import path from 'path';
import { getDb } from './database';

const DATA_DIR = path.join(process.cwd(), 'data');

interface MigrationStats {
  agents: number;
  agentTiers: number;
  projects: number;
  tasks: number;
  issues: number;
  settings: number;
  activity: number;
  agentSessions: number;
}

function fileExists(filepath: string): boolean {
  try {
    return fs.existsSync(filepath);
  } catch {
    return false;
  }
}

function readJsonFile<T>(filename: string): T | null {
  const filepath = path.join(DATA_DIR, filename);
  if (!fileExists(filepath)) {
    console.log(`  File not found: ${filename}, skipping`);
    return null;
  }
  try {
    const content = fs.readFileSync(filepath, 'utf8');
    return JSON.parse(content);
  } catch (err) {
    console.error(`  Error reading ${filename}:`, err);
    return null;
  }
}

function migrateAgents(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<{ tiers: Record<string, any>; agents: any[] }>('agents.json');
  if (!data) return 0;

  let count = 0;

  // Migrate tiers
  if (data.tiers) {
    const insertTier = db.prepare(`
      INSERT OR IGNORE INTO agent_tiers (tier_id, data) VALUES (?, ?)
    `);
    for (const [tierId, tierData] of Object.entries(data.tiers)) {
      insertTier.run(tierId, JSON.stringify(tierData));
      count++;
    }
    console.log(`  Migrated ${Object.keys(data.tiers).length} agent tiers`);
  }

  // Migrate agents
  if (data.agents) {
    const insertAgent = db.prepare(`
      INSERT OR IGNORE INTO agents (id, data) VALUES (?, ?)
    `);
    for (const agent of data.agents) {
      insertAgent.run(agent.id, JSON.stringify(agent));
      count++;
    }
    console.log(`  Migrated ${data.agents.length} agents`);
  }

  return count;
}

function migrateProjects(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<{ projects: any[] }>('projects.json');
  if (!data || !data.projects) return 0;

  const insertProject = db.prepare(`
    INSERT OR IGNORE INTO projects (id, data) VALUES (?, ?)
  `);

  let count = 0;
  for (const project of data.projects) {
    insertProject.run(project.id, JSON.stringify(project));
    count++;
  }
  console.log(`  Migrated ${count} projects`);
  return count;
}

function migrateTasks(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<{ columns: string[]; tasks: any[] }>('tasks.json');
  if (!data || !data.tasks) return 0;

  // First, save the columns as a setting
  if (data.columns) {
    const insertSetting = db.prepare(`
      INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
    `);
    insertSetting.run('taskColumns', JSON.stringify(data.columns));
  }

  // Migrate tasks
  const insertTask = db.prepare(`
    INSERT OR IGNORE INTO tasks (id, project_id, data) VALUES (?, ?, ?)
  `);

  let count = 0;
  for (const task of data.tasks) {
    // Extract project_id if task has one, otherwise null
    const projectId = (task as any).projectId || null;
    insertTask.run(task.id, projectId, JSON.stringify(task));
    count++;
  }
  console.log(`  Migrated ${count} tasks`);
  return count;
}

function migrateIssues(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<{ issues: any[]; categories: string[] }>('issues.json');
  if (!data || !data.issues) return 0;

  // Save categories as a setting
  if (data.categories) {
    const insertSetting = db.prepare(`
      INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
    `);
    insertSetting.run('issueCategories', JSON.stringify(data.categories));
  }

  // Migrate issues
  const insertIssue = db.prepare(`
    INSERT OR IGNORE INTO issues (id, data) VALUES (?, ?)
  `);

  let count = 0;
  for (const issue of data.issues) {
    insertIssue.run(issue.id, JSON.stringify(issue));
    count++;
  }
  console.log(`  Migrated ${count} issues`);
  return count;
}

function migrateSettings(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<any>('settings.json');
  if (!data) return 0;

  const insertSetting = db.prepare(`
    INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
  `);

  let count = 0;
  // Migrate top-level settings (excluding nested objects we'll handle separately)
  const topLevelKeys = ['port', 'theme'];
  for (const key of topLevelKeys) {
    if (data[key] !== undefined) {
      insertSetting.run(key, JSON.stringify(data[key]));
      count++;
    }
  }

  // Migrate nested objects as JSON strings
  if (data.apiKeys) {
    insertSetting.run('apiKeys', JSON.stringify(data.apiKeys));
    count++;
  }
  if (data.endpoints) {
    insertSetting.run('endpoints', JSON.stringify(data.endpoints));
    count++;
  }

  console.log(`  Migrated ${count} settings entries`);
  return count;
}

function migrateActivity(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<{ entries: any[] }>('activity.json');
  if (!data || !data.entries) return 0;

  const insertActivity = db.prepare(`
    INSERT INTO activity_log (type, agent_id, description, metadata, created_at) 
    VALUES (?, ?, ?, ?, ?)
  `);

  let count = 0;
  for (const entry of data.entries) {
    // Map JSON structure to database schema
    // type = action, agent_id = agent, description = details, metadata = null, created_at = timestamp
    insertActivity.run(
      entry.action || 'unknown',
      entry.agent || null,
      entry.details || '',
      null, // metadata - not present in original format
      entry.timestamp || null
    );
    count++;
  }
  console.log(`  Migrated ${count} activity entries`);
  return count;
}

function migrateAgentSessions(db: ReturnType<typeof getDb>): number {
  const data = readJsonFile<{ sessions: Record<string, any>; history: any[] }>('agent-sessions.json');
  if (!data || !data.sessions) return 0;

  const insertSession = db.prepare(`
    INSERT OR IGNORE INTO agent_session_state 
    (agent_id, status, current_task, last_task_at, tasks_completed, model) 
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  let count = 0;
  for (const [agentId, session] of Object.entries(data.sessions)) {
    insertSession.run(
      agentId,
      session.status || 'idle',
      session.currentTask || null,
      session.lastTaskAt || null,
      session.tasksCompleted || 0,
      session.model || null
    );
    count++;
  }
  console.log(`  Migrated ${count} agent session states`);
  return count;
}

function checkAlreadyMigrated(db: ReturnType<typeof getDb>): boolean {
  // Check if we already have data by counting rows in a few tables
  const agentCount = db.prepare('SELECT COUNT(*) as count FROM agents').get() as { count: number };
  const projectCount = db.prepare('SELECT COUNT(*) as count FROM projects').get() as { count: number };
  
  return agentCount.count > 0 || projectCount.count > 0;
}

export function runMigration(): MigrationStats {
  console.log('\n📦 Starting JSON → SQLite migration...\n');

  const db = getDb();

  // Check if already migrated
  if (checkAlreadyMigrated(db)) {
    console.log('⚠️  Data already appears to be migrated. Skipping to avoid duplicates.');
    console.log('   To re-migrate, delete the database file and run again.\n');
    return {
      agents: 0,
      agentTiers: 0,
      projects: 0,
      tasks: 0,
      issues: 0,
      settings: 0,
      activity: 0,
      agentSessions: 0
    };
  }

  const stats: MigrationStats = {
    agents: 0,
    agentTiers: 0,
    projects: 0,
    tasks: 0,
    issues: 0,
    settings: 0,
    activity: 0,
    agentSessions: 0
  };

  // Run migrations
  console.log('Migrating agents (incl. tiers)...');
  stats.agents = migrateAgents(db);

  console.log('\nMigrating projects...');
  stats.projects = migrateProjects(db);

  console.log('\nMigrating tasks...');
  stats.tasks = migrateTasks(db);

  console.log('\nMigrating issues...');
  stats.issues = migrateIssues(db);

  console.log('\nMigrating settings...');
  stats.settings = migrateSettings(db);

  console.log('\nMigrating activity log...');
  stats.activity = migrateActivity(db);

  console.log('\nMigrating agent sessions...');
  stats.agentSessions = migrateAgentSessions(db);

  console.log('\n✅ Migration complete!');
  console.log(`
  Stats:
  - Agents: ${stats.agents}
  - Agent Tiers: ${stats.agentTiers}
  - Projects: ${stats.projects}
  - Tasks: ${stats.tasks}
  - Issues: ${stats.issues}
  - Settings: ${stats.settings}
  - Activity entries: ${stats.activity}
  - Agent Sessions: ${stats.agentSessions}
  `);

  return stats;
}

// Run if executed directly
if (require.main === module) {
  runMigration();
}
