import { getIronSession, IronSession } from 'iron-session';
import { cookies } from 'next/headers';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';

const AUTH_PATH = path.join(process.cwd(), 'data', 'auth.json');

// Session password — auto-generated on first run, stored in auth.json
interface AuthConfig {
  passwordHash: string;
  sessionSecret: string;
  failedAttempts: number;
  lockoutUntil: number | null;
  createdAt: string;
}

interface SessionData {
  authenticated: boolean;
  loginTime: number;
}

// User type for multi-tenant filtering
export interface SessionUser {
  id: string;
  role: 'admin' | 'user' | 'viewer';
  email?: string;
}

function getAuthConfig(): AuthConfig {
  if (!fs.existsSync(AUTH_PATH)) {
    // First run — no password set yet
    const config: AuthConfig = {
      passwordHash: '',
      sessionSecret: crypto.randomBytes(32).toString('hex'),
      failedAttempts: 0,
      lockoutUntil: null,
      createdAt: new Date().toISOString(),
    };
    fs.writeFileSync(AUTH_PATH, JSON.stringify(config, null, 2));
    return config;
  }
  return JSON.parse(fs.readFileSync(AUTH_PATH, 'utf8'));
}

function saveAuthConfig(config: AuthConfig) {
  fs.writeFileSync(AUTH_PATH, JSON.stringify(config, null, 2));
}

export async function setPassword(password: string): Promise<void> {
  if (password.length < 8) throw new Error('Password must be at least 8 characters');
  const config = getAuthConfig();
  config.passwordHash = await bcrypt.hash(password, 12);
  config.failedAttempts = 0;
  config.lockoutUntil = null;
  saveAuthConfig(config);
}

export async function verifyPassword(password: string): Promise<boolean> {
  const config = getAuthConfig();
  
  // Check lockout
  if (config.lockoutUntil && Date.now() < config.lockoutUntil) {
    const remaining = Math.ceil((config.lockoutUntil - Date.now()) / 1000);
    throw new Error(`Account locked. Try again in ${remaining} seconds.`);
  }

  if (!config.passwordHash) {
    throw new Error('NO_PASSWORD_SET');
  }

  const valid = await bcrypt.compare(password, config.passwordHash);
  
  if (!valid) {
    config.failedAttempts++;
    if (config.failedAttempts >= 5) {
      config.lockoutUntil = Date.now() + (5 * 60 * 1000); // 5 min lockout
      config.failedAttempts = 0;
    }
    saveAuthConfig(config);
    return false;
  }

  // Reset on success
  config.failedAttempts = 0;
  config.lockoutUntil = null;
  saveAuthConfig(config);
  return true;
}

export function isPasswordSet(): boolean {
  const config = getAuthConfig();
  return !!config.passwordHash;
}

export function getSessionSecret(): string {
  return getAuthConfig().sessionSecret;
}

export async function getSession(): Promise<IronSession<SessionData>> {
  const secret = getSessionSecret();
  const session = await getIronSession<SessionData>(await cookies(), {
    password: secret,
    cookieName: 'mc_session',
    cookieOptions: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24, // 24 hours
    },
  });
  return session;
}

export async function requireAuth(): Promise<boolean> {
  const session = await getSession();
  return session.authenticated === true;
}

/**
 * Get the current user from session (NextAuth or iron-session)
 * Returns null if not authenticated
 * For admin role, returns all data (no filtering)
 */
export async function getUserFromSession(): Promise<SessionUser | null> {
  // Try NextAuth session first (OAuth users)
  try {
    const nextAuthSession = await getServerSession(authOptions);
    if (nextAuthSession?.user?.id) {
      return {
        id: nextAuthSession.user.id,
        role: nextAuthSession.user.role || 'user',
        email: nextAuthSession.user.email,
      };
    }
  } catch {
    // NextAuth not configured or not available, continue to iron-session
  }

  // Fall back to iron-session (password auth)
  try {
    const session = await getSession();
    if (session.authenticated) {
      // For password auth, use a default user ID
      // In production, this should be linked to the users table
      return {
        id: '7904b809-5e4b-4018-9d1b-998305e58678', // Kevin's ID
        role: 'admin', // Password auth users are admins by default
      };
    }
  } catch {
    // Session not available
  }

  return null;
}
