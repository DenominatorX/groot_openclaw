import * as crypto from 'crypto';
import { getDb } from './database';

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const SALT_LENGTH = 32;
const TAG_LENGTH = 16;

// Master key derived from MC_MASTER_KEY env var or a default for local dev
function getMasterKey(): Buffer {
  const masterPassword = process.env.MC_MASTER_KEY || 'mission-control-local-dev-key';
  // In production, this would come from user login session
  return crypto.pbkdf2Sync(masterPassword, 'mc-salt-v1', 100000, KEY_LENGTH, 'sha512');
}

export function encryptSecret(plaintext: string): { encrypted: string; iv: string; salt: string } {
  const iv = crypto.randomBytes(IV_LENGTH);
  const salt = crypto.randomBytes(SALT_LENGTH);
  const key = getMasterKey();
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  let encrypted = cipher.update(plaintext, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const tag = cipher.getAuthTag();
  return {
    encrypted: encrypted + tag.toString('hex'),
    iv: iv.toString('hex'),
    salt: salt.toString('hex')
  };
}

export function decryptSecret(encrypted: string, iv: string): string {
  const key = getMasterKey();
  const encData = encrypted.slice(0, -TAG_LENGTH * 2);
  const tag = Buffer.from(encrypted.slice(-TAG_LENGTH * 2), 'hex');
  const decipher = crypto.createDecipheriv(ALGORITHM, key, Buffer.from(iv, 'hex'));
  decipher.setAuthTag(tag);
  let decrypted = decipher.update(encData, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

export function maskKey(value: string): string {
  if (value.length <= 8) return '****';
  return value.slice(0, 6) + '****' + value.slice(-4);
}

export function storeSecret(key: string, value: string, label?: string) {
  const { encrypted, iv, salt } = encryptSecret(value);
  const masked = maskKey(value);
  const db = getDb();
  db.prepare(`
    INSERT OR REPLACE INTO secrets (key, value, label, masked, salt, iv, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
  `).run(key, encrypted, label || key, masked, salt, iv);
}

export function getSecret(key: string): string | null {
  const db = getDb();
  const row = db.prepare('SELECT value, iv FROM secrets WHERE key = ?').get(key) as any;
  if (!row) return null;
  return decryptSecret(row.value, row.iv);
}

export function listSecrets(): Array<{ key: string; label: string; masked: string; updated_at: string }> {
  const db = getDb();
  return db.prepare('SELECT key, label, masked, updated_at FROM secrets').all() as any[];
}

export function deleteSecret(key: string): boolean {
  const db = getDb();
  const result = db.prepare('DELETE FROM secrets WHERE key = ?').run(key);
  return result.changes > 0;
}

export function getSecretMetadata(key: string): { key: string; label: string; masked: string; updated_at: string } | null {
  const db = getDb();
  const row = db.prepare('SELECT key, label, masked, updated_at FROM secrets WHERE key = ?').get(key) as any;
  return row || null;
}
