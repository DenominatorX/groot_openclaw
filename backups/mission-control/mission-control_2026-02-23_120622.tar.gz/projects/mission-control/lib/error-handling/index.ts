// Error Handling Framework
// Provides: Toast notifications, retry logic, error boundaries

import React, { createContext, useContext, useCallback, ReactNode } from 'react';
import { useAppStore, Toast, ToastType } from '../stores/app-store';

// Toast System
// ============

interface ToastOptions {
  type?: ToastType;
  duration?: number;
  dismissible?: boolean;
}

export function useToast() {
  const { addToast, removeToast, clearToasts } = useAppStore();

  const toast = useCallback(
    (message: string, options: ToastOptions = {}) => {
      const { type = 'info', duration = 5000, dismissible = true } = options;
      addToast({ message, type, duration, dismissible });
    },
    [addToast]
  );

  const success = useCallback(
    (message: string, options?: ToastOptions) => toast(message, { ...options, type: 'success' }),
    [toast]
  );

  const error = useCallback(
    (message: string, options?: ToastOptions) => toast(message, { ...options, type: 'error' }),
    [toast]
  );

  const warning = useCallback(
    (message: string, options?: ToastOptions) => toast(message, { ...options, type: 'warning' }),
    [toast]
  );

  const info = useCallback(
    (message: string, options?: ToastOptions) => toast(message, { ...options, type: 'info' }),
    [toast]
  );

  return { toast, success, error, warning, info, clearToasts, removeToast };
}

// Retry Logic
// ===========

interface RetryOptions {
  maxRetries?: number;
  delay?: number;
  backoff?: number;
  onRetry?: (attempt: number, error: Error) => void;
  onSuccess?: () => void;
  onFinalError?: (error: Error) => void;
}

const DEFAULT_RETRY_OPTIONS: Required<RetryOptions> = {
  maxRetries: 3,
  delay: 1000,
  backoff: 2,
  onRetry: () => {},
  onSuccess: () => {},
  onFinalError: () => {},
};

export async function withRetry<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const {
    maxRetries,
    delay,
    backoff,
    onRetry,
    onSuccess,
    onFinalError,
  } = { ...DEFAULT_RETRY_OPTIONS, ...options };

  let lastError: Error;
  let currentDelay = delay;

  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
    try {
      const result = await fn();
      if (attempt > 1) {
        onSuccess();
      }
      return result;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));

      if (attempt > maxRetries) {
        onFinalError(lastError);
        throw lastError;
      }

      onRetry(attempt, lastError);
      await new Promise((resolve) => setTimeout(resolve, currentDelay));
      currentDelay *= backoff;
    }
  }

  throw lastError!;
}

// React hook for retry
export function useRetry<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): {
  execute: () => Promise<T | null>;
  isRetrying: boolean;
  error: Error | null;
  attempt: number;
} {
  const [isRetrying, setIsRetrying] = React.useState(false);
  const [error, setError] = React.useState<Error | null>(null);
  const [attempt, setAttempt] = React.useState(0);

  const execute = useCallback(async () => {
    setIsRetrying(true);
    setError(null);

    try {
      const result = await withRetry(fn, {
        ...options,
        onRetry: (att, err) => {
          setAttempt(att);
          options.onRetry?.(att, err);
        },
        onFinalError: (err) => {
          setError(err);
          options.onFinalError?.(err);
        },
      });
      return result;
    } catch (err) {
      return null;
    } finally {
      setIsRetrying(false);
    }
  }, [fn, options]);

  return { execute, isRetrying, error, attempt };
}

// Error Boundary Context
// ======================

interface ErrorBoundaryContextValue {
  handleError: (error: Error, context?: string) => void;
  clearError: () => void;
  error: Error | null;
  errorContext: string | null;
}

const ErrorBoundaryContext = createContext<ErrorBoundaryContextValue | null>(null);

export function ErrorBoundaryProvider({ children }: { children: ReactNode }) {
  const [error, setError] = React.useState<Error | null>(null);
  const [errorContext, setErrorContext] = React.useState<string | null>(null);

  const handleError = useCallback((err: Error, context?: string) => {
    console.error('[ErrorBoundary]', err, context);
    setError(err);
    setErrorContext(context ?? null);
  }, []);

  const clearError = useCallback(() => {
    setError(null);
    setErrorContext(null);
  }, []);

  return (
    <ErrorBoundaryContext.Provider value={{ handleError, clearError, error, errorContext }}>
      {children}
    </ErrorBoundaryContext.Provider>
  );
}

export function useErrorBoundary() {
  const context = useContext(ErrorBoundaryContext);
  if (!context) {
    throw new Error('useErrorBoundary must be used within ErrorBoundaryProvider');
  }
  return context;
}

// API Error Handler
// =================

import { ErrorCodes, ApiError } from '../api-response';
import { useToast } from './toast';

export function useApiError() {
  const { error: showError } = useToast();

  const handleApiError = useCallback(
    (apiError: ApiError | Error | unknown, fallbackMessage = 'An error occurred') => {
      if ('code' in (apiError as ApiError)) {
        const err = apiError as ApiError;
        showError(err.message);
        return err;
      }

      const message = apiError instanceof Error ? apiError.message : fallbackMessage;
      showError(message);
      return null;
    },
    [showError]
  );

  const isAuthError = useCallback((apiError: ApiError | unknown) => {
    if (!('code' in (apiError as ApiError))) return false;
    const err = apiError as ApiError;
    return err.code === ErrorCodes.UNAUTHORIZED || err.code === ErrorCodes.SESSION_EXPIRED;
  }, []);

  const isForbiddenError = useCallback((apiError: ApiError | unknown) => {
    if (!('code' in (apiError as ApiError))) return false;
    const err = apiError as ApiError;
    return err.code === ErrorCodes.FORBIDDEN || err.code === ErrorCodes.INSUFFICIENT_PERMISSIONS;
  }, []);

  return { handleApiError, isAuthError, isForbiddenError };
}

// Export toast component separately
export { ToastDisplay } from './toast-display';