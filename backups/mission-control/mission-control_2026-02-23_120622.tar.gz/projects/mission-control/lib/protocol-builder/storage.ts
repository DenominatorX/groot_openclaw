/**
 * Protocol Builder Storage
 * Handles reading/writing project protocol overrides
 */

import fs from 'fs';
import path from 'path';
import { ProtocolConfig } from './types';
import { validateProtocol } from './merge';

const PROJECTS_BASE = process.env.MC_PROJECTS_BASE || '/Users/groot/.openclaw/workspace/projects';

/**
 * Get the protocol override file path for a project
 */
export function getOverridePath(projectId: string): string {
  return path.join(PROJECTS_BASE, projectId, 'PROTOCOL_OVERRIDE.json');
}

/**
 * Check if project override exists
 */
export function overrideExists(projectId: string): boolean {
  const overridePath = getOverridePath(projectId);
  return fs.existsSync(overridePath);
}

/**
 * Read project protocol override
 * Returns null if not found
 */
export function readOverride(projectId: string): ProtocolConfig | null {
  const overridePath = getOverridePath(projectId);
  
  if (!fs.existsSync(overridePath)) {
    return null;
  }
  
  try {
    const content = fs.readFileSync(overridePath, 'utf8');
    return JSON.parse(content) as ProtocolConfig;
  } catch (error) {
    console.error(`Error reading protocol override for ${projectId}:`, error);
    return null;
  }
}

/**
 * Write project protocol override atomically
 * Validates before writing
 * Returns { success, validation, path }
 */
export function writeOverride(
  projectId: string,
  protocol: ProtocolConfig
): { success: boolean; validation: ReturnType<typeof validateProtocol>; path: string } {
  const overridePath = getOverridePath(projectId);
  
  // Validate the protocol first
  const validation = validateProtocol(protocol);
  
  if (!validation.valid) {
    return { success: false, validation, path: overridePath };
  }
  
  // Ensure directory exists
  const dir = path.dirname(overridePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  // Write atomically using temp file + rename
  const tempPath = `${overridePath}.tmp.${Date.now()}`;
  
  try {
    fs.writeFileSync(tempPath, JSON.stringify(protocol, null, 2), 'utf8');
    fs.renameSync(tempPath, overridePath);
    
    return { success: true, validation, path: overridePath };
  } catch (error) {
    // Clean up temp file if it exists
    if (fs.existsSync(tempPath)) {
      fs.unlinkSync(tempPath);
    }
    
    console.error(`Error writing protocol override for ${projectId}:`, error);
    
    return {
      success: false,
      validation: {
        valid: false,
        errors: [`Failed to write override: ${(error as Error).message}`],
        warnings: [],
      },
      path: overridePath,
    };
  }
}

/**
 * Delete project protocol override
 */
export function deleteOverride(projectId: string): boolean {
  const overridePath = getOverridePath(projectId);
  
  if (!fs.existsSync(overridePath)) {
    return false;
  }
  
  try {
    fs.unlinkSync(overridePath);
    return true;
  } catch (error) {
    console.error(`Error deleting protocol override for ${projectId}:`, error);
    return false;
  }
}
