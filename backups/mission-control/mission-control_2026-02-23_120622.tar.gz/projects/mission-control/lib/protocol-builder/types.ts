/**
 * Protocol Builder Types
 * Type-safe protocol step model for Mission Control
 */

// Protocol step types
export type ProtocolStepType = 'task' | 'approval' | 'notification' | 'checkpoint';

export interface ProtocolStep {
  /** Unique step identifier */
  id: string;
  /** Human-readable step name */
  name: string;
  /** Step type */
  type: ProtocolStepType;
  /** Whether this step is enabled */
  enabled: boolean;
  /** Step ID this step depends on (for ordering) */
  dependsOn?: string;
  /** Agent to execute this step */
  agent?: string;
  /** Model to use for this step */
  model?: string;
  /** Timeout in minutes */
  timeoutMin?: number;
  /** Number of retries on failure */
  retries?: number;
  /** Whether human approval is required before proceeding */
  approvalRequired?: boolean;
  /** Step configuration/parameters */
  config?: Record<string, unknown>;
  /** Additional metadata */
  metadata?: Record<string, unknown>;
}

export interface ProtocolConfig {
  /** Protocol version */
  version: string;
  /** Protocol steps */
  steps: ProtocolStep[];
  /** Optional: list of allowed agents for this project */
  allowedAgents?: string[];
  /** Optional: list of allowed models for this project */
  modelAllowlist?: string[];
  /** Default timeout in minutes (fallback for steps without explicit timeout) */
  defaultTimeoutMin?: number;
  /** Default number of retries */
  defaultRetries?: number;
}

export interface ProtocolValidation {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export interface ProtocolMergeResult {
  effectiveProtocol: ProtocolConfig;
  validation: ProtocolValidation;
}

// ============================================
// Team-related types for Protocol Builder
// ============================================

/** Team member assignment from project team */
export interface ProjectTeamMember {
  agentId: string;
  role: string;
  roleId?: string;
  roleTitle?: string;
  rules?: string[];
  expectedDocuments?: string[];
  modelOverride?: string;
  /** Whether PM/manager assigns the agent dynamically */
  pmAssign?: boolean;
  /** The actual agent ID assigned (if not pmAssign) */
  assignedAgentId?: string;
}

/** Team suggestion from Protocol Builder */
export interface TeamSuggestion {
  agentId: string;
  role: string;
  roleTitle: string;
  reason: string;
  model?: string;
  score?: number;
}

/** Team decision tracking for audit */
export interface TeamDecision {
  /** How the team was determined */
  source: 'assigned' | 'builder-suggested' | 'auto-generated' | 'manual';
  /** When the decision was made */
  timestamp: string;
  /** Who made the decision (user or system) */
  madeBy: string;
  /** If applied from builder suggestions, the original suggestion */
  appliedFromSuggestion?: boolean;
  /** Original assigned team members (if overwritten) */
  originalTeam?: ProjectTeamMember[];
}

/** Protocol Builder response with team context */
export interface ProtocolBuilderResponse {
  defaultProtocol: ProtocolConfig;
  projectOverride: ProtocolConfig | null;
  effectiveProtocol: ProtocolConfig;
  validation: ProtocolValidation;
  hasOverride: boolean;
  /** Current assigned team from project */
  assignedTeam?: ProjectTeamMember[];
  /** Team suggestions from Protocol Builder */
  suggestedTeam?: TeamSuggestion[];
  /** Team decision history for audit */
  teamDecision?: TeamDecision;
  /** Whether there are team suggestions pending user decision */
  hasPendingSuggestions?: boolean;
}

/**
 * Default protocol - used when no project override exists
 * Hardcoded as per requirements (PROJECT_PROTOCOL.md-derived JSON fallback)
 */
export const DEFAULT_PROTOCOL: ProtocolConfig = {
  version: '1.0.0',
  steps: [
    {
      id: 'phase-1-analyze',
      name: 'Analyze Project',
      type: 'task',
      enabled: true,
      agent: 'analyzer',
      model: 'openrouter/anthropic/claude-3.5-sonnet',
      timeoutMin: 10,
      retries: 2,
      config: {
        priority: 'high',
      },
    },
    {
      id: 'phase-2-plan',
      name: 'Create Plan',
      type: 'task',
      enabled: true,
      dependsOn: 'phase-1-analyze',
      agent: 'planner',
      model: 'openrouter/anthropic/claude-3.5-sonnet',
      timeoutMin: 15,
      retries: 2,
      config: {
        priority: 'high',
      },
    },
    {
      id: 'phase-3-approval',
      name: 'Plan Approval',
      type: 'approval',
      enabled: true,
      dependsOn: 'phase-2-plan',
      approvalRequired: true,
      timeoutMin: 60,
    },
    {
      id: 'phase-4-execute',
      name: 'Execute Tasks',
      type: 'task',
      enabled: true,
      dependsOn: 'phase-3-approval',
      agent: 'executor',
      model: 'openrouter/minimax/minimax-m2.5',
      timeoutMin: 30,
      retries: 3,
    },
    {
      id: 'phase-5-verify',
      name: 'Verify Results',
      type: 'checkpoint',
      enabled: true,
      dependsOn: 'phase-4-execute',
      agent: 'verifier',
      model: 'openrouter/anthropic/claude-3.5-sonnet',
      timeoutMin: 10,
      retries: 1,
    },
    {
      id: 'phase-6-notify',
      name: 'Notify Completion',
      type: 'notification',
      enabled: true,
      dependsOn: 'phase-5-verify',
      timeoutMin: 5,
      retries: 0,
    },
  ],
  defaultTimeoutMin: 30,
  defaultRetries: 2,
};
