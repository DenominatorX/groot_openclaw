/**
 * Protocol Builder Schema
 * Schema validation for protocol configuration
 */

// Protocol step types
type ProtocolStepType = 'task' | 'approval' | 'notification' | 'checkpoint';

interface ValidationError {
  path: string;
  message: string;
}

type ProtocolConfigInput = unknown;
type ProtocolStepInput = unknown;

const VALID_STEP_TYPES: ProtocolStepType[] = ['task', 'approval', 'notification', 'checkpoint'];

/**
 * Validate a protocol step
 */
function validateStep(step: unknown, index: number): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!step || typeof step !== 'object') {
    errors.push({ path: `steps[${index}]`, message: 'Step must be an object' });
    return errors;
  }
  
  const s = step as Record<string, unknown>;
  
  // id required
  if (typeof s.id !== 'string' || s.id.length === 0) {
    errors.push({ path: `steps[${index}].id`, message: 'Step ID is required and must be a non-empty string' });
  }
  
  // name required
  if (typeof s.name !== 'string' || s.name.length === 0) {
    errors.push({ path: `steps[${index}].name`, message: 'Step name is required and must be a non-empty string' });
  }
  
  // type validation
  if (!VALID_STEP_TYPES.includes(s.type as ProtocolStepType)) {
    errors.push({ 
      path: `steps[${index}].type`, 
      message: `Step type must be one of: ${VALID_STEP_TYPES.join(', ')}` 
    });
  }
  
  // enabled must be boolean if present
  if (s.enabled !== undefined && typeof s.enabled !== 'boolean') {
    errors.push({ path: `steps[${index}].enabled`, message: 'enabled must be a boolean' });
  }
  
  // dependsOn must be string if present
  if (s.dependsOn !== undefined && typeof s.dependsOn !== 'string') {
    errors.push({ path: `steps[${index}].dependsOn`, message: 'dependsOn must be a string' });
  }
  
  // agent must be string if present
  if (s.agent !== undefined && typeof s.agent !== 'string') {
    errors.push({ path: `steps[${index}].agent`, message: 'agent must be a string' });
  }
  
  // model must be string if present
  if (s.model !== undefined && typeof s.model !== 'string') {
    errors.push({ path: `steps[${index}].model`, message: 'model must be a string' });
  }
  
  // timeoutMin must be positive integer if present
  if (s.timeoutMin !== undefined) {
    if (typeof s.timeoutMin !== 'number' || !Number.isInteger(s.timeoutMin) || s.timeoutMin <= 0) {
      errors.push({ path: `steps[${index}].timeoutMin`, message: 'timeoutMin must be a positive integer' });
    }
  }
  
  // retries must be integer 0-10 if present
  if (s.retries !== undefined) {
    if (typeof s.retries !== 'number' || !Number.isInteger(s.retries) || s.retries < 0 || s.retries > 10) {
      errors.push({ path: `steps[${index}].retries`, message: 'retries must be an integer between 0 and 10' });
    }
  }
  
  // approvalRequired must be boolean if present
  if (s.approvalRequired !== undefined && typeof s.approvalRequired !== 'boolean') {
    errors.push({ path: `steps[${index}].approvalRequired`, message: 'approvalRequired must be a boolean' });
  }
  
  return errors;
}

/**
 * Validate a protocol configuration
 */
export function validateProtocolConfig(data: unknown): {
  success: boolean;
  data?: ProtocolConfigInput;
  errors: string[];
} {
  const errors: string[] = [];
  
  if (!data || typeof data !== 'object') {
    return { success: false, errors: ['Protocol must be an object'] };
  }
  
  const config = data as Record<string, unknown>;
  
  // version required
  if (typeof config.version !== 'string' || config.version.length === 0) {
    errors.push('version is required and must be a non-empty string');
  }
  
  // steps required and must be array
  if (!Array.isArray(config.steps)) {
    errors.push('steps is required and must be an array');
  } else if (config.steps.length === 0) {
    errors.push('At least one step is required');
  } else {
    // Validate each step
    config.steps.forEach((step, index) => {
      const stepErrors = validateStep(step, index);
      stepErrors.forEach(e => errors.push(`${e.path}: ${e.message}`));
    });
  }
  
  // allowedAgents must be array of strings if present
  if (config.allowedAgents !== undefined) {
    if (!Array.isArray(config.allowedAgents)) {
      errors.push('allowedAgents must be an array');
    } else if (!config.allowedAgents.every(a => typeof a === 'string')) {
      errors.push('allowedAgents must contain only strings');
    }
  }
  
  // modelAllowlist must be array of strings if present
  if (config.modelAllowlist !== undefined) {
    if (!Array.isArray(config.modelAllowlist)) {
      errors.push('modelAllowlist must be an array');
    } else if (!config.modelAllowlist.every(m => typeof m === 'string')) {
      errors.push('modelAllowlist must contain only strings');
    }
  }
  
  // defaultTimeoutMin must be positive integer if present
  if (config.defaultTimeoutMin !== undefined) {
    if (typeof config.defaultTimeoutMin !== 'number' || !Number.isInteger(config.defaultTimeoutMin) || config.defaultTimeoutMin <= 0) {
      errors.push('defaultTimeoutMin must be a positive integer');
    }
  }
  
  // defaultRetries must be integer 0-10 if present
  if (config.defaultRetries !== undefined) {
    if (typeof config.defaultRetries !== 'number' || !Number.isInteger(config.defaultRetries) || config.defaultRetries < 0 || config.defaultRetries > 10) {
      errors.push('defaultRetries must be an integer between 0 and 10');
    }
  }
  
  if (errors.length > 0) {
    return { success: false, errors };
  }
  
  return { success: true, data };
}

/**
 * Validate a protocol step
 */
export function validateProtocolStep(data: unknown): {
  success: boolean;
  data?: ProtocolStepInput;
  errors: string[];
} {
  const errors: string[] = [];
  
  if (!data || typeof data !== 'object') {
    return { success: false, errors: ['Step must be an object'] };
  }
  
  const stepErrors = validateStep(data, 0);
  stepErrors.forEach(e => errors.push(`${e.path}: ${e.message}`));
  
  if (errors.length > 0) {
    return { success: false, errors };
  }
  
  return { success: true, data };
}
