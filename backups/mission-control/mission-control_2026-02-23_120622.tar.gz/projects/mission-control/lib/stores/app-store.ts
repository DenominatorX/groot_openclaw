// Global Application State Store
// Uses Zustand for unified state management across all panels

import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

// Types
export interface Agent {
  id: string;
  name: string;
  role: string;
  status: 'online' | 'offline' | 'busy' | 'idle';
  model?: string;
  lastActive?: string;
}

export interface Project {
  id: string;
  name: string;
  status: 'in-progress' | 'completed' | 'archived' | 'planning';
  priority: 'low' | 'medium' | 'high' | 'critical';
  progress: number;
  owner?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  column: 'inbox' | 'in-progress' | 'review' | 'done';
  priority: 'low' | 'medium' | 'high' | 'critical';
  assignee?: string;
  projectId?: string;
  dueDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Issue {
  id: string;
  title: string;
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  severity: 'low' | 'medium' | 'high' | 'critical';
  category?: string;
  createdAt: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'viewer';
  organizationId?: string;
}

// UI State
export type LoadingState = 'idle' | 'loading' | 'success' | 'error';
export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface Toast {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
  dismissible?: boolean;
}

export interface AppState {
  // Data
  agents: Agent[];
  projects: Project[];
  tasks: Task[];
  issues: Issue[];
  currentUser: User | null;
  
  // Loading states per entity
  loadingStates: Record<string, LoadingState>;
  
  // Error tracking
  errors: Record<string, string>;
  
  // UI State
  activeTab: string;
  sidebarCollapsed: boolean;
  toasts: Toast[];
  
  // Actions - Agents
  setAgents: (agents: Agent[]) => void;
  addAgent: (agent: Agent) => void;
  updateAgent: (id: string, updates: Partial<Agent>) => void;
  removeAgent: (id: string) => void;
  
  // Actions - Projects
  setProjects: (projects: Project[]) => void;
  addProject: (project: Project) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  removeProject: (id: string) => void;
  
  // Actions - Tasks
  setTasks: (tasks: Task[]) => void;
  addTask: (task: Task) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  removeTask: (id: string) => void;
  
  // Actions - Issues
  setIssues: (issues: Issue[]) => void;
  addIssue: (issue: Issue) => void;
  updateIssue: (id: string, updates: Partial<Issue>) => void;
  removeIssue: (id: string) => void;
  
  // Actions - Loading
  setLoadingState: (key: string, state: LoadingState) => void;
  setError: (key: string, error: string | null) => void;
  
  // Actions - UI
  setActiveTab: (tab: string) => void;
  toggleSidebar: () => void;
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
  clearToasts: () => void;
  
  // Actions - User
  setCurrentUser: (user: User | null) => void;
  
  // Bulk actions
  setAllLoading: (loading: boolean) => void;
  reset: () => void;
}

const initialState = {
  agents: [],
  projects: [],
  tasks: [],
  issues: [],
  currentUser: null,
  loadingStates: {},
  errors: {},
  activeTab: 'home',
  sidebarCollapsed: false,
  toasts: [],
};

export const useAppStore = create<AppState>()(
  devtools(
    persist(
      (set, get) => ({
        ...initialState,

        // Agents
        setAgents: (agents) => set({ agents }),
        addAgent: (agent) => set((state) => ({ agents: [...state.agents, agent] })),
        updateAgent: (id, updates) =>
          set((state) => ({
            agents: state.agents.map((a) => (a.id === id ? { ...a, ...updates } : a)),
          })),
        removeAgent: (id) =>
          set((state) => ({ agents: state.agents.filter((a) => a.id !== id) })),

        // Projects
        setProjects: (projects) => set({ projects }),
        addProject: (project) => set((state) => ({ projects: [...state.projects, project] })),
        updateProject: (id, updates) =>
          set((state) => ({
            projects: state.projects.map((p) => (p.id === id ? { ...p, ...updates } : p)),
          })),
        removeProject: (id) =>
          set((state) => ({ projects: state.projects.filter((p) => p.id !== id) })),

        // Tasks
        setTasks: (tasks) => set({ tasks }),
        addTask: (task) => set((state) => ({ tasks: [...state.tasks, task] })),
        updateTask: (id, updates) =>
          set((state) => ({
            tasks: state.tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
          })),
        removeTask: (id) =>
          set((state) => ({ tasks: state.tasks.filter((t) => t.id !== id) })),

        // Issues
        setIssues: (issues) => set({ issues }),
        addIssue: (issue) => set((state) => ({ issues: [...state.issues, issue] })),
        updateIssue: (id, updates) =>
          set((state) => ({
            issues: state.issues.map((i) => (i.id === id ? { ...i, ...updates } : i)),
          })),
        removeIssue: (id) =>
          set((state) => ({ issues: state.issues.filter((i) => i.id !== id) })),

        // Loading & Errors
        setLoadingState: (key, state) =>
          set((s) => ({ loadingStates: { ...s.loadingStates, [key]: state } })),
        setError: (key, error) =>
          set((s) => ({ errors: { ...s.errors, [key]: error ?? {} } })),

        // UI
        setActiveTab: (tab) => set({ activeTab: tab }),
        toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
        addToast: (toast) =>
          set((s) => ({
            toasts: [...s.toasts, { ...toast, id: crypto.randomUUID() }],
          })),
        removeToast: (id) =>
          set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
        clearToasts: () => set({ toasts: [] }),

        // User
        setCurrentUser: (user) => set({ currentUser: user }),

        // Bulk
        setAllLoading: (loading) =>
          set({
            loadingStates: Object.keys(get().loadingStates).reduce(
              (acc, key) => ({ ...acc, [key]: loading ? 'loading' : 'idle' }),
              {}
            ),
          }),
        reset: () => set(initialState),
      }),
      {
        name: 'mission-control-storage',
        partialize: (state) => ({
          activeTab: state.activeTab,
          sidebarCollapsed: state.sidebarCollapsed,
          currentUser: state.currentUser,
        }),
      }
    ),
    { name: 'AppStore' }
  )
);

// Selectors for common use cases
export const useAgents = () => useAppStore((s) => s.agents);
export const useProjects = () => useAppStore((s) => s.projects);
export const useTasks = () => useAppStore((s) => s.tasks);
export const useIssues = () => useAppStore((s) => s.issues);
export const useActiveTab = () => useAppStore((s) => s.activeTab);
export const useToasts = () => useAppStore((s) => s.toasts);
export const useCurrentUser = () => useAppStore((s) => s.currentUser);

export const useLoadingState = (key: string) =>
  useAppStore((s) => s.loadingStates[key] ?? 'idle');

export const useError = (key: string) =>
  useAppStore((s) => s.errors[key]);

// Derived selectors
export const useInboxTasks = () =>
  useAppStore((s) => s.tasks.filter((t) => t.column === 'inbox'));

export const useInProgressTasks = () =>
  useAppStore((s) => s.tasks.filter((t) => t.column === 'in-progress'));

export const useActiveProjects = () =>
  useAppStore((s) => s.projects.filter((p) => p.status === 'in-progress'));

export const useOpenIssues = () =>
  useAppStore((s) => s.issues.filter((i) => i.status === 'open' || i.status === 'in-progress'));