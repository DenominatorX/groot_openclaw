import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';

// Security headers applied to all responses
function addSecurityHeaders(res: NextResponse) {
  res.headers.set('X-Frame-Options', 'DENY');
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('Referrer-Policy', 'no-referrer');
  res.headers.set('X-XSS-Protection', '1; mode=block');
  res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.headers.set('X-Robots-Tag', 'noindex, nofollow');
  return res;
}

// Routes that don't require authentication
const publicPaths = ['/auth/signin', '/auth/error', '/api/auth', '/terms', '/privacy', '/login', '/setup'];

// Admin-only routes
const adminPaths = ['/admin'];

// Check for iron-session authentication via cookie presence
// (Edge runtime can't use fs/iron-session directly — check the cookie exists
// and validate it server-side in the API routes instead)
function checkIronSessionCookie(req: NextRequest): boolean {
  return req.cookies.has('mc_session');
}

export async function middleware(req: NextRequest) {
  const res = NextResponse.next();
  
  // Add security headers to all responses
  addSecurityHeaders(res);

  // Check if the path is public
  const pathname = req.nextUrl.pathname;
  const isPublicPath = publicPaths.some(path => pathname === path || pathname.startsWith(path + '/'));
  
  if (isPublicPath) {
    return res;
  }

  // Check authentication status using NextAuth JWT (OAuth users)
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  
  // Also check iron-session cookie (password auth users like Kevin)
  const ironSessionAuth = checkIronSessionCookie(req);
  
  // If no NextAuth session AND no iron-session, block access
  if (!token && !ironSessionAuth) {
    // APIs should return JSON 401 (not HTML redirect), otherwise clients hit JSON.parse errors
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const signInUrl = new URL('/auth/signin', req.url);
    signInUrl.searchParams.set('callbackUrl', pathname);
    return NextResponse.redirect(signInUrl);
  }

  // Check if accessing admin route - only NextAuth has role info, iron-session users are admin by default
  const isAdminPath = adminPaths.some(path => pathname === path || pathname.startsWith(path + '/'));
  if (isAdminPath) {
    // For NextAuth, check role; for iron-session (Kevin), allow access (password users are admin)
    const isAdmin = token?.role === 'admin' || ironSessionAuth;
    if (!isAdmin) {
      const homeUrl = new URL('/', req.url);
      homeUrl.searchParams.set('error', 'unauthorized');
      return NextResponse.redirect(homeUrl);
    }
  }

  return res;
}

export const config = {
  matcher: ['/((?!api/auth|_next/static|_next/image|favicon.ico|auth/signin|auth/error).*)'],
};
