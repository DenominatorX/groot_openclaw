# Mission Control v3 — Master Plan
## "The Full Vision"
**Created:** 2026-02-11
**Owner:** Kevin Lane (@itsbacklog)
**Lead:** Groot

---

## Executive Summary
Transform Mission Control from a dashboard into a full **AI Command Center** — where Kevin manages a hierarchical agent organization through visual rooms, multi-agent conversations, persistent profiles, tiered model assignment, and project-driven workflows.

---

## Phase 1: Agent Profiles & Identity System
**Priority:** 🔴 Critical (foundation for everything else)
**Estimate:** 1-2 sessions

### 1.1 Agent Profile Data Model
- Full profile: name, bio, role, tier, model, character type, voice, color, avatar image
- Kevin's profile (special): preferences, rules, communication style, meeting preferences
- Executive Board: Kevin, Groot, Jimmy T, CEO, Dr. Al, Dirty Bird
- Sub-agent profiles: auto-created on spawn, persist across sessions
- Profile stores: `data/agents.json` expanded with full schema

### 1.2 Profile UI — Mission Control
- Click agent name in sidebar → opens Profile View panel
- Editable fields: name, bio, role, model override, character type (dropdown of 8 types), voice (ElevenLabs), color
- Profile card: avatar preview (3D character render or icon), stats, last active, session count
- "Edit Profile" mode with save/cancel

### 1.3 Profile UI — Agent World
- Click character in 3D → flyout mini-card (name, role, tier, status, last action)
- "View Full Profile" link → opens MC profile view
- Character type shown on mini-card

### 1.4 Kevin's Profile
- Special "Owner" profile in the system
- Editable preferences: communication style, meeting rules, project defaults
- Agents read Kevin's profile to adjust behavior
- Shows in Executive Board roster

---

## Phase 2: Rooms & Locations (Agent World)
**Priority:** 🔴 Critical
**Estimate:** 2-3 sessions

### 2.1 Room System
- Named locations in the 3D world with boundaries and labels
- Agents walk to rooms when assigned work
- Room types:
  - **The Boardroom** — Executive Board meetings (Kevin, CEO, Dirty Bird, Dr. Al, Groot, Jimmy T)
  - **The Doctor's Office** — Dr. Al's space, health consultations
  - **The Law Office** — Dirty Bird's space, legal review
  - **The Office** — General meeting room (1-on-1 or group)
  - **CEO's Suite** — Business/finance/admin hub
  - **Dev Studio** — Coding and technical work
  - **Break Room** — Idle agents hang out here
- Each room: position in world, capacity, assigned agents, active meeting indicator

### 2.2 Workbenches & Furniture
- Visual objects per room (desks, chairs, whiteboards, screens)
- Agents walk to their desk/station when working
- Activity indicators (typing animation, thinking emote, etc.)

### 2.3 Room Interaction
- Click room label → see who's in the room, active meeting, join button
- Agents auto-move to assigned room when given tasks

---

## Phase 3: Multi-Agent Chat System
**Priority:** 🔴 Critical
**Estimate:** 2-3 sessions

### 3.1 Chat Interface
- Chat box at bottom of meeting/room view
- Agent icon row below chat box (small character avatars)
- Click icon → inserts `@agentname` into message
- Send message → tagged agents respond in order
- Example: `@groot what's the status? @jimmyt start taking notes`

### 3.2 Conversation Threading & Forking
- Linear chat by default
- When conversation forks (multiple topics), create named threads
- Each thread tracks participants and context
- Agents see full thread context when tagged
- Visual thread indicator in chat (branching lines or tabs)

### 3.3 Meeting System
- Start a meeting: select room + invite agents
- Meeting has: agenda, participants, chat log, action items
- "Note Taker" role assignment — auto-summarizes meeting
- Meeting history: searchable, replayable
- Boardroom meetings: all Executive Board auto-invited

### 3.4 Queue System
- Agent response queue (who responds next, in what order)
- Logged pathways: which agent said what, when, in which thread
- Multiple concurrent conversations tracked cleanly
- Agents can tag each other to hand off or collaborate

---

## Phase 4: Agent Hierarchy & Model Tiering
**Priority:** 🟠 High
**Estimate:** 1-2 sessions

### 4.1 Organizational Tiers
| Tier | Title | Default Model | Cost Level |
|------|-------|--------------|------------|
| 0 | Owner (Kevin) | — | — |
| 1 | Executive Board | Claude Opus 4.6 | $$$$$ |
| 2 | VP | Claude Sonnet | $$$$ |
| 3 | Director | Grok | $$$ |
| 4 | Sr. Manager | Claude Haiku | $$ |
| 5 | Manager | Ollama 70B (local) | $ |
| 6 | Frontline | Ollama 8B (local) | ¢ |

### 4.2 Global Tier Config
- Settings > Agent Tiers: set default model per tier
- Dropdown per tier: all available models (Opus, Sonnet, Haiku, Grok, Ollama variants)
- Change tier model → updates ALL agents at that tier (unless individually overridden)
- Per-agent override in profile (takes precedence over tier default)

### 4.3 Sub-Agent Spawning
- Any Executive Board member can spawn sub-agents
- Sub-agents inherit parent's department but get own profile
- Unique persistent name, profile, session history
- Kevin can spawn from any Executive Board member
- Spawn UI: pick parent agent, name, role, tier, model
- Sub-agent tree visible in org chart

### 4.4 Cost Optimization Logic
- CEO auto-delegates to cheapest capable tier
- Task complexity scoring → routes to appropriate tier
- Dashboard shows cost per agent, per project, per tier
- "Always use cheapest option" toggle in settings

---

## Phase 5: Projects, Roles & Reports
**Priority:** 🟠 High
**Estimate:** 2-3 sessions

### 5.1 Enhanced Projects
- Custom settings per project: description, rules, communication preferences
- Agent assignments with **Roles** (Lead, Note Taker, Developer, Reviewer, Analyst, etc.)
- Role templates: pre-defined role sets per project type
- Project status: active, paused, completed, archived

### 5.2 Reports System
- Reports tab in MC (organized by project and/or task)
- Auto-generated reports stored as viewable files in dashboard
- Report types:
  - PRD (Product Requirements Document)
  - Design Document
  - Technical Spec / Architecture
  - Wireframes (descriptive)
  - Status Report
  - Meeting Notes / Summary
  - Financial Summary
  - Analytics Report
- "Generate Report" button per project → select type → agent produces it
- Reports viewer: markdown rendered, printable, downloadable
- AI-assisted badge on all generated docs

### 5.3 Analytics & Charts
- **Agent Analytics**: messages sent, tasks completed, time active, cost consumed
- **Project Analytics**: progress %, burn rate, velocity, milestone tracking
- **Health Analytics**: Oura trends over time (sleep score, HRV, stress, steps)
- **Cost Analytics**: spend by model, by tier, by agent, by project, daily/weekly/monthly
- **System Analytics**: API calls, uptime, response times
- **Smart Home Analytics**: energy usage patterns, device activity
- Chart library: Recharts or Chart.js embedded in MC
- Dashboard widgets: sparklines in sidebar, full charts in analytics tab

---

## Phase 6: Agent World Themes & Weather
**Priority:** 🟡 Medium
**Estimate:** 1-2 sessions

### 6.1 Theme System
- Theme selector: bottom-right corner of Agent World
- Save current look as **"Default"** theme

### 6.2 Theme 1: Default (Ocean World)
- Current sandy beach aesthetic
- Rocks, Moltbook, Worlds Portal, ClawHub Academy
- Underwater-ish color palette

### 6.3 Theme 2: Tropical Tampa
- Higher quality sky (gradient sunset/sunrise based on time of day)
- Sand → beach with water edge and waves
- Boardroom → Volleyball Court
- Kevin's Office → Swimming Pool
- Doctor's Office → Hot Tub
- CEO's Suite → Beach Cabana
- Palm trees, beach chairs, tiki torches
- Tropical color palette

### 6.4 Theme 3: Corporate Office
- Indoor office environment
- Cubicles, conference rooms, executive suites
- Professional color palette
- Elevator/hallway connecting rooms

### 6.5 Weather System
- Zip code input in settings (default: 34638 Land O' Lakes)
- Fetches real weather data (wttr.in or OpenWeather)
- Replicates in Agent World:
  - Time of day → lighting/sky color
  - Temperature → visual indicators
  - Rain/clouds/sun/storms → particle effects
  - Season → environment details

---

## Phase 7: Voice Integration
**Priority:** 🟡 Medium
**Estimate:** 1 session

- ElevenLabs voice per agent profile
- Voice design from within MC: describe voice → preview → save
- Agents can "speak" in meetings (TTS on their chat messages)
- Budget-conscious: Starter plan $5/mo, selective voice use
- Voice toggle per meeting (text-only vs voiced)

---

## Execution Order
1. **Phase 1** → Profiles are the foundation for everything
2. **Phase 4** → Hierarchy & tiering (needed before spawning sub-agents)
3. **Phase 3** → Chat system (needed for meetings and collaboration)
4. **Phase 2** → Rooms (visual representation of where work happens)
5. **Phase 5** → Projects & Reports (the output layer)
6. **Phase 6** → Themes & Weather (polish and delight)
7. **Phase 7** → Voice (enhancement layer)

---

## Tech Stack
- **Frontend**: Next.js 14, React 18, Tailwind CSS, TypeScript
- **3D**: Three.js (Agent World), embedded via iframe (later: native component)
- **Charts**: Recharts or Chart.js
- **Chat**: Custom WebSocket-based multi-agent chat
- **Data**: JSON files → future: SQLite or Convex
- **Models**: Anthropic (Opus/Sonnet/Haiku), xAI (Grok), Ollama (local)
- **Voice**: ElevenLabs API
- **Weather**: wttr.in (free, no API key)

---

## Success Metrics
- Kevin can manage all agents from one dashboard
- Multi-agent meetings work smoothly with @mentions
- Reports generated on demand, viewable in-app
- Cost optimized: right model for right task, always
- Visual delight: agents walking to rooms, weather matching reality
- $10K Mac Studio fund tracked and progressing
