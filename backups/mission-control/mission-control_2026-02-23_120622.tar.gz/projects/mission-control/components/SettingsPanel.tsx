'use client';
import { useEffect, useState } from 'react';
import ContextHealth from './ContextHealth';
import CronManagerPage from '@/app/settings/crons/page';
import ModelSettingsPage from '@/app/settings/models/page';

function VoiceBudget() {
  const [data, setData] = useState<{character_count: number; character_limit: number; tier: string} | null>(null);
  useEffect(() => {
    fetch('/api/voice?usage=true').then(r => r.json()).then(setData).catch(() => {});
  }, []);
  if (!data) return null;
  const pct = data.character_limit > 0 ? (data.character_count / data.character_limit) * 100 : 0;
  const warn = pct > 80;
  return (
    <section className="mt-3 p-3 bg-mc-bg rounded-lg border border-mc-border">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium">🔊 ElevenLabs Usage</span>
        <span className="text-[10px] text-mc-muted">{data.tier} plan</span>
      </div>
      <div className="w-full h-2 bg-mc-surface rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${warn ? 'bg-red-500' : 'bg-mc-accent'}`}
          style={{ width: `${Math.min(pct, 100)}%` }} />
      </div>
      <div className="flex justify-between mt-1">
        <span className={`text-[10px] ${warn ? 'text-red-400' : 'text-mc-muted'}`}>
          {data.character_count.toLocaleString()} / {data.character_limit.toLocaleString()} chars
        </span>
        <span className={`text-[10px] ${warn ? 'text-red-400' : 'text-mc-muted'}`}>{pct.toFixed(1)}%</span>
      </div>
    </section>
  );
}

interface Settings {
  port: number;
  theme: string;
  weatherZip: string;
  tempUnit: string;
  apiKeys: Record<string, string>;
  endpoints: Record<string, string>;
}

interface TierConfig {
  label: string;
  defaultModel: string | null;
  maxTokens?: number;
  description?: string;
}

const MODEL_OPTIONS = [
  { value: '', label: 'None (Owner)' },
  // Anthropic
  { value: 'anthropic/claude-opus-4-6', label: 'Claude Opus 4.6' },
  { value: 'anthropic/claude-sonnet-4', label: 'Claude Sonnet 4' },
  { value: 'anthropic/claude-haiku-4-5', label: 'Claude Haiku 4.5' },
  // OpenAI
  { value: 'openai/gpt-4o', label: 'GPT-4o' },
  { value: 'openai/gpt-4o-mini', label: 'GPT-4o Mini' },
  // xAI (native)
  { value: 'xai/grok-4', label: 'Grok 4 (xAI)' },
  { value: 'xai/grok-4-1-fast', label: 'Grok 4.1 Fast (xAI)' },
  // OpenRouter
  { value: 'openrouter/minimax/minimax-m2.5', label: 'MiniMax M2.5 (OpenRouter)' },
  { value: 'openrouter/google/gemini-2.5-pro', label: 'Gemini 2.5 Pro (OpenRouter)' },
  { value: 'openrouter/google/gemini-3-pro-preview', label: 'Gemini 3 Pro (OpenRouter)' },
  { value: 'openrouter/x-ai/grok-4', label: 'Grok 4 (OpenRouter)' },
  { value: 'openrouter/x-ai/grok-4.1-fast', label: 'Grok 4.1 Fast (OpenRouter)' },
  // NVIDIA
  { value: 'nvidia/moonshotai/kimi-k2-instruct', label: 'Kimi K2.5 (NVIDIA)' },
  // Local
  { value: 'lmstudio/gemma-3-12b', label: 'Gemma 3 12B (Local)' },
  { value: 'lmstudio/gemma-3-4b', label: 'Gemma 3 4B (Local)' },
  { value: 'lmstudio/deepseek-r1-0528-qwen3-8b', label: 'DeepSeek R1 8B (Local)' },
  { value: 'lmstudio/ministral-3-3b', label: 'Ministral 3B (Local)' },
  { value: 'ollama/llama3.1:8b', label: 'Ollama 8B (Local)' },
];

const API_KEY_META: Record<string, { label: string; icon: string; placeholder: string; category: string; manageUrl?: string }> = {
  openclaw_gateway: { label: 'OpenClaw Gateway', icon: '⚡', placeholder: 'Gateway auth token', category: 'Platform' },
  openai: { label: 'OpenAI', icon: '🤖', placeholder: 'sk-proj-...', category: 'AI Models', manageUrl: 'https://platform.openai.com/api-keys' },
  anthropic: { label: 'Anthropic (Claude)', icon: '🧠', placeholder: 'sk-ant-...', category: 'AI Models', manageUrl: 'https://console.anthropic.com/settings/keys' },
  gemini: { label: 'Google Gemini', icon: '💎', placeholder: 'AIza...', category: 'AI Models', manageUrl: 'https://aistudio.google.com/apikey' },
  grok: { label: 'Grok (xAI)', icon: '🚀', placeholder: 'xai-...', category: 'AI Models', manageUrl: 'https://console.x.ai/team/default/api-keys' },
  elevenlabs: { label: 'ElevenLabs', icon: '🔊', placeholder: 'ElevenLabs API key', category: 'Services', manageUrl: 'https://elevenlabs.io/app/settings/api-keys' },
  govee: { label: 'Govee Smart Home', icon: '💡', placeholder: 'Govee developer key', category: 'Smart Home', manageUrl: 'https://developer.govee.com/reference/apply-you-govee-api-key' },
  google_places: { label: 'Google Places', icon: '📍', placeholder: 'AIza...', category: 'Services', manageUrl: 'https://console.cloud.google.com/apis/credentials' },
  oura_client_id: { label: 'Oura Client ID', icon: '💍', placeholder: 'OAuth client ID', category: 'Health', manageUrl: 'https://cloud.ouraring.com/v2/docs' },
  oura_client_secret: { label: 'Oura Client Secret', icon: '💍', placeholder: 'OAuth client secret', category: 'Health', manageUrl: 'https://cloud.ouraring.com/v2/docs' },
  omi: { label: 'OMI Device', icon: '🎧', placeholder: 'omi_dev_...', category: 'Health', manageUrl: 'https://docs.omi.me' },
  openrouter: { label: 'OpenRouter', icon: '🔀', placeholder: 'sk-or-v1-...', category: 'AI Models', manageUrl: 'https://openrouter.ai/settings/keys' },
  coinbase_api_key: { label: 'Coinbase API Key', icon: '🪙', placeholder: 'API key UUID', category: 'Finance', manageUrl: 'https://www.coinbase.com/settings/api' },
  coinbase_api_secret: { label: 'Coinbase API Secret', icon: '🪙', placeholder: 'API secret', category: 'Finance', manageUrl: 'https://www.coinbase.com/settings/api' },
  nvidia_kimi: { label: 'NVIDIA Kimi K2.5', icon: '🟢', placeholder: 'nvapi-...', category: 'AI Models', manageUrl: 'https://build.nvidia.com/settings/api-keys' },
};

const THEMES = [
  { id: 'dark', label: '🌙 Dark', bg: '#0a0a0f', surface: '#12121a', accent: '#6366f1' },
  { id: 'light', label: '☀️ Light', bg: '#f5f5f5', surface: '#ffffff', accent: '#6366f1' },
  { id: 'midnight', label: '🌌 Midnight', bg: '#020617', surface: '#0f172a', accent: '#3b82f6' },
  { id: 'neon', label: '💚 Neon', bg: '#000000', surface: '#0a0a0a', accent: '#00ff88' },
  { id: 'cream', label: '☕ Cream', bg: '#faf6f1', surface: '#ffffff', accent: '#b8860b' },
  { id: 'tropical', label: '🌴 Tropical', bg: '#1a1412', surface: '#261e1a', accent: '#14b8a6' },
  { id: 'corporate', label: '🏢 Corporate', bg: '#f3f4f6', surface: '#ffffff', accent: '#2563eb' },
];

const TIER_COLORS: Record<number, string> = {
  0: 'text-yellow-400',
  1: 'text-purple-400',
  2: 'text-blue-400',
  3: 'text-cyan-400',
  4: 'text-green-400',
  5: 'text-orange-400',
  6: 'text-gray-400',
};

type SettingsTab = 'general' | 'apikeys' | 'security' | 'tiers' | 'models' | 'characters' | 'system' | 'crons';

interface CharacterType {
  id: string;
  name: string;
  emoji: string;
  description: string;
  asset3d: string | null;
}

export default function SettingsPanel({ onClose }: { onClose: () => void }) {
  // Lock body scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [rawKeys, setRawKeys] = useState<Record<string, string>>({});
  const [port, setPort] = useState(4000);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyValue, setNewKeyValue] = useState('');
  const [portChanged, setPortChanged] = useState(false);
  const [restarting, setRestarting] = useState(false);
  const [tab, setTab] = useState<SettingsTab>('general');
  const [keyFilter, setKeyFilter] = useState('');
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [pwMessage, setPwMessage] = useState('');
  const [tiers, setTiers] = useState<Record<string, TierConfig>>({});
  const [tiersSaving, setTiersSaving] = useState(false);
  const [tiersMessage, setTiersMessage] = useState('');
  const [charTypes, setCharTypes] = useState<CharacterType[]>([]);
  const [charSaving, setCharSaving] = useState<Record<string, boolean>>({});
  const [charDeleting, setCharDeleting] = useState<string | null>(null);
  const [allAgents, setAllAgents] = useState<{id:string;name:string;displayName?:string;avatarType?:string;characterType?:string}[]>([]);
  const [glbFiles, setGlbFiles] = useState<string[]>([]);

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => {
      const s = d.settings || d.raw || {};
      setSettings(s);
      setRawKeys(s.apiKeys || {});
      setPort(s.port || 3001);
    });
    fetch('/api/agents').then(r => r.json()).then(d => {
      if (d.tiers) setTiers(d.tiers);
      const agents = d.agents || d;
      if (Array.isArray(agents)) setAllAgents(agents);
    }).catch(() => {});
    fetch('/api/character-types').then(r => r.json()).then(d => {
      if (d.types) setCharTypes(d.types);
    }).catch(() => {});
    fetch('/api/assets').then(r => r.json()).then(d => {
      if (d.files) setGlbFiles(d.files);
    }).catch(() => {});
  }, []);

  const save = async (extraUpdates?: Partial<Settings>) => {
    setSaving(true);
    setMessage('');
    try {
      // Strip masked/unchanged values (contain bullet •) before saving — only send real edits
      const cleanKeys = Object.fromEntries(
        Object.entries(rawKeys).filter(([, v]) => v && !v.includes('•'))
      );
      const body: any = { apiKeys: cleanKeys, port, ...extraUpdates };
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(data.message);
        setPortChanged(data.portChanged);
        if (data.settings) { setSettings(data.settings); setRawKeys(data.settings.apiKeys || {}); }
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (e: any) { setMessage(`Error: ${e.message}`); }
    setSaving(false);
  };

  const saveTiers = async () => {
    setTiersSaving(true);
    setTiersMessage('');
    try {
      const res = await fetch('/api/agents', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update-tiers', tiers }),
      });
      const data = await res.json();
      if (data.ok) {
        setTiersMessage('Tier configuration saved.');
      } else {
        setTiersMessage(`Error: ${data.error || 'Unknown error'}`);
      }
    } catch (e: any) { setTiersMessage(`Error: ${e.message}`); }
    setTiersSaving(false);
  };

  const restartServer = async () => {
    setRestarting(true);
    setMessage('Restarting server...');
    try {
      const res = await fetch('/api/server/restart', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setMessage(`Restarting on port ${data.newPort}. Redirecting in 3s...`);
        setTimeout(() => { window.location.href = data.newUrl; }, 3000);
      } else {
        setMessage(`${data.error}. Run: ${data.manualCommand}`);
        setRestarting(false);
      }
    } catch {
      setMessage(`Server stopped. Navigate to http://localhost:${port}`);
      setRestarting(false);
    }
  };

  const addCustomKey = () => {
    if (!newKeyName.trim()) return;
    setRawKeys(prev => ({ ...prev, [newKeyName.trim().toLowerCase().replace(/\s+/g, '_')]: newKeyValue }));
    setNewKeyName('');
    setNewKeyValue('');
  };

  const removeKey = (key: string) => {
    setRawKeys(prev => { const n = { ...prev }; delete n[key]; return n; });
  };

  const changeTheme = (theme: string) => {
    document.documentElement.setAttribute('data-theme', theme);
    try { localStorage.setItem('mc-theme', theme); } catch(e) {}
    try { document.cookie = `mc-theme=${theme}; path=/; max-age=31536000; SameSite=Lax`; } catch(e) {}
    setSettings(prev => prev ? { ...prev, theme } : prev);
    save({ theme } as any);
  };

  // Filter API keys
  const filteredKeys = Object.entries(rawKeys).filter(([key]) => {
    if (!keyFilter) return true;
    const meta = API_KEY_META[key];
    const searchStr = `${key} ${meta?.label || ''} ${meta?.category || ''}`.toLowerCase();
    return searchStr.includes(keyFilter.toLowerCase());
  });

  // Group by category
  const groupedKeys = filteredKeys.reduce((acc, [key, value]) => {
    const cat = API_KEY_META[key]?.category || 'Custom';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push([key, value]);
    return acc;
  }, {} as Record<string, [string, string][]>);

  if (!settings) return <div className="p-4 text-mc-muted">Loading...</div>;

  const tabs: { id: SettingsTab; label: string; icon: string }[] = [
    { id: 'general', label: 'General', icon: '⚙️' },
    { id: 'apikeys', label: 'API Keys', icon: '🔑' },
    { id: 'security', label: 'Security', icon: '🔒' },
    { id: 'tiers', label: 'Agent Tiers', icon: '🏷️' },
    { id: 'models', label: 'Models', icon: '🤖' },
    { id: 'characters', label: 'Characters', icon: '🎭' },
    { id: 'system', label: 'System', icon: '🖥️' },
    { id: 'crons', label: 'Cron Manager', icon: '⏰' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-4xl max-h-[95vh] md:max-h-[85vh] overflow-hidden flex flex-col mx-2">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-mc-border">
          <h2 className="text-lg font-bold">⚙️ Settings</h2>
          <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
        </div>

        {/* Body: left nav + content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left vertical nav */}
          <div className="flex flex-col w-44 shrink-0 border-r border-mc-border py-2 overflow-y-auto">
            {tabs.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm text-left transition-colors whitespace-nowrap ${
                  tab === t.id
                    ? 'bg-mc-accent/10 text-mc-accent font-medium border-r-2 border-mc-accent'
                    : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg/50'
                }`}
              >
                <span>{t.icon}</span>
                <span>{t.label}</span>
              </button>
            ))}
          </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* ===== GENERAL TAB ===== */}
          {tab === 'general' && (
            <>
              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🌐 Server Port</h3>
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-mc-muted">localhost:</span>
                      <input type="number" value={port} onChange={e => setPort(parseInt(e.target.value) || 4000)}
                        min={1024} max={65535}
                        className="w-24 px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm font-mono focus:outline-none focus:border-mc-accent" />
                    </div>
                    <p className="text-xs text-mc-muted mt-1">Range: 1024-65535. Use 3001 for public (Cloudflare tunnel).</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => save()} disabled={saving}
                      className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:opacity-90 disabled:opacity-50">
                      {saving ? 'Saving...' : 'Save'}
                    </button>
                    {portChanged && (
                      <button onClick={restartServer} disabled={restarting}
                        className="px-3 py-1.5 bg-yellow-600 text-white rounded text-sm hover:opacity-90 disabled:opacity-50 animate-pulse">
                        {restarting ? 'Restarting...' : '🔄 Restart'}
                      </button>
                    )}
                  </div>
                </div>
              </section>

              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🎨 Theme</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {THEMES.map(t => (
                    <button key={t.id} onClick={() => changeTheme(t.id)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border text-sm transition-all ${
                        settings.theme === t.id
                          ? 'border-mc-accent ring-2 ring-mc-accent/30'
                          : 'border-mc-border hover:border-mc-accent/50'
                      }`}>
                      <div className="w-full h-10 rounded-md overflow-hidden flex" style={{ backgroundColor: t.bg }}>
                        <div className="w-1/2 h-full" style={{ backgroundColor: t.surface }} />
                        <div className="w-1/2 h-full flex items-center justify-center">
                          <div className="w-4 h-1.5 rounded-full" style={{ backgroundColor: t.accent }} />
                        </div>
                      </div>
                      <span className="text-xs">{t.label}</span>
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🌤️ Weather</h3>
                <div className="flex items-center gap-3">
                  <div>
                    <label className="text-xs text-mc-muted">Zip Code</label>
                    <input type="text" value={settings.weatherZip || '34638'}
                      onChange={e => setSettings(prev => prev ? { ...prev, weatherZip: e.target.value } : prev)}
                      className="w-28 px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm font-mono focus:outline-none focus:border-mc-accent block mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-mc-muted">Temp Unit</label>
                    <div className="flex bg-mc-bg border border-mc-border rounded overflow-hidden mt-1">
                      {['F', 'C'].map(u => (
                        <button key={u} onClick={() => setSettings(prev => prev ? { ...prev, tempUnit: u } : prev)}
                          className={`px-3 py-1.5 text-sm transition-colors ${(settings.tempUnit || 'F') === u ? 'bg-mc-accent text-white' : 'text-mc-muted hover:text-mc-text'}`}>
                          °{u}
                        </button>
                      ))}
                    </div>
                  </div>
                  <button onClick={() => save({ weatherZip: settings.weatherZip || '34638', tempUnit: settings.tempUnit || 'F' } as any)}
                    disabled={saving}
                    className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:opacity-90 disabled:opacity-50 mt-5">
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </section>

              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🔗 Endpoints</h3>
                <div className="space-y-2">
                  {Object.entries(settings.endpoints || {}).map(([key, value]) => (
                    <div key={key} className="space-y-1">
                      <label className="text-xs text-mc-muted">{key}</label>
                      <input type="text" defaultValue={value} readOnly
                        className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm font-mono opacity-70" />
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}

          {/* ===== API KEYS TAB ===== */}
          {tab === 'apikeys' && (
            <>
              <div className="sticky top-0 bg-mc-surface pb-3 z-10">
                <div className="flex items-center gap-2">
                  <input value={keyFilter} onChange={e => setKeyFilter(e.target.value)}
                    placeholder="🔍 Filter API keys..."
                    className="flex-1 px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text text-sm placeholder:text-mc-muted focus:outline-none focus:border-mc-accent" />
                  <span className="text-xs text-mc-muted">{filteredKeys.length} keys</span>
                  <a href="https://github.com/public-apis/public-apis" target="_blank" rel="noopener noreferrer"
                    className="text-xs text-mc-accent hover:underline whitespace-nowrap">📚 Public APIs</a>
                  <button
                    onClick={() => {
                      const allShown = filteredKeys.every(([k]) => showKeys[k]);
                      const next: Record<string, boolean> = { ...showKeys };
                      filteredKeys.forEach(([k]) => next[k] = !allShown);
                      setShowKeys(next);
                    }}
                    className="text-xs text-mc-muted hover:text-mc-text px-2 py-1 border border-mc-border rounded"
                  >
                    {filteredKeys.every(([k]) => showKeys[k]) ? '🙈 Hide All' : '👁 Show All'}
                  </button>
                </div>
              </div>

              {Object.entries(groupedKeys).map(([category, keys]) => (
                <section key={category}>
                  <h3 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">{category}</h3>
                  <div className="space-y-2">
                    {keys.map(([key, value]) => {
                      const meta = API_KEY_META[key] || { label: key, icon: '🔧', placeholder: 'API key', category: 'Custom' };
                      const hasValue = !!value;
                      return (
                        <div key={key} className="bg-mc-bg rounded-lg border border-mc-border p-3">
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-2">
                              <span>{meta.icon}</span>
                              <span className="text-sm font-medium">{meta.label}</span>
                              <span className={`w-2 h-2 rounded-full ${hasValue ? 'bg-green-500' : 'bg-gray-500'}`} title={hasValue ? 'Configured' : 'Not set'} />
                            </div>
                            {!API_KEY_META[key] && (
                              <button onClick={() => removeKey(key)} className="text-xs text-mc-muted hover:text-red-400">Remove</button>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <input type={showKeys[key] ? 'text' : 'password'} value={value}
                              onChange={e => setRawKeys(prev => ({ ...prev, [key]: e.target.value }))}
                              placeholder={meta.placeholder}
                              className="flex-1 px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-mc-text text-xs font-mono focus:outline-none focus:border-mc-accent" />
                            <button onClick={() => setShowKeys(prev => ({ ...prev, [key]: !prev[key] }))}
                              className="px-2 py-1 text-xs text-mc-muted hover:text-mc-text border border-mc-border rounded">
                              {showKeys[key] ? '🙈' : '👁'}
                            </button>
                            {meta.manageUrl && (
                              <a href={meta.manageUrl} target="_blank" rel="noopener noreferrer"
                                className="px-2 py-1 text-xs text-mc-muted hover:text-mc-accent border border-mc-border rounded flex items-center gap-1"
                                title={`Manage ${meta.label} API key`}>
                                🔗
                              </a>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>
              ))}

              <section className="pt-3 border-t border-mc-border">
                <h3 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">Add Custom Key</h3>
                <div className="flex gap-2">
                  <input value={newKeyName} onChange={e => setNewKeyName(e.target.value)}
                    placeholder="Key name" className="w-36 px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:border-mc-accent" />
                  <input value={newKeyValue} onChange={e => setNewKeyValue(e.target.value)}
                    placeholder="Value" className="flex-1 px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm font-mono focus:outline-none focus:border-mc-accent" />
                  <button onClick={addCustomKey} className="px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-sm hover:border-mc-accent">+ Add</button>
                </div>
              </section>

              {rawKeys.elevenlabs && <VoiceBudget />}

              <div className="flex justify-end pt-2">
                <button onClick={() => save()} disabled={saving}
                  className="px-4 py-2 bg-mc-accent text-white rounded text-sm hover:opacity-90 disabled:opacity-50">
                  {saving ? 'Saving...' : '💾 Save All API Keys'}
                </button>
              </div>
            </>
          )}

          {/* ===== SECURITY TAB ===== */}
          {tab === 'security' && (
            <>
              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🔒 Change Password</h3>
                <div className="space-y-2">
                  <input type="password" value={currentPw} onChange={e => setCurrentPw(e.target.value)}
                    placeholder="Current password"
                    className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:border-mc-accent" />
                  <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)}
                    placeholder="New password (min 8 chars)"
                    className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:border-mc-accent" />
                  <input type="password" value={confirmPw} onChange={e => setConfirmPw(e.target.value)}
                    placeholder="Confirm new password"
                    className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:border-mc-accent" />
                  <div className="flex items-center gap-2">
                    <button
                      onClick={async () => {
                        setPwMessage('');
                        const res = await fetch('/api/auth/change-password', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw, confirmPassword: confirmPw }),
                        });
                        const data = await res.json();
                        setPwMessage(data.message || data.error);
                        if (data.success) { setCurrentPw(''); setNewPw(''); setConfirmPw(''); }
                      }}
                      disabled={!currentPw || !newPw || !confirmPw}
                      className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:opacity-90 disabled:opacity-50">
                      Update Password
                    </button>
                    {pwMessage && (
                      <span className={`text-xs ${pwMessage.includes('success') ? 'text-green-400' : 'text-red-400'}`}>{pwMessage}</span>
                    )}
                  </div>
                </div>
              </section>

              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🛡 Security Features</h3>
                <div className="space-y-2 text-sm">
                  {[
                    'Session-based auth (httpOnly cookies)',
                    'Brute force protection (5 attempts → 5min lockout)',
                    'Rate limiting (login, settings, server)',
                    'Security headers (X-Frame, CSP, XSS, etc.)',
                    'robots.txt (Disallow all crawlers)',
                    'Input sanitization (Govee shell commands)',
                    '24-hour session expiry',
                  ].map((feat, i) => (
                    <div key={i} className={`flex items-center justify-between py-2 ${i < 6 ? 'border-b border-mc-border' : ''}`}>
                      <span>{feat}</span>
                      <span className="text-green-400 text-xs">✅ Active</span>
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}

          {/* ===== MODELS TAB ===== */}
          {tab === 'models' && (
            <>
              {(() => {
                const models = [
                  // --- Model Pricing (Updated 2026-02-21) ---
                  // Sources:
                  // - Anthropic: https://platform.claude.com/docs/en/about-claude/pricing
                  // - xAI: https://docs.x.ai/developers/models
                  // - OpenRouter: https://openrouter.ai/models (general overview, specific model pricing not directly extracted)
                  // - NVIDIA Kimi: No clear official pricing page for direct model integration. Based on existing config + search results.
                  // ---------------------------------------------
                  // Anthropic (Direct)
                  { id: 'anthropic/claude-opus-4-6', name: 'Claude Opus 4.6', alias: 'opus', provider: 'Anthropic', providerColor: 'bg-purple-500/20 text-purple-400', tier: 'Tier 1 Executive', tierColor: 'bg-purple-500/20 text-purple-400', agent: null, responseTime: null, cost: '$$$', costDetail: '$5/M in · $25/M out', bestFor: 'Strategy, complex reasoning, critical decisions. Most capable.', status: 'available' },
                  { id: 'anthropic/claude-sonnet-4', name: 'Claude Sonnet 4', alias: null, provider: 'Anthropic', providerColor: 'bg-purple-500/20 text-purple-400', tier: 'Tier 2 VP', tierColor: 'bg-blue-500/20 text-blue-400', agent: null, responseTime: null, cost: '$$', costDetail: '$3/M in · $15/M out', bestFor: 'Balanced quality and cost. Great for coding and analysis.', status: 'available' },
                  { id: 'anthropic/claude-haiku-4-5', name: 'Claude Haiku 4.5', alias: null, provider: 'Anthropic', providerColor: 'bg-purple-500/20 text-purple-400', tier: 'Tier 4 Sr. Manager', tierColor: 'bg-green-500/20 text-green-400', agent: null, responseTime: null, cost: '$', costDetail: '$1/M in · $5/M out', bestFor: 'Quick tasks, report generation, bulk processing. Fast and cheap.', status: 'available' },
                  // xAI (Direct)
                  { id: 'xai/grok-4', name: 'Grok 4', alias: 'grok', provider: 'xAI', providerColor: 'bg-red-500/20 text-red-400', tier: 'Tier 2 VP', tierColor: 'bg-blue-500/20 text-blue-400', agent: 'Viper', responseTime: null, cost: 'FREE', costDetail: '$0 (direct) - TBD (xAI API pricing is $3/M in · $15/M out)', bestFor: 'Trading, X/Twitter research, real-time sentiment via x_search.', status: rawKeys?.grok ? 'available' : 'needs-key' },
                  // OpenRouter
                  { id: 'openrouter/minimax/minimax-m2.5', name: 'MiniMax M2.5', alias: null, provider: 'OpenRouter', providerColor: 'bg-amber-500/20 text-amber-400', tier: 'Tier 2 VP', tierColor: 'bg-blue-500/20 text-blue-400', agent: 'Swift/Pixel/Forge', responseTime: null, cost: '$', costDetail: '$0.30/M in · $1.20/M out (TBD verify)', bestFor: 'Coding, 204K context, 80% SWE-Bench. Default for dev work.', status: rawKeys?.openrouter ? 'available' : 'needs-key' },
                  { id: 'openrouter/google/gemini-2.5-pro', name: 'Gemini 2.5 Pro', alias: null, provider: 'OpenRouter', providerColor: 'bg-amber-500/20 text-amber-400', tier: 'Tier 2 VP', tierColor: 'bg-blue-500/20 text-blue-400', agent: 'Oracle', responseTime: null, cost: '$$', costDetail: '$1.25/M in · $10/M out (TBD verify)', bestFor: '1M context, strong reasoning, document analysis.', status: rawKeys?.openrouter ? 'available' : 'needs-key' },
                  { id: 'openrouter/google/gemini-3-pro-preview', name: 'Gemini 3 Pro', alias: null, provider: 'OpenRouter', providerColor: 'bg-amber-500/20 text-amber-400', tier: 'Tier 2 VP', tierColor: 'bg-blue-500/20 text-blue-400', agent: null, responseTime: null, cost: '$$', costDetail: '$2/M in · $12/M out (TBD verify)', bestFor: 'Latest Gemini. Multimodal, 1M context.', status: rawKeys?.openrouter ? 'available' : 'needs-key' },
                  { id: 'openrouter/x-ai/grok-4.1-fast', name: 'Grok 4.1 Fast', alias: null, provider: 'OpenRouter', providerColor: 'bg-amber-500/20 text-amber-400', tier: 'Tier 3 Director', tierColor: 'bg-cyan-500/20 text-cyan-400', agent: null, responseTime: null, cost: '$', costDetail: '$0.20/M in · $0.50/M out', bestFor: 'Cheapest cloud model. Good for quick tasks.', status: rawKeys?.openrouter ? 'available' : 'needs-key' },
                  // NVIDIA
                  { id: 'nvidia/moonshotai/kimi-k2-instruct', name: 'Kimi K2.5', alias: null, provider: 'NVIDIA', providerColor: 'bg-green-500/20 text-green-400', tier: 'Tier 2 VP', tierColor: 'bg-blue-500/20 text-blue-400', agent: null, responseTime: null, cost: 'FREE', costDetail: '$0 (5K credits) - TBD (verify official NVIDIA pricing for direct integration)', bestFor: 'Long agentic chains (200+ steps), coding. 1T params, 131K context.', status: rawKeys?.nvidia_kimi ? 'available' : 'needs-key' },
                  // Local (LM Studio)
                  { id: 'lmstudio/gemma-3-12b', name: 'Gemma 3 12B', alias: null, provider: 'LM Studio', providerColor: 'bg-blue-500/20 text-blue-400', tier: 'Tier 3 Director', tierColor: 'bg-cyan-500/20 text-cyan-400', agent: 'Nova', responseTime: '~25s', cost: 'FREE', costDetail: '$0', bestFor: 'Quality local analysis, reports, research.', status: 'lmstudio' },
                  { id: 'lmstudio/gemma-3-4b', name: 'Gemma 3 4B', alias: null, provider: 'LM Studio', providerColor: 'bg-blue-500/20 text-blue-400', tier: 'Tier 5 Manager', tierColor: 'bg-orange-500/20 text-orange-400', agent: 'Tank', responseTime: '~14s', cost: 'FREE', costDetail: '$0', bestFor: 'Fast general tasks. Good balance of speed and quality.', status: 'lmstudio' },
                  { id: 'lmstudio/deepseek-r1-0528-qwen3-8b', name: 'DeepSeek R1 8B', alias: null, provider: 'LM Studio', providerColor: 'bg-blue-500/20 text-blue-400', tier: 'Tier 4 Sr. Manager', tierColor: 'bg-green-500/20 text-green-400', agent: 'Cipher', responseTime: '~80s', cost: 'FREE', costDetail: '$0', bestFor: 'Deep reasoning, logic puzzles, analysis.', status: 'lmstudio' },
                  { id: 'lmstudio/ministral-3-3b', name: 'Ministral 3B', alias: null, provider: 'LM Studio', providerColor: 'bg-blue-500/20 text-blue-400', tier: 'Tier 6 Frontline', tierColor: 'bg-gray-500/20 text-gray-400', agent: 'Worker B', responseTime: '~13s', cost: 'FREE', costDetail: '$0', bestFor: 'Bulk grunt work, simple text processing.', status: 'lmstudio' },
                  // Ollama
                  { id: 'ollama/llama3.1:8b', name: 'Ollama 8B', alias: null, provider: 'Ollama', providerColor: 'bg-emerald-500/20 text-emerald-400', tier: 'Tier 5 Manager', tierColor: 'bg-orange-500/20 text-orange-400', agent: 'Runner', responseTime: null, cost: 'FREE', costDetail: '$0', bestFor: 'General mid-range tasks. Always-on local model.', status: 'available' },
                ];
                const costColor = (c: string) => c === 'FREE' ? 'text-green-400' : c === '$' ? 'text-yellow-400' : c === '$$' ? 'text-orange-400' : 'text-red-400';
                const statusBadge = (s: string) => s === 'available' ? { text: '● Available', cls: 'text-green-400' } : s === 'needs-key' ? { text: '🔑 Needs API Key', cls: 'text-yellow-400' } : { text: '💻 Needs LM Studio', cls: 'text-blue-400' };

                return (
                  <div>
                    <h3 className="text-sm font-semibold mb-1 text-mc-accent">🤖 Model Reference</h3>
                    <p className="text-xs text-mc-muted mb-4">All AI models available in your environment.</p>

                    {/* Cloud */}
                    <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-3">☁️ Cloud Models</h4>
                    <div className="grid grid-cols-1 gap-3 mb-6">
                      {models.filter(m => !['LM Studio', 'Ollama'].includes(m.provider)).map(m => {
                        const sb = statusBadge(m.status);
                        return (
                          <div key={m.id} className="bg-mc-bg rounded-lg border border-mc-border p-4">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-semibold">{m.name}</span>
                                {m.alias && <span className="text-[10px] px-1.5 py-0.5 bg-mc-surface border border-mc-border rounded font-mono">{m.alias}</span>}
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.providerColor}`}>{m.provider}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.tierColor}`}>{m.tier}</span>
                              </div>
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <span className={`text-xs font-bold ${costColor(m.cost)}`}>{m.cost}</span>
                                <span className={`text-[10px] ${sb.cls}`}>{sb.text}</span>
                              </div>
                            </div>
                            <div className="text-xs text-mc-muted">{m.bestFor}</div>
                            <div className="text-[10px] text-mc-muted mt-1 font-mono">{m.costDetail}</div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Local - LM Studio */}
                    <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-3">💻 Local Models — LM Studio ($0 cost, one at a time)</h4>
                    <div className="grid grid-cols-1 gap-3 mb-6">
                      {models.filter(m => m.provider === 'LM Studio').map(m => {
                        const sb = statusBadge(m.status);
                        return (
                          <div key={m.id} className="bg-mc-bg rounded-lg border border-mc-border p-4">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-semibold">{m.name}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.providerColor}`}>{m.provider}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.tierColor}`}>{m.tier}</span>
                                {m.agent && <span className="text-[10px] px-2 py-0.5 rounded-full bg-mc-accent/20 text-mc-accent font-medium">🤖 {m.agent}</span>}
                              </div>
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <span className={`text-xs font-bold ${costColor(m.cost)}`}>{m.cost}</span>
                                {m.responseTime && <span className="text-[10px] text-mc-muted">⏱ {m.responseTime}</span>}
                              </div>
                            </div>
                            <div className="text-xs text-mc-muted">{m.bestFor}</div>
                            <div className="flex items-center gap-2 mt-1">
                              <span className={`text-[10px] ${sb.cls}`}>{sb.text}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Local - Ollama */}
                    <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-3">🟢 Local Models — Ollama ($0 cost, always available)</h4>
                    <div className="grid grid-cols-1 gap-3">
                      {models.filter(m => m.provider === 'Ollama').map(m => {
                        const sb = statusBadge(m.status);
                        return (
                          <div key={m.id} className="bg-mc-bg rounded-lg border border-mc-border p-4">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-semibold">{m.name}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.providerColor}`}>{m.provider}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.tierColor}`}>{m.tier}</span>
                                {m.agent && <span className="text-[10px] px-2 py-0.5 rounded-full bg-mc-accent/20 text-mc-accent font-medium">🤖 {m.agent}</span>}
                              </div>
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <span className={`text-xs font-bold ${costColor(m.cost)}`}>{m.cost}</span>
                                <span className={`text-[10px] ${sb.cls}`}>{sb.text}</span>
                              </div>
                            </div>
                            <div className="text-xs text-mc-muted">{m.bestFor}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {/* ===== MODEL SETTINGS (editable context windows) ===== */}
              <div className="mt-8 border-t border-mc-border pt-6">
                <h3 className="text-sm font-semibold mb-1 text-mc-accent">⚙️ Edit Context Windows</h3>
                <p className="text-xs text-mc-muted mb-4">Adjust context window and max output limits per model.</p>
                <ModelSettingsPage />
              </div>
            </>
          )}

          {/* ===== AGENT TIERS TAB ===== */}
          {tab === 'tiers' && (
            <>
              <section>
                <h3 className="text-sm font-semibold mb-1 text-mc-accent">🏷️ Agent Tier Configuration</h3>
                <p className="text-xs text-mc-muted mb-4">Configure the default AI model for each organizational tier. Agents can override with individual model settings.</p>
                <div className="space-y-3">
                  {[0, 1, 2, 3, 4, 5, 6].map(tierNum => {
                    const tier = tiers[String(tierNum)];
                    if (!tier) return null;
                    const tierColor = TIER_COLORS[tierNum] || 'text-gray-400';
                    return (
                      <div key={tierNum} className="bg-mc-bg rounded-lg border border-mc-border p-4">
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3 min-w-0">
                            <span className={`text-lg font-bold ${tierColor}`}>{tierNum}</span>
                            <div>
                              <div className={`text-sm font-semibold ${tierColor}`}>{tier.label}</div>
                              <div className="text-[10px] text-mc-muted">
                                {tierNum === 0 ? 'Human owner — no model' : `Default model for tier ${tierNum} agents`}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <select
                              value={tier.defaultModel || ''}
                              onChange={e => {
                                setTiers(prev => ({
                                  ...prev,
                                  [String(tierNum)]: {
                                    ...prev[String(tierNum)],
                                    defaultModel: e.target.value || null,
                                  },
                                }));
                              }}
                              disabled={tierNum === 0}
                              className="w-52 px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:border-mc-accent disabled:opacity-50"
                            >
                              {MODEL_OPTIONS.map(m => (
                                <option key={m.value} value={m.value}>{m.label}</option>
                              ))}
                            </select>
                            <input
                              type="number"
                              value={tier.maxTokens || ''}
                              onChange={e => setTiers(prev => ({
                                ...prev,
                                [String(tierNum)]: { ...prev[String(tierNum)], maxTokens: parseInt(e.target.value) || undefined },
                              }))}
                              placeholder="Max tokens"
                              disabled={tierNum === 0}
                              className="w-28 px-2 py-1.5 bg-mc-surface border border-mc-border rounded text-mc-text text-xs font-mono focus:outline-none focus:border-mc-accent disabled:opacity-50"
                            />
                          </div>
                        </div>
                        <input
                          value={tier.description || ''}
                          onChange={e => setTiers(prev => ({
                            ...prev,
                            [String(tierNum)]: { ...prev[String(tierNum)], description: e.target.value },
                          }))}
                          placeholder="Tier description..."
                          disabled={tierNum === 0}
                          className="w-full mt-2 px-3 py-1 bg-mc-surface border border-mc-border rounded text-mc-text text-xs focus:outline-none focus:border-mc-accent disabled:opacity-50"
                        />
                      </div>
                    );
                  })}
                </div>
              </section>

              <div className="flex items-center justify-between pt-2">
                {tiersMessage && (
                  <span className={`text-xs ${tiersMessage.startsWith('Error') ? 'text-red-400' : 'text-green-400'}`}>{tiersMessage}</span>
                )}
                <div className="ml-auto">
                  <button onClick={saveTiers} disabled={tiersSaving}
                    className="px-4 py-2 bg-mc-accent text-white rounded text-sm hover:opacity-90 disabled:opacity-50">
                    {tiersSaving ? 'Saving...' : '💾 Save Tier Config'}
                  </button>
                </div>
              </div>
            </>
          )}
          {/* ===== CHARACTERS TAB ===== */}
          {tab === 'characters' && (
            <>
              {/* ── Section 1: Procedural Characters ── */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-semibold text-mc-accent">🧱 Procedural Characters</h3>
                    <p className="text-xs text-mc-muted mt-0.5">Built-in 3D shapes created programmatically in Three.js. Always available as fallback.</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {charTypes.map((ct, idx) => (
                    <div key={ct.id} className="bg-mc-bg rounded-lg border border-mc-border p-4">
                      <div className="flex items-start gap-4">
                        {/* Emoji preview */}
                        <div className="flex flex-col items-center gap-1">
                          <div className="w-16 h-16 rounded-xl bg-mc-surface border border-mc-border flex items-center justify-center text-4xl">
                            {ct.emoji}
                          </div>
                          <input
                            value={ct.emoji}
                            onChange={e => {
                              const updated = [...charTypes];
                              updated[idx] = { ...updated[idx], emoji: e.target.value };
                              setCharTypes(updated);
                            }}
                            className="w-16 text-center px-1 py-0.5 bg-mc-surface border border-mc-border rounded text-xs"
                            placeholder="emoji"
                          />
                        </div>

                        {/* Fields */}
                        <div className="flex-1 space-y-2">
                          <div className="flex gap-2">
                            <input
                              value={ct.name}
                              onChange={e => {
                                const updated = [...charTypes];
                                updated[idx] = { ...updated[idx], name: e.target.value };
                                setCharTypes(updated);
                              }}
                              className="flex-1 px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-sm font-medium focus:outline-none focus:border-mc-accent"
                              placeholder="Name"
                            />
                            <span className="text-[10px] text-mc-muted self-center font-mono">{ct.id}</span>
                          </div>
                          <input
                            value={ct.description}
                            onChange={e => {
                              const updated = [...charTypes];
                              updated[idx] = { ...updated[idx], description: e.target.value };
                              setCharTypes(updated);
                            }}
                            className="w-full px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-xs focus:outline-none focus:border-mc-accent"
                            placeholder="Description"
                          />
                          {/* Default 3D Asset dropdown */}
                          <div>
                            <label className="text-[10px] text-mc-muted uppercase tracking-wide">Default 3D Asset</label>
                            <select
                              value={ct.asset3d || ''}
                              onChange={e => {
                                const updated = [...charTypes];
                                updated[idx] = { ...updated[idx], asset3d: e.target.value || null };
                                setCharTypes(updated);
                              }}
                              className="w-full mt-0.5 px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-xs focus:outline-none focus:border-mc-accent"
                            >
                              <option value="">None (Procedural)</option>
                              {glbFiles.map(f => (
                                <option key={f} value={f}>{f.split('/').pop()}</option>
                              ))}
                            </select>
                            <div className="text-[10px] text-mc-muted mt-0.5 italic">Used when agent has no per-agent GLB override</div>
                          </div>
                          {/* Agent usage info */}
                          {(() => {
                            const usingAgents = allAgents.filter(a => (a.avatarType || a.characterType) === ct.id);
                            return (
                              <div className="mt-1">
                                <span className="text-[10px] text-mc-muted">
                                  Agents using this type: <span className="font-bold text-mc-text">{usingAgents.length}</span>
                                  {usingAgents.length > 0 && (
                                    <span> — {usingAgents.map(a => a.displayName || a.name).join(', ')}</span>
                                  )}
                                </span>
                              </div>
                            );
                          })()}
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-1">
                          <button
                            onClick={async () => {
                              setCharSaving(s => ({ ...s, [ct.id]: true }));
                              try {
                                await fetch('/api/character-types', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify(ct),
                                });
                              } catch {}
                              setCharSaving(s => ({ ...s, [ct.id]: false }));
                            }}
                            disabled={charSaving[ct.id]}
                            className="px-3 py-1.5 text-xs bg-mc-accent text-white rounded hover:opacity-90 disabled:opacity-50"
                          >
                            {charSaving[ct.id] ? '...' : '💾'}
                          </button>
                          {charDeleting === ct.id ? (
                            <div className="flex gap-1">
                              <button
                                onClick={async () => {
                                  await fetch(`/api/character-types?id=${ct.id}`, { method: 'DELETE' });
                                  setCharTypes(prev => prev.filter(t => t.id !== ct.id));
                                  setCharDeleting(null);
                                }}
                                className="px-2 py-1 text-[10px] bg-red-600 text-white rounded"
                              >Yes</button>
                              <button onClick={() => setCharDeleting(null)} className="px-2 py-1 text-[10px] text-mc-muted bg-mc-surface rounded">No</button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setCharDeleting(ct.id)}
                              className="px-3 py-1.5 text-xs text-mc-muted hover:text-red-400 bg-mc-surface border border-mc-border rounded"
                            >🗑</button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={async () => {
                    const res = await fetch('/api/character-types', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ name: 'New Character', emoji: '❓', description: '' }),
                    });
                    const d = await res.json();
                    if (d.type) setCharTypes(prev => [...prev, d.type]);
                  }}
                  className="mt-4 w-full py-3 text-sm text-mc-muted bg-mc-bg border border-dashed border-mc-border rounded-lg hover:border-mc-accent hover:text-mc-accent transition-colors"
                >
                  ➕ Add New Character Type
                </button>
              </div>

              {/* ── Section 2: GLB Character Library ── */}
              <div>
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-mc-accent">📦 GLB Character Library</h3>
                  <p className="text-xs text-mc-muted mt-0.5">Imported 3D models (.glb) that can override procedural characters. Assign as default for a character type above, or per-agent on their profile.</p>
                </div>

                {glbFiles.length === 0 ? (
                  <div className="bg-mc-bg rounded-lg border border-mc-border p-6 text-center">
                    <p className="text-sm text-mc-muted">No .glb files found.</p>
                    <p className="text-xs text-mc-muted mt-1">Place .glb files in <code className="font-mono text-[10px] bg-mc-surface px-1 py-0.5 rounded">openclaw-world/public/assets/characters/</code></p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {glbFiles.map(f => {
                      const filename = f.split('/').pop() || f;
                      const usedByTypes = charTypes.filter(ct => ct.asset3d === f);
                      return (
                        <div key={f} className="bg-mc-bg rounded-lg border border-mc-border p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-lg bg-mc-surface border border-mc-border flex items-center justify-center text-2xl flex-shrink-0">
                              🎮
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium truncate" title={filename}>{filename}</div>
                              <div className="text-[10px] text-mc-muted font-mono truncate" title={f}>{f}</div>
                              {usedByTypes.length > 0 && (
                                <div className="text-[10px] text-mc-accent mt-0.5">
                                  Default for: {usedByTypes.map(t => `${t.emoji} ${t.name}`).join(', ')}
                                </div>
                              )}
                              <div className="text-[10px] text-mc-muted mt-0.5 italic">Preview in Agent World</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}

          {/* ===== SYSTEM TAB ===== */}
          {tab === 'system' && (
            <>
              <section>
                <h3 className="text-sm font-semibold mb-3 text-mc-accent">🧠 Context Health Monitor</h3>
                <p className="text-xs text-mc-muted mb-4">
                  Monitor OpenClaw session context usage and trigger memory compaction when needed.
                  Auto-refreshes every 60 seconds.
                </p>
                <ContextHealth />
              </section>
            </>
          )}

          {/* ===== CRON MANAGER TAB ===== */}
          {tab === 'crons' && (
            <>
              <section>
                <h3 className="text-sm font-semibold mb-1 text-mc-accent">⏰ Cron Manager</h3>
                <p className="text-xs text-mc-muted mb-4">Schedule and manage recurring jobs and timed events.</p>
                <CronManagerPage />
              </section>
            </>
          )}
        </div>
        </div>{/* end flex body */}

        {/* Footer */}
        {message && (
          <div className={`px-6 py-3 text-sm border-t border-mc-border flex items-start gap-2 ${message.startsWith('Error') ? 'bg-red-900/20 text-red-400' : 'bg-green-900/20 text-green-400'}`}>
            <span className="flex-shrink-0">{message.startsWith('Error') ? '❌' : '✅'}</span>
            <span className="break-all whitespace-pre-wrap">{message}</span>
            <button onClick={() => setMessage('')} className="flex-shrink-0 ml-auto text-mc-muted hover:text-mc-text">✕</button>
          </div>
        )}
      </div>
    </div>
  );
}
