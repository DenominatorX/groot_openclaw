'use client';
import { useState, useEffect } from 'react';

interface Mood {
  id: string;
  name: string;
  emoji: string;
  description?: string;
}

interface BrainResult {
  summary: string;
  projects: Array<{
    title: string;
    description: string;
    priority: string;
  }>;
  tasks: Array<{
    title: string;
    description: string;
    assignee: string;
    priority: string;
  }>;
  risks: Array<{
    description: string;
    severity: string;
  }>;
  ideas: Array<{
    title: string;
    description: string;
    category: string;
  }>;
  mood_detected: string;
  key_themes: string[];
}

interface DumpEntry {
  id: string;
  rawText: string;
  mood: string;
  analysis: BrainResult;
  timestamp: string;
}

const BRAIN_MOODS: Mood[] = [
  { id: 'default', name: 'Default', emoji: '😐', description: 'Neutral & analytical' },
  { id: 'goofy', name: 'Goofy', emoji: '🤪', description: 'Fun & playful' },
  { id: 'angry', name: 'Angry', emoji: '😤', description: 'Fired up & intense' },
  { id: 'happy', name: 'Happy', emoji: '😊', description: 'Upbeat & positive' },
  { id: 'sad', name: 'Sad', emoji: '😢', description: 'Thoughtful & reflective' },
  { id: 'focused', name: 'Focused', emoji: '🎯', description: 'Laser-focused' },
  { id: 'creative', name: 'Creative', emoji: '🎨', description: 'Imaginative & innovative' },
  { id: 'skeptical', name: 'Skeptical', emoji: '🤨', description: 'Questioning & critical' },
  { id: 'hype', name: 'Hype', emoji: '🔥', description: 'Energized & pumped' },
  { id: 'zen', name: 'Zen', emoji: '🧘', description: 'Calm & centered' },
  { id: 'detective', name: 'Detective', emoji: '🔍', description: 'Investigative & thorough' },
  { id: 'mentor', name: 'Mentor', emoji: '🎓', description: 'Teaching & guiding' },
];

const MOOD_COLORS: Record<string, string> = {
  default: 'bg-slate-500/10',
  goofy: 'bg-yellow-500/10',
  angry: 'bg-red-500/10',
  happy: 'bg-green-500/10',
  sad: 'bg-blue-500/10',
  focused: 'bg-purple-500/10',
  creative: 'bg-pink-500/10',
  skeptical: 'bg-amber-500/10',
  hype: 'bg-orange-500/10',
  zen: 'bg-cyan-500/10',
  detective: 'bg-indigo-500/10',
  mentor: 'bg-emerald-500/10',
};

export default function BrainDump({ agent }: { agent: any }) {
  const [selectedMood, setSelectedMood] = useState<string>('default');
  const [text, setText] = useState('');
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<BrainResult | null>(null);
  const [currentDumpId, setCurrentDumpId] = useState<string>('');
  const [history, setHistory] = useState<DumpEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [checkedProjects, setCheckedProjects] = useState<Set<number>>(new Set());
  const [checkedTasks, setCheckedTasks] = useState<Set<number>>(new Set());
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    // Load history on mount
    fetch('/api/brain/dump').then(r => r.json()).then(d => {
      if (d.dumps) setHistory(d.dumps);
    }).catch(() => {});
  }, []);

  const processDump = async () => {
    if (!text.trim()) return;
    setProcessing(true);
    try {
      const res = await fetch('/api/brain/dump', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, mood: selectedMood }),
      });
      const data = await res.json();
      if (!res.ok) {
        console.error('Error:', data.error);
        return;
      }
      
      setResult(data.analysis);
      setCurrentDumpId(data.id);
      setCheckedProjects(new Set(Array.from({ length: data.analysis?.projects?.length || 0 }, (_, i) => i)));
      setCheckedTasks(new Set(Array.from({ length: data.analysis?.tasks?.length || 0 }, (_, i) => i)));
      
      // Reload history
      const historyRes = await fetch('/api/brain/dump');
      const historyData = await historyRes.json();
      if (historyData.dumps) setHistory(historyData.dumps);
    } catch (err) {
      console.error('Error processing dump:', err);
    } finally {
      setProcessing(false);
    }
  };

  const applyToKanban = async () => {
    if (!currentDumpId || !result) return;
    
    setApplying(true);
    try {
      const res = await fetch('/api/brain/dump/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dumpId: currentDumpId,
          applyProjects: checkedProjects.size > 0,
          applyTasks: checkedTasks.size > 0,
        }),
      });
      
      if (res.ok) {
        // Clear the dumps and reset state
        setText('');
        setResult(null);
        setCurrentDumpId('');
        setCheckedProjects(new Set());
        setCheckedTasks(new Set());
      }
    } catch (err) {
      console.error('Error applying dump:', err);
    } finally {
      setApplying(false);
    }
  };

  const moodObj = BRAIN_MOODS.find(m => m.id === selectedMood);

  return (
    <div className={`space-y-4 p-4 rounded-lg transition-colors ${MOOD_COLORS[selectedMood]}`}>
      {/* Mood Selector */}
      <div>
        <label className="text-xs text-mc-muted uppercase tracking-wide mb-2 block">Mood</label>
        <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
          {BRAIN_MOODS.map(m => (
            <button key={m.id} onClick={() => setSelectedMood(m.id)}
              className={`px-2 py-2 rounded border text-center transition-all ${
                selectedMood === m.id
                  ? 'border-mc-accent bg-mc-accent/20 text-mc-accent scale-105'
                  : 'border-mc-border bg-mc-bg text-mc-muted hover:border-mc-accent/50'
              }`}
              title={m.description}>
              <div className="text-lg">{m.emoji}</div>
              <div className="text-[9px] mt-0.5 truncate">{m.name}</div>
            </button>
          ))}
        </div>
        {moodObj && <div className="text-[10px] text-mc-muted mt-2">{moodObj.emoji} {moodObj.description}</div>}
      </div>

      {/* Brain Dump Input */}
      <div>
        <label className="text-[10px] text-mc-muted uppercase tracking-wide mb-2 block">Brain Dump</label>
        <textarea value={text} onChange={e => setText(e.target.value)}
          placeholder="Dump your thoughts here... Brain will organize them."
          className="w-full bg-mc-bg border border-mc-border rounded-lg p-4 text-sm text-mc-text resize-none focus:outline-none focus:border-mc-accent"
          style={{ minHeight: '120px' }} />
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2">
        <button onClick={processDump} disabled={processing || !text.trim()}
          className="flex-1 px-4 py-2.5 bg-mc-accent text-white rounded-lg font-medium text-sm hover:opacity-90 disabled:opacity-50 transition-opacity">
          {processing ? '🧠 Processing...' : '🧠 Process Dump'}
        </button>
        <button onClick={() => setShowHistory(!showHistory)}
          className="px-3 py-2.5 bg-mc-bg border border-mc-border rounded-lg text-sm text-mc-muted hover:text-mc-text">
          📜 History ({history.length})
        </button>
      </div>

      {/* Processing indicator */}
      {processing && (
        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg px-4 py-3 flex items-center gap-3 animate-pulse">
          <div className="w-5 h-5 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
          <span className="text-sm text-purple-400">Brain is synthesizing... analyzing all projects, tasks, agents, and risks...</span>
        </div>
      )}

      {/* Results Panel */}
      {result && (
        <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-mc-border flex items-center justify-between">
            <h3 className="text-sm font-bold">🧠 Brain&apos;s Analysis</h3>
          </div>

          {/* Summary */}
          {result.summary && (
            <div className="px-4 py-3 border-b border-mc-border bg-mc-bg">
              <div className="text-xs text-mc-muted mb-1">Summary</div>
              <div className="text-sm">{result.summary}</div>
            </div>
          )}

          {/* Detected Mood */}
          {result.mood_detected && (
            <div className="px-4 py-3 border-b border-mc-border">
              <div className="text-xs text-mc-muted mb-1">Detected Mood</div>
              <div className="text-sm">{result.mood_detected}</div>
            </div>
          )}

          {/* Key Themes */}
          {result.key_themes?.length > 0 && (
            <div className="px-4 py-3 border-b border-mc-border">
              <div className="text-xs text-mc-muted mb-2">Key Themes</div>
              <div className="flex flex-wrap gap-1.5">
                {result.key_themes.map((theme, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-mc-accent/20 text-mc-accent">
                    {theme}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Projects to Create */}
          {result.projects?.length > 0 && (
            <div className="px-4 py-3 border-b border-mc-border">
              <div className="text-xs text-mc-muted mb-2 font-medium">📁 Projects ({result.projects.length})</div>
              {result.projects.map((proj, i) => (
                <div key={i} className="bg-mc-bg border border-mc-border rounded p-3 mb-2">
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={checkedProjects.has(i)}
                      onChange={(e) => {
                        const newSet = new Set(checkedProjects);
                        if (e.target.checked) newSet.add(i);
                        else newSet.delete(i);
                        setCheckedProjects(newSet);
                      }}
                      className="mt-1 cursor-pointer"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-sm">{proj.title}</div>
                      <div className="text-xs text-mc-muted mt-1">{proj.description}</div>
                      <div className="flex gap-2 mt-1">
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-mc-accent/20 text-mc-accent">{proj.priority}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tasks to Create */}
          {result.tasks?.length > 0 && (
            <div className="px-4 py-3 border-b border-mc-border">
              <div className="text-xs text-mc-muted mb-2 font-medium">✅ Tasks ({result.tasks.length})</div>
              {result.tasks.map((task, i) => (
                <div key={i} className="bg-mc-bg border border-mc-border rounded p-3 mb-2">
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={checkedTasks.has(i)}
                      onChange={(e) => {
                        const newSet = new Set(checkedTasks);
                        if (e.target.checked) newSet.add(i);
                        else newSet.delete(i);
                        setCheckedTasks(newSet);
                      }}
                      className="mt-1 cursor-pointer"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-sm">{task.title}</div>
                      <div className="text-xs text-mc-muted mt-1">{task.description}</div>
                      <div className="flex gap-2 mt-1">
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-mc-accent/20 text-mc-accent">{task.priority}</span>
                        {task.assignee && <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-400">{task.assignee}</span>}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Risks */}
          {result.risks?.length > 0 && (
            <div className="px-4 py-3 border-b border-mc-border">
              <div className="text-xs text-mc-muted mb-2 font-medium">⚠️ Risks ({result.risks.length})</div>
              {result.risks.map((r, i) => (
                <div key={i} className="bg-red-500/10 border border-red-500/20 rounded p-2 mb-1">
                  <div className="text-sm font-medium">{r.description}</div>
                  <div className="text-[10px] text-mc-muted">Severity: {r.severity}</div>
                </div>
              ))}
            </div>
          )}

          {/* Ideas */}
          {result.ideas?.length > 0 && (
            <div className="px-4 py-3 border-b border-mc-border">
              <div className="text-xs text-mc-muted mb-2 font-medium">💡 Ideas ({result.ideas.length})</div>
              {result.ideas.map((idea, i) => (
                <div key={i} className="bg-mc-bg border border-mc-border rounded p-3 mb-2">
                  <div className="font-medium text-sm">{idea.title}</div>
                  <div className="text-xs text-mc-muted mt-1">{idea.description}</div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 inline-block mt-1">
                    {idea.category}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Apply to Kanban Button */}
          {(checkedProjects.size > 0 || checkedTasks.size > 0) && (
            <div className="px-4 py-3">
              <button onClick={applyToKanban} disabled={applying}
                className="w-full px-4 py-2 bg-green-600 text-white rounded-lg font-medium text-sm hover:bg-green-700 disabled:opacity-50 transition-colors">
                {applying ? '⏳ Applying...' : '✅ Apply to Kanban'}
              </button>
              <div className="text-[10px] text-mc-muted mt-1">
                {checkedProjects.size} project{checkedProjects.size !== 1 ? 's' : ''} • {checkedTasks.size} task{checkedTasks.size !== 1 ? 's' : ''} selected
              </div>
            </div>
          )}
        </div>
      )}

      {/* History */}
      {showHistory && (
        <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-mc-border">
            <h3 className="text-sm font-bold">📜 Brain Dump History</h3>
          </div>
          <div className="max-h-60 overflow-y-auto">
            {history.length === 0 ? (
              <div className="px-4 py-6 text-center text-xs text-mc-muted">No brain dumps yet</div>
            ) : history.map((d) => (
              <button key={d.id} onClick={() => {
                setResult(d.analysis);
                setText(d.rawText);
                setSelectedMood(d.mood || 'default');
                setCurrentDumpId(d.id);
                setShowHistory(false);
              }}
                className="w-full text-left px-4 py-2.5 hover:bg-mc-bg border-b border-mc-border transition-colors">
                <div className="flex items-center justify-between">
                  <div className="text-sm truncate flex-1">{d.rawText.slice(0, 80)}{d.rawText.length > 80 ? '...' : ''}</div>
                  <div className="text-[10px] text-mc-muted flex-shrink-0 ml-2">
                    {BRAIN_MOODS.find(m => m.id === d.mood)?.emoji || '🧠'} {new Date(d.timestamp).toLocaleDateString()}
                  </div>
                </div>
                <div className="text-[10px] text-mc-muted mt-0.5">
                  {d.analysis?.projects?.length || 0} projects · {d.analysis?.tasks?.length || 0} tasks · {d.analysis?.risks?.length || 0} risks
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
