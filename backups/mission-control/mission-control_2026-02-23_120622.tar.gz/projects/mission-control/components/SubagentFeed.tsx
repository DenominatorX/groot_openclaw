'use client';
import { useState, useEffect, useCallback } from 'react';
import { Bot, Clock, User, Zap, CheckCircle, XCircle, Loader2, MessageSquare, Navigation, Trash2, Eye, X } from 'lucide-react';

interface SubagentRun {
  id: string;
  label: string;
  spawnedBy: string;
  spawnedByName?: string;
  agentId: string;
  agentName?: string;
  model: string;
  taskSummary: string;
  status: 'running' | 'completed' | 'failed';
  resultSummary?: string;
  costUsd?: number;
  durationMs?: number;
  startedAt: string;
  completedAt?: string;
}

interface SubagentFeedData {
  subagents: SubagentRun[];
  summary: {
    running: number;
    completed: number;
    failed: number;
  };
}

function timeAgo(ts: string) {
  if (!ts) return 'Never';
  const diff = Date.now() - new Date(ts).getTime();
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function formatDuration(ms: number) {
  if (!ms) return '-';
  const secs = Math.floor(ms / 1000);
  if (secs < 60) return `${secs}s`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ${secs % 60}s`;
  const hrs = Math.floor(mins / 60);
  return `${hrs}h ${mins % 60}m`;
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'running':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-400">
          <Loader2 className="w-3 h-3 animate-spin" />
          Running
        </span>
      );
    case 'completed':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-green-500/20 text-green-400">
          <CheckCircle className="w-3 h-3" />
          Completed
        </span>
      );
    case 'failed':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-red-500/20 text-red-400">
          <XCircle className="w-3 h-3" />
          Failed
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-gray-500/20 text-gray-400">
          {status}
        </span>
      );
  }
}

export default function SubagentFeed({ embedded = false }: { embedded?: boolean }) {
  const [data, setData] = useState<SubagentFeedData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  
  // Modal states
  const [modalType, setModalType] = useState<'nudge' | 'steer' | 'view' | null>(null);
  const [selectedSubagent, setSelectedSubagent] = useState<SubagentRun | null>(null);
  const [modalMessage, setModalMessage] = useState('');
  const [sessionHistory, setSessionHistory] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [killConfirm, setKillConfirm] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const response = await fetch('/api/subagents');
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      const result = await response.json();
      setData(result);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      // Mock data for development
      setData({
        subagents: [
          {
            id: 'sa-001',
            label: 'Pixel Frontend Engineer',
            spawnedBy: 'groot',
            spawnedByName: 'Groot',
            agentId: 'pixel',
            agentName: 'Pixel',
            model: 'minimax/minimax-m2.5',
            taskSummary: 'Build Discord Session Manager component',
            status: 'running',
            startedAt: new Date(Date.now() - 5 * 60000).toISOString(),
          },
          {
            id: 'sa-002',
            label: 'Forge Backend Engineer',
            spawnedBy: 'groot',
            spawnedByName: 'Groot',
            agentId: 'forge',
            agentName: 'Forge',
            model: 'minimax/minimax-m2.5',
            taskSummary: 'Create Discord Sessions API endpoints',
            status: 'completed',
            resultSummary: 'Created GET/POST endpoints for discord-sessions',
            costUsd: 0.12,
            durationMs: 45000,
            startedAt: new Date(Date.now() - 30 * 60000).toISOString(),
            completedAt: new Date(Date.now() - 25 * 60000).toISOString(),
          },
          {
            id: 'sa-003',
            label: 'Sentinel QA Reviewer',
            spawnedBy: 'groot',
            spawnedByName: 'Groot',
            agentId: 'sentinel',
            agentName: 'Sentinel',
            model: 'anthropic/claude-sonnet-4-6',
            taskSummary: 'Review code changes',
            status: 'failed',
            resultSummary: 'Build failed due to missing dependencies',
            costUsd: 0.08,
            durationMs: 120000,
            startedAt: new Date(Date.now() - 60 * 60000).toISOString(),
            completedAt: new Date(Date.now() - 58 * 60000).toISOString(),
          },
        ],
        summary: { running: 1, completed: 1, failed: 1 },
      });
    } finally {
      setLoading(false);
    }
  }, []);

  // Action handlers
  const handleNudge = (subagent: SubagentRun) => {
    setSelectedSubagent(subagent);
    setModalType('nudge');
    setModalMessage('');
  };

  const handleSteer = (subagent: SubagentRun) => {
    setSelectedSubagent(subagent);
    setModalType('steer');
    setModalMessage('');
  };

  const handleKill = async (subagent: SubagentRun) => {
    if (killConfirm !== subagent.id) {
      setKillConfirm(subagent.id);
      setTimeout(() => setKillConfirm(null), 3000);
      return;
    }
    try {
      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'kill', sessionKey: subagent.id }),
      });
      if (response.ok) {
        // Update local state to show killed badge or remove row
        setData(prev => prev ? {
          ...prev,
          subagents: prev.subagents.map(s => 
            s.id === subagent.id ? { ...s, status: 'failed' as const, resultSummary: 'Killed by user' } : s
          ),
          summary: { ...prev.summary, running: prev.summary.running - 1, failed: prev.summary.failed + 1 }
        } : null);
      }
    } catch (err) {
      console.error('Failed to kill subagent:', err);
    }
    setKillConfirm(null);
  };

  const handleView = async (subagent: SubagentRun) => {
    setSelectedSubagent(subagent);
    setModalType('view');
    setHistoryLoading(true);
    try {
      const response = await fetch(`/api/context-health?action=history&sessionKey=${subagent.id}`);
      if (response.ok) {
        const data = await response.json();
        setSessionHistory(data.history || []);
      } else {
        setSessionHistory([]);
      }
    } catch (err) {
      console.error('Failed to fetch history:', err);
      setSessionHistory([]);
    } finally {
      setHistoryLoading(false);
    }
  };

  const handleModalSubmit = async () => {
    if (!selectedSubagent || !modalMessage.trim()) return;
    
    const action = modalType === 'nudge' ? 'send_message' : 'send_message';
    try {
      await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action, 
          sessionKey: selectedSubagent.id, 
          message: modalMessage 
        }),
      });
    } catch (err) {
      console.error('Failed to send message:', err);
    }
    setModalType(null);
    setSelectedSubagent(null);
    setModalMessage('');
  };

  const closeModal = () => {
    setModalType(null);
    setSelectedSubagent(null);
    setModalMessage('');
    setSessionHistory([]);
  };

  useEffect(() => {
    fetchData();
    // Auto-refresh every 10 seconds
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, [fetchData]);

  if (loading) {
    return (
      <div className={`bg-mc-surface border border-mc-border rounded-lg p-4 ${embedded ? '' : 'animate-pulse'}`}>
        <div className="text-sm text-mc-muted">Loading sub-agents...</div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="text-sm text-red-400">Error: {error}</div>
        <button onClick={fetchData} className="mt-2 text-xs text-mc-accent hover:underline">
          Retry
        </button>
      </div>
    );
  }

  const summary = data?.summary || { running: 0, completed: 0, failed: 0 };
  const subagents = data?.subagents || [];

  // Sort: running first, then by start time
  const sortedSubagents = [...subagents].sort((a, b) => {
    if (a.status === 'running' && b.status !== 'running') return -1;
    if (b.status === 'running' && a.status !== 'running') return 1;
    return new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime();
  });

  return (
    <div className={`bg-mc-surface border border-mc-border rounded-lg overflow-hidden ${embedded ? '' : 'mb-4'}`}>
      {/* Header */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-mc-bg/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className="text-sm">🤖</span>
          <span className="text-sm font-semibold">Sub-agent Activity</span>
          <span className="text-xs text-mc-muted">({subagents.length} total)</span>
        </div>
        <div className="flex items-center gap-2">
          {summary.running > 0 && (
            <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400">
              {summary.running} running
            </span>
          )}
          {summary.completed > 0 && (
            <span className="text-xs px-2 py-0.5 rounded bg-green-500/20 text-green-400">
              {summary.completed} completed
            </span>
          )}
          {summary.failed > 0 && (
            <span className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400">
              {summary.failed} failed
            </span>
          )}
          <span className="text-mc-muted">{collapsed ? '▶' : '▼'}</span>
        </div>
      </button>

      {/* Collapsible Content */}
      {!collapsed && (
        <div className="border-t border-mc-border">
          {/* Refresh button */}
          <div className="px-4 py-2 flex border-b border-mc-border/50">
            <button
              onClick={fetchData}
              className="px-2 py-1 text-xs text-mc-muted hover:text-mc-accent flex items-center gap-1"
              title="Refresh"
            >
              🔄 Refresh
            </button>
            <span className="ml-auto text-[10px] text-mc-muted">Auto-refreshes every 10s</span>
          </div>

          {/* Sub-agent list */}
          <div className="p-3 space-y-2 max-h-[400px] overflow-y-auto">
            {sortedSubagents.map((subagent) => (
              <div
                key={subagent.id}
                className={`bg-mc-bg border rounded-lg p-3 ${
                  subagent.status === 'failed'
                    ? 'border-red-500/30'
                    : subagent.status === 'running'
                    ? 'border-blue-500/30'
                    : 'border-mc-border'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-mc-accent" />
                      <span className="text-xs font-medium truncate">{subagent.label}</span>
                    </div>
                    <div className="text-[10px] text-mc-muted mt-1 flex items-center gap-2">
                      <User className="w-3 h-3" />
                      <span>Spawned by {subagent.spawnedByName || subagent.spawnedBy}</span>
                    </div>
                  </div>
                  <StatusBadge status={subagent.status} />
                </div>

                {/* Task summary */}
                <div className="text-xs text-mc-text mb-2 line-clamp-2">
                  {subagent.taskSummary}
                </div>

                {/* Details row */}
                <div className="flex items-center justify-between text-[10px] text-mc-muted">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {subagent.status === 'running' 
                        ? timeAgo(subagent.startedAt)
                        : formatDuration(subagent.durationMs || 0)
                      }
                    </span>
                    <span>{subagent.model.split('/').pop()}</span>
                  </div>
                  {subagent.costUsd !== undefined && (
                    <span className="text-mc-accent">${subagent.costUsd.toFixed(2)}</span>
                  )}
                </div>

                {/* Result summary for completed/failed */}
                {subagent.resultSummary && (
                  <div className={`mt-2 text-[10px] ${
                    subagent.status === 'failed' ? 'text-red-400' : 'text-green-400'
                  }`}>
                    {subagent.status === 'failed' ? '✕ ' : '✓ '}
                    {subagent.resultSummary}
                  </div>
                )}

                {/* Action buttons for running subagents */}
                {subagent.status === 'running' && (
                  <div className="mt-3 pt-2 border-t border-mc-border/30 flex items-center gap-2">
                    <button
                      onClick={() => handleNudge(subagent)}
                      className="px-2 py-1 text-[10px] rounded bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 flex items-center gap-1"
                      title="Send message to nudge"
                    >
                      <MessageSquare className="w-3 h-3" /> Nudge
                    </button>
                    <button
                      onClick={() => handleSteer(subagent)}
                      className="px-2 py-1 text-[10px] rounded bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 flex items-center gap-1"
                      title="Send corrective instruction"
                    >
                      <Navigation className="w-3 h-3" /> Steer
                    </button>
                    <button
                      onClick={() => handleKill(subagent)}
                      className={`px-2 py-1 text-[10px] rounded flex items-center gap-1 ${
                        killConfirm === subagent.id 
                          ? 'bg-red-600 text-white' 
                          : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                      }`}
                      title="Kill this subagent"
                    >
                      <Trash2 className="w-3 h-3" /> {killConfirm === subagent.id ? 'Confirm?' : 'Kill'}
                    </button>
                    <button
                      onClick={() => handleView(subagent)}
                      className="px-2 py-1 text-[10px] rounded bg-gray-500/20 text-gray-400 hover:bg-gray-500/30 flex items-center gap-1"
                      title="View session history"
                    >
                      <Eye className="w-3 h-3" /> View
                    </button>
                  </div>
                )}
              </div>
            ))}

            {subagents.length === 0 && (
              <div className="text-center py-8 text-mc-muted text-xs">
                No sub-agent activity found.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal for Nudge/Steer/View */}
      {modalType && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={closeModal}>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 w-80 max-h-[80vh] overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold">
                {modalType === 'nudge' && 'Nudge Subagent'}
                {modalType === 'steer' && 'Steer Subagent'}
                {modalType === 'view' && 'Session History'}
              </h3>
              <button onClick={closeModal} className="text-mc-muted hover:text-mc-text">
                <X className="w-4 h-4" />
              </button>
            </div>

            {(modalType === 'nudge' || modalType === 'steer') && (
              <>
                <p className="text-xs text-mc-muted mb-3">
                  {modalType === 'nudge' 
                    ? `Send a message to "${selectedSubagent?.label}"` 
                    : `Send corrective instruction to "${selectedSubagent?.label}"`}
                </p>
                <textarea
                  value={modalMessage}
                  onChange={e => setModalMessage(e.target.value)}
                  placeholder={modalType === 'nudge' ? 'Type a message to nudge...' : 'Send corrective instruction...'}
                  className="w-full h-24 px-3 py-2 text-xs bg-mc-bg border border-mc-border rounded resize-none focus:outline-none focus:border-mc-accent"
                  autoFocus
                />
                <div className="mt-4 flex justify-end gap-2">
                  <button
                    onClick={closeModal}
                    className="px-3 py-1.5 text-xs rounded border border-mc-border hover:bg-mc-bg"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleModalSubmit}
                    disabled={!modalMessage.trim()}
                    className="px-3 py-1.5 text-xs rounded bg-mc-accent text-white hover:bg-mc-accent/80 disabled:opacity-50"
                  >
                    Send
                  </button>
                </div>
              </>
            )}

            {modalType === 'view' && (
              <div className="flex-1 overflow-hidden flex flex-col">
                {historyLoading ? (
                  <div className="text-xs text-mc-muted py-4 text-center">Loading history...</div>
                ) : sessionHistory.length > 0 ? (
                  <div className="flex-1 overflow-y-auto max-h-64 space-y-2 pr-1">
                    {sessionHistory.map((entry: any, idx: number) => (
                      <div key={idx} className="text-[10px] p-2 bg-mc-bg rounded border border-mc-border/30">
                        <div className="text-mc-muted mb-1">{entry.timestamp || new Date().toLocaleString()}</div>
                        <div className="text-mc-text">{entry.message || JSON.stringify(entry)}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-mc-muted py-4 text-center">No history available</div>
                )}
                <div className="mt-4 flex justify-end">
                  <button
                    onClick={closeModal}
                    className="px-3 py-1.5 text-xs rounded border border-mc-border hover:bg-mc-bg"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
