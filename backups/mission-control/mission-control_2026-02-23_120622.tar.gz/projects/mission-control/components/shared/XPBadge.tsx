interface XPBadgeProps {
  level: number;
  levelLabel?: string;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

const LEVEL_COLORS: Record<number, string> = {
  1: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  2: 'bg-green-500/20 text-green-400 border-green-500/30',
  3: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  4: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  5: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  6: 'bg-red-500/20 text-red-400 border-red-500/30',
  7: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  8: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  9: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  10: 'bg-gradient-to-r from-purple-500/30 to-yellow-500/30 text-yellow-300 border-yellow-500/30',
};

const SIZE_CLASSES = {
  sm: 'text-[10px] px-1.5 py-0.5',
  md: 'text-xs px-2 py-1',
  lg: 'text-sm px-3 py-1.5',
};

export default function XPBadge({ level, levelLabel, size = 'sm', showLabel = false }: XPBadgeProps) {
  const colorClass = LEVEL_COLORS[Math.min(level, 10)] || LEVEL_COLORS[1];

  return (
    <div className="flex items-center gap-1">
      <span className={`rounded-full font-semibold border ${colorClass} ${SIZE_CLASSES[size]}`}>
        ⭐ {level}
      </span>
      {showLabel && levelLabel && (
        <span className="text-xs text-mc-muted">{levelLabel}</span>
      )}
    </div>
  );
}
