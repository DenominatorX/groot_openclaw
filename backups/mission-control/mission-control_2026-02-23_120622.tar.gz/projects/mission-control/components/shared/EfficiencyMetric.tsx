interface EfficiencyMetricProps {
  efficiency: number;
  totalTasks?: number;
  completedTasks?: number;
  size?: 'sm' | 'md' | 'lg';
  showDetails?: boolean;
}

const EFFICIENCY_COLORS = {
  high: 'text-green-400',
  medium: 'text-yellow-400',
  low: 'text-red-400',
};

const EFFICIENCY_LABELS = {
  high: 'High',
  medium: 'Medium',
  low: 'Low',
};

export default function EfficiencyMetric({ 
  efficiency, 
  totalTasks, 
  completedTasks, 
  size = 'md',
  showDetails = false 
}: EfficiencyMetricProps) {
  const getEfficiencyLevel = (eff: number): 'high' | 'medium' | 'low' => {
    if (eff >= 80) return 'high';
    if (eff >= 50) return 'medium';
    return 'low';
  };

  const level = getEfficiencyLevel(efficiency);
  const colorClass = EFFICIENCY_COLORS[level];
  const label = EFFICIENCY_LABELS[level];

  const SIZE_CLASSES = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
  };

  const CIRCLE_SIZES = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
  };

  const STROKE_WIDTHS = {
    sm: 3,
    md: 4,
    lg: 5,
  };

  const radius = size === 'sm' ? 12 : size === 'md' ? 16 : 22;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (efficiency / 100) * circumference;

  return (
    <div className="flex items-center gap-2">
      <div className={`relative ${CIRCLE_SIZES[size]}`}>
        <svg className="w-full h-full -rotate-90">
          {/* Background circle */}
          <circle
            cx="50%"
            cy="50%"
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth={STROKE_WIDTHS[size]}
            className="text-mc-bg"
          />
          {/* Progress circle */}
          <circle
            cx="50%"
            cy="50%"
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth={STROKE_WIDTHS[size]}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className={`${colorClass} transition-all duration-500`}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`font-semibold ${SIZE_CLASSES[size]} ${colorClass}`}>
            {efficiency}%
          </span>
        </div>
      </div>
      
      {showDetails && (
        <div className="flex flex-col">
          <span className={`text-xs font-medium ${colorClass}`}>{label} Efficiency</span>
          {totalTasks !== undefined && completedTasks !== undefined && (
            <span className="text-[10px] text-mc-muted">
              {completedTasks}/{totalTasks} tasks
            </span>
          )}
        </div>
      )}
    </div>
  );
}
