'use client';
import { useState, useEffect } from 'react';

type TabType = 'shows' | 'episodes' | 'people' | 'promotion' | 'analytics' | 'bookings' | 'resources' | 'ideas';

interface Show {
  id: string;
  name: string;
  description: string;
  hosts: string[];
  coverArtUrl: string;
  rssFeedUrl: string;
  status: 'active' | 'hiatus' | 'development' | 'archived';
  category: string;
  episodeCount: number;
  launchDate: string | null;
  frequency?: string;
}

interface Episode {
  id: string;
  showId: string;
  episodeNumber: number;
  title: string;
  topic: string;
  description: string;
  status: 'idea' | 'planned' | 'recording' | 'editing' | 'published';
  scheduledDate: string | null;
  publishedDate: string | null;
  durationEstimate: number;
  notes: string;
  guests: string[];
  segments: any[];
}

interface Person {
  id: string;
  name: string;
  role: 'host' | 'guest' | 'specialist' | 'wishlist';
  bio: string;
  photoUrl: string;
  shows?: string[];
  socialLinks?: Record<string, string>;
  expertiseAreas?: string[];
  availability?: string;
  contact?: string;
}

interface Idea {
  id: string;
  title: string;
  description: string;
  category: string;
  source: 'conversation' | 'news' | 'request' | 'brainstorm';
  priority: 'low' | 'medium' | 'high';
  linkedShow?: string;
  stars: number;
  createdAt: string;
}

export default function PodcastHubApp() {
  const [tab, setTab] = useState<TabType>('shows');
  const [shows, setShows] = useState<Show[]>([]);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [aiOutput, setAiOutput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const [showsRes, episodesRes, peopleRes, ideasRes] = await Promise.all([
          fetch('/api/apps/podcast/shows'),
          fetch('/api/apps/podcast/episodes'),
          fetch('/api/apps/podcast/people'),
          fetch('/api/apps/podcast/ideas')
        ]);

        if (showsRes.ok) { const d = await showsRes.json(); setShows(Array.isArray(d) ? d : d.shows || []); }
        if (episodesRes.ok) { const d = await episodesRes.json(); setEpisodes(Array.isArray(d) ? d : d.episodes || []); }
        if (peopleRes.ok) {
          const data = await peopleRes.json();
          setPeople(Array.isArray(data) ? data : data.people || []);
        }
        if (ideasRes.ok) { const d = await ideasRes.json(); setIdeas(Array.isArray(d) ? d : d.ideas || []); }
      } catch (e) {
        setError('Failed to load data');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setSuccess('Copied to clipboard!');
    setTimeout(() => setSuccess(''), 2000);
  };

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      {/* Header */}
      <div className="border-b border-purple-500/20 pb-4 mb-6">
        <h1 className="text-3xl font-bold text-purple-400 mb-2">🎙️ Podcast Hub</h1>
        <p className="text-gray-400">Production & Guest Management</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2 mb-6 pb-4 border-b border-gray-700 overflow-x-auto">
        {[
          { id: 'shows' as TabType, label: '📺 Shows' },
          { id: 'episodes' as TabType, label: '📝 Episodes' },
          { id: 'people' as TabType, label: '👥 People' },
          { id: 'promotion' as TabType, label: '📢 Promotion' },
          { id: 'analytics' as TabType, label: '📊 Analytics' },
          { id: 'bookings' as TabType, label: '📅 Bookings' },
          { id: 'resources' as TabType, label: '📚 Resources' },
          { id: 'ideas' as TabType, label: '💡 Ideas' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 rounded font-medium transition-colors ${
              tab === t.id
                ? 'bg-purple-600 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="space-y-6">
        {error && (
          <div className="bg-red-900/30 border border-red-500 text-red-300 px-4 py-3 rounded">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-900/30 border border-green-500 text-green-300 px-4 py-3 rounded">
            {success}
          </div>
        )}

        {/* Shows Tab */}
        {tab === 'shows' && <ShowsManager shows={shows} setShows={setShows} />}

        {/* Episodes Tab */}
        {tab === 'episodes' && (
          <EpisodesManager
            episodes={episodes}
            setEpisodes={setEpisodes}
            shows={shows}
            setAiOutput={setAiOutput}
            setAiLoading={setAiLoading}
            aiOutput={aiOutput}
            aiLoading={aiLoading}
            copyToClipboard={copyToClipboard}
          />
        )}

        {/* People Tab */}
        {tab === 'people' && (
          <PeopleDirectory
            people={people}
            setPeople={setPeople}
            shows={shows}
            setAiOutput={setAiOutput}
            setAiLoading={setAiLoading}
            aiOutput={aiOutput}
            aiLoading={aiLoading}
            copyToClipboard={copyToClipboard}
          />
        )}

        {/* Promotion Tab */}
        {tab === 'promotion' && (
          <PromotionManager
            episodes={episodes}
            shows={shows}
            setAiOutput={setAiOutput}
            setAiLoading={setAiLoading}
            aiOutput={aiOutput}
            aiLoading={aiLoading}
            copyToClipboard={copyToClipboard}
          />
        )}

        {/* Analytics Tab */}
        {tab === 'analytics' && <AnalyticsSection shows={shows} episodes={episodes} />}

        {/* Bookings Tab */}
        {tab === 'bookings' && (
          <BookingsManager
            people={people}
            shows={shows}
            setAiOutput={setAiOutput}
            setAiLoading={setAiLoading}
            aiOutput={aiOutput}
            aiLoading={aiLoading}
            copyToClipboard={copyToClipboard}
          />
        )}

        {/* Resources Tab */}
        {tab === 'resources' && (
          <ResourcesManager
            setAiOutput={setAiOutput}
            setAiLoading={setAiLoading}
            aiOutput={aiOutput}
            aiLoading={aiLoading}
            copyToClipboard={copyToClipboard}
            shows={shows}
          />
        )}

        {/* Ideas Tab */}
        {tab === 'ideas' && (
          <IdeaBankManager
            ideas={ideas}
            setIdeas={setIdeas}
            shows={shows}
            setAiOutput={setAiOutput}
            setAiLoading={setAiLoading}
            aiOutput={aiOutput}
            aiLoading={aiLoading}
            copyToClipboard={copyToClipboard}
          />
        )}
      </div>
    </div>
  );
}

// ========== SHOWS MANAGER ==========
function ShowsManager({ shows, setShows }: { shows: Show[]; setShows: any }) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    hosts: '',
    status: 'development' as const,
    category: 'general',
    frequency: 'weekly'
  });
  const [submitting, setSubmitting] = useState(false);

  const handleAddShow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    try {
      setSubmitting(true);
      const res = await fetch('/api/apps/podcast/shows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          hosts: formData.hosts.split(',').map(h => h.trim()).filter(Boolean)
        })
      });

      if (res.ok) {
        const newShow = await res.json();
        setShows([...shows, newShow]);
        setFormData({ name: '', description: '', hosts: '', status: 'development', category: 'general', frequency: 'weekly' });
        setShowForm(false);
      }
    } catch (e) {
      console.error('Error adding show:', e);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <button
        onClick={() => setShowForm(!showForm)}
        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded font-medium transition-colors"
      >
        + Add Show
      </button>

      {showForm && (
        <form onSubmit={handleAddShow} className="bg-gray-800 p-4 rounded space-y-3">
          <input
            type="text"
            placeholder="Show name"
            value={formData.name}
            onChange={e => setFormData({ ...formData, name: e.target.value })}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={e => setFormData({ ...formData, description: e.target.value })}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
            rows={3}
          />
          <input
            type="text"
            placeholder="Hosts (comma-separated)"
            value={formData.hosts}
            onChange={e => setFormData({ ...formData, hosts: e.target.value })}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
          />
          <div className="flex gap-2">
            <select
              value={formData.status}
              onChange={e => setFormData({ ...formData, status: e.target.value as any })}
              className="flex-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
            >
              <option>development</option>
              <option>active</option>
              <option>hiatus</option>
              <option>archived</option>
            </select>
            <select
              value={formData.frequency}
              onChange={e => setFormData({ ...formData, frequency: e.target.value })}
              className="flex-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
            >
              <option>weekly</option>
              <option>bi-weekly</option>
              <option>monthly</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 bg-purple-600 hover:bg-purple-700 rounded px-4 py-2 font-medium disabled:opacity-50"
            >
              {submitting ? 'Creating...' : 'Create Show'}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="flex-1 bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 font-medium"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Shows Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {shows.map((show: Show) => (
          <div key={show.id} className="bg-gray-800 border border-gray-700 rounded-lg p-4 hover:border-purple-500/50 transition">
            <div className="flex gap-3 mb-3">
              <img
                src={show.coverArtUrl}
                alt={show.name}
                className="w-16 h-16 rounded object-cover"
              />
              <div className="flex-1">
                <h3 className="font-bold text-lg text-purple-400">{show.name}</h3>
                <p className="text-xs text-gray-400">{show.category}</p>
                <p className={`text-xs font-medium mt-1 px-2 py-0.5 rounded w-fit ${
                  show.status === 'active' ? 'bg-green-900/40 text-green-300' :
                  show.status === 'development' ? 'bg-blue-900/40 text-blue-300' :
                  show.status === 'archived' ? 'bg-gray-700 text-gray-300' :
                  'bg-yellow-900/40 text-yellow-300'
                }`}>
                  {show.status.toUpperCase()}
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-300 mb-3">{show.description}</p>
            <div className="flex flex-wrap gap-2 text-xs text-gray-400">
              <span>📊 {show.episodeCount} episodes</span>
              <span>👥 {show.hosts.length} hosts</span>
              <span>⏱️ {show.frequency}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ========== EPISODES MANAGER ==========
function EpisodesManager({
  episodes,
  setEpisodes,
  shows,
  setAiOutput,
  setAiLoading,
  aiOutput,
  aiLoading,
  copyToClipboard
}: any) {
  const [episodeForm, setEpisodeForm] = useState(false);
  const [selectedShow, setSelectedShow] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    topic: '',
    description: '',
    status: 'idea' as const
  });
  const [submitting, setSubmitting] = useState(false);
  const [aiAction, setAiAction] = useState('');
  const [aiTopic, setAiTopic] = useState('');

  const handleAddEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedShow || !formData.title.trim()) return;

    try {
      setSubmitting(true);
      const res = await fetch('/api/apps/podcast/episodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          showId: selectedShow,
          ...formData
        })
      });

      if (res.ok) {
        const newEpisode = await res.json();
        setEpisodes([...episodes, newEpisode]);
        setFormData({ title: '', topic: '', description: '', status: 'idea' });
        setSelectedShow('');
        setEpisodeForm(false);
      }
    } catch (e) {
      console.error('Error adding episode:', e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAiAction = async (action: string, topic: string) => {
    if (!topic.trim()) return;
    try {
      setAiLoading(true);
      setAiAction(action);
      setAiOutput('');
      const res = await fetch('/api/apps/podcast/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, topic })
      });

      if (res.ok) {
        const data = await res.json();
        setAiOutput(data.result);
      }
    } catch (e) {
      setAiOutput('Error generating content. Please try again.');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Episode Form */}
        <div className="space-y-4">
          <button
            onClick={() => setEpisodeForm(!episodeForm)}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded font-medium transition-colors"
          >
            + Plan Episode
          </button>

          {episodeForm && (
            <form onSubmit={handleAddEpisode} className="bg-gray-800 p-4 rounded space-y-3">
              <select
                value={selectedShow}
                onChange={e => setSelectedShow(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
              >
                <option value="">Select show...</option>
                {shows.map((show: Show) => (
                  <option key={show.id} value={show.id}>{show.name}</option>
                ))}
              </select>
              <input
                type="text"
                placeholder="Episode title"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
              />
              <input
                type="text"
                placeholder="Topic"
                value={formData.topic}
                onChange={e => setFormData({ ...formData, topic: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
              />
              <textarea
                placeholder="Description"
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
                rows={3}
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 rounded px-4 py-2 font-medium disabled:opacity-50"
                >
                  {submitting ? 'Creating...' : 'Create Episode'}
                </button>
                <button
                  type="button"
                  onClick={() => setEpisodeForm(false)}
                  className="flex-1 bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 font-medium"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* AI Tools */}
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-3">
            <h3 className="font-bold text-purple-400">🤖 AI Generation Tools</h3>
            <input
              type="text"
              placeholder="Enter topic or episode info..."
              value={aiTopic}
              onChange={e => setAiTopic(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
            />
            <div className="grid grid-cols-2 gap-2 text-sm">
              <button
                onClick={() => handleAiAction('generate-episode-outline', aiTopic)}
                disabled={aiLoading}
                className="bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50"
              >
                📋 Outline
              </button>
              <button
                onClick={() => handleAiAction('generate-show-notes', aiTopic)}
                disabled={aiLoading}
                className="bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50"
              >
                📝 Show Notes
              </button>
              <button
                onClick={() => handleAiAction('generate-episode-titles', aiTopic)}
                disabled={aiLoading}
                className="bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50"
              >
                ✨ Titles
              </button>
              <button
                onClick={() => handleAiAction('generate-interview-questions', aiTopic)}
                disabled={aiLoading}
                className="bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50"
              >
                ❓ Questions
              </button>
            </div>
          </div>
        </div>

        {/* AI Output */}
        {aiOutput && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-bold text-purple-400">{aiAction.replace(/-/g, ' ')}</h4>
              <button
                onClick={() => copyToClipboard(aiOutput)}
                className="text-sm px-2 py-1 bg-purple-600/30 hover:bg-purple-600/50 rounded"
              >
                📋 Copy
              </button>
            </div>
            <div className="text-sm text-gray-300 whitespace-pre-wrap font-mono text-xs">
              {aiLoading ? 'Generating...' : aiOutput}
            </div>
          </div>
        )}
      </div>

      {/* Episodes List */}
      <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-gray-700 font-bold text-purple-400">
          Planned Episodes
        </div>
        <div className="divide-y divide-gray-700">
          {episodes.slice(0, 10).map((ep: Episode) => (
            <div key={ep.id} className="p-4 hover:bg-gray-700/50 transition">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-white">{ep.title}</h4>
                  <p className="text-sm text-gray-400">{ep.topic}</p>
                  <p className="text-xs text-gray-500 mt-1">{shows.find((s: any) => s.id === ep.showId)?.name}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded ${
                  ep.status === 'published' ? 'bg-green-900/40 text-green-300' :
                  ep.status === 'idea' ? 'bg-gray-700 text-gray-300' :
                  'bg-blue-900/40 text-blue-300'
                }`}>
                  {ep.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ========== PEOPLE DIRECTORY ==========
function PeopleDirectory({
  people,
  setPeople,
  shows,
  setAiOutput,
  setAiLoading,
  aiOutput,
  aiLoading,
  copyToClipboard
}: any) {
  const [personForm, setPersonForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    role: 'host' as const,
    bio: '',
    expertiseAreas: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [aiTopic, setAiTopic] = useState('');

  const handleAddPerson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    try {
      setSubmitting(true);
      const res = await fetch('/api/apps/podcast/people', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          expertiseAreas: formData.expertiseAreas.split(',').map(a => a.trim()).filter(Boolean)
        })
      });

      if (res.ok) {
        const newPerson = await res.json();
        setPeople([...people, newPerson]);
        setFormData({ name: '', role: 'host', bio: '', expertiseAreas: '' });
        setPersonForm(false);
      }
    } catch (e) {
      console.error('Error adding person:', e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSuggestGuests = async () => {
    if (!aiTopic.trim()) return;
    try {
      setAiLoading(true);
      const res = await fetch('/api/apps/podcast/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'suggest-guests', topic: aiTopic })
      });

      if (res.ok) {
        const data = await res.json();
        setAiOutput(data.result);
      }
    } catch (e) {
      setAiOutput('Error generating suggestions.');
    } finally {
      setAiLoading(false);
    }
  };

  const hosts = people.filter((p: Person) => p.role === 'host');
  const guests = people.filter((p: Person) => p.role === 'guest');
  const specialists = people.filter((p: Person) => p.role === 'specialist');

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Add Person Form */}
        <div className="space-y-3">
          <button
            onClick={() => setPersonForm(!personForm)}
            className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded font-medium"
          >
            + Add Person
          </button>

          {personForm && (
            <form onSubmit={handleAddPerson} className="bg-gray-800 p-4 rounded space-y-3">
              <input
                type="text"
                placeholder="Name"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
              />
              <select
                value={formData.role}
                onChange={e => setFormData({ ...formData, role: e.target.value as any })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
              >
                <option>host</option>
                <option>guest</option>
                <option>specialist</option>
                <option>wishlist</option>
              </select>
              <textarea
                placeholder="Bio"
                value={formData.bio}
                onChange={e => setFormData({ ...formData, bio: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
                rows={2}
              />
              <input
                type="text"
                placeholder="Expertise areas (comma-separated)"
                value={formData.expertiseAreas}
                onChange={e => setFormData({ ...formData, expertiseAreas: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 rounded px-4 py-2 font-medium disabled:opacity-50"
                >
                  {submitting ? 'Adding...' : 'Add'}
                </button>
                <button
                  type="button"
                  onClick={() => setPersonForm(false)}
                  className="flex-1 bg-gray-700 hover:bg-gray-600 rounded px-4 py-2"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Guest Suggestion Tool */}
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-3">
            <h4 className="font-bold text-purple-400">🤖 Suggest Guests</h4>
            <input
              type="text"
              placeholder="Enter episode topic..."
              value={aiTopic}
              onChange={e => setAiTopic(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400 text-sm"
            />
            <button
              onClick={handleSuggestGuests}
              disabled={aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50"
            >
              {aiLoading ? 'Generating...' : 'Generate Suggestions'}
            </button>
          </div>
        </div>

        {/* AI Output */}
        {aiOutput && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-bold text-purple-400">Guest Suggestions</h4>
              <button
                onClick={() => copyToClipboard(aiOutput)}
                className="text-sm px-2 py-1 bg-purple-600/30 hover:bg-purple-600/50 rounded"
              >
                📋 Copy
              </button>
            </div>
            <div className="text-sm text-gray-300 whitespace-pre-wrap font-mono text-xs">
              {aiLoading ? 'Generating...' : aiOutput}
            </div>
          </div>
        )}
      </div>

      {/* People Lists */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Hosts */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-gray-700 font-bold text-purple-400">👥 Hosts ({hosts.length})</div>
          <div className="divide-y divide-gray-700">
            {hosts.map((host: Person) => (
              <div key={host.id} className="p-3 hover:bg-gray-700/50">
                <h5 className="font-semibold text-white">{host.name}</h5>
                <p className="text-xs text-gray-400 mt-1">{host.bio}</p>
                {host.shows && host.shows.length > 0 && (
                  <p className="text-xs text-purple-300 mt-2">{host.shows.length} shows</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Guests */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-gray-700 font-bold text-purple-400">🎤 Guests ({guests.length})</div>
          <div className="divide-y divide-gray-700">
            {guests.map((guest: Person) => (
              <div key={guest.id} className="p-3 hover:bg-gray-700/50">
                <h5 className="font-semibold text-white">{guest.name}</h5>
                <p className="text-xs text-gray-400 mt-1">{guest.bio}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Specialists */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-gray-700 font-bold text-purple-400">🔧 Specialists ({specialists.length})</div>
          <div className="divide-y divide-gray-700">
            {specialists.map((spec: Person) => (
              <div key={spec.id} className="p-3 hover:bg-gray-700/50">
                <h5 className="font-semibold text-white">{spec.name}</h5>
                <p className="text-xs text-gray-400 mt-1">{spec.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ========== PROMOTION MANAGER ==========
function PromotionManager({
  episodes,
  shows,
  setAiOutput,
  setAiLoading,
  aiOutput,
  aiLoading,
  copyToClipboard
}: any) {
  const [selectedEpisode, setSelectedEpisode] = useState('');
  const [promotionAction, setPromotionAction] = useState('');

  const handleGeneratePromo = async (action: string) => {
    if (!selectedEpisode) return;
    const episode = episodes.find((e: any) => e.id === selectedEpisode);
    if (!episode) return;

    try {
      setAiLoading(true);
      setPromotionAction(action);
      const res = await fetch('/api/apps/podcast/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          topic: episode.topic,
          episodeDetails: { title: episode.title }
        })
      });

      if (res.ok) {
        const data = await res.json();
        setAiOutput(data.result);
      }
    } catch (e) {
      setAiOutput('Error generating content.');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Controls */}
      <div className="space-y-4">
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-purple-400 mb-2">Select Episode</label>
            <select
              value={selectedEpisode}
              onChange={e => setSelectedEpisode(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
            >
              <option value="">Choose episode...</option>
              {episodes.map((ep: any) => (
                <option key={ep.id} value={ep.id}>
                  {shows.find((s: any) => s.id === ep.showId)?.name} - {ep.title}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <h3 className="font-bold text-purple-400">🤖 Generate Content</h3>
            <button
              onClick={() => handleGeneratePromo('generate-social-posts')}
              disabled={!selectedEpisode || aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              📱 Social Posts
            </button>
            <button
              onClick={() => handleGeneratePromo('generate-episode-description')}
              disabled={!selectedEpisode || aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              📝 Description
            </button>
            <button
              onClick={() => handleGeneratePromo('generate-clip-suggestions')}
              disabled={!selectedEpisode || aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              ✂️ Clip Suggestions
            </button>
            <button
              onClick={() => handleGeneratePromo('generate-newsletter-blurb')}
              disabled={!selectedEpisode || aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              📧 Newsletter
            </button>
            <button
              onClick={() => handleGeneratePromo('generate-blog-post')}
              disabled={!selectedEpisode || aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              📄 Blog Post
            </button>
            <button
              onClick={() => handleGeneratePromo('generate-audiogram-script')}
              disabled={!selectedEpisode || aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              🎬 Audiogram
            </button>
          </div>
        </div>
      </div>

      {/* Output */}
      {aiOutput && (
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto">
          <div className="flex justify-between items-center mb-3">
            <h4 className="font-bold text-purple-400">{promotionAction.replace(/-/g, ' ')}</h4>
            <button
              onClick={() => copyToClipboard(aiOutput)}
              className="text-sm px-2 py-1 bg-purple-600/30 hover:bg-purple-600/50 rounded"
            >
              📋 Copy
            </button>
          </div>
          <div className="text-sm text-gray-300 whitespace-pre-wrap font-mono text-xs">
            {aiLoading ? 'Generating...' : aiOutput}
          </div>
        </div>
      )}
    </div>
  );
}

// ========== ANALYTICS SECTION ==========
function AnalyticsSection({ shows, episodes }: any) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {shows.map((show: any) => {
        const showEpisodes = episodes.filter((e: any) => e.showId === show.id);
        return (
          <div key={show.id} className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <h3 className="font-bold text-purple-400 mb-3">{show.name}</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Episodes:</span>
                <span className="text-white font-semibold">{show.episodeCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Status:</span>
                <span className={`font-semibold ${
                  show.status === 'active' ? 'text-green-400' :
                  show.status === 'development' ? 'text-blue-400' :
                  show.status === 'archived' ? 'text-gray-400' :
                  'text-yellow-400'
                }`}>
                  {show.status.toUpperCase()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Hosts:</span>
                <span className="text-white">{show.hosts.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Planned Episodes:</span>
                <span className="text-white">{showEpisodes.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Launch Date:</span>
                <span className="text-white">{show.launchDate || 'TBD'}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ========== BOOKINGS MANAGER ==========
function BookingsManager({
  people,
  shows,
  setAiOutput,
  setAiLoading,
  aiOutput,
  aiLoading,
  copyToClipboard
}: any) {
  const [selectedGuest, setSelectedGuest] = useState('');
  const [selectedShow, setSelectedShow] = useState('');
  const [topic, setTopic] = useState('');

  const handleGenerateQuestions = async () => {
    if (!topic.trim()) return;
    try {
      setAiLoading(true);
      const res = await fetch('/api/apps/podcast/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate-interview-questions', topic })
      });

      if (res.ok) {
        const data = await res.json();
        setAiOutput(data.result);
      }
    } catch (e) {
      setAiOutput('Error generating questions.');
    } finally {
      setAiLoading(false);
    }
  };

  const guests = people.filter((p: any) => p.role === 'guest' || p.role === 'wishlist');

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Booking Form */}
      <div className="space-y-4">
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-4">
          <h3 className="font-bold text-purple-400">📅 Guest Booking</h3>

          <select
            value={selectedGuest}
            onChange={e => setSelectedGuest(e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
          >
            <option value="">Select guest...</option>
            {guests.map((guest: any) => (
              <option key={guest.id} value={guest.id}>{guest.name}</option>
            ))}
          </select>

          <select
            value={selectedShow}
            onChange={e => setSelectedShow(e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
          >
            <option value="">Select show...</option>
            {shows.map((show: any) => (
              <option key={show.id} value={show.id}>{show.name}</option>
            ))}
          </select>

          <input
            type="text"
            placeholder="Episode topic..."
            value={topic}
            onChange={e => setTopic(e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
          />

          <button
            onClick={handleGenerateQuestions}
            disabled={!topic.trim() || aiLoading}
            className="w-full bg-purple-600 hover:bg-purple-700 rounded px-3 py-2 font-medium disabled:opacity-50"
          >
            {aiLoading ? '⏳ Generating...' : '❓ Generate Questions'}
          </button>
        </div>
      </div>

      {/* Questions Output */}
      {aiOutput && (
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto">
          <div className="flex justify-between items-center mb-3">
            <h4 className="font-bold text-purple-400">Interview Questions</h4>
            <button
              onClick={() => copyToClipboard(aiOutput)}
              className="text-sm px-2 py-1 bg-purple-600/30 hover:bg-purple-600/50 rounded"
            >
              📋 Copy
            </button>
          </div>
          <div className="text-sm text-gray-300 whitespace-pre-wrap font-mono text-xs">
            {aiLoading ? 'Generating...' : aiOutput}
          </div>
        </div>
      )}
    </div>
  );
}

// ========== RESOURCES MANAGER ==========
function ResourcesManager({
  setAiOutput,
  setAiLoading,
  aiOutput,
  aiLoading,
  copyToClipboard,
  shows
}: any) {
  const [selectedShow, setSelectedShow] = useState('');
  const [resourceType, setResourceType] = useState('template');

  const handleGenerateResource = async () => {
    if (resourceType === 'intro-script' && !selectedShow) return;

    let action = '';
    if (resourceType === 'intro-script') action = 'generate-intro-script';
    else if (resourceType === 'sponsorship') action = 'generate-sponsorship-pitch';

    if (!action) return;

    try {
      setAiLoading(true);
      const res = await fetch('/api/apps/podcast/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          topic: selectedShow,
          showData: shows.find((s: any) => s.id === selectedShow)
        })
      });

      if (res.ok) {
        const data = await res.json();
        setAiOutput(data.result);
      }
    } catch (e) {
      setAiOutput('Error generating resource.');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Generator */}
      <div className="space-y-4">
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-4">
          <h3 className="font-bold text-purple-400">🤖 Generate Resources</h3>

          <select
            value={resourceType}
            onChange={e => setResourceType(e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
          >
            <option value="intro-script">Intro Script</option>
            <option value="sponsorship">Sponsorship Pitch</option>
          </select>

          {resourceType === 'intro-script' && (
            <select
              value={selectedShow}
              onChange={e => setSelectedShow(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
            >
              <option value="">Select show...</option>
              {shows.map((show: any) => (
                <option key={show.id} value={show.id}>{show.name}</option>
              ))}
            </select>
          )}

          <button
            onClick={handleGenerateResource}
            disabled={aiLoading || (resourceType === 'intro-script' && !selectedShow)}
            className="w-full bg-purple-600 hover:bg-purple-700 rounded px-3 py-2 font-medium disabled:opacity-50"
          >
            {aiLoading ? '⏳ Generating...' : '✨ Generate'}
          </button>
        </div>
      </div>

      {/* Output */}
      {aiOutput && (
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto">
          <div className="flex justify-between items-center mb-3">
            <h4 className="font-bold text-purple-400">Generated {resourceType}</h4>
            <button
              onClick={() => copyToClipboard(aiOutput)}
              className="text-sm px-2 py-1 bg-purple-600/30 hover:bg-purple-600/50 rounded"
            >
              📋 Copy
            </button>
          </div>
          <div className="text-sm text-gray-300 whitespace-pre-wrap font-mono text-xs">
            {aiLoading ? 'Generating...' : aiOutput}
          </div>
        </div>
      )}
    </div>
  );
}

// ========== IDEA BANK MANAGER ==========
function IdeaBankManager({
  ideas,
  setIdeas,
  shows,
  setAiOutput,
  setAiLoading,
  aiOutput,
  aiLoading,
  copyToClipboard
}: any) {
  const [ideaForm, setIdeaForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'general',
    source: 'brainstorm' as const,
    priority: 'medium' as const,
    linkedShow: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [brainstormTheme, setBrainstormTheme] = useState('');

  const handleAddIdea = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    try {
      setSubmitting(true);
      const res = await fetch('/api/apps/podcast/ideas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (res.ok) {
        const newIdea = await res.json();
        setIdeas([...ideas, newIdea]);
        setFormData({ title: '', description: '', category: 'general', source: 'brainstorm', priority: 'medium', linkedShow: '' });
        setIdeaForm(false);
      }
    } catch (e) {
      console.error('Error adding idea:', e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleBrainstorm = async () => {
    if (!brainstormTheme.trim()) return;
    try {
      setAiLoading(true);
      const res = await fetch('/api/apps/podcast/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'brainstorm-ideas', theme: brainstormTheme })
      });

      if (res.ok) {
        const data = await res.json();
        setAiOutput(data.result);
      }
    } catch (e) {
      setAiOutput('Error generating ideas.');
    } finally {
      setAiLoading(false);
    }
  };

  const topIdeas = ideas.sort((a: Idea, b: Idea) => b.stars - a.stars).slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Idea Form */}
        <div className="space-y-3">
          <button
            onClick={() => setIdeaForm(!ideaForm)}
            className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded font-medium"
          >
            + Add Idea
          </button>

          {ideaForm && (
            <form onSubmit={handleAddIdea} className="bg-gray-800 p-4 rounded space-y-3">
              <input
                type="text"
                placeholder="Idea title"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
              />
              <textarea
                placeholder="Description"
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400"
                rows={2}
              />
              <select
                value={formData.source}
                onChange={e => setFormData({ ...formData, source: e.target.value as any })}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm"
              >
                <option>brainstorm</option>
                <option>conversation</option>
                <option>news</option>
                <option>request</option>
              </select>
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 rounded px-4 py-2 font-medium disabled:opacity-50 text-sm"
                >
                  {submitting ? 'Adding...' : 'Add'}
                </button>
                <button
                  type="button"
                  onClick={() => setIdeaForm(false)}
                  className="flex-1 bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 text-sm"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Brainstorm Tool */}
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-3">
            <h4 className="font-bold text-purple-400">🧠 Brainstorm</h4>
            <input
              type="text"
              placeholder="Enter theme..."
              value={brainstormTheme}
              onChange={e => setBrainstormTheme(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-400 text-sm"
            />
            <button
              onClick={handleBrainstorm}
              disabled={aiLoading}
              className="w-full bg-purple-600/30 hover:bg-purple-600/50 rounded px-3 py-2 disabled:opacity-50 text-sm"
            >
              {aiLoading ? 'Generating...' : 'Generate Ideas'}
            </button>
          </div>
        </div>

        {/* AI Output */}
        {aiOutput && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-bold text-purple-400">Brainstorm Results</h4>
              <button
                onClick={() => copyToClipboard(aiOutput)}
                className="text-sm px-2 py-1 bg-purple-600/30 hover:bg-purple-600/50 rounded"
              >
                📋 Copy
              </button>
            </div>
            <div className="text-sm text-gray-300 whitespace-pre-wrap font-mono text-xs">
              {aiLoading ? 'Generating...' : aiOutput}
            </div>
          </div>
        )}

        {/* Top Ideas */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-gray-700 font-bold text-purple-400">⭐ Top Ideas ({topIdeas.length})</div>
          <div className="divide-y divide-gray-700">
            {topIdeas.map((idea: Idea) => (
              <div key={idea.id} className="p-3 hover:bg-gray-700/50">
                <h5 className="font-semibold text-white text-sm">{idea.title}</h5>
                <p className="text-xs text-gray-400 mt-1">{idea.description}</p>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-purple-300">{idea.source}</span>
                  <span className="text-lg">⭐ {idea.stars}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* All Ideas List */}
      <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-gray-700 font-bold text-purple-400">All Ideas ({ideas.length})</div>
        <div className="divide-y divide-gray-700 max-h-64 overflow-y-auto">
          {ideas.map((idea: Idea) => (
            <div key={idea.id} className="p-3 hover:bg-gray-700/50">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-white">{idea.title}</h5>
                  <p className="text-xs text-gray-400 mt-1">{idea.description}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded ${
                  idea.priority === 'high' ? 'bg-red-900/40 text-red-300' :
                  idea.priority === 'medium' ? 'bg-yellow-900/40 text-yellow-300' :
                  'bg-gray-700 text-gray-300'
                }`}>
                  {idea.priority}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
