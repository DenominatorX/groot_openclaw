'use client';
import { useState } from 'react';

interface Lesson {
  id: string;
  title: string;
  type: 'text' | 'video' | 'quiz' | 'assignment' | 'resource';
  content: string;
  estimatedMinutes?: number;
}

interface Module {
  id: string;
  title: string;
  lessons: Lesson[];
}

interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  targetAudience: string;
  price: number;
  modules: Module[];
  createdAt: string;
  students?: number;
}

interface CourseTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  moduleCount: number;
  lessonsPerModule: number;
}

interface AppState {
  screen: 'dashboard' | 'create' | 'edit' | 'builder' | 'student-tracker' | 'templates' | 'revenue-calc' | 'landing-page';
  courses: Course[];
  currentCourse?: Course;
  selectedTemplate?: CourseTemplate;
  genInputTopic?: string;
  genInputAudience?: string;
  generatedOutline?: Module[];
  isGenerating: boolean;
  studentEnrollment?: { [courseId: string]: number };
}

const TEMPLATES: CourseTemplate[] = [
  { id: 'ai-ml', name: 'AI/ML Basics', description: 'Introduction to artificial intelligence and machine learning', category: 'Technology', moduleCount: 8, lessonsPerModule: 4 },
  { id: 'digital-marketing', name: 'Digital Marketing', description: 'Master digital marketing strategies and tactics', category: 'Business', moduleCount: 10, lessonsPerModule: 5 },
  { id: 'freelancing', name: 'Freelancing 101', description: 'Build a successful freelancing career', category: 'Business', moduleCount: 6, lessonsPerModule: 3 },
  { id: 'personal-finance', name: 'Personal Finance', description: 'Master money management and investing', category: 'Finance', moduleCount: 9, lessonsPerModule: 4 },
  { id: 'coding-bootcamp', name: 'Coding Bootcamp', description: 'Learn full-stack web development', category: 'Technology', moduleCount: 12, lessonsPerModule: 6 },
];

const generateCourseOutline = (topic: string, audience: string): Module[] => {
  // Simulated AI generation
  return [
    {
      id: '1',
      title: `${topic} Fundamentals`,
      lessons: [
        { id: '1-1', title: 'Introduction to ' + topic, type: 'text', content: 'Core concepts and overview...', estimatedMinutes: 15 },
        { id: '1-2', title: 'Key Principles', type: 'text', content: 'Essential principles for success...', estimatedMinutes: 20 },
        { id: '1-3', title: 'Common Misconceptions', type: 'text', content: 'Debunking myths about ' + topic + '...', estimatedMinutes: 10 },
      ],
    },
    {
      id: '2',
      title: `Getting Started with ${topic}`,
      lessons: [
        { id: '2-1', title: 'Setup and Prerequisites', type: 'text', content: 'What you need to begin...', estimatedMinutes: 20 },
        { id: '2-2', title: 'Your First Steps', type: 'text', content: 'Hands-on tutorial for beginners...', estimatedMinutes: 30 },
        { id: '2-3', title: 'Quick Quiz', type: 'quiz', content: 'Test your understanding', estimatedMinutes: 15 },
      ],
    },
    {
      id: '3',
      title: `Advanced ${topic} Techniques`,
      lessons: [
        { id: '3-1', title: 'Advanced Strategies', type: 'text', content: 'Level up your ' + topic + ' skills...', estimatedMinutes: 25 },
        { id: '3-2', title: 'Case Study Analysis', type: 'text', content: 'Real-world examples and analysis...', estimatedMinutes: 20 },
        { id: '3-3', title: 'Assignment', type: 'assignment', content: 'Apply your knowledge to a real project...', estimatedMinutes: 60 },
      ],
    },
  ];
};

export default function CourseBuilderApp() {
  const [app, setApp] = useState<AppState>({
    screen: 'dashboard',
    courses: [],
    isGenerating: false,
    studentEnrollment: {},
  });

  const createNewCourse = () => {
    setApp(prev => ({
      ...prev,
      screen: 'create',
      selectedTemplate: undefined,
    }));
  };

  const selectTemplate = (template: CourseTemplate) => {
    const newCourse: Course = {
      id: `course-${Date.now()}`,
      title: `New ${template.name} Course`,
      description: template.description,
      category: template.category,
      difficulty: 'beginner',
      targetAudience: 'Everyone',
      price: 29.99,
      modules: Array(template.moduleCount).fill(0).map((_, i) => ({
        id: `m-${i}`,
        title: `Module ${i + 1}`,
        lessons: Array(template.lessonsPerModule).fill(0).map((_, j) => ({
          id: `l-${i}-${j}`,
          title: `Lesson ${j + 1}`,
          type: 'text' as const,
          content: 'Add lesson content...',
        })),
      })),
      createdAt: new Date().toLocaleDateString(),
    };
    setApp(prev => ({
      ...prev,
      screen: 'builder',
      currentCourse: newCourse,
      courses: [...prev.courses, newCourse],
    }));
  };

  const generateCourseOutlineAI = () => {
    if (!app.genInputTopic || !app.genInputAudience) return;
    
    setApp(prev => ({ ...prev, isGenerating: true }));
    
    // Simulate API delay
    setTimeout(() => {
      const outline = generateCourseOutline(app.genInputTopic || '', app.genInputAudience || '');
      setApp(prev => ({
        ...prev,
        isGenerating: false,
        generatedOutline: outline,
        currentCourse: prev.currentCourse ? {
          ...prev.currentCourse,
          modules: outline,
        } : undefined,
      }));
    }, 1500);
  };

  const handleCourseUpdate = (updates: Partial<Course>) => {
    if (!app.currentCourse) return;
    const updated = { ...app.currentCourse, ...updates };
    setApp(prev => ({
      ...prev,
      currentCourse: updated,
      courses: prev.courses.map(c => c.id === updated.id ? updated : c),
    }));
  };

  const deleteCourse = (id: string) => {
    setApp(prev => ({
      ...prev,
      courses: prev.courses.filter(c => c.id !== id),
      currentCourse: prev.currentCourse?.id === id ? undefined : prev.currentCourse,
    }));
  };

  // === DASHBOARD ===
  if (app.screen === 'dashboard') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-1">🎓 Course Builder</h2>
            <p className="text-sm text-mc-muted">Create, manage, and monetize your online courses</p>
          </div>
          <button
            onClick={createNewCourse}
            className="px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium transition"
          >
            ➕ New Course
          </button>
        </div>

        {app.courses.length === 0 ? (
          <div className="bg-mc-surface border-2 border-dashed border-mc-border rounded-lg p-12 text-center">
            <div className="text-4xl mb-3">📚</div>
            <h3 className="text-lg font-bold mb-2">No courses yet</h3>
            <p className="text-sm text-mc-muted mb-4">Start by creating a new course or using a template</p>
            <button
              onClick={createNewCourse}
              className="px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium transition"
            >
              Create Your First Course
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {app.courses.map(course => (
              <div key={course.id} className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-bold text-base">{course.title}</h3>
                    <p className="text-xs text-mc-muted">{course.category}</p>
                  </div>
                  <span className="text-xs bg-mc-accent/20 text-mc-accent px-2 py-1 rounded">{course.difficulty}</span>
                </div>
                <p className="text-sm text-mc-muted mb-4 line-clamp-2">{course.description}</p>
                <div className="text-xs text-mc-muted mb-4">
                  {course.modules.length} modules • {course.modules.reduce((sum, m) => sum + m.lessons.length, 0)} lessons
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setApp(prev => ({ ...prev, screen: 'builder', currentCourse: course }))}
                    className="flex-1 px-2 py-1.5 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded text-sm transition"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => deleteCourse(course.id)}
                    className="flex-1 px-2 py-1.5 bg-red-900/20 text-red-400 hover:bg-red-900/30 rounded text-sm transition"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
          <button
            onClick={() => setApp(prev => ({ ...prev, screen: 'templates' }))}
            className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition text-left"
          >
            <div className="text-2xl mb-2">📋</div>
            <div className="font-bold mb-1">Course Templates</div>
            <p className="text-sm text-mc-muted">Start from pre-built course structures</p>
          </button>
          <button
            onClick={() => setApp(prev => ({ ...prev, screen: 'revenue-calc' }))}
            className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition text-left"
          >
            <div className="text-2xl mb-2">💰</div>
            <div className="font-bold mb-1">Revenue Calculator</div>
            <p className="text-sm text-mc-muted">Project earnings from your courses</p>
          </button>
        </div>
      </div>
    );
  }

  // === TEMPLATES ===
  if (app.screen === 'templates') {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setApp(prev => ({ ...prev, screen: 'dashboard' }))}
          className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
        >
          ← Back to Dashboard
        </button>

        <div>
          <h2 className="text-xl font-bold mb-4">📋 Course Templates</h2>
          <p className="text-sm text-mc-muted mb-6">Choose a template to jumpstart your course creation</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {TEMPLATES.map(template => (
              <div key={template.id} className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition">
                <h3 className="font-bold text-base mb-2">{template.name}</h3>
                <p className="text-sm text-mc-muted mb-3">{template.description}</p>
                <div className="text-xs text-mc-muted mb-4">
                  {template.moduleCount} modules • {template.lessonsPerModule} lessons each
                </div>
                <button
                  onClick={() => selectTemplate(template)}
                  className="w-full px-3 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium text-sm transition"
                >
                  Use Template
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // === CREATE COURSE WITH AI ===
  if (app.screen === 'create') {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setApp(prev => ({ ...prev, screen: 'dashboard' }))}
          className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
        >
          ← Back to Dashboard
        </button>

        <div className="bg-mc-surface border border-mc-border rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">🤖 Generate Course Outline</h2>
          <p className="text-sm text-mc-muted mb-6">Let AI create a full course structure for you</p>

          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-sm font-medium mb-2">Topic</label>
              <input
                type="text"
                placeholder="e.g., Machine Learning for Beginners"
                value={app.genInputTopic || ''}
                onChange={(e) => setApp(prev => ({ ...prev, genInputTopic: e.target.value }))}
                className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text placeholder-mc-muted focus:outline-none focus:border-mc-accent transition"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Target Audience</label>
              <input
                type="text"
                placeholder="e.g., Developers new to AI, Business professionals"
                value={app.genInputAudience || ''}
                onChange={(e) => setApp(prev => ({ ...prev, genInputAudience: e.target.value }))}
                className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text placeholder-mc-muted focus:outline-none focus:border-mc-accent transition"
              />
            </div>
          </div>

          <button
            onClick={generateCourseOutlineAI}
            disabled={app.isGenerating || !app.genInputTopic || !app.genInputAudience}
            className="w-full px-4 py-3 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 disabled:cursor-not-allowed rounded font-medium transition"
          >
            {app.isGenerating ? '⏳ Generating...' : '✨ Generate Outline'}
          </button>

          {app.generatedOutline && (
            <div className="mt-6 pt-6 border-t border-mc-border">
              <h3 className="font-bold mb-4">Preview Generated Course</h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {(app.generatedOutline || []).map(module => (
                  <div key={module.id} className="bg-mc-bg border border-mc-border/50 rounded p-3">
                    <div className="font-medium text-sm mb-2">{module.title}</div>
                    <div className="text-xs text-mc-muted space-y-1">
                      {module.lessons.map(lesson => (
                        <div key={lesson.id}>• {lesson.title} ({lesson.type})</div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  const newCourse: Course = {
                    id: `course-${Date.now()}`,
                    title: app.genInputTopic || 'New Course',
                    description: `Course about ${app.genInputTopic} for ${app.genInputAudience}`,
                    category: 'Technology',
                    difficulty: 'beginner',
                    targetAudience: app.genInputAudience || 'Everyone',
                    price: 49.99,
                    modules: app.generatedOutline || [],
                    createdAt: new Date().toLocaleDateString(),
                  };
                  setApp(prev => ({
                    ...prev,
                    screen: 'builder',
                    courses: [...prev.courses, newCourse],
                    currentCourse: newCourse,
                  }));
                }}
                className="w-full mt-4 px-4 py-2 bg-green-600/20 text-green-400 hover:bg-green-600/30 rounded font-medium transition"
              >
                ✅ Use This Course
              </button>
            </div>
          )}

          <div className="mt-8 pt-6 border-t border-mc-border">
            <h3 className="font-bold mb-4">Or start from a template</h3>
            <button
              onClick={() => setApp(prev => ({ ...prev, screen: 'templates' }))}
              className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium transition"
            >
              View Templates
            </button>
          </div>
        </div>
      </div>
    );
  }

  // === COURSE BUILDER ===
  if (app.screen === 'builder' && app.currentCourse) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setApp(prev => ({ ...prev, screen: 'dashboard', currentCourse: undefined }))}
          className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
        >
          ← Back to Dashboard
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-6 mb-6">
              <h2 className="text-2xl font-bold mb-4">Edit Course</h2>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium mb-1">Course Title</label>
                  <input
                    type="text"
                    value={app.currentCourse.title}
                    onChange={(e) => handleCourseUpdate({ title: e.target.value })}
                    className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent transition"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <textarea
                    value={app.currentCourse.description}
                    onChange={(e) => handleCourseUpdate({ description: e.target.value })}
                    rows={3}
                    className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent transition"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Price ($)</label>
                    <input
                      type="number"
                      value={app.currentCourse.price}
                      onChange={(e) => handleCourseUpdate({ price: parseFloat(e.target.value) })}
                      className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent transition"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Difficulty</label>
                    <select
                      value={app.currentCourse.difficulty}
                      onChange={(e) => handleCourseUpdate({ difficulty: e.target.value as any })}
                      className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent transition"
                    >
                      <option value="beginner">Beginner</option>
                      <option value="intermediate">Intermediate</option>
                      <option value="advanced">Advanced</option>
                    </select>
                  </div>
                </div>
              </div>

              <h3 className="font-bold mb-3">📚 Modules & Lessons</h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {app.currentCourse.modules.map((module, idx) => (
                  <div key={module.id} className="bg-mc-bg border border-mc-border/50 rounded p-3">
                    <div className="font-medium text-sm mb-2">
                      <input
                        type="text"
                        value={module.title}
                        onChange={(e) => {
                          const updated = { ...app.currentCourse };
                          if (updated.modules) {
                            updated.modules[idx].title = e.target.value;
                            handleCourseUpdate({ modules: updated.modules });
                          }
                        }}
                        className="w-full bg-transparent text-sm font-medium focus:outline-none"
                      />
                    </div>
                    <div className="text-xs text-mc-muted space-y-1">
                      {module.lessons.map(lesson => (
                        <div key={lesson.id} className="flex items-center gap-2">
                          <span>•</span>
                          <span className="flex-1">{lesson.title}</span>
                          <span className="text-xs bg-mc-accent/20 px-1.5 py-0.5 rounded">{lesson.type}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-green-600/10 border border-green-600/30 rounded-lg p-4 sticky top-4">
              <h3 className="font-bold mb-4">Course Preview</h3>
              <div className="space-y-2 text-sm">
                <div>
                  <div className="text-xs text-mc-muted">Title</div>
                  <div className="font-medium">{app.currentCourse.title}</div>
                </div>
                <div>
                  <div className="text-xs text-mc-muted">Price</div>
                  <div className="font-bold text-green-400">${app.currentCourse.price}</div>
                </div>
                <div>
                  <div className="text-xs text-mc-muted">Content</div>
                  <div>{app.currentCourse.modules.length} modules</div>
                  <div>{app.currentCourse.modules.reduce((sum, m) => sum + m.lessons.length, 0)} lessons</div>
                </div>
                <div className="pt-3 border-t border-green-600/20">
                  <button
                    onClick={() => setApp(prev => ({ ...prev, screen: 'landing-page', currentCourse: app.currentCourse }))}
                    className="w-full px-3 py-2 bg-green-600/20 text-green-400 hover:bg-green-600/30 rounded font-medium text-sm transition"
                  >
                    Generate Landing Page
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // === REVENUE CALCULATOR ===
  if (app.screen === 'revenue-calc') {
    const [price, setPrice] = useState(49.99);
    const [students, setStudents] = useState(50);

    const revenue = price * students;
    const commissionShare = revenue * 0.1; // 10% commission if using revenue share model
    const saasFee = 19.99;

    return (
      <div className="space-y-6">
        <button
          onClick={() => setApp(prev => ({ ...prev, screen: 'dashboard' }))}
          className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
        >
          ← Back to Dashboard
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-mc-surface border border-mc-border rounded-lg p-6">
            <h2 className="text-xl font-bold mb-6">💰 Revenue Calculator</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Course Price ($)</label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(parseFloat(e.target.value))}
                  step="0.01"
                  className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent transition"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Expected Students</label>
                <input
                  type="number"
                  value={students}
                  onChange={(e) => setStudents(parseInt(e.target.value))}
                  className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent transition"
                />
                <input
                  type="range"
                  min="0"
                  max="1000"
                  value={students}
                  onChange={(e) => setStudents(parseInt(e.target.value))}
                  className="w-full mt-2"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-blue-600/10 border border-blue-600/30 rounded-lg p-4">
              <h3 className="font-bold mb-3">Standalone Model</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-mc-muted">Gross Revenue</span>
                  <span className="font-bold">${revenue.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs text-mc-muted">
                  <span>{students} students × ${price}</span>
                </div>
              </div>
            </div>

            <div className="bg-green-600/10 border border-green-600/30 rounded-lg p-4">
              <h3 className="font-bold mb-3">Platform Model (10% Commission)</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-mc-muted">Your Share</span>
                  <span className="font-bold text-green-400">${(revenue - commissionShare).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs text-mc-muted">
                  <span>After 10% commission</span>
                </div>
              </div>
            </div>

            <div className="bg-purple-600/10 border border-purple-600/30 rounded-lg p-4">
              <h3 className="font-bold mb-3">SaaS Model ($19.99/month)</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-mc-muted">Monthly Cost</span>
                  <span className="font-bold">${saasFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-mc-muted">Your Revenue (All)</span>
                  <span className="font-bold text-purple-400">${revenue.toFixed(2)}</span>
                </div>
                <div className="border-t border-purple-600/20 pt-2 mt-2 flex justify-between">
                  <span className="text-mc-muted">Net After Fees</span>
                  <span className="font-bold text-purple-400">${Math.max(0, revenue - saasFee).toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // === LANDING PAGE GENERATOR ===
  if (app.screen === 'landing-page' && app.currentCourse) {
    const course = app.currentCourse;
    return (
      <div className="space-y-6">
        <button
          onClick={() => setApp(prev => ({ ...prev, screen: 'builder' }))}
          className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
        >
          ← Back to Course
        </button>

        <div className="bg-mc-surface border border-mc-border rounded-lg p-8">
          <h2 className="text-3xl font-bold mb-2">{course.title}</h2>
          <p className="text-lg text-mc-muted mb-6">{course.description}</p>

          <div className="bg-blue-600/10 border-2 border-blue-600/30 rounded-lg p-6 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-mc-muted">Investment</div>
                <div className="text-4xl font-bold text-blue-400">${course.price}</div>
              </div>
              <button className="px-6 py-3 bg-blue-600/50 text-blue-200 hover:bg-blue-600 rounded font-bold transition text-lg">
                Enroll Now
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="border border-mc-border rounded-lg p-4">
              <div className="text-2xl mb-2">⏱️</div>
              <div className="font-bold mb-1">Self-Paced</div>
              <p className="text-sm text-mc-muted">Learn at your own speed</p>
            </div>
            <div className="border border-mc-border rounded-lg p-4">
              <div className="text-2xl mb-2">🎓</div>
              <div className="font-bold mb-1">Certificate</div>
              <p className="text-sm text-mc-muted">Completion certificate included</p>
            </div>
            <div className="border border-mc-border rounded-lg p-4">
              <div className="text-2xl mb-2">💬</div>
              <div className="font-bold mb-1">Support</div>
              <p className="text-sm text-mc-muted">Lifetime access & community</p>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-bold mb-4">📚 Curriculum</h3>
            <div className="space-y-3">
              {course.modules.map((module, idx) => (
                <details key={module.id} className="border border-mc-border rounded-lg p-4 cursor-pointer group">
                  <summary className="font-bold flex justify-between items-center">
                    <span>Module {idx + 1}: {module.title}</span>
                    <span className="group-open:rotate-180 transition">▼</span>
                  </summary>
                  <div className="mt-3 space-y-2 text-sm text-mc-muted">
                    {module.lessons.map(lesson => (
                      <div key={lesson.id} className="flex items-center gap-2">
                        <span>✓</span>
                        <span>{lesson.title}</span>
                      </div>
                    ))}
                  </div>
                </details>
              ))}
            </div>
          </div>

          <div className="bg-green-600/10 border border-green-600/30 rounded-lg p-6 text-center">
            <p className="text-mc-muted mb-4">"This course changed my perspective. Highly recommend!" — Happy Student</p>
            <button className="px-6 py-2 bg-green-600/50 text-green-200 hover:bg-green-600 rounded font-bold transition">
              ✅ Enroll Today
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
