'use client';
import { useState, useEffect, useMemo } from 'react';

interface HistoryItem {
  id: string;
  rawPrompt: string;
  enhancedPrompt: string;
  targetModel: string;
  timestamp: string;
  tags: string[];
}

interface ContextModule {
  id: string;
  name: string;
  content: string;
  active: boolean;
  priority: number;
}

interface Template {
  id: string;
  name: string;
  category: string;
  description: string;
  fields: string[];
  template: string;
}

interface DetectionResult {
  score: number;
  indicators: string[];
  breakdown: string;
}

interface DriftIssue {
  type: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  suggestion: string;
}

interface DriftResult {
  driftScore: number;
  issues: DriftIssue[];
  timestamp: string;
}

interface VoiceProfile {
  tone: string;
  sentenceLength: string;
  vocabularyLevel: string;
  humorStyle: string;
  commonPhrases: string[];
  punctuationHabits: string;
  paragraphStructure: string;
  emotionalRegister: string;
}

const TARGET_MODELS = ['ChatGPT', 'Claude', 'Gemini', 'Grok', 'Midjourney', 'DALL-E', 'Perplexity'];
const PLATFORM_FORMATS = {
  ChatGPT: 'Custom instructions format',
  Claude: 'XML tags with system/user structure',
  Gemini: 'Concise, structured format',
  Grok: 'Direct, less formal approach',
  Midjourney: 'Visual descriptors and style parameters',
  'DALL-E': 'Natural language image descriptions',
  Perplexity: 'Research-focused with source requests',
  Generic: 'Standard prompt format',
};

const TEMPLATE_CATEGORIES = {
  Business: ['PRD', 'Business Plan', 'Pitch Deck', 'Strategy Brief'],
  Technical: ['Code Review', 'Architecture Doc', 'Bug Report', 'API Spec'],
  Creative: ['Blog Post', 'Social Media', 'Script', 'Podcast Outline'],
  Legal: ['Contract Review', 'Compliance Memo', 'IP Assessment', 'NDA Review'],
  Health: ['Symptom Report', 'Supplement Research', 'Doctor Prep', 'Genetic Analysis'],
  Personal: ['Resume', 'Cover Letter', 'Email Draft', 'Decision Framework'],
};

const GUARDRAIL_OPTIONS = {
  noMoralizing: 'No moralizing/disclaimers',
  noFluff: 'No fluff/filler words',
  noOverEnthusiasm: 'No over-enthusiasm ("Great question!")',
  strictFormattingOnly: 'Strict formatting only',
  tablesPreferred: 'Tables preferred over paragraphs',
  codeInCopyBoxes: 'Code in copy-boxes',
  concise: 'Concise (1-2 sentences when possible)',
  noUnsolicited: 'No unsolicited expansions',
  directDisagreement: 'Direct/honest disagreement encouraged',
};

export default function PrePromptApp() {
  const [activeSection, setActiveSection] = useState<'builder' | 'guardrails' | 'voice' | 'drift' | 'analytics' | 'teleprompter' | 'modules' | 'detector' | 'templates' | 'history' | 'settings'>('builder');
  const [rawPrompt, setRawPrompt] = useState('');
  const [enhancedPrompt, setEnhancedPrompt] = useState('');
  const [targetModel, setTargetModel] = useState('Claude');
  const [selectedFormat, setSelectedFormat] = useState('Generic');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [modules, setModules] = useState<ContextModule[]>([]);
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);
  const [detectingText, setDetectingText] = useState('');
  const [detecting, setDetecting] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [templateFields, setTemplateFields] = useState<Record<string, string>>({});
  const [newModule, setNewModule] = useState({ name: '', content: '', priority: 5 });
  const [showNewModule, setShowNewModule] = useState(false);
  
  // Guardrails
  const [guardrails, setGuardrails] = useState<Record<string, boolean>>({});
  const [customGuardrail, setCustomGuardrail] = useState('');

  // Voice Profile
  const [voiceProfile, setVoiceProfile] = useState<VoiceProfile | null>(null);
  const [voiceSamples, setVoiceSamples] = useState<string[]>(['']);
  const [analyzingVoice, setAnalyzingVoice] = useState(false);
  const [applyVoiceProfile, setApplyVoiceProfile] = useState(false);

  // Drift Detection
  const [driftText, setDriftText] = useState('');
  const [driftContext, setDriftContext] = useState('');
  const [driftResult, setDriftResult] = useState<DriftResult | null>(null);
  const [analyzingDrift, setAnalyzingDrift] = useState(false);
  const [driftHistory, setDriftHistory] = useState<DriftResult[]>([]);

  // Teleprompter
  const [teleprompterText, setTeleprompterText] = useState('');
  const [teleprompterSpeed, setTeleprompterSpeed] = useState(5);
  const [teleprompterFontSize, setTeleprompterFontSize] = useState(32);
  const [teleprompterPlaying, setTeleprompterPlaying] = useState(false);
  const [teleprompterMirror, setTeleprompterMirror] = useState(false);

  // Load data on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const [modulesRes, templatesRes, historyRes, guardrailsRes, profileRes, driftRes] = await Promise.all([
          fetch('/api/apps/preprompt/modules'),
          fetch('/api/apps/preprompt/templates'),
          fetch('/api/apps/preprompt/history'),
          fetch('/api/apps/preprompt/guardrails'),
          fetch('/api/apps/preprompt/voice-profile'),
          fetch('/api/apps/preprompt/drift'),
        ]);

        if (modulesRes.ok) setModules(await modulesRes.json());
        if (templatesRes.ok) setTemplates(await templatesRes.json());
        if (historyRes.ok) setHistory(await historyRes.json());
        if (guardrailsRes.ok) {
          const data = await guardrailsRes.json();
          setGuardrails(data.rules || {});
          setCustomGuardrail(data.custom || '');
        }
        if (profileRes.ok) {
          const profile = await profileRes.json();
          if (profile) setVoiceProfile(profile);
        }
        if (driftRes.ok) {
          const history = await driftRes.json();
          setDriftHistory(history || []);
        }
      } catch (e) {
        console.error('Failed to load data:', e);
      }
    };

    loadData();
  }, []);

  // Save guardrails
  const saveGuardrails = async (newGuardrails: Record<string, boolean>, custom: string) => {
    try {
      await fetch('/api/apps/preprompt/guardrails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rules: newGuardrails, custom }),
      });
    } catch (e) {
      console.error('Failed to save guardrails:', e);
    }
  };

  // A. Prompt Builder & Optimizer
  const handleEnhance = async () => {
    if (!rawPrompt.trim()) {
      setError('Please enter a prompt to enhance');
      return;
    }

    setLoading(true);
    setError('');
    try {
      let enhanced = rawPrompt;

      // Apply voice profile if enabled
      if (applyVoiceProfile && voiceProfile) {
        const voiceContext = `Apply this voice profile: tone=${voiceProfile.tone}, sentence_length=${voiceProfile.sentenceLength}, vocabulary=${voiceProfile.vocabularyLevel}, humor=${voiceProfile.humorStyle}. `;
        enhanced = voiceContext + enhanced;
      }

      // Apply active guardrails
      const activeRules = Object.entries(guardrails)
        .filter(([_, enabled]) => enabled)
        .map(([name]) => name);

      const guardrailContext =
        activeRules.length > 0
          ? `Follow these rules: ${activeRules.join(', ')}. ${customGuardrail}`
          : customGuardrail;

      if (guardrailContext.trim()) {
        enhanced = guardrailContext + '\n\n' + enhanced;
      }

      const res = await fetch('/api/apps/preprompt/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawPrompt: enhanced, targetModel }),
      });

      if (!res.ok) throw new Error('Enhancement failed');
      let result = await res.json();
      let enhanced_text = result.enhanced;

      // Apply format
      if (selectedFormat !== 'Generic') {
        enhanced_text = await applyFormat(enhanced_text, selectedFormat);
      }

      setEnhancedPrompt(enhanced_text);

      // Save to history
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        rawPrompt,
        enhancedPrompt: enhanced_text,
        targetModel,
        timestamp: new Date().toISOString(),
        tags: [],
      };

      await fetch('/api/apps/preprompt/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(historyItem),
      });

      setHistory(prev => [historyItem, ...prev]);
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  };

  const applyFormat = async (text: string, format: string): Promise<string> => {
    const formats: Record<string, (t: string) => string> = {
      ChatGPT: t => `# Custom Instructions\n\n${t}`,
      Claude: t => `<system>${t}</system>`,
      Gemini: t => `**Task:**\n${t}`,
      Grok: t => `Direct: ${t}`,
      Midjourney: t => {
        // Strip to visual descriptors
        const lines = t.split('\n').filter(l => !l.match(/^(role|format|constraint)/i));
        return lines.join(', ');
      },
      'DALL-E': t => `Generate an image: ${t}`,
      Perplexity: t => `Research question:\n${t}\n\nProvide sources.`,
    };

    return formats[format]?.(text) || text;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  // B. Context Modules Manager
  const activeModules = useMemo(() => {
    return modules.filter(m => m.active).sort((a, b) => b.priority - a.priority);
  }, [modules]);

  const combinedContext = useMemo(() => {
    return activeModules.map(m => `## ${m.name}\n\n${m.content}`).join('\n\n---\n\n');
  }, [activeModules]);

  const handleToggleModule = async (id: string) => {
    const updated = modules.map(m => (m.id === id ? { ...m, active: !m.active } : m));
    setModules(updated);

    await fetch('/api/apps/preprompt/modules', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    });
  };

  const handleAddModule = async () => {
    if (!newModule.name.trim() || !newModule.content.trim()) return;

    const module: ContextModule = {
      id: Date.now().toString(),
      name: newModule.name,
      content: newModule.content,
      active: true,
      priority: newModule.priority,
    };

    const updated = [...modules, module];
    setModules(updated);
    setShowNewModule(false);
    setNewModule({ name: '', content: '', priority: 5 });

    await fetch('/api/apps/preprompt/modules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(module),
    });
  };

  // C. AI Content Detector
  const handleDetect = async () => {
    if (!detectingText.trim()) {
      setError('Please enter text to analyze');
      return;
    }

    setDetecting(true);
    setError('');
    try {
      const res = await fetch('/api/apps/preprompt/detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: detectingText }),
      });

      if (!res.ok) throw new Error('Detection failed');
      const result = await res.json();
      setDetectionResult(result);
    } catch (e) {
      setError(String(e));
    } finally {
      setDetecting(false);
    }
  };

  // D. Prompt Templates Library
  const handleUseTemplate = () => {
    if (!selectedTemplate) return;
    let filled = selectedTemplate.template;
    for (const [key, value] of Object.entries(templateFields)) {
      filled = filled.replace(`{{${key}}}`, value);
    }
    setRawPrompt(filled);
    setSelectedTemplate(null);
    setActiveSection('builder');
  };

  // E. History & Version Control
  const handleReuseFromHistory = (item: HistoryItem) => {
    setRawPrompt(item.rawPrompt);
    setEnhancedPrompt(item.enhancedPrompt);
    setTargetModel(item.targetModel);
    setActiveSection('builder');
  };

  // Voice Profile
  const handleAnalyzeVoice = async () => {
    const samples = voiceSamples.filter(s => s.trim());
    if (samples.length === 0) {
      setError('Please add at least one writing sample');
      return;
    }

    setAnalyzingVoice(true);
    setError('');
    try {
      const res = await fetch('/api/apps/preprompt/voice-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ samples }),
      });

      if (!res.ok) throw new Error('Analysis failed');
      const profile = await res.json();
      setVoiceProfile(profile);
    } catch (e) {
      setError(String(e));
    } finally {
      setAnalyzingVoice(false);
    }
  };

  // Drift Detection
  const handleCheckDrift = async () => {
    if (!driftText.trim()) {
      setError('Please enter text to analyze');
      return;
    }

    if (!voiceProfile) {
      setError('Please analyze your voice profile first');
      return;
    }

    setAnalyzingDrift(true);
    setError('');
    try {
      const res = await fetch('/api/apps/preprompt/drift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: driftText, context: driftContext || undefined }),
      });

      if (!res.ok) throw new Error('Detection failed');
      const result = await res.json();
      setDriftResult(result);
      setDriftHistory(prev => [result, ...prev]);
    } catch (e) {
      setError(String(e));
    } finally {
      setAnalyzingDrift(false);
    }
  };

  // Analytics
  const analyticsData = useMemo(() => {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const thisWeek = history.filter(h => new Date(h.timestamp) > weekAgo).length;
    const thisMonth = history.filter(h => new Date(h.timestamp) > monthAgo).length;

    const modelCounts: Record<string, number> = {};
    history.forEach(h => {
      modelCounts[h.targetModel] = (modelCounts[h.targetModel] || 0) + 1;
    });

    const tagCounts: Record<string, number> = {};
    history.forEach(h => {
      h.tags?.forEach(tag => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
    });

    return {
      totalPrompts: history.length,
      thisWeek,
      thisMonth,
      modelCounts,
      tagCounts,
    };
  }, [history]);

  // Export/Import
  const handleExport = async () => {
    try {
      const res = await fetch('/api/apps/preprompt/export');
      if (!res.ok) throw new Error('Export failed');
      const data = await res.json();

      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `preprompt-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(String(e));
    }
  };

  const handleImport = async (file: File) => {
    try {
      const json = await file.text();
      const data = JSON.parse(json);

      const res = await fetch('/api/apps/preprompt/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data }),
      });

      if (!res.ok) throw new Error('Import failed');
      const result = await res.json();

      // Reload data
      window.location.reload();
    } catch (e) {
      setError(String(e));
    }
  };

  // Tabs
  const tabs = [
    { id: 'builder' as const, label: '🚀 Builder', icon: '✏️' },
    { id: 'guardrails' as const, label: '🛡️ Guardrails', icon: '⚙️' },
    { id: 'voice' as const, label: '🎤 Voice', icon: '🎙️' },
    { id: 'drift' as const, label: '📊 Drift', icon: '🔍' },
    { id: 'analytics' as const, label: '📈 Analytics', icon: '📉' },
    { id: 'teleprompter' as const, label: '📺 Teleprompter', icon: '📹' },
    { id: 'modules' as const, label: '📚 Context', icon: '🔗' },
    { id: 'detector' as const, label: '🔍 Detector', icon: '📱' },
    { id: 'templates' as const, label: '📋 Templates', icon: '📄' },
    { id: 'history' as const, label: '⏱️ History', icon: '🕐' },
    { id: 'settings' as const, label: '⚙️ Settings', icon: '🔧' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex gap-1 border-b border-mc-border pb-2 overflow-x-auto">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveSection(t.id)}
            className={`px-3 py-2 text-sm rounded whitespace-nowrap transition-colors ${
              activeSection === t.id
                ? 'bg-mc-accent/20 text-mc-accent font-medium'
                : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Builder Section */}
      {activeSection === 'builder' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Raw Prompt Input */}
            <div>
              <label className="block text-sm font-semibold text-mc-text mb-2">Raw Prompt</label>
              <textarea
                value={rawPrompt}
                onChange={e => setRawPrompt(e.target.value)}
                placeholder="Paste your raw prompt here..."
                className="w-full h-64 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
              />
              <button
                onClick={() => copyToClipboard(rawPrompt)}
                className="mt-2 px-3 py-1.5 text-sm bg-mc-bg/50 text-mc-muted hover:text-mc-text rounded"
              >
                📋 Copy
              </button>
            </div>

            {/* Enhanced Prompt Output */}
            <div>
              <label className="block text-sm font-semibold text-mc-text mb-2">Enhanced Prompt</label>
              <textarea
                value={enhancedPrompt}
                readOnly
                placeholder="Enhanced version will appear here..."
                className="w-full h-64 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm"
              />
              {enhancedPrompt && (
                <button
                  onClick={() => copyToClipboard(enhancedPrompt)}
                  className="mt-2 px-3 py-1.5 text-sm bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded"
                >
                  📋 Copy
                </button>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-sm font-semibold text-mc-text mb-2">Target Model</label>
              <select
                value={targetModel}
                onChange={e => setTargetModel(e.target.value)}
                className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
              >
                {TARGET_MODELS.map(m => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-mc-text mb-2">Format for:</label>
              <select
                value={selectedFormat}
                onChange={e => setSelectedFormat(e.target.value)}
                className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
              >
                {Object.keys(PLATFORM_FORMATS).map(f => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleEnhance}
              disabled={loading}
              className="px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium text-sm transition-colors h-fit"
            >
              {loading ? '⏳ Enhancing...' : '🚀 Enhance'}
            </button>

            {enhancedPrompt && (
              <button
                onClick={() => copyToClipboard(enhancedPrompt)}
                className="px-4 py-2 bg-green-500/20 text-green-400 hover:bg-green-500/30 rounded font-medium text-sm transition-colors h-fit"
              >
                📋 Copy Formatted
              </button>
            )}
          </div>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </div>
      )}

      {/* Guardrails Section */}
      {activeSection === 'guardrails' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-mc-text">Behavior Rules</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {Object.entries(GUARDRAIL_OPTIONS).map(([key, label]) => (
              <div key={key} className="flex items-center gap-3 p-3 bg-mc-surface border border-mc-border rounded">
                <input
                  type="checkbox"
                  id={key}
                  checked={guardrails[key] || false}
                  onChange={e => {
                    const updated = { ...guardrails, [key]: e.target.checked };
                    setGuardrails(updated);
                    saveGuardrails(updated, customGuardrail);
                  }}
                  className="w-4 h-4 rounded"
                />
                <label htmlFor={key} className="text-sm text-mc-text cursor-pointer flex-1">
                  {label}
                </label>
              </div>
            ))}
          </div>

          <div>
            <label className="block text-sm font-semibold text-mc-text mb-2">Custom Guardrail</label>
            <textarea
              value={customGuardrail}
              onChange={e => {
                setCustomGuardrail(e.target.value);
                saveGuardrails(guardrails, e.target.value);
              }}
              placeholder="Add any custom rules or constraints..."
              className="w-full h-32 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
            />
          </div>
        </div>
      )}

      {/* Voice Profile Section */}
      {activeSection === 'voice' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input */}
            <div className="space-y-3">
              <h3 className="font-semibold text-mc-text">Writing Samples</h3>
              {voiceSamples.map((sample, i) => (
                <textarea
                  key={i}
                  value={sample}
                  onChange={e => {
                    const updated = [...voiceSamples];
                    updated[i] = e.target.value;
                    setVoiceSamples(updated);
                  }}
                  placeholder={`Sample ${i + 1}: Paste a writing example...`}
                  className="w-full h-24 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
                />
              ))}
              <button
                onClick={() => setVoiceSamples([...voiceSamples, ''])}
                className="px-3 py-1.5 text-sm bg-mc-bg/50 text-mc-muted hover:text-mc-text rounded"
              >
                + Add Sample
              </button>
              <button
                onClick={handleAnalyzeVoice}
                disabled={analyzingVoice}
                className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium text-sm transition-colors"
              >
                {analyzingVoice ? '⏳ Analyzing...' : '🎤 Analyze My Voice'}
              </button>
            </div>

            {/* Profile Display */}
            {voiceProfile && (
              <div className="space-y-3">
                <h3 className="font-semibold text-mc-text">Voice Profile</h3>
                <div className="bg-mc-surface border border-mc-border rounded p-4 space-y-2 text-sm">
                  <div>
                    <span className="text-mc-muted">Tone:</span>
                    <span className="ml-2 text-mc-text">{voiceProfile.tone}</span>
                  </div>
                  <div>
                    <span className="text-mc-muted">Sentence Length:</span>
                    <span className="ml-2 text-mc-text">{voiceProfile.sentenceLength}</span>
                  </div>
                  <div>
                    <span className="text-mc-muted">Vocabulary:</span>
                    <span className="ml-2 text-mc-text">{voiceProfile.vocabularyLevel}</span>
                  </div>
                  <div>
                    <span className="text-mc-muted">Humor:</span>
                    <span className="ml-2 text-mc-text">{voiceProfile.humorStyle}</span>
                  </div>
                  <div>
                    <span className="text-mc-muted">Common Phrases:</span>
                    <div className="ml-2 text-mc-text text-xs">
                      {voiceProfile.commonPhrases?.map((p, i) => (
                        <div key={i}>• {p}</div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-mc-muted">Punctuation:</span>
                    <span className="ml-2 text-mc-text text-xs">{voiceProfile.punctuationHabits}</span>
                  </div>
                </div>

                <label className="flex items-center gap-2 p-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={applyVoiceProfile}
                    onChange={e => setApplyVoiceProfile(e.target.checked)}
                    className="w-4 h-4 rounded"
                  />
                  <span className="text-sm text-mc-text">Apply to all enhanced prompts</span>
                </label>
              </div>
            )}
          </div>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </div>
      )}

      {/* Drift Detection Section */}
      {activeSection === 'drift' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input */}
            <div className="space-y-3">
              <label className="block text-sm font-semibold text-mc-text">Text to Analyze</label>
              <textarea
                value={driftText}
                onChange={e => setDriftText(e.target.value)}
                placeholder="Paste text to check for drift..."
                className="w-full h-48 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
              />
              <textarea
                value={driftContext}
                onChange={e => setDriftContext(e.target.value)}
                placeholder="Optional context..."
                className="w-full h-20 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
              />
              <button
                onClick={handleCheckDrift}
                disabled={analyzingDrift}
                className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium text-sm transition-colors"
              >
                {analyzingDrift ? '⏳ Checking...' : '🔍 Check Drift'}
              </button>
            </div>

            {/* Results */}
            <div className="space-y-3">
              {driftResult ? (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-mc-text mb-2">Drift Score</label>
                    <div className="relative h-12 bg-mc-bg border border-mc-border rounded overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          driftResult.driftScore > 70
                            ? 'bg-red-500/50'
                            : driftResult.driftScore > 40
                              ? 'bg-yellow-500/50'
                              : 'bg-green-500/50'
                        }`}
                        style={{ width: `${driftResult.driftScore}%` }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center text-sm font-semibold text-mc-text">
                        {driftResult.driftScore}/100
                      </div>
                    </div>
                  </div>

                  {(driftResult.issues || []).length > 0 && (
                    <div>
                      <h4 className="font-semibold text-mc-text mb-2 text-sm">Issues Found</h4>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {(driftResult.issues || []).map((issue, i) => (
                          <div key={i} className="bg-mc-bg rounded p-2 text-xs border-l-2 border-yellow-500">
                            <div className="font-semibold text-mc-text">{issue.type}</div>
                            <div className="text-mc-muted mt-1">{issue.description}</div>
                            <div className="text-yellow-400 mt-1">💡 {issue.suggestion}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-mc-muted text-sm text-center py-12">Results will appear here</div>
              )}
            </div>
          </div>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </div>
      )}

      {/* Analytics Section */}
      {activeSection === 'analytics' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-mc-surface border border-mc-border rounded p-4 text-center">
              <div className="text-2xl font-bold text-mc-accent">{analyticsData.totalPrompts}</div>
              <div className="text-xs text-mc-muted mt-1">Total Prompts</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded p-4 text-center">
              <div className="text-2xl font-bold text-mc-accent">{analyticsData.thisWeek}</div>
              <div className="text-xs text-mc-muted mt-1">This Week</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded p-4 text-center">
              <div className="text-2xl font-bold text-mc-accent">{analyticsData.thisMonth}</div>
              <div className="text-xs text-mc-muted mt-1">This Month</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded p-4 text-center">
              <div className="text-2xl font-bold text-mc-accent">{Object.keys(analyticsData.modelCounts).length}</div>
              <div className="text-xs text-mc-muted mt-1">Models Used</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Model Usage */}
            <div className="bg-mc-surface border border-mc-border rounded p-4">
              <h4 className="font-semibold text-mc-text mb-3">Model Usage</h4>
              <div className="space-y-2">
                {Object.entries(analyticsData.modelCounts)
                  .sort(([, a], [, b]) => b - a)
                  .map(([model, count]) => (
                    <div key={model} className="flex items-center gap-2">
                      <div className="flex-1 text-sm text-mc-text">{model}</div>
                      <div
                        className="h-2 bg-mc-accent rounded"
                        style={{
                          width: `${(count / analyticsData.totalPrompts) * 100}%`,
                        }}
                      />
                      <div className="text-xs text-mc-muted w-8 text-right">{count}</div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Tags Word Cloud */}
            {Object.keys(analyticsData.tagCounts).length > 0 && (
              <div className="bg-mc-surface border border-mc-border rounded p-4">
                <h4 className="font-semibold text-mc-text mb-3">Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(analyticsData.tagCounts)
                    .sort(([, a], [, b]) => b - a)
                    .slice(0, 20)
                    .map(([tag, count]) => (
                      <div
                        key={tag}
                        className="px-2 py-1 bg-mc-bg rounded text-xs text-mc-text"
                        style={{
                          fontSize: `${Math.min(14, 10 + count)}px`,
                        }}
                      >
                        {tag} ({count})
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Teleprompter Section */}
      {activeSection === 'teleprompter' && (
        <div className="space-y-4">
          {/* Input */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-mc-text">Text to Display</label>
            <textarea
              value={teleprompterText}
              onChange={e => setTeleprompterText(e.target.value)}
              placeholder="Paste text here..."
              className="w-full h-32 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
            />
          </div>

          {/* Display Area */}
          {teleprompterText && (
            <div
              className="w-full bg-black rounded p-8 text-white text-center transition-transform"
              style={{
                fontSize: `${teleprompterFontSize}px`,
                transform: teleprompterMirror ? 'scaleX(-1)' : 'none',
              }}
            >
              <div className="leading-relaxed whitespace-pre-wrap">{teleprompterText}</div>
            </div>
          )}

          {/* Controls */}
          <div className="space-y-3 bg-mc-surface border border-mc-border rounded p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-mc-muted mb-2">Speed (1-10)</label>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={teleprompterSpeed}
                  onChange={e => setTeleprompterSpeed(parseInt(e.target.value))}
                  className="w-full"
                />
                <div className="text-xs text-mc-text text-center mt-1">{teleprompterSpeed}</div>
              </div>

              <div>
                <label className="block text-xs text-mc-muted mb-2">Font Size</label>
                <input
                  type="range"
                  min="16"
                  max="64"
                  value={teleprompterFontSize}
                  onChange={e => setTeleprompterFontSize(parseInt(e.target.value))}
                  className="w-full"
                />
                <div className="text-xs text-mc-text text-center mt-1">{teleprompterFontSize}px</div>
              </div>

              <div className="flex items-end gap-2">
                <button
                  onClick={() => setTeleprompterPlaying(!teleprompterPlaying)}
                  className="flex-1 px-3 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded text-sm font-medium"
                >
                  {teleprompterPlaying ? '⏸️ Pause' : '▶️ Play'}
                </button>
                <button
                  onClick={() => setTeleprompterMirror(!teleprompterMirror)}
                  className={`px-3 py-2 rounded text-sm font-medium ${
                    teleprompterMirror
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-mc-bg text-mc-muted hover:text-mc-text'
                  }`}
                >
                  🪞 Mirror
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Context Modules Section */}
      {activeSection === 'modules' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Modules List */}
            <div className="space-y-3">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-semibold text-mc-text">Active Modules ({activeModules.length})</h3>
                <button
                  onClick={() => setShowNewModule(!showNewModule)}
                  className="px-3 py-1 text-xs bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded"
                >
                  + Add Module
                </button>
              </div>

              {showNewModule && (
                <div className="bg-mc-bg border border-mc-border rounded p-3 space-y-2">
                  <input
                    type="text"
                    placeholder="Module name"
                    value={newModule.name}
                    onChange={e => setNewModule({ ...newModule, name: e.target.value })}
                    className="w-full px-2 py-1.5 bg-mc-surface border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
                  />
                  <textarea
                    placeholder="Module content (markdown)"
                    value={newModule.content}
                    onChange={e => setNewModule({ ...newModule, content: e.target.value })}
                    className="w-full h-24 px-2 py-1.5 bg-mc-surface border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
                  />
                  <div className="flex gap-2 items-center">
                    <label className="text-xs text-mc-muted">Priority:</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={newModule.priority}
                      onChange={e => setNewModule({ ...newModule, priority: parseInt(e.target.value) })}
                      className="w-16 px-2 py-1 bg-mc-surface border border-mc-border rounded text-sm text-mc-text"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={handleAddModule}
                      className="flex-1 px-2 py-1.5 bg-green-500/20 text-green-400 hover:bg-green-500/30 rounded text-sm"
                    >
                      ✓ Add
                    </button>
                    <button
                      onClick={() => setShowNewModule(false)}
                      className="flex-1 px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-muted hover:text-mc-text"
                    >
                      ✕ Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2 max-h-96 overflow-y-auto">
                {modules.map(m => (
                  <div key={m.id} className="bg-mc-surface border border-mc-border rounded p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-semibold text-mc-text text-sm">{m.name}</h4>
                        <div className="flex gap-2 text-xs text-mc-muted mt-1">
                          <span>Priority: {m.priority}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleToggleModule(m.id)}
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          m.active
                            ? 'bg-green-500/20 text-green-400'
                            : 'bg-gray-500/20 text-gray-400'
                        }`}
                      >
                        {m.active ? '✓ Active' : '○ Inactive'}
                      </button>
                    </div>
                    <p className="text-xs text-mc-muted line-clamp-2">{m.content}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Combined Context Preview */}
            <div>
              <h3 className="font-semibold text-mc-text mb-3">Combined Context Preview</h3>
              <div className="bg-mc-bg border border-mc-border rounded p-4 h-96 overflow-y-auto text-xs text-mc-text whitespace-pre-wrap">
                {combinedContext || <span className="text-mc-muted">No active modules selected</span>}
              </div>
              {combinedContext && (
                <button
                  onClick={() => copyToClipboard(combinedContext)}
                  className="mt-2 px-3 py-1.5 text-sm bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded"
                >
                  📋 Copy Context
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* AI Content Detector Section */}
      {activeSection === 'detector' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input */}
            <div>
              <label className="block text-sm font-semibold text-mc-text mb-2">Text to Analyze</label>
              <textarea
                value={detectingText}
                onChange={e => setDetectingText(e.target.value)}
                placeholder="Paste text here to check for AI generation..."
                className="w-full h-64 bg-mc-bg border border-mc-border rounded p-3 text-mc-text text-sm focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
              />
              <button
                onClick={handleDetect}
                disabled={detecting}
                className="mt-2 px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium text-sm transition-colors"
              >
                {detecting ? '⏳ Scanning...' : '🔍 Scan for AI'}
              </button>
            </div>

            {/* Results */}
            <div>
              {detectionResult ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-mc-text mb-2">AI Score</label>
                    <div className="relative h-8 bg-mc-bg border border-mc-border rounded overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          detectionResult.score > 70
                            ? 'bg-red-500/50'
                            : detectionResult.score > 40
                              ? 'bg-yellow-500/50'
                              : 'bg-green-500/50'
                        }`}
                        style={{ width: `${detectionResult.score}%` }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center text-sm font-semibold text-mc-text">
                        {detectionResult.score}/100
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-mc-text mb-2 text-sm">Indicators Found</h4>
                    <div className="space-y-1">
                      {(detectionResult.indicators || []).map((ind, i) => (
                        <div key={i} className="text-xs text-mc-muted">
                          • {ind}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-mc-text mb-2 text-sm">Detailed Breakdown</h4>
                    <p className="text-xs text-mc-muted leading-relaxed">{detectionResult.breakdown}</p>
                  </div>
                </div>
              ) : (
                <div className="text-mc-muted text-sm text-center py-12">
                  Results will appear here after scanning
                </div>
              )}
            </div>
          </div>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </div>
      )}

      {/* Templates Section */}
      {activeSection === 'templates' && (
        <div className="space-y-4">
          {selectedTemplate ? (
            <div className="space-y-4">
              <button
                onClick={() => setSelectedTemplate(null)}
                className="px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text rounded"
              >
                ← Back to Templates
              </button>

              <div className="bg-mc-surface border border-mc-border rounded p-4">
                <h3 className="text-lg font-semibold text-mc-text mb-4">{selectedTemplate.name}</h3>
                <p className="text-sm text-mc-muted mb-4">{selectedTemplate.description}</p>

                {selectedTemplate.fields.length > 0 && (
                  <div className="space-y-3 mb-4">
                    <h4 className="text-sm font-semibold text-mc-text">Fill in Fields</h4>
                    {selectedTemplate.fields.map(field => (
                      <div key={field}>
                        <label className="block text-xs text-mc-muted mb-1">{field}</label>
                        <input
                          type="text"
                          placeholder={`Enter ${field.toLowerCase()}`}
                          value={templateFields[field] || ''}
                          onChange={e =>
                            setTemplateFields({ ...templateFields, [field]: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:ring-2 focus:ring-mc-accent/50"
                        />
                      </div>
                    ))}
                  </div>
                )}

                <div className="bg-mc-bg rounded p-3 mb-4">
                  <p className="text-xs text-mc-muted mb-2">Template Preview:</p>
                  <p className="text-xs text-mc-text whitespace-pre-wrap">{selectedTemplate.template}</p>
                </div>

                <button
                  onClick={handleUseTemplate}
                  className="px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium text-sm transition-colors"
                >
                  📝 Use Template
                </button>
              </div>
            </div>
          ) : (
            <div>
              {Object.entries(TEMPLATE_CATEGORIES).map(([category, names]) => (
                <div key={category} className="mb-6">
                  <h3 className="font-semibold text-mc-text mb-3">{category}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {names.map(name => {
                      const tmpl = templates.find(t => t.name === name && t.category === category);
                      return (
                        <button
                          key={name}
                          onClick={() => setSelectedTemplate(tmpl || null)}
                          className="text-left p-3 bg-mc-surface border border-mc-border rounded hover:border-mc-accent/50 transition-colors"
                        >
                          <h4 className="font-semibold text-mc-text text-sm">{name}</h4>
                          <p className="text-xs text-mc-muted mt-1">
                            {tmpl?.description || 'Coming soon'}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* History Section */}
      {activeSection === 'history' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-mc-text">Past Enhancements ({history.length})</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {history.length === 0 ? (
              <div className="text-mc-muted text-sm text-center py-8">No history yet</div>
            ) : (
              history.map(item => (
                <div key={item.id} className="bg-mc-surface border border-mc-border rounded p-3">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-mc-muted">
                        {new Date(item.timestamp).toLocaleString()}
                      </p>
                      <p className="text-sm text-mc-text line-clamp-1 mt-1">{item.rawPrompt}</p>
                    </div>
                    <span className="text-xs bg-mc-bg px-2 py-1 rounded text-mc-muted ml-2 whitespace-nowrap">
                      {item.targetModel}
                    </span>
                  </div>
                  <button
                    onClick={() => handleReuseFromHistory(item)}
                    className="text-xs text-mc-accent hover:text-mc-accent/80"
                  >
                    ↻ Reuse
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Settings Section */}
      {activeSection === 'settings' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-mc-text">Export & Import</h3>
          <div className="bg-mc-surface border border-mc-border rounded p-4 space-y-3">
            <button
              onClick={handleExport}
              className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium text-sm transition-colors"
            >
              📥 Export All Data
            </button>

            <div className="relative">
              <input
                type="file"
                accept=".json"
                onChange={e => {
                  const file = e.target.files?.[0];
                  if (file) handleImport(file);
                }}
                className="hidden"
                id="import-file"
              />
              <label
                htmlFor="import-file"
                className="block w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium text-sm transition-colors text-center cursor-pointer"
              >
                📤 Import Data
              </label>
            </div>
          </div>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </div>
      )}
    </div>
  );
}
