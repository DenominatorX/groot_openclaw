'use client';

import React, { useState, useEffect } from 'react';
import { FileText, Plus, Trash2, Edit2, Save, X, DollarSign, Users, TrendingUp, AlertCircle, Download } from 'lucide-react';

interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  hourlyRate: number;
  notes: string;
}

interface LineItem {
  description: string;
  quantity: number;
  rate: number;
}

interface Invoice {
  id: string;
  clientId: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  lineItems: LineItem[];
  taxRate: number;
  discount: number;
  notes: string;
  status: 'draft' | 'sent' | 'paid' | 'overdue';
  paidDate?: string;
  paymentMethod?: string;
}

type Tab = 'dashboard' | 'clients' | 'invoices' | 'builder';

const InvoiceApp: React.FC = () => {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [clients, setClients] = useState<Client[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [showClientForm, setShowClientForm] = useState(false);
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState<Invoice | null>(null);

  const [clientForm, setClientForm] = useState<Omit<Client, 'id'>>({
    name: '',
    company: '',
    email: '',
    phone: '',
    address: '',
    hourlyRate: 0,
    notes: '',
  });

  const [invoiceForm, setInvoiceForm] = useState<Partial<Invoice>>({
    clientId: '',
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    lineItems: [{ description: '', quantity: 1, rate: 0 }],
    taxRate: 10,
    discount: 0,
    notes: '',
    status: 'draft',
  });

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        const [clientsRes, invoicesRes] = await Promise.all([
          fetch('/api/apps/invoice/clients'),
          fetch('/api/apps/invoice/invoices'),
        ]);
        const clientsData = await clientsRes.json();
        const invoicesData = await invoicesRes.json();
        setClients(Array.isArray(clientsData) ? clientsData : clientsData.clients || []);
        setInvoices(Array.isArray(invoicesData) ? invoicesData : invoicesData.invoices || []);
      } catch (error) {
        console.error('Failed to load data:', error);
      }
    };
    loadData();
  }, []);

  // Client Management
  const addClient = async () => {
    const id = `client-${Date.now()}`;
    const newClient: Client = { ...clientForm, id };

    try {
      await fetch('/api/apps/invoice/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newClient),
      });
      setClients([...clients, newClient]);
      setClientForm({
        name: '',
        company: '',
        email: '',
        phone: '',
        address: '',
        hourlyRate: 0,
        notes: '',
      });
      setShowClientForm(false);
    } catch (error) {
      console.error('Failed to add client:', error);
    }
  };

  const updateClient = async () => {
    if (!editingClient) return;

    try {
      await fetch(`/api/apps/invoice/clients/${editingClient.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingClient),
      });
      setClients(clients.map((c) => (c.id === editingClient.id ? editingClient : c)));
      setEditingClient(null);
    } catch (error) {
      console.error('Failed to update client:', error);
    }
  };

  const deleteClient = async (id: string) => {
    try {
      await fetch(`/api/apps/invoice/clients/${id}`, { method: 'DELETE' });
      setClients(clients.filter((c) => c.id !== id));
    } catch (error) {
      console.error('Failed to delete client:', error);
    }
  };

  // Invoice Management
  const createInvoice = async () => {
    if (!invoiceForm.clientId || !invoiceForm.lineItems?.length) {
      alert('Please select a client and add line items');
      return;
    }

    const invoiceNumber = `INV-${clients.find((c) => c.id === invoiceForm.clientId)?.name}-${Date.now().toString().slice(-6)}`;
    const newInvoice: Invoice = {
      id: `invoice-${Date.now()}`,
      invoiceNumber,
      clientId: invoiceForm.clientId,
      date: invoiceForm.date || new Date().toISOString().split('T')[0],
      dueDate: invoiceForm.dueDate || '',
      lineItems: invoiceForm.lineItems,
      taxRate: invoiceForm.taxRate || 10,
      discount: invoiceForm.discount || 0,
      notes: invoiceForm.notes || '',
      status: 'draft',
    };

    try {
      await fetch('/api/apps/invoice/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newInvoice),
      });
      setInvoices([...invoices, newInvoice]);
      setInvoiceForm({
        clientId: '',
        date: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        lineItems: [{ description: '', quantity: 1, rate: 0 }],
        taxRate: 10,
        discount: 0,
        notes: '',
        status: 'draft',
      });
      setShowInvoiceForm(false);
      setTab('invoices');
    } catch (error) {
      console.error('Failed to create invoice:', error);
    }
  };

  const updateInvoiceStatus = async (invoiceId: string, status: Invoice['status'], paidDate?: string) => {
    try {
      await fetch(`/api/apps/invoice/invoices/${invoiceId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, paidDate }),
      });
      setInvoices(
        invoices.map((inv) =>
          inv.id === invoiceId
            ? { ...inv, status, paidDate: paidDate || inv.paidDate }
            : inv
        )
      );
    } catch (error) {
      console.error('Failed to update invoice:', error);
    }
  };

  const deleteInvoice = async (id: string) => {
    try {
      await fetch(`/api/apps/invoice/invoices/${id}`, { method: 'DELETE' });
      setInvoices(invoices.filter((inv) => inv.id !== id));
    } catch (error) {
      console.error('Failed to delete invoice:', error);
    }
  };

  // Calculations
  const calculateInvoiceTotal = (invoice: Invoice) => {
    const subtotal = invoice.lineItems.reduce((sum, item) => sum + item.quantity * item.rate, 0);
    const taxAmount = (subtotal - invoice.discount) * (invoice.taxRate / 100);
    return subtotal - invoice.discount + taxAmount;
  };

  const getClientName = (clientId: string) => clients.find((c) => c.id === clientId)?.name || 'Unknown';

  // Dashboard Metrics
  const totalRevenue = invoices
    .filter((inv) => inv.status === 'paid')
    .reduce((sum, inv) => sum + calculateInvoiceTotal(inv), 0);

  const outstandingAmount = invoices
    .filter((inv) => inv.status === 'sent' || inv.status === 'draft')
    .reduce((sum, inv) => sum + calculateInvoiceTotal(inv), 0);

  const overdueAmount = invoices
    .filter((inv) => inv.status === 'overdue')
    .reduce((sum, inv) => sum + calculateInvoiceTotal(inv), 0);

  const thisMonthRevenue = invoices
    .filter((inv) => {
      const invDate = new Date(inv.date);
      const now = new Date();
      return inv.status === 'paid' &&
        invDate.getMonth() === now.getMonth() &&
        invDate.getFullYear() === now.getFullYear();
    })
    .reduce((sum, inv) => sum + calculateInvoiceTotal(inv), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 text-white">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <FileText className="w-10 h-10 text-blue-400" />
            <h1 className="text-4xl font-bold">Invoice & Client Manager</h1>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-4 mb-8 border-b border-slate-700">
          {(['dashboard', 'clients', 'invoices', 'builder'] as const).map((t) => (
            <button
              key={t}
              onClick={() => {
                setTab(t);
                if (t === 'builder') setShowInvoiceForm(true);
              }}
              className={`px-4 py-3 font-semibold transition border-b-2 ${
                tab === t
                  ? 'border-blue-400 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              {t === 'dashboard' && '📊 Dashboard'}
              {t === 'clients' && '👥 Clients'}
              {t === 'invoices' && '📄 Invoices'}
              {t === 'builder' && '✏️ Create Invoice'}
            </button>
          ))}
        </div>

        {/* Dashboard Tab */}
        {tab === 'dashboard' && (
          <div>
            <div className="grid grid-cols-4 gap-4 mb-8">
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-400 mb-2">Total Revenue</p>
                    <p className="text-3xl font-bold text-green-400">${totalRevenue.toFixed(2)}</p>
                  </div>
                  <TrendingUp className="w-6 h-6 text-green-400" />
                </div>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-400 mb-2">Outstanding</p>
                    <p className="text-3xl font-bold text-yellow-400">${outstandingAmount.toFixed(2)}</p>
                  </div>
                  <DollarSign className="w-6 h-6 text-yellow-400" />
                </div>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-400 mb-2">Overdue</p>
                    <p className="text-3xl font-bold text-red-400">${overdueAmount.toFixed(2)}</p>
                  </div>
                  <AlertCircle className="w-6 h-6 text-red-400" />
                </div>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-400 mb-2">This Month</p>
                    <p className="text-3xl font-bold text-blue-400">${thisMonthRevenue.toFixed(2)}</p>
                  </div>
                  <Users className="w-6 h-6 text-blue-400" />
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Recent Invoices</h2>
              <div className="space-y-3">
                {invoices.slice(-5).reverse().map((inv) => (
                  <div key={inv.id} className="flex justify-between items-center p-4 bg-slate-700/30 rounded-lg">
                    <div>
                      <p className="font-semibold">{inv.invoiceNumber}</p>
                      <p className="text-sm text-slate-400">{getClientName(inv.clientId)} • {inv.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${calculateInvoiceTotal(inv).toFixed(2)}</p>
                      <span className={`text-xs px-2 py-1 rounded ${
                        inv.status === 'paid' ? 'bg-green-900/50 text-green-300' :
                        inv.status === 'overdue' ? 'bg-red-900/50 text-red-300' :
                        inv.status === 'sent' ? 'bg-blue-900/50 text-blue-300' :
                        'bg-slate-700/50 text-slate-300'
                      }`}>
                        {inv.status.charAt(0).toUpperCase() + inv.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Clients Tab */}
        {tab === 'clients' && (
          <div>
            <button
              onClick={() => setShowClientForm(true)}
              className="mb-6 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg font-semibold flex items-center gap-2 transition"
            >
              <Plus className="w-5 h-5" />
              New Client
            </button>

            {/* Client Form Modal */}
            {showClientForm && (
              <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 max-w-2xl w-full max-h-96 overflow-y-auto">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold">New Client</h2>
                    <button onClick={() => setShowClientForm(false)} className="text-2xl">✕</button>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <input
                      type="text"
                      placeholder="Name *"
                      value={clientForm.name}
                      onChange={(e) => setClientForm({ ...clientForm, name: e.target.value })}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="text"
                      placeholder="Company"
                      value={clientForm.company}
                      onChange={(e) => setClientForm({ ...clientForm, company: e.target.value })}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="email"
                      placeholder="Email *"
                      value={clientForm.email}
                      onChange={(e) => setClientForm({ ...clientForm, email: e.target.value })}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="tel"
                      placeholder="Phone"
                      value={clientForm.phone}
                      onChange={(e) => setClientForm({ ...clientForm, phone: e.target.value })}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="text"
                      placeholder="Address"
                      value={clientForm.address}
                      onChange={(e) => setClientForm({ ...clientForm, address: e.target.value })}
                      className="col-span-2 px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="number"
                      placeholder="Hourly Rate"
                      value={clientForm.hourlyRate}
                      onChange={(e) => setClientForm({ ...clientForm, hourlyRate: parseFloat(e.target.value) })}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                  </div>
                  <button
                    onClick={addClient}
                    className="w-full px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg font-semibold transition"
                  >
                    Create Client
                  </button>
                </div>
              </div>
            )}

            {/* Clients List */}
            <div className="grid grid-cols-1 gap-4">
              {clients.map((client) => (
                <div key={client.id} className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                  {editingClient?.id === client.id ? (
                    <div className="space-y-4">
                      <input
                        type="text"
                        value={editingClient.name}
                        onChange={(e) => setEditingClient({ ...editingClient, name: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                      />
                      <input
                        type="email"
                        value={editingClient.email}
                        onChange={(e) => setEditingClient({ ...editingClient, email: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={updateClient}
                          className="px-4 py-2 bg-green-500 hover:bg-green-600 rounded font-semibold transition flex items-center gap-2"
                        >
                          <Save className="w-4 h-4" />
                          Save
                        </button>
                        <button
                          onClick={() => setEditingClient(null)}
                          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded font-semibold transition"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-bold">{client.name}</h3>
                        <p className="text-sm text-slate-400">{client.company}</p>
                        <p className="text-sm text-slate-400 mt-2">{client.email}</p>
                        <p className="text-sm text-slate-400">{client.phone}</p>
                        <p className="text-sm text-blue-400 font-semibold mt-2">${client.hourlyRate}/hr</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingClient(client)}
                          className="px-3 py-2 bg-blue-500/30 hover:bg-blue-500/50 rounded transition flex items-center gap-1"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteClient(client.id)}
                          className="px-3 py-2 bg-red-500/30 hover:bg-red-500/50 rounded transition flex items-center gap-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Invoices Tab */}
        {tab === 'invoices' && (
          <div>
            <button
              onClick={() => {
                setTab('builder');
                setShowInvoiceForm(true);
              }}
              className="mb-6 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg font-semibold flex items-center gap-2 transition"
            >
              <Plus className="w-5 h-5" />
              Create Invoice
            </button>

            <div className="grid grid-cols-1 gap-4">
              {invoices.map((invoice) => (
                <div key={invoice.id} className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-bold">{invoice.invoiceNumber}</h3>
                      <p className="text-sm text-slate-400">{getClientName(invoice.clientId)}</p>
                      <p className="text-sm text-slate-400">Date: {invoice.date} • Due: {invoice.dueDate}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-400">${calculateInvoiceTotal(invoice).toFixed(2)}</p>
                      <select
                        value={invoice.status}
                        onChange={(e) => updateInvoiceStatus(invoice.id, e.target.value as Invoice['status'])}
                        className={`mt-2 px-3 py-1 rounded text-sm font-semibold ${
                          invoice.status === 'paid' ? 'bg-green-900/50 text-green-300' :
                          invoice.status === 'overdue' ? 'bg-red-900/50 text-red-300' :
                          invoice.status === 'sent' ? 'bg-blue-900/50 text-blue-300' :
                          'bg-slate-700/50 text-slate-300'
                        }`}
                      >
                        <option value="draft">Draft</option>
                        <option value="sent">Sent</option>
                        <option value="paid">Paid</option>
                        <option value="overdue">Overdue</option>
                      </select>
                    </div>
                  </div>

                  <div className="bg-slate-700/20 rounded p-4 mb-4">
                    {invoice.lineItems.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-sm mb-2">
                        <span>{item.description}</span>
                        <span>${(item.quantity * item.rate).toFixed(2)}</span>
                      </div>
                    ))}
                    <div className="border-t border-slate-600 pt-2 mt-2 text-sm">
                      <div className="flex justify-between font-semibold">
                        <span>Subtotal:</span>
                        <span>${invoice.lineItems.reduce((sum, item) => sum + item.quantity * item.rate, 0).toFixed(2)}</span>
                      </div>
                      {invoice.discount > 0 && (
                        <div className="flex justify-between text-red-400">
                          <span>Discount:</span>
                          <span>-${invoice.discount.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-blue-400">
                        <span>Tax ({invoice.taxRate}%):</span>
                        <span>${((invoice.lineItems.reduce((sum, item) => sum + item.quantity * item.rate, 0) - invoice.discount) * (invoice.taxRate / 100)).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => deleteInvoice(invoice.id)}
                      className="px-3 py-2 bg-red-500/30 hover:bg-red-500/50 rounded transition flex items-center gap-1 text-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Invoice Builder Tab */}
        {tab === 'builder' && showInvoiceForm && (
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-8">Create Invoice</h2>

            <div className="grid grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-sm font-semibold mb-2">Select Client *</label>
                <select
                  value={invoiceForm.clientId || ''}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, clientId: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                >
                  <option value="">-- Choose a client --</option>
                  {clients.map((client) => (
                    <option key={client.id} value={client.id}>
                      {client.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Due Date</label>
                <input
                  type="date"
                  value={invoiceForm.dueDate || ''}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, dueDate: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                />
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-bold mb-4">Line Items</h3>
              <div className="space-y-4">
                {invoiceForm.lineItems?.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-4 gap-3">
                    <input
                      type="text"
                      placeholder="Description *"
                      value={item.description}
                      onChange={(e) => {
                        const newItems = [...(invoiceForm.lineItems || [])];
                        newItems[idx].description = e.target.value;
                        setInvoiceForm({ ...invoiceForm, lineItems: newItems });
                      }}
                      className="col-span-2 px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="number"
                      placeholder="Qty"
                      value={item.quantity}
                      onChange={(e) => {
                        const newItems = [...(invoiceForm.lineItems || [])];
                        newItems[idx].quantity = parseFloat(e.target.value);
                        setInvoiceForm({ ...invoiceForm, lineItems: newItems });
                      }}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                    <input
                      type="number"
                      placeholder="Rate"
                      value={item.rate}
                      onChange={(e) => {
                        const newItems = [...(invoiceForm.lineItems || [])];
                        newItems[idx].rate = parseFloat(e.target.value);
                        setInvoiceForm({ ...invoiceForm, lineItems: newItems });
                      }}
                      className="px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                  </div>
                ))}
              </div>
              <button
                onClick={() => {
                  const newItems = [...(invoiceForm.lineItems || [])];
                  newItems.push({ description: '', quantity: 1, rate: 0 });
                  setInvoiceForm({ ...invoiceForm, lineItems: newItems });
                }}
                className="mt-4 px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded text-sm transition"
              >
                + Add Line Item
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-sm font-semibold mb-2">Tax Rate (%)</label>
                <input
                  type="number"
                  value={invoiceForm.taxRate || 0}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, taxRate: parseFloat(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Discount</label>
                <input
                  type="number"
                  value={invoiceForm.discount || 0}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, discount: parseFloat(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                />
              </div>
            </div>

            <div className="mb-8">
              <label className="block text-sm font-semibold mb-2">Notes</label>
              <textarea
                value={invoiceForm.notes || ''}
                onChange={(e) => setInvoiceForm({ ...invoiceForm, notes: e.target.value })}
                placeholder="Thank you for your business!"
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white h-24"
              />
            </div>

            <div className="flex gap-4">
              <button
                onClick={createInvoice}
                className="px-6 py-3 bg-blue-500 hover:bg-blue-600 rounded-lg font-bold transition"
              >
                Create Invoice
              </button>
              <button
                onClick={() => {
                  setShowInvoiceForm(false);
                  setTab('invoices');
                }}
                className="px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold transition"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default InvoiceApp;
