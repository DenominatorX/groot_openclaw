'use client';

interface FormFieldProps {
  label: string;
  type?: 'text' | 'email' | 'tel' | 'number' | 'date' | 'select' | 'textarea';
  value: string | number;
  onChange: (value: string) => void;
  placeholder?: string;
  options?: { label: string; value: string }[];
  required?: boolean;
  rows?: number;
  min?: number;
  max?: number;
}

export default function FormField({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  options,
  required = false,
  rows = 3,
  min,
  max,
}: FormFieldProps) {
  const baseInputClass = "w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none";

  return (
    <div>
      <label className="block text-sm text-gray-400 mb-1">
        {label} {required && <span className="text-[#DC143C]">*</span>}
      </label>
      {type === 'textarea' ? (
        <textarea
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          rows={rows}
          className={`${baseInputClass} resize-none`}
        />
      ) : type === 'select' ? (
        <select
          value={value}
          onChange={e => onChange(e.target.value)}
          className={baseInputClass}
        >
          {options?.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      ) : (
        <input
          type={type}
          value={value}
          onChange={e => onChange(type === 'number' ? e.target.value : e.target.value)}
          placeholder={placeholder}
          min={min}
          max={max}
          className={baseInputClass}
        />
      )}
    </div>
  );
}
