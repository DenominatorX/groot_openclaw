'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface SavedReport {
  id: string;
  type: string;
  title: string;
  content: string;
  savedAt: string;
}

const QUICK_TEMPLATES = [
  { id: 'competitor', label: '🎖️ Competitor Analysis', action: 'competitors', placeholder: 'Competitor company name...' },
  { id: 'market', label: '📊 Market Sizing', action: 'industry', placeholder: 'Industry or market to size...' },
  { id: 'audience', label: '👤 Audience Insights', action: 'persona', placeholder: 'Target audience description...' },
  { id: 'trends', label: '📡 Trend Spotting', action: 'trends', placeholder: 'Industry for trend analysis...' },
];

export default function ResearchPanel() {
  const [researchTab, setResearchTab] = useState<'quick' | 'swot' | 'persona' | 'valueprop' | 'saved'>('quick');
  const [research, setResearch] = useState<any>(null);
  const [savedReports, setSavedReports] = useState<SavedReport[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=research');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'research', title, content, tags: ['research'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateResearch = async (action: string, input: string | Record<string, string>) => {
    setLoading(true); setError('');
    try {
      const body = typeof input === 'string' ? { [action]: input } : { ...input };
      const res = await fetch('/api/apps/maxtarget/research', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...body }),
      });
      if (res.ok) { const data = await res.json(); setResearch(data.research || data); setSuccess('Research generated'); }
      else { setError('Failed to generate research'); }
    } catch { setError('Error generating research'); }
    finally { setLoading(false); }
  };

  const saveReport = (type: string, title: string) => {
    const content = typeof research === 'string' ? research : JSON.stringify(research, null, 2);
    setSavedReports(prev => [...prev, { id: Date.now().toString(), type, title, content, savedAt: new Date().toISOString() }]);
    setSuccess('Report saved');
  };

  const renderResearchOutput = (title: string) => {
    if (!research) return null;
    const content = typeof research === 'string' ? research : JSON.stringify(research, null, 2);

    // Try to render structured output
    if (typeof research === 'object' && !Array.isArray(research)) {
      return (
        <div className="space-y-3">
          {Object.entries(research).map(([key, value]) => (
            <div key={key} className="bg-gray-800 rounded p-3 border border-gray-700">
              <div className="text-sm font-semibold text-[#DC143C] capitalize mb-2">{key.replace(/_/g, ' ')}</div>
              {Array.isArray(value) ? (
                <ul className="space-y-1">{(value as any[]).map((item, i) => <li key={i} className="text-sm text-gray-300">• {String(item)}</li>)}</ul>
              ) : (
                <p className="text-sm text-gray-100 whitespace-pre-wrap">{String(value)}</p>
              )}
            </div>
          ))}
          <div className="flex gap-2">
            <button onClick={() => { navigator.clipboard.writeText(content); setSuccess('Copied'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            <button onClick={() => saveReport(title, title)}
              className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
          </div>
        </div>
      );
    }

    return (
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="whitespace-pre-wrap text-sm text-gray-100 max-h-96 overflow-y-auto mb-3">{content}</div>
        <div className="flex gap-2">
          <button onClick={() => { navigator.clipboard.writeText(content); setSuccess('Copied'); }}
            className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
          <button onClick={() => saveReport(title, title)}
            className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
        </div>
      </div>
    );
  };

  const renderQuick = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {QUICK_TEMPLATES.map(tmpl => (
          <div key={tmpl.id} className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-sm font-semibold text-gray-100 mb-2">{tmpl.label}</div>
            <input type="text" placeholder={tmpl.placeholder} id={`quick_${tmpl.id}`}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 text-sm mb-2" />
            <button onClick={() => { generateResearch(tmpl.action, (document.getElementById(`quick_${tmpl.id}`) as HTMLInputElement).value); }}
              disabled={loading} className="w-full px-3 py-1.5 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded text-sm font-medium disabled:opacity-50">
              {loading ? '⏳...' : '🔬 Research'}
            </button>
          </div>
        ))}
      </div>
      {loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-2xl mb-2 animate-pulse">🔬</div>
          <div className="text-gray-400 text-sm">Researching...</div>
        </div>
      )}
      {renderResearchOutput('Quick Research')}
    </div>
  );

  const renderSWOT = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Company or Product</label>
        <input type="text" placeholder="Your company or product name..." id="swotInput" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={() => { generateResearch('swot', (document.getElementById('swotInput') as HTMLInputElement).value); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '⚙️ Generate SWOT'}
        </button>
      </div>
      {research && typeof research === 'object' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { key: 'strengths', color: 'green', icon: '✅' },
            { key: 'weaknesses', color: 'red', icon: '❌' },
            { key: 'opportunities', color: 'blue', icon: '🎯' },
            { key: 'threats', color: 'yellow', icon: '⚠️' },
          ].map(({ key, color, icon }) => (
            <div key={key} className={`bg-gray-800 rounded p-3 border border-${color}-700/50`}>
              <div className={`text-sm font-semibold text-${color}-500 mb-2`}>{icon} {key.charAt(0).toUpperCase() + key.slice(1)}</div>
              <ul className="space-y-1">
                {(Array.isArray(research[key]) ? research[key] : [research[key]]).filter(Boolean).map((item: any, i: number) => (
                  <li key={i} className="text-xs text-gray-300">• {item}</li>
                ))}
              </ul>
            </div>
          ))}
          <div className="col-span-full flex gap-2">
            <button onClick={() => { navigator.clipboard.writeText(JSON.stringify(research, null, 2)); setSuccess('SWOT copied'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            <button onClick={() => saveReport('SWOT', 'SWOT Analysis')}
              className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
          </div>
        </div>
      )}
    </div>
  );

  const renderPersona = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Target Market</label>
        <textarea placeholder="Describe your target market (industry, company size, role, etc.)" id="personaInput" rows={3}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={() => { generateResearch('persona', (document.getElementById('personaInput') as HTMLTextAreaElement).value); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Building...' : '👤 Build Persona'}
        </button>
      </div>
      {renderResearchOutput('Buyer Persona')}
    </div>
  );

  const renderValueProp = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Product/Service</label>
          <input type="text" placeholder="What do you offer?" id="valuePropProduct" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Audience</label>
          <input type="text" placeholder="Who is it for?" id="valuePropAudience" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateResearch('valueprop', { product: (document.getElementById('valuePropProduct') as HTMLInputElement).value, audience: (document.getElementById('valuePropAudience') as HTMLInputElement).value });
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Building...' : '🎯 Build Value Prop'}
        </button>
      </div>
      {renderResearchOutput('Value Proposition')}
    </div>
  );

  const renderSaved = () => (
    <div className="space-y-4">
      {savedReports.length === 0 ? (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">📚</div>
          <div className="text-gray-400 mb-2">No saved research yet</div>
          <div className="text-gray-500 text-sm">Run research and save reports here for easy reference</div>
        </div>
      ) : savedReports.map(report => (
        <div key={report.id} className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm font-semibold text-gray-100">{report.title}</div>
              <div className="text-xs text-gray-500 mt-1">{report.type} • {new Date(report.savedAt).toLocaleDateString()}</div>
            </div>
            <button onClick={() => setSavedReports(prev => prev.filter(r => r.id !== report.id))} className="text-xs text-red-400 hover:text-red-300">✕</button>
          </div>
          <div className="text-xs text-gray-400 mt-2 line-clamp-3 whitespace-pre-wrap">{report.content}</div>
          <button onClick={() => { navigator.clipboard.writeText(report.content); setSuccess('Report copied'); }}
            className="text-xs mt-2 px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'quick', label: '🔬 Quick Research' },
          { id: 'swot', label: '⚙️ SWOT' },
          { id: 'persona', label: '👤 Persona' },
          { id: 'valueprop', label: '🎯 Value Prop' },
          { id: 'saved', label: '📚 Saved' },
        ].map(t => (
          <button key={t.id} onClick={() => setResearchTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              researchTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {researchTab === 'quick' && renderQuick()}
      {researchTab === 'swot' && renderSWOT()}
      {researchTab === 'persona' && renderPersona()}
      {researchTab === 'valueprop' && renderValueProp()}
      {researchTab === 'saved' && renderSaved()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
