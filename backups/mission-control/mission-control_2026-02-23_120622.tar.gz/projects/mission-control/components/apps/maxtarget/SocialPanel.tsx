'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface SocialPost {
  id: string;
  platform: string;
  content: string;
  hashtags: string[];
  cta: string;
  scheduledDate?: string;
  scheduledTime?: string;
}

const PLATFORM_LIMITS: Record<string, number> = {
  'LinkedIn': 3000,
  'Twitter/X': 280,
  'Facebook': 63206,
  'Instagram': 2200,
  'TikTok': 2200,
};

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function SocialPanel() {
  const [socialTab, setSocialTab] = useState<'generator' | 'calendar' | 'library' | 'hashtags'>('generator');
  const [posts, setPosts] = useState<SocialPost[]>([]);
  const [savedPosts, setSavedPosts] = useState<SocialPost[]>([]);
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState('LinkedIn');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [postDraft, setPostDraft] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=social');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'social', title, content, tags: ['social'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generatePost = async (platform: string, topic: string) => {
    if (!platform || !topic.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/social', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'post', platform, topic }),
      });
      if (res.ok) {
        const data = await res.json();
        const newPost: SocialPost = { id: Date.now().toString(), platform, content: data.post, hashtags: data.hashtags || [], cta: data.cta || '' };
        setPosts([...posts, newPost]);
        setPostDraft(data.post || '');
        setSuccess('Post generated');
      } else { setError('Failed to generate post'); }
    } catch { setError('Error generating post'); }
    finally { setLoading(false); }
  };

  const generateHashtags = async (topic: string) => {
    if (!topic.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/social', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'hashtags', topic }),
      });
      if (res.ok) { const data = await res.json(); setHashtags(data.hashtags || []); setSuccess('Hashtags generated'); }
      else { setError('Failed to generate hashtags'); }
    } catch { setError('Error generating hashtags'); }
    finally { setLoading(false); }
  };

  const charLimit = PLATFORM_LIMITS[selectedPlatform] || 3000;

  const renderGenerator = () => (
    <div className="space-y-4">
      {/* Platform Selector */}
      <div className="flex gap-2 flex-wrap">
        {Object.keys(PLATFORM_LIMITS).map(p => (
          <button key={p} onClick={() => setSelectedPlatform(p)}
            className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
              selectedPlatform === p ? 'bg-[#DC143C]/20 text-[#DC143C] border border-[#DC143C]/50' : 'bg-gray-800 text-gray-400 border border-gray-700 hover:text-gray-300'
            }`}>{p}</button>
        ))}
      </div>

      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Topic/Idea</label>
          <textarea placeholder="What would you like to post about?" id="postTopic" rows={3}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          const topic = (document.getElementById('postTopic') as HTMLTextAreaElement).value;
          generatePost(selectedPlatform, topic);
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '✨ Generate Post'}
        </button>
      </div>

      {/* Draft Editor with char count */}
      {postDraft && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex justify-between items-center mb-2">
            <div className="text-xs font-semibold text-red-600">{selectedPlatform} Draft</div>
            <div className={`text-xs ${postDraft.length > charLimit ? 'text-red-400' : 'text-gray-500'}`}>
              {postDraft.length}/{charLimit}
            </div>
          </div>
          <textarea value={postDraft} onChange={e => setPostDraft(e.target.value)} rows={4}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 text-sm mb-3" />
          {postDraft.length > charLimit && (
            <div className="text-xs text-red-400 mb-2">⚠️ Over character limit by {postDraft.length - charLimit} characters</div>
          )}
          <div className="flex gap-2">
            <button onClick={() => { navigator.clipboard.writeText(postDraft); setSuccess('Post copied'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            <button onClick={() => {
              setSavedPosts(prev => [...prev, { id: Date.now().toString(), platform: selectedPlatform, content: postDraft, hashtags: [], cta: '' }]);
              setSuccess('Post saved to library');
            }} className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
          </div>
        </div>
      )}

      {/* Generated Posts */}
      <div className="space-y-3">
        {posts.map((post) => (
          <div key={post.id} className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="flex justify-between items-start mb-2">
              <div className="text-xs font-semibold text-red-600">{post.platform}</div>
              <div className="text-xs text-gray-500">{post.content.length}/{PLATFORM_LIMITS[post.platform] || '∞'}</div>
            </div>
            <p className="text-sm text-gray-100 mb-3">{post.content}</p>
            {post.hashtags.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-2">
                {post.hashtags.map((tag, j) => <span key={j} className="text-xs text-blue-400">#{tag}</span>)}
              </div>
            )}
            {post.cta && <div className="text-xs text-emerald-400 mb-3 font-semibold">CTA: {post.cta}</div>}
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(post.content); setSuccess('Post copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => { setSavedPosts(prev => [...prev, post]); setSuccess('Post saved'); }}
                className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCalendar = () => {
    const [calendarPosts, setCalendarPosts] = useState<Record<string, SocialPost[]>>({});
    const [addingDay, setAddingDay] = useState<string | null>(null);
    const [newPostContent, setNewPostContent] = useState('');

    return (
      <div className="space-y-4">
        <div className="text-sm font-semibold text-gray-100 mb-2">📅 Content Calendar — This Week</div>
        <div className="grid grid-cols-7 gap-2">
          {DAYS.map(day => (
            <div key={day} className="bg-gray-800 rounded border border-gray-700 min-h-[200px]">
              <div className="text-xs font-semibold text-gray-400 p-2 border-b border-gray-700 text-center">{day}</div>
              <div className="p-2 space-y-2">
                {(calendarPosts[day] || []).map((post, i) => (
                  <div key={i} className="bg-gray-700 rounded p-1.5 text-xs text-gray-300">
                    <div className="text-[10px] text-red-600 font-semibold mb-0.5">{post.platform}</div>
                    <div className="line-clamp-2">{post.content}</div>
                    <button onClick={() => {
                      setCalendarPosts(prev => ({ ...prev, [day]: (prev[day] || []).filter((_, j) => j !== i) }));
                    }} className="text-[10px] text-red-400 mt-1">Remove</button>
                  </div>
                ))}
                {addingDay === day ? (
                  <div className="space-y-1">
                    <textarea value={newPostContent} onChange={e => setNewPostContent(e.target.value)} rows={2}
                      className="w-full px-1 py-1 bg-gray-900 border border-gray-600 rounded text-[10px] text-gray-100" placeholder="Post content..." />
                    <div className="flex gap-1">
                      <button onClick={() => {
                        if (newPostContent.trim()) {
                          setCalendarPosts(prev => ({ ...prev, [day]: [...(prev[day] || []), { id: Date.now().toString(), platform: selectedPlatform, content: newPostContent, hashtags: [], cta: '' }] }));
                          setNewPostContent('');
                          setAddingDay(null);
                        }
                      }} className="text-[10px] px-1.5 py-0.5 bg-[#DC143C] text-white rounded">Add</button>
                      <button onClick={() => { setAddingDay(null); setNewPostContent(''); }} className="text-[10px] px-1.5 py-0.5 bg-gray-700 text-gray-300 rounded">✕</button>
                    </div>
                  </div>
                ) : (
                  <button onClick={() => setAddingDay(day)} className="w-full text-[10px] text-gray-500 hover:text-gray-300 py-1">+ Add Post</button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderLibrary = () => (
    <div className="space-y-4">
      {savedPosts.length === 0 ? (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">📚</div>
          <div className="text-gray-400 mb-2">No saved posts yet</div>
          <div className="text-gray-500 text-sm">Generate posts and save them here for later use</div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="text-sm font-semibold text-gray-100">📚 Saved Posts ({savedPosts.length})</div>
          {savedPosts.map((post, i) => (
            <div key={post.id} className="bg-gray-800 rounded p-4 border border-gray-700">
              <div className="flex justify-between items-start mb-2">
                <div className="text-xs font-semibold text-red-600">{post.platform}</div>
                <button onClick={() => setSavedPosts(prev => prev.filter((_, j) => j !== i))}
                  className="text-xs text-red-400 hover:text-red-300">✕</button>
              </div>
              <p className="text-sm text-gray-100 mb-2">{post.content}</p>
              <button onClick={() => { navigator.clipboard.writeText(post.content); setSuccess('Post copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderHashtags = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Topic</label>
        <input type="text" placeholder="e.g., AI productivity tools, remote work..." id="hashtagTopic"
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={() => { const topic = (document.getElementById('hashtagTopic') as HTMLInputElement).value; generateHashtags(topic); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '🏷️ Generate Hashtags'}
        </button>
      </div>
      {hashtags.length > 0 && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex flex-wrap gap-2 mb-3">
            {hashtags.map((tag, i) => <span key={i} className="text-sm text-blue-400 bg-gray-700 px-2 py-1 rounded">#{tag}</span>)}
          </div>
          <button onClick={() => { navigator.clipboard.writeText(hashtags.map(h => `#${h}`).join(' ')); setSuccess('Hashtags copied'); }}
            className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy All</button>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'generator', label: '✨ Generator' },
          { id: 'calendar', label: '📅 Calendar' },
          { id: 'library', label: '📚 Library' },
          { id: 'hashtags', label: '🏷️ Hashtags' },
        ].map(t => (
          <button key={t.id} onClick={() => setSocialTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              socialTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {socialTab === 'generator' && renderGenerator()}
      {socialTab === 'calendar' && renderCalendar()}
      {socialTab === 'library' && renderLibrary()}
      {socialTab === 'hashtags' && renderHashtags()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
