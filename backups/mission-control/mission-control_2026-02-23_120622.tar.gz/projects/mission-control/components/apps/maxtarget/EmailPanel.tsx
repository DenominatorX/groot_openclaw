'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface EmailVariant {
  subject: string;
  body: string;
  predictedOpenRate?: 'low' | 'medium' | 'high';
}

interface SavedEmail {
  id: string;
  subject: string;
  body: string;
  savedAt: string;
}

interface ABTest {
  id: string;
  subjectA: string;
  subjectB: string;
  winner: 'A' | 'B' | 'pending';
  openRateA?: number;
  openRateB?: number;
}

const EMAIL_TEMPLATES = [
  { id: 'welcome', name: '🎉 Welcome Email', subject: 'Welcome to {{company}} — Here\'s what\'s next', body: 'Hi {{first_name}},\n\nWelcome aboard! We\'re thrilled to have you.\n\nHere\'s what you can do right now:\n1. Complete your profile setup\n2. Explore our key features\n3. Join our community\n\nNeed help? Reply to this email — we\'re real humans.\n\nCheers,\n{{sender_name}}' },
  { id: 'followup', name: '🔄 Follow-Up', subject: 'Quick follow-up: {{topic}}', body: 'Hi {{first_name}},\n\nJust following up on our conversation about {{topic}}.\n\nI wanted to share a few resources that might help:\n• [Resource 1]\n• [Resource 2]\n\nWould love to schedule a quick call this week. What works for you?\n\nBest,\n{{sender_name}}' },
  { id: 'casestudy', name: '📊 Case Study', subject: 'How {{client}} achieved {{result}} with us', body: 'Hi {{first_name}},\n\nI thought you\'d find this interesting — we recently helped {{client}} achieve {{result}}.\n\nThe challenge:\n{{challenge}}\n\nOur approach:\n{{approach}}\n\nThe results:\n{{results}}\n\nWant similar results? Let\'s chat.\n\n{{sender_name}}' },
  { id: 'webinar', name: '🎥 Webinar Invite', subject: 'You\'re invited: {{webinar_title}} [{{date}}]', body: 'Hi {{first_name}},\n\nYou\'re invited to our upcoming webinar:\n\n📌 {{webinar_title}}\n📅 {{date}} at {{time}}\n⏱️ {{duration}} minutes\n\nWhat you\'ll learn:\n• Key insight 1\n• Key insight 2\n• Key insight 3\n\n👉 [Register Now]\n\nSpots are limited — save yours today.\n\n{{sender_name}}' },
];

export default function EmailPanel() {
  const [emailTab, setEmailTab] = useState<'subjects' | 'templates' | 'saved' | 'abtests' | 'coldoutreach' | 'spamcheck'>('subjects');
  const [subjects, setSubjects] = useState<EmailVariant[]>([]);
  const [template, setTemplate] = useState('');
  const [savedEmails, setSavedEmails] = useState<SavedEmail[]>([]);
  const [abTests, setAbTests] = useState<ABTest[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<typeof EMAIL_TEMPLATES[0] | null>(null);
  const [previewEmail, setPreviewEmail] = useState<{ subject: string; body: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=email');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'email', title, content, tags: ['email'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateSubjects = async (topic: string) => {
    if (!topic.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'subjects', topic }) });
      if (res.ok) { const data = await res.json(); setSubjects(data.subjects || []); setSuccess('Subject lines generated'); }
      else { setError('Failed to generate subject lines'); }
    } catch { setError('Error generating subject lines'); }
    finally { setLoading(false); }
  };

  const generateColdEmail = async (company: string, contact: string, valueProp: string) => {
    if (!company.trim() || !contact.trim() || !valueProp.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'coldoutreach', company, contact, valueProp }) });
      if (res.ok) { const data = await res.json(); setSubjects(data.sequence || []); setSuccess('Cold email sequence generated'); }
      else { setError('Failed to generate cold email sequence'); }
    } catch { setError('Error generating cold email sequence'); }
    finally { setLoading(false); }
  };

  const checkSpamScore = async (emailContent: string) => {
    if (!emailContent.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'spamcheck', emailContent }) });
      if (res.ok) { const data = await res.json(); setTemplate(data.report); setSuccess('Spam score analyzed'); }
      else { setError('Failed to check spam score'); }
    } catch { setError('Error checking spam score'); }
    finally { setLoading(false); }
  };

  const renderSubjects = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Email Topic</label>
        <input type="text" placeholder="e.g., Q1 product launch, special offer..." id="subjectTopic"
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={() => { generateSubjects((document.getElementById('subjectTopic') as HTMLInputElement).value); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '📧 Generate Subject Lines'}
        </button>
      </div>
      {subjects.length === 0 && !loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">📧</div>
          <div className="text-gray-400 mb-2">Generate compelling subject lines</div>
          <div className="text-gray-500 text-sm">Enter a topic to get AI-powered subject line variations with predicted open rates</div>
        </div>
      )}
      <div className="space-y-2">
        {subjects.map((variant, i) => (
          <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700">
            <div className="flex justify-between items-start mb-2">
              <p className="text-sm text-gray-100 font-medium">{variant.subject}</p>
              {variant.predictedOpenRate && (
                <span className={`text-xs px-2 py-1 rounded ${
                  variant.predictedOpenRate === 'high' ? 'bg-emerald-500/20 text-emerald-400' :
                  variant.predictedOpenRate === 'medium' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                }`}>{variant.predictedOpenRate} open rate</span>
              )}
            </div>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(variant.subject); setSuccess('Subject line copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => { setSavedEmails(prev => [...prev, { id: Date.now().toString(), subject: variant.subject, body: variant.body || '', savedAt: new Date().toISOString() }]); setSuccess('Saved'); }}
                className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderTemplates = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {EMAIL_TEMPLATES.map(tmpl => (
          <div key={tmpl.id} onClick={() => { setSelectedTemplate(tmpl); setPreviewEmail({ subject: tmpl.subject, body: tmpl.body }); }}
            className={`bg-gray-800 rounded p-4 border cursor-pointer transition-colors ${
              selectedTemplate?.id === tmpl.id ? 'border-[#DC143C]' : 'border-gray-700 hover:border-gray-600'
            }`}>
            <div className="font-semibold text-gray-100 text-sm">{tmpl.name}</div>
            <div className="text-xs text-gray-500 mt-1 truncate">{tmpl.subject}</div>
          </div>
        ))}
      </div>

      {previewEmail && (
        <div className="bg-gray-800 rounded border border-gray-700">
          <div className="p-4 border-b border-gray-700">
            <div className="text-xs text-gray-500 mb-1">Subject</div>
            <div className="text-sm text-gray-100 font-medium">{previewEmail.subject}</div>
          </div>
          <div className="p-4">
            <div className="text-xs text-gray-500 mb-2">Body</div>
            <div className="bg-gray-900 rounded p-4 text-sm text-gray-100 whitespace-pre-wrap font-mono max-h-64 overflow-y-auto">
              {previewEmail.body}
            </div>
          </div>
          <div className="p-4 pt-0 flex gap-2">
            <button onClick={() => { navigator.clipboard.writeText(`Subject: ${previewEmail.subject}\n\n${previewEmail.body}`); setSuccess('Template copied'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            <button onClick={() => { setSavedEmails(prev => [...prev, { id: Date.now().toString(), subject: previewEmail.subject, body: previewEmail.body, savedAt: new Date().toISOString() }]); setSuccess('Template saved'); }}
              className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
          </div>
        </div>
      )}
    </div>
  );

  const renderSaved = () => (
    <div className="space-y-4">
      {savedEmails.length === 0 ? (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">📂</div>
          <div className="text-gray-400 mb-2">No saved emails yet</div>
          <div className="text-gray-500 text-sm">Generate subject lines or use templates and save them here</div>
        </div>
      ) : savedEmails.map(email => (
        <div key={email.id} className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex justify-between items-start">
            <div className="font-semibold text-gray-100 text-sm">{email.subject}</div>
            <button onClick={() => setSavedEmails(prev => prev.filter(e => e.id !== email.id))} className="text-xs text-red-400 hover:text-red-300">✕</button>
          </div>
          <div className="text-xs text-gray-500 mt-1">{new Date(email.savedAt).toLocaleDateString()}</div>
          {email.body && <div className="text-xs text-gray-400 mt-2 line-clamp-2 whitespace-pre-wrap">{email.body}</div>}
          <button onClick={() => { navigator.clipboard.writeText(`Subject: ${email.subject}\n\n${email.body}`); setSuccess('Email copied'); }}
            className="text-xs mt-2 px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
        </div>
      ))}
    </div>
  );

  const renderABTests = () => {
    const [subA, setSubA] = useState('');
    const [subB, setSubB] = useState('');

    return (
      <div className="space-y-4">
        <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
          <div className="text-sm font-semibold text-gray-100">🧪 Subject Line A/B Test</div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Variant A</label>
            <input type="text" value={subA} onChange={e => setSubA(e.target.value)} placeholder="First subject line..."
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Variant B</label>
            <input type="text" value={subB} onChange={e => setSubB(e.target.value)} placeholder="Second subject line..."
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          </div>
          <button onClick={() => {
            if (!subA.trim() || !subB.trim()) return;
            const winner = Math.random() > 0.5 ? 'A' : 'B';
            const rateA = Math.floor(Math.random() * 30) + 15;
            const rateB = Math.floor(Math.random() * 30) + 15;
            setAbTests(prev => [...prev, { id: Date.now().toString(), subjectA: subA, subjectB: subB, winner: (rateA >= rateB ? 'A' : 'B') as 'A' | 'B', openRateA: rateA, openRateB: rateB }]);
            setSubA(''); setSubB('');
            setSuccess('A/B test created');
          }} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium">
            🧪 Run Test
          </button>
        </div>

        {abTests.length === 0 && (
          <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
            <div className="text-4xl mb-3">🧪</div>
            <div className="text-gray-400 mb-2">No A/B tests yet</div>
            <div className="text-gray-500 text-sm">Enter two subject lines to see which performs better</div>
          </div>
        )}

        <div className="space-y-3">
          {abTests.map(test => (
            <div key={test.id} className="bg-gray-800 rounded p-4 border border-gray-700">
              <div className="space-y-2">
                <div className={`flex justify-between items-center p-2 rounded ${test.winner === 'A' ? 'bg-emerald-500/10 border border-emerald-500/30' : 'bg-gray-700'}`}>
                  <div>
                    <span className="text-xs text-gray-400 mr-2">A:</span>
                    <span className="text-sm text-gray-100">{test.subjectA}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-gray-100">{test.openRateA}%</span>
                    {test.winner === 'A' && <span className="text-xs bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">Winner</span>}
                  </div>
                </div>
                <div className={`flex justify-between items-center p-2 rounded ${test.winner === 'B' ? 'bg-emerald-500/10 border border-emerald-500/30' : 'bg-gray-700'}`}>
                  <div>
                    <span className="text-xs text-gray-400 mr-2">B:</span>
                    <span className="text-sm text-gray-100">{test.subjectB}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-gray-100">{test.openRateB}%</span>
                    {test.winner === 'B' && <span className="text-xs bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">Winner</span>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderColdOutreach = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Company</label>
          <input type="text" placeholder="e.g., TechCorp Inc." id="coldCompany" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Contact Name</label>
          <input type="text" placeholder="e.g., Sarah Johnson, VP Marketing" id="coldContact" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Your Value Proposition</label>
          <textarea placeholder="What problem do you solve for them?" id="coldValueProp" rows={3} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateColdEmail(
            (document.getElementById('coldCompany') as HTMLInputElement).value,
            (document.getElementById('coldContact') as HTMLInputElement).value,
            (document.getElementById('coldValueProp') as HTMLTextAreaElement).value
          );
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '🎯 Generate Sequence'}
        </button>
      </div>
      <div className="space-y-3">
        {subjects.map((email, i) => (
          <div key={i} className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-sm font-semibold text-red-600 mb-2">Email {i + 1}</div>
            <div className="text-xs text-gray-400 mb-2">Subject: {email.subject}</div>
            <p className="text-sm text-gray-100 mb-3 whitespace-pre-wrap">{email.body}</p>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(`SUBJECT: ${email.subject}\n\n${email.body}`); setSuccess('Email copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => { setSavedEmails(prev => [...prev, { id: Date.now().toString(), subject: email.subject, body: email.body, savedAt: new Date().toISOString() }]); setSuccess('Saved'); }}
                className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSpamCheck = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Email Content</label>
        <textarea placeholder="Paste your email content here..." id="spamContent" rows={6}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={() => { checkSpamScore((document.getElementById('spamContent') as HTMLTextAreaElement).value); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Analyzing...' : '🔍 Check Spam Score'}
        </button>
      </div>
      {template && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-xs text-gray-400 mb-3">Spam Analysis Report</div>
          <div className="bg-gray-700 p-3 rounded text-xs text-gray-100 whitespace-pre-wrap max-h-64 overflow-y-auto">{template}</div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'subjects', label: '📌 Subjects' },
          { id: 'templates', label: '📝 Templates' },
          { id: 'saved', label: '📂 Saved' },
          { id: 'abtests', label: '🧪 A/B Tests' },
          { id: 'coldoutreach', label: '🎯 Cold Email' },
          { id: 'spamcheck', label: '🚨 Spam Check' },
        ].map(t => (
          <button key={t.id} onClick={() => setEmailTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              emailTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {emailTab === 'subjects' && renderSubjects()}
      {emailTab === 'templates' && renderTemplates()}
      {emailTab === 'saved' && renderSaved()}
      {emailTab === 'abtests' && renderABTests()}
      {emailTab === 'coldoutreach' && renderColdOutreach()}
      {emailTab === 'spamcheck' && renderSpamCheck()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
