'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface SavedReport {
  id: string;
  template: string;
  content: string;
  savedAt: string;
}

const REPORT_TEMPLATES = [
  { id: 'monthly', name: '📊 Monthly Performance', desc: 'KPIs, channel performance, wins & learnings', fields: [
    { id: 'client', label: 'Client Name', type: 'text' },
    { id: 'month', label: 'Month', type: 'text' },
    { id: 'metrics', label: 'Key Metrics', type: 'textarea' },
  ]},
  { id: 'campaign', name: '📈 Campaign Summary', desc: 'Results, spend, ROAS, next steps', fields: [
    { id: 'campaign', label: 'Campaign Name', type: 'text' },
    { id: 'spend', label: 'Total Spend ($)', type: 'number' },
    { id: 'results', label: 'Results (conversions, leads, etc.)', type: 'textarea' },
  ]},
  { id: 'qbr', name: '📋 Client QBR', desc: 'Quarterly Business Review with stakeholder updates', fields: [
    { id: 'client', label: 'Client Name', type: 'text' },
    { id: 'quarter', label: 'Quarter', type: 'text' },
    { id: 'highlights', label: 'Key Highlights', type: 'textarea' },
  ]},
  { id: 'roi', name: '💰 ROI Report', desc: 'Investment vs. return breakdown', fields: [
    { id: 'investment', label: 'Total Investment ($)', type: 'number' },
    { id: 'revenue', label: 'Revenue Generated ($)', type: 'number' },
    { id: 'details', label: 'Breakdown Details', type: 'textarea' },
  ]},
];

export default function ReportingPanel() {
  const [reportTab, setReportTab] = useState<'templates' | 'generate' | 'saved'>('templates');
  const [report, setReport] = useState('');
  const [savedReports, setSavedReports] = useState<SavedReport[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<typeof REPORT_TEMPLATES[0] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=reporting');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'reporting', title, content, tags: ['reporting'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateReport = async (action: string, params: Record<string, string>) => {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/reporting', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...params }),
      });
      if (res.ok) { const data = await res.json(); setReport(data.report || JSON.stringify(data, null, 2)); setSuccess('Report generated'); }
      else { setError('Failed to generate report'); }
    } catch { setError('Error generating report'); }
    finally { setLoading(false); }
  };

  const renderTemplates = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {REPORT_TEMPLATES.map(tmpl => (
          <div key={tmpl.id} onClick={() => { setSelectedTemplate(tmpl); setReportTab('generate'); }}
            className="bg-gray-800 rounded p-4 border border-gray-700 hover:border-[#DC143C]/50 cursor-pointer transition-colors">
            <div className="text-sm font-semibold text-gray-100">{tmpl.name}</div>
            <div className="text-xs text-gray-500 mt-1">{tmpl.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderGenerate = () => (
    <div className="space-y-4">
      {selectedTemplate ? (
        <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
          <div className="text-sm font-semibold text-gray-100 mb-1">{selectedTemplate.name}</div>
          <div className="text-xs text-gray-500 mb-3">{selectedTemplate.desc}</div>
          {selectedTemplate.fields.map(field => (
            <div key={field.id}>
              <label className="block text-sm font-medium text-gray-300 mb-2">{field.label}</label>
              {field.type === 'textarea' ? (
                <textarea id={`report_${field.id}`} rows={3} placeholder={`Enter ${field.label.toLowerCase()}...`}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
              ) : (
                <input type={field.type} id={`report_${field.id}`} placeholder={`Enter ${field.label.toLowerCase()}...`}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
              )}
            </div>
          ))}
          <button onClick={() => {
            const params: Record<string, string> = {};
            selectedTemplate.fields.forEach(f => { params[f.id] = (document.getElementById(`report_${f.id}`) as HTMLInputElement)?.value || ''; });
            generateReport(selectedTemplate.id, params);
          }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
            {loading ? '⏳ Generating...' : '📊 Generate Report'}
          </button>
        </div>
      ) : (
        <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
          <div className="text-sm font-semibold text-gray-100">Custom Report</div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Client Name</label>
            <input type="text" id="clientName" placeholder="Client company name..."
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Start Date</label>
              <input type="date" id="reportStartDate" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">End Date</label>
              <input type="date" id="reportEndDate" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Metrics</label>
            <input type="text" id="metrics" placeholder="impressions, clicks, conversions, revenue..."
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          </div>
          <button onClick={() => {
            generateReport('clientreport', {
              clientName: (document.getElementById('clientName') as HTMLInputElement).value,
              startDate: (document.getElementById('reportStartDate') as HTMLInputElement).value,
              endDate: (document.getElementById('reportEndDate') as HTMLInputElement).value,
              metrics: (document.getElementById('metrics') as HTMLInputElement).value,
            });
          }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
            {loading ? '⏳ Generating...' : '📊 Generate Report'}
          </button>
        </div>
      )}

      {loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-2xl mb-2 animate-pulse">📊</div>
          <div className="text-gray-400 text-sm">Generating report...</div>
        </div>
      )}

      {report && (
        <div className="bg-gray-800 rounded border border-gray-700">
          <div className="p-4 border-b border-gray-700 flex justify-between items-center">
            <div className="text-sm font-semibold text-gray-100">Generated Report</div>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(report); setSuccess('Report copied to clipboard'); }}
                className="text-xs px-3 py-1.5 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">📤 Export (Copy)</button>
            </div>
          </div>
          <div className="p-4">
            <div className="bg-gray-900 rounded p-4 text-sm text-gray-100 whitespace-pre-wrap max-h-96 overflow-y-auto font-mono">
              {report}
            </div>
          </div>
          <div className="p-4 pt-0 flex gap-2">
            <button onClick={() => {
              setSavedReports(prev => [...prev, { id: Date.now().toString(), template: selectedTemplate?.name || 'Custom', content: report, savedAt: new Date().toISOString() }]);
              setSuccess('Report saved');
            }} className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save Report</button>
          </div>
        </div>
      )}
    </div>
  );

  const renderSaved = () => (
    <div className="space-y-4">
      {savedReports.length === 0 ? (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">📂</div>
          <div className="text-gray-400 mb-2">No saved reports yet</div>
          <div className="text-gray-500 text-sm">Generate reports and save them here for easy access</div>
        </div>
      ) : savedReports.map(r => (
        <div key={r.id} className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm font-semibold text-gray-100">{r.template}</div>
              <div className="text-xs text-gray-500 mt-1">{new Date(r.savedAt).toLocaleDateString()}</div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(r.content); setSuccess('Report copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => setSavedReports(prev => prev.filter(x => x.id !== r.id))} className="text-xs text-red-400 hover:text-red-300">✕</button>
            </div>
          </div>
          <div className="text-xs text-gray-400 mt-2 line-clamp-3 whitespace-pre-wrap">{r.content}</div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'templates', label: '📋 Templates' },
          { id: 'generate', label: '📊 Generate' },
          { id: 'saved', label: '📂 Saved' },
        ].map(t => (
          <button key={t.id} onClick={() => setReportTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              reportTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {reportTab === 'templates' && renderTemplates()}
      {reportTab === 'generate' && renderGenerate()}
      {reportTab === 'saved' && renderSaved()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
