'use client';

interface StatusBadgeProps {
  status: string;
  colorMap?: Record<string, { bg: string; text: string }>;
}

const defaultColorMap: Record<string, { bg: string; text: string }> = {
  // Lead stages
  'Lead': { bg: 'bg-blue-500/20', text: 'text-blue-400' },
  'MQL': { bg: 'bg-yellow-500/20', text: 'text-yellow-400' },
  'SQL': { bg: 'bg-orange-500/20', text: 'text-orange-400' },
  'Opportunity': { bg: 'bg-purple-500/20', text: 'text-purple-400' },
  'Closed Won': { bg: 'bg-emerald-500/20', text: 'text-emerald-400' },
  'Closed Lost': { bg: 'bg-red-500/20', text: 'text-red-400' },
  // Campaign status
  'draft': { bg: 'bg-gray-600/20', text: 'text-gray-400' },
  'active': { bg: 'bg-emerald-500/20', text: 'text-emerald-400' },
  'paused': { bg: 'bg-yellow-500/20', text: 'text-yellow-400' },
  'completed': { bg: 'bg-blue-500/20', text: 'text-blue-400' },
  // Content status
  'published': { bg: 'bg-emerald-500/20', text: 'text-emerald-400' },
  'approved': { bg: 'bg-blue-500/20', text: 'text-blue-400' },
  'review': { bg: 'bg-yellow-500/20', text: 'text-yellow-400' },
  // Threat levels
  'high': { bg: 'bg-red-500/20', text: 'text-red-400' },
  'medium': { bg: 'bg-yellow-500/20', text: 'text-yellow-400' },
  'low': { bg: 'bg-emerald-500/20', text: 'text-emerald-400' },
};

export default function StatusBadge({ status, colorMap }: StatusBadgeProps) {
  const colors = colorMap?.[status] || defaultColorMap[status] || { bg: 'bg-gray-700', text: 'text-gray-400' };
  
  return (
    <span className={`text-xs font-medium px-2 py-1 rounded ${colors.bg} ${colors.text}`}>
      {status}
    </span>
  );
}
