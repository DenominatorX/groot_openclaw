'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface AutomationFlow {
  id: string;
  name: string;
  trigger: string;
  status: 'active' | 'paused' | 'draft';
  stepsCount: number;
  leadsEnrolled: number;
  steps: Array<{ type: 'condition' | 'action' | 'wait'; description: string }>;
}

interface AutomationTemplate {
  name: string;
  desc: string;
  trigger: string;
  steps: string[];
}

const TEMPLATES: AutomationTemplate[] = [
  { name: 'Lead Nurture', desc: 'Nurture new leads through the funnel', trigger: 'Lead Score > 30',
    steps: ['Send educational content email', 'Wait 3 days', 'If opened → Send case study', 'If not opened → Send alternative subject', 'Wait 5 days', 'Send demo request', 'Notify sales if clicked'] },
  { name: 'Onboarding Sequence', desc: 'Welcome and activate new customers', trigger: 'Customer Created',
    steps: ['Send welcome email with setup guide', 'Wait 1 day', 'Send feature highlight #1', 'Wait 2 days', 'Send feature highlight #2', 'Wait 3 days', 'Send feedback survey', 'If completed setup → send advanced tips'] },
  { name: 'Re-engagement', desc: 'Win back inactive leads', trigger: 'No Activity for 30 Days',
    steps: ['Send "We miss you" email', 'Wait 5 days', 'If opened → Send special offer', 'If not opened → Send different angle', 'Wait 7 days', 'Final attempt with urgency', 'If no response → mark as cold'] },
  { name: 'Event Follow-up', desc: 'Follow up with event attendees', trigger: 'Event Attended',
    steps: ['Send thank you email with recording', 'Wait 1 day', 'Send additional resources', 'Wait 3 days', 'Send meeting request', 'If no response → add to nurture track'] },
];

const SEED_AUTOMATIONS: AutomationFlow[] = [
  { id: '1', name: 'New Lead Welcome', trigger: 'Form Submission', status: 'active', stepsCount: 5, leadsEnrolled: 234, steps: [
    { type: 'action', description: 'Send welcome email' }, { type: 'wait', description: 'Wait 2 days' },
    { type: 'condition', description: 'If score > 50' }, { type: 'action', description: 'Send case study' },
    { type: 'action', description: 'Notify SDR' },
  ]},
  { id: '2', name: 'MQL Acceleration', trigger: 'Score > 60', status: 'active', stepsCount: 4, leadsEnrolled: 87, steps: [
    { type: 'action', description: 'Send product comparison guide' }, { type: 'wait', description: 'Wait 1 day' },
    { type: 'action', description: 'Book demo CTA email' }, { type: 'action', description: 'Alert sales team' },
  ]},
  { id: '3', name: 'Stale Lead Re-engagement', trigger: 'No activity 21 days', status: 'paused', stepsCount: 6, leadsEnrolled: 156, steps: [
    { type: 'action', description: 'Send re-engagement email' }, { type: 'wait', description: 'Wait 5 days' },
    { type: 'condition', description: 'If opened email' }, { type: 'action', description: 'Send offer' },
    { type: 'wait', description: 'Wait 7 days' }, { type: 'action', description: 'Mark as cold' },
  ]},
];

export default function AutomationPanel() {
  const [automationTab, setAutomationTab] = useState<'active' | 'templates' | 'builder'>('active');
  const [automations, setAutomations] = useState<AutomationFlow[]>(SEED_AUTOMATIONS);
  const [selectedFlow, setSelectedFlow] = useState<AutomationFlow | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=automation');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'automation', title, content, tags: ['automation'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const renderActive = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="text-sm font-semibold text-gray-100">🤖 Active Automations</div>
        <button onClick={() => setAutomationTab('builder')}
          className="text-xs px-3 py-1.5 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">+ New Flow</button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gray-800 rounded p-3 border border-gray-700">
          <div className="text-xs text-gray-500">Active</div>
          <div className="text-2xl font-bold text-emerald-400">{automations.filter(a => a.status === 'active').length}</div>
        </div>
        <div className="bg-gray-800 rounded p-3 border border-gray-700">
          <div className="text-xs text-gray-500">Paused</div>
          <div className="text-2xl font-bold text-yellow-400">{automations.filter(a => a.status === 'paused').length}</div>
        </div>
        <div className="bg-gray-800 rounded p-3 border border-gray-700">
          <div className="text-xs text-gray-500">Total Enrolled</div>
          <div className="text-2xl font-bold text-gray-100">{automations.reduce((s, a) => s + a.leadsEnrolled, 0)}</div>
        </div>
      </div>

      {/* Automation List */}
      <div className="space-y-3">
        {automations.map(auto => (
          <div key={auto.id} onClick={() => setSelectedFlow(auto)}
            className={`bg-gray-800 rounded p-4 border cursor-pointer transition-colors ${
              selectedFlow?.id === auto.id ? 'border-[#DC143C]' : 'border-gray-700 hover:border-gray-600'
            }`}>
            <div className="flex justify-between items-start">
              <div>
                <div className="text-sm font-semibold text-gray-100">{auto.name}</div>
                <div className="text-xs text-gray-500 mt-1">Trigger: {auto.trigger}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-0.5 rounded font-medium ${
                  auto.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' :
                  auto.status === 'paused' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-700 text-gray-400'
                }`}>{auto.status === 'active' ? '🟢' : auto.status === 'paused' ? '🟡' : '⚪'} {auto.status}</span>
              </div>
            </div>
            <div className="flex gap-4 mt-2 text-xs text-gray-400">
              <span>{auto.stepsCount} steps</span>
              <span>{auto.leadsEnrolled} leads enrolled</span>
            </div>
          </div>
        ))}
      </div>

      {/* Flow Detail */}
      {selectedFlow && (
        <div className="bg-gray-800 rounded p-4 border border-[#DC143C]/30">
          <div className="flex justify-between items-center mb-4">
            <div className="text-sm font-semibold text-gray-100">{selectedFlow.name}</div>
            <div className="flex gap-2">
              {selectedFlow.status === 'active' ? (
                <button onClick={() => {
                  setAutomations(prev => prev.map(a => a.id === selectedFlow.id ? { ...a, status: 'paused' as const } : a));
                  setSelectedFlow({ ...selectedFlow, status: 'paused' });
                  setSuccess('Automation paused');
                }} className="text-xs px-2 py-1 bg-yellow-500/20 text-yellow-400 rounded hover:bg-yellow-500/30">⏸ Pause</button>
              ) : (
                <button onClick={() => {
                  setAutomations(prev => prev.map(a => a.id === selectedFlow.id ? { ...a, status: 'active' as const } : a));
                  setSelectedFlow({ ...selectedFlow, status: 'active' });
                  setSuccess('Automation activated');
                }} className="text-xs px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded hover:bg-emerald-500/30">▶ Activate</button>
              )}
            </div>
          </div>

          <div className="text-xs text-gray-500 mb-3">🔔 Trigger: {selectedFlow.trigger}</div>

          <div className="space-y-2 border-l-2 border-gray-600 pl-4">
            {selectedFlow.steps.map((step, i) => (
              <div key={i} className="relative">
                <div className={`absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full border-2 border-gray-800 ${
                  step.type === 'action' ? 'bg-emerald-500' : step.type === 'condition' ? 'bg-blue-500' : 'bg-yellow-500'
                }`} />
                <div className={`text-xs p-2 rounded ${
                  step.type === 'action' ? 'bg-emerald-500/10 text-emerald-400' :
                  step.type === 'condition' ? 'bg-blue-500/10 text-blue-400' : 'bg-yellow-500/10 text-yellow-400'
                }`}>
                  {step.type === 'condition' ? '❓' : step.type === 'action' ? '→' : '⏳'} {step.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderTemplates = () => (
    <div className="space-y-4">
      <div className="text-sm font-semibold text-gray-100">📋 Automation Templates</div>
      {TEMPLATES.map((tmpl, i) => (
        <div key={i} className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex justify-between items-start mb-2">
            <div>
              <div className="text-sm font-semibold text-gray-100">{tmpl.name}</div>
              <div className="text-xs text-gray-500 mt-1">{tmpl.desc}</div>
              <div className="text-xs text-gray-400 mt-1">🔔 Trigger: {tmpl.trigger}</div>
            </div>
          </div>
          <div className="space-y-1 mt-3 border-l-2 border-gray-600 pl-3">
            {tmpl.steps.map((step, j) => (
              <div key={j} className="text-xs text-gray-300 relative">
                <span className="absolute -left-[11px] top-1 w-1.5 h-1.5 rounded-full bg-gray-500" />
                {step}
              </div>
            ))}
          </div>
          <button onClick={() => {
            const newFlow: AutomationFlow = {
              id: Date.now().toString(), name: tmpl.name, trigger: tmpl.trigger, status: 'draft',
              stepsCount: tmpl.steps.length, leadsEnrolled: 0,
              steps: tmpl.steps.map(s => ({
                type: s.toLowerCase().startsWith('if') ? 'condition' as const : s.toLowerCase().startsWith('wait') ? 'wait' as const : 'action' as const,
                description: s,
              })),
            };
            setAutomations(prev => [...prev, newFlow]);
            setSuccess(`${tmpl.name} template added`);
            setAutomationTab('active');
          }} className="mt-3 text-xs px-3 py-1.5 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium">
            Use Template
          </button>
        </div>
      ))}
    </div>
  );

  const renderBuilder = () => {
    const [flowName, setFlowName] = useState('');
    const [trigger, setTrigger] = useState('Form Submission');
    const [steps, setSteps] = useState<Array<{ type: 'condition' | 'action' | 'wait'; description: string }>>([]);

    return (
      <div className="space-y-4">
        <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
          <div className="text-sm font-semibold text-gray-100">🔧 Build New Automation</div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Flow Name</label>
            <input type="text" value={flowName} onChange={e => setFlowName(e.target.value)} placeholder="e.g., New Lead Welcome"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Trigger</label>
            <select value={trigger} onChange={e => setTrigger(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 text-sm">
              {['Form Submission', 'Score Threshold', 'Page Visit', 'Email Open', 'Tag Added', 'Date/Time', 'Manual'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>

        {/* Steps */}
        {steps.length > 0 && (
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-xs font-semibold text-gray-400 uppercase mb-3">Flow Steps</div>
            <div className="space-y-2 border-l-2 border-gray-600 pl-4">
              {steps.map((step, i) => (
                <div key={i} className="relative flex items-center gap-2">
                  <div className={`absolute -left-[21px] top-2 w-2.5 h-2.5 rounded-full border-2 border-gray-800 ${
                    step.type === 'action' ? 'bg-emerald-500' : step.type === 'condition' ? 'bg-blue-500' : 'bg-yellow-500'
                  }`} />
                  <div className={`flex-1 text-xs p-2 rounded ${
                    step.type === 'action' ? 'bg-emerald-500/10 text-emerald-400' :
                    step.type === 'condition' ? 'bg-blue-500/10 text-blue-400' : 'bg-yellow-500/10 text-yellow-400'
                  }`}>{step.description}</div>
                  <button onClick={() => setSteps(prev => prev.filter((_, j) => j !== i))} className="text-xs text-red-400 hover:text-red-300">✕</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Add Step Buttons */}
        <div className="grid grid-cols-3 gap-2">
          <button onClick={() => setSteps(prev => [...prev, { type: 'action', description: 'Send email' }])}
            className="px-3 py-2 bg-emerald-500/10 text-emerald-400 rounded text-xs hover:bg-emerald-500/20">+ Action</button>
          <button onClick={() => setSteps(prev => [...prev, { type: 'condition', description: 'If condition met' }])}
            className="px-3 py-2 bg-blue-500/10 text-blue-400 rounded text-xs hover:bg-blue-500/20">+ Condition</button>
          <button onClick={() => setSteps(prev => [...prev, { type: 'wait', description: 'Wait 3 days' }])}
            className="px-3 py-2 bg-yellow-500/10 text-yellow-400 rounded text-xs hover:bg-yellow-500/20">+ Wait</button>
        </div>

        <button onClick={() => {
          if (!flowName.trim()) return;
          setAutomations(prev => [...prev, {
            id: Date.now().toString(), name: flowName, trigger, status: 'draft',
            stepsCount: steps.length, leadsEnrolled: 0, steps,
          }]);
          setFlowName(''); setSteps([]);
          setSuccess('Automation created');
          setAutomationTab('active');
        }} className="w-full px-4 py-2 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">
          💾 Save Automation
        </button>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'active', label: '🤖 Active' },
          { id: 'templates', label: '📋 Templates' },
          { id: 'builder', label: '🔧 Builder' },
        ].map(t => (
          <button key={t.id} onClick={() => setAutomationTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              automationTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {automationTab === 'active' && renderActive()}
      {automationTab === 'templates' && renderTemplates()}
      {automationTab === 'builder' && renderBuilder()}
    </div>
  );
}
