'use client';

interface KPICardProps {
  title: string;
  value: string | number;
  change?: number;
  changeType?: 'up' | 'down' | 'neutral';
  icon?: string;
}

export default function KPICard({ title, value, change, changeType = 'neutral', icon }: KPICardProps) {
  const changeColors = {
    up: 'text-emerald-400',
    down: 'text-red-400',
    neutral: 'text-gray-400',
  };

  const changeIcons = {
    up: '↑',
    down: '↓',
    neutral: '→',
  };

  return (
    <div className="bg-gray-800 rounded p-4 border border-gray-700">
      <div className="text-sm text-gray-400">{title}</div>
      <div className="flex items-end justify-between mt-1">
        <div className="text-2xl font-bold text-white">
          {icon && <span className="mr-2">{icon}</span>}
          {typeof value === 'number' ? value.toLocaleString() : value}
        </div>
        {change !== undefined && (
          <div className={`text-sm font-medium ${changeColors[changeType]}`}>
            {changeIcons[changeType]} {Math.abs(change).toLocaleString()}%
          </div>
        )}
      </div>
    </div>
  );
}
