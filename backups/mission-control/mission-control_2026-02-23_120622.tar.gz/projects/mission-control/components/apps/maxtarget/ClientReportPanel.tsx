'use client';

import { SavedOutputs } from './shared';
import { useState, useEffect, useCallback } from 'react';
import KPICard from './shared/KPICard';
import BarChart from './shared/BarChart';

interface DailyMetric {
  date: string;
  impressions: number;
  clicks: number;
  conversions: number;
  spent: number;
}

interface Campaign {
  id: string;
  name: string;
  status: string;
  budget: number;
  spent: number;
  impressions: number;
  clicks: number;
  conversions: number;
  ctr: number;
  cpa: number;
  roas: number;
  targetROAS: number;
}

interface ExecutiveSummary {
  totalSpend: number;
  totalConversions: number;
  avgCPA: number;
  overallROAS: number;
}

interface PipelineSummary {
  newLeads: number;
  qualified: number;
  proposalsSent: number;
  dealsClosed: number;
  stageCounts: Record<string, number>;
  pipelineValue: number;
}

interface Competitor {
  name: string;
  threatLevel: string;
  category: string;
  strengths: string[];
  weaknesses: string[];
}

interface ReportData {
  reportDate: string;
  period: { startDate: string; endDate: string };
  executiveSummary: ExecutiveSummary;
  campaignPerformance: Campaign[];
  pipeline: PipelineSummary;
  competitors: Competitor[];
  recommendations: string[];
}

interface SavedReportData {
  id: string;
  clientName: string;
  reportTitle: string;
  startDate: string;
  endDate: string;
  reportData: ReportData;
  savedAt: string;
}

const STAGES = ['Lead', 'MQL', 'SQL', 'Opportunity', 'Closed Won'];

export default function ClientReportPanel() {
  // Report configuration
  const [clientName, setClientName] = useState('SpecTarget');
  const [reportTitle, setReportTitle] = useState('Marketing Performance Report');
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState('2026-02-16');
  const [generatedDate] = useState(new Date().toLocaleDateString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric'
  }));
  const [preparedBy] = useState('SpecTarget Marketing Team');
  
  // Report data
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [savedReports, setSavedReports] = useState<SavedReportData[]>([]);
  const [showSaved, setShowSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Previous period data for comparison (for executive summary)
  const [previousPeriodData, setPreviousPeriodData] = useState<{ conversions: number; cpa: number; spend: number } | null>(null);
  
  // Load saved reports on mount
  useEffect(() => {
    fetchSavedReports();
  }, []);
  
  const fetchSavedReports = async () => {
    try {
      const res = await fetch('/api/apps/maxtarget/reports?saved=true');
      if (res.ok) {
        const data = await res.json();
        setSavedReports(data.reports || []);
      } else {
        throw new Error('Failed to fetch');
      }
    } catch (e) {
      console.error('Failed to load saved reports:', e);
      setError('Failed to load saved reports — check network.');
    }
  };
  
  const generateReport = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/apps/maxtarget/reports?startDate=${startDate}&endDate=${endDate}`);
      if (res.ok) {
        const data = await res.json();
        setReportData(data);
        
        // Calculate mock previous period data for comparison
        // In production, this would come from the API
        if (data.executiveSummary) {
          setPreviousPeriodData({
            conversions: Math.round(data.executiveSummary.totalConversions * 0.85),
            cpa: data.executiveSummary.avgCPA * 1.15,
            spend: Math.round(data.executiveSummary.totalSpend * 0.9)
          });
        }
      } else {
        throw new Error('Failed to fetch');
      }
    } catch (e) {
      console.error('Failed to generate report:', e);
      setError('Failed to load data — check network.');
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate]);
  
  const saveReport = async () => {
    if (!reportData) return;
    try {
      const res = await fetch('/api/apps/maxtarget/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName,
          reportTitle,
          startDate,
          endDate,
          reportData,
        }),
      });
      if (res.ok) {
        await fetchSavedReports();
        alert('Report saved successfully!');
      } else {
        throw new Error('Failed to save');
      }
    } catch (e) {
      console.error('Failed to save report:', e);
      setError('Failed to save report — check network.');
    }
  };
  
  const loadSavedReport = (saved: { reportData: ReportData; clientName: string; reportTitle: string; startDate: string; endDate: string }) => {
    setClientName(saved.clientName);
    setReportTitle(saved.reportTitle);
    setStartDate(saved.startDate);
    setEndDate(saved.endDate);
    setReportData(saved.reportData);
    setShowSaved(false);
  };
  
  const handlePrint = () => {
    window.print();
  };
  
  // Get ROAS color class for campaign row
  const getROASColor = (roas: number): string => {
    if (roas >= 3) return 'text-emerald-400 print:text-emerald-700';
    if (roas >= 1) return 'text-yellow-400 print:text-yellow-700';
    return 'text-red-400 print:text-red-700';
  };
  
  // Get ROAS background class for campaign row
  const getROASRowColor = (roas: number): string => {
    if (roas >= 3) return 'bg-emerald-500/10 border-l-emerald-500';
    if (roas >= 1) return 'bg-yellow-500/10 border-l-yellow-500';
    return 'bg-red-500/10 border-l-red-500';
  };
  
  // Generate executive summary paragraph
  const generateExecutiveSummaryText = (): string => {
    if (!reportData?.executiveSummary || !previousPeriodData) {
      return `In this period, ${clientName} generated ${reportData?.executiveSummary.totalConversions || 0} conversions at an average CPA of $${reportData?.executiveSummary.avgCPA.toFixed(2) || '0.00'}.`;
    }
    
    const { totalSpend, totalConversions, avgCPA, overallROAS } = reportData.executiveSummary;
    const { conversions: prevConversions, cpa: prevCPA } = previousPeriodData;
    
    const conversionChange = ((totalConversions - prevConversions) / prevConversions) * 100;
    const cpaChange = ((avgCPA - prevCPA) / prevCPA) * 100;
    
    let summary = `In this period, ${clientName} ran ${reportData.campaignPerformance?.length || 0} campaigns, generating ${totalConversions} conversions at $${avgCPA.toFixed(2)} CPA.`;
    
    if (conversionChange !== 0 || cpaChange !== 0) {
      summary += ` This represents a ${Math.abs(conversionChange).toFixed(0)}% ${conversionChange >= 0 ? 'increase' : 'decrease'} in conversions`;
      
      if (cpaChange !== 0) {
        summary += ` and a ${Math.abs(cpaChange).toFixed(0)}% ${cpaChange <= 0 ? 'improvement' : 'increase'} in CPA`;
      }
      
      summary += ` over the previous period.`;
    } else {
      summary += ' Performance remained stable compared to the previous period.';
    }
    
    if (overallROAS >= 3) {
      summary += ` The overall ROAS of ${overallROAS.toFixed(1)}x indicates highly effective advertising.`;
    } else if (overallROAS >= 1) {
      summary += ` The overall ROAS of ${overallROAS.toFixed(1)}x shows positive return on ad spend.`;
    }
    
    return summary;
  };
  
  // Get threat level badge color
  const getThreatBadgeColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-red-500/20 text-red-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'low': return 'bg-emerald-500/20 text-emerald-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            background: white !important;
            color: black !important;
            font-family: Georgia, 'Times New Roman', serif !important;
            font-size: 11pt !important;
            line-height: 1.4 !important;
          }
          .print\\:hidden {
            display: none !important;
          }
          .print\\:bg-white {
            background: white !important;
          }
          .print\\:text-black {
            color: black !important;
          }
          .print\\:border-gray-300 {
            border-color: #d1d5db !important;
          }
          .print\\:break-before-page {
            break-before: page;
          }
          .print\\:break-after-page {
            break-after: page;
          }
          .no-print-nav {
            display: none !important;
          }
          .report-container {
            padding: 0.5in !important;
            background: white !important;
          }
          .report-section {
            margin-bottom: 0.5in !important;
          }
          table {
            font-size: 9pt !important;
          }
          h1 {
            font-size: 18pt !important;
          }
          h2 {
            font-size: 14pt !important;
            border-bottom: 1px solid #d1d5db !important;
            padding-bottom: 4px !important;
          }
          .kpi-card {
            border: 1px solid #e5e7eb !important;
            padding: 8px !important;
          }
        }
      `}</style>
      
      {/* Controls - Hidden on print */}
      <div className="print:hidden bg-gray-800 rounded-lg p-4 border border-gray-700">
        <div className="flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm text-gray-400 mb-1">Client Name</label>
            <input
              type="text"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none"
            />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm text-gray-400 mb-1">Report Title</label>
            <input
              type="text"
              value={reportTitle}
              onChange={(e) => setReportTitle(e.target.value)}
              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={generateReport}
              disabled={loading}
              className="px-4 py-2 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium disabled:opacity-50"
            >
              {loading ? '⏳ Generating...' : '📊 Generate'}
            </button>
            <button
              onClick={handlePrint}
              disabled={!reportData}
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded font-medium disabled:opacity-50"
            >
              🖨️ Print
            </button>
            <button
              onClick={saveReport}
              disabled={!reportData}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-medium disabled:opacity-50"
            >
              💾 Save
            </button>
            <button
              onClick={() => setShowSaved(!showSaved)}
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded font-medium"
            >
              📂 {showSaved ? 'Hide' : 'Load'} Saved
            </button>
          </div>
        </div>
        
        {/* Saved Reports Panel */}
        {showSaved && (
          <div className="mt-4 pt-4 border-t border-gray-700">
            <div className="text-sm font-medium text-gray-300 mb-2">Saved Reports</div>
            {savedReports.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved reports yet</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {savedReports.map((saved) => (
                  <button
                    key={saved.id}
                    onClick={() => loadSavedReport(saved)}
                    className="text-left bg-gray-900 rounded p-3 border border-gray-600 hover:border-[#DC143C] transition-colors"
                  >
                    <div className="text-sm font-medium text-white">{saved.clientName}</div>
                    <div className="text-xs text-gray-400">{saved.reportTitle}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {saved.startDate} - {saved.endDate}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      
      {error && (
        <div className="print:hidden bg-gray-800 rounded-lg p-4 border border-red-500 text-red-400 text-center">
          {error}
        </div>
      )}
      
      {/* Report Preview / Print View */}
      {reportData ? (
        <div className="report-container bg-gray-800 rounded-lg border border-gray-700 print:bg-white print:border-gray-300">
          {/* Report Header */}
          <div className="p-6 border-b border-gray-700 print:border-gray-300">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-4">
                {/* SpecTarget Logo Placeholder */}
                <div className="w-16 h-16 bg-gradient-to-br from-[#DC143C] to-[#8B0000] rounded-lg flex items-center justify-center print:bg-gray-100">
                  <span className="text-white font-bold text-xs tracking-wider print:text-black">SPECTARGET</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white print:text-black">{reportTitle}</h1>
                  <p className="text-gray-400 print:text-gray-600 mt-1">Prepared for: {clientName}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-400 print:text-gray-600">Generated: {generatedDate}</p>
                <p className="text-sm text-gray-400 print:text-gray-600">
                  Period: {reportData.period.startDate} to {reportData.period.endDate}
                </p>
              </div>
            </div>
          </div>
          
          {/* Section A - Executive Summary */}
          <div className="p-6 border-b border-gray-700 print:border-gray-300 print:break-before-page report-section">
            <h2 className="text-lg font-semibold text-white print:text-black mb-4">A. Executive Summary</h2>
            
            {/* Executive Summary Paragraph */}
            <div className="mb-6 bg-gray-900/50 print:bg-gray-50 rounded-lg p-4 border border-gray-700 print:border-gray-200">
              <p className="text-gray-300 print:text-gray-700 leading-relaxed">
                {generateExecutiveSummaryText()}
              </p>
            </div>
            
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50 kpi-card">
                <div className="text-sm text-gray-400 print:text-gray-600">Total Spend</div>
                <div className="text-2xl font-bold text-white print:text-black">
                  ${reportData.executiveSummary.totalSpend.toLocaleString()}
                </div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50 kpi-card">
                <div className="text-sm text-gray-400 print:text-gray-600">Total Conversions</div>
                <div className="text-2xl font-bold text-emerald-400 print:text-emerald-700">
                  {reportData.executiveSummary.totalConversions}
                </div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50 kpi-card">
                <div className="text-sm text-gray-400 print:text-gray-600">Avg CPA</div>
                <div className="text-2xl font-bold text-white print:text-black">
                  ${reportData.executiveSummary.avgCPA.toFixed(2)}
                </div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50 kpi-card">
                <div className="text-sm text-gray-400 print:text-gray-600">Overall ROAS</div>
                <div className={`text-2xl font-bold ${
                  reportData.executiveSummary.overallROAS >= 3
                    ? 'text-emerald-400 print:text-emerald-700'
                    : reportData.executiveSummary.overallROAS >= 1
                    ? 'text-yellow-400 print:text-yellow-700'
                    : 'text-red-400 print:text-red-700'
                }`}>
                  {reportData.executiveSummary.overallROAS.toFixed(1)}x
                </div>
              </div>
            </div>
          </div>
          
          {/* Section B - Campaign Performance */}
          <div className="p-6 border-b border-gray-700 print:border-gray-300 print:break-before-page report-section">
            <h2 className="text-lg font-semibold text-white print:text-black mb-4">B. Campaign Performance</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700 print:border-gray-300">
                    <th className="text-left py-2 text-gray-400 print:text-gray-600">Campaign</th>
                    <th className="text-left py-2 text-gray-400 print:text-gray-600">Status</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">Budget</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">Spent</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">Impr.</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">Clicks</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">Conv.</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">CTR</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">CPA</th>
                    <th className="text-right py-2 text-gray-400 print:text-gray-600">ROAS</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.campaignPerformance.map((campaign) => (
                    <tr
                      key={campaign.id}
                      className={`border-b border-gray-700/50 print:border-gray-200 ${getROASRowColor(campaign.roas)}`}
                    >
                      <td className="py-2 text-white print:text-black font-medium">{campaign.name}</td>
                      <td className="py-2">
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          campaign.status === 'active'
                            ? 'bg-emerald-500/20 text-emerald-400 print:bg-emerald-100 print:text-emerald-800'
                            : campaign.status === 'paused'
                            ? 'bg-yellow-500/20 text-yellow-400 print:bg-yellow-100 print:text-yellow-800'
                            : campaign.status === 'completed'
                            ? 'bg-blue-500/20 text-blue-400 print:bg-blue-100 print:text-blue-800'
                            : 'bg-gray-500/20 text-gray-400 print:bg-gray-100 print:text-gray-800'
                        }`}>
                          {campaign.status}
                        </span>
                      </td>
                      <td className="py-2 text-right text-gray-300 print:text-gray-700">${campaign.budget.toLocaleString()}</td>
                      <td className="py-2 text-right text-gray-300 print:text-gray-700">${campaign.spent.toLocaleString()}</td>
                      <td className="py-2 text-right text-gray-300 print:text-gray-700">{campaign.impressions.toLocaleString()}</td>
                      <td className="py-2 text-right text-gray-300 print:text-gray-700">{campaign.clicks.toLocaleString()}</td>
                      <td className="py-2 text-right text-emerald-400 print:text-emerald-700">{campaign.conversions}</td>
                      <td className="py-2 text-right text-gray-300 print:text-gray-700">{campaign.ctr.toFixed(1)}%</td>
                      <td className="py-2 text-right text-gray-300 print:text-gray-700">${campaign.cpa.toFixed(2)}</td>
                      <td className={`py-2 text-right font-bold ${getROASColor(campaign.roas)}`}>
                        {campaign.roas.toFixed(1)}x
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 flex gap-4 text-xs text-gray-500 print:text-gray-600">
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-emerald-500/20 rounded"></span> Green: ROAS ≥ 3x (Excellent)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-yellow-500/20 rounded"></span> Yellow: ROAS 1-3x (Good)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-red-500/20 rounded"></span> Red: ROAS &lt; 1x (Underperforming)
              </span>
            </div>
          </div>
          
          {/* Section C - Pipeline Summary */}
          <div className="p-6 border-b border-gray-700 print:border-gray-300 print:break-before-page report-section">
            <h2 className="text-lg font-semibold text-white print:text-black mb-4">C. Pipeline Summary</h2>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50">
                <div className="text-sm text-gray-400 print:text-gray-600">New Leads</div>
                <div className="text-2xl font-bold text-blue-400 print:text-blue-700">{reportData.pipeline.newLeads}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50">
                <div className="text-sm text-gray-400 print:text-gray-600">Qualified (SQL)</div>
                <div className="text-2xl font-bold text-orange-400 print:text-orange-700">{reportData.pipeline.qualified}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50">
                <div className="text-sm text-gray-400 print:text-gray-600">Proposals Sent</div>
                <div className="text-2xl font-bold text-purple-400 print:text-purple-700">{reportData.pipeline.proposalsSent}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50">
                <div className="text-sm text-gray-400 print:text-gray-600">Deals Closed</div>
                <div className="text-2xl font-bold text-emerald-400 print:text-emerald-700">{reportData.pipeline.dealsClosed}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 print:bg-gray-50">
                <div className="text-sm text-gray-400 print:text-gray-600">Pipeline Value</div>
                <div className="text-2xl font-bold text-white print:text-black">${reportData.pipeline.pipelineValue.toLocaleString()}</div>
              </div>
            </div>
            
            {/* Pipeline Bar Chart */}
            <div className="h-48">
              <BarChart
                data={STAGES.map((stage, i) => ({
                  label: stage,
                  value: reportData.pipeline.stageCounts[stage] || 0,
                  color: ['bg-blue-500', 'bg-yellow-500', 'bg-orange-500', 'bg-purple-500', 'bg-emerald-500'][i],
                }))}
              />
            </div>
          </div>
          
          {/* Section D - Competitive Landscape */}
          <div className="p-6 border-b border-gray-700 print:border-gray-300 print:break-before-page report-section">
            <h2 className="text-lg font-semibold text-white print:text-black mb-4">D. Competitive Landscape</h2>
            <div className="space-y-4">
              {reportData.competitors.map((competitor, index) => (
                <div key={index} className="bg-gray-900 rounded-lg p-4 print:bg-gray-50 print:border print:border-gray-200">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold text-white print:text-black">{competitor.name}</h3>
                      <div className="text-xs text-gray-500 print:text-gray-600">{competitor.category}</div>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded ${getThreatBadgeColor(competitor.threatLevel)} print:bg-gray-100`}>
                      {competitor.threatLevel.toUpperCase()} THREAT
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-3">
                    <div>
                      <div className="text-xs text-gray-500 print:text-gray-600 mb-1">Strengths</div>
                      <ul className="text-xs space-y-1">
                        {competitor.strengths.slice(0, 3).map((strength, i) => (
                          <li key={i} className="text-emerald-400 print:text-emerald-700">✓ {strength}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 print:text-gray-600 mb-1">Weaknesses</div>
                      <ul className="text-xs space-y-1">
                        {competitor.weaknesses.slice(0, 2).map((weakness, i) => (
                          <li key={i} className="text-red-400 print:text-red-700">✗ {weakness}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Section E - Recommendations */}
          <div className="p-6 print:break-before-page report-section">
            <h2 className="text-lg font-semibold text-white print:text-black mb-4">E. Recommendations</h2>
            <div className="space-y-2">
              {reportData.recommendations.map((rec, index) => (
                <div key={index} className="bg-gray-900 rounded-lg p-4 print:bg-gray-50 print:border print:border-gray-200">
                  <p className="text-gray-300 print:text-gray-700">{rec}</p>
                </div>
              ))}
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-6 py-4 border-t border-gray-700 print:border-gray-300 bg-gray-900/30 print:bg-gray-50">
            <div className="flex justify-between items-center text-sm text-gray-500 print:text-gray-600">
              <span>Prepared by: {preparedBy}</span>
              <span>Report generated: {generatedDate}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-gray-800 rounded-lg p-12 border border-gray-700 text-center">
          <div className="text-5xl mb-4">📄</div>
          <h3 className="text-xl font-semibold text-white mb-2">No Report Generated</h3>
          <p className="text-gray-400 mb-4">
            Configure your report settings above and click "Generate" to create a client report.
          </p>
          <button
            onClick={generateReport}
            disabled={loading}
            className="px-6 py-3 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded-lg font-medium disabled:opacity-50"
          >
            {loading ? '⏳ Generating...' : '📊 Generate Sample Report'}
          </button>
        </div>
      )}
      <SavedOutputs panel="clientreport" />
    </div>
  );
}