'use client';

interface ProgressBarProps {
  value: number;
  max?: number;
  color?: string;
  label?: string;
  showPercent?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showValue?: boolean;
}

export default function ProgressBar({
  value,
  max = 100,
  color = 'bg-[#DC143C]',
  label,
  showPercent = true,
  size = 'md',
  showValue = false,
}: ProgressBarProps) {
  const percentage = Math.min((value / max) * 100, 100);
  
  const heightClasses = {
    sm: 'h-1.5',
    md: 'h-2',
    lg: 'h-3',
  };

  // Auto-color based on percentage
  const getColor = () => {
    if (color !== 'bg-[#DC143C]') return color;
    if (percentage > 90) return 'bg-red-500';
    if (percentage > 70) return 'bg-yellow-500';
    return 'bg-emerald-500';
  };

  return (
    <div className="w-full">
      {(label || showValue) && (
        <div className="flex justify-between text-xs text-gray-400 mb-1">
          {label && <span>{label}</span>}
          {showValue && <span>{value.toLocaleString()} / {max.toLocaleString()}</span>}
          {showPercent && <span>{percentage.toFixed(0)}%</span>}
        </div>
      )}
      <div className={`bg-gray-900 rounded-full h-full overflow-hidden ${heightClasses[size]}`}>
        <div
          className={`h-full ${getColor()} rounded-full transition-all`}
          style={{ width: `${Math.max(percentage, 4)}%` }}
        />
      </div>
    </div>
  );
}
