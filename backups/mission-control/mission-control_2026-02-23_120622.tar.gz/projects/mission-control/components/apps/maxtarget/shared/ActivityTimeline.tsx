'use client';

import { useState, useEffect, useCallback } from 'react';

interface Activity {
  id: string;
  entityType: 'lead' | 'campaign' | 'content';
  entityId: string;
  action: string;
  detail: string;
  timestamp: string;
  userId: string;
}

interface ActivityTimelineProps {
  entityType: 'lead' | 'campaign' | 'content' | 'all';
  entityId?: string;
  limit?: number;
  compact?: boolean;
}

const ENTITY_COLORS: Record<string, string> = {
  lead: 'bg-red-500',
  campaign: 'bg-blue-500',
  content: 'bg-emerald-500',
};

const ENTITY_BADGE_COLORS: Record<string, string> = {
  lead: 'bg-red-500/20 text-red-400',
  campaign: 'bg-blue-500/20 text-blue-400',
  content: 'bg-emerald-500/20 text-emerald-400',
};

function formatRelativeTime(timestamp: string): string {
  const now = new Date();
  const date = new Date(timestamp);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)}w ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function getActionIcon(action: string): string {
  switch (action) {
    case 'created': return '➕';
    case 'status_changed': return '🔄';
    case 'stage_updated': return '📈';
    case 'budget_adjusted': return '💰';
    case 'note_added': return '📝';
    case 'completed': return '✅';
    default: return '📌';
  }
}

export default function ActivityTimeline({ entityType, entityId, limit = 20, compact = false }: ActivityTimelineProps) {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isExpanded, setIsExpanded] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fetchActivities = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (entityType !== 'all') params.set('entityType', entityType);
      if (entityId) params.set('entityId', entityId);
      params.set('limit', limit.toString());

      const res = await fetch(`/api/apps/maxtarget/activities?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch activities');
      
      const data = await res.json();
      setActivities(data.activities || []);
    } catch (err) {
      setError('Failed to load activities');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [entityType, entityId, limit]);

  useEffect(() => {
    fetchActivities();
  }, [fetchActivities]);

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    
    setSubmitting(true);
    try {
      const res = await fetch('/api/apps/maxtarget/activities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entityType: entityType === 'all' ? 'lead' : entityType,
          entityId: entityId || 'lead-001',
          action: 'note_added',
          detail: newNote.trim(),
          userId: 'user1',
        }),
      });
      
      if (res.ok) {
        const data = await res.json();
        setActivities(prev => [data.activity, ...prev]);
        setNewNote('');
        setShowAddForm(false);
      }
    } catch (err) {
      console.error('Failed to add note:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className={`bg-gray-900 rounded border border-gray-700 ${compact ? 'p-3' : 'p-4'}`}>
        <div className="text-gray-400 text-sm">Loading activities...</div>
      </div>
    );
  }

  if (error && activities.length === 0) {
    return (
      <div className={`bg-gray-900 rounded border border-gray-700 ${compact ? 'p-3' : 'p-4'}`}>
        <div className="text-red-400 text-sm">{error}</div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-900 rounded border border-gray-700 ${compact ? 'p-3' : 'p-4'}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center gap-2 text-sm font-medium text-gray-300 hover:text-white"
        >
          <span className={`transform transition-transform ${isExpanded ? 'rotate-90' : ''}`}>▶</span>
          📋 Activity Timeline
          <span className="text-xs text-gray-500">({activities.length})</span>
        </button>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="text-xs px-2 py-1 bg-[#DC143C]/20 hover:bg-[#DC143C]/30 text-[#DC143C] rounded transition-colors"
        >
          + Add Note
        </button>
      </div>

      {/* Add Note Form */}
      {showAddForm && (
        <div className="mb-3 p-3 bg-gray-800 rounded border border-gray-600">
          <textarea
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Add a note..."
            rows={2}
            className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-[#DC143C] focus:outline-none resize-none"
          />
          <div className="flex gap-2 mt-2">
            <button
              onClick={handleAddNote}
              disabled={submitting || !newNote.trim()}
              className="px-3 py-1 bg-[#DC143C] hover:bg-[#DC143C]/80 disabled:opacity-50 text-white text-xs rounded"
            >
              {submitting ? 'Saving...' : 'Save'}
            </button>
            <button
              onClick={() => { setShowAddForm(false); setNewNote(''); }}
              className="px-3 py-1 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs rounded"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Timeline */}
      {isExpanded && (
        <div className={`space-y-2 ${compact ? 'max-h-[200px] overflow-y-auto' : 'max-h-[320px] overflow-y-auto pr-2'} scrollbar-thin`}>
          {activities.length === 0 ? (
            <div className="text-gray-500 text-sm text-center py-4">No activities yet</div>
          ) : (
            activities.map((activity) => (
              <div key={activity.id} className="flex gap-3">
                {/* Timeline dot */}
                <div className="flex flex-col items-center">
                  <div className={`w-2.5 h-2.5 rounded-full ${ENTITY_COLORS[activity.entityType] || 'bg-gray-500'}`} />
                  {!compact && activities.indexOf(activity) !== activities.length - 1 && (
                    <div className="w-px h-full bg-gray-700 mt-1" />
                  )}
                </div>
                
                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-xs font-medium px-1.5 py-0.5 rounded ${ENTITY_BADGE_COLORS[activity.entityType] || 'bg-gray-700 text-gray-400'}`}>
                      {activity.entityType}
                    </span>
                    <span className="text-xs text-gray-500">{formatRelativeTime(activity.timestamp)}</span>
                  </div>
                  <div className="flex items-start gap-2 mt-1">
                    <span className="text-sm shrink-0">{getActionIcon(activity.action)}</span>
                    <div className="min-w-0">
                      <span className="text-sm font-medium text-gray-200 capitalize">
                        {activity.action.replace('_', ' ')}
                      </span>
                      <p className={`text-gray-400 ${compact ? 'text-xs' : 'text-sm'} truncate`} title={activity.detail}>
                        {activity.detail}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
