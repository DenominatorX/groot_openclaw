'use client';
import { useState, useEffect } from 'react';

interface TeamRole {
  id: string;
  title: string;
  agentId: string | null;
  tier: string;
  modelOverride: string | null;
  rules: string;
  responsibilities: string[];
}

interface Team {
  id: string;
  name: string;
  description: string;
  category: string;
  isDefault: boolean;
  roles: TeamRole[];
}

interface Agent {
  id: string;
  name: string;
  displayName: string;
  title: string;
  tier: number;
  status: string;
  initials: string;
  color: string;
  model: string | null;
  department?: string;
}

const TIER_OPTIONS = ['executive', 'senior', 'mid', 'junior'];
const TIER_COLORS: Record<string, string> = {
  executive: 'bg-red-500/20 text-red-400 border-red-500/30',
  senior: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  mid: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  junior: 'bg-green-500/20 text-green-400 border-green-500/30',
};

const AVAILABLE_MODELS = [
  // ── Escalation only ──────────────────────────────
  'anthropic/claude-sonnet-4-6',
  'anthropic/claude-opus-4-6',
  // ── PM / Architect / Analyst (free, 2M ctx) ──────
  'openrouter/x-ai/grok-4.1-fast',
  'x-ai/grok-4',
  'x-ai/grok-3',
  // ── Dev (backend / frontend / full-stack) ────────
  'openrouter/minimax/minimax-m2.5',
  // ── QA / Docs / Research ─────────────────────────
  'openrouter/google/gemini-2.5-flash',
  'openrouter/google/gemini-2.5-pro',
  'openrouter/google/gemini-3-pro-preview',
  // ── Memory / Archivist + Cron / Utility ──────────
  'anthropic/claude-haiku-3-5',
  // ── Local / fallback ─────────────────────────────
  'lmstudio/gemma-3-12b',
];

export default function TeamsTab() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState<string | null>(null);

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showCloneModal, setShowCloneModal] = useState(false);
  const [cloneSourceTeam, setCloneSourceTeam] = useState<Team | null>(null);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamDesc, setNewTeamDesc] = useState('');

  // Inline edit
  const [editMode, setEditMode] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');

  // Role management
  const [managingTeamId, setManagingTeamId] = useState<string | null>(null);
  const [editingRoleId, setEditingRoleId] = useState<string | null>(null);
  const [roleForm, setRoleForm] = useState<TeamRole>({
    id: '', title: '', agentId: null, tier: 'mid', modelOverride: null, rules: '', responsibilities: [],
  });
  const [respInput, setRespInput] = useState('');

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [teamsRes, agentsRes] = await Promise.all([
        fetch('/api/teams'),
        fetch('/api/agents'),
      ]);
      const teamsData = await teamsRes.json();
      const agentsData = await agentsRes.json();
      setTeams(teamsData.teams || []);
      setAgents(agentsData.agents || []);
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const notify = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const saveTeams = async (updated: Team[]) => {
    setTeams(updated);
    await fetch('/api/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'save', teams: updated }),
    });
  };

  // ---- Team CRUD ----
  const handleCreateTeam = async () => {
    if (!newTeamName.trim()) return;
    const newTeam: Team = {
      id: `team-${Date.now()}`,
      name: newTeamName,
      description: newTeamDesc,
      category: 'custom',
      isDefault: false,
      roles: [],
    };
    await saveTeams([...teams, newTeam]);
    setShowCreateModal(false);
    setNewTeamName('');
    setNewTeamDesc('');
    notify('✅ Team created!');
  };

  const handleCloneTeam = async () => {
    if (!cloneSourceTeam || !newTeamName.trim()) return;
    const cloned: Team = {
      ...cloneSourceTeam,
      id: `team-${Date.now()}`,
      name: newTeamName,
      description: newTeamDesc || `Cloned from ${cloneSourceTeam.name}`,
      isDefault: false,
      roles: cloneSourceTeam.roles.map(r => ({ ...r, id: `role-${Date.now()}-${Math.random().toString(36).slice(2, 6)}` })),
    };
    await saveTeams([...teams, cloned]);
    setShowCloneModal(false);
    setCloneSourceTeam(null);
    setNewTeamName('');
    setNewTeamDesc('');
    notify('✅ Team cloned!');
  };

  const handleEditTeam = async (teamId: string) => {
    await saveTeams(teams.map(t => t.id === teamId ? { ...t, name: editName, description: editDesc } : t));
    setEditMode(null);
    notify('✅ Team updated!');
  };

  const handleDeleteTeam = async (teamId: string) => {
    const team = teams.find(t => t.id === teamId);
    if (team?.isDefault) { notify('❌ Cannot delete default templates'); return; }
    await saveTeams(teams.filter(t => t.id !== teamId));
    if (managingTeamId === teamId) setManagingTeamId(null);
    notify('🗑️ Team deleted');
  };

  // ---- Role CRUD ----
  const managingTeam = teams.find(t => t.id === managingTeamId);

  const startAddRole = () => {
    setEditingRoleId(null);
    setRoleForm({ id: '', title: '', agentId: null, tier: 'mid', modelOverride: null, rules: '', responsibilities: [] });
    setRespInput('');
  };

  const startEditRole = (role: TeamRole) => {
    setEditingRoleId(role.id);
    setRoleForm({ ...role });
    setRespInput('');
  };

  const saveRole = async () => {
    if (!managingTeamId || !roleForm.title.trim()) return;
    const updated = teams.map(t => {
      if (t.id !== managingTeamId) return t;
      let roles: TeamRole[];
      if (editingRoleId) {
        roles = t.roles.map(r => r.id === editingRoleId ? { ...roleForm } : r);
      } else {
        const newRole = { ...roleForm, id: `role-${Date.now()}-${Math.random().toString(36).slice(2, 6)}` };
        roles = [...t.roles, newRole];
      }
      return { ...t, roles };
    });
    await saveTeams(updated);
    setEditingRoleId(null);
    setRoleForm({ id: '', title: '', agentId: null, tier: 'mid', modelOverride: null, rules: '', responsibilities: [] });
    notify(editingRoleId ? '✅ Role updated!' : '✅ Role added!');
  };

  const removeRole = async (roleId: string) => {
    if (!managingTeamId) return;
    await saveTeams(teams.map(t => t.id === managingTeamId ? { ...t, roles: t.roles.filter(r => r.id !== roleId) } : t));
    if (editingRoleId === roleId) {
      setEditingRoleId(null);
      setRoleForm({ id: '', title: '', agentId: null, tier: 'mid', modelOverride: null, rules: '', responsibilities: [] });
    }
    notify('🗑️ Role removed');
  };

  const addResponsibility = () => {
    if (!respInput.trim()) return;
    setRoleForm(f => ({ ...f, responsibilities: [...f.responsibilities, respInput.trim()] }));
    setRespInput('');
  };

  const removeResponsibility = (idx: number) => {
    setRoleForm(f => ({ ...f, responsibilities: f.responsibilities.filter((_, i) => i !== idx) }));
  };

  const getAgent = (id: string | null) => id ? agents.find(a => a.id === id) : null;

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="text-mc-muted">Loading teams...</div></div>;
  }

  // ---- ROLE MANAGEMENT PANEL ----
  if (managingTeam) {
    return (
      <div className="space-y-6">
        {/* Back header */}
        <div className="flex items-center gap-4">
          <button onClick={() => { setManagingTeamId(null); setEditingRoleId(null); }} className="text-mc-muted hover:text-mc-text text-sm">← Back to Teams</button>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-mc-text">👥 {managingTeam.name}</h2>
            <p className="text-sm text-mc-muted">{managingTeam.description}</p>
          </div>
          <span className="px-2 py-0.5 text-xs bg-mc-accent/20 text-mc-accent rounded">{managingTeam.roles.length} roles</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Roles list */}
          <div className="lg:col-span-1 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-mc-muted uppercase">Roles</h3>
              <button onClick={startAddRole} className="px-3 py-1 bg-mc-accent text-white rounded text-xs hover:bg-mc-accent/80">+ Add Role</button>
            </div>
            {managingTeam.roles.length === 0 && (
              <div className="p-6 text-center border border-dashed border-mc-border rounded-lg">
                <p className="text-mc-muted text-sm">No roles yet. Click "Add Role" to get started.</p>
              </div>
            )}
            {managingTeam.roles.map(role => {
              const agent = getAgent(role.agentId);
              const isActive = editingRoleId === role.id;
              return (
                <div key={role.id}
                  onClick={() => startEditRole(role)}
                  className={`p-3 rounded-lg cursor-pointer border transition-colors ${isActive ? 'bg-mc-accent/10 border-mc-accent/50' : 'bg-mc-surface border-mc-border hover:border-mc-accent/30'}`}>
                  <div className="flex items-center gap-3">
                    {agent ? (
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                        style={{ backgroundColor: agent.color }}>
                        {agent.initials}
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-mc-border flex items-center justify-center text-xs flex-shrink-0">👤</div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-mc-text truncate">{role.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border ${TIER_COLORS[role.tier] || TIER_COLORS.mid}`}>{role.tier}</span>
                        {agent && <span className="text-[10px] text-mc-muted">{agent.displayName || agent.name}</span>}
                      </div>
                    </div>
                    <button onClick={e => { e.stopPropagation(); removeRole(role.id); }}
                      className="text-mc-muted hover:text-red-400 text-xs p-1">✕</button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Role edit form */}
          <div className="lg:col-span-2 bg-mc-surface border border-mc-border rounded-xl p-5">
            {editingRoleId || roleForm.title !== undefined ? (
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-mc-muted uppercase">{editingRoleId ? 'Edit Role' : 'New Role'}</h3>

                {/* Role Title */}
                <div>
                  <label className="block text-xs font-medium text-mc-muted mb-1">Role Title</label>
                  <input type="text" value={roleForm.title} onChange={e => setRoleForm(f => ({ ...f, title: e.target.value }))}
                    placeholder="e.g., Lead Developer" className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-sm text-mc-text" />
                </div>

                {/* Agent Picker */}
                <div>
                  <label className="block text-xs font-medium text-mc-muted mb-1">Assigned Agent</label>
                  <select value={roleForm.agentId || ''} onChange={e => setRoleForm(f => ({ ...f, agentId: e.target.value || null }))}
                    className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-sm text-mc-text">
                    <option value="">— Unassigned —</option>
                    {agents.filter(a => a.id !== 'kevin' && a.status === 'active').map(a => (
                      <option key={a.id} value={a.id}>
                        {a.displayName || a.name} — {a.title} (T{a.tier})
                      </option>
                    ))}
                  </select>
                  {roleForm.agentId && (() => {
                    const a = getAgent(roleForm.agentId);
                    if (!a) return null;
                    return (
                      <div className="mt-2 flex items-center gap-3 p-2 bg-mc-bg/50 rounded-lg">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{ backgroundColor: a.color }}>{a.initials}</div>
                        <div>
                          <p className="text-sm font-medium text-mc-text">{a.displayName || a.name}</p>
                          <p className="text-xs text-mc-muted">{a.title} · T{a.tier} · {a.model || 'default model'}</p>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Tier */}
                <div>
                  <label className="block text-xs font-medium text-mc-muted mb-1">Tier Level</label>
                  <select value={roleForm.tier} onChange={e => setRoleForm(f => ({ ...f, tier: e.target.value }))}
                    className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-sm text-mc-text">
                    {TIER_OPTIONS.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
                  </select>
                </div>

                {/* Model Override */}
                <div>
                  <label className="block text-xs font-medium text-mc-muted mb-1">Model Override <span className="text-mc-muted">(optional)</span></label>
                  <select value={roleForm.modelOverride || ''} onChange={e => setRoleForm(f => ({ ...f, modelOverride: e.target.value || null }))}
                    className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-sm text-mc-text">
                    <option value="">Use agent&apos;s default model</option>
                    {AVAILABLE_MODELS.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>

                {/* Rules/Notes */}
                <div>
                  <label className="block text-xs font-medium text-mc-muted mb-1">Rules / Notes</label>
                  <textarea value={roleForm.rules} onChange={e => setRoleForm(f => ({ ...f, rules: e.target.value }))}
                    placeholder="Specific instructions this agent must follow in this role..."
                    rows={3} className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-sm text-mc-text resize-none" />
                </div>

                {/* Responsibilities */}
                <div>
                  <label className="block text-xs font-medium text-mc-muted mb-1">Responsibilities</label>
                  <div className="flex gap-2 mb-2">
                    <input type="text" value={respInput} onChange={e => setRespInput(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addResponsibility(); } }}
                      placeholder="Add a responsibility..." className="flex-1 bg-mc-bg border border-mc-border rounded-lg px-3 py-1.5 text-sm text-mc-text" />
                    <button onClick={addResponsibility} className="px-3 py-1.5 bg-mc-accent/20 text-mc-accent rounded-lg text-sm hover:bg-mc-accent/30">Add</button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {roleForm.responsibilities.map((r, i) => (
                      <span key={i} className="inline-flex items-center gap-1 px-2 py-1 bg-mc-bg border border-mc-border rounded text-xs text-mc-text">
                        {r}
                        <button onClick={() => removeResponsibility(i)} className="text-mc-muted hover:text-red-400 ml-1">✕</button>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 pt-2 border-t border-mc-border">
                  <button onClick={saveRole} disabled={!roleForm.title.trim()}
                    className="px-4 py-2 bg-mc-accent text-white rounded-lg text-sm font-medium hover:bg-mc-accent/80 disabled:opacity-50 disabled:cursor-not-allowed">
                    {editingRoleId ? 'Update Role' : 'Add Role'}
                  </button>
                  <button onClick={() => { setEditingRoleId(null); setRoleForm({ id: '', title: '', agentId: null, tier: 'mid', modelOverride: null, rules: '', responsibilities: [] }); }}
                    className="px-4 py-2 text-mc-muted hover:text-mc-text text-sm">Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-48 text-mc-muted text-sm">
                Select a role to edit or click "Add Role"
              </div>
            )}
          </div>
        </div>

        {notification && (
          <div className="fixed bottom-4 right-4 z-50 px-4 py-3 bg-mc-surface border border-mc-accent/50 rounded-lg shadow-xl">
            <p className="text-sm text-mc-text">{notification}</p>
          </div>
        )}
      </div>
    );
  }

  // ---- TEAMS GRID VIEW ----
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-mc-text">👥 Project Teams</h2>
          <p className="text-sm text-mc-muted">Manage team templates and assign agents to roles</p>
        </div>
        <button onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-mc-accent text-white rounded-lg hover:bg-mc-accent/80 transition-colors text-sm font-medium">
          + Create Team
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {teams.map(team => (
          <div key={team.id} className="bg-mc-surface border border-mc-border rounded-xl overflow-hidden hover:border-mc-accent/50 transition-colors">
            {/* Header */}
            <div className="p-4 border-b border-mc-border bg-mc-bg/50">
              {editMode === team.id ? (
                <div className="space-y-2">
                  <input type="text" value={editName} onChange={e => setEditName(e.target.value)}
                    className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text" placeholder="Team name" />
                  <input type="text" value={editDesc} onChange={e => setEditDesc(e.target.value)}
                    className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text" placeholder="Description" />
                  <div className="flex gap-2">
                    <button onClick={() => handleEditTeam(team.id)} className="px-2 py-1 bg-green-600 text-white rounded text-xs">Save</button>
                    <button onClick={() => setEditMode(null)} className="px-2 py-1 bg-mc-border text-mc-muted rounded text-xs">Cancel</button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-mc-text">{team.name}</h3>
                    <p className="text-xs text-mc-muted mt-1">{team.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="px-2 py-0.5 text-xs bg-mc-accent/20 text-mc-accent rounded">{team.category}</span>
                      {team.isDefault && <span className="px-2 py-0.5 text-[10px] bg-green-500/10 text-green-400 rounded">default</span>}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => { setEditMode(team.id); setEditName(team.name); setEditDesc(team.description); }}
                      className="p-1.5 text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded" title="Edit">✏️</button>
                    <button onClick={() => { setCloneSourceTeam(team); setNewTeamName(`${team.name} (Copy)`); setNewTeamDesc(team.description); setShowCloneModal(true); }}
                      className="p-1.5 text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded" title="Clone">📋</button>
                    {!team.isDefault && (
                      <button onClick={() => handleDeleteTeam(team.id)}
                        className="p-1.5 text-mc-muted hover:text-red-400 hover:bg-mc-bg rounded" title="Delete">🗑️</button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Roles preview */}
            <div className="p-4">
              <h4 className="text-xs font-semibold text-mc-muted uppercase mb-3">Roles ({team.roles.length})</h4>
              {team.roles.length === 0 ? (
                <p className="text-xs text-mc-muted italic">No roles configured</p>
              ) : (
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {team.roles.map(role => {
                    const agent = getAgent(role.agentId);
                    return (
                      <div key={role.id} className="flex items-center gap-2 p-1.5 bg-mc-bg/50 rounded">
                        {agent ? (
                          <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0"
                            style={{ backgroundColor: agent.color }}>{agent.initials}</div>
                        ) : (
                          <div className="w-6 h-6 rounded-full bg-mc-border flex items-center justify-center text-[10px] flex-shrink-0">👤</div>
                        )}
                        <span className="text-xs text-mc-text truncate flex-1">{role.title}</span>
                        <span className={`text-[10px] px-1 py-0.5 rounded border ${TIER_COLORS[role.tier] || TIER_COLORS.mid}`}>{role.tier}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="p-3 border-t border-mc-border bg-mc-bg/30 flex gap-2">
              <button onClick={() => { setManagingTeamId(team.id); startAddRole(); }}
                className="flex-1 px-3 py-1.5 text-xs bg-mc-accent text-white rounded hover:bg-mc-accent/80 transition-colors font-medium">
                ⚙️ Manage Roles
              </button>
              <button onClick={() => { setCloneSourceTeam(team); setNewTeamName(`${team.name} (Copy)`); setNewTeamDesc(team.description); setShowCloneModal(true); }}
                className="px-3 py-1.5 text-xs bg-mc-bg border border-mc-border rounded hover:bg-mc-surface transition-colors">
                📋 Clone
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Create Team Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setShowCreateModal(false)}>
          <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-md shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-mc-border">
              <h2 className="text-lg font-bold text-mc-text">➕ Create New Team</h2>
              <button onClick={() => setShowCreateModal(false)} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-mc-text mb-1">Team Name</label>
                <input type="text" value={newTeamName} onChange={e => setNewTeamName(e.target.value)}
                  placeholder="e.g., My Custom Team" className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-mc-text" autoFocus />
              </div>
              <div>
                <label className="block text-sm font-medium text-mc-text mb-1">Description</label>
                <textarea value={newTeamDesc} onChange={e => setNewTeamDesc(e.target.value)}
                  placeholder="What this team is for..." rows={3} className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-mc-text resize-none" />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={handleCreateTeam} disabled={!newTeamName.trim()}
                  className="flex-1 px-4 py-2 bg-mc-accent text-white rounded-lg hover:bg-mc-accent/80 disabled:opacity-50 disabled:cursor-not-allowed">Create Team</button>
                <button onClick={() => setShowCreateModal(false)} className="px-4 py-2 text-mc-muted hover:text-mc-text">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Clone Team Modal */}
      {showCloneModal && cloneSourceTeam && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setShowCloneModal(false)}>
          <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-md shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-mc-border">
              <h2 className="text-lg font-bold text-mc-text">📋 Clone Team</h2>
              <button onClick={() => setShowCloneModal(false)} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-sm text-mc-muted">Cloning: <span className="text-mc-text font-medium">{cloneSourceTeam.name}</span> ({cloneSourceTeam.roles.length} roles)</p>
              <div>
                <label className="block text-sm font-medium text-mc-text mb-1">New Team Name</label>
                <input type="text" value={newTeamName} onChange={e => setNewTeamName(e.target.value)}
                  className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-mc-text" autoFocus />
              </div>
              <div>
                <label className="block text-sm font-medium text-mc-text mb-1">Description</label>
                <textarea value={newTeamDesc} onChange={e => setNewTeamDesc(e.target.value)}
                  rows={3} className="w-full bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-mc-text resize-none" />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={handleCloneTeam} disabled={!newTeamName.trim()}
                  className="flex-1 px-4 py-2 bg-mc-accent text-white rounded-lg hover:bg-mc-accent/80 disabled:opacity-50 disabled:cursor-not-allowed">Clone Team</button>
                <button onClick={() => setShowCloneModal(false)} className="px-4 py-2 text-mc-muted hover:text-mc-text">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {notification && (
        <div className="fixed bottom-4 right-4 z-50 px-4 py-3 bg-mc-surface border border-mc-accent/50 rounded-lg shadow-xl">
          <p className="text-sm text-mc-text">{notification}</p>
        </div>
      )}
    </div>
  );
}
