'use client';
import { useEffect, useState, useCallback } from 'react';

interface WeatherData {
  temp_F: string;
  temp_C: string;
  humidity: string;
  windspeedMiles: string;
  windspeedKmph: string;
  weatherDesc: string;
  weatherCode: string;
  feelsLikeF: string;
  feelsLikeC: string;
  maxTempF?: string;
  maxTempC?: string;
  minTempF?: string;
  minTempC?: string;
}

const WEATHER_ICONS: Record<string, string> = {
  '113': '☀️', '116': '⛅', '119': '☁️', '122': '☁️',
  '143': '🌫', '176': '🌦', '179': '🌨', '182': '🌧',
  '185': '🌧', '200': '⛈', '227': '🌨', '230': '❄️',
  '248': '🌫', '260': '🌫', '263': '🌦', '266': '🌧',
  '281': '🌧', '284': '🌧', '293': '🌦', '296': '🌧',
  '299': '🌧', '302': '🌧', '305': '🌧', '308': '🌧',
  '311': '🌧', '314': '🌧', '317': '🌨', '320': '🌨',
  '323': '🌨', '326': '🌨', '329': '❄️', '332': '❄️',
  '335': '❄️', '338': '❄️', '350': '🌧', '353': '🌦',
  '356': '🌧', '359': '🌧', '362': '🌨', '365': '🌨',
  '368': '🌨', '371': '❄️', '374': '🌨', '377': '🌨',
  '386': '⛈', '389': '⛈', '392': '⛈', '395': '❄️',
};

export function useWeather() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [zip, setZip] = useState('34638');
  const [tempUnit, setTempUnit] = useState<'F' | 'C'>('F');

  const fetchWeather = useCallback(async (zipCode: string) => {
    try {
      const res = await fetch(`https://wttr.in/${zipCode}?format=j1`);
      if (!res.ok) throw new Error('Weather fetch failed');
      const data = await res.json();
      const cur = data.current_condition?.[0];
      const today = data.weather?.[0];
      if (cur) {
        setWeather({
          temp_F: cur.temp_F,
          temp_C: cur.temp_C,
          humidity: cur.humidity,
          windspeedMiles: cur.windspeedMiles,
          windspeedKmph: cur.windspeedKmph,
          weatherDesc: cur.weatherDesc?.[0]?.value || 'Unknown',
          weatherCode: cur.weatherCode,
          feelsLikeF: cur.FeelsLikeF,
          feelsLikeC: cur.FeelsLikeC,
          maxTempF: today?.maxtempF,
          maxTempC: today?.maxtempC,
          minTempF: today?.mintempF,
          minTempC: today?.mintempC,
        });
      }
    } catch {
      // silently fail
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Load settings
    fetch('/api/settings').then(r => r.json()).then(d => {
      const z = d.raw?.weatherZip || '34638';
      const u = d.raw?.tempUnit || 'F';
      setZip(z);
      setTempUnit(u as 'F' | 'C');
      fetchWeather(z);
    }).catch(() => fetchWeather('34638'));

    const interval = setInterval(() => {
      fetch('/api/settings').then(r => r.json()).then(d => {
        fetchWeather(d.raw?.weatherZip || '34638');
        setTempUnit((d.raw?.tempUnit || 'F') as 'F' | 'C');
      }).catch(() => {});
    }, 30 * 60 * 1000);

    return () => clearInterval(interval);
  }, [fetchWeather]);

  const icon = weather ? (WEATHER_ICONS[weather.weatherCode] || '🌡') : '🌡';
  const temp = weather ? (tempUnit === 'F' ? `${weather.temp_F}°F` : `${weather.temp_C}°C`) : '--';
  const feelsLike = weather ? (tempUnit === 'F' ? `${weather.feelsLikeF}°F` : `${weather.feelsLikeC}°C`) : '--';
  const high = weather ? (tempUnit === 'F' ? `${weather.maxTempF}°` : `${weather.maxTempC}°`) : '--';
  const low = weather ? (tempUnit === 'F' ? `${weather.minTempF}°` : `${weather.minTempC}°`) : '--';

  return { weather, loading, icon, temp, feelsLike, high, low, tempUnit, zip };
}

export default function WeatherWidget() {
  const { weather, loading, icon, temp, feelsLike, high, low } = useWeather();
  const [expanded, setExpanded] = useState(false);

  if (loading) return <span className="text-mc-muted text-xs">🌡 ...</span>;
  if (!weather) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1 text-xs text-mc-muted hover:text-mc-text transition-colors"
      >
        <span>{icon}</span>
        <span className="font-mono">{temp}</span>
        <span className="hidden sm:inline text-[10px]">{weather.weatherDesc}</span>
      </button>

      {expanded && (
        <div className="absolute top-full left-0 mt-1 bg-mc-surface border border-mc-border rounded-lg p-3 shadow-xl z-50 min-w-[200px]">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">{icon}</span>
            <div>
              <div className="text-lg font-bold text-mc-text">{temp}</div>
              <div className="text-xs text-mc-muted">{weather.weatherDesc}</div>
            </div>
          </div>
          <div className="space-y-1 text-xs text-mc-muted">
            <div className="flex justify-between"><span>Feels like</span><span className="text-mc-text">{feelsLike}</span></div>
            <div className="flex justify-between"><span>High / Low</span><span className="text-mc-text">{high} / {low}</span></div>
            <div className="flex justify-between"><span>Humidity</span><span className="text-mc-text">{weather.humidity}%</span></div>
            <div className="flex justify-between"><span>Wind</span><span className="text-mc-text">{weather.windspeedMiles} mph</span></div>
          </div>
        </div>
      )}
    </div>
  );
}
