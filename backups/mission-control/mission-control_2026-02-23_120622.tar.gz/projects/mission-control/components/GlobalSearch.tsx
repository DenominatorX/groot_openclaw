'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Search, X } from 'lucide-react';

interface SearchResult {
  type: string;
  id: string;
  title: string;
  subtitle: string;
  url: string;
  relevance: number;
  highlight?: string;
}

interface SearchResponse {
  query: string;
  total: number;
  results: SearchResult[];
  byType: Record<string, number>;
}

interface GroupedResults {
  [type: string]: SearchResult[];
}

// Type badge colors
const TYPE_COLORS: Record<string, string> = {
  project: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  task: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  issue: 'bg-red-500/20 text-red-400 border-red-500/30',
  agent: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  report: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  feature: 'bg-green-500/20 text-green-400 border-green-500/30',
  activity: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  chat: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
};

// Type icons
const TYPE_ICONS: Record<string, string> = {
  project: '📁',
  task: '📋',
  issue: '🛡️',
  agent: '🤖',
  report: '📄',
  feature: '🧩',
  activity: '⚡',
  chat: '💬',
};

// Route mapping
function getTargetUrl(result: SearchResult): string {
  const { type, id, url } = result;
  
  switch (type) {
    case 'project':
      return `/projects/${id}`;
    case 'task':
      return `/tasks?id=${id}`;
    case 'issue':
      return `/issues/${id}`;
    case 'agent':
      return `/agents/${id}`;
    case 'report':
      return `/reports/${id}`;
    case 'feature':
      return `/features?highlight=${id}`;
    case 'activity':
      return '/';
    case 'chat':
      return `/chat/${id}`;
    default:
      return url || '/';
  }
}

interface GlobalSearchProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export default function GlobalSearch({ isOpen: externalIsOpen, onClose: externalOnClose }: GlobalSearchProps) {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [groupedResults, setGroupedResults] = useState<GroupedResults>({});
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const debounceTimer = useRef<NodeJS.Timeout | null>(null);

  // Controlled vs uncontrolled mode
  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;
  const setIsOpen = externalOnClose ? () => externalOnClose() : setInternalIsOpen;

  // Group results by type
  const groupByType = (results: SearchResult[]): GroupedResults => {
    const grouped: GroupedResults = {};
    results.forEach((result) => {
      if (!grouped[result.type]) {
        grouped[result.type] = [];
      }
      grouped[result.type].push(result);
    });
    return grouped;
  };

  // Get flat list for navigation
  const getFlatResults = (grouped: GroupedResults): SearchResult[] => {
    return Object.values(grouped).flat();
  };

  // Search API call
  const search = useCallback(async (q: string) => {
    if (!q || q.trim().length < 2) {
      setResults([]);
      setGroupedResults({});
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(q)}&limit=20`);
      const data: SearchResponse = await response.json();
      
      setResults(data.results || []);
      setGroupedResults(groupByType(data.results || []));
      setSelectedIndex(0);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
      setGroupedResults({});
    } finally {
      setLoading(false);
    }
  }, []);

  // Debounced search
  useEffect(() => {
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    if (query.trim().length < 2) {
      setResults([]);
      setGroupedResults({});
      return;
    }

    debounceTimer.current = setTimeout(() => {
      search(query);
    }, 300);

    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }
    };
  }, [query, search]);

  // Keyboard shortcuts - only in uncontrolled mode
  useEffect(() => {
    // Only register global shortcut when not in controlled mode
    if (externalOnClose) return;
    
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd+K or Ctrl+K to open
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setInternalIsOpen(true);
      }

      // Escape to close
      if (e.key === 'Escape' && internalIsOpen) {
        setInternalIsOpen(false);
        setQuery('');
        setResults([]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [internalIsOpen, externalOnClose]);

  // Auto-focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Keyboard navigation
  const handleKeyNavigation = (e: React.KeyboardEvent) => {
    const flatResults = getFlatResults(groupedResults);

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex((prev) => Math.min(prev + 1, flatResults.length - 1));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex((prev) => Math.max(prev - 1, 0));
        break;
      case 'Enter':
        e.preventDefault();
        if (flatResults[selectedIndex]) {
          router.push(getTargetUrl(flatResults[selectedIndex]));
          setIsOpen(false);
          setQuery('');
          setResults([]);
        }
        break;
    }
  };

  // Handle result click
  const handleResultClick = (result: SearchResult) => {
    router.push(getTargetUrl(result));
    setIsOpen(false);
    setQuery('');
    setResults([]);
  };

  // Handle overlay click
  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      setIsOpen(false);
      setQuery('');
      setResults([]);
    }
  };

  // Get flat results for index calculation
  const flatResults = getFlatResults(groupedResults);

  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] bg-black/60 backdrop-blur-sm"
      onClick={handleOverlayClick}
    >
      {/* Modal Panel */}
      <div className="w-full max-w-2xl mx-4 bg-mc-surface border border-mc-border rounded-xl shadow-2xl overflow-hidden">
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-mc-border">
          <Search className="w-5 h-5 text-mc-muted flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyNavigation}
            placeholder="Search Mission Control..."
            className="flex-1 bg-transparent text-mc-text placeholder-mc-muted/70 outline-none text-lg"
            autoComplete="off"
          />
          {loading && (
            <div className="w-5 h-5 border-2 border-mc-muted border-t-mc-text rounded-full animate-spin" />
          )}
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 text-mc-muted hover:text-mc-text transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto">
          {query.trim().length >= 2 && flatResults.length === 0 && !loading && (
            <div className="px-4 py-8 text-center text-mc-muted/70">
              No results for &apos;{query}&apos;
            </div>
          )}

          {query.trim().length < 2 && (
            <div className="px-4 py-8 text-center text-mc-muted/70">
              Type at least 2 characters to search
            </div>
          )}

          {Object.entries(groupedResults).map(([type, typeResults]) => (
            <div key={type} className="border-b border-mc-bg last:border-b-0">
              {/* Section Header */}
              <div className="px-4 py-2 bg-mc-bg/80 flex items-center gap-2 sticky top-0">
                <span className="text-sm">{TYPE_ICONS[type] || '📄'}</span>
                <span className="text-sm font-medium text-mc-text capitalize">
                  {type === 'project' ? 'Projects' : type === 'task' ? 'Tasks' : 
                   type === 'issue' ? 'Issues' : type === 'agent' ? 'Agents' :
                   type === 'report' ? 'Reports' : type === 'feature' ? 'Features' :
                   type === 'activity' ? 'Activity' : type === 'chat' ? 'Chat' : type}s
                </span>
                <span className="text-xs text-mc-muted/70">({typeResults.length})</span>
              </div>

              {/* Results */}
              {typeResults.map((result, idx) => {
                const globalIdx = flatResults.findIndex(r => r.id === result.id && r.type === result.type);
                const isSelected = globalIdx === selectedIndex;
                
                return (
                  <div
                    key={`${result.type}-${result.id}`}
                    onClick={() => handleResultClick(result)}
                    className={`px-4 py-3 cursor-pointer transition-colors ${
                      isSelected ? 'bg-mc-bg' : 'hover:bg-mc-bg/50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Type Badge */}
                      <span className={`px-2 py-0.5 rounded-full text-xs border ${TYPE_COLORS[result.type] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'}`}>
                        {type}
                      </span>
                      
                      <div className="flex-1 min-w-0">
                        {/* Title */}
                        <div className="font-medium text-mc-text truncate">
                          {result.title}
                        </div>
                        
                        {/* Subtitle */}
                        <div className="text-sm text-mc-muted/70 truncate">
                          {result.subtitle}
                        </div>
                        
                        {/* Highlight */}
                        {result.highlight && (
                          <div className="text-xs text-mc-muted/70 italic truncate mt-1">
                            {result.highlight.substring(0, 80)}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Footer Hint */}
        <div className="px-4 py-2 border-t border-mc-border bg-mc-bg/30 flex items-center justify-between text-xs text-mc-muted/70">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-mc-border rounded text-mc-muted">↑↓</kbd>
              <span>Navigate</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-mc-border rounded text-mc-muted">↵</kbd>
              <span>Open</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-mc-border rounded text-mc-muted">Esc</kbd>
              <span>Close</span>
            </span>
          </div>
          <span>
            Press <kbd className="px-1 py-0.5 bg-mc-border rounded">⌘K</kbd> to open
          </span>
        </div>
      </div>
    </div>
  );
}

// Hook to trigger search from outside
export function useGlobalSearch() {
  const [trigger, setTrigger] = useState(0);
  
  const open = useCallback(() => {
    setTrigger((t) => t + 1);
  }, []);

  return { trigger, open };
}
