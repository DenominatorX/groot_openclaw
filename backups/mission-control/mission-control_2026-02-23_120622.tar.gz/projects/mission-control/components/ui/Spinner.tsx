export function Spinner({ className = 'w-8 h-8' }) {
  return (
    <div className={`${className} border-4 border-slate-300 border-t-blue-500 rounded-full animate-spin`} />
  );
}
