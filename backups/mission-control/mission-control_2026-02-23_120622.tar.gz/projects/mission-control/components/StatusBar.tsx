'use client';
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { Search } from 'lucide-react';
import dynamic from 'next/dynamic';
import WeatherWidget from './WeatherWidget';
import UserMenu from './auth/UserMenu';

// Dynamic import for GlobalSearch to avoid SSR issues
const GlobalSearch = dynamic(() => import('./GlobalSearch'), { ssr: false });

interface SystemInfo {
  hostname: string;
  cpuCores: number;
  memUsedPct: number;
  diskUsedPct: number;
  gatewayStatus: string;
  uptime: number;
}

interface User {
  id: string;
  name?: string | null;
  email?: string | null;
  image?: string | null;
  role?: string;
}

function formatUptime(s: number) {
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return d > 0 ? `${d}d ${h}h` : `${h}h ${m}m`;
}

function Counters() {
  const { data: session } = useSession();
  const [counts, setCounts] = useState({ agents: 0, tasks: 0 });
  useEffect(() => {
    if (!session) return;
    Promise.all([
      fetch('/api/agents').then(r => r.json()).then(d => d.agents?.length || 0),
      fetch('/api/tasks').then(r => r.json()).then(d => (d.tasks || []).length),
    ]).then(([agents, tasks]) => setCounts({ agents, tasks })).catch(() => {});
  }, [session]);
  if (!session) return null;
  return <span className="text-mc-muted text-xs">{counts.agents}A • {counts.tasks}T</span>;
}

function VersionDisplay() {
  const [version, setVersion] = useState('1.0.0');
  useEffect(() => {
    fetch('/api/version')
      .then(r => r.json())
      .then(d => setVersion(d.version || '1.0.0'))
      .catch(() => {});
  }, []);
  return <span className="font-mono text-mc-accent text-xs">v{version}</span>;
}

export default function StatusBar() {
  const [sys, setSys] = useState<SystemInfo | null>(null);
  const [time, setTime] = useState(new Date());
  const [user, setUser] = useState<User | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);

  // Handle global keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    const fetchSys = () => fetch('/api/system').then(r => r.json()).then(setSys).catch(() => {});
    fetchSys();
    const s = setInterval(fetchSys, 30000);
    return () => { clearInterval(t); clearInterval(s); };
  }, []);

  // Fetch current user session
  useEffect(() => {
    fetch('/api/auth/session')
      .then(r => r.json())
      .then(data => {
        if (data.user) {
          setUser(data.user);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="flex items-center justify-between px-2 md:px-4 py-1.5 md:py-2 bg-mc-surface border-b border-mc-border text-xs md:text-sm transition-all duration-300 md:ml-16">
      <div className="flex items-center gap-2 md:gap-4 min-w-0">
        <span className="font-bold text-mc-accent text-sm md:text-base flex-shrink-0">⚡ MC</span>
        <VersionDisplay />
        <span className="text-mc-muted font-mono hidden sm:inline">
          {time.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
        </span>
        <span className="text-mc-muted font-mono text-[10px] md:text-xs">
          {time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
        </span>
        <Counters />
        <WeatherWidget />
      </div>
      <div className="flex items-center gap-2 md:gap-4 flex-shrink-0">
        {sys && (
          <div className="flex items-center gap-2 md:gap-4 text-mc-muted">
            <span className="hidden md:inline">🖥 {sys.cpuCores} cores</span>
            <span className={`hidden sm:inline ${sys.memUsedPct > 80 ? 'text-yellow-400' : ''}`}>
              RAM {sys.memUsedPct}%
            </span>
            <span className="hidden md:inline">⏱ {formatUptime(sys.uptime)}</span>
            <span className={`flex items-center gap-1 ${sys.gatewayStatus === 'online' ? 'text-green-400' : 'text-red-400'}`}>
              <span className={`w-1.5 h-1.5 md:w-2 md:h-2 rounded-full ${sys.gatewayStatus === 'online' ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="hidden sm:inline">GW</span>
            </span>
          </div>
        )}
        {user ? (
          <UserMenu user={user} />
        ) : (
          <a
            href="/auth/signin"
            className="px-3 py-1.5 bg-mc-accent hover:bg-mc-accent/90 text-white text-xs font-medium rounded-lg transition-colors"
          >
            Sign In
          </a>
        )}
        {/* Search Button */}
        <button
          onClick={() => setSearchOpen(true)}
          className="flex items-center gap-2 px-2 md:px-3 py-1.5 bg-mc-bg hover:bg-mc-accent/20 text-mc-muted hover:text-mc-accent rounded-lg transition-colors border border-mc-border"
          title="Search (⌘K)"
        >
          <Search className="w-4 h-4" />
          <span className="hidden md:inline text-xs">Search</span>
          <kbd className="hidden md:inline px-1.5 py-0.5 bg-mc-surface rounded text-[10px] text-mc-muted">
            ⌘K
          </kbd>
        </button>
      </div>
      {/* Global Search Modal */}
      <GlobalSearch isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}
