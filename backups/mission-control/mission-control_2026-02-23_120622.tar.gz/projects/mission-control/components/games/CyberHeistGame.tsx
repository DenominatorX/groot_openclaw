'use client';
import { useState, useEffect } from 'react';

interface Specialist {
  id: string;
  name: string;
  role: string;
  skill: string;
  cost: number; // resource units
  bonus: number; // % boost to phase success
}

interface MissionBrief {
  id: string;
  target: string;
  sector: string;
  securityLevel: 'low' | 'medium' | 'high' | 'extreme';
  value: number; // in $
  dataTypes: string[];
  layout: string;
  guards: number;
  firewalls: number;
  timeLimit: number; // minutes
}

interface PlanPhase {
  reconnaissance: number; // 0-100 resource allocation
  toolPrep: number;
  entryStrategy: number;
  extractionPlan: number;
  escapeRoute: number;
}

interface ExecutionChoice {
  text: string;
  riskLevel: 'low' | 'medium' | 'high';
  successChance: number; // 0-100
  outcome?: string;
}

interface GameState {
  screen: 'lobby' | 'briefing' | 'team-assembly' | 'planning' | 'execution' | 'results' | 'leaderboard';
  difficulty: 'script-kiddie' | 'hacker' | 'elite' | 'legendary';
  mission?: MissionBrief;
  selectedTeam: Specialist[];
  plan?: PlanPhase;
  careerEarnings: number;
  successfulHeists: number;
  totalAttempts: number;
  executionLog: string[];
  executionPhaseIndex: number;
  lastOutcome?: {
    success: boolean;
    earnings: number;
    message: string;
  };
}

const SPECIALISTS: Specialist[] = [
  { id: 'hacker', name: 'The Ghost', role: 'Hacker', skill: 'Bypass firewalls & intrusion detection', cost: 30, bonus: 25 },
  { id: 'soceng', name: 'The Mimic', role: 'Social Engineer', skill: 'Trick guards & staff', cost: 20, bonus: 20 },
  { id: 'hardware', name: 'The Machinist', role: 'Hardware Expert', skill: 'Physical access & device hacking', cost: 25, bonus: 22 },
  { id: 'analyst', name: 'The Oracle', role: 'Analyst', skill: 'Find vulnerabilities & data location', cost: 15, bonus: 18 },
  { id: 'ghost', name: 'The Phantom', role: 'Ghost', skill: 'Stealth movement & extraction', cost: 35, bonus: 28 },
];

const SAMPLE_MISSIONS: MissionBrief[] = [
  {
    id: 'nexus-1',
    target: 'Nexus Finance Corp',
    sector: 'Financial Services',
    securityLevel: 'high',
    value: 500000,
    dataTypes: ['Trading Algorithms', 'Client Lists', 'Crypto Wallets'],
    layout: 'Downtown high-rise, 12 floors, 24/7 armed security',
    guards: 8,
    firewalls: 3,
    timeLimit: 90,
  },
  {
    id: 'apex-1',
    target: 'Apex Biotech',
    sector: 'Biotechnology',
    securityLevel: 'extreme',
    value: 1200000,
    dataTypes: ['Gene Therapy Code', 'Patent Files', 'Lab Notes'],
    layout: 'Secure compound with biometric locks, underground lab',
    guards: 12,
    firewalls: 4,
    timeLimit: 60,
  },
  {
    id: 'synth-1',
    target: 'Synthetic Mind AI Labs',
    sector: 'Artificial Intelligence',
    securityLevel: 'extreme',
    value: 2000000,
    dataTypes: ['Model Weights', 'Training Data', 'API Keys'],
    layout: 'Warehouse facility with quantum-locked servers',
    guards: 10,
    firewalls: 5,
    timeLimit: 45,
  },
];

export default function CyberHeistGame() {
  const [game, setGame] = useState<GameState>({
    screen: 'lobby',
    difficulty: 'hacker',
    selectedTeam: [],
    careerEarnings: 0,
    successfulHeists: 0,
    totalAttempts: 0,
    executionLog: [],
    executionPhaseIndex: 0,
  });

  // Mission generation simulation (in real version, calls API)
  const generateMission = () => {
    const mission = SAMPLE_MISSIONS[Math.floor(Math.random() * SAMPLE_MISSIONS.length)];
    setGame(prev => ({
      ...prev,
      screen: 'briefing',
      mission,
      selectedTeam: [],
      plan: undefined,
      executionLog: [],
      executionPhaseIndex: 0,
    }));
  };

  const selectSpecialist = (specialist: Specialist) => {
    if (game.selectedTeam.length < 3 && !game.selectedTeam.find(s => s.id === specialist.id)) {
      setGame(prev => ({
        ...prev,
        selectedTeam: [...prev.selectedTeam, specialist],
      }));
    }
  };

  const deselectSpecialist = (id: string) => {
    setGame(prev => ({
      ...prev,
      selectedTeam: prev.selectedTeam.filter(s => s.id !== id),
    }));
  };

  const advanceToPlanning = () => {
    if (game.selectedTeam.length === 3) {
      setGame(prev => ({
        ...prev,
        screen: 'planning',
        plan: { reconnaissance: 20, toolPrep: 20, entryStrategy: 20, extractionPlan: 20, escapeRoute: 20 },
      }));
    }
  };

  const updatePlanAllocation = (phase: keyof PlanPhase, value: number) => {
    setGame(prev => ({
      ...prev,
      plan: { ...prev.plan!, [phase]: Math.max(0, Math.min(100, value)) },
    }));
  };

  const executeHeist = () => {
    if (!game.plan || !game.mission) return;

    // Simulate execution
    const messages: string[] = [];
    const teamBonus = game.selectedTeam.reduce((sum, s) => sum + s.bonus, 0) / 3;
    const planQuality = Object.values(game.plan).reduce((sum, v) => sum + v, 0) / 5;
    const baseSuccessChance = 50 + teamBonus + (planQuality / 2);

    messages.push(`⚡ INITIATING HEIST: ${game.mission.target}`);
    messages.push(`📊 Security Level: ${game.mission.securityLevel.toUpperCase()} | Guards: ${game.mission.guards} | Firewalls: ${game.mission.firewalls}`);
    messages.push(`👥 Team: ${game.selectedTeam.map(s => s.name).join(', ')}`);
    messages.push('');
    messages.push(`🔍 [RECONNAISSANCE] Scanning target layout...`);
    messages.push(`   ├─ Building schematics acquired (Plan Quality: ${Math.round(game.plan.reconnaissance)}%)`);
    messages.push(`   └─ Guard patrol patterns detected`);
    messages.push('');
    messages.push(`🛠️  [TOOL PREPARATION] Deploying custom tools...`);
    messages.push(`   ├─ Firewall exploit prepared (Hacker Bonus: +${SPECIALISTS[0].bonus}%)`);
    messages.push(`   └─ Physical entry device ready`);
    messages.push('');
    messages.push(`🚪 [ENTRY STRATEGY] Initiating breach...`);
    const entryRoll = Math.random() * 100;
    if (entryRoll < baseSuccessChance - 15) {
      messages.push(`   ✓ SILENT ENTRY SUCCESS - Bypassed south entrance`);
    } else {
      messages.push(`   ⚠️  SILENT ENTRY PARTIAL - Alarm triggered, 60 seconds to exit`);
    }
    messages.push('');
    messages.push(`💾 [DATA EXTRACTION] Locating sensitive files...`);
    const extractRoll = Math.random() * 100;
    if (extractRoll < baseSuccessChance) {
      messages.push(`   ✓ EXTRACTION SUCCESS - All target files secured`);
    } else {
      messages.push(`   ⚠️  PARTIAL EXTRACTION - 70% of files recovered`);
    }
    messages.push('');
    messages.push(`🏃 [ESCAPE ROUTE] Executing exit plan...`);
    const escapeRoll = Math.random() * 100;
    if (escapeRoll < baseSuccessChance + 10) {
      messages.push(`   ✓ CLEAN ESCAPE - Lost all pursuers`);
    } else if (escapeRoll < baseSuccessChance + 25) {
      messages.push(`   ⚠️  CLOSE CALL - Narrowly escaped, 2 minutes ahead of security`);
    } else {
      messages.push(`   ✗ APPREHENDED - Mission failed, exfiltration blocked`);
    }

    const successRoll = Math.random() * 100;
    const success = successRoll < baseSuccessChance;
    const earnings = success ? Math.floor(game.mission.value * (0.5 + Math.random() * 0.4)) : 0;

    messages.push('');
    if (success) {
      messages.push(`✅ HEIST COMPLETE - Mission Successful!`);
      messages.push(`💰 Earnings: $${earnings.toLocaleString()}`);
    } else {
      messages.push(`❌ HEIST FAILED - Caught by security.`);
      messages.push(`💀 No earnings. Next mission available in 5 minutes.`);
    }

    setGame(prev => ({
      ...prev,
      screen: 'results',
      executionLog: messages,
      lastOutcome: {
        success,
        earnings,
        message: success ? `Scored $${earnings.toLocaleString()}!` : 'Mission failed—try again.',
      },
      careerEarnings: prev.careerEarnings + earnings,
      successfulHeists: success ? prev.successfulHeists + 1 : prev.successfulHeists,
      totalAttempts: prev.totalAttempts + 1,
    }));
  };

  // === RENDER SCREENS ===

  if (game.screen === 'lobby') {
    return (
      <div className="space-y-6">
        <div className="bg-black border-2 border-[#00ff00] rounded-lg p-8 font-mono text-[#00ff00] shadow-lg" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,255,0,0.03) 1px, transparent 1px)',
          backgroundSize: '100% 2px',
        }}>
          <div className="text-4xl font-bold mb-2 animate-pulse">🔓 CYBER HEIST</div>
          <div className="text-sm opacity-75 mb-6">Strategic digital infiltration. Plan. Execute. Escape.</div>
          
          <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-4 mb-6 space-y-2 text-sm">
            <div>▶ Elite heist simulator with AI-generated targets</div>
            <div>▶ Assemble 3-person specialist teams</div>
            <div>▶ Plan reconnaissance, entry, extraction, escape</div>
            <div>▶ Execute with strategic choices & dice rolls</div>
            <div>▶ Build career earnings & reputation</div>
            <div>▶ Compete on global leaderboards</div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
              <div className="text-xs opacity-50 mb-1">CAREER STATUS</div>
              <div className="text-xl font-bold">${game.careerEarnings.toLocaleString()}</div>
              <div className="text-xs opacity-75">{game.successfulHeists} successful heists</div>
            </div>
            <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
              <div className="text-xs opacity-50 mb-1">SUCCESS RATE</div>
              <div className="text-xl font-bold">{game.totalAttempts > 0 ? Math.round((game.successfulHeists / game.totalAttempts) * 100) : 0}%</div>
              <div className="text-xs opacity-75">{game.totalAttempts} total attempts</div>
            </div>
          </div>

          <div className="space-y-2 mb-6">
            <label className="block text-sm mb-2">Difficulty:</label>
            <select 
              value={game.difficulty} 
              onChange={(e) => setGame(prev => ({ ...prev, difficulty: e.target.value as any }))}
              className="w-full bg-gray-900 border border-[#00ff00] text-[#00ff00] rounded p-2 font-mono text-sm"
            >
              <option value="script-kiddie">Script Kiddie (Easy)</option>
              <option value="hacker">Hacker (Medium)</option>
              <option value="elite">Elite (Hard)</option>
              <option value="legendary">Legendary (Insane)</option>
            </select>
          </div>

          <button
            onClick={generateMission}
            className="w-full bg-[#00ff00] text-black font-bold py-3 rounded hover:bg-[#00ff00]/80 transition text-lg"
          >
            🎬 START NEW HEIST
          </button>
        </div>
      </div>
    );
  }

  if (game.screen === 'briefing' && game.mission) {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setGame(prev => ({ ...prev, screen: 'lobby' }))}
          className="px-3 py-1.5 text-sm text-[#00ff00] hover:bg-[#00ff00]/10 rounded font-mono"
        >
          ← Back to Lobby
        </button>

        <div className="bg-black border-2 border-[#00ff00] rounded-lg p-6 font-mono text-[#00ff00]" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,255,0,0.03) 1px, transparent 1px)',
          backgroundSize: '100% 2px',
        }}>
          <div className="text-2xl font-bold mb-4">⚔️ MISSION BRIEFING</div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
              <div className="text-xs opacity-50 mb-1">TARGET</div>
              <div className="font-bold text-lg">{game.mission.target}</div>
              <div className="text-xs opacity-75">{game.mission.sector}</div>
            </div>
            <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
              <div className="text-xs opacity-50 mb-1">SECURITY LEVEL</div>
              <div className="font-bold text-lg">{game.mission.securityLevel.toUpperCase()}</div>
              <div className="text-xs opacity-75">{game.mission.guards} guards, {game.mission.firewalls} firewalls</div>
            </div>
          </div>

          <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3 mb-4">
            <div className="text-xs opacity-50 mb-2">TARGET LAYOUT</div>
            <div className="text-sm">{game.mission.layout}</div>
          </div>

          <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3 mb-4">
            <div className="text-xs opacity-50 mb-2">VALUABLE DATA</div>
            <div className="text-sm space-y-1">
              {(game.mission.dataTypes || []).map((dt, i) => (
                <div key={i}>• {dt}</div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3 mb-6">
            <div className="text-xs opacity-50 mb-1">ESTIMATED PAYOFF</div>
            <div className="text-2xl font-bold">${(game.mission.value * 0.6).toLocaleString()}</div>
            <div className="text-xs opacity-75">Successful extraction of all data</div>
          </div>

          <button
            onClick={() => setGame(prev => ({ ...prev, screen: 'team-assembly' }))}
            className="w-full bg-[#00ff00] text-black font-bold py-3 rounded hover:bg-[#00ff00]/80 transition text-lg"
          >
            👥 ASSEMBLE TEAM
          </button>
        </div>
      </div>
    );
  }

  if (game.screen === 'team-assembly') {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setGame(prev => ({ ...prev, screen: 'briefing' }))}
          className="px-3 py-1.5 text-sm text-[#00ff00] hover:bg-[#00ff00]/10 rounded font-mono"
        >
          ← Back to Briefing
        </button>

        <div className="bg-black border-2 border-[#00ff00] rounded-lg p-6 font-mono text-[#00ff00]" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,255,0,0.03) 1px, transparent 1px)',
          backgroundSize: '100% 2px',
        }}>
          <div className="text-2xl font-bold mb-2">👥 TEAM ASSEMBLY</div>
          <div className="text-xs opacity-50 mb-6">Select 3 specialists. Each brings unique skills.</div>

          <div className="mb-6">
            <div className="text-sm font-bold mb-2">YOUR TEAM ({game.selectedTeam.length}/3)</div>
            <div className="space-y-2">
              {game.selectedTeam.map(s => (
                <div key={s.id} className="bg-gray-900 border border-[#00ff00]/50 rounded p-2 flex justify-between items-center">
                  <div>
                    <div className="font-bold">{s.name}</div>
                    <div className="text-xs opacity-75">{s.skill}</div>
                  </div>
                  <button
                    onClick={() => deselectSpecialist(s.id)}
                    className="px-2 py-1 bg-red-900/50 text-red-300 rounded text-xs hover:bg-red-900 transition"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="text-sm font-bold mb-3">AVAILABLE SPECIALISTS</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
            {SPECIALISTS.map(spec => (
              <div
                key={spec.id}
                className={`border-2 rounded p-3 cursor-pointer transition ${
                  game.selectedTeam.find(s => s.id === spec.id)
                    ? 'border-[#00ff00] bg-[#00ff00]/10'
                    : 'border-[#00ff00]/30 hover:border-[#00ff00]/60 bg-gray-900'
                }`}
                onClick={() => selectSpecialist(spec)}
              >
                <div className="font-bold text-base">{spec.name}</div>
                <div className="text-xs opacity-75 mb-2">{spec.role}</div>
                <div className="text-xs mb-2">{spec.skill}</div>
                <div className="flex justify-between text-xs opacity-50">
                  <span>Cost: {spec.cost} units</span>
                  <span>Bonus: +{spec.bonus}%</span>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={advanceToPlanning}
            disabled={game.selectedTeam.length !== 3}
            className="w-full bg-[#00ff00] text-black font-bold py-3 rounded hover:bg-[#00ff00]/80 transition text-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            📋 PROCEED TO PLANNING
          </button>
        </div>
      </div>
    );
  }

  if (game.screen === 'planning' && game.plan) {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setGame(prev => ({ ...prev, screen: 'team-assembly' }))}
          className="px-3 py-1.5 text-sm text-[#00ff00] hover:bg-[#00ff00]/10 rounded font-mono"
        >
          ← Back to Team
        </button>

        <div className="bg-black border-2 border-[#00ff00] rounded-lg p-6 font-mono text-[#00ff00]" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,255,0,0.03) 1px, transparent 1px)',
          backgroundSize: '100% 2px',
        }}>
          <div className="text-2xl font-bold mb-2">📋 OPERATION PLANNING</div>
          <div className="text-xs opacity-50 mb-6">Allocate resources across 5 phases (0-100 each).</div>

          <div className="space-y-4 mb-6">
            {[
              { key: 'reconnaissance' as const, label: '🔍 Reconnaissance', desc: 'Gather intel on target layout & security' },
              { key: 'toolPrep' as const, label: '🛠️ Tool Preparation', desc: 'Ready hacking tools & physical devices' },
              { key: 'entryStrategy' as const, label: '🚪 Entry Strategy', desc: 'Plan your infiltration approach' },
              { key: 'extractionPlan' as const, label: '💾 Extraction Plan', desc: 'Locate and secure valuable data' },
              { key: 'escapeRoute' as const, label: '🏃 Escape Route', desc: 'Define your getaway plan' },
            ].map(({ key, label, desc }) => (
              <div key={key} className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
                <div className="flex justify-between mb-2">
                  <div>
                    <div className="font-bold text-sm">{label}</div>
                    <div className="text-xs opacity-75">{desc}</div>
                  </div>
                  <div className="font-bold text-lg">{game.plan?.[key]}%</div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={game.plan?.[key] || 0}
                  onChange={(e) => updatePlanAllocation(key, parseInt(e.target.value))}
                  className="w-full h-2 bg-[#00ff00]/20 rounded appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #00ff00 0%, #00ff00 ${game.plan?.[key] || 0}%, rgba(0,255,0,0.2) ${game.plan?.[key] || 0}%, rgba(0,255,0,0.2) 100%)`
                  }}
                />
              </div>
            ))}
          </div>

          <div className="bg-gray-800 border border-[#00ff00]/30 rounded p-3 mb-6">
            <div className="text-xs opacity-50 mb-1">TEAM SYNERGY BONUS</div>
            <div className="text-lg font-bold">+{Math.round((game.selectedTeam.reduce((sum, s) => sum + s.bonus, 0) / 3))}%</div>
            <div className="text-xs opacity-75">From selected specialists</div>
          </div>

          <button
            onClick={executeHeist}
            className="w-full bg-[#ff0000] text-white font-bold py-3 rounded hover:bg-red-600 transition text-lg animate-pulse"
          >
            🚨 EXECUTE HEIST NOW
          </button>
        </div>
      </div>
    );
  }

  if (game.screen === 'results') {
    return (
      <div className="space-y-4">
        <div className="bg-black border-2 border-[#00ff00] rounded-lg p-6 font-mono text-[#00ff00]" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,255,0,0.03) 1px, transparent 1px)',
          backgroundSize: '100% 2px',
        }}>
          <div className="text-2xl font-bold mb-6">📡 EXECUTION LOG</div>
          
          <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-4 mb-6 max-h-96 overflow-y-auto space-y-1 text-sm font-mono">
            {game.executionLog.map((line, i) => (
              <div key={i} className={line.startsWith('✅') ? 'text-green-400' : line.startsWith('❌') ? 'text-red-400' : line.startsWith('⚠️') ? 'text-yellow-400' : ''}>
                {line}
              </div>
            ))}
          </div>

          {game.lastOutcome && (
            <div className={`border-2 rounded p-4 mb-6 ${game.lastOutcome.success ? 'border-green-500 bg-green-500/10' : 'border-red-500 bg-red-500/10'}`}>
              <div className="text-lg font-bold mb-2">
                {game.lastOutcome.success ? '✅ SUCCESS!' : '❌ FAILED'}
              </div>
              <div className="text-sm mb-3">{game.lastOutcome.message}</div>
              {game.lastOutcome.success && (
                <div className="text-2xl font-bold text-green-400">
                  +${game.lastOutcome.earnings.toLocaleString()}
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
              <div className="text-xs opacity-50 mb-1">CAREER TOTAL</div>
              <div className="text-2xl font-bold">${game.careerEarnings.toLocaleString()}</div>
            </div>
            <div className="bg-gray-900 border border-[#00ff00]/30 rounded p-3">
              <div className="text-xs opacity-50 mb-1">SUCCESS RATE</div>
              <div className="text-2xl font-bold">{game.totalAttempts > 0 ? Math.round((game.successfulHeists / game.totalAttempts) * 100) : 0}%</div>
            </div>
          </div>

          <button
            onClick={() => setGame(prev => ({ ...prev, screen: 'lobby' }))}
            className="w-full bg-[#00ff00] text-black font-bold py-3 rounded hover:bg-[#00ff00]/80 transition text-lg"
          >
            🎬 RETURN TO LOBBY
          </button>
        </div>
      </div>
    );
  }

  return null;
}
