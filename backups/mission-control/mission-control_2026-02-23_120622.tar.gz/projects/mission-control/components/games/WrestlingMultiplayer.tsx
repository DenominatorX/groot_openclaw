'use client';
import { useState, useEffect, useRef } from 'react';
import ChatPanel from './ChatPanel';

interface Player {
  id: string;
  name: string;
  avatar: string;
  score: number;
  streak: number;
  ready: boolean;
}

interface Question {
  question: string;
  options: string[];
  correct: number;
  funFact: string;
  difficulty: string;
  category: string;
}

interface Answer {
  playerId: string;
  answerIndex: number;
  timeMs: number;
  isCorrect: boolean;
}

interface ChatMessage {
  playerId: string;
  name: string;
  message: string;
  timestamp: string;
}

interface GameSettings {
  mode: string;
  category: string;
  questionCount: number;
  timePerQuestion: number;
  difficulty: string;
}

interface Room {
  code: string;
  hostId: string;
  players: Player[];
  settings: GameSettings;
  status: string;
  currentQuestion: number;
  question: Question | null;
  answers: Answer[];
  chat: ChatMessage[];
}

interface WrestlingMultiplayerProps {
  roomCode: string;
  playerId: string;
  playerName: string;
  room: Room;
  onGameEnd: () => void;
}

export default function WrestlingMultiplayer({
  roomCode,
  playerId,
  playerName,
  room: initialRoom,
  onGameEnd,
}: WrestlingMultiplayerProps) {
  const [room, setRoom] = useState<Room>(initialRoom);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [timeLeft, setTimeLeft] = useState(room.settings.timePerQuestion);
  const [questionStartTime] = useState(Date.now());
  const [showAnswers, setShowAnswers] = useState(false);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  // Poll for room updates
  useEffect(() => {
    const poll = async () => {
      try {
        const res = await fetch(
          `/api/games/wrestling-trivia/multiplayer?roomCode=${roomCode}&playerId=${playerId}`
        );
        const data = await res.json();

        if (data.success) {
          const safeRoom = { ...data.room, players: data.room.players || [], answers: data.room.answers || [], chat: data.room.chat || [] };
          setRoom(safeRoom);

          // Add new chat messages
          if (safeRoom.chat.length > 0) {
            setChatMessages(prev => [...prev, ...data.room.chat]);
          }

          // Check if we should move to next question
          if (data.room.status === 'finished') {
            onGameEnd();
          }
        }
      } catch (error) {
        console.error('Polling error:', error);
      }
    };

    pollingRef.current = setInterval(poll, 1000);

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, [roomCode, playerId, onGameEnd]);

  // Timer
  useEffect(() => {
    if (!answered && room.status === 'playing' && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }

    if (timeLeft === 0 && !answered && room.status === 'playing') {
      handleAnswer(null);
    }
  }, [timeLeft, answered, room.status]);

  const handleAnswer = async (answerIndex: number | null) => {
    if (answered || room.status !== 'playing') return;

    setAnswered(true);
    const timeMs = Date.now() - questionStartTime;

    try {
      await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'answer',
          roomCode,
          playerId,
          questionIndex: room.currentQuestion,
          answerIndex,
          timeMs,
        }),
      });

      setShowAnswers(true);

      // Move to next question after delay
      setTimeout(async () => {
        const res = await fetch('/api/games/wrestling-trivia/multiplayer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'next',
            roomCode,
          }),
        });

        const data = await res.json();
        if (data.success) {
          setRoom(data.room);
          setSelectedAnswer(null);
          setAnswered(false);
          setTimeLeft(data.room.settings.timePerQuestion);
          setShowAnswers(false);
        }
      }, 2000);
    } catch (error) {
      console.error('Failed to submit answer:', error);
    }
  };

  const sendChatMessage = async (message: string) => {
    try {
      await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          roomCode,
          playerId,
          message,
        }),
      });
    } catch (error) {
      console.error('Failed to send chat:', error);
    }
  };

  if (room.status === 'finished') {
    // Final podium
    const sortedPlayers = [...room.players].sort((a, b) => b.score - a.score);

    return (
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
          
          .wrestling-title {
            font-family: 'Righteous', cursive;
            font-size: 2.5rem;
            font-weight: 900;
            color: #FFD700;
            text-shadow: 
              2px 2px 0 #DC143C,
              4px 4px 0 #000,
              6px 6px 0 #0000FF;
          }

          .ring-rope {
            border: 3px solid;
            border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
            box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
          }

          .championship-belt {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
            color: #1a1a1a;
            font-weight: 900;
          }
        `}</style>

        <div className="wrestling-title">🏆 CHAMPIONSHIP PODIUM 🏆</div>

        <div className="grid md:grid-cols-3 gap-6">
          {sortedPlayers.slice(0, 3).map((player, idx) => {
            const medals = ['🥇', '🥈', '🥉'];
            const titles = ['CHAMPION', '2ND PLACE', '3RD PLACE'];
            const heights = ['h-80', 'h-72', 'h-64'];

            return (
              <div key={player.id} className={`flex flex-col items-center ${heights[idx]}`}>
                {idx === 0 && <div className="text-6xl mb-2">👑</div>}

                <div className={`flex-grow w-full ${idx === 0 ? 'bg-gradient-to-b from-yellow-500 to-yellow-600' : idx === 1 ? 'bg-gradient-to-b from-gray-400 to-gray-500' : 'bg-gradient-to-b from-orange-600 to-orange-700'} rounded-t-lg ring-rope flex flex-col items-center justify-end pb-4`}>
                  <div className="text-5xl mb-2">{player.avatar}</div>
                  <div className="text-xl font-bold">{player.name}</div>
                  <div className="text-3xl font-bold text-white">{medals[idx]}</div>
                </div>

                <div className="w-full bg-slate-800 p-4 rounded-b-lg ring-rope">
                  <div className="text-xs font-bold text-yellow-400">{titles[idx]}</div>
                  <div className="text-2xl font-bold text-white">{player.score.toLocaleString()}</div>
                </div>
              </div>
            );
          })}
        </div>

        <button
          onClick={onGameEnd}
          className="w-full py-4 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold text-lg rounded ring-rope transform hover:scale-105 transition-all"
        >
          🎪 NEW GAME
        </button>
      </div>
    );
  }

  if (room.status !== 'playing' || !room.question) {
    return (
      <div className="text-center text-white p-4">
        <div className="text-2xl font-bold">Waiting for game to start...</div>
      </div>
    );
  }

  const question = room.question;
  const playerAnswer = room.answers.find(a => a.playerId === playerId);
  const allAnswered = room.answers.length === room.players.length;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
        
        .wrestling-title {
          font-family: 'Righteous', cursive;
          font-size: 1.5rem;
          font-weight: 900;
          color: #FFD700;
          text-shadow: 2px 2px 0 #DC143C;
        }

        .ring-rope {
          border: 3px solid;
          border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
          box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
        }

        .championship-belt {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
          color: #1a1a1a;
          font-weight: 900;
        }

        .scoreboard-entry {
          transition: all 0.3s ease;
        }
      `}</style>

      {/* Main Game Area */}
      <div className="lg:col-span-3 space-y-4">
        {/* Header */}
        <div className="championship-belt p-4 rounded-lg">
          <div className="text-sm font-semibold">MATCH PROGRESS</div>
          <div className="text-2xl font-bold">
            Question {room.currentQuestion + 1} / {room.settings.questionCount}
          </div>
        </div>

        {/* Question */}
        <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
          <div className="text-xs font-bold text-yellow-400 uppercase">
            {question.category} • {question.difficulty}
          </div>
          <div className="text-2xl font-bold text-white">{question.question}</div>
          <div className="h-1 bg-gradient-to-r from-red-600 via-yellow-400 to-blue-600 rounded-full" />
        </div>

        {/* Timer */}
        <div className="bg-slate-800 p-3 rounded-lg ring-rope">
          <div className={`text-center text-3xl font-bold ${timeLeft <= 5 ? 'text-red-500 animate-pulse' : 'text-yellow-400'}`}>
            ⏱️ {timeLeft}s
          </div>
        </div>

        {/* Answers */}
        <div className="space-y-3">
          {(question.options || []).map((option, idx) => {
            const isSelected = selectedAnswer === idx;
            const isCorrect = idx === question.correct;
            const showCorrect = showAnswers && isCorrect;
            const showWrong = showAnswers && isSelected && !isCorrect;
            const playerSelected = playerAnswer && playerAnswer.answerIndex === idx;

            return (
              <button
                key={idx}
                onClick={() => !answered && setSelectedAnswer(idx)}
                onDoubleClick={() => !answered && handleAnswer(idx)}
                disabled={answered}
                className={`w-full p-4 rounded-lg font-bold text-left transition-all ${
                  showCorrect
                    ? 'bg-green-600 text-white border-2 border-green-400'
                    : showWrong
                    ? 'bg-red-600 text-white border-2 border-red-400'
                    : isSelected
                    ? 'bg-yellow-500 text-black border-2 border-yellow-300'
                    : 'bg-slate-700 hover:bg-slate-600 text-white border-2 border-slate-600'
                } ${answered ? 'cursor-not-allowed' : 'cursor-pointer'}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">
                      {showCorrect ? '✓' : showWrong ? '✗' : ['A', 'B', 'C', 'D'][idx]}
                    </span>
                    <span>{option}</span>
                  </div>
                  {playerSelected && !showAnswers && <span className="text-lg">👉</span>}
                </div>
              </button>
            );
          })}
        </div>

        {/* Hint */}
        {showAnswers && (
          <div className="p-4 bg-slate-800 border-l-4 border-yellow-400 rounded-lg">
            <div className="text-xs font-bold text-yellow-400 mb-2">💡 DID YOU KNOW?</div>
            <div className="text-sm text-white">{question.funFact}</div>
          </div>
        )}
      </div>

      {/* Right Sidebar */}
      <div className="space-y-4">
        {/* Scoreboard */}
        <div className="bg-slate-800 p-4 rounded-lg ring-rope space-y-3">
          <div className="wrestling-title text-center text-sm">LEADERBOARD</div>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {[...room.players]
              .sort((a, b) => b.score - a.score)
              .map((player, idx) => {
                const leader = idx === 0;
                const isMe = player.id === playerId;

                return (
                  <div
                    key={player.id}
                    className={`scoreboard-entry p-2 rounded text-sm font-semibold transition-all ${
                      isMe
                        ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-black'
                        : leader
                        ? 'bg-gradient-to-r from-yellow-600 to-yellow-700 text-white'
                        : 'bg-slate-700 text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-2 flex-1">
                        <span className="text-lg">{player.avatar}</span>
                        <div className="flex-1 min-w-0">
                          <div className="truncate text-xs">{player.name}</div>
                        </div>
                        {leader && <span>👑</span>}
                      </div>
                      <div className="text-right whitespace-nowrap">
                        <div>{player.score.toLocaleString()}</div>
                        {player.streak > 0 && <div className="text-xs">🔥 {player.streak}</div>}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* Status */}
        <div className="bg-slate-800 p-4 rounded-lg ring-rope text-center text-sm">
          <div className="text-xs font-bold text-yellow-400 mb-2">STATUS</div>
          {answered ? (
            <div className="text-green-400 font-bold">✓ Answer Submitted</div>
          ) : (
            <div className="text-blue-400 font-bold">⏳ Answering...</div>
          )}
        </div>
      </div>

      {/* Chat Panel */}
      <div className="lg:col-span-4">
        <ChatPanel
          roomCode={roomCode}
          playerId={playerId}
          playerName={playerName}
          messages={chatMessages}
          onSendMessage={sendChatMessage}
        />
      </div>
    </div>
  );
}
