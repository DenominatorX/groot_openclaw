'use client';
import { useState } from 'react';

interface VoiceChatProps {
  roomCode: string;
  playerId: string;
  playerName: string;
  players: Array<{ id: string; name: string; avatar: string }>;
}

export default function VoiceChat({
  roomCode,
  playerId,
  playerName,
  players,
}: VoiceChatProps) {
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(100);
  const [isCollapsed, setIsCollapsed] = useState(true);

  if (isCollapsed) {
    return (
      <button
        onClick={() => setIsCollapsed(false)}
        className="fixed bottom-4 left-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-full p-4 shadow-lg z-40"
      >
        🎙️
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 left-4 w-72 bg-slate-800 rounded-lg ring-rope overflow-hidden shadow-xl z-40">
      <style>{`
        .ring-rope {
          border: 3px solid;
          border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
          box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
        }

        .championship-belt {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
          color: #1a1a1a;
          font-weight: 900;
        }
      `}</style>

      {/* Header */}
      <div className="championship-belt p-3 flex items-center justify-between">
        <div className="font-bold text-sm">VOICE CHAT 🎙️</div>
        <button
          onClick={() => setIsCollapsed(true)}
          className="text-lg font-bold hover:scale-110"
        >
          ⎯
        </button>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Coming Soon Banner */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 rounded-lg text-center">
          <div className="text-2xl mb-2">🚀</div>
          <div className="font-bold text-white">Voice Chat</div>
          <div className="text-sm text-blue-100 mt-1">Coming Soon!</div>
          <div className="text-xs text-blue-100 mt-2">
            WebRTC voice support will be enabled in the next update.
          </div>
        </div>

        {/* Controls (Disabled) */}
        <div className="space-y-3 opacity-50">
          {/* Voice Toggle */}
          <button
            disabled
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded text-sm transition-colors flex items-center justify-center gap-2"
          >
            🎤 {voiceEnabled ? 'Voice On' : 'Voice Off'}
          </button>

          {/* Mute Toggle */}
          <button
            disabled
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded text-sm transition-colors flex items-center justify-center gap-2"
          >
            {isMuted ? '🔇' : '🔊'} {isMuted ? 'Unmute' : 'Mute Me'}
          </button>

          {/* Volume Control */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-white">Volume</label>
            <input
              type="range"
              min="0"
              max="100"
              value={volume}
              onChange={e => setVolume(parseInt(e.target.value))}
              disabled
              className="w-full"
            />
            <div className="text-xs text-gray-400 text-right">{volume}%</div>
          </div>
        </div>

        {/* Active Players */}
        <div className="bg-slate-700 rounded-lg p-3">
          <div className="text-xs font-bold text-yellow-400 mb-2">CONNECTED PLAYERS</div>
          <div className="space-y-1">
            {players.map(player => (
              <div
                key={player.id}
                className={`flex items-center gap-2 p-2 rounded text-sm ${
                  player.id === playerId
                    ? 'bg-yellow-600 text-white font-semibold'
                    : 'bg-slate-600 text-white'
                }`}
              >
                <span className="text-lg">{player.avatar}</span>
                <span className="flex-1 truncate text-xs">{player.name}</span>
                <span className="text-xs opacity-50">🔇</span>
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="text-xs text-gray-400 text-center">
          Text chat is available now! 💬
        </div>
      </div>
    </div>
  );
}
