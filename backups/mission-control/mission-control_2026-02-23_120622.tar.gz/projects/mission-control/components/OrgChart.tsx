'use client';
import { useEffect, useState, useRef, useCallback } from 'react';

const CHARACTER_EMOJIS: Record<string, string> = {
  lobster: '🦞', robot: '🤖', humanoid: '🧑', orb: '🔮',
  mech: '⚙️', ghost: '👻', cat: '🐱', tree: '🌳',
};

const TIER_BADGES: Record<number, { label: string; color: string; bg: string }> = {
  0: { label: 'OWNER', color: 'text-yellow-400', bg: 'bg-yellow-500/20' },
  1: { label: 'EXEC', color: 'text-purple-400', bg: 'bg-purple-500/20' },
  2: { label: 'VP', color: 'text-blue-400', bg: 'bg-blue-500/20' },
  3: { label: 'DIR', color: 'text-cyan-400', bg: 'bg-cyan-500/20' },
  4: { label: 'SR', color: 'text-green-400', bg: 'bg-green-500/20' },
  5: { label: 'MGR', color: 'text-orange-400', bg: 'bg-orange-500/20' },
  6: { label: 'FW', color: 'text-gray-400', bg: 'bg-gray-500/20' },
};

interface Agent {
  id: string;
  name: string;
  tier: number;
  status: string;
  color: string;
  avatarType?: string;
  model?: string | null;
  parent?: string | null;
  role: string;
  isExecutiveBoard?: boolean;
}

interface Props {
  onSelectAgent?: (agentId: string) => void;
}

export default function OrgChart({ onSelectAgent }: Props) {
  const [agents, setAgents] = useState<Agent[]>([]);

  useEffect(() => {
    fetch('/api/agents').then(r => r.json()).then(d => setAgents(d.agents || [])).catch(() => {});
  }, []);

  // Auto-scroll to center tier-0 (owner) node when data loads
  useEffect(() => {
    if (agents.length === 0) return;
    
    // Find the owner node (tier 0 or role='Owner')
    const ownerNode = agents.find(a => a.tier === 0 || a.role === 'Owner');
    if (!ownerNode) return;

    // Delay to ensure DOM is rendered
    setTimeout(() => {
      const ownerEl = document.querySelector(`[data-agent-id="${ownerNode.id}"]`) as HTMLElement;
      if (ownerEl) {
        ownerEl.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
      }
    }, 100);
  }, [agents]);

  // Build tree: root nodes have no parent
  const roots = agents.filter(a => !a.parent);
  const childrenOf = (parentId: string) => agents.filter(a => a.parent === parentId);

  const renderNode = (agent: Agent) => {
    const emoji = CHARACTER_EMOJIS[agent.avatarType || 'lobster'] || '🦞';
    const tier = TIER_BADGES[agent.tier] || TIER_BADGES[6];
    const children = childrenOf(agent.id);
    const modelShort = agent.model ? agent.model.split('/').pop() : 'default';

    return (
      <div key={agent.id} className="flex flex-col items-center">
        <button
          data-agent-id={agent.id}
          onClick={() => onSelectAgent?.(agent.id)}
          className="relative bg-mc-surface border border-mc-border rounded-xl px-4 py-3 hover:border-mc-accent transition-all cursor-pointer group min-w-[140px]"
        >
          <div className="flex flex-col items-center gap-1">
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl relative"
              style={{ backgroundColor: agent.color + '22', border: `2px solid ${agent.color}` }}>
              {emoji}
              <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-mc-surface ${
                agent.status === 'active' ? 'bg-green-500' : 'bg-gray-500'
              }`} />
            </div>
            <span className="text-sm font-semibold group-hover:text-mc-accent transition-colors">{agent.name}</span>
            <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${tier.color} ${tier.bg}`}>{tier.label}</span>
            <span className="text-[9px] text-mc-muted truncate max-w-[120px]">{modelShort}</span>
          </div>
        </button>

        {children.length > 0 && (
          <>
            {/* Vertical line down */}
            <div className="w-px h-6 bg-mc-border" />
            {/* Horizontal connector + children */}
            <div className="relative flex items-start">
              {children.length > 1 && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-px bg-mc-border"
                  style={{ width: `calc(100% - 140px)` }} />
              )}
              <div className="flex gap-4">
                {children.map(child => (
                  <div key={child.id} className="flex flex-col items-center">
                    <div className="w-px h-6 bg-mc-border" />
                    {renderNode(child)}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    );
  };

  // Pan & zoom state
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.85);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, panX: 0, panY: 0 });

  const pinchStart = useRef<{ dist: number; zoom: number }>({ dist: 0, zoom: 0.85 });

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    setZoom(z => Math.min(2, Math.max(0.2, z - e.deltaY * 0.001)));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
  }, [pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!dragging) return;
    setPan({
      x: dragStart.current.panX + (e.clientX - dragStart.current.x),
      y: dragStart.current.panY + (e.clientY - dragStart.current.y),
    });
  }, [dragging]);

  const handleMouseUp = useCallback(() => setDragging(false), []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setDragging(true);
      dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, panX: pan.x, panY: pan.y };
    } else if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      pinchStart.current = { dist: Math.hypot(dx, dy), zoom };
    }
  }, [pan, zoom]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (e.touches.length === 1 && dragging) {
      setPan({
        x: dragStart.current.panX + (e.touches[0].clientX - dragStart.current.x),
        y: dragStart.current.panY + (e.touches[0].clientY - dragStart.current.y),
      });
    } else if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const scale = dist / pinchStart.current.dist;
      setZoom(Math.min(2, Math.max(0.2, pinchStart.current.zoom * scale)));
    }
  }, [dragging]);

  const handleTouchEnd = useCallback(() => setDragging(false), []);

  const resetView = useCallback(() => { setZoom(0.85); setPan({ x: 0, y: 0 }); }, []);

  // Group roots: owner first, then exec board, then others
  const owner = roots.find(a => a.tier === 0);
  const execBoard = roots.filter(a => a.tier !== 0 && a.isExecutiveBoard);
  const otherRoots = roots.filter(a => a.tier !== 0 && !a.isExecutiveBoard);

  return (
    <div
      ref={containerRef}
      className="relative overflow-hidden select-none"
      style={{ height: 'calc(100vh - 200px)', cursor: dragging ? 'grabbing' : 'grab', touchAction: 'none' }}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div className="absolute top-3 left-3 z-10 flex gap-2">
        <span className="text-xs text-mc-muted bg-mc-surface/80 px-2 py-1 rounded">Scroll to zoom · Drag to pan</span>
        <button onClick={resetView} className="text-xs bg-mc-surface/80 px-2 py-1 rounded hover:text-mc-accent transition-colors">Reset View</button>
        <button onClick={() => setZoom(z => Math.min(2, z + 0.15))} className="text-xs bg-mc-surface/80 px-2 py-1 rounded hover:text-mc-accent">+</button>
        <button onClick={() => setZoom(z => Math.max(0.2, z - 0.15))} className="text-xs bg-mc-surface/80 px-2 py-1 rounded hover:text-mc-accent">−</button>
      </div>
      <div
        className="p-4"
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: 'top center', transition: dragging ? 'none' : 'transform 0.1s ease' }}
      >
      <h2 className="text-lg font-bold mb-6 text-center">📊 Organization Chart</h2>
      <div className="flex flex-col items-center min-w-max">
        {/* Owner at top */}
        {owner && (
          <>
            {renderNode(owner)}
            {(execBoard.length > 0 || otherRoots.length > 0) && (
              <div className="w-px h-6 bg-mc-border" />
            )}
          </>
        )}

        {/* Executive Board row */}
        {execBoard.length > 0 && (
          <>
            <div className="relative flex items-start">
              {execBoard.length > 1 && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-px bg-mc-border"
                  style={{ width: `calc(100% - 140px)` }} />
              )}
              <div className="flex gap-4">
                {execBoard.map(agent => (
                  <div key={agent.id} className="flex flex-col items-center">
                    <div className="w-px h-6 bg-mc-border" />
                    {renderNode(agent)}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Other roots */}
        {otherRoots.length > 0 && (
          <div className="mt-6">
            <div className="flex gap-4 justify-center">
              {otherRoots.map(agent => renderNode(agent))}
            </div>
          </div>
        )}
      </div>
      </div>
    </div>
  );
}
