'use client';
import { useState } from 'react';
import PrePromptApp from './apps/PrePromptApp';
import GetToKnowPanel from './apps/GetToKnowPanel';
import MediaVaultPanel from './apps/MediaVaultPanel';
import MaxTargetApp from './apps/MaxTargetApp';
import PodcastHubApp from './apps/PodcastHubApp';
import InvoiceApp from './apps/InvoiceApp';
import CourseBuilderApp from './apps/CourseBuilderApp';
import { PitchDeckApp } from './apps/PitchDeckApp';
import HabitForgeApp from './apps/HabitForgeApp';
import TweetAnalyzerApp from './apps/TweetAnalyzerApp';

type AppId = 'preprompt' | 'get-to-know' | 'media-vault' | 'maxtarget' | 'podcast-hub' | 'invoice' | 'course-builder' | 'pitch-deck' | 'habit-forge' | 'tweet-analyzer' | null;

interface AppDef {
  id: AppId;
  name: string;
  icon: string;
  description: string;
  status: 'available' | 'coming-soon';
  component?: React.ComponentType<any>;
}

const APPS: AppDef[] = [
  {
    id: 'preprompt',
    name: 'PrePrompt',
    icon: '🎯',
    description: 'Prompt engineering, optimization, templates, and AI detection',
    status: 'available',
    component: PrePromptApp,
  },
  {
    id: 'get-to-know',
    name: 'Get to Know You',
    icon: '🤝',
    description: 'Answer personality questions and build your profile',
    status: 'available',
    component: GetToKnowPanel,
  },
  {
    id: 'media-vault',
    name: 'Media Vault',
    icon: '🖼️',
    description: 'Save and organize links and images',
    status: 'available',
    component: MediaVaultPanel,
  },
  {
    id: 'maxtarget',
    name: 'MaxTarget',
    icon: '📈',
    description: 'Marketing command center — leads, campaigns, content & analytics',
    status: 'available',
    component: MaxTargetApp,
  },
  {
    id: 'podcast-hub',
    name: 'Podcast Hub',
    icon: '🎙️',
    description: 'Production & Guest Management — shows, episodes, people, promotion & analytics',
    status: 'available',
    component: PodcastHubApp,
  },
  {
    id: 'invoice',
    name: 'Invoice & Client Manager',
    icon: '🧾',
    description: 'Professional invoicing and client management for freelancers and agencies',
    status: 'available',
    component: InvoiceApp,
  },
  {
    id: 'course-builder',
    name: 'Course Builder',
    icon: '🎓',
    description: 'AI-powered course creation platform — outline, content, quiz, certificate generation',
    status: 'available',
    component: CourseBuilderApp,
  },
  {
    id: 'pitch-deck',
    name: 'Pitch Deck Builder',
    icon: '📊',
    description: 'AI-powered pitch deck creation for entrepreneurs and startups — templates, content generation, investor research',
    status: 'available',
    component: PitchDeckApp,
  },
  {
    id: 'habit-forge',
    name: 'Habit Forge',
    icon: '🔥',
    description: 'Gamified habit tracking with AI coaching — build streaks, level up, and transform your life!',
    status: 'available',
    component: HabitForgeApp,
  },
  {
    id: 'tweet-analyzer',
    name: 'Tweet Analyzer',
    icon: '🐦',
    description: 'X Intelligence Hub — Analyze any tweet with full research, team assessments, and compatibility scoring',
    status: 'available',
    component: TweetAnalyzerApp,
  },
  {
    id: null,
    name: 'Universal Bookmarks',
    icon: '🔖',
    description: 'Organize and manage your bookmarks across all platforms',
    status: 'coming-soon',
  },
  {
    id: null,
    name: 'Supplement Calculator',
    icon: '🧮',
    description: 'Plan and optimize your supplement regimen',
    status: 'coming-soon',
  },
  {
    id: null,
    name: 'Portfolio Tracker',
    icon: '📊',
    description: 'Monitor your investments and asset allocation',
    status: 'coming-soon',
  },
  {
    id: null,
    name: 'Mind Map',
    icon: '🧠',
    description: 'Visually organize ideas and concepts',
    status: 'coming-soon',
  },
];

export default function AppsTab() {
  const [openApp, setOpenApp] = useState<AppId>(null);

  // If an app is open, render it full-screen
  if (openApp) {
    const app = APPS.find(a => a.id === openApp);
    if (app?.component) {
      const Comp = app.component;
      return (
        <div>
          <button
            onClick={() => setOpenApp(null)}
            className="mb-4 px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
          >
            ← Back to Apps
          </button>
          <Comp />
        </div>
      );
    }
  }

  // Show app grid/store
  return (
    <div className="space-y-4">
      <div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {APPS.map(app => (
            <div
              key={app.name}
              className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition-colors"
            >
              <div className="text-3xl mb-3">{app.icon}</div>
              <h3 className="text-base font-semibold text-mc-text mb-2">{app.name}</h3>
              <p className="text-sm text-mc-muted mb-4">{app.description}</p>

              {app.status === 'available' ? (
                <button
                  onClick={() => setOpenApp(app.id)}
                  className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium text-sm transition-colors"
                >
                  🚀 Open
                </button>
              ) : (
                <div className="w-full px-4 py-2 bg-gray-700/30 text-gray-500 rounded text-sm text-center">
                  🔜 Coming Soon
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
