'use client';
import { useEffect, useState, useRef } from 'react';

interface Report {
  id: string;
  title: string;
  type: string;
  projectId: string | null;
  content: string;
  createdAt: string;
  createdBy: string;
  tags?: string[];
  author?: string;
  agentId?: string;
  status?: string;
  testResults?: Record<string, 'pass' | 'fail' | 'skip' | 'untested'>;
}

interface Project {
  id: string;
  title: string;
  status?: string;
}

interface CustomReportType {
  id: string; label: string; icon: string; category: string;
}

const BUILT_IN_REPORT_TYPES = [
  // Project
  { id: 'prd', label: 'PRD', icon: '📄', category: 'project' },
  { id: 'design', label: 'Design Doc', icon: '🎨', category: 'project' },
  { id: 'tech-spec', label: 'Tech Spec', icon: '⚙️', category: 'project' },
  { id: 'status', label: 'Status Report', icon: '📊', category: 'project' },
  { id: 'meeting', label: 'Meeting Notes', icon: '📝', category: 'project' },
  { id: 'task-breakdown', label: 'Task Breakdown / WBS', icon: '📋', category: 'project' },
  { id: 'completion-report', label: 'Completion Report', icon: '✅', category: 'project' },
  { id: 'retrospective', label: 'Retrospective / Post-Mortem', icon: '🔄', category: 'project' },
  { id: 'architecture-doc', label: 'Architecture Doc', icon: '🏗️', category: 'project' },
  { id: 'api-documentation', label: 'API Documentation', icon: '🔌', category: 'project' },
  { id: 'user-guide', label: 'User Guide / Manual', icon: '📖', category: 'project' },
  { id: 'release-notes', label: 'Release Notes', icon: '🚀', category: 'project' },
  { id: 'requirements-doc', label: 'Requirements Doc', icon: '📝', category: 'project' },
  { id: 'sprint-planning', label: 'Sprint Planning', icon: '🎯', category: 'project' },
  { id: 'stakeholder-brief', label: 'Stakeholder Brief', icon: '👔', category: 'project' },
  // System
  { id: 'weekly-summary', label: 'Weekly Summary', icon: '📅', category: 'system' },
  { id: 'agent-performance', label: 'Agent Performance', icon: '🤖', category: 'system' },
  { id: 'cost-analysis', label: 'Cost Analysis', icon: '💰', category: 'system' },
  { id: 'system-health', label: 'System Health', icon: '🖥️', category: 'system' },
  { id: 'security-audit', label: 'Security Audit Report', icon: '🔒', category: 'system' },
  { id: 'infrastructure-report', label: 'Infrastructure Report', icon: '🖧', category: 'system' },
  { id: 'dependency-audit', label: 'Dependency Audit', icon: '📦', category: 'system' },
  // Personal Health
  { id: 'personal-health', label: 'Personal Health', icon: '❤️', category: 'personal-health' },
  { id: 'health-report', label: 'Health Report', icon: '🏥', category: 'personal-health' },
  { id: 'supplement-report', label: 'Supplement Report', icon: '💊', category: 'personal-health' },
  { id: 'exercise-protocol', label: 'Exercise Protocol', icon: '🏋️', category: 'personal-health' },
  { id: 'mayo-clinic-prep', label: 'Mayo Clinic Prep', icon: '🏥', category: 'personal-health' },
  // Legal
  { id: 'legal-report', label: 'Legal Report', icon: '⚖️', category: 'legal' },
  { id: 'malpractice-assessment', label: 'Malpractice Assessment', icon: '⚖️', category: 'legal' },
  { id: 'contract-review', label: 'Contract Review', icon: '📃', category: 'legal' },
  // Memory
  { id: 'life-timeline', label: 'Life Timeline Report', icon: '🧠', category: 'memory' },
  { id: 'family-history', label: 'Family History', icon: '👨‍👩‍👧‍👦', category: 'memory' },
];

// Category definitions for sectioned display
const REPORT_CATEGORIES = [
  { id: 'personal-health', label: 'Personal Health', icon: '❤️', description: 'Medical records, Mayo prep, supplement plans' },
  { id: 'legal', label: 'Legal', icon: '⚖️', description: 'Legal assessments, malpractice reviews, contracts' },
  { id: 'system', label: 'System Health', icon: '🖥️', description: 'Dashboard metrics, agent performance, costs' },
  { id: 'project', label: 'Projects', icon: '📁', description: 'PRDs, specs, status reports' },
  { id: 'memory', label: 'Memory', icon: '🧠', description: 'Life timeline, family history, personal archives' },
];

function buildTypeLabels(types: CustomReportType[]) {
  const labels: Record<string, string> = {};
  for (const t of types) labels[t.id] = `${t.icon} ${t.label}`;
  return labels;
}

async function fetchAnalyticsData() {
  try {
    const [tasks, agents, activity, analytics] = await Promise.all([
      fetch('/api/tasks').then(r => r.json()).catch(() => ({ tasks: [] })),
      fetch('/api/agents').then(r => r.json()).catch(() => ({ agents: [] })),
      fetch('/api/activity').then(r => r.json()).catch(() => ({ entries: [] })),
      fetch('/api/analytics').then(r => r.json()).catch(() => null),
    ]);
    return { tasks: tasks.tasks || [], agents: agents.agents || [], activity: activity.entries || [], analytics };
  } catch { return { tasks: [], agents: [], activity: [], analytics: null }; }
}

function generateTemplate(type: string, projectTitle: string, liveData?: any): string {
  const date = new Date().toLocaleDateString();
  const d = liveData || {};
  switch (type) {
    case 'prd':
      return `# Product Requirements Document\n\n**Project:** ${projectTitle}\n**Date:** ${date}\n**Author:** Kevin Lane\n\n## Overview\n\n_Describe the product and its purpose._\n\n## Goals\n\n- Goal 1\n- Goal 2\n\n## Requirements\n\n### Functional\n\n1. \n\n### Non-Functional\n\n1. \n\n## Success Metrics\n\n| Metric | Target |\n|--------|--------|\n| | |\n\n## Timeline\n\n| Phase | Date | Description |\n|-------|------|-------------|\n| | | |\n`;
    case 'design':
      return `# Design Document\n\n**Project:** ${projectTitle}\n**Date:** ${date}\n\n## Design Goals\n\n## Architecture\n\n## UI/UX\n\n## Data Model\n\n## Open Questions\n`;
    case 'tech-spec':
      return `# Technical Specification\n\n**Project:** ${projectTitle}\n**Date:** ${date}\n\n## Stack\n\n## Architecture\n\n## API Endpoints\n\n## Database Schema\n\n## Deployment\n\n## Security Considerations\n`;
    case 'status':
      return `# Status Report\n\n**Project:** ${projectTitle}\n**Date:** ${date}\n\n## Summary\n\n## Completed This Week\n\n- \n\n## In Progress\n\n- \n\n## Blockers\n\n- \n\n## Next Steps\n\n- \n`;
    case 'meeting':
      return `# Meeting Notes\n\n**Project:** ${projectTitle}\n**Date:** ${date}\n\n## Attendees\n\n- \n\n## Agenda\n\n1. \n\n## Discussion\n\n## Action Items\n\n- [ ] \n\n## Next Meeting\n\n`;
    case 'weekly-summary': {
      const tasks = d.tasks || [];
      const activity = d.activity || [];
      const analytics = d.analytics?.summary || {};
      const inProgress = tasks.filter((t: any) => t.column === 'in-progress');
      const completed = tasks.filter((t: any) => t.column === 'complete');
      const review = tasks.filter((t: any) => t.column === 'review');
      return `# Weekly Summary Report\n\n**Date:** ${date}\n**Generated:** Auto-generated from live data\n\n## Task Overview\n\n| Status | Count |\n|--------|-------|\n| Total Tasks | ${tasks.length} |\n| In Progress | ${inProgress.length} |\n| In Review | ${review.length} |\n| Completed | ${completed.length} |\n\n## In Progress\n\n${inProgress.map((t: any) => `- **${t.title}** (${t.assignee || 'Unassigned'}) — ${t.priority}`).join('\n') || '- None'}\n\n## Recently Completed\n\n${completed.slice(0, 10).map((t: any) => `- ✅ ${t.title}`).join('\n') || '- None'}\n\n## Activity Summary\n\n- Total activities this period: ${activity.length}\n- Active agents: ${analytics.activeAgents || '—'}\n- Projects in progress: ${analytics.projectsInProgress || '—'}\n\n## Key Events\n\n${activity.slice(-10).map((e: any) => `- ${new Date(e.timestamp).toLocaleDateString()} — **${e.agent}**: ${e.action}${e.details ? ` (${e.details})` : ''}`).join('\n') || '- None'}\n`;
    }
    case 'agent-performance': {
      const agents = d.agents || [];
      const agentActions = d.analytics?.agentActions || {};
      return `# Agent Performance Report\n\n**Date:** ${date}\n**Generated:** Auto-generated from live data\n\n## Agent Activity\n\n| Agent | Tier | Messages | Tasks | Sessions | Actions (7d) |\n|-------|------|----------|-------|----------|---------------|\n${agents.map((a: any) => `| ${a.name} | ${a.tier} | ${a.stats?.messagesExchanged || 0} | ${a.stats?.tasksCompleted || 0} | ${a.stats?.sessionsStarted || 0} | ${agentActions[a.name] || 0} |`).join('\n')}\n\n## Top Performers\n\n${agents.sort((a: any, b: any) => (b.stats?.messagesExchanged || 0) - (a.stats?.messagesExchanged || 0)).slice(0, 5).map((a: any, i: number) => `${i + 1}. **${a.name}** — ${a.stats?.messagesExchanged || 0} messages`).join('\n')}\n\n## Notes\n\n- Performance data based on tracked metrics\n- Activity window: last 7 days\n`;
    }
    case 'cost-analysis': {
      const agents = d.agents || [];
      const tierCosts: Record<number, number> = { 0: 0, 1: 0.015, 2: 0.003, 3: 0.005, 4: 0.0008, 5: 0.0002, 6: 0.0001 };
      const tierLabels: Record<number, string> = { 0: 'Owner', 1: 'Executive', 2: 'VP', 3: 'Director', 4: 'Sr. Manager', 5: 'Manager', 6: 'Frontline' };
      let totalCost = 0;
      const tierRows = [0,1,2,3,4,5,6].map(tier => {
        const ta = agents.filter((a: any) => a.tier === tier);
        const msgs = ta.reduce((s: number, a: any) => s + (a.stats?.messagesExchanged || 0), 0);
        const tokens = msgs * 500;
        const cost = (tokens / 1000) * (tierCosts[tier] || 0);
        totalCost += cost;
        return `| ${tierLabels[tier]} (T${tier}) | ${ta.length} | ${msgs.toLocaleString()} | ${(tokens/1000).toFixed(0)}k | $${tierCosts[tier]} | $${cost.toFixed(2)} |`;
      });
      return `# Cost Analysis Report\n\n**Date:** ${date}\n**Generated:** Auto-generated from live data\n\n## Cost by Tier\n\n| Tier | Agents | Messages | Est. Tokens | Cost/1k | Est. Cost |\n|------|--------|----------|-------------|---------|----------|\n${tierRows.join('\n')}\n\n**Total Estimated Cost: $${totalCost.toFixed(2)}**\n\n## Notes\n\n- Token estimates based on ~500 tokens per message average\n- Actual costs may vary based on prompt/completion ratio\n- Local models (Tier 5-6) have negligible API cost\n`;
    }
    case 'system-health':
    case 'health-report': {
      const analytics = d.analytics?.summary || {};
      return `# System Health Report\n\n**Date:** ${date}\n**Generated:** Auto-generated\n\n## Overview\n\n| Metric | Value |\n|--------|-------|\n| Total Tasks | ${analytics.totalTasks || '—'} |\n| Active Agents | ${analytics.activeAgents || '—'} / ${analytics.totalAgents || '—'} |\n| Projects In Progress | ${analytics.projectsInProgress || '—'} |\n| Reports Generated | ${analytics.reportsGenerated || '—'} |\n| Messages Today | ${analytics.messagesToday || '—'} |\n| Est. API Cost | $${(analytics.estimatedCostToday || 0).toFixed(2)} |\n\n## System Status\n\n- Gateway: Operational\n- Dashboard: Online\n- Data persistence: OK\n\n## Recommendations\n\n- Review agent utilization for cost optimization\n- Consider consolidating low-activity agents\n- Monitor disk usage for data growth\n`;
    }
    default:
      return `# ${projectTitle}\n\n**Date:** ${date}\n\n`;
  }
}

function renderMarkdown(text: string) {
  const lines = text.split('\n');
  const elements: any[] = [];
  let inCodeBlock = false;
  let codeLines: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (line.startsWith('```')) {
      if (inCodeBlock) {
        elements.push(<pre key={i} className="bg-mc-bg border border-mc-border rounded p-3 text-xs font-mono overflow-x-auto my-2">{codeLines.join('\n')}</pre>);
        codeLines = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      continue;
    }

    if (inCodeBlock) { codeLines.push(line); continue; }

    if (line.trim() === '') { elements.push(<div key={i} className="h-2" />); continue; }

    // Headers
    if (line.startsWith('### ')) {
      elements.push(<h3 key={i} className="text-base font-bold mt-4 mb-1">{processInline(line.slice(4))}</h3>);
      continue;
    }
    if (line.startsWith('## ')) {
      elements.push(<h2 key={i} className="text-lg font-bold mt-5 mb-2">{processInline(line.slice(3))}</h2>);
      continue;
    }
    if (line.startsWith('# ')) {
      elements.push(<h1 key={i} className="text-xl font-bold mt-6 mb-2">{processInline(line.slice(2))}</h1>);
      continue;
    }

    // Checkboxes
    if (line.match(/^- \[x\]/i)) {
      elements.push(<div key={i} className="flex items-center gap-2 ml-2 my-0.5"><span className="text-green-400">☑</span><span className="text-sm">{processInline(line.replace(/^- \[x\]\s*/i, ''))}</span></div>);
      continue;
    }
    if (line.match(/^- \[ \]/)) {
      elements.push(<div key={i} className="flex items-center gap-2 ml-2 my-0.5"><span className="text-mc-muted">☐</span><span className="text-sm">{processInline(line.replace(/^- \[ \]\s*/, ''))}</span></div>);
      continue;
    }

    // Bullet points
    if (line.match(/^[-*] /)) {
      elements.push(<div key={i} className="flex items-start gap-2 ml-2 my-0.5"><span className="text-mc-muted mt-1">•</span><span className="text-sm">{processInline(line.replace(/^[-*] /, ''))}</span></div>);
      continue;
    }

    // Numbered lists
    if (line.match(/^\d+\. /)) {
      const num = line.match(/^(\d+)\./)?.[1];
      elements.push(<div key={i} className="flex items-start gap-2 ml-2 my-0.5"><span className="text-mc-muted text-sm min-w-[1.2em]">{num}.</span><span className="text-sm">{processInline(line.replace(/^\d+\.\s*/, ''))}</span></div>);
      continue;
    }

    // Table rows
    if (line.includes('|') && line.trim().startsWith('|')) {
      const cells = line.split('|').filter(c => c.trim()).map(c => c.trim());
      if (cells.every(c => c.match(/^[-:]+$/))) continue; // separator row
      const isHeader = i + 1 < lines.length && lines[i + 1]?.match(/^\|[\s-:|]+\|$/);
      elements.push(
        <div key={i} className={`grid gap-2 text-xs py-1 px-2 ${isHeader ? 'font-bold border-b border-mc-border' : 'text-mc-muted'}`} style={{ gridTemplateColumns: `repeat(${cells.length}, 1fr)` }}>
          {cells.map((c, j) => <span key={j}>{processInline(c)}</span>)}
        </div>
      );
      continue;
    }

    // Images: ![alt](url)
    const imgMatch = line.match(/^!\[([^\]]*)\]\(([^)]+)\)/);
    if (imgMatch) {
      elements.push(
        <div key={i} className="my-3">
          <img src={imgMatch[2]} alt={imgMatch[1]} className="max-w-full rounded-lg border border-mc-border shadow-sm" loading="lazy" />
          {imgMatch[1] && <div className="text-xs text-mc-muted mt-1 italic text-center">{imgMatch[1]}</div>}
        </div>
      );
      continue;
    }

    // Horizontal rule
    if (line.match(/^---+$/)) {
      elements.push(<hr key={i} className="border-mc-border my-3" />);
      continue;
    }

    // Regular paragraph
    elements.push(<p key={i} className="text-sm my-0.5">{processInline(line)}</p>);
  }

  return elements;
}

// Check if report type is a test report
function isTestReport(type: string): boolean {
  const lowerType = type.toLowerCase();
  return lowerType.includes('test') || lowerType.includes('test-plan') || lowerType === 'test-plan';
}

// Test Report Viewer with interactive test cases
function TestReportViewer({ 
  report, 
  onSave 
}: { 
  report: Report; 
  onSave: (r: Report) => Promise<void>;
}) {
  const [testResults, setTestResults] = useState<Record<string, 'pass' | 'fail' | 'skip' | 'untested'>>(
    report.testResults || {}
  );
  const [saving, setSaving] = useState(false);
  const [runningAll, setRunningAll] = useState(false);
  
  const testCases = parseTestCases(report.content);
  
  // Initialize test results from content if not set
  useEffect(() => {
    if (!report.testResults && testCases.length > 0) {
      const initialResults: Record<string, 'pass' | 'fail' | 'skip' | 'untested'> = {};
      testCases.forEach(tc => {
        if (tc.originalLine.includes('[x]') || tc.originalLine.includes('[X]')) {
          initialResults[tc.id] = 'pass';
        }
      });
      if (Object.keys(initialResults).length > 0) {
        setTestResults(initialResults);
      }
    }
  }, [report.testResults, testCases]);
  
  const handleTestChange = async (testId: string, status: 'pass' | 'fail' | 'skip' | 'untested') => {
    const newResults = { ...testResults, [testId]: status };
    setTestResults(newResults);
    
    // Auto-save to report
    setSaving(true);
    await onSave({ ...report, testResults: newResults });
    setSaving(false);
  };
  
  const handleRunAllTests = async () => {
    setRunningAll(true);
    // Simulate running tests - in production this would call Sentinel
    setTimeout(() => {
      setRunningAll(false);
    }, 2000);
  };
  
  const passed = testCases.filter(t => testResults[t.id] === 'pass').length;
  const failed = testCases.filter(t => testResults[t.id] === 'fail').length;
  const skipped = testCases.filter(t => testResults[t.id] === 'skip').length;
  const total = testCases.length;
  
  return (
    <div className="space-y-4">
      {/* Header with summary and actions */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <span className="text-lg">🧪</span>
          <div>
            <div className="text-sm font-medium">Test Plan</div>
            <div className="text-xs text-mc-muted">
              {passed}/{total} passed · {failed} failed · {skipped} skipped
              {saving && <span className="ml-2 text-mc-accent">Saving...</span>}
            </div>
          </div>
        </div>
        
        <button 
          onClick={handleRunAllTests}
          disabled={runningAll || testCases.length === 0}
          className="px-3 py-1.5 text-xs bg-mc-accent text-white rounded hover:bg-mc-accent/80 disabled:opacity-50 flex items-center gap-2"
        >
          {runningAll ? (
            <>
              <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Running Tests...
            </>
          ) : (
            <>▶ Run All Tests</>
          )}
        </button>
      </div>
      
      {/* Test cases */}
      <TestCaseList 
        testCases={testCases} 
        results={testResults}
        onChange={handleTestChange}
      />
      
      {/* Divider */}
      <hr className="border-mc-border" />
      
      {/* Render rest of content (non-test parts) */}
      <div className="max-w-none text-mc-text leading-relaxed">
        {renderMarkdown(report.content)}
      </div>
    </div>
  );
}

// Parse test cases from markdown content
interface ParsedTestCase {
  id: string;
  title: string;
  status: 'pass' | 'fail' | 'skip' | 'untested';
  originalLine: string;
}

function parseTestCases(content: string): ParsedTestCase[] {
  const testCases: ParsedTestCase[] = [];
  const lines = content.split('\n');
  
  lines.forEach((line, idx) => {
    // Match checkbox format: - [ ] or - [x] or - [X]
    const checkboxMatch = line.match(/^(\s*)- \[([ xX])\] (.+)$/);
    if (checkboxMatch) {
      const status: 'pass' | 'fail' | 'skip' | 'untested' = checkboxMatch[2].toLowerCase() === 'x' ? 'pass' : 'untested';
      testCases.push({
        id: `test-${idx}`,
        title: checkboxMatch[3].trim(),
        status,
        originalLine: line,
      });
      return;
    }
    
    // Match numbered format: 1. Test: description or 1. Test - description
    const numberedMatch = line.match(/^(\s*)(\d+)\.\s*Test:?\s*[-–—]?\s*(.+)$/i);
    if (numberedMatch) {
      testCases.push({
        id: `test-${idx}`,
        title: numberedMatch[3].trim(),
        status: 'untested',
        originalLine: line,
      });
      return;
    }
    
    // Match "Test:" prefix anywhere in a line
    const testPrefixMatch = line.match(/^(\s*)-\s*Test:?\s*[-–—]?\s*(.+)$/i);
    if (testPrefixMatch) {
      testCases.push({
        id: `test-${idx}`,
        title: testPrefixMatch[2].trim(),
        status: 'untested',
        originalLine: line,
      });
    }
  });
  
  return testCases;
}

// Render interactive test case checklist
function TestCaseList({ 
  testCases, 
  results, 
  onChange 
}: { 
  testCases: ParsedTestCase[]; 
  results: Record<string, 'pass' | 'fail' | 'skip' | 'untested'>;
  onChange: (id: string, status: 'pass' | 'fail' | 'skip' | 'untested') => void;
}) {
  const statusIcons: Record<string, string> = {
    pass: '✅',
    fail: '❌',
    skip: '⏭',
    untested: '⬜',
  };
  
  const statusColors: Record<string, string> = {
    pass: 'bg-green-500/20 text-green-400 border-green-500/30',
    fail: 'bg-red-500/20 text-red-400 border-red-500/30',
    skip: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    untested: 'bg-mc-bg text-mc-muted border-mc-border',
  };
  
  const passed = testCases.filter(t => results[t.id] === 'pass').length;
  const failed = testCases.filter(t => results[t.id] === 'fail').length;
  const skipped = testCases.filter(t => results[t.id] === 'skip').length;
  const total = testCases.length;
  
  return (
    <div className="space-y-3">
      {/* Summary bar */}
      <div className="flex items-center justify-between bg-mc-bg rounded-lg px-4 py-2 border border-mc-border">
        <div className="flex items-center gap-4 text-xs">
          <span className="text-green-400 font-medium">✅ {passed}/{total} passed</span>
          <span className="text-red-400 font-medium">❌ {failed} failed</span>
          <span className="text-yellow-400 font-medium">⏭ {skipped} skipped</span>
        </div>
        {total > 0 && (
          <div className="flex items-center gap-1">
            <div className="w-32 h-2 bg-mc-border rounded-full overflow-hidden flex">
              <div className="h-full bg-green-500" style={{ width: `${(passed/total)*100}%` }} />
              <div className="h-full bg-red-500" style={{ width: `${(failed/total)*100}%` }} />
              <div className="h-full bg-yellow-500" style={{ width: `${(skipped/total)*100}%` }} />
            </div>
          </div>
        )}
      </div>
      
      {/* Test case list */}
      <div className="space-y-2">
        {testCases.map((tc, idx) => {
          const currentStatus = results[tc.id] || 'untested';
          return (
            <div key={tc.id} className="flex items-center gap-3 p-2 rounded-lg border border-mc-border hover:bg-mc-bg transition-colors">
              <span className="text-xs text-mc-muted w-6">{idx + 1}.</span>
              
              {/* Status buttons */}
              <div className="flex gap-1">
                {(['pass', 'fail', 'skip', 'untested'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => onChange(tc.id, status)}
                    className={`px-2 py-1 text-xs rounded border transition-all ${
                      currentStatus === status 
                        ? statusColors[status] 
                        : 'border-transparent text-mc-muted hover:text-mc-text'
                    }`}
                    title={status.charAt(0).toUpperCase() + status.slice(1)}
                  >
                    {statusIcons[status]}
                  </button>
                ))}
              </div>
              
              <span className={`text-sm flex-1 ${
                currentStatus === 'pass' ? 'text-green-400' :
                currentStatus === 'fail' ? 'text-red-400' :
                currentStatus === 'skip' ? 'text-yellow-400' :
                'text-mc-text'
              }`}>
                {tc.title}
              </span>
            </div>
          );
        })}
      </div>
      
      {testCases.length === 0 && (
        <div className="text-xs text-mc-muted text-center py-4">
          No test cases found. Add test cases using:
          <br />- [ ] Checkbox format
          <br />- 1. Test: description
          <br />- - Test: description
        </div>
      )}
    </div>
  );
}

function processInline(text: string): any {
  // Bold
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-bold text-mc-text">{part.slice(2, -2)}</strong>;
    }
    // Inline code
    const codeParts = part.split(/(`[^`]+`)/g);
    return codeParts.map((cp, j) => {
      if (cp.startsWith('`') && cp.endsWith('`')) {
        return <code key={`${i}-${j}`} className="bg-mc-bg px-1 py-0.5 rounded text-xs font-mono text-mc-accent">{cp.slice(1, -1)}</code>;
      }
      return cp;
    });
  });
}

// ══════════════════════════════════════════════════════════════
// REPORT VIEWER — Edit, Print, PDF, Images
// ══════════════════════════════════════════════════════════════
function ReportViewer({ report, onClose, onSave, copied, onExport }: {
  report: Report; onClose: () => void;
  onSave: (r: Report) => Promise<void>;
  copied: boolean; onExport: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [editContent, setEditContent] = useState(report.content);
  const [editTitle, setEditTitle] = useState(report.title);
  const [saving, setSaving] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await onSave({ ...report, content: editContent, title: editTitle });
    setEditing(false);
    setSaving(false);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const content = printRef.current?.innerHTML || '';
    printWindow.document.write(`
      <!DOCTYPE html><html><head><title>${report.title}</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 800px; margin: 40px auto; padding: 0 20px; color: #1a1a1a; line-height: 1.6; }
        h1 { font-size: 24px; border-bottom: 2px solid #333; padding-bottom: 8px; }
        h2 { font-size: 20px; margin-top: 24px; color: #333; }
        h3 { font-size: 16px; margin-top: 16px; color: #555; }
        table { border-collapse: collapse; width: 100%; margin: 12px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 13px; }
        th { background: #f5f5f5; font-weight: 600; }
        code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 12px; }
        pre { background: #f5f5f5; padding: 12px; border-radius: 6px; overflow-x: auto; font-size: 12px; }
        ul, ol { padding-left: 24px; }
        li { margin: 4px 0; }
        img { max-width: 100%; border-radius: 8px; margin: 12px 0; }
        .meta { color: #888; font-size: 12px; margin-bottom: 24px; }
        @media print { body { margin: 20px; } }
      </style></head><body>
      <h1>${report.title}</h1>
      <div class="meta">${report.type} · ${report.createdBy} · ${new Date(report.createdAt).toLocaleString()}</div>
      ${content}
      </body></html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const handlePDF = () => {
    // Use print dialog with "Save as PDF" option — works on all modern browsers
    handlePrint();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-mc-border">
          <div className="flex-1 min-w-0">
            {editing ? (
              <input value={editTitle} onChange={e => setEditTitle(e.target.value)}
                className="bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm font-bold text-mc-text w-full" />
            ) : (
              <>
                <h3 className="text-sm font-bold">{report.title}</h3>
                <div className="text-[10px] text-mc-muted mt-0.5">
                  {report.type} · by {report.createdBy} · {new Date(report.createdAt).toLocaleString()}
                </div>
              </>
            )}
          </div>
          <div className="flex items-center gap-1.5 ml-4 flex-shrink-0">
            {editing ? (
              <>
                <button onClick={handleSave} disabled={saving}
                  className="px-3 py-1 text-xs rounded bg-green-600 text-white hover:bg-green-700 disabled:opacity-50">
                  {saving ? '💾...' : '💾 Save'}
                </button>
                <button onClick={() => { setEditing(false); setEditContent(report.content); setEditTitle(report.title); }}
                  className="px-3 py-1 text-xs rounded bg-mc-bg text-mc-muted border border-mc-border hover:text-mc-text">
                  Cancel
                </button>
              </>
            ) : (
              <>
                <button onClick={() => setEditing(true)}
                  className="px-2 py-1 text-xs rounded bg-mc-bg text-mc-muted border border-mc-border hover:text-mc-accent" title="Edit">
                  ✏️ Edit
                </button>
                <button onClick={handlePrint}
                  className="px-2 py-1 text-xs rounded bg-mc-bg text-mc-muted border border-mc-border hover:text-mc-accent" title="Print">
                  🖨️ Print
                </button>
                <button onClick={handlePDF}
                  className="px-2 py-1 text-xs rounded bg-mc-bg text-mc-muted border border-mc-border hover:text-mc-accent" title="Save as PDF">
                  📄 PDF
                </button>
                <button onClick={onExport}
                  className={`px-2 py-1 text-xs rounded transition-colors ${copied ? 'bg-green-500/20 text-green-400' : 'bg-mc-bg text-mc-muted border border-mc-border hover:text-mc-accent'}`}>
                  {copied ? '✅' : '📋 Copy'}
                </button>
              </>
            )}
            <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl ml-1">✕</button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {editing ? (
            <textarea value={editContent} onChange={e => setEditContent(e.target.value)}
              className="w-full h-full min-h-[400px] bg-mc-bg border border-mc-border rounded-lg p-4 text-sm text-mc-text font-mono resize-none focus:outline-none focus:border-mc-accent"
              spellCheck={false} />
          ) : (
            isTestReport(report.type) ? (
              <TestReportViewer 
                report={report} 
                onSave={onSave}
              />
            ) : (
              <div ref={printRef} className="max-w-none text-mc-text leading-relaxed">
                {renderMarkdown(report.content)}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}

export default function ReportsPanel() {
  const [reports, setReports] = useState<Report[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [showDropdown, setShowDropdown] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [hideCompleted, setHideCompleted] = useState(true); // Default: hide completed projects
  const [copied, setCopied] = useState(false);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [customTypes, setCustomTypes] = useState<CustomReportType[]>([]);
  const [customMode, setCustomMode] = useState<string | null>(null);
  const [customName, setCustomName] = useState('');
  const [showSavePrompt, setShowSavePrompt] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'category' | 'all'>('category');
  const [sortCol, setSortCol] = useState<string>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [ranking, setRanking] = useState(false);
  const [rankedReports, setRankedReports] = useState<any[]>([]);
  const [autoGenerateTab, setAutoGenerateTab] = useState<'health' | 'legal' | 'system'>('health');
  const [autoGenerating, setAutoGenerating] = useState<string | null>(null);
  const [showGenerationWatcher, setShowGenerationWatcher] = useState(true);

  const AUTO_GENERATE_TYPES = {
    health: [
      { id: 'daily-health-summary', label: 'Daily Health Summary', icon: '📊' },
      { id: 'weekly-health-trends', label: 'Weekly Health Trends', icon: '📈' },
      { id: 'supplement-compliance', label: 'Supplement Compliance', icon: '💊' },
      { id: 'mayo-clinic-prep', label: 'Mayo Clinic Prep', icon: '🏥' },
      { id: 'exercise-safety', label: 'Exercise Safety', icon: '🏃' },
      { id: 'genetic-condition-overview', label: 'Genetic Overview', icon: '🧬' },
      { id: 'nutrition-analysis', label: 'Nutrition Analysis', icon: '🥗' },
    ],
    legal: [
      { id: 'medical-malpractice', label: 'Malpractice Assessment', icon: '⚖️' },
      { id: 'legal-action-checklist', label: 'Legal Action Checklist', icon: '📋' },
      { id: 'rights-benefits-review', label: 'Rights & Benefits', icon: '📜' },
      { id: 'contract-review', label: 'Contract Review Template', icon: '📃' },
      { id: 'ip-status', label: 'IP Status', icon: '🔐' },
      { id: 'privacy-compliance', label: 'Privacy Compliance', icon: '🔒' },
    ],
    system: [
      { id: 'daily-system-health', label: 'Daily System Health', icon: '🖥️' },
      { id: 'api-usage-cost', label: 'API Usage & Cost', icon: '💰' },
      { id: 'agent-performance', label: 'Agent Performance', icon: '🤖' },
      { id: 'security-audit', label: 'Security Audit', icon: '🔐' },
      { id: 'infrastructure-status', label: 'Infrastructure Status', icon: '🖧' },
      { id: 'project-progress', label: 'Project Progress', icon: '📊' },
    ],
  };

  const REPORT_TYPES = [...BUILT_IN_REPORT_TYPES, ...customTypes];
  const TYPE_LABELS = buildTypeLabels(REPORT_TYPES);

  useEffect(() => {
    fetch('/api/reports').then(r => r.json()).then(d => setReports(d.reports || [])).catch(() => {});
    fetch('/api/projects').then(r => r.json()).then(d => setProjects(d.projects || [])).catch(() => {});
    fetch('/api/reports/custom-types').then(r => r.json()).then(d => setCustomTypes(d.types || [])).catch(() => {});
  }, []);

  const createReport = async (projectId: string, type: string) => {
    setShowGenerationWatcher(true);
    setCreating(true);
    setShowDropdown(null);
    const project = projects.find(p => p.id === projectId);
    const typeLabel = REPORT_TYPES.find(t => t.id === type)?.label || type;
    const isLiveReport = ['weekly-summary', 'agent-performance', 'cost-analysis', 'system-health', 'health-report'].includes(type);
    let liveData: any = undefined;
    if (isLiveReport) {
      liveData = await fetchAnalyticsData();
    }
    try {
      const isLive = ['weekly-summary', 'agent-performance', 'cost-analysis', 'system-health', 'health-report'].includes(type);
      const content = isLive ? generateTemplate(type, project?.title || 'General', liveData) : '';

      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create',
          title: `${typeLabel} — ${project?.title || 'General'}`,
          type,
          projectId,
          content,
          createdBy: 'Kevin',
        }),
      });
      const data = await res.json();
      if (data.ok && data.report) {
        setReports(prev => [data.report, ...prev]);
        setSelectedReport(data.report);
      }
    } catch {}
    setCreating(false);
  };

  const createCustomReport = async (projectId: string, customLabel: string) => {
    setCreating(true);
    setCustomMode(null);
    const project = projects.find(p => p.id === projectId);
    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create',
          title: `${customLabel} — ${project?.title || 'General'}`,
          type: 'custom',
          projectId,
          content: '',
          createdBy: 'Kevin',
        }),
      });
      const data = await res.json();
      if (data.ok && data.report) {
        setReports(prev => [data.report, ...prev]);
        setSelectedReport(data.report);
        setShowSavePrompt(customLabel);
      }
    } catch {}
    setCreating(false);
    setCustomName('');
  };

  const saveCustomType = async (label: string) => {
    const id = label.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newType: CustomReportType = { id, label, icon: '✏️', category: 'project' };
    try {
      await fetch('/api/reports/custom-types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newType),
      });
      setCustomTypes(prev => [...prev, newType]);
    } catch {}
    setShowSavePrompt(null);
  };

  const deleteReport = async (id: string) => {
    await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete', id }),
    });
    setReports(prev => prev.filter(r => r.id !== id));
    if (selectedReport?.id === id) setSelectedReport(null);
  };

  const exportReport = async () => {
    if (!selectedReport) return;
    await navigator.clipboard.writeText(selectedReport.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filter reports by date
  const filteredReports = reports.filter(r => {
    if (dateFrom && new Date(r.createdAt) < new Date(dateFrom)) return false;
    if (dateTo && new Date(r.createdAt) > new Date(dateTo + 'T23:59:59')) return false;
    return true;
  });

  // Group reports by category first, then by project
  const grouped: Record<string, Report[]> = {};
  const noProject: Report[] = [];
  const categoryReports: Record<string, Report[]> = {
    'personal-health': [],
    'legal': [],
    'system': [],
    'memory': [],
  };

  for (const r of filteredReports) {
    // Determine category from report type
    const typeInfo = REPORT_TYPES.find(t => t.id === r.type);
    const cat = typeInfo?.category;

    if (cat === 'personal-health' || r.type === 'personal-health' || (r.type === 'health-report' && r.tags?.includes('health'))) {
      categoryReports['personal-health'].push(r);
    } else if (cat === 'memory') {
      categoryReports['memory'].push(r);
    } else if (cat === 'legal' || r.type === 'legal-report' || r.tags?.includes('legal')) {
      categoryReports['legal'].push(r);
    } else if (cat === 'system' && !r.projectId) {
      categoryReports['system'].push(r);
    } else if (r.projectId) {
      if (!grouped[r.projectId]) grouped[r.projectId] = [];
      grouped[r.projectId].push(r);
    } else {
      // Legacy health-report type (system metrics) → system category
      if (r.type === 'health-report' && !r.tags) {
        categoryReports['system'].push(r);
      } else {
        noProject.push(r);
      }
    }
  }

  const handleRank = async () => {
    setRanking(true);
    try {
      const res = await fetch('/api/reports/rank', { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        setRankedReports(data.reports || []);
        setSortCol('rank');
        setSortDir('asc');
      }
    } catch {} finally { setRanking(false); }
  };

  const allReportsForTable = (rankedReports.length > 0 ? rankedReports : filteredReports.map(r => ({
    ...r,
    prereqRank: 999,
    projectTitle: r.projectId ? projects.find(p => p.id === r.projectId)?.title || '' : '',
  }))).sort((a: any, b: any) => {
    let va: any, vb: any;
    if (sortCol === 'name') { va = a.title; vb = b.title; }
    else if (sortCol === 'type') { va = a.type; vb = b.type; }
    else if (sortCol === 'project') { va = a.projectTitle || ''; vb = b.projectTitle || ''; }
    else if (sortCol === 'date') { va = a.createdAt; vb = b.createdAt; }
    else if (sortCol === 'creator') { va = a.createdBy || ''; vb = b.createdBy || ''; }
    else if (sortCol === 'rank') { va = a.prereqRank || 999; vb = b.prereqRank || 999; }
    else { va = a.createdAt; vb = b.createdAt; }
    if (typeof va === 'number') return sortDir === 'asc' ? va - vb : vb - va;
    return sortDir === 'asc' ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
  });

  const toggleSort = (col: string) => {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  };

  const SortHeader = ({ col, label }: { col: string; label: string }) => (
    <th onClick={() => toggleSort(col)} className="px-3 py-2 text-left text-xs font-medium text-mc-muted cursor-pointer hover:text-mc-accent select-none">
      {label} {sortCol === col ? (sortDir === 'asc' ? '▲' : '▼') : ''}
    </th>
  );

  const isGenerating = creating || autoGenerating !== null;

  const generateAutoReport = async (category: 'health' | 'legal' | 'system', type: string) => {
    setShowGenerationWatcher(true);
    setAutoGenerating(type);
    try {
      const res = await fetch('/api/reports/auto-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: category === 'health' ? 'personal-health' : category,
          type,
        }),
      });
      const data = await res.json();
      if (data.ok && data.report) {
        setReports(prev => [data.report, ...prev]);
        setSelectedReport(data.report);
      } else {
        alert(`Report generation failed: ${data.error || 'Unknown error'}`);
      }
    } catch (e: any) {
      alert(`Report generation failed: ${e.message || 'Network error'}`);
    } finally {
      setAutoGenerating(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Generation Watcher */}
      {isGenerating && showGenerationWatcher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md bg-mc-surface border border-mc-border rounded-xl p-4 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold">Generating report…</h3>
                <p className="text-xs text-mc-muted mt-1">{autoGenerating ? `Type: ${autoGenerating}` : 'Preparing report context'} · This may take 10–30 seconds.</p>
              </div>
              <button
                onClick={() => setShowGenerationWatcher(false)}
                className="text-xs px-2 py-1 rounded bg-mc-bg border border-mc-border text-mc-muted hover:text-mc-text"
              >
                Run in background
              </button>
            </div>
            <div className="mt-4 flex items-center gap-3">
              <div className="w-5 h-5 border-2 border-mc-accent border-t-transparent rounded-full animate-spin" />
              <span className="text-sm text-mc-accent">Working… report will auto-open when ready.</span>
            </div>
          </div>
        </div>
      )}

      {isGenerating && !showGenerationWatcher && (
        <button
          onClick={() => setShowGenerationWatcher(true)}
          className="fixed bottom-4 right-4 z-40 px-3 py-2 text-xs rounded-full bg-mc-accent text-white shadow-lg hover:opacity-90"
        >
          ⏳ Report generating — show status
        </button>
      )}

      {/* View Toggle */}
      <div className="flex items-center gap-2">
        <div className="flex bg-mc-surface border border-mc-border rounded overflow-hidden">
          <button onClick={() => setViewMode('all')}
            className={`px-3 py-1.5 text-xs transition-colors ${viewMode === 'all' ? 'bg-mc-accent/20 text-mc-accent font-medium' : 'text-mc-muted hover:text-mc-text'}`}>
            📋 All Reports
          </button>
          <button onClick={() => setViewMode('category')}
            className={`px-3 py-1.5 text-xs transition-colors ${viewMode === 'category' ? 'bg-mc-accent/20 text-mc-accent font-medium' : 'text-mc-muted hover:text-mc-text'}`}>
            📂 By Category
          </button>
        </div>
        {viewMode === 'all' && (
          <button onClick={handleRank} disabled={ranking}
            className="px-3 py-1.5 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 disabled:opacity-50">
            {ranking ? '⏳ Ranking...' : '🔄 Analyze & Rank'}
          </button>
        )}
      </div>

      {viewMode === 'all' && (
        <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-mc-border bg-mc-bg">
                <tr>
                  <SortHeader col="name" label="Report Name" />
                  <SortHeader col="type" label="Type" />
                  <SortHeader col="project" label="Project" />
                  <SortHeader col="date" label="Date Generated" />
                  <SortHeader col="creator" label="Creator" />
                  <SortHeader col="rank" label="Priority Rank" />
                  <th className="px-3 py-2 w-8"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-mc-border">
                {allReportsForTable.map((r: any) => {
                  const typeInfo = REPORT_TYPES.find(t => t.id === r.type);
                  return (
                    <tr key={r.id} onClick={() => setSelectedReport(r)} className="hover:bg-mc-bg cursor-pointer transition-colors">
                      <td className="px-3 py-2 text-sm">{r.title}</td>
                      <td className="px-3 py-2 text-sm" title={typeInfo?.label || r.type}>{typeInfo?.icon || '📄'}</td>
                      <td className="px-3 py-2 text-xs text-mc-muted">{r.projectTitle || '—'}</td>
                      <td className="px-3 py-2 text-xs text-mc-muted">{new Date(r.createdAt).toLocaleDateString()}</td>
                      <td className="px-3 py-2 text-xs text-mc-muted">{r.createdBy || '—'}</td>
                      <td className="px-3 py-2 text-xs">
                        {r.prereqRank < 999 ? (
                          <span className={`px-1.5 py-0.5 rounded ${r.prereqRank === 1 ? 'bg-red-500/20 text-red-400' : r.prereqRank <= 3 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-blue-500/20 text-blue-400'}`}>
                            #{r.prereqRank}
                          </span>
                        ) : <span className="text-mc-muted">—</span>}
                      </td>
                      <td className="px-3 py-2">
                        <button onClick={(e) => { e.stopPropagation(); deleteReport(r.id); }}
                          className="text-mc-muted hover:text-red-400 text-xs">✕</button>
                      </td>
                    </tr>
                  );
                })}
                {allReportsForTable.length === 0 && (
                  <tr><td colSpan={7} className="px-3 py-8 text-center text-xs text-mc-muted">No reports found</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {viewMode === 'category' && <>
      {/* Auto-Generate Section — 3 columns */}
      <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border">
          <span className="text-sm font-semibold">✨ Auto-Generate Reports</span>
          <span className="text-[10px] text-mc-muted">AI-powered reports from live data</span>
        </div>

        {autoGenerating && (
          <div className="px-4 py-2 border-b border-mc-border bg-mc-accent/10 text-xs text-mc-accent flex items-center gap-2">
            <div className="w-3 h-3 border-2 border-mc-accent border-t-transparent rounded-full animate-spin" />
            🤖 Generating report with Claude Haiku — will open when ready...
          </div>
        )}

        <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Health Column */}
          <div>
            <h3 className="text-xs font-bold text-mc-muted uppercase tracking-wide mb-2 px-1">❤️ Health</h3>
            <div className="space-y-1.5">
              {AUTO_GENERATE_TYPES.health.map(rt => (
                <button key={rt.id} onClick={() => generateAutoReport('health', rt.id)}
                  disabled={autoGenerating !== null}
                  className={`w-full px-2.5 py-2 text-xs rounded border transition-colors text-left flex items-center gap-2 ${
                    autoGenerating === rt.id
                      ? 'bg-mc-accent/20 border-mc-accent text-mc-accent'
                      : 'bg-mc-bg border-mc-border text-mc-text hover:border-mc-accent hover:text-mc-accent disabled:opacity-50'
                  }`}>
                  {autoGenerating === rt.id ? (
                    <div className="w-3 h-3 border-2 border-mc-accent border-t-transparent rounded-full animate-spin flex-shrink-0" />
                  ) : (
                    <span className="flex-shrink-0">{rt.icon}</span>
                  )}
                  <span className="truncate">{rt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Legal Column */}
          <div>
            <h3 className="text-xs font-bold text-mc-muted uppercase tracking-wide mb-2 px-1">⚖️ Legal</h3>
            <div className="space-y-1.5">
              {AUTO_GENERATE_TYPES.legal.map(rt => (
                <button key={rt.id} onClick={() => generateAutoReport('legal', rt.id)}
                  disabled={autoGenerating !== null}
                  className={`w-full px-2.5 py-2 text-xs rounded border transition-colors text-left flex items-center gap-2 ${
                    autoGenerating === rt.id
                      ? 'bg-mc-accent/20 border-mc-accent text-mc-accent'
                      : 'bg-mc-bg border-mc-border text-mc-text hover:border-mc-accent hover:text-mc-accent disabled:opacity-50'
                  }`}>
                  {autoGenerating === rt.id ? (
                    <div className="w-3 h-3 border-2 border-mc-accent border-t-transparent rounded-full animate-spin flex-shrink-0" />
                  ) : (
                    <span className="flex-shrink-0">{rt.icon}</span>
                  )}
                  <span className="truncate">{rt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* System Column */}
          <div>
            <h3 className="text-xs font-bold text-mc-muted uppercase tracking-wide mb-2 px-1">🖥️ System</h3>
            <div className="space-y-1.5">
              {AUTO_GENERATE_TYPES.system.map(rt => (
                <button key={rt.id} onClick={() => generateAutoReport('system', rt.id)}
                  disabled={autoGenerating !== null}
                  className={`w-full px-2.5 py-2 text-xs rounded border transition-colors text-left flex items-center gap-2 ${
                    autoGenerating === rt.id
                      ? 'bg-mc-accent/20 border-mc-accent text-mc-accent'
                      : 'bg-mc-bg border-mc-border text-mc-text hover:border-mc-accent hover:text-mc-accent disabled:opacity-50'
                  }`}>
                  {autoGenerating === rt.id ? (
                    <div className="w-3 h-3 border-2 border-mc-accent border-t-transparent rounded-full animate-spin flex-shrink-0" />
                  ) : (
                    <span className="flex-shrink-0">{rt.icon}</span>
                  )}
                  <span className="truncate">{rt.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Date Range Filter */}
      <div className="bg-mc-surface border border-mc-border rounded-lg px-4 py-3 flex flex-wrap items-center gap-3">
        <span className="text-xs text-mc-muted">📅 Filter:</span>
        <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
          className="px-2 py-1 text-xs bg-mc-bg border border-mc-border rounded text-mc-text focus:outline-none focus:border-mc-accent" />
        <span className="text-xs text-mc-muted">to</span>
        <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
          className="px-2 py-1 text-xs bg-mc-bg border border-mc-border rounded text-mc-text focus:outline-none focus:border-mc-accent" />
        {(dateFrom || dateTo) && (
          <button onClick={() => { setDateFrom(''); setDateTo(''); }} className="text-xs text-mc-muted hover:text-mc-accent">✕ Clear</button>
        )}
        <span className="text-xs text-mc-muted ml-auto">{filteredReports.length} report{filteredReports.length !== 1 ? 's' : ''}</span>
      </div>

      {/* Quick Generate (no project needed) */}
      <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border">
          <span className="text-sm font-semibold">🚀 Quick Reports</span>
          <span className="text-[10px] text-mc-muted">Auto-generated from live data</span>
        </div>
        <div className="p-3 flex flex-wrap gap-2">
          {['weekly-summary', 'agent-performance', 'cost-analysis', 'system-health'].map(type => {
            const rt = REPORT_TYPES.find(t => t.id === type)!;
            return (
              <button key={type} onClick={() => createReport('', type)} disabled={creating}
                className="px-3 py-2 text-xs bg-mc-bg border border-mc-border rounded hover:border-mc-accent hover:text-mc-accent transition-colors disabled:opacity-50">
                {rt.icon} {rt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Generation indicator */}
      {creating && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg px-4 py-3 flex items-center gap-3 animate-pulse">
          <div className="w-5 h-5 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin" />
          <span className="text-sm text-yellow-400 font-medium">Agent is generating your report... This may take 10-20 seconds.</span>
        </div>
      )}

      {/* Category Sections: Personal Health, Legal, System Health */}
      {REPORT_CATEGORIES.map(cat => {
        const catReports = categoryReports[cat.id] || [];
        if (cat.id === 'project') return null; // Projects rendered separately below
        return (
          <div key={cat.id} className="bg-mc-surface border border-mc-border rounded-lg overflow-visible">
            <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border">
              <div className="flex items-center gap-2">
                <span className="text-lg">{cat.icon}</span>
                <div>
                  <span className="text-sm font-semibold">{cat.label}</span>
                  <span className="text-[10px] text-mc-muted ml-2">{cat.description}</span>
                </div>
              </div>
              <span className="text-[10px] text-mc-muted">{catReports.length} report{catReports.length !== 1 ? 's' : ''}</span>
            </div>
            {catReports.length > 0 ? (
              <div className="divide-y divide-mc-border">
                {catReports.map(report => (
                  <button key={report.id} onClick={() => setSelectedReport(report)}
                    className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-mc-bg transition-colors text-left">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xs">{TYPE_LABELS[report.type] || report.type}</span>
                      <span className="text-sm truncate">{report.title}</span>
                      {report.author && <span className="text-[10px] text-mc-muted">by {report.author}</span>}
                      {report.status === 'final' && <span className="text-[10px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded">Final</span>}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-[10px] text-mc-muted">{new Date(report.createdAt).toLocaleDateString()}</span>
                      <button onClick={(e) => { e.stopPropagation(); deleteReport(report.id); }}
                        className="text-mc-muted hover:text-red-400 text-xs">✕</button>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="px-4 py-3 text-xs text-mc-muted">No {cat.label.toLowerCase()} reports yet</div>
            )}
          </div>
        );
      })}

      {/* Project filter */}
      <div className="flex items-center gap-3">
        <span className="text-xs font-semibold text-mc-muted">📁 Projects</span>
        <label className="flex items-center gap-1.5 text-xs text-mc-muted cursor-pointer">
          <input type="checkbox" checked={hideCompleted} onChange={e => setHideCompleted(e.target.checked)}
            className="rounded border-mc-border" />
          Hide completed
        </label>
        <span className="text-[10px] text-mc-muted ml-auto">{projects.filter(p => !hideCompleted || !['complete','completed'].includes(p.status || '')).length} projects</span>
      </div>

      {/* Project sections — 3 column grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
      {[...projects].filter(p => !hideCompleted || !['complete','completed'].includes(p.status || '')).sort((a, b) => {
        const aComplete = ['complete', 'completed'].includes(a.status || '');
        const bComplete = ['complete', 'completed'].includes(b.status || '');
        if (aComplete && !bComplete) return 1;
        if (!aComplete && bComplete) return -1;
        return 0;
      }).map(project => (
        <div key={project.id} className="bg-mc-surface border border-mc-border rounded-lg overflow-visible">
          <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border">
            <div className="flex items-center gap-2">
              <span className="text-lg">{['complete', 'completed'].includes(project.status || '') ? '✅' : '📁'}</span>
              <span className={`text-sm font-semibold ${['complete', 'completed'].includes(project.status || '') ? 'text-mc-muted' : ''}`}>{project.title}</span>
              {['complete', 'completed'].includes(project.status || '') && <span className="text-[10px] px-1.5 py-0.5 bg-green-500/10 text-green-400 rounded">Done</span>}
              <span className="text-[10px] text-mc-muted">{(grouped[project.id] || []).length} reports</span>
            </div>
            <div className="relative">
              <button
                onClick={() => setShowDropdown(showDropdown === project.id ? null : project.id)}
                disabled={creating}
                className="px-3 py-1 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 transition-colors disabled:opacity-50"
              >
                + Generate Report
              </button>
              {showDropdown === project.id && (
                <div className="absolute right-0 top-full mt-1 bg-mc-surface border border-mc-border rounded-lg shadow-xl z-50 w-56 max-h-80 overflow-y-auto">
                  {REPORT_TYPES.filter(t => t.category === 'project').map(type => (
                    <button key={type.id} onClick={() => createReport(project.id, type.id)}
                      className="w-full text-left px-3 py-2 text-sm hover:bg-mc-bg transition-colors">
                      {type.icon} {type.label}
                    </button>
                  ))}
                  <button onClick={() => { setCustomMode(project.id); setShowDropdown(null); }}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-mc-bg transition-colors border-t border-mc-border text-mc-accent">
                    ✏️ Custom...
                  </button>
                </div>
              )}
              {customMode === project.id && (
                <div className="absolute right-0 top-full mt-1 bg-mc-surface border border-mc-border rounded-lg shadow-xl z-50 w-64 p-3 space-y-2">
                  <input value={customName} onChange={e => setCustomName(e.target.value)} placeholder="Custom report name..."
                    className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1.5 text-sm text-mc-text"
                    onKeyDown={e => e.key === 'Enter' && customName.trim() && createCustomReport(project.id, customName.trim())}
                    autoFocus />
                  <div className="flex gap-2">
                    <button onClick={() => customName.trim() && createCustomReport(project.id, customName.trim())}
                      disabled={!customName.trim() || creating}
                      className="flex-1 bg-mc-accent text-white px-3 py-1 rounded text-xs hover:opacity-80 disabled:opacity-50">Generate</button>
                    <button onClick={() => { setCustomMode(null); setCustomName(''); }}
                      className="text-mc-muted text-xs hover:text-mc-text">Cancel</button>
                  </div>
                </div>
              )}
            </div>
          </div>
          {(grouped[project.id] || []).length > 0 ? (
            <div className="divide-y divide-mc-border">
              {(grouped[project.id] || []).map(report => (
                <button key={report.id} onClick={() => setSelectedReport(report)}
                  className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-mc-bg transition-colors text-left">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs">{TYPE_LABELS[report.type] || report.type}</span>
                    <span className="text-sm truncate">{report.title}</span>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-[10px] text-mc-muted">{new Date(report.createdAt).toLocaleDateString()}</span>
                    <button onClick={(e) => { e.stopPropagation(); deleteReport(report.id); }}
                      className="text-mc-muted hover:text-red-400 text-xs">✕</button>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="px-4 py-3 text-xs text-mc-muted">No reports yet</div>
          )}
        </div>
      ))}
      </div>

      {/* Unassigned reports */}
      {noProject.length > 0 && (
        <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-mc-border">
            <span className="text-sm font-semibold text-mc-muted">General Reports</span>
          </div>
          <div className="divide-y divide-mc-border">
            {noProject.map(report => (
              <button key={report.id} onClick={() => setSelectedReport(report)}
                className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-mc-bg transition-colors text-left">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-xs">{TYPE_LABELS[report.type] || report.type}</span>
                  <span className="text-sm truncate">{report.title}</span>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span className="text-[10px] text-mc-muted">{new Date(report.createdAt).toLocaleDateString()}</span>
                  <button onClick={(e) => { e.stopPropagation(); deleteReport(report.id); }}
                    className="text-mc-muted hover:text-red-400 text-xs">✕</button>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {projects.length === 0 && filteredReports.length === 0 && (
        <div className="text-center py-12 text-mc-muted">
          <div className="text-3xl mb-2">📄</div>
          <div className="text-sm">No projects or reports yet</div>
          <div className="text-xs mt-1">Create a project first, then generate reports</div>
        </div>
      )}

      </>}

      {/* Save Custom Type Prompt */}
      {showSavePrompt && (
        <div className="bg-mc-accent/10 border border-mc-accent/30 rounded-lg px-4 py-3 flex items-center gap-3">
          <span className="text-sm">Add &apos;{showSavePrompt}&apos; to your report types for future use?</span>
          <button onClick={() => saveCustomType(showSavePrompt)} className="px-3 py-1 text-xs bg-mc-accent text-white rounded hover:opacity-80">Yes</button>
          <button onClick={() => setShowSavePrompt(null)} className="px-3 py-1 text-xs bg-mc-bg border border-mc-border rounded text-mc-muted hover:text-mc-text">No</button>
        </div>
      )}

      {/* Report Viewer Modal */}
      {selectedReport && (
        <ReportViewer
          report={selectedReport}
          onClose={() => setSelectedReport(null)}
          onSave={async (updated) => {
            await fetch('/api/reports', {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: updated.id, content: updated.content, title: updated.title }),
            });
            setSelectedReport(updated);
            setReports(prev => prev.map(r => r.id === updated.id ? updated : r));
          }}
          copied={copied}
          onExport={exportReport}
        />
      )}
    </div>
  );
}
