'use client';
import { useState, useEffect } from 'react';

function getWorldUrl(theme: string): string {
  if (typeof window !== 'undefined' && window.location.hostname.includes('denominatorx.com')) {
    return `https://world.denominatorx.com/?server=https://world-ws.denominatorx.com&theme=${theme}`;
  }
  return `http://localhost:3002/?server=http://127.0.0.1:18800&theme=${theme}`;
}

const CHARACTER_EMOJIS: Record<string, string> = {
  lobster: '🦞', robot: '🤖', humanoid: '🧑', orb: '🔮',
  mech: '⚙️', ghost: '👻', cat: '🐱', tree: '🌳', bee: '🐝', dragonfly: '🪰', hillbilly: '🤠',
};

const TIER_BADGES: Record<number, { label: string; color: string }> = {
  0: { label: 'OWNER', color: 'text-yellow-400' },
  1: { label: 'EXEC', color: 'text-purple-400' },
  2: { label: 'VP', color: 'text-blue-400' },
  3: { label: 'DIR', color: 'text-cyan-400' },
  4: { label: 'SR', color: 'text-green-400' },
  5: { label: 'MGR', color: 'text-orange-400' },
  6: { label: 'FW', color: 'text-gray-400' },
};

interface Agent {
  id: string;
  name: string;
  displayName?: string;
  role: string;
  tier: number;
  status: string;
  color: string;
  avatarType?: string;
  lastActive?: string;
}

interface Props {
  onSelectAgent: (agentId: string) => void;
}

const THEMES = [
  { id: 'ocean', label: '🌊 Ocean', },
  { id: 'tropical', label: '🌴 Tampa', },
  { id: 'corporate', label: '🏢 Office', },
] as const;

export default function WorldTab({ onSelectAgent }: Props & { onChatAgent?: (agentId: string) => void }) {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [panelOpen, setPanelOpen] = useState(false);
  const [theme, setTheme] = useState('tropical');
  const [taskModal, setTaskModal] = useState<{ agentId: string; agentName: string } | null>(null);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskSubmitting, setTaskSubmitting] = useState(false);
  const [worldUrl, setWorldUrl] = useState(`http://localhost:3002/?server=http://127.0.0.1:18800&theme=${theme}`);

  useEffect(() => {
    setWorldUrl(getWorldUrl(theme));
  }, [theme]);

  useEffect(() => {
    fetch('/api/agents').then(r => r.json()).then(d => {
      const sorted = (d.agents || []).sort((a: Agent, b: Agent) => {
        // Active first, then by lastActive descending
        if (a.status === 'active' && b.status !== 'active') return -1;
        if (b.status === 'active' && a.status !== 'active') return 1;
        const aTime = new Date(a.lastActive || '2000-01-01').getTime();
        const bTime = new Date(b.lastActive || '2000-01-01').getTime();
        return bTime - aTime;
      });
      setAgents(sorted);
    }).catch(() => {});
  }, []);

  // Listen for postMessage from Agent World iframe (Phase B integration)
  useEffect(() => {
    const handler = (event: MessageEvent) => {
      if (event.data?.type !== 'agent-action') return;
      const { action, agentId } = event.data;
      if (action === 'profile') onSelectAgent(agentId);
      else if (action === 'chat') {
        // Open profile with chat tab active
        (window as any).__openAgentChat = agentId;
        onSelectAgent(agentId);
      }
      else if (action === 'assign-task') {
        const agent = agents.find(a => a.id === agentId);
        setTaskModal({ agentId, agentName: agent?.displayName || agent?.name || agentId });
        setTaskTitle('');
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [onSelectAgent]);

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 120px)', minHeight: '300px', overflow: 'hidden' }}>
      <div className="flex-1 flex rounded-lg overflow-hidden border border-mc-border relative" style={{ minHeight: 0 }}>
        {/* Floating controls */}
        <div className="absolute top-2 right-2 z-10 flex items-center gap-1 bg-black/60 backdrop-blur-sm rounded-lg px-2 py-1">
          {THEMES.map(t => (
            <button key={t.id} onClick={() => setTheme(t.id)}
              className={`text-xs px-1.5 py-0.5 rounded transition-colors ${theme === t.id ? 'bg-mc-accent text-white' : 'text-white/70 hover:text-white'}`}>
              {t.label}
            </button>
          ))}
          <span className="text-white/20 mx-0.5">|</span>
          <button onClick={() => setPanelOpen(p => !p)}
            className="text-xs px-1.5 py-0.5 rounded text-white/70 hover:text-white transition-colors">
            👥
          </button>
          <button onClick={async () => { try { await fetch('/api/agents/world-reset', { method: 'POST' }); } catch {} }}
            className="text-xs px-1.5 py-0.5 rounded text-white/70 hover:text-green-400 transition-colors" title="Reset Agents">
            🔄
          </button>
          <a href={worldUrl} target="_blank" rel="noopener noreferrer"
            className="text-xs px-1.5 py-0.5 rounded text-white/70 hover:text-white transition-colors" title="Open Fullscreen">
            ↗
          </a>
        </div>
        {/* 3D world - hidden on mobile, show agent grid instead */}
        <div className="hidden md:flex flex-1">
          <iframe
            src={worldUrl}
            className="flex-1 h-full"
            style={{ border: 'none' }}
            allow="fullscreen"
            title="OpenClaw Agent World"
          />
        </div>
        <div className="flex md:hidden flex-1 flex-col bg-mc-bg p-4 overflow-y-auto">
          <p className="text-xs text-mc-muted mb-3">3D view available on desktop. Tap an agent to view profile.</p>
          <div className="grid grid-cols-2 gap-3">
            {agents.map(agent => {
              const emoji = CHARACTER_EMOJIS[agent.avatarType || 'lobster'] || '🦞';
              const tier = TIER_BADGES[agent.tier] || TIER_BADGES[6];
              return (
                <button key={agent.id} onClick={() => onSelectAgent(agent.id)}
                  className="flex flex-col items-center gap-1 p-3 rounded-lg bg-mc-surface border border-mc-border hover:border-mc-accent transition-colors">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                    style={{ backgroundColor: agent.color + '22', border: `2px solid ${agent.color}` }}>
                    {emoji}
                  </div>
                  <span className="text-sm font-medium">{agent.name}</span>
                  <span className={`text-[10px] font-bold ${tier.color}`}>{tier.label}</span>
                  <span className={`w-2 h-2 rounded-full ${agent.status === 'active' ? 'bg-green-500' : 'bg-gray-500'}`} />
                </button>
              );
            })}
          </div>
        </div>
        {panelOpen && (
          <div className="w-56 bg-mc-surface border-l border-mc-border overflow-y-auto flex-shrink-0">
            <div className="px-3 py-2 border-b border-mc-border">
              <span className="text-[10px] text-mc-muted uppercase tracking-wider font-bold">Agents</span>
            </div>
            {agents.map(agent => {
              const emoji = CHARACTER_EMOJIS[agent.avatarType || 'lobster'] || '🦞';
              const tier = TIER_BADGES[agent.tier] || TIER_BADGES[6];
              return (
                <button key={agent.id} onClick={() => onSelectAgent(agent.id)}
                  className="w-full flex items-center gap-2 px-3 py-2 hover:bg-mc-bg transition-colors text-left group">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-lg relative"
                    style={{ backgroundColor: agent.color + '22', border: `2px solid ${agent.color}` }}>
                    {emoji}
                    <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-mc-surface ${
                      agent.status === 'active' ? 'bg-green-500' : 'bg-gray-500'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="text-sm font-medium truncate group-hover:text-mc-accent transition-colors">{agent.name}</span>
                      <span className={`text-[10px] font-bold ${tier.color}`}>{tier.label}</span>
                    </div>
                    <div className="text-[10px] text-mc-muted truncate">{agent.role}</div>
                  </div>
                </button>
              );
            })}
            <div className="px-3 py-2 border-t border-mc-border">
              <div className="text-[10px] text-mc-muted">
                {agents.filter(a => a.status === 'active').length} active · {agents.length} total
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Task Assignment Modal */}
      {taskModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center" onClick={() => setTaskModal(null)}>
          <div className="bg-mc-surface border border-mc-border rounded-xl p-6 w-[400px] max-w-[90vw]" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-1">📋 Assign Task</h3>
            <p className="text-sm text-mc-muted mb-4">Assign to <span className="text-mc-accent font-semibold">{taskModal.agentName}</span></p>
            <input
              type="text"
              value={taskTitle}
              onChange={e => setTaskTitle(e.target.value)}
              placeholder="Describe the task..."
              className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded-lg text-sm mb-3 focus:outline-none focus:border-mc-accent"
              autoFocus
              onKeyDown={e => { if (e.key === 'Enter' && taskTitle.trim()) {
                setTaskSubmitting(true);
                fetch('/api/tasks', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ title: taskTitle.trim(), assignee: taskModal.agentId, status: 'in-progress', priority: 'medium' }),
                }).then(() => { setTaskModal(null); setTaskSubmitting(false); }).catch(() => setTaskSubmitting(false));
              }}}
            />
            <div className="flex gap-2 justify-end">
              <button onClick={() => setTaskModal(null)} className="text-sm px-3 py-1.5 rounded-lg text-mc-muted hover:text-white transition-colors">Cancel</button>
              <button
                disabled={!taskTitle.trim() || taskSubmitting}
                onClick={() => {
                  if (!taskTitle.trim()) return;
                  setTaskSubmitting(true);
                  fetch('/api/tasks', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title: taskTitle.trim(), assignee: taskModal.agentId, status: 'in-progress', priority: 'medium' }),
                  }).then(() => { setTaskModal(null); setTaskSubmitting(false); }).catch(() => setTaskSubmitting(false));
                }}
                className="text-sm px-4 py-1.5 rounded-lg bg-mc-accent text-white font-medium hover:bg-mc-accent/80 transition-colors disabled:opacity-50"
              >{taskSubmitting ? 'Assigning...' : 'Assign & Start'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
