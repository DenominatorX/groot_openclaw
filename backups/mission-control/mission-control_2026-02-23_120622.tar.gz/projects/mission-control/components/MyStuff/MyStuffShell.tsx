'use client';

export default function MyStuffShell() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-mc-text mb-4">🗂️ My Stuff</h2>
      <p className="text-mc-muted">Your personal workspace — files, notes, and bookmarks.</p>
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <h3 className="font-semibold text-mc-text mb-2">📝 Notes</h3>
          <p className="text-sm text-mc-muted">Quick notes and scratchpad</p>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <h3 className="font-semibold text-mc-text mb-2">📁 Files</h3>
          <p className="text-sm text-mc-muted">Uploaded files and documents</p>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <h3 className="font-semibold text-mc-text mb-2">🔖 Bookmarks</h3>
          <p className="text-sm text-mc-muted">Saved links and references</p>
        </div>
      </div>
    </div>
  );
}
