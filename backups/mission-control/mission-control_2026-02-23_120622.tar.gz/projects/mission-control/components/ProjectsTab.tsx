'use client';
import { useState, useEffect, useMemo } from 'react';
import ProjectProfile from './ProjectProfile';

interface ProjectAgent { agentId: string; role: string; }
interface Project {
  id: string; name: string; description: string; status: string;
  priority: string; goals: string[]; agents: ProjectAgent[];
  createdAt: string; updatedAt: string; stats: any;
  title?: string; assignee?: string; roles?: any[];
  created?: string; updated?: string;
}

interface TeamRole {
  id: string; title: string; tier: string;
  responsibilities: string[]; rules: string[];
  expectedDocuments?: string[];
  autoMatchCriteria?: any;
}

interface Team {
  id: string; name: string; description: string;
  category: string; isDefault?: boolean;
  roles: TeamRole[];
  instructions?: string;
}

const STATUS_COLORS: Record<string, string> = {
  planning: 'bg-blue-500/20 text-blue-400',
  active: 'bg-green-500/20 text-green-400',
  'in-progress': 'bg-amber-500/20 text-amber-400 border border-amber-500/30',
  'on-hold': 'bg-yellow-500/20 text-yellow-400',
  completed: 'bg-purple-500/20 text-purple-400',
  complete: 'bg-purple-500/20 text-purple-400',
  review: 'bg-orange-500/20 text-orange-400',
};

const PRIORITY_COLORS: Record<string, string> = {
  low: 'text-gray-400', medium: 'text-blue-400', high: 'text-orange-400', critical: 'text-red-400',
};

const STATUS_FILTERS = ['all', 'planning', 'active', 'in-progress', 'backlog', 'review', 'on-hold', 'complete'] as const;
type SortKey = 'name' | 'status' | 'priority' | 'createdAt' | 'updatedAt' | 'agents' | 'mcId' | 'assignee';

// ══════════════════════════════════════════════
// TEAM MANAGEMENT FLYOUT
// ══════════════════════════════════════════════
function TeamManagementFlyout({ onClose }: { onClose: () => void }) {
  const [teams, setTeams] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editInstructions, setEditInstructions] = useState('');
  const [newTeamName, setNewTeamName] = useState('');
  const [showNewTeam, setShowNewTeam] = useState(false);
  const [newRoleTitle, setNewRoleTitle] = useState('');
  const [saving, setSaving] = useState(false);

  const load = () => {
    fetch('/api/teams').then(r => r.json()).then(d => {
      const t = d.teams || [];
      setTeams(t);
      if (selectedTeam) {
        const updated = t.find((tt: Team) => tt.id === selectedTeam.id);
        if (updated) setSelectedTeam(updated);
      }
    }).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (selectedTeam) {
      setEditName(selectedTeam.name);
      setEditDesc(selectedTeam.description || '');
      setEditInstructions(selectedTeam.instructions || '');
    }
  }, [selectedTeam?.id]);

  const saveTeam = async (team: Team) => {
    setSaving(true);
    await fetch('/api/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', team }),
    });
    setSaving(false);
    load();
  };

  const createTeam = async () => {
    if (!newTeamName.trim()) return;
    const id = newTeamName.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const team: Team = {
      id, name: newTeamName.trim(), description: '',
      category: 'custom', roles: [], instructions: '',
    };
    await fetch('/api/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', team }),
    });
    setNewTeamName('');
    setShowNewTeam(false);
    load();
  };

  const deleteTeam = async (id: string) => {
    if (!confirm('Delete this team template?')) return;
    await fetch('/api/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete', id }),
    });
    if (selectedTeam?.id === id) setSelectedTeam(null);
    load();
  };

  const addRole = () => {
    if (!newRoleTitle.trim() || !selectedTeam) return;
    const roleId = newRoleTitle.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const updated = {
      ...selectedTeam,
      roles: [...selectedTeam.roles, {
        id: roleId, title: newRoleTitle.trim(), tier: 'member',
        responsibilities: [], rules: [],
      }],
    };
    setSelectedTeam(updated);
    saveTeam(updated);
    setNewRoleTitle('');
  };

  const removeRole = (roleId: string) => {
    if (!selectedTeam) return;
    const updated = { ...selectedTeam, roles: selectedTeam.roles.filter(r => r.id !== roleId) };
    setSelectedTeam(updated);
    saveTeam(updated);
  };

  const saveCurrentTeam = () => {
    if (!selectedTeam) return;
    const updated = { ...selectedTeam, name: editName, description: editDesc, instructions: editInstructions };
    setSelectedTeam(updated);
    saveTeam(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />

      {/* Flyout panel */}
      <div className="absolute right-0 top-0 bottom-0 w-[600px] max-w-[90vw] bg-mc-surface border-l border-mc-border shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-4 py-3 border-b border-mc-border flex items-center justify-between flex-shrink-0">
          <h2 className="font-bold text-lg">👥 Project Teams</h2>
          <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
        </div>

        <div className="flex-1 overflow-hidden flex">
          {/* Team list sidebar */}
          <div className="w-48 border-r border-mc-border flex flex-col flex-shrink-0">
            <div className="p-2 border-b border-mc-border">
              {showNewTeam ? (
                <div className="flex flex-col gap-1">
                  <input value={newTeamName} onChange={e => setNewTeamName(e.target.value)}
                    placeholder="Team name..." className="bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs" autoFocus
                    onKeyDown={e => { if (e.key === 'Enter') createTeam(); if (e.key === 'Escape') setShowNewTeam(false); }} />
                  <div className="flex gap-1">
                    <button onClick={createTeam} className="flex-1 px-2 py-0.5 bg-mc-accent text-white rounded text-xs">Create</button>
                    <button onClick={() => setShowNewTeam(false)} className="px-2 py-0.5 text-mc-muted text-xs">✕</button>
                  </div>
                </div>
              ) : (
                <button onClick={() => setShowNewTeam(true)} className="w-full px-2 py-1 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30">
                  + New Team
                </button>
              )}
            </div>
            <div className="flex-1 overflow-y-auto">
              {teams.map(t => (
                <div key={t.id} onClick={() => setSelectedTeam(t)}
                  className={`px-3 py-2 cursor-pointer text-sm border-b border-mc-border/30 hover:bg-mc-bg/50 ${selectedTeam?.id === t.id ? 'bg-mc-accent/10 text-mc-accent border-l-2 border-l-mc-accent' : 'text-mc-text'}`}>
                  <div className="font-medium text-xs truncate">{t.name}</div>
                  <div className="text-[10px] text-mc-muted">{t.roles.length} role{t.roles.length !== 1 ? 's' : ''}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Team detail */}
          <div className="flex-1 overflow-y-auto p-4">
            {!selectedTeam ? (
              <div className="text-center py-12 text-mc-muted">
                <div className="text-3xl mb-2">👥</div>
                <div className="text-sm">Select a team to manage, or create a new one.</div>
                <div className="text-xs mt-2">Teams are reusable templates you can apply to any project.</div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Team name & description */}
                <div>
                  <label className="text-xs text-mc-muted mb-1 block">Team Name</label>
                  <input value={editName} onChange={e => setEditName(e.target.value)}
                    className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm" />
                </div>
                <div>
                  <label className="text-xs text-mc-muted mb-1 block">Description</label>
                  <input value={editDesc} onChange={e => setEditDesc(e.target.value)}
                    className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm" placeholder="What this team does..." />
                </div>

                {/* Instructions box */}
                <div>
                  <label className="text-xs text-mc-muted mb-1 block">📋 Team Instructions</label>
                  <textarea value={editInstructions} onChange={e => setEditInstructions(e.target.value)}
                    rows={4} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm resize-none"
                    placeholder="Enter team-wide instructions, rules, or context that all team members should follow..." />
                </div>

                <div className="flex gap-2">
                  <button onClick={saveCurrentTeam} disabled={saving}
                    className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:bg-mc-accent/80 disabled:opacity-50">
                    {saving ? 'Saving...' : '💾 Save Changes'}
                  </button>
                  <button onClick={() => deleteTeam(selectedTeam.id)}
                    className="px-3 py-1.5 bg-red-500/20 text-red-400 rounded text-sm hover:bg-red-500/30">
                    🗑 Delete Team
                  </button>
                </div>

                {/* Roles */}
                <div className="border-t border-mc-border pt-3">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold">Roles ({selectedTeam.roles.length})</h3>
                  </div>

                  <div className="space-y-2 mb-3">
                    {selectedTeam.roles.map(role => (
                      <div key={role.id} className="bg-mc-bg border border-mc-border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-1">
                          <div className="font-medium text-sm">{role.title}</div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-mc-surface text-mc-muted capitalize">{role.tier}</span>
                            <button onClick={() => removeRole(role.id)} className="text-red-400 hover:text-red-300 text-xs">✕</button>
                          </div>
                        </div>
                        {role.responsibilities.length > 0 && (
                          <div className="text-xs text-mc-muted mt-1">
                            {role.responsibilities.slice(0, 3).join(' · ')}
                            {role.responsibilities.length > 3 && ` +${role.responsibilities.length - 3} more`}
                          </div>
                        )}
                        {role.rules.length > 0 && (
                          <div className="text-[10px] text-mc-muted mt-1 opacity-60">
                            {role.rules.length} rule{role.rules.length !== 1 ? 's' : ''}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Add role */}
                  <div className="flex gap-2">
                    <input value={newRoleTitle} onChange={e => setNewRoleTitle(e.target.value)}
                      placeholder="New role title..." className="flex-1 bg-mc-bg border border-mc-border rounded px-3 py-1 text-sm"
                      onKeyDown={e => e.key === 'Enter' && addRole()} />
                    <button onClick={addRole} className="px-2 py-1 text-xs bg-mc-accent/20 text-mc-accent rounded">+ Add Role</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════
// PROJECTS TAB (MAIN)
// ══════════════════════════════════════════════
export default function ProjectsTab() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [agents, setAgents] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('updatedAt');
  const [sortAsc, setSortAsc] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [showTeams, setShowTeams] = useState(false);

  const load = () => {
    fetch('/api/projects').then(r => r.json()).then(d => setProjects(d.projects || []));
    fetch('/api/agents').then(r => r.json()).then(d => setAgents(d.agents || []));
  };
  useEffect(load, []);

  const agentMap = useMemo(() => {
    const m: Record<string, any> = {};
    agents.forEach(a => m[a.id] = a);
    return m;
  }, [agents]);

  const getProjectName = (p: Project) => p.name || p.title || 'Untitled';
  const getProjectAgents = (p: Project) => p.agents || (p.roles || []).map((r: any) => ({ agentId: r.agentId, role: r.role }));
  const getPM = (p: Project) => {
    const pa = getProjectAgents(p);
    const pm = pa.find((a: ProjectAgent) => a.role === 'Project Manager' || a.role === 'lead');
    if (pm) return agentMap[pm.agentId]?.displayName || pm.agentId;
    return p.assignee || '—';
  };

  const filtered = useMemo(() => {
    let list = projects;
    if (statusFilter !== 'all') list = list.filter(p => (p.status || '').toLowerCase() === statusFilter);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(p => {
        const name = getProjectName(p).toLowerCase();
        const desc = (p.description || '').toLowerCase();
        const pm = getPM(p).toLowerCase();
        return name.includes(q) || desc.includes(q) || pm.includes(q) || (p.status || '').toLowerCase().includes(q);
      });
    }
    return [...list].sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'name') cmp = getProjectName(a).localeCompare(getProjectName(b));
      else if (sortKey === 'status') cmp = (a.status || '').localeCompare(b.status || '');
      else if (sortKey === 'priority') {
        const order = ['critical', 'high', 'medium', 'low'];
        cmp = order.indexOf(a.priority) - order.indexOf(b.priority);
      }
      else if (sortKey === 'agents') cmp = getProjectAgents(a).length - getProjectAgents(b).length;
      else if (sortKey === 'createdAt') cmp = (a.createdAt || a.created || '').localeCompare(b.createdAt || b.created || '');
      else if (sortKey === 'updatedAt') cmp = (a.updatedAt || a.updated || '').localeCompare(b.updatedAt || b.updated || '');
      else if (sortKey === 'mcId') {
        const numA = parseInt(((a as any).mcId || '').replace('MC-', '') || '0', 10);
        const numB = parseInt(((b as any).mcId || '').replace('MC-', '') || '0', 10);
        cmp = numA - numB;
      }
      else if (sortKey === 'assignee') cmp = (a.assignee || '').localeCompare(b.assignee || '');
      return sortAsc ? cmp : -cmp;
    });
  }, [projects, search, statusFilter, sortKey, sortAsc, agents]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(true); }
  };
  const sortIcon = (key: SortKey) => sortKey === key ? (sortAsc ? ' ▲' : ' ▼') : '';

  const createProject = async () => {
    if (!newName.trim()) return;
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'create', title: newName.trim(), name: newName.trim(),
        agents: [{ agentId: 'ceo', role: 'Project Manager' }],
      }),
    });
    setNewName(''); setShowNew(false); load();
  };

  const fmtDate = (d: string | undefined) => {
    if (!d) return '—';
    try { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); }
    catch { return '—'; }
  };

  if (selectedId) {
    return <ProjectProfile projectId={selectedId} onClose={() => { setSelectedId(null); load(); }} agentMap={agentMap} allAgents={agents} />;
  }

  return (
    <div>
      {/* Title row with buttons */}
      <div className="flex items-center gap-2 mb-3">
        <div className="flex-1" />
        <button onClick={() => setShowTeams(true)}
          className="px-3 py-1.5 bg-mc-surface border border-mc-border text-mc-text rounded text-sm hover:bg-mc-bg flex items-center gap-1.5">
          👥 Project Teams
        </button>
        <button onClick={() => setShowNew(true)}
          className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:bg-mc-accent/80">
          + New Project
        </button>
      </div>

      {showNew && (
        <div className="mb-4 p-3 bg-mc-surface border border-mc-border rounded-lg flex gap-2">
          <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Project name..."
            className="flex-1 bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm" autoFocus
            onKeyDown={e => e.key === 'Enter' && createProject()} />
          <button onClick={createProject} className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm">Create</button>
          <button onClick={() => setShowNew(false)} className="px-3 py-1.5 text-mc-muted hover:text-mc-text text-sm">Cancel</button>
        </div>
      )}

      {/* Search + filters */}
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search projects..."
          className="bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm flex-1 min-w-[200px]" />
        <div className="flex gap-1">
          {STATUS_FILTERS.map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-2 py-1 rounded text-xs capitalize ${statusFilter === s ? 'bg-mc-accent/20 text-mc-accent' : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-mc-border text-mc-muted text-xs">
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text font-mono" onClick={() => toggleSort('mcId')}>ID{sortIcon('mcId')}</th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text" onClick={() => toggleSort('name')}>Project{sortIcon('name')}</th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text" onClick={() => toggleSort('status')}>Status{sortIcon('status')}</th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text" onClick={() => toggleSort('priority')}>Priority{sortIcon('priority')}</th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text hidden sm:table-cell" onClick={() => toggleSort('assignee')}>PM / Assignee{sortIcon('assignee')}</th>
              <th className="text-left px-3 py-2 hidden md:table-cell">PM</th>
              <th className="text-center px-3 py-2 cursor-pointer hover:text-mc-text hidden md:table-cell" onClick={() => toggleSort('agents')}>Agents{sortIcon('agents')}</th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text hidden lg:table-cell" onClick={() => toggleSort('createdAt')}>Created{sortIcon('createdAt')}</th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-mc-text hidden lg:table-cell" onClick={() => toggleSort('updatedAt')}>Updated{sortIcon('updatedAt')}</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(p => (
              <tr key={p.id} onClick={() => setSelectedId(p.id)}
                className="border-b border-mc-border/50 hover:bg-mc-bg/50 cursor-pointer transition-colors">
                <td className="px-3 py-2.5 text-xs font-mono text-mc-accent">{(p as any).mcId || p.id}</td>
                <td className="px-3 py-2.5 font-medium">{getProjectName(p)}</td>
                <td className="px-3 py-2.5">
                  <span className={`px-2 py-0.5 rounded-full text-xs ${STATUS_COLORS[p.status] || 'text-mc-muted'}`}>{p.status}</span>
                </td>
                <td className={`px-3 py-2.5 text-xs capitalize ${PRIORITY_COLORS[p.priority] || ''}`}>{p.priority}</td>
                <td className="px-3 py-2.5 text-xs text-mc-muted hidden sm:table-cell">{p.assignee || 'Unassigned'}</td>
                <td className="px-3 py-2.5 text-xs text-mc-muted hidden md:table-cell">{getPM(p)}</td>
                <td className="px-3 py-2.5 text-xs text-center hidden md:table-cell">{getProjectAgents(p).length}</td>
                <td className="px-3 py-2.5 text-xs text-mc-muted hidden lg:table-cell">{fmtDate(p.createdAt || p.created)}</td>
                <td className="px-3 py-2.5 text-xs text-mc-muted hidden lg:table-cell">{fmtDate(p.updatedAt || p.updated)}</td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={9} className="px-3 py-8 text-center text-mc-muted">No projects found</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Teams Flyout */}
      {showTeams && <TeamManagementFlyout onClose={() => setShowTeams(false)} />}
    </div>
  );
}
