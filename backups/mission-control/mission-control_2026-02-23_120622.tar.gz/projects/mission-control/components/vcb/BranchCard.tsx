'use client';

import { useState, useRef, useEffect } from 'react';

interface Branch {
  id: string;
  name: string;
  parent_id: string | null;
  status: 'active' | 'merged' | 'archived' | 'stale';
  description: string | null;
  color: string;
  created_at: string;
  updated_at: string;
  last_commit_id?: string;
  last_commit_message?: string;
  last_commit_author?: string;
  last_commit_at?: string;
  commit_count?: number;
  snapshot_count?: number;
}

interface BranchCardProps {
  branch: Branch;
  depth: number;
  expanded: boolean;
  hasChildren: boolean;
  onToggleExpand: () => void;
  onStatusChange: (status: Branch['status']) => void;
}

function formatRelativeTime(timestamp: string | undefined): string {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString();
}

const statusColors = {
  active: 'bg-green-500/20 text-green-400 border-green-500/30',
  merged: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  archived: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  stale: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
};

export default function BranchCard({
  branch,
  depth,
  expanded,
  hasChildren,
  onToggleExpand,
  onStatusChange,
}: BranchCardProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div
      className="flex items-center gap-3 px-4 py-3 bg-[--mc-surface] rounded-xl border border-[--mc-border] border-l-4 hover:border-[--mc-accent]/40 hover:bg-[--mc-surface]/80 transition-all duration-150 cursor-default"
      style={{ borderLeftColor: branch.color }}
    >
      {/* Expand Arrow */}
      <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
        {hasChildren ? (
          <button
            onClick={onToggleExpand}
            className="text-[--mc-muted] hover:text-[--mc-text] cursor-pointer transition-transform duration-150"
            style={{ transform: expanded ? 'rotate(90deg)' : 'rotate(0deg)' }}
          >
            ‹
          </button>
        ) : null}
      </div>

      {/* Color Dot */}
      <div
        className="w-2.5 h-2.5 rounded-full flex-shrink-0"
        style={{ background: branch.color }}
      />

      {/* Branch Name */}
      <span className="text-[--mc-text] font-semibold text-sm flex-1 truncate">
        {branch.name}
      </span>

      {/* Status Badge */}
      <span className={`text-xs px-2 py-0.5 rounded-full font-medium border ${statusColors[branch.status]}`}>
        {branch.status}
      </span>

      {/* Last Commit */}
      <div className="flex flex-col items-end min-w-0 max-w-[180px]">
        <span className="text-[--mc-muted] text-xs truncate w-full text-right">
          {branch.last_commit_message || 'No commits yet'}
        </span>
        <div className="flex items-center gap-2 text-[--mc-muted] text-xs">
          {branch.last_commit_at && (
            <span>{formatRelativeTime(branch.last_commit_at)}</span>
          )}
          {branch.commit_count !== undefined && (
            <span>{branch.commit_count} commits</span>
          )}
        </div>
      </div>

      {/* Actions Dropdown */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={() => setDropdownOpen(!dropdownOpen)}
          className="text-[--mc-muted] hover:text-[--mc-text] p-1 rounded transition-colors"
        >
          ⋯
        </button>

        {dropdownOpen && (
          <div className="absolute right-0 top-full mt-1 bg-[--mc-surface] border border-[--mc-border] rounded-lg shadow-lg py-1 z-20 min-w-[140px]">
            <button
              onClick={() => {
                onStatusChange('active');
                setDropdownOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm text-[--mc-text] hover:bg-[--mc-border]/50 transition-colors"
            >
              Mark Active
            </button>
            <button
              onClick={() => {
                onStatusChange('merged');
                setDropdownOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm text-[--mc-text] hover:bg-[--mc-border]/50 transition-colors"
            >
              Mark Merged
            </button>
            <button
              onClick={() => {
                onStatusChange('archived');
                setDropdownOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm text-[--mc-text] hover:bg-[--mc-border]/50 transition-colors"
            >
              Mark Archived
            </button>
            <button
              onClick={() => {
                onStatusChange('stale');
                setDropdownOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-sm text-[--mc-text] hover:bg-[--mc-border]/50 transition-colors"
            >
              Mark Stale
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
