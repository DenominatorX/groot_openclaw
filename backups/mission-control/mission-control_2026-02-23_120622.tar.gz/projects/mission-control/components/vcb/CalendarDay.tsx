'use client';

interface CalendarDayProps {
  date: number | null;
  isoDate: string | null;
  isToday: boolean;
  isSelected: boolean;
  commitCount: number;
  snapshotCount: number;
  branchColors: string[];
  onClick: () => void;
}

export default function CalendarDay({
  date,
  isoDate,
  isToday,
  isSelected,
  commitCount,
  snapshotCount,
  branchColors,
  onClick,
}: CalendarDayProps) {
  // Empty cell when date === null
  if (date === null) {
    return <div className="flex flex-col items-center justify-center h-10 w-full" />;
  }

  const totalActivity = commitCount + snapshotCount;
  const displayColors = branchColors.slice(0, 3);
  const overflowCount = branchColors.length > 3 ? branchColors.length - 3 : 0;

  return (
    <button
      onClick={onClick}
      className={`
        relative flex flex-col items-center justify-center h-10 w-full rounded-lg
        cursor-pointer transition-all duration-150
        hover:bg-[--mc-border]/60
        ${isSelected ? 'bg-[--mc-accent]/20 ring-1 ring-[--mc-accent]' : ''}
        ${isToday ? 'ring-1 ring-[--mc-accent]/50' : ''}
      `}
    >
      <span
        className={`
          text-sm font-medium
          ${isToday ? 'text-[--mc-accent]' : 'text-[--mc-text]'}
        `}
      >
        {date}
      </span>

      {/* Dots row */}
      {totalActivity > 0 && (
        <div className="flex items-center gap-0.5 mt-0.5">
          {displayColors.map((color, idx) => (
            <div
              key={idx}
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: color }}
            />
          ))}
          {overflowCount > 0 && (
            <span className="text-[--mc-muted] text-[8px] ml-0.5">
              +{overflowCount}
            </span>
          )}
          {snapshotCount > 0 && totalActivity > 0 && (
            <span className="text-[8px] text-[--mc-accent]">★</span>
          )}
        </div>
      )}
    </button>
  );
}
