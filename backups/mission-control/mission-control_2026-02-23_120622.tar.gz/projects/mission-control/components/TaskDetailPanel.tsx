/* @ts-nocheck */
'use client';
import { useState, useEffect, useRef, useCallback } from 'react';

// ─── Types ───────────────────────────────────────────────────────────────────

interface TeamMember {
  agentId: string;
  role: string;
  model: string;
  rationale: string;
}

interface AnalysisResult {
  viability: 'still_needed' | 'already_implemented' | 'superseded' | 'too_complex';
  existingFeatureMatch?: string;
  complexity: 'simple' | 'moderate' | 'complex' | 'very_complex';
  suggestedProjectIds?: string[];
  suggestedProjectTitles?: string[];
  team: TeamMember[];
  gameplan: string;
  estimatedCost: string;
  analyzedAt: string;
  reasoning?: string;
}

interface LogEntry {
  ts: string;
  agent: string;
  message: string;
  type: 'info' | 'progress' | 'success' | 'error';
}

interface ChatMessage {
  id: string;
  agentId: string;
  role: 'user' | 'agent';
  content: string;
  ts: string;
}

interface Task {
  id: string;
  title: string;
  column: string;
  assignee: string;
  priority: string;
  tags: string[];
  created: string;
  description?: string;
  dueDate?: string;
  instructions?: string;
  teamComposition?: TeamMember[];
  analysisResult?: AnalysisResult;
  executionLog?: LogEntry[];
  executionStatus?: 'idle' | 'running' | 'complete' | 'failed';
  teamChat?: ChatMessage[];
  pipelineStatus?: 'backlog' | 'active' | 'review' | 'done';
}

// ─── Constants ────────────────────────────────────────────────────────────────

const PRIORITIES = [
  { id: 'critical', label: 'Critical', color: 'bg-red-600/30 text-red-300 border-red-600/50' },
  { id: 'high',     label: 'High',     color: 'bg-red-500/20 text-red-400 border-red-500/30' },
  { id: 'medium',   label: 'Medium',   color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' },
  { id: 'low',      label: 'Low',      color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
];

const PIPELINE_STEPS: { id: 'backlog' | 'active' | 'review' | 'done'; label: string; color: string }[] = [
  { id: 'backlog', label: 'Backlog', color: 'bg-gray-500' },
  { id: 'active',  label: 'Active',  color: 'bg-blue-500' },
  { id: 'review',  label: 'Review',  color: 'bg-yellow-500' },
  { id: 'done',    label: 'Done',    color: 'bg-green-500' },
];

const VIABILITY_CONFIG: Record<string, { label: string; color: string }> = {
  still_needed:       { label: 'Still Needed',       color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  already_implemented:{ label: 'Already Implemented', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  superseded:         { label: 'Superseded',          color: 'bg-gray-500/20 text-gray-400 border-gray-500/30' },
  too_complex:        { label: 'Too Complex',          color: 'bg-red-500/20 text-red-400 border-red-500/30' },
};

const COMPLEXITY_CONFIG: Record<string, { label: string; color: string }> = {
  simple:      { label: 'Simple',      color: 'bg-green-500/20 text-green-400' },
  moderate:    { label: 'Moderate',    color: 'bg-yellow-500/20 text-yellow-400' },
  complex:     { label: 'Complex',     color: 'bg-orange-500/20 text-orange-400' },
  very_complex:{ label: 'Very Complex',color: 'bg-red-500/20 text-red-400' },
};

const LOG_COLORS: Record<string, string> = {
  info:     'text-gray-400',
  progress: 'text-blue-400',
  success:  'text-green-400',
  error:    'text-red-400',
};

const AGENT_AVATAR_COLORS = [
  '#6366f1','#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6',
];

function agentColor(agentId: string) {
  let hash = 0;
  for (let i = 0; i < agentId.length; i++) hash = agentId.charCodeAt(i) + ((hash << 5) - hash);
  return AGENT_AVATAR_COLORS[Math.abs(hash) % AGENT_AVATAR_COLORS.length];
}

function agentInitials(agentId: string) {
  return agentId.split(/[-_\s]/).map(p => p[0] || '').join('').toUpperCase().slice(0, 2);
}

function fmtTime(ts: string) {
  try { return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
  catch { return ts; }
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function AgentAvatar({ agentId, size = 7 }: { agentId: string; size?: number }) {
  const color = agentColor(agentId);
  const sz = `w-${size} h-${size}`;
  return (
    <div className={`${sz} rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0`}
      style={{ backgroundColor: color }}>
      {agentInitials(agentId)}
    </div>
  );
}

// ─── Tab: Overview ────────────────────────────────────────────────────────────

function OverviewTab({ task, onSave }: { task: Task; onSave: (id: string, updates: Partial<Task>) => void }) {
  const [title, setTitle]       = useState(task.title);
  const [desc, setDesc]         = useState(task.description || '');
  const [instructions, setInst] = useState(task.instructions || '');
  const [priority, setPriority] = useState(task.priority);
  const [assignee, setAssignee] = useState(task.assignee || '');
  const [tagInput, setTagInput] = useState((task.tags || []).join(', '));
  const [pipeline, setPipeline] = useState<Task['pipelineStatus']>(task.pipelineStatus || 'backlog');
  const [saving, setSaving]     = useState(false);

  const persist = useCallback(async (updates: Partial<Task>) => {
    setSaving(true);
    try { await onSave(task.id, updates); } finally { setSaving(false); }
  }, [task.id, onSave]);

  const saveTags = () => {
    const tags = tagInput.split(',').map(t => t.trim().replace(/^#/, '')).filter(Boolean);
    persist({ tags });
  };

  const setPipelineStep = (step: Task['pipelineStatus']) => {
    setPipeline(step);
    persist({ pipelineStatus: step });
  };

  return (
    <div className="space-y-4 pb-4">
      {/* Title */}
      <input
        value={title}
        onChange={e => setTitle(e.target.value)}
        onBlur={() => persist({ title })}
        className="w-full text-xl font-bold bg-transparent border-none text-mc-text focus:outline-none focus:border-b focus:border-mc-accent pb-1"
        placeholder="Task title..."
      />

      {/* Description */}
      <div>
        <label className="text-xs text-mc-muted mb-1 block font-medium uppercase tracking-wide">Description</label>
        <textarea
          value={desc}
          onChange={e => setDesc(e.target.value)}
          onBlur={() => persist({ description: desc })}
          rows={3}
          placeholder="Add details, context, background..."
          className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent resize-y"
        />
      </div>

      {/* Instructions */}
      <div>
        <label className="text-xs text-mc-muted mb-1 block font-medium uppercase tracking-wide">Instructions</label>
        <textarea
          value={instructions}
          onChange={e => setInst(e.target.value)}
          onBlur={async () => {
            setSaving(true);
            try {
              await fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'update-instructions', id: task.id, instructions }),
              });
              await onSave(task.id, { instructions });
            } finally { setSaving(false); }
          }}
          rows={6}
          placeholder="Detailed step-by-step instructions for executing this task..."
          className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent resize-y font-mono"
        />
      </div>

      {/* Priority + Assignee */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-mc-muted mb-2 block font-medium uppercase tracking-wide">Priority</label>
          <div className="flex flex-wrap gap-1.5">
            {PRIORITIES.map(p => (
              <button
                key={p.id}
                onClick={() => { setPriority(p.id); persist({ priority: p.id }); }}
                className={`px-2.5 py-1 rounded text-xs border transition-colors ${
                  priority === p.id ? `${p.color} font-medium` : 'border-mc-border text-mc-muted hover:border-mc-accent/50'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="text-xs text-mc-muted mb-2 block font-medium uppercase tracking-wide">Assignee</label>
          <input
            value={assignee}
            onChange={e => setAssignee(e.target.value)}
            onBlur={() => persist({ assignee })}
            placeholder="Assign to..."
            className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent"
          />
        </div>
      </div>

      {/* Tags */}
      <div>
        <label className="text-xs text-mc-muted mb-1 block font-medium uppercase tracking-wide">Tags (comma-separated)</label>
        <input
          value={tagInput}
          onChange={e => setTagInput(e.target.value)}
          onBlur={saveTags}
          placeholder="tag1, tag2, tag3"
          className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent"
        />
      </div>

      {/* Pipeline Status Bar */}
      <div>
        <label className="text-xs text-mc-muted mb-2 block font-medium uppercase tracking-wide">Pipeline Status</label>
        <div className="flex items-center gap-0">
          {PIPELINE_STEPS.map((step, idx) => {
            const isActive = pipeline === step.id;
            const stepIdx = PIPELINE_STEPS.findIndex(s => s.id === pipeline);
            const isPast  = idx < stepIdx;
            return (
              <button
                key={step.id}
                onClick={() => setPipelineStep(step.id)}
                className={`flex-1 py-2 text-xs font-medium transition-all relative group
                  ${idx === 0 ? 'rounded-l' : ''} ${idx === PIPELINE_STEPS.length - 1 ? 'rounded-r' : ''}
                  ${isActive ? `${step.color} text-white` : isPast ? 'bg-green-800/40 text-green-400' : 'bg-mc-bg text-mc-muted hover:bg-mc-border'}
                  border border-mc-border`}
              >
                {idx > 0 && <span className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 text-mc-border text-xs">›</span>}
                {step.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Created */}
      <div className="text-xs text-mc-muted pt-2 border-t border-mc-border flex items-center justify-between">
        <span>Created: {task.created ? new Date(task.created).toLocaleString() : 'Unknown'}</span>
        {saving && <span className="text-mc-accent animate-pulse">Saving…</span>}
      </div>
    </div>
  );
}

// ─── Tab: Team ────────────────────────────────────────────────────────────────

function TeamTab({ task, onAnalyze }: { task: Task; onAnalyze: () => void }) {
  const members = task.teamComposition || task.analysisResult?.team || [];

  if (!members.length) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
        <div className="text-4xl">🤖</div>
        <div className="text-mc-muted text-sm max-w-xs">Run "Analyze Task" to get AI-powered team recommendations for this task.</div>
        <button
          onClick={onAnalyze}
          className="px-4 py-2 bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 text-sm font-medium"
        >
          🔍 Analyze Task
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3 pb-4">
      <p className="text-xs text-mc-muted">AI-assembled team for this task</p>
      {members.map((m, i) => (
        <div key={i} className="flex gap-3 p-3 bg-mc-bg border border-mc-border rounded-lg">
          <AgentAvatar agentId={m.agentId} size={9} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm">{m.agentId}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-mc-accent/20 text-mc-accent border border-mc-accent/30">{m.role}</span>
              {m.model && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-gray-500/20 text-gray-400 border border-gray-500/30 font-mono">
                  {m.model.split('/').pop()}
                </span>
              )}
            </div>
            {m.rationale && <p className="text-xs text-mc-muted mt-1">{m.rationale}</p>}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Tab: Play ────────────────────────────────────────────────────────────────

function PlayTab({ task, onPlay, onMarkComplete }: {
  task: Task;
  onPlay: () => void;
  onMarkComplete: () => void;
}) {
  const [log, setLog] = useState<LogEntry[]>(task.executionLog || []);
  const [status, setStatus] = useState<Task['executionStatus']>(task.executionStatus || 'idle');
  const logEndRef = useRef<HTMLDivElement>(null);

  // Poll for log updates while running
  useEffect(() => {
    if (status !== 'running') return;
    const interval = setInterval(async () => {
      try {
        const r = await fetch(`/api/tasks/${task.id}/log`);
        const d = await r.json();
        if (d.log) setLog(d.log);
        if (d.executionStatus && d.executionStatus !== 'running') {
          setStatus(d.executionStatus);
          clearInterval(interval);
        }
      } catch {}
    }, 2000);
    return () => clearInterval(interval);
  }, [task.id, status]);

  // Auto-scroll log
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [log]);

  const handlePlay = async () => {
    setStatus('running');
    setLog([]);
    onPlay();
  };

  return (
    <div className="flex flex-col gap-4 pb-4 h-full">
      {/* Status + Play Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {status === 'running' && (
            <span className="flex items-center gap-2 text-blue-400 text-sm">
              <span className="animate-spin">⟳</span> Running…
            </span>
          )}
          {status === 'complete' && <span className="text-green-400 text-sm">✅ Complete</span>}
          {status === 'failed'   && <span className="text-red-400 text-sm">❌ Failed</span>}
          {status === 'idle'     && <span className="text-mc-muted text-sm">Ready to run</span>}
        </div>
        <button
          onClick={handlePlay}
          disabled={status === 'running'}
          className="px-5 py-2.5 text-sm font-bold rounded-lg bg-green-600 text-white hover:bg-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {status === 'running' ? '⟳ Running…' : '▶ Play Task'}
        </button>
      </div>

      {/* Complete Banner */}
      {status === 'complete' && (
        <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
          <span className="text-green-400 font-semibold text-sm">✅ Task Complete!</span>
          <button
            onClick={onMarkComplete}
            className="px-3 py-1.5 text-xs bg-green-600/30 text-green-400 rounded hover:bg-green-600/50"
          >
            📋 Add to Features List
          </button>
        </div>
      )}

      {/* Execution Log */}
      <div className="flex-1 bg-mc-bg border border-mc-border rounded-lg overflow-y-auto p-3 font-mono text-xs space-y-1 max-h-96">
        {log.length === 0 && (
          <div className="text-mc-muted text-center py-8">No log entries yet. Click Play Task to start.</div>
        )}
        {log.map((entry, i) => (
          <div key={i} className="flex gap-2 items-start">
            <span className="text-mc-muted flex-shrink-0">{fmtTime(entry.ts)}</span>
            <span className="text-mc-muted/60 flex-shrink-0 w-16 truncate">[{entry.agent}]</span>
            <span className={LOG_COLORS[entry.type] || 'text-mc-text'}>{entry.message}</span>
          </div>
        ))}
        <div ref={logEndRef} />
      </div>

      {status === 'running' && (
        <div className="flex items-center gap-2 text-xs text-blue-400">
          <span className="animate-pulse">●</span> Live — polling every 2s
        </div>
      )}
    </div>
  );
}

// ─── Tab: Chat ────────────────────────────────────────────────────────────────

function ChatTab({ task }: { task: Task }) {
  const [messages, setMessages] = useState<ChatMessage[]>(task.teamChat || []);
  const [input, setInput]       = useState('');
  const [sending, setSending]   = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async () => {
    const content = input.trim();
    if (!content || sending) return;
    setSending(true);
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      agentId: 'kevin',
      role: 'user',
      content,
      ts: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    try {
      // Save user message
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add-chat-message', taskId: task.id, message: content, role: 'user', agentId: 'kevin' }),
      });

      // Get agent response
      const r = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get-chat-response', taskId: task.id, message: content }),
      });
      const d = await r.json();
      if (d.agentId && d.content) {
        const agentMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          agentId: d.agentId,
          role: 'agent',
          content: d.content,
          ts: new Date().toISOString(),
        };
        setMessages(prev => [...prev, agentMsg]);
      }
    } catch {}
    setSending(false);
  };

  return (
    <div className="flex flex-col h-full gap-3 pb-4" style={{ minHeight: '400px' }}>
      {/* History */}
      <div className="flex-1 overflow-y-auto space-y-3 max-h-96 pr-1">
        {messages.length === 0 && (
          <div className="text-center text-mc-muted text-sm py-12">
            <div className="text-3xl mb-2">💬</div>
            Start the team conversation. Agents will reply in character.
          </div>
        )}
        {messages.map(msg => (
          <div key={msg.id} className={`flex gap-2.5 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <AgentAvatar agentId={msg.agentId} size={7} />
            <div className={`max-w-[75%] ${msg.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-0.5`}>
              <div className="flex items-center gap-2">
                {msg.role !== 'user' && <span className="text-xs font-medium text-mc-text">{msg.agentId}</span>}
                <span className="text-[10px] text-mc-muted">{fmtTime(msg.ts)}</span>
              </div>
              <div className={`px-3 py-2 rounded-xl text-sm ${
                msg.role === 'user'
                  ? 'bg-mc-accent/20 text-mc-text rounded-tr-none'
                  : 'bg-mc-bg border border-mc-border text-mc-text rounded-tl-none'
              }`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex gap-2 border-t border-mc-border pt-3">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="Message the team…"
          disabled={sending}
          className="flex-1 px-3 py-2 bg-mc-bg border border-mc-border rounded text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent disabled:opacity-50"
        />
        <button
          onClick={send}
          disabled={sending || !input.trim()}
          className="px-4 py-2 bg-mc-accent text-white rounded text-sm hover:opacity-90 disabled:opacity-50"
        >
          {sending ? '…' : '➤'}
        </button>
      </div>
    </div>
  );
}

// ─── Tab: Analysis ────────────────────────────────────────────────────────────

function AnalysisTab({ task, onReAnalyze, onAddToProject, onConvertToNew }: { 
  task: Task; 
  onReAnalyze: () => void;
  onAddToProject?: (projectId: string) => void;
  onConvertToNew?: () => void;
}) {
  const r = task.analysisResult;

  if (!r) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
        <div className="text-4xl">🔍</div>
        <div className="text-mc-muted text-sm max-w-xs">No analysis yet. Run "Analyze Task" to get viability, team, and gameplan.</div>
        <button onClick={onReAnalyze} className="px-4 py-2 bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 text-sm font-medium">
          🔍 Analyze Task
        </button>
      </div>
    );
  }

  const viabilityCfg = VIABILITY_CONFIG[r.viability]   || VIABILITY_CONFIG.still_needed;
  const complexityCfg = COMPLEXITY_CONFIG[r.complexity] || COMPLEXITY_CONFIG.moderate;

  return (
    <div className="space-y-4 pb-4">
      {/* Re-Analyze */}
      <div className="flex items-center justify-between">
        <div className="text-xs text-mc-muted">
          Analyzed: {r.analyzedAt ? new Date(r.analyzedAt).toLocaleString() : 'Unknown'}
        </div>
        <button onClick={onReAnalyze} className="px-3 py-1.5 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30">
          🔄 Re-Analyze
        </button>
      </div>

      {/* Badges */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${viabilityCfg.color}`}>
          {viabilityCfg.label}
        </span>
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${complexityCfg.color}`}>
          {complexityCfg.label}
        </span>
        {r.estimatedCost && (
          <span className="text-xs px-2.5 py-1 rounded-full bg-mc-bg border border-mc-border text-mc-muted">
            💰 {r.estimatedCost}
          </span>
        )}
      </div>

      {/* Already Implemented */}
      {r.viability === 'already_implemented' && r.existingFeatureMatch && (
        <div className="p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
          <p className="text-xs text-orange-400 font-medium">✅ Already Implemented</p>
          <p className="text-sm text-mc-text mt-1">{r.existingFeatureMatch}</p>
        </div>
      )}

      {/* Too Complex warning */}
      {r.viability === 'too_complex' && r.suggestedProjectTitles && r.suggestedProjectTitles.length > 0 && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
          <p className="text-xs text-red-400 font-medium">⚠️ Too Complex for a single task. Consider adding to:</p>
          <ul className="mt-1 space-y-0.5">
            {r.suggestedProjectTitles.map((t, i) => (
              <li key={i} className="text-sm text-mc-text">• {t}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Gameplan */}
      {r.gameplan && (
        <div>
          <label className="text-xs text-mc-muted mb-1 block font-medium uppercase tracking-wide">Game Plan</label>
          <div className="bg-mc-bg border border-mc-border rounded-lg p-3 text-sm text-mc-text font-mono whitespace-pre-wrap leading-relaxed">
            {r.gameplan}
          </div>
        </div>
      )}

      {/* Team Summary */}
      {r.team && r.team.length > 0 && (
        <div>
          <label className="text-xs text-mc-muted mb-2 block font-medium uppercase tracking-wide">Recommended Team</label>
          <div className="space-y-2">
            {r.team.map((m, i) => (
              <div key={i} className="flex items-center gap-2 text-sm">
                <AgentAvatar agentId={m.agentId} size={6} />
                <span className="font-medium">{m.agentId}</span>
                <span className="text-xs text-mc-muted">— {m.role}</span>
                {m.model && <span className="text-[10px] text-gray-500 font-mono ml-auto">{m.model.split('/').pop()}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Reasoning */}
      {r.reasoning && (
        <div>
          <label className="text-xs text-mc-muted mb-1 block font-medium uppercase tracking-wide">Reasoning</label>
          <p className="text-sm text-mc-muted leading-relaxed">{r.reasoning}</p>
        </div>
      )}
    </div>
  );
}

// ─── Main Panel ───────────────────────────────────────────────────────────────

type TabId = 'overview' | 'team' | 'play' | 'chat' | 'analysis';

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: 'overview',  label: 'Overview',  icon: '📋' },
  { id: 'team',      label: 'Team',      icon: '👥' },
  { id: 'play',      label: 'Play',      icon: '▶' },
  { id: 'chat',      label: 'Chat',      icon: '💬' },
  { id: 'analysis',  label: 'Analysis',  icon: '🔍' },
];

export default function TaskDetailPanel({
  task,
  onSave,
  onDelete,
  onClose,
  initialTab,
}: {
  task: Task;
  onSave: (id: string, updates: Partial<Task>) => void;
  onDelete?: (id: string) => void;
  onClose: () => void;
  initialTab?: TabId;
}) {
  const [activeTab, setActiveTab]   = useState<TabId>(initialTab || 'overview');
  const [localTask, setLocalTask]   = useState<Task>(task);
  const [analyzing, setAnalyzing]   = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isVisible, setIsVisible]   = useState(false);

  // Sync if task prop changes
  useEffect(() => { setLocalTask(task); }, [task]);

  // Animate in
  useEffect(() => {
    const t = setTimeout(() => setIsVisible(true), 10);
    return () => clearTimeout(t);
  }, []);

  // ESC key to close
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') handleClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };

  const handleSave = async (id: string, updates: Partial<Task>) => {
    setLocalTask(prev => ({ ...prev, ...updates }));
    await onSave(id, updates);
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    setActiveTab('analysis');
    try {
      const r = await fetch('/api/tasks/analyze-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskId: localTask.id,
          title: localTask.title,
          description: localTask.description,
          instructions: localTask.instructions,
        }),
      });
      const d = await r.json();
      if (d.analysisResult || d.viability) {
        const result: AnalysisResult = d.analysisResult || d;
        const updates = { analysisResult: result, teamComposition: result.team };
        setLocalTask(prev => ({ ...prev, ...updates }));
        await onSave(localTask.id, updates);
      }
    } catch (err) {
      console.error('Analyze error:', err);
    }
    setAnalyzing(false);
  };

  const handlePlay = async () => {
    setActiveTab('play');
    try {
      await fetch('/api/tasks/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId: localTask.id }),
      });
      setLocalTask(prev => ({ ...prev, executionStatus: 'running' }));
    } catch {}
  };

  const handleMarkComplete = async () => {
    try {
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark-complete', id: localTask.id }),
      });
      setLocalTask(prev => ({ ...prev, executionStatus: 'complete', column: 'complete' }));
      await onSave(localTask.id, { column: 'complete', executionStatus: 'complete' as any });
    } catch {}
  };

  const handleAddToFeatures = async () => {
    try {
      const response = await fetch('/api/features', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pageId: 'kanban',
          name: localTask.title,
          description: localTask.description || '',
          status: 'live',
          testStatus: 'pending',
        }),
      });
      const data = await response.json();
      if (data.success) {
        // Show success feedback - could add a toast here
        alert('✅ Added to Features List!');
      } else if (response.status === 409) {
        alert('ℹ️ Feature already exists in the list');
      }
    } catch (err) {
      console.error('Failed to add to features:', err);
      alert('❌ Failed to add to features list');
    }
  };

  const [showProjectPicker, setShowProjectPicker] = useState(false);
  const [availableProjects, setAvailableProjects] = useState<{id: string; title: string}[]>([]);

  const handleAddToExistingProject = async (projectId: string) => {
    try {
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action: 'update', 
          id: localTask.id, 
          updates: { notes: `Added to project: ${projectId}`, column: 'complete' } 
        }),
      });
      setLocalTask(prev => ({ ...prev, column: 'complete' }));
      await onSave(localTask.id, { column: 'complete' });
      setShowProjectPicker(false);
      alert('✅ Task added to project!');
    } catch (err) {
      console.error('Failed to add to project:', err);
      alert('❌ Failed to add to project');
    }
  };

  const handleConvertToNewProject = async () => {
    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action: 'create', 
          title: localTask.title, 
          description: localTask.description || '', 
          priority: localTask.priority,
          assignee: localTask.assignee || 'Kevin',
          tags: localTask.tags || [],
        }),
      });
      const data = await response.json();
      if (data.project || data.id) {
        const projectId = data.project?.id || data.id;
        // Mark task as complete
        await fetch('/api/tasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'update', id: localTask.id, updates: { column: 'complete' } }),
        });
        setLocalTask(prev => ({ ...prev, column: 'complete' }));
        await onSave(localTask.id, { column: 'complete' });
        alert(`✅ Created new project and moved task to it!`);
      }
    } catch (err) {
      console.error('Failed to create project:', err);
      alert('❌ Failed to create project');
    }
  };

  return (
    <>
      {/* Dark overlay */}
      <div
        className={`fixed inset-0 z-40 bg-black/50 transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
        onClick={handleClose}
      />

      {/* Slide-over panel */}
      <div
        className={`fixed top-0 right-0 bottom-0 z-50 flex flex-col bg-mc-surface border-l border-mc-border shadow-2xl transition-transform duration-300 ease-out
          ${isVisible ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ width: '60vw', minWidth: '400px', maxWidth: '900px' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-mc-border flex-shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <span className="text-xs text-mc-muted font-mono flex-shrink-0">#{localTask.id.slice(-6)}</span>
            <span className="text-sm font-semibold text-mc-text truncate">{localTask.title}</span>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Quick action buttons */}
            <button
              onClick={handleAnalyze}
              disabled={analyzing}
              title="Analyze Task"
              className="px-2.5 py-1.5 text-xs bg-mc-bg border border-mc-border rounded hover:border-mc-accent/50 text-mc-muted hover:text-mc-accent disabled:opacity-50"
            >
              {analyzing ? '⏳' : '🔍'} {analyzing ? 'Analyzing…' : 'Analyze'}
            </button>
            <button
              onClick={() => { setActiveTab('play'); handlePlay(); }}
              title="Play Task"
              className="px-2.5 py-1.5 text-xs bg-green-600/20 border border-green-600/30 rounded hover:bg-green-600/30 text-green-400"
            >
              ▶ Play
            </button>

            {/* Delete */}
            {onDelete && (
              confirmDelete ? (
                <>
                  <span className="text-xs text-red-400">Delete?</span>
                  <button onClick={() => { onDelete(localTask.id); handleClose(); }} className="px-2 py-1 text-xs bg-red-600 text-white rounded">Yes</button>
                  <button onClick={() => setConfirmDelete(false)} className="px-2 py-1 text-xs border border-mc-border text-mc-muted rounded">No</button>
                </>
              ) : (
                <button onClick={() => setConfirmDelete(true)} title="Delete task" className="text-mc-muted hover:text-red-400 px-1.5 py-1">🗑</button>
              )
            )}

            <button onClick={handleClose} className="text-mc-muted hover:text-mc-text text-xl ml-1 leading-none" title="Close (ESC)">✕</button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-mc-border flex-shrink-0 overflow-x-auto">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 text-sm font-medium flex items-center gap-1.5 whitespace-nowrap transition-colors border-b-2 -mb-px
                ${activeTab === tab.id
                  ? 'border-mc-accent text-mc-accent bg-mc-accent/5'
                  : 'border-transparent text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                }`}
            >
              <span className="text-base leading-none">{tab.icon}</span>
              {tab.label}
              {/* Badges */}
              {tab.id === 'analysis' && localTask.analysisResult && (
                <span className="ml-1 w-1.5 h-1.5 rounded-full bg-green-400 flex-shrink-0" />
              )}
              {tab.id === 'play' && localTask.executionStatus === 'running' && (
                <span className="ml-1 w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse flex-shrink-0" />
              )}
              {tab.id === 'chat' && (localTask.teamChat?.length || 0) > 0 && (
                <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-mc-accent/20 text-mc-accent">
                  {localTask.teamChat!.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {activeTab === 'overview' && (
            <OverviewTab task={localTask} onSave={handleSave} />
          )}
          {activeTab === 'team' && (
            <TeamTab task={localTask} onAnalyze={() => { handleAnalyze(); }} />
          )}
          {activeTab === 'play' && (
            <PlayTab task={localTask} onPlay={handlePlay} onMarkComplete={handleAddToFeatures} />
          )}
          {activeTab === 'chat' && (
            <ChatTab task={localTask} />
          )}
          {activeTab === 'analysis' && (
            <AnalysisTab task={localTask} onReAnalyze={handleAnalyze} />
          )}
        </div>
      </div>
    </>
  );
}
