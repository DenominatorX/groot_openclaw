'use client';

import { useState, useEffect, useRef } from 'react';

interface ActivityEvent {
  id: string;
  agent: string;
  status: string;
  model?: string;
  timestamp: string;
  message?: string;
}

interface LiveActivityFeedProps {
  projectId?: string; // Optional: filter by project
}

export default function LiveActivityFeed({ projectId }: LiveActivityFeedProps) {
  const [events, setEvents] = useState<ActivityEvent[]>([]);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);

  const connect = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    const url = projectId 
      ? `/api/activity/stream?projectId=${encodeURIComponent(projectId)}`
      : '/api/activity/stream';

    const eventSource = new EventSource(url);
    eventSourceRef.current = eventSource;

    eventSource.onopen = () => {
      setConnected(true);
      setError(null);
      reconnectAttempts.current = 0;
    };

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setEvents(prev => {
          const newEvents = [
            {
              id: data.id || `event-${Date.now()}`,
              agent: data.agent || data.label || 'Unknown',
              status: data.status || 'active',
              model: data.model,
              timestamp: data.timestamp || new Date().toISOString(),
              message: data.message,
            },
            ...prev,
          ].slice(0, 10);
          return newEvents;
        });
      } catch (e) {
        console.error('Failed to parse activity event:', e);
      }
    };

    eventSource.onerror = () => {
      setConnected(false);
      eventSource.close();
      
      // Auto-reconnect with exponential backoff
      if (reconnectAttempts.current < 5) {
        const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
        reconnectTimeoutRef.current = setTimeout(() => {
          reconnectAttempts.current++;
          connect();
        }, delay);
      } else {
        setError('Connection lost. Please refresh.');
      }
    };
  };

  useEffect(() => {
    connect();

    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [projectId]);

  const formatTime = (timestamp: string) => {
    try {
      const date = new Date(timestamp);
      const now = new Date();
      
      // Sanity check: if timestamp is in the future, it's a bug
      if (date.getTime() > now.getTime() + 60000) {
        console.warn('[LiveActivityFeed] Future timestamp detected:', timestamp);
        return '⚠️';
      }
      
      return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return '--:--';
    }
  };

  const getStatusColor = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('run') || s.includes('active')) return 'bg-green-500/20 text-green-400';
    if (s.includes('pause') || s.includes('wait')) return 'bg-yellow-500/20 text-yellow-400';
    if (s.includes('error') || s.includes('fail')) return 'bg-red-500/20 text-red-400';
    return 'bg-gray-500/20 text-gray-400';
  };

  const getStatusIcon = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('run') || s.includes('active')) return '🟢';
    if (s.includes('pause') || s.includes('wait')) return '⏸️';
    if (s.includes('error') || s.includes('fail')) return '❌';
    return '⭕';
  };

  return (
    <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
      {/* Header */}
      <div className="px-3 py-2 border-b border-mc-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm">📡</span>
          <span className="text-xs font-semibold text-mc-text">Live Activity</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
          <span className="text-[10px] text-mc-muted">
            {connected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
      </div>

      {error && (
        <div className="px-3 py-2 bg-red-500/10 text-red-400 text-[10px]">
          {error}
        </div>
      )}

      {/* Events List */}
      <div className="max-h-64 overflow-y-auto">
        {events.length === 0 ? (
          <div className="px-3 py-6 text-center text-xs text-mc-muted">
            {connected ? 'Waiting for activity...' : 'Connecting...'}
          </div>
        ) : (
          <div className="divide-y divide-mc-border/30">
            {events.map((event) => (
              <div key={event.id} className="px-3 py-2 hover:bg-mc-bg/30 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="text-[10px]">{getStatusIcon(event.status)}</span>
                  <span className="text-[10px] font-medium text-mc-accent">{event.agent}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded ${getStatusColor(event.status)}`}>
                    {event.status}
                  </span>
                  {event.model && (
                    <span className="text-[9px] text-mc-muted ml-auto">{event.model}</span>
                  )}
                  <span className="text-[9px] text-mc-muted flex-shrink-0">
                    {formatTime(event.timestamp)}
                  </span>
                </div>
                {event.message && (
                  <div className="text-[10px] text-mc-muted mt-0.5 truncate ml-4">
                    {event.message}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
