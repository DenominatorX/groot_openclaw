/* @ts-nocheck */
'use client';
import React, { useState, useEffect } from 'react';

interface TeamRole {
  id: string; title: string; tier: string;
  responsibilities: string[]; rules: string[];
  expectedDocuments: string[]; autoMatchCriteria?: any;
}
interface TeamTemplate {
  id: string; name: string; description: string;
  category: string; isDefault: boolean; roles: TeamRole[];
}
interface Assignment {
  roleId: string; roleTitle: string; tier: string;
  responsibilities: string[]; rules: string[];
  expectedDocuments: string[]; agentId: string | null; score?: number;
  modelOverride: string | null;
}

interface Props {
  projectId: string;
  onApply: (team: any[]) => void;
  onClose: () => void;
  agentMap?: Record<string, any>;
  allAgents?: any[];
}

const AVAILABLE_MODELS = [
  // ── Escalation only ──────────────────────────────
  'anthropic/claude-sonnet-4-6',
  'anthropic/claude-opus-4-6',
  // ── PM / Architect / Analyst (free, 2M ctx) ──────
  'openrouter/x-ai/grok-4.1-fast',
  'x-ai/grok-4',
  'x-ai/grok-3',
  // ── Dev (backend / frontend / full-stack) ────────
  'openrouter/minimax/minimax-m2.5',
  // ── QA / Docs / Research ─────────────────────────
  'openrouter/google/gemini-2.5-flash',
  'openrouter/google/gemini-2.5-pro',
  'openrouter/google/gemini-3-pro-preview',
  // ── Memory / Archivist + Cron / Utility ──────────
  'anthropic/claude-haiku-3-5',
  // ── Local / fallback ─────────────────────────────
  'lmstudio/gemma-3-12b',
];

const TIER_COLORS: Record<string, string> = {
  executive: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  senior: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  mid: 'bg-green-500/20 text-green-400 border-green-500/30',
  junior: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
};

const CAT_ICONS: Record<string, string> = {
  development: '💻', research: '📊', health: '🏥', legal: '⚖️', marketing: '🎯',
};

export default function TeamBuilder({ projectId, onApply, onClose, agentMap = {}, allAgents = [] }: Props) {
  const [templates, setTemplates] = useState<TeamTemplate[]>([]);
  const [selected, setSelected] = useState<TeamTemplate | null>(null);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [autoAssigning, setAutoAssigning] = useState(false);
  const [expandedRole, setExpandedRole] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveTemplateName, setSaveTemplateName] = useState('');
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [view, setView] = useState<'templates' | 'configure'>('templates');

  useEffect(() => {
    fetch('/api/teams').then(r => r.json())
      .then(d => { setTemplates(d.teams || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const selectTemplate = (t: TeamTemplate) => {
    setSelected(t);
    setAssignments((t.roles || []).map(r => ({
      roleId: r.id, roleTitle: r.title, tier: r.tier,
      responsibilities: r.responsibilities, rules: r.rules,
      expectedDocuments: r.expectedDocuments, agentId: null,
      modelOverride: null,
    })));
    setView('configure');
  };

  const autoAssign = async () => {
    if (!selected) return;
    setAutoAssigning(true);
    try {
      const r = await fetch('/api/teams/auto-assign', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teamId: selected.id }),
      });
      const d = await r.json();
      if (d.assignments) setAssignments(d.assignments);
    } catch {}
    setAutoAssigning(false);
  };

  const swapAgent = (roleId: string, agentId: string | null) => {
    setAssignments(prev => prev.map(a => a.roleId === roleId ? { ...a, agentId } : a));
  };

  const setModelOverride = (roleId: string, model: string | null) => {
    setAssignments(prev => prev.map(a => a.roleId === roleId ? { ...a, modelOverride: model } : a));
  };

  const applyTeam = async () => {
    setSaving(true);
    const team = assignments.map(a => ({
      agentId: a.agentId,
      roleId: a.roleId,
      roleTitle: a.roleTitle,
      rules: a.rules,
      expectedDocuments: a.expectedDocuments,
      modelOverride: a.modelOverride,
      pmAssign: !a.agentId, // Flag for PM to auto-fill
    }));
    onApply(team);
    setSaving(false);
  };

  const saveAsTemplate = async () => {
    if (!saveTemplateName.trim() || !selected) return;
    setSaving(true);
    try {
      await fetch('/api/teams', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: `custom-${Date.now()}`,
          name: saveTemplateName,
          description: `Custom team based on ${selected.name}`,
          category: selected.category,
          roles: selected.roles,
        }),
      });
      // Refresh templates
      const r = await fetch('/api/teams');
      const d = await r.json();
      setTemplates(d.teams || []);
      setShowSaveDialog(false);
      setSaveTemplateName('');
    } catch {}
    setSaving(false);
  };

  const deleteTemplate = async (id: string) => {
    await fetch('/api/teams', {
      method: 'DELETE', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    setTemplates(prev => prev.filter(t => t.id !== id));
  };

  const assignedIds = new Set(assignments.map(a => a.agentId).filter(Boolean));

  if (loading) return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center">
      <div className="bg-[#12121a] border border-[#1a1a2e] rounded-xl p-8 text-mc-muted">Loading team templates...</div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-4xl max-h-[90vh] bg-[#12121a] border border-[#1a1a2e] rounded-xl flex flex-col overflow-hidden"
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#1a1a2e] flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            {view === 'configure' && (
              <button onClick={() => setView('templates')} className="text-mc-muted hover:text-mc-text text-sm">← Back</button>
            )}
            <h2 className="text-lg font-bold text-mc-text">
              {view === 'templates' ? '🏗️ Team Builder' : `Configure: ${selected?.name}`}
            </h2>
          </div>
          <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {/* TEMPLATE SELECTION VIEW */}
          {view === 'templates' && (
            <div className="space-y-4">
              <p className="text-sm text-mc-muted">Select a team template to get started, then auto-assign agents or configure manually.</p>
              <div className="grid grid-cols-2 gap-3">
                {templates.map(t => (
                  <div key={t.id}
                    className="bg-[#0a0a0f] border border-[#1a1a2e] rounded-lg p-4 cursor-pointer hover:border-indigo-500/50 transition-colors group"
                    onClick={() => selectTemplate(t)}>
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-mc-text group-hover:text-indigo-400 transition-colors">{t.name}</h3>
                        <p className="text-xs text-mc-muted mt-1">{t.description}</p>
                      </div>
                      {!t.isDefault && (
                        <button onClick={e => { e.stopPropagation(); deleteTemplate(t.id); }}
                          className="text-mc-muted hover:text-red-400 text-xs opacity-0 group-hover:opacity-100">✕</button>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-400">{t.roles.length} roles</span>
                      <span className="text-xs text-mc-muted">{t.category}</span>
                      {t.isDefault && <span className="text-[10px] px-1.5 py-0.5 rounded bg-green-500/10 text-green-400">default</span>}
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {t.roles.map(r => (
                        <span key={r.id} className="text-[10px] px-1.5 py-0.5 rounded bg-[#1a1a2e] text-mc-muted">{r.title}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CONFIGURE VIEW */}
          {view === 'configure' && selected && (
            <div className="space-y-4">
              {/* Info bar */}
              {(() => {
                const filled = assignments.filter(a => a.agentId).length;
                const empty = assignments.length - filled;
                const multiRole = Object.entries(
                  assignments.filter(a => a.agentId).reduce((acc, a) => { acc[a.agentId!] = (acc[a.agentId!] || 0) + 1; return acc; }, {} as Record<string, number>)
                ).filter(([, count]) => count > 1);
                return (
                  <div className="flex flex-wrap gap-3 text-[10px] text-mc-muted">
                    <span>✅ {filled}/{assignments.length} roles filled</span>
                    {empty > 0 && <span className="text-yellow-400">⏳ {empty} for PM to assign</span>}
                    {multiRole.length > 0 && <span className="text-blue-400">
                      ★ Multi-role: {multiRole.map(([id, count]) => `${agentMap[id]?.displayName || id} (${count})`).join(', ')}
                    </span>}
                  </div>
                );
              })()}

              {/* Actions bar */}
              <div className="flex gap-2 flex-wrap">
                <button onClick={autoAssign} disabled={autoAssigning}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold disabled:opacity-50 transition-colors">
                  {autoAssigning ? '🔄 Auto-Assigning...' : '🤖 Auto-Generate Team'}
                </button>
                <button onClick={() => setShowSaveDialog(true)}
                  className="px-4 py-2 bg-[#1a1a2e] hover:bg-[#252540] text-mc-text rounded-lg text-sm transition-colors">
                  💾 Save as Template
                </button>
                <button onClick={applyTeam} disabled={saving}
                  className="px-4 py-2 bg-green-600 hover:bg-green-500 text-white rounded-lg text-sm font-semibold disabled:opacity-50 ml-auto transition-colors">
                  {saving ? 'Applying...' : '✅ Apply Team to Project'}
                </button>
              </div>

              {/* Save dialog */}
              {showSaveDialog && (
                <div className="bg-[#0a0a0f] border border-indigo-500/30 rounded-lg p-3 flex gap-2">
                  <input value={saveTemplateName} onChange={e => setSaveTemplateName(e.target.value)}
                    placeholder="Template name..." className="flex-1 bg-[#12121a] border border-[#1a1a2e] rounded px-3 py-1.5 text-sm text-mc-text" />
                  <button onClick={saveAsTemplate} className="px-3 py-1.5 bg-indigo-600 text-white rounded text-sm">Save</button>
                  <button onClick={() => setShowSaveDialog(false)} className="px-3 py-1.5 text-mc-muted text-sm">Cancel</button>
                </div>
              )}

              {/* Role assignments */}
              <div className="space-y-2">
                {assignments.map(a => {
                  const isExpanded = expandedRole === a.roleId;
                  const agent = a.agentId ? agentMap[a.agentId] : null;
                  return (
                    <div key={a.roleId} className="bg-[#0a0a0f] border border-[#1a1a2e] rounded-lg overflow-hidden">
                      <div className="flex items-center gap-3 p-3 cursor-pointer" onClick={() => setExpandedRole(isExpanded ? null : a.roleId)}>
                        <span className={`text-[10px] px-2 py-0.5 rounded border font-semibold ${TIER_COLORS[a.tier] || TIER_COLORS.mid}`}>
                          {a.tier}
                        </span>
                        <span className="text-sm font-medium text-mc-text flex-1">{a.roleTitle}</span>
                        {/* Agent selector — agents can hold multiple roles */}
                        <select value={a.agentId || ''} onClick={e => e.stopPropagation()}
                          onChange={e => swapAgent(a.roleId, e.target.value || null)}
                          className="bg-[#12121a] border border-[#1a1a2e] rounded px-2 py-1 text-xs text-mc-text min-w-[160px]">
                          <option value="">— PM decides —</option>
                          {allAgents.filter(ag => ag.id !== 'kevin').map(ag => (
                            <option key={ag.id} value={ag.id}>
                              {ag.displayName || ag.name} (T{ag.tier}){assignedIds.has(ag.id) && ag.id !== a.agentId ? ' ★' : ''}
                            </option>
                          ))}
                        </select>
                        {/* Model override selector */}
                        <select value={a.modelOverride || ''} onClick={e => e.stopPropagation()}
                          onChange={e => setModelOverride(a.roleId, e.target.value || null)}
                          className="bg-[#12121a] border border-[#1a1a2e] rounded px-2 py-1 text-xs text-mc-text min-w-[180px]">
                          <option value="">{a.agentId && agentMap[a.agentId]?.model ? `${agentMap[a.agentId].model} (default)` : 'Default model'}</option>
                          {AVAILABLE_MODELS.map(m => (
                            <option key={m} value={m}>{m}</option>
                          ))}
                        </select>
                        {agent && (
                          <span className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0"
                            style={{ background: agent.color || '#666' }}>
                            {(agent.initials || '?').slice(0, 2)}
                          </span>
                        )}
                        {a.score !== undefined && a.score > 0 && (
                          <span className="text-[10px] text-mc-muted">score: {a.score}</span>
                        )}
                        <span className="text-mc-muted text-xs">{isExpanded ? '▼' : '▶'}</span>
                      </div>
                      {isExpanded && (
                        <div className="px-3 pb-3 border-t border-[#1a1a2e]/50 space-y-3">
                          <div className="mt-2">
                            <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider mb-1">Responsibilities</h4>
                            <div className="flex flex-wrap gap-1">
                              {a.responsibilities.map((r, i) => (
                                <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-[#1a1a2e] text-mc-muted">{r}</span>
                              ))}
                            </div>
                          </div>
                          <div>
                            <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider mb-1">Rules</h4>
                            <ul className="space-y-0.5">
                              {a.rules.map((r, i) => (
                                <li key={i} className="text-xs text-mc-text flex items-start gap-1.5">
                                  <span className="text-indigo-400 mt-0.5 flex-shrink-0">•</span>{r}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider mb-1">Expected Documents</h4>
                            <div className="flex flex-wrap gap-1">
                              {a.expectedDocuments.map((d, i) => (
                                <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400">📄 {d}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
