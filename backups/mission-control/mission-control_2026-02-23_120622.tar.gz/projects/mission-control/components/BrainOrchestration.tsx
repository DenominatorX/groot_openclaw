'use client';
import { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Brain, Users, MessageSquare, CheckCircle, 
  Send, Play, Pause, Plus, X, RefreshCw,
  ChevronDown, ChevronRight, AlertCircle, Check,
  ArrowUpDown, Search, FileText, Loader2,
  Cpu, Minimize2, Zap
} from 'lucide-react';
import AgentProfile from './AgentProfile';
import TodaysMemory from './Brain/TodaysMemory';
import DailyBriefing from './Brain/DailyBriefing';

// Types
interface Agent {
  id: string;
  name: string;
  title: string;
  status: string;
  department: string;
  tier: number;
  capabilities?: string[];
  color?: string;
  displayName?: string;
  emoji?: string;
}

interface Meeting {
  id: string;
  topic: string;
  agents: { id: string; name: string }[];
  actionItems: string[];
  createdAt: string;
  classification: string;
  accessGranted?: boolean;
}

interface Delegation {
  id: string;
  topic: string;
  targetAgent: { id: string; name: string; title: string };
  status: string;
  requiresApproval: boolean;
  createdAt: string;
  result?: string;
}

interface ConsensusSession {
  id: string;
  topic: string;
  agents: string[];
  status: string;
  votes: { agentId: string; agentName: string; position: string; reasoning: string }[];
  result?: {
    consensus: string;
    confidence: number;
    agreeCount: number;
    disagreeCount: number;
  };
}

interface AgentSessionInfo {
  sessionKey: string;
  totalTokens: number;
  contextTokens: number;
  pct: number;
  status: 'green' | 'yellow' | 'red';
  model: string;
  updatedAt: number | null;
}

type SortField = 'name' | 'status' | 'tier' | 'department';
type SortDir = 'asc' | 'desc';

export default function BrainOrchestration() {
  const [activeTab, setActiveTab] = useState<'monitor' | 'meetings' | 'delegate' | 'consensus'>('monitor');
  const [agents, setAgents] = useState<Agent[]>([]);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [delegations, setDelegations] = useState<Delegation[]>([]);
  const [consensusSessions, setConsensusSessions] = useState<ConsensusSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Agent management state
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>('status');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Form states
  const [newMeetingTopic, setNewMeetingTopic] = useState('');
  const [selectedMeetingAgents, setSelectedMeetingAgents] = useState<string[]>([]);
  const [meetingContext, setMeetingContext] = useState('');
  const [meetingResult, setMeetingResult] = useState<any>(null);
  
  const [delegateTopic, setDelegateTopic] = useState('');
  const [selectedDelegateAgent, setSelectedDelegateAgent] = useState('');
  const [delegateContext, setDelegateContext] = useState('');
  const [delegateResult, setDelegateResult] = useState<any>(null);
  
  const [consensusTopic, setConsensusTopic] = useState('');
  const [selectedConsensusAgents, setSelectedConsensusAgents] = useState<string[]>([]);
  const [consensusContext, setConsensusContext] = useState('');
  const [consensusResult, setConsensusResult] = useState<any>(null);

  // Per-agent session data
  const [agentSessions, setAgentSessions] = useState<Record<string, AgentSessionInfo>>({});
  
  // Compact state
  const [compactingAgent, setCompactingAgent] = useState<string | null>(null);
  const [compactProgress, setCompactProgress] = useState<string | null>(null);
  const [compactResult, setCompactResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [showCompactModal, setShowCompactModal] = useState(false);
  const [confirmCompactAgent, setConfirmCompactAgent] = useState<string | null>(null);

  // Roster state
  const [rosterContent, setRosterContent] = useState('');
  const [rosterOpen, setRosterOpen] = useState(false);
  const [rosterLoading, setRosterLoading] = useState(false);
  const [rosterMsg, setRosterMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Orchestration panel collapsed state
  const [orchestrationOpen, setOrchestrationOpen] = useState(true);

  const fetchAgents = useCallback(async () => {
    try {
      const res = await fetch('/api/brain/agents?all=true');
      const data = await res.json();
      setAgents(data.agents || []);
    } catch (err) {
      console.error('Failed to fetch agents:', err);
    }
  }, []);

  const fetchMeetings = useCallback(async () => {
    try {
      const res = await fetch('/api/brain/meetings');
      const data = await res.json();
      setMeetings(data.meetings || []);
    } catch (err) {
      console.error('Failed to fetch meetings:', err);
    }
  }, []);

  const fetchDelegations = useCallback(async () => {
    try {
      const res = await fetch('/api/brain/delegation');
      const data = await res.json();
      setDelegations(data.delegations || []);
    } catch (err) {
      console.error('Failed to fetch delegations:', err);
    }
  }, []);

  const fetchConsensus = useCallback(async () => {
    try {
      const res = await fetch('/api/brain/consensus');
      const data = await res.json();
      setConsensusSessions(data.sessions || []);
    } catch (err) {
      console.error('Failed to fetch consensus:', err);
    }
  }, []);

  const fetchContextHealth = useCallback(async () => {
    try {
      const res = await fetch('/api/context-health');
      const data = await res.json();
      if (data.agentSessions) {
        setAgentSessions(data.agentSessions);
      }
    } catch (err) {
      console.error('Failed to fetch context health:', err);
    }
  }, []);

  const fetchRoster = useCallback(async () => {
    try {
      const res = await fetch('/api/agents/roster');
      const data = await res.json();
      setRosterContent(data.roster || '');
    } catch (err) {
      console.error('Failed to fetch roster:', err);
    }
  }, []);

  const handleRecompileRoster = async () => {
    setRosterLoading(true);
    setRosterMsg(null);
    try {
      const res = await fetch('/api/agents/roster', { method: 'POST' });
      const data = await res.json();
      if (data.error) {
        setRosterMsg({ type: 'error', text: data.error });
      } else {
        setRosterContent(data.roster || '');
        setRosterMsg({ type: 'success', text: `Roster recompiled — ${data.agentCount} agents` });
      }
    } catch (err: any) {
      setRosterMsg({ type: 'error', text: err.message });
    } finally {
      setRosterLoading(false);
    }
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await Promise.all([fetchAgents(), fetchMeetings(), fetchDelegations(), fetchConsensus(), fetchRoster(), fetchContextHealth()]);
      setLoading(false);
    };
    load();
  }, [fetchAgents, fetchMeetings, fetchDelegations, fetchConsensus, fetchRoster, fetchContextHealth]);

  // Sorted & filtered agents
  const sortedAgents = useMemo(() => {
    let filtered = agents.filter(a => {
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return a.name.toLowerCase().includes(q) || 
             (a.displayName || '').toLowerCase().includes(q) ||
             (a.title || '').toLowerCase().includes(q) ||
             (a.department || '').toLowerCase().includes(q);
    });

    filtered.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name':
          cmp = (a.displayName || a.name).localeCompare(b.displayName || b.name);
          break;
        case 'status': {
          const order: Record<string, number> = { active: 0, idle: 1, offline: 2 };
          cmp = (order[a.status] ?? 9) - (order[b.status] ?? 9);
          break;
        }
        case 'tier':
          cmp = a.tier - b.tier;
          break;
        case 'department':
          cmp = (a.department || 'zzz').localeCompare(b.department || 'zzz');
          break;
      }
      return sortDir === 'desc' ? -cmp : cmp;
    });

    return filtered;
  }, [agents, sortField, sortDir, searchQuery]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const handleCreateMeeting = async () => {
    if (!newMeetingTopic || selectedMeetingAgents.length < 2) {
      setError('Need topic and at least 2 agents');
      return;
    }
    setError('');
    setMeetingResult(null);
    
    try {
      const res = await fetch('/api/brain/orchestrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'meeting',
          topic: newMeetingTopic,
          agents: selectedMeetingAgents,
          context: meetingContext,
        }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setMeetingResult(data);
        fetchMeetings();
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDelegate = async () => {
    if (!delegateTopic) {
      setError('Need a topic');
      return;
    }
    setError('');
    setDelegateResult(null);
    
    try {
      const res = await fetch('/api/brain/delegation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'delegate',
          topic: delegateTopic,
          agentIds: selectedDelegateAgent ? [selectedDelegateAgent] : [],
          context: delegateContext,
        }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setDelegateResult(data);
        fetchDelegations();
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleStartConsensus = async () => {
    if (!consensusTopic || selectedConsensusAgents.length < 2) {
      setError('Need topic and at least 2 agents');
      return;
    }
    setError('');
    setConsensusResult(null);
    
    try {
      const res = await fetch('/api/brain/orchestrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'consensus',
          topic: consensusTopic,
          agents: selectedConsensusAgents,
          context: consensusContext,
        }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setConsensusResult(data);
        fetchConsensus();
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const toggleAgentSelection = (agentId: string, setFn: React.Dispatch<React.SetStateAction<string[]>>) => {
    setFn(prev => 
      prev.includes(agentId) 
        ? prev.filter(id => id !== agentId)
        : [...prev, agentId]
    );
  };

  const handleCompactAgent = async (agentId: string) => {
    setConfirmCompactAgent(null);
    setCompactingAgent(agentId);
    setCompactResult(null);
    setShowCompactModal(true);
    setCompactProgress('📝 Generating session summary...');

    try {
      const sessionInfo = agentSessions[agentId];
      const body: any = { action: 'compact' };
      if (sessionInfo?.sessionKey) {
        body.sessionKey = sessionInfo.sessionKey;
      } else {
        body.agentId = agentId;
      }

      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const result = await response.json();

      if (result.ok) {
        setCompactProgress('💾 Flushing memories to disk...');
        await new Promise(r => setTimeout(r, 1500));
        setCompactProgress('🔄 Resetting session...');
        await new Promise(r => setTimeout(r, 2000));
        setCompactProgress('🔃 Loading fresh session...');
        await new Promise(r => setTimeout(r, 1000));

        await fetchContextHealth();

        setCompactResult({ ok: true, msg: '✅ Session compacted & reset! 🚀' });
        setCompactProgress(null);
      } else {
        setCompactResult({ ok: false, msg: result.error || 'Compact failed' });
        setCompactProgress(null);
      }
    } catch (err: any) {
      setCompactResult({ ok: false, msg: err.message });
      setCompactProgress(null);
    }

    setCompactingAgent(null);
    setTimeout(() => {
      setCompactResult(null);
      setShowCompactModal(false);
    }, 3000);
  };

  const formatTokens = (tokens: number) => {
    if (tokens >= 1000000) return `${(tokens / 1000000).toFixed(1)}M`;
    if (tokens >= 1000) return `${(tokens / 1000).toFixed(1)}K`;
    return `${tokens}`;
  };

  const getContextColor = (pct: number) => {
    if (pct >= 85) return 'text-red-400';
    if (pct >= 60) return 'text-yellow-400';
    return 'text-mc-muted';
  };

  const getContextBarColor = (pct: number) => {
    if (pct >= 85) return 'bg-red-500';
    if (pct >= 60) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const shortenModel = (model: string | null | undefined) => {
    if (!model || model === 'unknown') return null;
    const parts = model.split('/');
    const name = parts[parts.length - 1];
    return name
      .replace('claude-', '')
      .replace('minimax-', 'minimax-')
      .replace('llama3.1:', 'llama-')
      .replace('gemma-3-', 'gemma-');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'idle': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-400';
    }
  };

  const getStatusRing = (status: string) => {
    switch (status) {
      case 'active': return 'ring-green-500/30';
      case 'idle': return 'ring-yellow-500/30';
      default: return 'ring-gray-500/20';
    }
  };

  const getTierLabel = (tier: number) => {
    const labels: Record<number, string> = { 0: 'Owner', 1: 'Executive', 2: 'VP', 3: 'Director', 4: 'Sr. Manager', 5: 'Manager', 6: 'Frontline' };
    return labels[tier] || `Tier ${tier}`;
  };

  const getTierColor = (tier: number) => {
    if (tier <= 0) return 'bg-yellow-900/50 text-yellow-400';
    if (tier <= 1) return 'bg-purple-900/50 text-purple-400';
    if (tier <= 2) return 'bg-blue-900/50 text-blue-400';
    if (tier <= 4) return 'bg-green-900/50 text-green-400';
    return 'bg-gray-900/50 text-gray-400';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-6 h-6 animate-spin text-mc-accent" />
        <span className="ml-2 text-mc-muted">Loading Brain Orchestration...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Agent Profile Modal */}
      {selectedAgentId && (
        <AgentProfile
          agentId={selectedAgentId}
          onClose={() => setSelectedAgentId(null)}
          onSelectAgent={(id) => setSelectedAgentId(id)}
        />
      )}

      {/* Error Banner */}
      {error && (
        <div className="bg-red-900/30 border border-red-600 text-red-400 px-4 py-2 rounded flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          {error}
          <button onClick={() => setError('')} className="ml-auto hover:text-red-300">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Daily Briefing & Today's Memory - 50/50 Split */}
      <div className="flex flex-col md:flex-row h-[520px] gap-4">
        {/* Left: Today's Memory */}
        <div className="flex-1 min-h-[260px]">
          <TodaysMemory />
        </div>
        {/* Right: Daily Briefing */}
        <div className="flex-1 min-h-[260px]">
          <DailyBriefing />
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════
          ORCHESTRATION PANEL (collapsible)
          Agent Monitor | Meetings | Delegate | Consensus
          ═══════════════════════════════════════════════════ */}
      <div className="bg-mc-surface border border-mc-border rounded-xl overflow-hidden">
        {/* Collapsible header */}
        <button
          onClick={() => setOrchestrationOpen(o => !o)}
          className="w-full flex items-center justify-between px-4 py-3 hover:bg-mc-bg/40 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-mc-accent" />
            <span className="font-semibold text-sm text-mc-text">Orchestration</span>
            <span className="text-[10px] text-mc-muted bg-mc-bg/60 px-2 py-0.5 rounded border border-mc-border/50">
              {agents.length} agents · {meetings.length} meetings · {delegations.length} delegations
            </span>
          </div>
          {orchestrationOpen
            ? <ChevronDown className="w-4 h-4 text-mc-muted" />
            : <ChevronRight className="w-4 h-4 text-mc-muted" />
          }
        </button>

        {orchestrationOpen && (
          <div className="border-t border-mc-border p-4 space-y-4">
            {/* Tab Navigation */}
            <div className="flex gap-2 border-b border-mc-border pb-2">
              <button
                onClick={() => setActiveTab('monitor')}
                className={`px-4 py-2 rounded-t text-sm flex items-center gap-2 ${
                  activeTab === 'monitor' 
                    ? 'bg-mc-accent text-white' 
                    : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                }`}
              >
                <Brain className="w-4 h-4" /> Monitor
              </button>
              <button
                onClick={() => setActiveTab('meetings')}
                className={`px-4 py-2 rounded-t text-sm flex items-center gap-2 ${
                  activeTab === 'meetings' 
                    ? 'bg-mc-accent text-white' 
                    : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                }`}
              >
                <Users className="w-4 h-4" /> Meetings
              </button>
              <button
                onClick={() => setActiveTab('delegate')}
                className={`px-4 py-2 rounded-t text-sm flex items-center gap-2 ${
                  activeTab === 'delegate' 
                    ? 'bg-mc-accent text-white' 
                    : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                }`}
              >
                <Send className="w-4 h-4" /> Delegate
              </button>
              <button
                onClick={() => setActiveTab('consensus')}
                className={`px-4 py-2 rounded-t text-sm flex items-center gap-2 ${
                  activeTab === 'consensus' 
                    ? 'bg-mc-accent text-white' 
                    : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                }`}
              >
                <CheckCircle className="w-4 h-4" /> Consensus
              </button>
            </div>

            {/* Monitor Tab */}
            {activeTab === 'monitor' && (
              <div className="space-y-4">
                {/* Summary Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <div className="text-2xl font-bold text-mc-text">{agents.length}</div>
                    <div className="text-sm text-mc-muted">Total Agents</div>
                  </div>
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <div className="text-2xl font-bold text-green-400">
                      {agents.filter(a => a.status === 'active').length}
                    </div>
                    <div className="text-sm text-mc-muted">Active</div>
                  </div>
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <div className="text-2xl font-bold text-blue-400">{meetings.length}</div>
                    <div className="text-sm text-mc-muted">Meetings Held</div>
                  </div>
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <div className="text-2xl font-bold text-purple-400">{delegations.length}</div>
                    <div className="text-sm text-mc-muted">Delegations</div>
                  </div>
                </div>

                {/* Controls: Search + Sort + Refresh */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="relative flex-1 min-w-[200px] max-w-sm">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-mc-muted" />
                    <input
                      type="text"
                      placeholder="Search agents..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full bg-mc-surface border border-mc-border rounded-lg pl-9 pr-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent"
                    />
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-mc-muted mr-1">Sort:</span>
                    {(['status', 'name', 'tier', 'department'] as SortField[]).map(f => (
                      <button
                        key={f}
                        onClick={() => toggleSort(f)}
                        className={`px-2 py-1.5 rounded transition-colors flex items-center gap-1 ${
                          sortField === f
                            ? 'bg-mc-accent/20 text-mc-accent'
                            : 'bg-mc-surface text-mc-muted hover:text-mc-text'
                        }`}
                      >
                        {f.charAt(0).toUpperCase() + f.slice(1)}
                        {sortField === f && (
                          <span className="text-[10px]">{sortDir === 'asc' ? '↑' : '↓'}</span>
                        )}
                      </button>
                    ))}
                  </div>
                  <button 
                    onClick={fetchAgents}
                    className="text-mc-muted hover:text-mc-text p-2"
                    title="Refresh"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>

                {/* Agent Card Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {sortedAgents.map(agent => {
                    const session = agentSessions[agent.id];
                    const displayModel = shortenModel((agent as any).model) || shortenModel(session?.model);

                    return (
                      <div
                        key={agent.id}
                        className={`bg-mc-surface border border-mc-border rounded-lg text-left hover:border-mc-accent/50 hover:bg-mc-bg/50 transition-all group ring-2 ring-transparent hover:ring-mc-accent/20 ${getStatusRing(agent.status)} flex flex-col`}
                      >
                        <button
                          onClick={() => setSelectedAgentId(agent.id)}
                          className="p-4 pb-2 text-left flex-1"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                              style={{ backgroundColor: (agent.color || '#6366f1') + '22', border: `1.5px solid ${agent.color || '#6366f1'}` }}>
                              {agent.emoji || '🤖'}
                            </div>
                            <div className="flex items-center gap-1.5">
                              <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`} />
                              <span className="text-[10px] text-mc-muted capitalize">{agent.status}</span>
                            </div>
                          </div>
                          <div className="font-semibold text-sm text-mc-text truncate group-hover:text-mc-accent transition-colors">
                            {agent.displayName || agent.name}
                          </div>
                          <div className="text-xs text-mc-muted truncate mt-0.5">
                            {agent.title || 'Agent'}
                          </div>
                          <div className="flex flex-wrap gap-1 mt-2">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded ${getTierColor(agent.tier)}`}>
                              {getTierLabel(agent.tier)}
                            </span>
                            {agent.department && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-mc-bg text-mc-muted">
                                {agent.department}
                              </span>
                            )}
                          </div>
                        </button>
                        <div className="px-4 pb-3 pt-1 border-t border-mc-border/50 mt-1">
                          <div className="flex items-center gap-2 text-[10px] mb-1.5">
                            {displayModel && (
                              <span className="flex items-center gap-1 text-mc-muted truncate" title={(agent as any).model || session?.model || ''}>
                                <Cpu className="w-3 h-3 flex-shrink-0" />
                                {displayModel}
                              </span>
                            )}
                            {session && (
                              <span className={`flex items-center gap-1 ml-auto flex-shrink-0 ${getContextColor(session.pct)}`} title={`${session.totalTokens.toLocaleString()} / ${session.contextTokens.toLocaleString()} tokens`}>
                                <Zap className="w-3 h-3" />
                                {formatTokens(session.totalTokens)}
                              </span>
                            )}
                          </div>
                          {session ? (
                            <div className="flex items-center gap-2">
                              <div className="flex-1 h-1.5 bg-mc-bg rounded-full overflow-hidden" title={`${session.pct}% context used`}>
                                <div
                                  className={`h-full ${getContextBarColor(session.pct)} transition-all`}
                                  style={{ width: `${Math.min(session.pct, 100)}%` }}
                                />
                              </div>
                              <span className={`text-[10px] font-medium w-7 text-right ${getContextColor(session.pct)}`}>
                                {session.pct}%
                              </span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setConfirmCompactAgent(agent.id);
                                }}
                                disabled={compactingAgent === agent.id}
                                className="p-1 rounded hover:bg-mc-bg text-mc-muted hover:text-mc-accent transition-colors disabled:opacity-50"
                                title="Compact & reset session"
                              >
                                {compactingAgent === agent.id ? (
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                ) : (
                                  <Minimize2 className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                          ) : (
                            <div className="text-[10px] text-mc-muted/50 italic">
                              No active session
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {sortedAgents.length === 0 && searchQuery && (
                  <div className="text-center py-8 text-mc-muted text-sm">
                    No agents match &ldquo;{searchQuery}&rdquo;
                  </div>
                )}

                {/* Agent Roster */}
                <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
                  <button
                    onClick={() => setRosterOpen(!rosterOpen)}
                    className="w-full px-4 py-3 flex items-center justify-between hover:bg-mc-bg/50 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-mc-accent" />
                      <span className="font-semibold text-mc-text text-sm">Agent Roster (AGENTS.md)</span>
                    </div>
                    {rosterOpen ? <ChevronDown className="w-4 h-4 text-mc-muted" /> : <ChevronRight className="w-4 h-4 text-mc-muted" />}
                  </button>

                  {rosterOpen && (
                    <div className="border-t border-mc-border p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleRecompileRoster}
                          disabled={rosterLoading}
                          className="px-3 py-1.5 bg-mc-accent text-white rounded text-xs font-medium hover:bg-mc-accent/80 disabled:opacity-50 flex items-center gap-1.5"
                        >
                          {rosterLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                          Recompile Roster
                        </button>
                        {rosterMsg && (
                          <span className={`text-xs ${rosterMsg.type === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                            {rosterMsg.type === 'success' ? <Check className="w-3 h-3 inline mr-1" /> : <AlertCircle className="w-3 h-3 inline mr-1" />}
                            {rosterMsg.text}
                          </span>
                        )}
                      </div>
                      <pre className="text-xs text-mc-text bg-mc-bg rounded p-3 overflow-x-auto whitespace-pre font-mono">
                        {rosterContent || 'No roster found. Click "Recompile Roster" to generate.'}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Meetings Tab */}
            {activeTab === 'meetings' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <h3 className="font-semibold text-mc-text mb-4 flex items-center gap-2">
                      <MessageSquare className="w-4 h-4" /> Run Meeting
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Topic</label>
                        <input type="text" value={newMeetingTopic} onChange={(e) => setNewMeetingTopic(e.target.value)}
                          placeholder="What should they discuss?" className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                      </div>
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Context (optional)</label>
                        <textarea value={meetingContext} onChange={(e) => setMeetingContext(e.target.value)}
                          placeholder="Background info..." rows={2} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-none" />
                      </div>
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Select Agents (min 2)</label>
                        <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto p-2 bg-mc-bg rounded border border-mc-border">
                          {agents.map(agent => (
                            <button key={agent.id} onClick={() => toggleAgentSelection(agent.id, setSelectedMeetingAgents)}
                              className={`text-xs px-2 py-1 rounded transition-colors ${
                                selectedMeetingAgents.includes(agent.id) ? 'bg-mc-accent text-white' : 'bg-mc-surface text-mc-muted hover:text-mc-text'
                              }`}>
                              {agent.name}
                            </button>
                          ))}
                        </div>
                      </div>
                      <button onClick={handleCreateMeeting} disabled={!newMeetingTopic || selectedMeetingAgents.length < 2}
                        className="w-full py-2 bg-mc-accent text-white rounded text-sm font-medium hover:bg-mc-accent/80 disabled:opacity-50 flex items-center justify-center gap-2">
                        <Play className="w-4 h-4" /> Run Meeting
                      </button>
                    </div>
                  </div>
                  <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
                    <div className="px-4 py-3 border-b border-mc-border">
                      <h3 className="font-semibold text-mc-text">Past Meetings</h3>
                    </div>
                    <div className="max-h-80 overflow-y-auto">
                      {meetings.length === 0 ? (
                        <div className="p-4 text-mc-muted text-sm text-center">No meetings yet</div>
                      ) : (
                        <div className="divide-y divide-mc-border">
                          {meetings.map(m => (
                            <div key={m.id} className="p-3">
                              <div className="font-medium text-sm text-mc-text truncate">{m.topic}</div>
                              <div className="text-xs text-mc-muted mt-1">
                                {m.agents.map(a => a.name).join(', ')}
                              </div>
                              <div className="text-xs text-mc-muted/60 mt-0.5">
                                {new Date(m.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                {meetingResult && (
                  <div className="bg-mc-bg border border-mc-border rounded-lg p-4 text-sm text-mc-text whitespace-pre-wrap">
                    {typeof meetingResult === 'string' ? meetingResult : JSON.stringify(meetingResult, null, 2)}
                  </div>
                )}
              </div>
            )}

            {/* Delegate Tab */}
            {activeTab === 'delegate' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <h3 className="font-semibold text-mc-text mb-4 flex items-center gap-2">
                      <Send className="w-4 h-4" /> Delegate Task
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Topic</label>
                        <input type="text" value={delegateTopic} onChange={(e) => setDelegateTopic(e.target.value)}
                          placeholder="What needs to be done?" className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                      </div>
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Agent</label>
                        <select value={selectedDelegateAgent} onChange={(e) => setSelectedDelegateAgent(e.target.value)}
                          className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent">
                          <option value="">Auto-select best agent</option>
                          {agents.map(agent => (
                            <option key={agent.id} value={agent.id}>{agent.displayName || agent.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Context (optional)</label>
                        <textarea value={delegateContext} onChange={(e) => setDelegateContext(e.target.value)}
                          placeholder="Background info..." rows={2} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-none" />
                      </div>
                      <button onClick={handleDelegate} disabled={!delegateTopic}
                        className="w-full py-2 bg-mc-accent text-white rounded text-sm font-medium hover:bg-mc-accent/80 disabled:opacity-50 flex items-center justify-center gap-2">
                        <Send className="w-4 h-4" /> Delegate
                      </button>
                    </div>
                  </div>
                  <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
                    <div className="px-4 py-3 border-b border-mc-border">
                      <h3 className="font-semibold text-mc-text">Past Delegations</h3>
                    </div>
                    <div className="max-h-80 overflow-y-auto">
                      {delegations.length === 0 ? (
                        <div className="p-4 text-mc-muted text-sm text-center">No delegations yet</div>
                      ) : (
                        <div className="divide-y divide-mc-border">
                          {delegations.map(d => (
                            <div key={d.id} className="p-3">
                              <div className="font-medium text-sm text-mc-text truncate">{d.topic}</div>
                              <div className="text-xs text-mc-muted mt-1">{d.targetAgent.name} — <span className="capitalize">{d.status}</span></div>
                              {d.result && <div className="text-xs text-mc-muted/70 mt-1 truncate">{d.result}</div>}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                {delegateResult && (
                  <div className="bg-mc-bg border border-mc-border rounded-lg p-4 text-sm text-mc-text whitespace-pre-wrap">
                    {typeof delegateResult === 'string' ? delegateResult : JSON.stringify(delegateResult, null, 2)}
                  </div>
                )}
              </div>
            )}

            {/* Consensus Tab */}
            {activeTab === 'consensus' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
                    <h3 className="font-semibold text-mc-text mb-4 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" /> Run Consensus
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Topic</label>
                        <input type="text" value={consensusTopic} onChange={(e) => setConsensusTopic(e.target.value)}
                          placeholder="What decision needs consensus?" className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                      </div>
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Context (optional)</label>
                        <textarea value={consensusContext} onChange={(e) => setConsensusContext(e.target.value)}
                          placeholder="Background info..." rows={2} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-2 text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-none" />
                      </div>
                      <div>
                        <label className="text-xs text-mc-muted block mb-1">Select Agents (min 2)</label>
                        <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto p-2 bg-mc-bg rounded border border-mc-border">
                          {agents.map(agent => (
                            <button key={agent.id} onClick={() => toggleAgentSelection(agent.id, setSelectedConsensusAgents)}
                              className={`text-xs px-2 py-1 rounded transition-colors ${
                                selectedConsensusAgents.includes(agent.id) ? 'bg-mc-accent text-white' : 'bg-mc-surface text-mc-muted hover:text-mc-text'
                              }`}>
                              {agent.name}
                            </button>
                          ))}
                        </div>
                      </div>
                      <button onClick={handleStartConsensus} disabled={!consensusTopic || selectedConsensusAgents.length < 2}
                        className="w-full py-2 bg-mc-accent text-white rounded text-sm font-medium hover:bg-mc-accent/80 disabled:opacity-50 flex items-center justify-center gap-2">
                        <CheckCircle className="w-4 h-4" /> Start Consensus
                      </button>
                    </div>
                  </div>
                  <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
                    <div className="px-4 py-3 border-b border-mc-border">
                      <h3 className="font-semibold text-mc-text">Past Sessions</h3>
                    </div>
                    <div className="max-h-80 overflow-y-auto">
                      {consensusSessions.length === 0 ? (
                        <div className="p-4 text-mc-muted text-sm text-center">No consensus sessions yet</div>
                      ) : (
                        <div className="divide-y divide-mc-border">
                          {consensusSessions.map(cs => (
                            <div key={cs.id} className="p-3">
                              <div className="font-medium text-sm text-mc-text truncate">{cs.topic}</div>
                              <div className="text-xs text-mc-muted mt-1 capitalize">{cs.status}</div>
                              {cs.result && (
                                <div className="text-xs mt-1">
                                  <span className="text-green-400">{cs.result.agreeCount} agree</span>
                                  {' / '}
                                  <span className="text-red-400">{cs.result.disagreeCount} disagree</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                {consensusResult && (
                  <div className="bg-mc-bg border border-mc-border rounded-lg p-4 text-sm text-mc-text whitespace-pre-wrap">
                    {typeof consensusResult === 'string' ? consensusResult : JSON.stringify(consensusResult, null, 2)}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Confirm Compact Modal */}
      {confirmCompactAgent && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setConfirmCompactAgent(null)}>
          <div className="bg-mc-surface border border-mc-border rounded-xl p-6 max-w-sm w-full mx-4" onClick={e => e.stopPropagation()}>
            <h3 className="font-semibold text-mc-text mb-2">Compact Session?</h3>
            <p className="text-sm text-mc-muted mb-4">
              This will summarize and reset <span className="text-mc-text font-medium">{confirmCompactAgent}</span>&apos;s session. The agent will wake fresh with a summary.
            </p>
            <div className="flex gap-2">
              <button onClick={() => setConfirmCompactAgent(null)} className="flex-1 py-2 bg-mc-bg border border-mc-border text-mc-muted rounded text-sm hover:text-mc-text">Cancel</button>
              <button onClick={() => handleCompactAgent(confirmCompactAgent)} className="flex-1 py-2 bg-mc-accent text-white rounded text-sm font-medium hover:bg-mc-accent/80">Compact</button>
            </div>
          </div>
        </div>
      )}

      {/* Compact Progress Modal */}
      {showCompactModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-mc-surface border border-mc-border rounded-xl p-6 max-w-sm w-full mx-4">
            <h3 className="font-semibold text-mc-text mb-4">
              Compacting {compactingAgent}...
            </h3>
            {compactResult ? (
              <div className={`text-sm ${compactResult.ok ? 'text-green-400' : 'text-red-400'}`}>
                {compactResult.msg}
              </div>
            ) : (
              <div className="flex items-center gap-3 text-sm text-mc-muted">
                <Loader2 className="w-4 h-4 animate-spin text-mc-accent" />
                {compactProgress}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
