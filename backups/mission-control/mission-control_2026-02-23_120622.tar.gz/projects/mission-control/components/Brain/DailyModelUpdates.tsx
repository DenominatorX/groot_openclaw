'use client';

import { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { RefreshCw, AlertCircle, Cpu, CalendarDays } from 'lucide-react';

interface ModelUpdatesData {
  file: string;
  content: string;
  date?: string;
}

function SkeletonLine({ w = 'w-full' }: { w?: string }) {
  return <div className={`h-3 ${w} bg-mc-border/60 rounded animate-pulse`} />;
}

/** Extract a YYYY-MM-DD date from a filename like model-updates-2025-01-15.md */
function parseDateFromFilename(filename: string): string | null {
  const match = filename.match(/(\d{4}-\d{2}-\d{2})/);
  if (!match) return null;
  try {
    return new Date(match[1]).toLocaleDateString(undefined, {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return match[1];
  }
}

export default function DailyModelUpdates() {
  const [data, setData] = useState<ModelUpdatesData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchUpdates = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/model-updates/latest');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      setError(err.message || 'Failed to load model updates');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUpdates();
  }, []);

  const reportDate = data?.file ? parseDateFromFilename(data.file) : null;

  return (
    <div className="flex flex-col h-full bg-mc-surface border border-mc-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border/50">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-mc-accent" />
          <span className="font-semibold text-sm text-mc-text">Model Updates</span>
          {reportDate && (
            <span className="flex items-center gap-1 text-[10px] text-mc-muted bg-mc-bg px-1.5 py-0.5 rounded border border-mc-border/40">
              <CalendarDays className="w-3 h-3" />
              {reportDate}
            </span>
          )}
        </div>
        <button
          onClick={fetchUpdates}
          disabled={loading}
          className="text-mc-muted hover:text-mc-text transition-colors disabled:opacity-40 p-1 rounded"
          title="Refresh model updates"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-mc-border scrollbar-track-transparent">
        {loading && (
          <div className="space-y-3">
            <SkeletonLine w="w-1/2" />
            <SkeletonLine w="w-full" />
            <SkeletonLine w="w-5/6" />
            <SkeletonLine w="w-full" />
            <SkeletonLine w="w-3/4" />
            <div className="pt-2 space-y-2">
              <SkeletonLine w="w-1/3" />
              <SkeletonLine w="w-full" />
              <SkeletonLine w="w-4/5" />
            </div>
          </div>
        )}
        {!loading && error && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-sm text-red-400">{error}</p>
            <button onClick={fetchUpdates} className="text-xs text-mc-accent hover:underline">Try again</button>
          </div>
        )}
        {!loading && !error && (!data || !data.content) && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <Cpu className="w-6 h-6 text-mc-muted" />
            <p className="text-sm text-mc-muted font-medium">No updates yet</p>
            <p className="text-xs text-mc-muted/70">Model intel reports will appear here once the daily cron runs.</p>
          </div>
        )}
        {!loading && !error && data?.content && (
          <div className="prose prose-invert prose-sm max-w-none
            prose-headings:text-mc-text prose-headings:font-semibold
            prose-h1:text-base prose-h2:text-sm prose-h3:text-xs
            prose-h2:mt-4 prose-h3:mt-3
            prose-p:text-mc-muted prose-p:leading-relaxed prose-p:text-xs
            prose-li:text-mc-muted prose-li:text-xs
            prose-strong:text-mc-text
            prose-code:text-mc-accent prose-code:bg-mc-bg prose-code:px-1 prose-code:py-0.5 prose-code:rounded prose-code:text-[11px]
            prose-pre:bg-mc-bg prose-pre:border prose-pre:border-mc-border/50 prose-pre:text-xs
            prose-hr:border-mc-border/50
            prose-a:text-mc-accent prose-a:no-underline hover:prose-a:underline
            prose-table:text-xs prose-th:text-mc-text prose-td:text-mc-muted
            prose-blockquote:border-l-mc-accent/60 prose-blockquote:text-mc-muted
          ">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{data.content}</ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}
