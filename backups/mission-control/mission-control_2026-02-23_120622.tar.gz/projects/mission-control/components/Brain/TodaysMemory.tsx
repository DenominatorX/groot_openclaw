'use client';

import { useState, useEffect } from 'react';
import { RefreshCw, AlertCircle, BookOpen, Folder, Circle } from 'lucide-react';

interface Project {
  id: string;
  name: string;
  status: string;
}

interface BriefingData {
  activeProjects: Project[];
  todayMemory?: string | null;
  generatedAt?: string;
}

function StatusBadge({ status }: { status: string }) {
  const color =
    status === 'active' ? 'bg-green-900/60 text-green-400 border-green-700/50' :
    status === 'in-progress' ? 'bg-blue-900/60 text-blue-400 border-blue-700/50' :
    status === 'paused' ? 'bg-yellow-900/60 text-yellow-400 border-yellow-700/50' :
    status === 'blocked' ? 'bg-red-900/60 text-red-400 border-red-700/50' :
    status === 'completed' ? 'bg-gray-900/60 text-gray-400 border-gray-700/50' :
    'bg-mc-bg text-mc-muted border-mc-border';

  return (
    <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border ${color} font-medium uppercase tracking-wide`}>
      <Circle className="w-1.5 h-1.5 fill-current" />
      {status}
    </span>
  );
}

function SkeletonLine({ w = 'w-full' }: { w?: string }) {
  return <div className={`h-3 ${w} bg-mc-bg rounded animate-pulse`} />;
}

export default function TodaysMemory() {
  const [data, setData] = useState<BriefingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBriefing = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/brain/briefing');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      setError(err.message || 'Failed to load briefing');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBriefing();
  }, []);

  return (
    <div className="flex flex-col h-full bg-mc-bg border border-mc-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-mc-accent" />
          <span className="font-semibold text-sm text-mc-text">Today&apos;s Memory</span>
        </div>
        <button
          onClick={fetchBriefing}
          disabled={loading}
          className="text-mc-muted hover:text-mc-text transition-colors disabled:opacity-40 p-1 rounded"
          title="Refresh"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-mc-border scrollbar-track-transparent">
        {/* Loading skeleton */}
        {loading && (
          <div className="space-y-4">
            <div className="space-y-2">
              <SkeletonLine w="w-1/3" />
              <SkeletonLine w="w-full" />
              <SkeletonLine w="w-5/6" />
              <SkeletonLine w="w-4/5" />
            </div>
            <div className="space-y-2">
              <SkeletonLine w="w-1/3" />
              <SkeletonLine w="w-full" />
              <SkeletonLine w="w-3/4" />
            </div>
          </div>
        )}

        {/* Error state */}
        {!loading && error && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-sm text-red-400">{error}</p>
            <button
              onClick={fetchBriefing}
              className="text-xs text-mc-accent hover:underline"
            >
              Try again
            </button>
          </div>
        )}

        {/* Content */}
        {!loading && !error && data && (
          <>
            {/* Active Projects */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Folder className="w-3.5 h-3.5 text-mc-accent" />
                <span className="text-xs font-semibold text-mc-text uppercase tracking-wider">
                  Active Projects
                </span>
                <span className="ml-auto text-xs font-bold text-mc-accent bg-mc-accent/10 px-1.5 py-0.5 rounded">
                  {data.activeProjects?.length || 0}
                </span>
              </div>

              {(data.activeProjects?.length || 0) === 0 ? (
                <p className="text-xs text-mc-muted italic pl-1">No active projects found.</p>
              ) : (
                <ul className="space-y-1.5">
                  {data.activeProjects?.map((project) => (
                    <li
                      key={project.id}
                      className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-lg bg-mc-bg border border-mc-border hover:bg-mc-surface transition-colors"
                    >
                      <div className="min-w-0">
                        <span className="text-[10px] text-mc-muted font-mono mr-1.5">{project.id}</span>
                        <span className="text-xs text-mc-text truncate">{project.name}</span>
                      </div>
                      <StatusBadge status={project.status} />
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Memory Snippet */}
            {data.todayMemory && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-mc-accent text-sm">🧠</span>
                  <span className="text-xs font-semibold text-mc-text uppercase tracking-wider">
                    Memory
                  </span>
                </div>
                <div className="px-3 py-2 rounded-lg bg-mc-bg border border-mc-border border-l-2 border-l-mc-accent/60">
                  <p className="text-xs text-mc-muted leading-relaxed whitespace-pre-wrap">
                    {data.todayMemory}
                  </p>
                </div>
              </div>
            )}

            {/* Timestamp */}
            {data.generatedAt && (
              <p className="text-[10px] text-mc-muted/50 text-right">
                Updated {new Date(data.generatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            )}
          </>
        )}

        {/* Empty state (no data, no error) */}
        {!loading && !error && !data && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <BookOpen className="w-6 h-6 text-mc-muted" />
            <p className="text-sm text-mc-muted">No memory available</p>
          </div>
        )}
      </div>
    </div>
  );
}