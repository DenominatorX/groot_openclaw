'use client';
import { useState, useRef, useEffect, useCallback } from 'react';

type Message = { role: 'user' | 'assistant'; content: string };

type Props = {
  userId?: string;
  fullPage?: boolean;
};

export default function BrainChat({ userId = 'kevin', fullPage = false }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const inputRef = useRef<null | HTMLInputElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  useEffect(() => {
    fetch(`/api/brain/${userId}/chat`)
      .then((res) => res.json())
      .then((data) => {
        if (data.history) {
          setMessages(data.history);
        }
      })
      .catch(console.error);
  }, [userId]);

  const sendMessage = async () => {
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const userMessage: Message = { role: 'user', content: trimmed };
    setMessages((prev) => [...prev, userMessage]);
    const tempInput = input;
    setInput('');
    setLoading(true);

    try {
      const response = await fetch(`/api/brain/${userId}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: tempInput }),
      });
      const data = await response.json();
      if (data.reply) {
        setMessages((prev) => [...prev, { role: 'assistant', content: data.reply }]);
      }
    } catch (error) {
      console.error('Error:', error);
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Sorry, something went wrong.' }]);
    } finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className={`flex flex-col h-full ${fullPage ? '' : 'p-4'}`} style={{ minHeight: 0 }}>
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin scrollbar-thumb-mc-border scrollbar-track-mc-bg/50" style={{ minHeight: 0 }}>
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-64 text-mc-muted">
            <div className="text-4xl mb-2">🧠</div>
            <p>Your universal memory assistant is ready.</p>
            <p className="text-sm mt-2">Ask about projects, agents, memory, or dispatch tasks.</p>
          </div>
        )}
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : ''}`} >
            <div
              className={`max-w-3xl p-4 rounded-2xl shadow-md ${
                message.role === 'user'
                  ? 'bg-mc-accent text-white ml-16'
                  : 'bg-mc-bg/80 backdrop-blur-sm border border-mc-border/50 mr-16'
              }`}
            >
              <p className="whitespace-pre-wrap">{message.content}</p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
        {loading && (
          <div className="flex">
            <div className="p-4 bg-mc-bg/50 border border-mc-border rounded-2xl mr-16 animate-pulse">
              Brain is thinking...
            </div>
          </div>
        )}
      </div>
      <div className="flex gap-2 p-1 bg-mc-bg/50 rounded-xl border border-mc-border">
        <textarea
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 p-4 bg-mc-bg/50 border-0 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-mc-accent max-h-32"
          placeholder="Message Brain... (⌘ Enter to send)"
          rows={1}
          onKeyDown={handleKeyDown}
          disabled={loading}
        />
        <button
          onClick={sendMessage}
          disabled={loading || !input.trim()}
          className="px-4 py-4 bg-mc-accent/90 hover:bg-mc-accent text-white rounded-xl font-medium transition-all disabled:opacity-50 flex items-center gap-1"
        >
          {loading ? '<div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>' : 'Send'}
        </button>
        <button
          className="p-4 text-mc-muted hover:text-mc-accent transition-colors"
          title="Save to memory"
        >
          💾
        </button>
      </div>
    </div>
  );
}