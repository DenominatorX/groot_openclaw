# Mission Control — Full Audit Report

**Date:** 2026-02-15  
**Auditor:** Architect (AI Agent)  
**Scope:** OpenClaw integration, SaaS readiness, security, file I/O, component capabilities

---

## 1. Executive Summary

Mission Control is a feature-rich Next.js dashboard with ~100+ API routes, chat rooms, agent orchestration, brain dumps, project management, and games. However, it has **critical architectural issues** that block both OpenClaw compatibility and SaaS deployment:

1. **Mixed agent spawning patterns** — Some routes use broken CLI `spawn('openclaw', ...)`, others use the Gateway HTTP API, and most chat routes call LLM APIs directly (bypassing OpenClaw entirely).
2. **No auth on critical routes** — `issues/route.ts` (create, analyze, execute) and `omi/route.ts` have **zero authentication**.
3. **All data is flat JSON files** in `data/` with synchronous `fs.readFileSync`/`writeFileSync` — race conditions guaranteed under concurrent access.
4. **Hardcoded paths** — Multiple routes contain `/Users/groot/.openclaw/workspace/...` strings.
5. **Single-tenant architecture** — No user/org isolation. One `data/` directory, one `auth.json`, one set of API keys.
6. **API keys stored in plain JSON** — `data/settings.json` holds Anthropic, OpenAI, Grok, OpenRouter, and Gateway tokens in cleartext.

**Bottom line:** The app works well as a local single-user tool. Getting to SaaS requires a database migration, auth overhaul, and agent integration standardization.

---

## 2. Critical Issues (Blocking)

### ❌ C1: No Auth on Issues API
`app/api/issues/route.ts` — GET and POST have **no `checkAuth()` call**. Anyone can create issues, trigger agent analysis (`spawn('openclaw', ...)`), and execute code fixes. This is a **remote code execution vector** if exposed to the network.

### ❌ C2: No Auth on OMI Webhook
`app/api/omi/route.ts` — No authentication. Accepts external webhook data and writes to disk.

### ❌ C3: CLI-based Agent Spawning (Broken Pattern)
These routes use `spawn('openclaw', ['agent', ...])` which:
- Requires `openclaw` CLI on PATH
- Blocks the Node.js event loop waiting for process completion (up to 10 min!)
- Won't work in containerized/SaaS deployments
- No error recovery if CLI hangs

**Affected routes:**
- `app/api/agents/spawn/route.ts`
- `app/api/plan/execute/route.ts`
- `app/api/issues/route.ts` (analyze + execute actions)

### ❌ C4: Hardcoded Absolute Paths
These routes embed `/Users/groot/.openclaw/workspace/...`:
- `app/api/plan/execute/route.ts` — line 104
- `app/api/projects/route.ts` — line 258
- `app/api/projects/execute/route.ts` — lines 123, 128, 145
- `app/api/assets/route.ts` — line 10
- `app/api/issues/route.ts` — lines 99, 200

### ❌ C5: Settings API Exposes Raw API Keys
`app/api/settings/route.ts` GET returns `{ settings: masked, raw: settings }` — the `raw` field contains **all API keys in cleartext**. Any authenticated user gets every key.

---

## 3. OpenClaw Integration Gaps

### Agent Spawning — Three Competing Patterns

| Pattern | Routes | Status |
|---------|--------|--------|
| **CLI spawn** (`spawn('openclaw', ...)`) | `agents/spawn`, `plan/execute`, `issues` | ❌ Broken for SaaS |
| **Gateway HTTP API** (`fetch(gatewayUrl + '/api/sessions')`) | `projects/execute` | ✅ Correct pattern |
| **Direct LLM API calls** (Anthropic/OpenAI/Grok) | `chat/*`, `brain/*`, `projects/route.ts` execute action | ⚠️ Works but bypasses OpenClaw |

**Recommendation:** Standardize ALL agent interactions through the Gateway HTTP API (`projects/execute/route.ts` is the model). The direct LLM calls in chat are acceptable for low-latency chat but should be labeled as "direct mode" vs "agent mode."

### Gateway Integration Status
- `projects/execute/route.ts` — ✅ Uses Gateway API correctly (spawn session → send message → poll → cleanup)
- `dispatch/route.ts` — ⚠️ Tracks sessions but doesn't actually spawn via Gateway; communicates with a separate "world server" at port 18801
- `brain/orchestrate/route.ts` — ❌ Calls Anthropic API directly, no Gateway involvement
- `context-health/route.ts` — Uses `execSync('curl ... localhost:18789')` to check gateway — fragile

---

## 4. SaaS Blockers

### 4.1 Data Layer: JSON Files on Disk
**Every single route** reads/writes JSON files via synchronous `fs` calls. No database.

**Files written:**
| File | Writers |
|------|---------|
| `data/tasks.json` | tasks, chat/agent (CREATE_TASK action) |
| `data/projects.json` | projects, chat/agent (CREATE_PROJECT action) |
| `data/issues.json` | issues, chat/agent (CREATE_ISSUE action) |
| `data/agents.json` | dispatch |
| `data/agent-sessions.json` | agents/spawn, dispatch |
| `data/activity.json` | dispatch, plan/execute, chat/agent, many others |
| `data/agent-usage.json` | chat/agent |
| `data/settings.json` | settings |
| `data/auth.json` | auth/setup, auth/change-password |
| `data/rooms.json` | rooms |
| `data/brain-dumps.json` | brain/process |
| `data/brain/meetings.json` | brain/orchestrate |
| `data/chat/*.json` | chat, chat/agent, chat/project |
| `data/plans/*.json` | plan |
| `data/risks/*.json` | risks |
| `data/tests/*.json` | tests |
| `data/trading/*.json` | trading |
| `data/games/*.json` | games/* |
| `data/apps/*` | apps/* |
| `data/features.json` | features |
| `data/lifecycle.json` | lifecycle |
| `data/versions.json` | version |
| `data/reports.json` | reports |
| `data/oura-tokens.json` | oura |

**Race conditions:** Multiple routes write to `activity.json`, `tasks.json`, `projects.json` — concurrent requests will overwrite each other (read-modify-write without locking).

### 4.2 Authentication: Single-User Only
- One password in `data/auth.json`
- Iron-session cookie auth (good foundation)
- No user model, no orgs, no roles
- `checkAuth()` returns `{ authenticated: boolean }` — no user identity

### 4.3 Multi-Tenancy: Zero Isolation
- All data in one `data/` directory
- API keys shared across all "users"
- No concept of org/workspace/tenant
- Agent configs are global

### 4.4 Configuration: Hardcoded Values
- Port 18789 (Gateway), 18801 (World server) hardcoded in dispatch
- Agent-to-model mapping hardcoded in `projects/route.ts`
- LLM model names hardcoded throughout
- Room context descriptions hardcoded in `chat/route.ts`

---

## 5. Component-by-Component Findings

### IssuesLog.tsx
- **Read:** Fetches from `/api/issues`
- **Write:** Can create issues, trigger analyze/execute (which spawn agents via CLI)
- **Issue:** Backend has NO AUTH — exposed publicly

### ProjectProfile.tsx / ProjectDetail.tsx
- **Read:** Fetches project data, documents
- **Write:** Can update projects, phases, trigger execution
- **Issue:** Document listing traverses `../../projects/` relative path — directory traversal risk

### KanbanBoard.tsx
- **Read/Write:** Full CRUD on tasks via `/api/tasks`
- **Status:** ✅ Well-structured, auth-protected backend

### GlobalChat.tsx
- **Read/Write:** Chat messages via `/api/chat`
- **Agent spawning:** Triggers agent responses by @mention — uses direct LLM calls, not Gateway
- **Issue:** In-memory typing state (`typingState` map) lost on restart; doesn't scale to multiple instances

### BrainOrchestration.tsx
- **Read/Write:** Meetings, consensus, delegation via `/api/brain/orchestrate`
- **Agent spawning:** Direct Anthropic API calls for all brain functions
- **Issue:** Uses `brain-security.ts` library but synthetic consensus votes (not real agent input)

### AnalyticsPanel.tsx
- **Read only:** Aggregates data from various JSON files
- **Status:** ✅ OK for current use

### BrainDump.tsx
- **Write:** Creates brain dumps, can auto-create projects/tasks from dumps
- **Issue:** Sends full project/task/agent data in system prompt (~could be large)

---

## 6. API Route Inventory

### Core Data Routes
| Route | Methods | Auth | File I/O | Agent Spawn | Status |
|-------|---------|------|----------|-------------|--------|
| `/api/tasks` | GET, POST | ✅ | tasks.json | ❌ | ✅ OK |
| `/api/projects` | GET, POST, PATCH | ✅ | projects.json | OpenRouter direct | ⚠️ Needs Fix |
| `/api/issues` | GET, POST | ❌ **NONE** | issues.json | CLI spawn | ❌ Broken |
| `/api/agents` | GET | ✅ | agents.json | ❌ | ✅ OK |
| `/api/agents/spawn` | GET, POST | ✅ | agent-sessions.json | CLI spawn | ❌ Broken |
| `/api/dispatch` | GET, POST | ✅ | agents.json, sessions, activity | World IPC | ⚠️ Needs Fix |
| `/api/activity` | GET | ✅ | activity.json | ❌ | ✅ OK |
| `/api/teams` | GET, POST | ✅ | teams.json | ❌ | ✅ OK |
| `/api/rooms` | GET, POST | ✅ | rooms.json | ❌ | ✅ OK |

### Chat Routes
| Route | Methods | Auth | File I/O | Agent Spawn | Status |
|-------|---------|------|----------|-------------|--------|
| `/api/chat` | GET, POST, PATCH, DELETE | ✅ | chat/*.json | Direct LLM | ⚠️ Needs Fix |
| `/api/chat/agent` | GET, POST | ✅ | chat/*.json, issues, tasks, projects | Direct LLM + actions | ⚠️ Needs Fix |
| `/api/chat/project` | GET, POST | ✅ | chat/*.json | Direct LLM | ⚠️ Needs Fix |

### Brain Routes
| Route | Methods | Auth | File I/O | Agent Spawn | Status |
|-------|---------|------|----------|-------------|--------|
| `/api/brain/orchestrate` | POST | ✅ | meetings.json | Direct Anthropic | ⚠️ Needs Fix |
| `/api/brain/process` | POST | ✅ | brain-dumps.json | Direct Anthropic | ⚠️ Needs Fix |
| `/api/brain/dump` | GET, POST | ✅ | brain-dumps.json | ❌ | ✅ OK |
| `/api/brain/dump/apply` | POST | ✅ | projects, tasks, issues | ❌ | ✅ OK |
| `/api/brain/mood` | GET, POST | ✅ | brain/mood.json | ❌ | ✅ OK |
| `/api/brain/status` | GET | ✅ | multiple reads | ❌ | ✅ OK |
| `/api/brain/agents` | GET | ✅ | agents.json | ❌ | ✅ OK |
| `/api/brain/consensus` | POST | ✅ | brain/ | ❌ | ✅ OK |
| `/api/brain/delegation` | GET, POST | ✅ | brain/ | ❌ | ✅ OK |
| `/api/brain/meetings` | GET | ✅ | brain/meetings.json | ❌ | ✅ OK |
| `/api/brain/moods` | GET | ✅ | brain/ | ❌ | ✅ OK |
| `/api/brain/dumps` | GET | ✅ | brain-dumps.json | ❌ | ✅ OK |

### Plan Routes
| Route | Methods | Auth | File I/O | Agent Spawn | Status |
|-------|---------|------|----------|-------------|--------|
| `/api/plan` | GET, POST | ✅ | plans/ | ❌ | ✅ OK |
| `/api/plan/generate` | POST | ✅ | plans/ | Direct LLM | ⚠️ Needs Fix |
| `/api/plan/execute` | POST | ✅ | activity.json | CLI spawn | ❌ Broken |

### Project Execution Routes
| Route | Methods | Auth | File I/O | Agent Spawn | Status |
|-------|---------|------|----------|-------------|--------|
| `/api/projects/execute` | POST | ✅ | ❌ | **Gateway API** ✅ | ✅ OK |
| `/api/projects/analyze` | POST | ✅ | projects.json | Direct LLM | ⚠️ Needs Fix |
| `/api/projects/auto-assign` | POST | ✅ | projects, agents | Direct LLM | ⚠️ Needs Fix |

### Auth Routes
| Route | Methods | Auth | Status |
|-------|---------|------|--------|
| `/api/auth/setup` | POST | Rate-limited | ✅ OK |
| `/api/auth/login` | POST | Rate-limited | ✅ OK |
| `/api/auth/logout` | POST | Session | ✅ OK |
| `/api/auth/status` | GET | Session | ✅ OK |
| `/api/auth/change-password` | POST | ✅ | ✅ OK |

### System Routes
| Route | Methods | Auth | Status |
|-------|---------|------|--------|
| `/api/system` | GET | ✅ | ⚠️ Exposes system info |
| `/api/health` | GET | ✅ | ✅ OK |
| `/api/settings` | GET, PUT | ✅ | ❌ Leaks raw API keys |
| `/api/server/restart` | POST | ✅ | ⚠️ Sends SIGUSR2 |
| `/api/version` | GET | ✅ | ✅ OK |
| `/api/context-health` | GET | ✅ | ⚠️ Uses execSync curl |
| `/api/features` | GET, POST | ✅ | ✅ OK |

### Misc Routes (all use checkAuth ✅)
| Route | Status | Notes |
|-------|--------|-------|
| `/api/risks/*` | ✅ OK | Read/write risk JSON files |
| `/api/tests/*` | ✅ OK | Read/write test JSON files |
| `/api/lifecycle` | ✅ OK | Read/write lifecycle.json |
| `/api/usage` | ✅ OK | Read-only usage data |
| `/api/agents/usage` | ✅ OK | Read usage data |
| `/api/agents/activity` | ✅ OK | Read activity data |
| `/api/agents/world-reset` | ✅ OK | Resets world state |
| `/api/analytics` | ✅ OK | Read-only aggregation |
| `/api/reports/*` | ✅ OK | Reports management |
| `/api/trading` | ✅ OK | Trading data |
| `/api/voice` | ✅ OK | Voice processing |
| `/api/govee` | ✅ OK | Smart home control |
| `/api/oura/*` | ⚠️ | OAuth callback unauthed (expected) |
| `/api/omi` | ❌ | No auth on webhook |
| `/api/character-types` | ✅ OK | Character config |
| `/api/assets` | ✅ OK | Static assets (hardcoded path) |
| `/api/games/*` | ✅ OK | Game state management |
| `/api/apps/*` | ✅ OK | App data management |

---

## 7. Recommended Fix Priority

### P0 — Fix Immediately (Security)
1. **Add `checkAuth()` to `/api/issues/route.ts`** — Both GET and POST are unprotected. This is an RCE vector via the agent spawn in analyze/execute actions.
2. **Remove `raw: settings` from settings GET response** — API keys are leaked in cleartext.
3. **Add auth or webhook secret to `/api/omi/route.ts`** — External webhook with no validation.

### P1 — Fix This Week (Functionality)
4. **Replace all CLI `spawn('openclaw', ...)` with Gateway HTTP API** — Use the pattern from `projects/execute/route.ts`. Affected: `agents/spawn`, `plan/execute`, `issues` (analyze/execute).
5. **Remove hardcoded `/Users/groot/` paths** — Replace with env var or config: `process.env.WORKSPACE_ROOT || process.cwd()`.
6. **Fix race conditions on shared JSON files** — At minimum, add file-level locking (e.g., `proper-lockfile`). Long-term: migrate to database.

### P2 — Fix This Month (SaaS Prep)
7. **Database migration** — Replace JSON files with SQLite (immediate) or PostgreSQL (production). Start with: tasks, projects, issues, activity.
8. **Multi-user auth** — Extend `checkAuth()` to return user identity. Add user model with org/workspace scoping.
9. **Tenant-scoped data paths** — All file paths need `{tenantId}/` prefix or database isolation.
10. **API key management** — Move to encrypted storage or env vars. Never return raw keys via API.
11. **Standardize agent integration** — Create a shared `lib/agent-client.ts` that wraps Gateway API calls. All routes use this instead of ad-hoc fetch/spawn.

### P3 — Fix Before Launch (Polish)
12. **Rate limiting on all write endpoints** — Currently only auth routes have rate limiting.
13. **Request validation** — No input validation/sanitization on most POST routes.
14. **Audit logging** — Add structured audit trail for all mutations (who, what, when).
15. **API documentation** — No OpenAPI/Swagger specs exist.
16. **Chat scalability** — Replace in-memory `typingState`/`meetingState` with Redis or similar.
17. **Error handling consistency** — Mix of error response formats across routes.

---

## 8. Architecture Recommendations for SaaS

### Phase 1: Foundation (Weeks 1-2)
1. **Fix P0 security issues** (day 1)
2. **Create `lib/gateway-client.ts`** — Single module for all Gateway API interactions
3. **Create `lib/data-store.ts`** — Abstract data access behind an interface (JSON now, DB later)
4. **Add env-based configuration** — `GATEWAY_URL`, `WORKSPACE_ROOT`, `DATABASE_URL`

### Phase 2: Data Layer (Weeks 3-4)
5. **Migrate to SQLite** with Prisma or Drizzle ORM
6. **Schema:** Users, Orgs, Workspaces, Projects, Tasks, Issues, Activity, ChatMessages, AgentSessions
7. **Add proper migrations** and seed scripts
8. **Implement optimistic locking** for concurrent writes

### Phase 3: Multi-Tenancy (Weeks 5-6)
9. **User/Org model** — JWT or session-based auth with org scoping
10. **Row-level security** — All queries filtered by `orgId`
11. **API key vault** — Per-org encrypted API key storage
12. **Per-org Gateway tokens** — Each org gets its own Gateway session namespace

### Phase 4: Production (Weeks 7-8)
13. **Containerize** — Docker with proper secrets management
14. **Add Redis** — For sessions, rate limiting, real-time features (typing indicators, etc.)
15. **WebSocket support** — For real-time chat and agent status updates (replace polling)
16. **Monitoring** — Structured logging, error tracking, performance monitoring

### Key Architecture Decisions
- **Keep the Gateway as the agent execution layer** — Don't embed agent logic in the dashboard
- **The dashboard is a thin client** — It manages UI state and routes requests to Gateway
- **All LLM calls should go through Gateway** (eventually) — For usage tracking, rate limiting, and model management
- **Chat direct-to-LLM is acceptable** for latency-sensitive chat — but tag it as "direct mode" for billing

---

*End of audit. This report should be treated as the authoritative source for all Mission Control remediation work.*
