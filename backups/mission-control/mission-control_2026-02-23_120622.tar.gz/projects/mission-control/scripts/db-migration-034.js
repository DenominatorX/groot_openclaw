/**
 * DB Migration: Add pm_id to projects table (T3)
 * 
 * This migration:
 * 1. Adds `pm_id` TEXT column to projects table (safe ALTER TABLE IF NOT EXISTS)
 * 2. Provides updated code snippets for sort-by-pm and pm_id on create
 * 
 * Run from mission-control: node ../mc-034/output/db-migration.js
 */

const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = process.env.MC_DB_PATH || path.join(process.cwd(), 'data', 'mission-control.db');

// ============== MIGRATION: Add pm_id column ==============
function runMigration(db) {
  console.log('Running migration: Adding pm_id column to projects table...');
  
  // Safe ALTER TABLE IF NOT EXISTS pattern
  // SQLite doesn't support IF NOT EXISTS for columns, so we check first
  const tableInfo = db.prepare("PRAGMA table_info(projects)").all();
  const hasPmId = tableInfo.some(col => col.name === 'pm_id');
  
  if (!hasPmId) {
    db.exec("ALTER TABLE projects ADD COLUMN pm_id TEXT");
    console.log('✓ Added pm_id column to projects table');
  } else {
    console.log('✓ pm_id column already exists, skipping');
  }
  
  // Create index for pm_id if it doesn't exist
  try {
    db.exec("CREATE INDEX IF NOT EXISTS idx_projects_pm_id ON projects(pm_id)");
    console.log('✓ Created index on pm_id');
  } catch (e) {
    console.log('✓ Index on pm_id already exists or skipped');
  }
}

// ============== Run migration ==============
const db = new Database(DB_PATH);

try {
  runMigration(db);
  console.log('');
  console.log('=== Migration complete! ===');
  console.log('');
  console.log('Next steps - update app/api/projects/route.ts:');
  console.log('1. In GET handler: Add sort=pm support (fetch all, sort by pm_id in memory)');
  console.log('2. In POST create: Add pm_id: body.pm_id || body.assignee || null');
  console.log('3. Optionally add pm_id to PATCH handler');
} catch (e) {
  console.error('Migration failed:', e);
  process.exit(1);
} finally {
  db.close();
}
