# Security Audit — Mission Control v3
**Date:** 2026-02-10 | **Auditor:** Groot | **Status:** IN PROGRESS

## 🔴 CRITICAL Vulnerabilities (Pre-Auth)

| # | Issue | Risk | Fix |
|---|-------|------|-----|
| 1 | **No authentication** — anyone can access all routes | CRITICAL | Add auth middleware + login page |
| 2 | **/api/settings** exposes all API keys in plaintext | CRITICAL | Require auth, mask keys in responses |
| 3 | **/api/govee** executes shell commands (govee.sh) | CRITICAL | Require auth, sanitize inputs |
| 4 | **/api/system** exposes hostname, CPU, memory, disk info | HIGH | Require auth |
| 5 | **/api/health** exposes personal health data | HIGH | Require auth |
| 6 | **/api/tasks** exposes personal task data | MEDIUM | Require auth |
| 7 | **/api/server/restart** can restart the server | CRITICAL | Require auth |
| 8 | No rate limiting on any endpoint | HIGH | Add rate limiter |
| 9 | No CSRF protection | MEDIUM | Add CSRF tokens |
| 10 | No Content-Security-Policy headers | MEDIUM | Add security headers |
| 11 | Settings API accepts arbitrary port values | LOW | Already validates 1024-65535 |

## 🟢 Security Plan

### Layer 1: Authentication (session-based)
- Login page with password
- Server-side session cookie (httpOnly, secure, sameSite=strict)
- All /api/* routes require valid session
- Password stored as bcrypt hash in data/auth.json (not plaintext)
- Brute-force protection: lockout after 5 failed attempts

### Layer 2: Security Headers
- Content-Security-Policy
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- Referrer-Policy: no-referrer
- Strict-Transport-Security (via Cloudflare)

### Layer 3: Rate Limiting
- 60 req/min per IP for general endpoints
- 5 req/min for login attempts
- 10 req/min for settings/server endpoints

### Layer 4: Input Validation
- Sanitize all shell command inputs (govee room names)
- Validate JSON payloads
- Prevent path traversal

### Layer 5: API Key Protection
- Keys stored encrypted at rest (AES-256)
- Only show masked keys in UI
- Full keys only returned when explicitly requested + auth'd
