# Spark
**ID:** spark | **Tier:** 4 (Sr. Manager)
**Role:** Junior Dev
**Title:** Junior Developer
**Department:** Development
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
