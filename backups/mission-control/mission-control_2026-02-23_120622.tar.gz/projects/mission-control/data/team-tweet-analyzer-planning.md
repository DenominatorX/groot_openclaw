# Team Meeting: Tweet Analyzer (X Intelligence Hub)
**Date:** 2026-02-13  
**Attendees:** CEO, The Interrogator, Forge, Pixel, Dirty Bird, Brain  
**Project:** X Intelligence Hub — Real-time Tweet Analysis Engine

---

## AGENDA

### Opening Remarks — CEO
**CEO:** "Kevin came to me with a vision. Every day, tweets are shaping markets, products, and tech trends. We see a tweet about a new startup, but we don't know the context—is this legit? Is it a scam? Does it fit our portfolio? Kevin wants a single tool: paste a tweet, get back a full intelligence report. Market context, team assessment, viability, legal flags, everything. This is our next killer feature for Mission Control."

**CEO:** "The xAI API just dropped Responses with `x_search` and `web_search`. Perfect fit. We have the Grok API key already configured. Let's ship this in 48 hours."

---

### Technical Overview — The Interrogator (xAI Specialist)

**The Interrogator:** "I've reviewed the xAI Responses API spec. Here's what we're dealing with:

**Endpoint:** `https://api.x.ai/v1/responses`  
**Model:** `grok-3` (we have it in our gateway config)  
**Auth:** Bearer token in Authorization header

**Request Structure (key difference from OpenAI):**
```json
{
  "model": "grok-3",
  "input": [{"role": "user", "content": "Your prompt"}],
  "tools": [
    {"type": "x_search"},
    {"type": "web_search"}
  ]
}
```

Note: It's `input`, not `messages`. Tools are server-side declarations.

**Response:**
```json
{
  "output": [{"type": "text", "content": "Grok's analysis..."}],
  "citations": [...]
}
```

**Tools Behavior:**
- `x_search`: Real-time X (Twitter) search via Grok
- `web_search`: General web search
- Grok calls them automatically based on the prompt context
- No need to call them separately

**My Recommendation:** 
- For a tweet analysis, ask Grok to: 1) Extract tweet content + author, 2) Research what's being discussed, 3) Business/legal/technical assessment, 4) How it relates to our portfolio (AI agents, health tech, marketing automation)
- Let Grok decide when to use x_search (for author/context) and web_search (for companies/products mentioned)
"

**Forge:** "Wait, so Grok handles tool invocation internally?"

**The Interrogator:** "Exactly. We send `"tools": [...]`, Grok sees them, and if it needs to search, it does. We get the full response with results baked in."

---

### Backend Architecture — Forge

**Forge:** "Alright, so here's the backend plan:

**API Route:** `POST /api/apps/tweet-analyzer`

**Input:**
```json
{
  "url": "https://twitter.com/kevin/.../...",
  "text": "optional raw tweet text"
}
```

**Flow:**
1. Parse URL or use raw text
2. Build the xAI request payload
3. Read API key from:
   - `settings.xaiApiKey` (new field if needed)
   - `settings.apiKeys.xai` (fallback)
   - `process.env.XAI_API_KEY` (gateway config)
4. POST to xAI endpoint
5. Parse response, extract output + citations
6. Augment with engagement metrics (if possible from tweet URL)
7. **Storage:** Save analysis to `data/apps/tweet-analyzer/analyses.json`
8. Return the full analysis object

**GET Endpoint:** `/api/apps/tweet-analyzer` returns past analyses.

**Error Handling:**
- Bad URL? Return 400
- xAI API down? Return 503 with retry info
- Rate limit hit? Log it, return 429
- Parse errors? Return 400 with details

**Security Note:** I'll validate URLs to avoid injection, rate-limit per user (if auth available)."

**Dirty Bird:** "Hold up—rate limiting. If we hit xAI's rate limits, do we have fallback?"

**Forge:** "Good catch. We log when we hit it, inform the user, suggest trying again in N minutes. No fallback for now—we're dependent on xAI. This is a business risk."

---

### Frontend & UX — Pixel

**Pixel:** "UI is three sections:

**1. Input Panel:**
- Large URL input field, placeholder: `"Paste tweet URL..."`
- OR toggle to paste raw tweet text
- Blue/cyan "🔍 Analyze Tweet" button (#06b6d4)
- Recent analyses sidebar (last 5)

**2. Results Dashboard (post-analysis):**

**Tweet Card:**
- Embed-style display: avatar, author name, @handle, timestamp
- Tweet text, engagement metrics (❤️ 234K, 🔄 45K, 💬 2.1K)
- Link back to original tweet

**Author Profile Card:**
- Small profile: avatar, follower count, bio, joined date
- Verify badge if available

**Deep Research Section:**
- Title: What's This About?
- Paragraph: What product/company/tech is being discussed
- External links/context
- 2-3 key facts extracted by Grok

**Team Assessment Cards (4 columns):**
- Each team member has a card with their emoji and assessment
- 💼 **CEO**: Business viability (0-100), market fit, scalability potential, action
- ⚖️ **Dirty Bird**: Legal flags, IP concerns, compliance notes
- 🔧 **Forge**: Technical feasibility (0-100), implementation effort, tech stack fit
- 🧠 **Brain**: Relevance to our projects (0-100), pattern matches, recommendation

**Implementation Report:**
- "Can We Build This?" section
- Estimated effort (hours), cost, timeline
- Go/No-Go recommendation

**Compatibility Score:**
- Big metric: 0-100, how well does this fit our stack?
- Breakdown: tech (30pts), team expertise (30pts), market need (25pts), resources (15pts)

**Action Items:**
- Bulleted list of next steps
- Assignee, due date if applicable

**3. History Panel:**
- Searchable table: Date, Author, Tweet preview, Score
- Click to re-display analysis
- Delete option

**Style:**
- Dark theme (dark-slate background)
- Cyan accents for intelligence/research vibe
- Card-based layout
- Tweet cards styled like actual embedded tweets
- Agent assessment cards with subtle emoji watermark"

**CEO:** "Love it. The Compatibility Score is key—Kevin will use that to fast-track decisions."

---

### Security & Compliance — Dirty Bird

**Dirty Bird:** "Several concerns I need addressed:

**1. API Key Management:**
- We're storing xAI key in `settings.json` AND in the gateway config?
- Risk: If settings.json leaks, we're exposed
- **Recommendation:** Primary source should be `process.env.XAI_API_KEY` from gateway (managed centrally)
- Fallback to settings.json only if env var not available
- **Action:** Update route to check env first, then settings

**2. Data Privacy:**
- We're analyzing tweets (public data), but storing analyses locally
- **Question:** Do we need user consent? These are Twitter data.
- **Answer:** Public tweets don't require consent per Twitter TOS, but we should disclose that we're storing the analysis
- **Recommendation:** Add a privacy notice in the UI: "Analyses are stored locally for history. No data shared externally."

**3. Rate Limiting:**
- xAI has rate limits (plan details?)
- If user hammers 100 tweets/minute, we'll hit limits and block
- **Recommendation:** Implement per-session rate limit (e.g., 10/min) with user-facing feedback
- Log rate limit events for monitoring

**4. URL Validation:**
- Malicious tweet URLs could cause issues
- **Recommendation:** Validate URL format (https://twitter.com/...) or require raw text
- Regex: `^https:\/\/(twitter\.com|x\.com)\/[a-zA-Z0-9_]+\/status\/\d+`

**5. Response Handling:**
- Grok's response includes citations. Are those URLs safe?
- **Recommendation:** Sanitize citation URLs, display them in `<a>` with `rel='noopener noreferrer'`

**6. Error Messages:**
- Don't expose API key in error logs
- Sanitize stack traces sent to client
- **Recommendation:** Use generic error messages for users, detailed logs server-side

**My Sign-Off:**
- Proceeding under assumption: tweets are public data, storage is local, no external sharing
- If Kevin plans to share analyses externally (email, publish), we need a different compliance review
"

**Forge:** "Got it. I'll implement env-first API key loading and URL validation. Will add rate limit middleware."

---

### Intelligence Mapping — Brain

**Brain:** "I've cross-referenced this with our existing systems:

**1. Relationship to Existing Projects:**
- **PrePrompt App:** This is like PrePrompt's orchestration + research module
- **MaxTarget Marketing Suite:** We could use Tweet Analyzer insights to populate MaxTarget campaigns
- **Brain Dump + Intelligence:** This is a data point for Kevin's decision-making—feeds into mood/mood-based recommendations
- **Podcast Hub:** Could analyze podcast-adjacent tweets for research

**2. Opportunity for Pattern Matching:**
- When Kevin analyzes a tweet about "AI agent healthcare," Brain can flag: "Related to health-tech exploration we noted in [date] dump"
- Could integrate with our agent portfolio tracking

**3. Data Storage & Retrieval:**
- Store analyses in `data/apps/tweet-analyzer/analyses.json`
- Include metadata: timestamp, grok-response-time, token-count (if available), mood-at-time (from Brain Dump)
- Future: Feed this into Brain's intelligence layer for cross-project insights

**4. Recommendations:**
- Tag each analysis with relevant domains (AI, marketing, health, productivity, etc.)
- Allow Brain to suggest related past tweets when Kevin analyzes new ones
- Export analyses to Brain Dump for reflection

**Example Integration:**
```
Kevin analyzes tweet → TweetAnalyzer report generated
→ Brain flags: "Relates to health-tech pattern we saw in Feb dumps"
→ Kevin asks Brain for all related analyses → gets cross-project insights
```

**Long-term:** This becomes part of Kevin's personal intelligence layer.
"

**CEO:** "Brilliant. Let's ship a v1 with just the core feature, but build it with Brain integration in mind from the start."

---

## DECISIONS

**Approved:**
1. ✅ Single API endpoint: POST/GET `/api/apps/tweet-analyzer`
2. ✅ xAI Responses API with `x_search` + `web_search` tools, `grok-3` model
3. ✅ Dark theme, cyan accents, 4-team assessment cards
4. ✅ Compatibility Score (0-100) as primary decision metric
5. ✅ Local storage in `data/apps/tweet-analyzer/analyses.json`
6. ✅ URL validation + rate limiting + sanitized responses
7. ✅ API key: env var first, then settings.json fallback
8. ✅ History searchable table with delete capability

**Timeline:**
- **Phase 1 (STEP 1-3):** Planning, PRD, Design Doc — 2 hours
- **Phase 2 (STEP 4):** Component + API route build — 4 hours
- **Phase 3 (STEP 5-6):** Kanban, test plan — 1 hour
- **Phase 4 (STEP 7-8):** Testing + build verification — 2 hours
- **Target:** Complete by EOD Feb 13

**Owner:** Forge (backend), Pixel (frontend), The Interrogator (API integration review)

---

## OPEN QUESTIONS

1. **Engagement Metrics:** Can we fetch tweet engagement (likes, retweets) from tweet URL alone, or do we need Twitter API access?
   - **Answer (The Interrogator):** Grok might extract them if tweet is public, but not guaranteed. We'll display what Grok finds, fallback to "Public tweet data"

2. **Tweet Author Verification:** How do we verify the author is who they claim?
   - **Answer:** We display what's on the tweet. If Grok's web_search finds contradictions, we note them.

3. **Should We Cache Analyses?**
   - **Answer (Forge):** v1 doesn't dedupe. If Kevin analyzes same tweet twice, we store both. Future optimization.

---

## FINAL NOTES

**CEO:** "This is it. The Tweet Analyzer is our gateway into AI-powered intelligence synthesis. Kevin gets instant deep dives on anything moving the needle. Let's build it right, secure it tight, and ship it tomorrow morning."

**All:** 🚀
