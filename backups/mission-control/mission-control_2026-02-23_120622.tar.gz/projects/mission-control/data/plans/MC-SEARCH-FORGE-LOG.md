# MC-SEARCH-FORGE-LOG.md

## Global Search API - Forge Task Log

**Date:** 2026-02-18
**Agent:** Forge (Backend Engineer)
**Task:** Build Global Search API for Mission Control v3

---

### Database Schema Analysis

Ran schema inspection on `mission-control.db`:

**Tables found:**
- `projects` - id (TEXT), data (JSON), created_at, updated_at, user_id
- `tasks` - id (TEXT), project_id (TEXT), data (JSON), created_at, updated_at
- `issues` - id (TEXT), data (JSON), created_at, updated_at, user_id
- `agents` - id (TEXT), data (JSON), updated_at, user_id
- `messages` - id (INTEGER), session_id, role, content, timestamp
- `user_chat_history` - id (INTEGER), user_id, agent_id, session_key, message, response, created_at
- `activity_log` - id (INTEGER), type, agent_id, description, metadata (JSON), created_at
- `sessions` - for chat search

**No `reports` table found** - will use `data/reports.json` file instead.

---

### Implementation Details

Created: `/Users/groot/.openclaw/workspace/projects/mission-control/app/api/search/route.ts`

**Search Targets Implemented:**
1. ✅ **projects** - searches JSON data field for title, description
2. ✅ **tasks** - searches JSON data field, includes project_id in URL
3. ✅ **issues** - searches JSON data field
4. ✅ **agents** - searches agents table, falls back to data/agents.json
5. ✅ **reports** - searches data/reports.json (file-based, no DB table)
6. ✅ **activity** - searches activity_log.description
7. ✅ **features** - searches data/features.json (file-based)
8. ✅ **chat** - searches both messages and user_chat_history tables

**Search Logic:**
- Case-insensitive LIKE search: `WHERE LOWER(data) LIKE LOWER('%query%')`
- Relevance scoring: exact title match (1.0) > title contains > description > content
- Highlight extraction: 100-char snippet around match position

**URL Mapping:**
- project → `/projects/[id]`
- task → `/tasks?id=[id]`
- issue → `/issues/[id]`
- agent → `/agents/[id]`
- report → `/reports/[id]`
- feature → `/features?highlight=[pageId]`
- activity → `/activity`
- chat → `/chat/[sessionKey]`

**API Parameters:**
- `q` or `query` - search term (min 2 chars)
- `types` - comma-separated list (default: all)
- `limit` - results per type (default 5, max 20)

**Auth:** Uses `checkAuth()` from @/lib/api-auth

**Performance Note:** Added comment noting frontend should debounce to 300ms

---

### Response Format

```json
{
  "query": "discord",
  "total": 12,
  "results": [
    {
      "type": "project",
      "id": "MC-031",
      "title": "Mission Control Enhancement Suite",
      "subtitle": "Major cleanup...",
      "url": "/projects/MC-031",
      "relevance": 0.95,
      "highlight": "...Discord Session Manager panel..."
    }
  ],
  "byType": {
    "project": 2,
    "task": 5,
    "feature": 3,
    "agent": 2
  }
}
```

---

### Testing

To test the API:
```bash
curl "http://localhost:3000/api/search?q=discord&types=projects,tasks&limit=10"
```

---

### Files Created/Modified

- **Created:** `/Users/groot/.openclaw/workspace/projects/mission-control/app/api/search/route.ts`
- **Created:** `/Users/groot/.openclaw/workspace/projects/mission-control/data/plans/MC-SEARCH-FORGE-LOG.md` (this file)

---

### Notes

- Used same patterns as existing API routes (checkAuth, getDb)
- Falls back to JSON files when DB tables don't exist (reports, features, agents JSON)
- Results sorted by relevance score (0-1)
- Total results capped at `limit` param (default 20)
- Per-type limit is configurable (default 5)