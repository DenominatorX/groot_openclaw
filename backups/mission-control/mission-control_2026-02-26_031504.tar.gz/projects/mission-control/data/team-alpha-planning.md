# Team Alpha — Project Planning Session

**Date:** 2026-02-13 04:20 AM EST  
**Duration:** 47 minutes  
**Attendees:** Nova (ideation), CEO (project manager), Pixel (frontend), Spark (junior dev)  
**Status:** ✅ Approved for development sprint

---

## 🎯 Ideation Phase — Nova Pitches

**Nova:** "Team, I've been analyzing market gaps in Mission Control v3. Two concepts with strong revenue potential and user retention hooks:

**Concept 1 — Stock Market Tycoon**
A financial strategy game. Players start with $100K virtual cash, buy/sell stocks from fictional companies. Every day (player click), an AI-generated market event shifts prices. It's addictive — think Zynga meets Wall Street.

Revenue angle: Free-to-play base game, cosmetic skins ($2-5), premium battle pass with leaderboard entries ($4.99/mo), and eventually **multiplayer competitive trading** with entry fees (10-30% house take).

Barrier to entry is LOW — anyone interested in finance, investing, or just gambling simulation. Retention is SOLID because markets are unpredictable. And crypto/DeFi audiences are hungry for this.

**Concept 2 — Invoice & Client Manager**
A SaaS app for freelancers and agencies. Problem: most freelancers still use spreadsheets or Stripe invoicing. We build a sleek, integrated invoice builder with AI-generated professional templates, automatic recurring invoices, late payment reminders (AI escalates: polite → firm), and a client directory.

Revenue: $9.99/mo subscription. Lower ceiling than the game, but predictable MRR (monthly recurring revenue). Market is HUGE — 70M+ freelancers globally. Churn will be low because invoicing is essential.

Both tap different user segments: gamers vs. professionals. Both have network effects or addictive loops. Both integrate seamlessly into MC as a 'Games' tab and 'Apps' tab."

---

## 💭 Review Phase — CEO Asks Hard Questions

**CEO:** "Good thinking, Nova. I like the divergent segments. Before we commit, let me ask:

**On Stock Tycoon:**
- Scope: How many companies in the initial roster? How complex is the AI event generation?
- Technical debt: Do we build multiplayer from day one, or add it post-launch?
- Competition: Robinhood, eToro, Webull all offer real trading. What's our hook?

**On Invoice App:**
- MVP feature set: What's truly table-stakes vs. nice-to-have?
- Monetization: Is $9.99 price anchored to competitors like FreshBooks, Wave, Square?
- Integration: Payment processing (Stripe, PayPal) or just tracking?

**Operational:**
- Dev timeline: How many sprints to MVP for each?
- Resource allocation: Team Alpha only, or do we pull in backend support?
- Data storage: SQLite for MVP, or Postgres from day one?

**Nova:** "Solid. Let me clarify:

**Stock Tycoon:**
- 20 companies, realistic sectors (tech, health, energy, finance, retail). Pre-seeded in JSON.
- AI events: Haiku generates a short news blurb each turn. Simple + fast.
- Multiplayer: Post-launch. MVP is single-player with leaderboard (tracks best runs locally).
- Hook: It's not about *accuracy* — it's about *fun decisions under uncertainty*. Game loops, achievements (First Trade, Double Your Money, Diamond Hands), difficulty modes (Bull/Bear/Chaos).

**Invoice App:**
- MVP: Clients directory, invoice builder with line items, status tracking, payment date logging, export to PDF-ish text. NO payment processing initially.
- Pricing: $9.99 is standard for indie SaaS. Undercut Wave's free tier slightly with better UX.
- Data: SQLite for MVP (simple, no DevOps). Migrate to Postgres if we hit 10K users.
- Timeline: Stock Tycoon ~4 days (frontend + API), Invoice ~5-6 days (more complex forms + data relationships).

**CEO:** "Alright. I'm structuring the project scope. Pixel, you're lead frontend — both components. Spark, you're APIs and data schemas. I'll manage scope and deadlines.

Timeline:
- **Day 1 (today)**: Spike & architecture planning
- **Day 2-3**: Stock Tycoon MVP (game loop, AI events, basic UI)
- **Day 4**: Stock Tycoon polish + leaderboard
- **Day 5-6**: Invoice App MVP (forms, calc, storage)
- **Day 7**: Integration into MC, QA, launch"

---

## 🔧 Technical Planning — Pixel + Spark

**Pixel:** "Okay, here's the component structure I'm proposing:

**Stock Tycoon Game:**
- `StockTycoonGame.tsx` (main container)
- `Portfolio.tsx` (holdings + dashboard)
- `Market.tsx` (stock list, buy/sell interface)
- `PriceChart.tsx` (30-day history, CSS line chart)
- `NewsEvent.tsx` (display AI-generated market event)
- `Leaderboard.tsx` (high scores local storage)
- `Achievements.tsx` (badges earned this session)

**Invoice App:**
- `InvoiceApp.tsx` (main router)
- `ClientDirectory.tsx` (CRUD clients)
- `InvoiceBuilder.tsx` (form-heavy, line items, auto-calc)
- `InvoiceHistory.tsx` (list, filter, search)
- `Dashboard.tsx` (KPI cards: revenue, outstanding, overdue)
- `InvoicePreview.tsx` (read-only, print-friendly)

Dark theme for both. Game: green/red accent colors (Wall Street vibe). App: blue (#3b82f6) for professional feel.

**Spark:** "APIs I'll build:

Stock Tycoon:
- `POST /api/games/stock-tycoon/event` — Haiku generates market event, returns price deltas
- `POST /api/games/stock-tycoon/save` — Save game state (portfolio, prices, day #)
- `GET /api/games/stock-tycoon/save/:id` — Load saved game
- `GET /api/games/stock-tycoon/leaderboard` — Top 10 runs

Invoice App:
- `POST /api/apps/invoice/clients` — Add client
- `GET /api/apps/invoice/clients` — List all clients
- `PUT /api/apps/invoice/clients/:id` — Edit client
- `DELETE /api/apps/invoice/clients/:id` — Delete client
- `POST /api/apps/invoice/invoices` — Create invoice
- `GET /api/apps/invoice/invoices` — List invoices (with filters)
- `PUT /api/apps/invoice/invoices/:id` — Update status/payment date
- `POST /api/apps/invoice/ai/format` — AI formats invoice template from line items

Data schemas:
- `data/games/stock-tycoon/companies.json` — Pre-seeded 20 companies
- `data/games/stock-tycoon/saves.json` — Active games
- `data/games/stock-tycoon/leaderboard.json` — Top scores
- `data/apps/invoice/clients.json` — Client directory
- `data/apps/invoice/invoices.json` — All invoices

**Pixel:** "Clean. I'll use Tailwind for styling, manage state with React hooks (or Zustand if we go multiplayer later). Spark, can you have the client/invoice schemas ready by EOD?"

**Spark:** "Yeah, data is lightweight. Done by 10am."

**CEO:** "Excellent. One more thing — both need to integrate into the main MC tabs. I'll update `GamesTab.tsx` to include Stock Tycoon (💰 icon), and `AppsTab.tsx` for Invoice (🧾 icon). Both get added to `data/projects.json` with status 'in-progress', creator 'Team Alpha'."

---

## 📋 Final Plan & Assignments

| Component | Owner | Start | Est. Completion | Status |
|-----------|-------|-------|-----------------|--------|
| Stock Tycoon Game | Pixel + Spark | Today | Day 4 | In Progress |
| Invoice App | Pixel + Spark | Day 2 | Day 6 | In Progress |
| API Routes (all) | Spark | Today | Day 2 | In Progress |
| Data Schemas | Spark | Today | Day 1 | In Progress |
| MC Tab Integration | CEO | Day 1 | Day 7 | Pending |
| QA + Deployment | CEO + Team | Day 7 | Day 7 | Pending |

**Key Dependencies:**
- Spark finishes data schemas → Pixel can stub components
- Spark finishes APIs → Pixel can wire UI
- Both components ready → CEO integrates into tabs
- All features tested → Merged into main MC

**Risk Mitigation:**
- If Haiku API is slow: Pre-cache event templates
- If forms are complex: Spark helps Pixel with React form libraries
- If time-constrained: Cut Leaderboard/Achievements post-launch, keep core loops

**Success Criteria:**
- Stock Tycoon: Game loop working, 3+ difficulty modes, leaderboard functional
- Invoice App: CRUD clients, create/export invoices, dashboard KPIs
- Both: Zero errors on launch, <2s API response, dark theme consistent

---

## 🎬 Next Steps

1. **Spark**: Build data schemas & seed companies.json (today, 10am)
2. **Pixel**: Set up component structure, stub routes (today, 2pm)
3. **Spark**: Complete API routes (tomorrow, end of day)
4. **Pixel + Spark**: Feature development (Days 2-6)
5. **CEO**: Daily standup, scope management, integration (ongoing)
6. **All**: QA & polish (Day 7)

**Launch Target:** 2026-02-20 (7 days)

---

**Approved by:** CEO  
**Budget:** Team Alpha dev resources (no external spend)  
**Confidence Level:** 🟢 HIGH — low technical risk, clear scope, strong market fit
