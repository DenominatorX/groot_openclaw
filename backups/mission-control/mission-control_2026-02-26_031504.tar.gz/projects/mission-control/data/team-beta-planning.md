# Team Beta — Mission Control v3 Planning Chat
**Date**: 2026-02-13 | **Sprint**: Q1 2026 | **Attendees**: Cipher, Groot, Forge, Worker B

---

## Opening: Cipher's Pitch

**Cipher (10:05 AM):**
> "Alright team, I've been thinking about what Mission Control v3 really needs — not just dashboards, but *experiences*. Two angles:
> 
> **First:** What if we built an AI-powered RPG game right into MC? *AI Dungeon Master*. A text adventure where the AI generates the entire story, your choices matter, and you progress through campaigns. Think *choose-your-own-adventure* meets *procedural narrative*. Users create characters, fight monsters, collect loot. It's engagement gold.
> 
> **Second:** For the startup/business side — *Pitch Deck Builder*. An AI that takes a 2-sentence company description and builds an entire pitch deck. Slides for problem, solution, market, team, financials — all auto-generated with professional copy. Investors love data; founders hate PowerPoint. We fix that."

---

## Groot's Refinement

**Groot (10:18 AM):**
> "Cipher, I like the directional thinking. Let me pressure-test:
> 
> **On Dungeon Master:** The AI generation cost is high (Haiku calls per turn). How do we handle save/load? Storage? Do we support multiplayer later?
> 
> **On Pitch Deck:** I get the value, but this needs to be *legally defensible* — VCs trust specific structures (Series A, Seed templates). We should pre-seed templates, not let AI hallucinate deck order.
> 
> Counter-proposal: Let's scope these as **MVP → Premium path**.
> - Dungeon: Basic game loop in Phase 1, co-op in Phase 2, custom world building as paid add-on.
> - Pitch Deck: Templates + AI content generation for Phase 1, investor research/practice mode in Phase 2.
> 
> This gives us revenue hooks ($4.99 per campaign for dungeons, $14.99/mo for decks) without overcomplicating v3."

**Cipher (10:22 AM):**
> "Solid pushback. I like the premium model. Saves us from feature creep and makes it monetizable from day one."

---

## Forge's Architecture

**Forge (10:35 AM):**
> "Let me map the tech:
>
> **AI Dungeon Master:**
> - Component: `components/games/AIDungeonGame.tsx` (React state for character, inventory, health, scene, history)
> - API: `app/api/games/dungeon/route.ts` — POST for Haiku story gen, combat logic, choice generation; GET/POST for saves
> - Data: `data/games/dungeon/saves.json` (per-user save slots), `achievements.json` (global leaderboard seed)
> - Storage: JSON initially, migrate to DB if multiplayer needed
> - UI: Dark parchment theme, amber/gold accents, scrollwork borders (theming by campaign: Fantasy/Sci-Fi/Horror/Pirate/Apocalypse)
> 
> **Pitch Deck Builder:**
> - Component: `components/apps/PitchDeckApp.tsx` (step-by-step wizard, slide preview, export)
> - API: `app/api/apps/pitch-deck/route.ts` — CRUD decks, Haiku for content generation, template validation
> - Data: `data/apps/pitch-deck/decks.json` (user decks), `templates.json` (pre-seeded: Seed, Series A, B2B SaaS, Marketplace, Hardware, Biotech)
> - Export: Copy as markdown, print-to-PDF (browser native)
> - Practice Mode: Simple turn-taking (user answer → AI investor question)
>
> Both use the same `claude-haiku-4-5-20250414` API key from `data/settings.json`.
> 
> Question for Groot: Do we need auth/user isolation on saves, or is this demo-grade (localStorage + JSON)?"

**Groot (10:42 AM):**
> "For v3 launch, localStorage + JSON is fine. If we hit scale, we add Supabase. Let's not pre-optimize."

---

## Worker B's Data & Boilerplate

**Worker B (10:50 AM):**
> "I've outlined the data structures:
>
> **Dungeon Saves (`saves.json`):**
> ```json
> {
>   "save-slot-1": {
>     "id": "save-slot-1",
>     "character": {"name": "Aragorn", "class": "Warrior", "traits": ["brave", "wise"], "level": 3, "xp": 250},
>     "inventory": [{"id": "sword-01", "name": "Iron Sword", "type": "weapon"}, ...],
>     "health": 85,
>     "mana": 40,
>     "scene": {...current scene description...},
>     "history": [... array of past scenes ...],
>     "timestamp": "2026-02-13T14:30:00Z",
>     "campaign": "fantasy",
>     "playTime": 3600
>   }
> }
> ```
>
> **Pitch Decks (`decks.json`):**
> ```json
> {
>   "deck-001": {
>     "id": "deck-001",
>     "name": "My Cool Startup Pitch",
>     "template": "seed-stage",
>     "slides": [
>       {"slideNumber": 1, "type": "title", "content": {...}},
>       {"slideNumber": 2, "type": "problem", "content": {...}},
>       ...
>     ],
>     "createdAt": "2026-02-13T10:00:00Z",
>     "updatedAt": "2026-02-13T10:00:00Z"
>   }
> }
> ```
>
> **Templates (`templates.json`):**
> Pre-seeded with 6 templates (Seed, Series A, B2B SaaS, Marketplace, Hardware, Biotech) — each specifies slide order & validation rules.
>
> I'll handle the boilerplate files and data structure validation."

---

## Key Decisions & Compromises

| Topic | Cipher's Take | Groot's Take | **Resolution** |
|-------|---------------|--------------|----------------|
| **Multiplayer for Dungeon** | Phase 1 nice-to-have | Too complex for v3 | Save architecture for Phase 2, mark in code |
| **Pitch Deck AI Safety** | Full auto-generation | Requires templates | Hybrid: templates define structure, AI fills content |
| **Save Storage** | Cloud database | Overkill for launch | JSON + localStorage, DB migration ready |
| **Campaign Themes** | 10+ themes | Keep it simple | Agree on 5 core themes: Fantasy, Sci-Fi, Horror, Apocalypse, Pirate |
| **Monetization Entry** | Free game, paid campaigns | Both premium | $4.99/campaign for Dungeon, $14.99/mo for Pitch (investor features) |

---

## Deliverables Checklist

- [ ] **Cipher**: Finalize narrative prompts for Haiku (story seeds, choice generation logic)
- [x] **Groot**: Architecture doc (implicit above)
- [ ] **Forge**: Build AIDungeonGame.tsx and PitchDeckApp.tsx
- [ ] **Forge**: Build API routes for both
- [x] **Worker B**: Pre-seed data structures (saves.json, templates.json)
- [ ] **Team**: Wire components into GamesTab.tsx and AppsTab.tsx
- [ ] **Team**: Update projects.json with new project entries
- [ ] **Groot**: Verify build and test happy path

---

## Timeline
- **Today (Feb 13)**: Complete component builds, data setup
- **Tomorrow (Feb 14)**: Integration & wiring into MC, QA
- **Fri (Feb 15)**: Deploy to staging, investor demo ready

---

## Notes
- **Haiku quota**: Budget ~5-10 calls per game session (story, choices, combat outcomes). Plan for $0.10-0.20 per session.
- **Pitch Deck exports**: Keep markdown format for now; PDF export in Phase 2.
- **Achievement system**: Start with 5 core achievements per game (First Kill, Level 10, Dragon Slayer, Pacifist Run, Speed Run). Expand based on user engagement.
- **Color schemes**: Use CSS variables for theme switching. Each campaign theme changes primary colors (Fantasy=amber/gold, Sci-Fi=cyan/purple, Horror=red/black, etc.).

---

**Status**: ✅ **Approved for Build**  
**Next**: Forge starts coding AIDungeonGame.tsx and PitchDeckApp.tsx
