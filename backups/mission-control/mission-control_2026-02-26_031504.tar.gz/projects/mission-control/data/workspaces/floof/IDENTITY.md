# Floof
**ID:** floof | **Tier:** 3 (Director)
**Role:** Game Dev & Creative Lead
**Title:** Video Game Creator
**Department:** Development
**Model:** xai/grok-4
**Status:** active
**Created:** 2026-02-16
