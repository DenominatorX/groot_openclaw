# The Architect
**ID:** architect | **Tier:** 1 (Executive Board)
**Role:** System Architect
**Title:** Architecture & Integration Specialist
**Department:** Engineering
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
