# Runner
**ID:** runner | **Tier:** 5 (Manager)
**Role:** Task Runner
**Title:** Task Runner
**Department:** Operations
**Model:** ollama/llama3.1:8b
**Status:** active
**Created:** 2026-02-16
