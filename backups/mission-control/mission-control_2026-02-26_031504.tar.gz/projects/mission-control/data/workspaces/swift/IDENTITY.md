# Swift
**ID:** swift | **Tier:** 2 (VP)
**Role:** VP Operations
**Title:** VP Operations
**Department:** Operations
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
