# Nova
**ID:** nova | **Tier:** 3 (Director)
**Role:** Senior Dev
**Title:** Senior Developer
**Department:** Development
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
