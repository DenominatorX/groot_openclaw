# Tank
**ID:** tank | **Tier:** 5 (Manager)
**Role:** Manager
**Title:** Operations Manager
**Department:** Operations
**Model:** lmstudio/gemma-3-4b
**Status:** active
**Created:** 2026-02-16
