# The Interrogator
**ID:** interrogator | **Tier:** 3 (Director)
**Role:** Memory Extraction Specialist
**Title:** Deep Memory Analyst
**Department:** Memory
**Model:** xai/grok-4
**Status:** active
**Created:** 2026-02-16
