# Cipher
**ID:** cipher | **Tier:** 4 (Sr. Manager)
**Role:** Analyst
**Title:** Lead Analyst
**Department:** Research
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
