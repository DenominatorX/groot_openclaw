# Jimmy T — Memory Log
> Long-term memory for Jimmy T. Append important decisions, context, and learnings here.

## MC-031 Update (2026-02-18)
Mission Control Enhancement Suite is now live. New features available:
- Discord Session Manager panel on home page (compact/reset/change-model per channel)
- Enhanced Context Health with filters, bulk actions, inline model switching
- Cron Manager in Settings — create and manage cron jobs from MC UI
- Sub-agent Activity Feed on home page (real-time, auto-refreshing)
- Model Settings page with editable context windows per model
- Activity feed logs all session actions
- "sonnet" alias = anthropic/claude-sonnet-4-6 (confirmed)
- Config Broadcaster and Tier Restructure Helper planned for next sprint
