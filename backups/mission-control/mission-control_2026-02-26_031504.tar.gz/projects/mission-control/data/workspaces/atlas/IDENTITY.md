# Atlas
**ID:** atlas | **Tier:** 4 (Sr. Manager)
**Role:** 3D Asset Specialist
**Title:** 3D Asset Engineer
**Department:** Development
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
