// VCB Database Layer - mirrors lib/database.ts pattern
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const VCB_DB_PATH = process.env.VCB_DB_PATH || path.join(process.cwd(), 'data', 'vcb.db');

// Ensure data dir exists
fs.mkdirSync(path.dirname(VCB_DB_PATH), { recursive: true });

let _vcbDb: Database.Database | null = null;

export function getVcbDb(): Database.Database {
  if (!_vcbDb) {
    _vcbDb = new Database(VCB_DB_PATH);
    _vcbDb.pragma('journal_mode = WAL');
    _vcbDb.pragma('foreign_keys = ON');
    initVcbSchema(_vcbDb);
  }
  return _vcbDb;
}

export function closeVcbDb(): void {
  if (_vcbDb) {
    _vcbDb.close();
    _vcbDb = null;
  }
}

function initVcbSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS branches (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      parent_id TEXT REFERENCES branches(id),
      status TEXT DEFAULT 'active' CHECK(status IN ('active', 'merged', 'archived', 'stale')),
      description TEXT,
      color TEXT DEFAULT '#6366f1',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_branches_parent ON branches(parent_id);
    CREATE INDEX IF NOT EXISTS idx_branches_status ON branches(status);

    CREATE TABLE IF NOT EXISTS commits (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL REFERENCES branches(id),
      message TEXT NOT NULL,
      author TEXT NOT NULL DEFAULT 'Kevin',
      hash TEXT UNIQUE,
      parent_commit_id TEXT REFERENCES commits(id),
      metadata JSON DEFAULT '{}',
      timestamp TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_commits_branch ON commits(branch_id);
    CREATE INDEX IF NOT EXISTS idx_commits_timestamp ON commits(timestamp);

    CREATE TABLE IF NOT EXISTS files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      commit_id TEXT NOT NULL REFERENCES commits(id),
      path TEXT NOT NULL,
      action TEXT CHECK(action IN ('added', 'modified', 'deleted', 'renamed')),
      diff TEXT,
      content_snapshot TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_files_commit ON files(commit_id);

    CREATE TABLE IF NOT EXISTS snapshots (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL REFERENCES branches(id),
      commit_id TEXT REFERENCES commits(id),
      label TEXT NOT NULL,
      description TEXT,
      data JSON DEFAULT '{}',
      timestamp TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_snapshots_branch ON snapshots(branch_id);
    CREATE INDEX IF NOT EXISTS idx_snapshots_timestamp ON snapshots(timestamp);
  `);

  // Seed data: insert main branch if no branches exist
  const existingBranches = db.prepare('SELECT COUNT(*) as count FROM branches').get() as { count: number };
  if (existingBranches.count === 0) {
    db.prepare('INSERT OR IGNORE INTO branches (id, name, status, description) VALUES (?, ?, ?, ?)').run('main', 'main', 'active', 'Primary branch');
  }
}

// ==================== TypeScript Interfaces ====================

export interface Branch {
  id: string;
  name: string;
  parent_id: string | null;
  status: 'active' | 'merged' | 'archived' | 'stale';
  description: string | null;
  color: string;
  created_at: string;
  updated_at: string;
  last_commit_id?: string;
  last_commit_message?: string;
  last_commit_author?: string;
  last_commit_at?: string;
  commit_count?: number;
  snapshot_count?: number;
}

export interface Commit {
  id: string;
  branch_id: string;
  message: string;
  author: string;
  hash: string | null;
  parent_commit_id: string | null;
  metadata: Record<string, unknown>;
  timestamp: string;
  branch_name?: string;
  branch_color?: string;
  file_count?: number;
}

export interface Snapshot {
  id: string;
  branch_id: string;
  commit_id: string | null;
  label: string;
  description: string | null;
  data: Record<string, unknown>;
  timestamp: string;
  branch_name?: string;
  branch_color?: string;
}

export interface VcbFile {
  id: number;
  commit_id: string;
  path: string;
  action: 'added' | 'modified' | 'deleted' | 'renamed';
  diff: string | null;
  content_snapshot: string | null;
}

export interface CalendarDay {
  commits: Commit[];
  snapshots: Snapshot[];
}

export interface CalendarResponse {
  year: number;
  month: number;
  days: Record<string, CalendarDay>;
}

export interface CreateBranchInput {
  name: string;
  parent_id?: string;
  description?: string;
  color?: string;
}

export interface CommitFilters {
  branch_id?: string;
  date_from?: string;
  date_to?: string;
  page?: number;
  limit?: number;
}

export interface CreateCommitInput {
  branch_id: string;
  message: string;
  author?: string;
  hash?: string;
  parent_commit_id?: string;
  metadata?: Record<string, unknown>;
  files?: Array<{
    path: string;
    action: 'added' | 'modified' | 'deleted' | 'renamed';
    diff?: string;
    content_snapshot?: string;
  }>;
}

// ==================== Typed Query Helpers ====================

export function getBranches(): Branch[] {
  const db = getVcbDb();
  return db.prepare(`
    SELECT 
      b.id, b.name, b.parent_id, b.status, b.description, b.color,
      b.created_at, b.updated_at,
      c.id AS last_commit_id,
      c.message AS last_commit_message,
      c.author AS last_commit_author,
      c.timestamp AS last_commit_at,
      (SELECT COUNT(*) FROM commits WHERE branch_id = b.id) AS commit_count,
      (SELECT COUNT(*) FROM snapshots WHERE branch_id = b.id) AS snapshot_count
    FROM branches b
    LEFT JOIN commits c ON c.id = (
      SELECT id FROM commits WHERE branch_id = b.id ORDER BY timestamp DESC LIMIT 1
    )
    ORDER BY b.created_at ASC
  `).all() as Branch[];
}

export function getBranchById(id: string): Branch | null {
  const db = getVcbDb();
  return db.prepare(`
    SELECT 
      b.id, b.name, b.parent_id, b.status, b.description, b.color,
      b.created_at, b.updated_at,
      c.id AS last_commit_id,
      c.message AS last_commit_message,
      c.author AS last_commit_author,
      c.timestamp AS last_commit_at,
      (SELECT COUNT(*) FROM commits WHERE branch_id = b.id) AS commit_count,
      (SELECT COUNT(*) FROM snapshots WHERE branch_id = b.id) AS snapshot_count
    FROM branches b
    LEFT JOIN commits c ON c.id = (
      SELECT id FROM commits WHERE branch_id = b.id ORDER BY timestamp DESC LIMIT 1
    )
    WHERE b.id = ?
  `).get(id) as Branch | null;
}

export function createBranch(data: CreateBranchInput): Branch {
  const db = getVcbDb();
  const id = data.name.toLowerCase().replace(/[^a-z0-9-/]/g, '-').replace(/-+/g, '-');
  
  db.prepare(`
    INSERT INTO branches (id, name, parent_id, description, color)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    id,
    data.name,
    data.parent_id || null,
    data.description || null,
    data.color || '#6366f1'
  );
  
  return getBranchById(id)!;
}

export function updateBranch(id: string, data: Partial<Branch>): Branch | null {
  const db = getVcbDb();
  const updates: string[] = [];
  const values: unknown[] = [];
  
  if (data.status !== undefined) {
    updates.push('status = ?');
    values.push(data.status);
  }
  if (data.description !== undefined) {
    updates.push('description = ?');
    values.push(data.description);
  }
  if (data.color !== undefined) {
    updates.push('color = ?');
    values.push(data.color);
  }
  
  if (updates.length > 0) {
    updates.push('updated_at = datetime(\'now\')');
    values.push(id);
    db.prepare(`UPDATE branches SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  }
  
  return getBranchById(id);
}

export function getCommits(filters: CommitFilters): { commits: Commit[]; total: number } {
  const db = getVcbDb();
  const page = filters.page || 1;
  const limit = Math.min(filters.limit || 50, 200);
  const offset = (page - 1) * limit;
  
  let whereClause = '1=1';
  const params: unknown[] = [];
  
  if (filters.branch_id) {
    whereClause += ' AND c.branch_id = ?';
    params.push(filters.branch_id);
  }
  if (filters.date_from) {
    whereClause += ' AND date(c.timestamp) >= ?';
    params.push(filters.date_from);
  }
  if (filters.date_to) {
    whereClause += ' AND date(c.timestamp) <= ?';
    params.push(filters.date_to);
  }
  
  // Get total count
  const countResult = db.prepare(`
    SELECT COUNT(*) as total FROM commits c WHERE ${whereClause}
  `).get(...params) as { total: number };
  
  // Get paginated results
  const commits = db.prepare(`
    SELECT c.*, b.name AS branch_name, b.color AS branch_color
    FROM commits c
    JOIN branches b ON b.id = c.branch_id
    WHERE ${whereClause}
    ORDER BY c.timestamp DESC
    LIMIT ? OFFSET ?
  `).all(...params, limit, offset) as Commit[];
  
  return { commits, total: countResult.total };
}

export function getCommitsByBranch(branchId: string, page: number = 1, limit: number = 20): { commits: Commit[]; total: number } {
  const db = getVcbDb();
  const offset = (page - 1) * limit;
  
  const countResult = db.prepare('SELECT COUNT(*) as total FROM commits WHERE branch_id = ?').get(branchId) as { total: number };
  
  const commits = db.prepare(`
    SELECT c.*, 
      (SELECT COUNT(*) FROM files WHERE commit_id = c.id) AS file_count
    FROM commits c
    WHERE c.branch_id = ?
    ORDER BY c.timestamp DESC
    LIMIT ? OFFSET ?
  `).all(branchId, limit, offset) as Commit[];
  
  return { commits, total: countResult.total };
}

export function createCommit(data: CreateCommitInput): Commit {
  const db = getVcbDb();
  const id = data.hash || `commit-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  
  db.prepare(`
    INSERT INTO commits (id, branch_id, message, author, hash, parent_commit_id, metadata)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    data.branch_id,
    data.message,
    data.author || 'Kevin',
    data.hash || null,
    data.parent_commit_id || null,
    JSON.stringify(data.metadata || {})
  );
  
  // Insert files if provided
  if (data.files && data.files.length > 0) {
    const insertFile = db.prepare(`
      INSERT INTO files (commit_id, path, action, diff, content_snapshot)
      VALUES (?, ?, ?, ?, ?)
    `);
    for (const file of data.files) {
      insertFile.run(id, file.path, file.action, file.diff || null, file.content_snapshot || null);
    }
  }
  
  return db.prepare('SELECT * FROM commits WHERE id = ?').get(id) as Commit;
}

export function getSnapshotsByBranch(branchId: string): Snapshot[] {
  const db = getVcbDb();
  return db.prepare(`
    SELECT s.*, b.name AS branch_name, b.color AS branch_color
    FROM snapshots s
    JOIN branches b ON b.id = s.branch_id
    WHERE s.branch_id = ?
    ORDER BY s.timestamp DESC
  `).all(branchId) as Snapshot[];
}

export function getCalendarEvents(year: number, month: number): CalendarResponse {
  const db = getVcbDb();
  const monthPadded = month.toString().padStart(2, '0');
  
  // Get commits for the month
  const commits = db.prepare(`
    SELECT 
      date(c.timestamp) AS day,
      c.id, c.message, c.author, c.timestamp,
      b.name AS branch_name, b.color AS branch_color
    FROM commits c
    JOIN branches b ON b.id = c.branch_id
    WHERE strftime('%Y', c.timestamp) = ?
      AND strftime('%m', c.timestamp) = ?
    ORDER BY c.timestamp ASC
  `).all(year.toString(), monthPadded) as Array<Commit & { day: string }>;
  
  // Get snapshots for the month
  const snapshots = db.prepare(`
    SELECT 
      date(s.timestamp) AS day,
      s.id, s.label, s.description, s.timestamp,
      b.name AS branch_name, b.color AS branch_color
    FROM snapshots s
    JOIN branches b ON b.id = s.branch_id
    WHERE strftime('%Y', s.timestamp) = ?
      AND strftime('%m', s.timestamp) = ?
    ORDER BY s.timestamp ASC
  `).all(year.toString(), monthPadded) as Array<Snapshot & { day: string }>;
  
  // Group by day
  const days: Record<string, CalendarDay> = {};
  
  // Initialize all days of the month
  const daysInMonth = new Date(year, month, 0).getDate();
  for (let d = 1; d <= daysInMonth; d++) {
    const dayKey = `${year}-${monthPadded}-${d.toString().padStart(2, '0')}`;
    days[dayKey] = { commits: [], snapshots: [] };
  }
  
  // Add commits to their days
  for (const commit of commits) {
    const dayKey = commit.day;
    if (days[dayKey]) {
      days[dayKey].commits.push({
        id: commit.id,
        branch_id: '',
        message: commit.message,
        author: commit.author,
        hash: null,
        parent_commit_id: null,
        metadata: {},
        timestamp: commit.timestamp,
        branch_name: commit.branch_name,
        branch_color: commit.branch_color
      });
    }
  }
  
  // Add snapshots to their days
  for (const snapshot of snapshots) {
    const dayKey = snapshot.day;
    if (days[dayKey]) {
      days[dayKey].snapshots.push({
        id: snapshot.id,
        branch_id: '',
        commit_id: null,
        label: snapshot.label,
        description: snapshot.description,
        data: {},
        timestamp: snapshot.timestamp,
        branch_name: snapshot.branch_name,
        branch_color: snapshot.branch_color
      });
    }
  }
  
  return { year, month, days };
}
