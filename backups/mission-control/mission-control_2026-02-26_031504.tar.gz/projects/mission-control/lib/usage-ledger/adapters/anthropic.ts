/**
 * Anthropic Usage Adapter
 * 
 * Anthropic provides usage data via their API with Token API usage reporting.
 * 
 * CAVEATS:
 * - Anthropic provides usage in response metadata
 * - Cache controls (prompt caching) available - discounted pricing
 * - No historical usage API - must track at request time
 * - Organization API may provide billing data
 */

import { BaseProviderAdapter } from './base';
import { UsageEvent, Provider } from '../types';
import { calculateCost } from '../costs';

export class AnthropicAdapter extends BaseProviderAdapter {
  readonly provider: Provider = 'anthropic';
  readonly supportsUsageFetch = false; // No public historical usage API

  async fetchUsageEvents(since?: Date): Promise<UsageEvent[]> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      console.log('[UsageLedger] Anthropic: No API key configured');
      return [];
    }

    // Anthropic's API doesn't have a public usage/history endpoint
    // We'd need to track at request time or use organization billing
    // For now, return empty and rely on request-time tracking
    
    console.log('[UsageLedger] Anthropic: No historical usage API, tracking at request time');
    return [];
  }

  async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return false;
    }
    
    try {
      // Test with a minimal API call - this will fail but proves the key is valid
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-3-haiku-20240307',
          max_tokens: 1,
          messages: [{ role: 'user', content: 'hi' }],
        }),
      });
      
      // 400 means valid key but bad request (expected)
      // 401 means invalid key
      return response.ok || response.status === 400;
    } catch {
      return false;
    }
  }

  /**
   * Create a usage event from Anthropic API response
   */
  static createEventFromResponse(
    model: string,
    usage: { 
      input_tokens?: number; 
      output_tokens?: number;
      cache_creation_tokens?: number;
      cache_read_tokens?: number;
    },
    requestId?: string
  ): UsageEvent {
    const tokensIn = usage.input_tokens || 0;
    const tokensOut = usage.output_tokens || 0;
    const cacheWrite = usage.cache_creation_tokens || 0;
    const cacheRead = usage.cache_read_tokens || 0;
    
    return {
      provider: 'anthropic',
      model,
      timestamp: new Date().toISOString(),
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cache_read: cacheRead,
      cache_write: cacheWrite,
      request_id: requestId || null,
      cost_usd: calculateCost('anthropic', model, tokensIn, tokensOut, cacheRead, cacheWrite),
      raw_payload: JSON.stringify(usage),
      source: 'request',
    };
  }
}