/**
 * OpenRouter Usage Adapter
 * 
 * OpenRouter provides usage data via their API. They don't have a direct usage endpoint,
 * but we can infer usage from response headers and track requests.
 * 
 * CAVEATS:
 * - OpenRouter does not provide a programmatic usage/history API
 * - Usage must be tracked at request time from response metadata
 * - Costs are model-dependent and vary
 * - No direct way to fetch historical usage - must track at request time
 * 
 * This adapter implements stub methods that will be used for tracking at request time.
 * For historical sync, it returns empty array.
 */

import { BaseProviderAdapter } from './base';
import { UsageEvent, Provider } from '../types';
import { calculateCost } from '../costs';

export class OpenRouterAdapter extends BaseProviderAdapter {
  readonly provider: Provider = 'openrouter';
  readonly supportsUsageFetch = false; // No usage API available

  async fetchUsageEvents(_since?: Date): Promise<UsageEvent[]> {
    // OpenRouter does not provide a usage API
    // This adapter tracks usage at request time via response metadata
    // For sync purposes, we return empty - actual usage tracked via middleware
    console.log('[UsageLedger] OpenRouter: No usage API available, usage tracked at request time');
    return [];
  }

  async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      console.log('[UsageLedger] OpenRouter: No API key configured');
      return false;
    }
    
    try {
      const response = await fetch('https://openrouter.ai/api/v1/auth/key', {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      });
      return response.ok;
    } catch (error) {
      console.error('[UsageLedger] OpenRouter: Connection test failed', error);
      return false;
    }
  }

  /**
   * Process a response from OpenRouter and create a usage event
   * This is called by middleware when tracking usage at request time
   */
  static createEventFromResponse(
    model: string,
    usage: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number },
    requestId?: string,
    cost?: number
  ): UsageEvent {
    const tokensIn = usage.prompt_tokens || 0;
    const tokensOut = usage.completion_tokens || usage.total_tokens ? 
      (usage.total_tokens || 0) - tokensIn : 0;
    
    return {
      provider: 'openrouter',
      model,
      timestamp: new Date().toISOString(),
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cache_read: 0,
      cache_write: 0,
      request_id: requestId || null,
      cost_usd: cost ?? calculateCost('openrouter', model, tokensIn, tokensOut),
      raw_payload: JSON.stringify(usage),
      source: 'request',
    };
  }
}