import { getSetting } from '@/lib/db-helpers';
import { getSecret } from '@/lib/secrets';
import { Provider, UsageEvent } from '@/lib/usage-ledger/types';

export interface ProviderAdapter {
  readonly provider: Provider;
  readonly supportsUsageFetch: boolean;
  fetchUsageEvents(since?: Date): Promise<UsageEvent[]>;
  testConnection(): Promise<boolean>;
}

export abstract class BaseProviderAdapter implements ProviderAdapter {
  abstract readonly provider: Provider;
  abstract readonly supportsUsageFetch: boolean;

  protected getApiKey(): string | null {
    const keyMap: Record<Provider, string[]> = {
      openrouter: ['openrouter', 'OPENROUTER_API_KEY'],
      openai: ['openai', 'OPENAI_API_KEY'],
      google: ['google', 'GOOGLE_API_KEY'],
      xai: ['xai', 'XAI_API_KEY'],
      anthropic: ['anthropic', 'ANTHROPIC_API_KEY'],
      nvidia: ['nvidia', 'NVIDIA_API_KEY'],
    };

    // 1) Reuse existing non-secret API keys settings (legacy pattern)
    const apiKeys = getSetting<Record<string, string>>('apiKeys') || {};
    for (const candidate of keyMap[this.provider]) {
      if (apiKeys[candidate]) return apiKeys[candidate];
    }

    // 2) Secret store (preferred secure path)
    for (const candidate of keyMap[this.provider]) {
      const secret = getSecret(candidate);
      if (secret) return secret;
    }

    // 3) Env fallback
    for (const candidate of keyMap[this.provider]) {
      if (process.env[candidate]) return process.env[candidate] as string;
    }

    return null;
  }

  protected toEvent(params: {
    model: string;
    timestamp?: string;
    tokensIn?: number;
    tokensOut?: number;
    cacheRead?: number;
    cacheWrite?: number;
    requestId?: string | null;
    costUsd?: number;
    rawPayload?: unknown;
    source?: string;
  }): UsageEvent {
    return {
      provider: this.provider,
      model: params.model || 'unknown',
      timestamp: params.timestamp || new Date().toISOString(),
      tokens_in: Math.max(0, Math.floor(params.tokensIn || 0)),
      tokens_out: Math.max(0, Math.floor(params.tokensOut || 0)),
      cache_read: Math.max(0, Math.floor(params.cacheRead || 0)),
      cache_write: Math.max(0, Math.floor(params.cacheWrite || 0)),
      request_id: params.requestId ?? null,
      cost_usd: Math.max(0, Number(params.costUsd || 0)),
      raw_payload: params.rawPayload ? JSON.stringify(params.rawPayload) : null,
      source: params.source || 'api',
    };
  }

  abstract fetchUsageEvents(since?: Date): Promise<UsageEvent[]>;
  abstract testConnection(): Promise<boolean>;
}
