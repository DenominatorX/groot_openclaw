/**
 * NVIDIA NIM Usage Adapter
 * 
 * NVIDIA provides usage data via their NIM API with response metadata.
 * 
 * CAVEATS:
 * - NVIDIA NIM is a newer service with evolving API
 * - Usage tracking depends on specific NIM deployment
 * - May require NVIDIA NGC account
 * - Pricing varies by deployed model
 */

import { BaseProviderAdapter } from './base';
import { UsageEvent, Provider } from '../types';
import { calculateCost } from '../costs';

export class NVIDIAAdapter extends BaseProviderAdapter {
  readonly provider: Provider = 'nvidia';
  readonly supportsUsageFetch = false; // No stable programmatic historical usage API

  async fetchUsageEvents(_since?: Date): Promise<UsageEvent[]> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      console.log('[UsageLedger] NVIDIA: No API key configured');
      return [];
    }

    // NVIDIA NIM doesn't have a standardized usage API
    // Usage should be tracked at request time
    // There may be usage data in NVIDIA NGC dashboard
    
    console.log('[UsageLedger] NVIDIA: No programmatic usage API, tracking at request time');
    return [];
  }

  async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return false;
    }
    
    try {
      // Test with NVIDIA NGC API
      const response = await fetch('https://api.ngc.nvidia.com/v0/auth/validate', {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
      });
      
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * Create a usage event from NVIDIA NIM API response
   */
  static createEventFromResponse(
    model: string,
    usage: { input_tokens?: number; output_tokens?: number },
    requestId?: string
  ): UsageEvent {
    const tokensIn = usage.input_tokens || 0;
    const tokensOut = usage.output_tokens || 0;
    
    return {
      provider: 'nvidia',
      model,
      timestamp: new Date().toISOString(),
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cache_read: 0,
      cache_write: 0,
      request_id: requestId || null,
      cost_usd: calculateCost('nvidia', model, tokensIn, tokensOut),
      raw_payload: JSON.stringify(usage),
      source: 'request',
    };
  }
}