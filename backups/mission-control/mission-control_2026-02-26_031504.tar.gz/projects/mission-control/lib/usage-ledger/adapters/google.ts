/**
 * Google Gemini Usage Adapter
 * 
 * Google AI (Gemini) provides usage data via the Google AI Studio API.
 * 
 * CAVEATS:
 * - Usage tracking available via Google AI Studio API
 * - Historical usage requires API key with appropriate permissions
 * - Token counts provided in response metadata
 * - Cache controls available (Google's cached content feature)
 */

import { BaseProviderAdapter } from './base';
import { UsageEvent, Provider } from '../types';
import { calculateCost } from '../costs';

export class GoogleAdapter extends BaseProviderAdapter {
  readonly provider: Provider = 'google';
  readonly supportsUsageFetch = false; // No direct historical usage API

  async fetchUsageEvents(since?: Date): Promise<UsageEvent[]> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      console.log('[UsageLedger] Google: No API key configured');
      return [];
    }

    // Google AI Studio doesn't have a direct usage API, but we can check
    // the models endpoint to validate connection and estimate from requests
    // Actual usage tracking is best done at request time
    
    try {
      // List available models to verify connection
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1/models?key=${apiKey}`
      );

      if (!response.ok) {
        console.error('[UsageLedger] Google: Failed to connect', await response.text());
        return [];
      }

      // Note: Google doesn't provide historical usage API
      // This would need to be tracked at request time
      // Returning empty as usage should be captured via middleware
      console.log('[UsageLedger] Google: Connection OK, usage tracked at request time');
      return [];
    } catch (error) {
      console.error('[UsageLedger] Google: Error fetching usage', error);
      return [];
    }
  }

  async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return false;
    }
    
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1/models?key=${apiKey}`
      );
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * Create a usage event from Google Gemini API response
   */
  static createEventFromResponse(
    model: string,
    usageMetadata: { promptTokenCount?: number; candidatesTokenCount?: number; totalTokenCount?: number },
    requestId?: string,
    cachedContentTokenCount?: number
  ): UsageEvent {
    const tokensIn = usageMetadata.promptTokenCount || 0;
    const tokensOut = usageMetadata.candidatesTokenCount || 0;
    const cacheRead = cachedContentTokenCount || 0;
    
    return {
      provider: 'google',
      model,
      timestamp: new Date().toISOString(),
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cache_read: cacheRead,
      cache_write: 0,
      request_id: requestId || null,
      cost_usd: calculateCost('google', model, tokensIn, tokensOut, cacheRead),
      raw_payload: JSON.stringify(usageMetadata),
      source: 'request',
    };
  }
}