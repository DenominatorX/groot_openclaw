import { getDb } from '@/lib/database';
import { calculateCost } from '@/lib/usage-ledger/costs';
import { AggregatedMetrics, Provider, SyncStatus, UsageEvent, UsageQueryFilter } from '@/lib/usage-ledger/types';

function parseCostFromRaw(rawPayload: string | null): number | null {
  if (!rawPayload) return null;
  try {
    const payload = JSON.parse(rawPayload) as any;
    if (typeof payload?.cost === 'number') return payload.cost;
    if (typeof payload?.cost_usd === 'number') return payload.cost_usd;
    if (typeof payload?.usage?.cost === 'number') return payload.usage.cost;
    return null;
  } catch {
    return null;
  }
}

function normalizeEvent(event: UsageEvent): UsageEvent {
  const normalized: UsageEvent = {
    provider: event.provider,
    model: event.model || 'unknown',
    timestamp: event.timestamp || new Date().toISOString(),
    tokens_in: Math.max(0, Math.floor(event.tokens_in || 0)),
    tokens_out: Math.max(0, Math.floor(event.tokens_out || 0)),
    cache_read: Math.max(0, Math.floor(event.cache_read || 0)),
    cache_write: Math.max(0, Math.floor(event.cache_write || 0)),
    request_id: event.request_id ?? null,
    cost_usd: Number(event.cost_usd || 0),
    raw_payload: event.raw_payload || null,
    source: event.source || 'api',
  };

  if (!Number.isFinite(normalized.cost_usd) || normalized.cost_usd <= 0) {
    const parsed = parseCostFromRaw(normalized.raw_payload);
    normalized.cost_usd = parsed ?? calculateCost(
      normalized.provider,
      normalized.model,
      normalized.tokens_in,
      normalized.tokens_out,
      normalized.cache_read,
      normalized.cache_write
    );
  }

  if (!Number.isFinite(normalized.cost_usd) || normalized.cost_usd < 0) {
    normalized.cost_usd = 0;
  }

  return normalized;
}

export function insertUsageEvent(event: UsageEvent): number {
  const db = getDb();
  const e = normalizeEvent(event);

  if (e.request_id) {
    const existing = db.prepare('SELECT id FROM usage_events WHERE provider = ? AND request_id = ? ORDER BY id DESC LIMIT 1')
      .get(e.provider, e.request_id) as { id: number } | undefined;

    if (existing?.id) {
      db.prepare(`
        UPDATE usage_events
        SET model = ?, timestamp = ?, tokens_in = ?, tokens_out = ?, cache_read = ?, cache_write = ?, cost_usd = ?, raw_payload = ?, source = ?
        WHERE id = ?
      `).run(
        e.model,
        e.timestamp,
        e.tokens_in,
        e.tokens_out,
        e.cache_read,
        e.cache_write,
        e.cost_usd,
        e.raw_payload,
        e.source,
        existing.id
      );
      return existing.id;
    }
  }

  const result = db.prepare(`
    INSERT INTO usage_events
    (provider, model, timestamp, tokens_in, tokens_out, cache_read, cache_write, request_id, cost_usd, raw_payload, source)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    e.provider,
    e.model,
    e.timestamp,
    e.tokens_in,
    e.tokens_out,
    e.cache_read,
    e.cache_write,
    e.request_id,
    e.cost_usd,
    e.raw_payload,
    e.source
  );

  return Number(result.lastInsertRowid || 0);
}

export function insertUsageEvents(events: UsageEvent[]): number {
  if (!events.length) return 0;
  const db = getDb();

  let inserted = 0;
  db.transaction((batch: UsageEvent[]) => {
    for (const event of batch) {
      const e = normalizeEvent(event);

      if (e.request_id) {
        const existing = db.prepare('SELECT id FROM usage_events WHERE provider = ? AND request_id = ? ORDER BY id DESC LIMIT 1')
          .get(e.provider, e.request_id) as { id: number } | undefined;

        if (existing?.id) {
          db.prepare(`
            UPDATE usage_events
            SET model = ?, timestamp = ?, tokens_in = ?, tokens_out = ?, cache_read = ?, cache_write = ?, cost_usd = ?, raw_payload = ?, source = ?
            WHERE id = ?
          `).run(
            e.model,
            e.timestamp,
            e.tokens_in,
            e.tokens_out,
            e.cache_read,
            e.cache_write,
            e.cost_usd,
            e.raw_payload,
            e.source,
            existing.id
          );
          continue;
        }
      }

      const r = db.prepare(`
        INSERT INTO usage_events
        (provider, model, timestamp, tokens_in, tokens_out, cache_read, cache_write, request_id, cost_usd, raw_payload, source)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        e.provider,
        e.model,
        e.timestamp,
        e.tokens_in,
        e.tokens_out,
        e.cache_read,
        e.cache_write,
        e.request_id,
        e.cost_usd,
        e.raw_payload,
        e.source
      );

      if (r.changes > 0) inserted++;
    }
  })(events);

  return inserted;
}

export function getUsageEvents(filter: UsageQueryFilter = {}): UsageEvent[] {
  const db = getDb();
  let sql = 'SELECT * FROM usage_events WHERE 1=1';
  const params: unknown[] = [];

  if (filter.provider) {
    sql += ' AND provider = ?';
    params.push(filter.provider);
  }
  if (filter.model) {
    sql += ' AND model LIKE ?';
    params.push(`%${filter.model}%`);
  }
  if (filter.startDate) {
    sql += ' AND timestamp >= ?';
    params.push(filter.startDate);
  }
  if (filter.endDate) {
    sql += ' AND timestamp <= ?';
    params.push(filter.endDate);
  }

  sql += ' ORDER BY timestamp DESC';

  if (typeof filter.limit === 'number') {
    sql += ' LIMIT ?';
    params.push(filter.limit);
  }
  if (typeof filter.offset === 'number') {
    sql += ' OFFSET ?';
    params.push(filter.offset);
  }

  return db.prepare(sql).all(...params) as UsageEvent[];
}

export function getUsageEventByRequest(provider: Provider, requestId: string): UsageEvent | null {
  const db = getDb();
  return db.prepare('SELECT * FROM usage_events WHERE provider = ? AND request_id = ?').get(provider, requestId) as UsageEvent | null;
}

export function getAggregatedMetrics(filter: UsageQueryFilter = {}): AggregatedMetrics {
  const db = getDb();
  let whereClause = '1=1';
  const params: unknown[] = [];

  if (filter.provider) {
    whereClause += ' AND provider = ?';
    params.push(filter.provider);
  }
  if (filter.model) {
    whereClause += ' AND model LIKE ?';
    params.push(`%${filter.model}%`);
  }
  if (filter.startDate) {
    whereClause += ' AND timestamp >= ?';
    params.push(filter.startDate);
  }
  if (filter.endDate) {
    whereClause += ' AND timestamp <= ?';
    params.push(filter.endDate);
  }

  const totals = db.prepare(`
    SELECT
      COALESCE(SUM(cost_usd), 0) AS total_cost_usd,
      COALESCE(SUM(tokens_in), 0) AS total_tokens_in,
      COALESCE(SUM(tokens_out), 0) AS total_tokens_out,
      COALESCE(SUM(cache_read), 0) AS total_cache_read,
      COALESCE(SUM(cache_write), 0) AS total_cache_write,
      COUNT(*) AS total_requests
    FROM usage_events
    WHERE ${whereClause}
  `).get(...params) as any;

  const providerRows = db.prepare(`
    SELECT provider, COALESCE(SUM(cost_usd),0) AS cost_usd, COALESCE(SUM(tokens_in),0) AS tokens_in, COALESCE(SUM(tokens_out),0) AS tokens_out, COUNT(*) AS requests
    FROM usage_events
    WHERE ${whereClause}
    GROUP BY provider
  `).all(...params) as any[];

  const by_provider: AggregatedMetrics['by_provider'] = {
    openrouter: { cost_usd: 0, tokens_in: 0, tokens_out: 0, requests: 0 },
    openai: { cost_usd: 0, tokens_in: 0, tokens_out: 0, requests: 0 },
    google: { cost_usd: 0, tokens_in: 0, tokens_out: 0, requests: 0 },
    xai: { cost_usd: 0, tokens_in: 0, tokens_out: 0, requests: 0 },
    anthropic: { cost_usd: 0, tokens_in: 0, tokens_out: 0, requests: 0 },
    nvidia: { cost_usd: 0, tokens_in: 0, tokens_out: 0, requests: 0 },
  };

  for (const row of providerRows) {
    const key = row.provider as Provider;
    if (by_provider[key]) {
      by_provider[key] = {
        cost_usd: Number(row.cost_usd || 0),
        tokens_in: Number(row.tokens_in || 0),
        tokens_out: Number(row.tokens_out || 0),
        requests: Number(row.requests || 0),
      };
    }
  }

  const modelRows = db.prepare(`
    SELECT model, COALESCE(SUM(cost_usd),0) AS cost_usd, COALESCE(SUM(tokens_in),0) AS tokens_in, COALESCE(SUM(tokens_out),0) AS tokens_out, COUNT(*) AS requests
    FROM usage_events
    WHERE ${whereClause}
    GROUP BY model
    ORDER BY cost_usd DESC
    LIMIT 100
  `).all(...params) as any[];

  const by_model: AggregatedMetrics['by_model'] = {};
  for (const row of modelRows) {
    by_model[row.model || 'unknown'] = {
      cost_usd: Number(row.cost_usd || 0),
      tokens_in: Number(row.tokens_in || 0),
      tokens_out: Number(row.tokens_out || 0),
      requests: Number(row.requests || 0),
    };
  }

  return {
    total_cost_usd: Number(totals.total_cost_usd || 0),
    total_tokens_in: Number(totals.total_tokens_in || 0),
    total_tokens_out: Number(totals.total_tokens_out || 0),
    total_requests: Number(totals.total_requests || 0),
    total_cache_read: Number(totals.total_cache_read || 0),
    total_cache_write: Number(totals.total_cache_write || 0),
    by_provider,
    by_model,
  };
}

export function updateSyncStatus(status: SyncStatus): void {
  const db = getDb();
  db.prepare(`
    INSERT INTO usage_sync_status (provider, last_sync_at, last_sync_status, last_sync_error, records_synced, updated_at)
    VALUES (?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(provider) DO UPDATE SET
      last_sync_at = excluded.last_sync_at,
      last_sync_status = excluded.last_sync_status,
      last_sync_error = excluded.last_sync_error,
      records_synced = excluded.records_synced,
      updated_at = datetime('now')
  `).run(
    status.provider,
    status.last_sync_at,
    status.last_sync_status,
    status.last_sync_error,
    status.records_synced
  );
}

export function getSyncStatus(provider?: Provider): SyncStatus | SyncStatus[] | null {
  const db = getDb();
  if (provider) {
    return db.prepare('SELECT provider, last_sync_at, last_sync_status, last_sync_error, records_synced FROM usage_sync_status WHERE provider = ?').get(provider) as SyncStatus | null;
  }
  return db.prepare('SELECT provider, last_sync_at, last_sync_status, last_sync_error, records_synced FROM usage_sync_status ORDER BY provider ASC').all() as SyncStatus[];
}

export function listDistinctModels(provider?: Provider): string[] {
  const db = getDb();
  if (provider) {
    return (db.prepare('SELECT DISTINCT model FROM usage_events WHERE provider = ? AND model IS NOT NULL ORDER BY model ASC').all(provider) as { model: string }[]).map(r => r.model);
  }
  return (db.prepare('SELECT DISTINCT model FROM usage_events WHERE model IS NOT NULL ORDER BY model ASC').all() as { model: string }[]).map(r => r.model);
}

export function listDistinctProviders(): Provider[] {
  const db = getDb();
  return (db.prepare('SELECT DISTINCT provider FROM usage_events ORDER BY provider ASC').all() as { provider: Provider }[]).map(r => r.provider);
}

export interface UsageIngestionHealth {
  lastEventTimestamp: string | null;
  totalEvents: number;
  last24hTotalEvents: number;
  byProviderLast24h: Record<Provider, number>;
}

export function getUsageIngestionHealth(): UsageIngestionHealth {
  const db = getDb();
  const lastRow = db.prepare('SELECT MAX(timestamp) as ts FROM usage_events').get() as { ts?: string | null };
  const totalRow = db.prepare('SELECT COUNT(*) as count FROM usage_events').get() as { count?: number };
  const cutoffIso = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  const recentRows = db.prepare(`
    SELECT provider, COUNT(*) as count
    FROM usage_events
    WHERE timestamp >= ?
    GROUP BY provider
  `).all(cutoffIso) as { provider: Provider; count: number }[];

  const byProviderLast24h: Record<Provider, number> = {
    openrouter: 0,
    openai: 0,
    google: 0,
    xai: 0,
    anthropic: 0,
    nvidia: 0,
  };

  for (const row of recentRows) {
    if (row.provider in byProviderLast24h) {
      byProviderLast24h[row.provider] = Number(row.count || 0);
    }
  }

  const last24hTotalEvents = Object.values(byProviderLast24h).reduce((sum, n) => sum + n, 0);

  return {
    lastEventTimestamp: lastRow?.ts || null,
    totalEvents: Number(totalRow?.count || 0),
    last24hTotalEvents,
    byProviderLast24h,
  };
}
