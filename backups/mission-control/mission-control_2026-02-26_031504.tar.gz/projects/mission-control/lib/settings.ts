import fs from 'fs';
import path from 'path';

const SETTINGS_PATH = path.join(process.cwd(), 'data', 'settings.json');

export interface Settings {
  port: number;
  theme: string;
  apiKeys: Record<string, string>;
  endpoints: Record<string, string>;
}

export function getSettings(): Settings {
  const raw = fs.readFileSync(SETTINGS_PATH, 'utf8');
  return JSON.parse(raw);
}

export function saveSettings(settings: Settings): void {
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2));
}

export function updateApiKey(key: string, value: string): Settings {
  const s = getSettings();
  s.apiKeys[key] = value;
  saveSettings(s);
  return s;
}

export function updatePort(port: number): Settings {
  if (port < 1024 || port > 65535) throw new Error('Port must be 1024-65535');
  const s = getSettings();
  s.port = port;
  saveSettings(s);
  return s;
}
