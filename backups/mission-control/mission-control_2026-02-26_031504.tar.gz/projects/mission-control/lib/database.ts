import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const DB_PATH = process.env.MC_DB_PATH || path.join(process.cwd(), 'data', 'mission-control.db');

// Ensure data dir exists
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!_db) {
    _db = new Database(DB_PATH);
    _db.pragma('journal_mode = WAL');  // Better concurrent access
    _db.pragma('foreign_keys = ON');
    initSchema(_db);
  }
  return _db;
}

export function closeDb(): void {
  if (_db) {
    _db.close();
    _db = null;
  }
}

function initSchema(db: Database.Database) {
  db.exec(`
    -- Users
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      google_id TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      avatar_url TEXT,
      role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user', 'viewer')),
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      last_login_at TEXT,
      onboarding_completed INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_users_google_id ON users(google_id);
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

    -- User settings
    CREATE TABLE IF NOT EXISTS user_settings (
      user_id TEXT PRIMARY KEY,
      theme TEXT DEFAULT 'dark',
      layout TEXT DEFAULT 'default',
      pinned_agents TEXT,
      dashboard_config TEXT,
      notifications_enabled INTEGER DEFAULT 1,
      agent_limit INTEGER DEFAULT 6,
      token_budget_monthly INTEGER DEFAULT NULL,
      enabled INTEGER DEFAULT 1,
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    -- Agent sessions (chat)
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      session_key TEXT UNIQUE,
      agent_id TEXT NOT NULL,
      model TEXT,
      title TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now')),
      last_message_at TEXT,
      message_count INTEGER DEFAULT 0
    );

    -- Chat messages (local cache)
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT REFERENCES sessions(id),
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      timestamp TEXT DEFAULT (datetime('now'))
    );

    -- Secrets (encrypted API keys) - kept from original
    CREATE TABLE IF NOT EXISTS secrets (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      label TEXT,
      masked TEXT,
      salt TEXT,
      iv TEXT,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Projects
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      user_id TEXT
    );

    -- Tasks
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      project_id TEXT,
      data JSON NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Issues
    CREATE TABLE IF NOT EXISTS issues (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Settings (non-secret config)
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value JSON NOT NULL,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Activity log
    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      agent_id TEXT,
      description TEXT,
      metadata JSON,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Agents config
    CREATE TABLE IF NOT EXISTS agents (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      updated_at TEXT DEFAULT (datetime('now')),
      user_id TEXT
    );

    -- Agent tiers (part of agents config)
    CREATE TABLE IF NOT EXISTS agent_tiers (
      tier_id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Plugins registry
    CREATE TABLE IF NOT EXISTS plugins (
      id TEXT PRIMARY KEY,
      manifest JSON NOT NULL,
      enabled INTEGER DEFAULT 1,
      config JSON DEFAULT '{}',
      installed_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Agent sessions state (from agent-sessions.json)
    CREATE TABLE IF NOT EXISTS agent_session_state (
      agent_id TEXT PRIMARY KEY,
      status TEXT,
      current_task TEXT,
      last_task_at TEXT,
      tasks_completed INTEGER DEFAULT 0,
      model TEXT,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Agent conversations (for tracking inter-agent chats)
    CREATE TABLE IF NOT EXISTS agent_conversations (
      id TEXT PRIMARY KEY,
      agent_id TEXT,
      with_agent_id TEXT,
      session_key TEXT,
      message_count INTEGER DEFAULT 0,
      started_at TEXT DEFAULT (datetime('now')),
      last_message_at TEXT,
      summary TEXT
    );

    -- Sub-agent runs (for tracking spawned sub-agents)
    CREATE TABLE IF NOT EXISTS subagent_runs (
      id TEXT PRIMARY KEY,
      label TEXT,
      spawned_by TEXT,
      agent_id TEXT,
      model TEXT,
      task_summary TEXT,
      status TEXT DEFAULT 'running',
      result_summary TEXT,
      cost_usd REAL DEFAULT 0,
      duration_ms INTEGER DEFAULT 0,
      started_at TEXT DEFAULT (datetime('now')),
      completed_at TEXT
    );

    -- Unified Usage Ledger - tracks API usage across all providers
    CREATE TABLE IF NOT EXISTS usage_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      provider TEXT NOT NULL,
      model TEXT,
      timestamp TEXT DEFAULT (datetime('now')),
      tokens_in INTEGER DEFAULT 0,
      tokens_out INTEGER DEFAULT 0,
      cache_read INTEGER DEFAULT 0,
      cache_write INTEGER DEFAULT 0,
      request_id TEXT,
      cost_usd REAL DEFAULT 0,
      raw_payload TEXT,
      source TEXT DEFAULT 'api',
      synced_at TEXT DEFAULT (datetime('now')),
      UNIQUE(provider, request_id, timestamp)
    );
    CREATE INDEX IF NOT EXISTS idx_usage_events_provider ON usage_events(provider);
    CREATE INDEX IF NOT EXISTS idx_usage_events_model ON usage_events(model);
    CREATE INDEX IF NOT EXISTS idx_usage_events_timestamp ON usage_events(timestamp);
    CREATE INDEX IF NOT EXISTS idx_usage_events_request_id ON usage_events(request_id);

    -- Usage sync status tracking
    CREATE TABLE IF NOT EXISTS usage_sync_status (
      provider TEXT PRIMARY KEY,
      last_sync_at TEXT,
      last_sync_status TEXT,
      last_sync_error TEXT,
      records_synced INTEGER DEFAULT 0,
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
}
