import * as fs from 'fs';
import * as path from 'path';
import { PATHS } from './paths';

/**
 * OpenClaw Gateway API Client
 * 
 * Communicates with the OpenClaw Gateway REST API to spawn agent sessions
 * and manage agent lifecycle.
 */

interface GatewayConfig {
  baseUrl: string;
  token: string;
}

interface SpawnOptions {
  agentId: string;
  task: string;
  model?: string;
  context?: Record<string, any>;
  label?: string;
}

interface SessionInfo {
  sessionKey: string;
  agentId: string;
  status: string;
  createdAt: string;
}

interface SessionMessage {
  role: string;
  content: string;
  timestamp: string;
}

/**
 * Get Gateway configuration from environment or config file
 */
function getGatewayConfig(): GatewayConfig {
  // First try environment variables
  const envUrl = process.env.OPENCLAW_GATEWAY_URL;
  const envToken = process.env.OPENCLAW_GATEWAY_TOKEN;
  
  if (envUrl && envToken) {
    return { baseUrl: envUrl, token: envToken };
  }
  
  // Fall back to config file
  const configPath = PATHS.OPENCLAW_CONFIG;
  try {
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      const token = envToken || config?.gateway?.auth?.token;
      const url = envUrl || config?.gateway?.url || process.env.OPENCLAW_GATEWAY_URL || 'http://localhost:18789';
      
      if (token) {
        return { baseUrl: url, token };
      }
    }
  } catch (err) {
    console.error('[OpenClawClient] Failed to read config file:', err);
  }
  
  // Default fallback
  return {
    baseUrl: envUrl || 'http://localhost:18789',
    token: envToken || '',
  };
}

/**
 * Invoke a tool via the Gateway /tools/invoke HTTP API
 */
async function toolsInvoke<T>(tool: string, args: Record<string, any>): Promise<T> {
  const config = getGatewayConfig();
  
  if (!config.token) {
    throw new Error('OpenClaw Gateway token not configured');
  }
  
  const url = `${config.baseUrl}/tools/invoke`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ tool, args }),
  });
  
  if (!response.ok) {
    const errorText = await response.text().catch(() => 'Unknown error');
    throw new Error(`Gateway ${tool} failed: ${response.status} ${response.statusText} - ${errorText}`);
  }
  
  const data = await response.json();
  if (!data.ok) {
    throw new Error(`Gateway ${tool} error: ${data.error?.message || JSON.stringify(data.error)}`);
  }
  
  return data.result as T;
}

/**
 * Spawn a new agent session via the Gateway
 * Requires sessions_spawn in gateway.tools.allow (loopback-only, token-protected)
 */
export async function spawnAgent(
  agentId: string,
  task: string,
  model?: string
): Promise<SessionInfo> {
  const args: Record<string, any> = { task, agentId };
  if (model) args.model = model;
  
  const result = await toolsInvoke<{
    status: string;
    childSessionKey: string;
    runId: string;
  }>('sessions_spawn', args);
  
  return {
    sessionKey: result.childSessionKey,
    agentId,
    status: result.status || 'spawned',
    createdAt: new Date().toISOString(),
  };
}

/**
 * Send a message to an active session
 */
export async function sendSessionMessage(
  sessionKey: string,
  message: string
): Promise<{ response?: string }> {
  const result = await toolsInvoke<any>('sessions_send', {
    sessionKey,
    message,
  });
  return result;
}

/**
 * Get session history (messages)
 */
export async function getSessionHistory(
  sessionKey: string,
  limit: number = 50
): Promise<SessionMessage[]> {
  const result = await toolsInvoke<{
    messages?: SessionMessage[];
  }>('sessions_history', {
    sessionKey,
    limit,
  });
  return result.messages || [];
}

/**
 * List all active sessions
 */
export async function listSessions(): Promise<Array<{
  sessionKey: string;
  agentId: string;
  status: string;
  createdAt: string;
}>> {
  const result = await toolsInvoke<{
    sessions?: Array<any>;
  }>('sessions_list', {});
  return result.sessions || [];
}

/**
 * Get session information
 */
export async function getSession(sessionKey: string): Promise<{
  sessionKey: string;
  agentId: string;
  status: string;
  messages: SessionMessage[];
}> {
  const history = await getSessionHistory(sessionKey, 50);
  return {
    sessionKey,
    agentId: '',
    status: 'active',
    messages: history,
  };
}

/**
 * Terminate a session (no direct API — just mark locally)
 */
export async function terminateSession(sessionKey: string): Promise<void> {
  // Gateway sessions auto-expire; we just mark them locally
  console.log(`[OpenClawClient] Session ${sessionKey} marked for termination`);
}

/**
 * Spawn an agent and wait for completion (with timeout)
 * 
 * @param agentId - Agent ID
 * @param task - Task to execute
 * @param model - Optional model override
 * @param timeoutMs - Timeout in milliseconds (default 5 minutes)
 * @returns The final response from the agent
 */
export async function spawnAndWait(
  agentId: string,
  task: string,
  model?: string,
  timeoutMs: number = 300000
): Promise<string> {
  const config = getGatewayConfig();
  
  if (!config.token) {
    throw new Error('OpenClaw Gateway token not configured');
  }
  
  // Spawn the session via tools/invoke
  const session = await spawnAgent(agentId, task, model);
  const sessionKey = session.sessionKey;
  
  if (!sessionKey) {
    throw new Error('No session key returned from spawn');
  }
  
  // Poll for completion via sessions_history
  const startTime = Date.now();
  let lastMessage = '';
  
  while (Date.now() - startTime < timeoutMs) {
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    try {
      const messages = await getSessionHistory(sessionKey, 5);
      
      if (messages && messages.length > 0) {
        const lastMsg = messages[messages.length - 1];
        if (lastMsg.role === 'assistant' && lastMsg.content) {
          lastMessage = typeof lastMsg.content === 'string' 
            ? lastMsg.content 
            : JSON.stringify(lastMsg.content);
          break; // Got a response, done
        }
      }
    } catch (err) {
      console.error('[OpenClawClient] Poll error:', err);
    }
  }
  
  return lastMessage || 'Agent completed but no response';
}

/**
 * Check if Gateway is available and configured
 */
export async function checkGatewayHealth(): Promise<{
  available: boolean;
  error?: string;
}> {
  try {
    const config = getGatewayConfig();
    
    if (!config.token) {
      return { available: false, error: 'Gateway token not configured' };
    }
    
    // Use tools/invoke with sessions_list as a health check
    const response = await fetch(`${config.baseUrl}/tools/invoke`, {
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${config.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ tool: 'sessions_list', args: { limit: 1 } }),
    });
    
    if (response.ok) {
      return { available: true };
    }
    
    return { available: false, error: `Gateway returned ${response.status}` };
  } catch (err) {
    return { 
      available: false, 
      error: err instanceof Error ? err.message : 'Unknown error' 
    };
  }
}

export default {
  spawnAgent,
  sendSessionMessage,
  getSession,
  getSessionHistory,
  listSessions,
  terminateSession,
  spawnAndWait,
  checkGatewayHealth,
};
