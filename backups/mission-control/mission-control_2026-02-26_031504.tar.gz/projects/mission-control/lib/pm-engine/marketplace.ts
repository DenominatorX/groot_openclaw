/**
 * PM Engine - Agent Marketplace Backend
 * Pre-built agents, weights, custom agent import
 */

import fs from 'fs';
import path from 'path';
import { MarketplaceAgent } from './types';

const DATA_DIR = path.join(process.cwd(), 'data', 'pm-engine');
const MARKETPLACE_FILE = path.join(DATA_DIR, 'marketplace.json');

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ==================== Built-in Agents ====================

const BUILT_IN_AGENTS: MarketplaceAgent[] = [
  {
    id: 'mp-forge',
    agentId: 'forge',
    name: 'Forge',
    description: 'Backend engineer specializing in APIs, databases, and server-side logic',
    specialty: 'backend',
    defaultModel: 'minimax/minimax-m2.5',
    recommendedWeight: 40,
    tags: ['backend', 'api', 'database', 'server'],
    usageCount: 0,
    rating: 4.8,
    builtIn: true,
  },
  {
    id: 'mp-pixel',
    agentId: 'pixel',
    name: 'Pixel',
    description: 'Frontend & UI/UX lead — React, CSS, design systems',
    specialty: 'frontend',
    defaultModel: 'minimax/minimax-m2.5',
    recommendedWeight: 35,
    tags: ['frontend', 'react', 'ui', 'ux', 'css'],
    usageCount: 0,
    rating: 4.7,
    builtIn: true,
  },
  {
    id: 'mp-sentinel',
    agentId: 'sentinel',
    name: 'Sentinel',
    description: 'QA & security engineer — testing, code review, vulnerability scanning',
    specialty: 'qa',
    defaultModel: 'xai/grok-4-1-fast-reasoning',
    recommendedWeight: 20,
    tags: ['qa', 'testing', 'security', 'review'],
    usageCount: 0,
    rating: 4.9,
    builtIn: true,
  },
  {
    id: 'mp-architect',
    agentId: 'architect',
    name: 'Architect',
    description: 'System architect — design docs, infrastructure planning, tech decisions',
    specialty: 'architecture',
    defaultModel: 'anthropic/claude-3.5-sonnet',
    recommendedWeight: 15,
    tags: ['architecture', 'design', 'infrastructure', 'planning'],
    usageCount: 0,
    rating: 4.6,
    builtIn: true,
  },
  {
    id: 'mp-oracle',
    agentId: 'oracle',
    name: 'Oracle',
    description: 'Senior analyst — data analysis, research, intelligence gathering',
    specialty: 'analysis',
    defaultModel: 'xai/grok-4-1-fast-reasoning',
    recommendedWeight: 15,
    tags: ['analysis', 'data', 'research', 'intelligence'],
    usageCount: 0,
    rating: 4.5,
    builtIn: true,
  },
  {
    id: 'mp-brain',
    agentId: 'brain',
    name: 'Brain',
    description: 'Synthesis & analysis CIO — project planning, strategic decisions',
    specialty: 'planning',
    defaultModel: 'anthropic/claude-3.5-sonnet',
    recommendedWeight: 10,
    tags: ['planning', 'strategy', 'synthesis', 'executive'],
    usageCount: 0,
    rating: 4.8,
    builtIn: true,
  },
];

// ==================== Storage ====================

function readMarketplaceFile(): MarketplaceAgent[] {
  ensureDir();
  try {
    if (!fs.existsSync(MARKETPLACE_FILE)) return [];
    return JSON.parse(fs.readFileSync(MARKETPLACE_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function writeMarketplaceFile(agents: MarketplaceAgent[]) {
  ensureDir();
  fs.writeFileSync(MARKETPLACE_FILE, JSON.stringify(agents, null, 2), 'utf8');
}

/**
 * Get all marketplace agents (built-in + custom)
 */
export function getAllMarketplaceAgents(): MarketplaceAgent[] {
  const custom = readMarketplaceFile();
  return [...BUILT_IN_AGENTS, ...custom];
}

/**
 * Get agent by ID
 */
export function getMarketplaceAgent(id: string): MarketplaceAgent | null {
  const builtIn = BUILT_IN_AGENTS.find(a => a.id === id);
  if (builtIn) return builtIn;
  
  const custom = readMarketplaceFile();
  return custom.find(a => a.id === id) || null;
}

/**
 * Search marketplace agents by tag or specialty
 */
export function searchMarketplaceAgents(query: string): MarketplaceAgent[] {
  const q = query.toLowerCase();
  const all = getAllMarketplaceAgents();
  return all.filter(a =>
    a.name.toLowerCase().includes(q) ||
    a.specialty.toLowerCase().includes(q) ||
    a.tags.some(t => t.includes(q)) ||
    a.description.toLowerCase().includes(q)
  );
}

/**
 * Import a custom agent into the marketplace (Elite tier only)
 */
export function importCustomAgent(agent: Omit<MarketplaceAgent, 'builtIn' | 'usageCount' | 'rating'>): MarketplaceAgent {
  const custom = readMarketplaceFile();
  
  const newAgent: MarketplaceAgent = {
    ...agent,
    builtIn: false,
    usageCount: 0,
    rating: 0,
  };

  const existing = custom.findIndex(a => a.id === agent.id);
  if (existing >= 0) {
    custom[existing] = newAgent;
  } else {
    custom.push(newAgent);
  }

  writeMarketplaceFile(custom);
  return newAgent;
}

/**
 * Remove a custom agent (cannot remove built-in)
 */
export function removeCustomAgent(id: string): boolean {
  if (BUILT_IN_AGENTS.some(a => a.id === id)) return false;
  
  const custom = readMarketplaceFile();
  const filtered = custom.filter(a => a.id !== id);
  if (filtered.length === custom.length) return false;
  
  writeMarketplaceFile(filtered);
  return true;
}

/**
 * Increment usage count for an agent
 */
export function incrementUsage(agentId: string): void {
  // For custom agents, update the file
  const custom = readMarketplaceFile();
  const agent = custom.find(a => a.agentId === agentId);
  if (agent) {
    agent.usageCount++;
    writeMarketplaceFile(custom);
  }
  // Built-in usage would be tracked in DB in production
}
