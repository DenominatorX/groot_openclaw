/**
 * PM Engine - DAG Utilities
 * Validation, cycle detection, topological sort for DAG definitions
 */

import { DAGDefinition, DAGNode, DAGEdge } from './types';

/**
 * Validate a DAG definition
 */
export function validateDAG(dag: DAGDefinition): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!dag.nodes || dag.nodes.length === 0) {
    errors.push('DAG must have at least one node');
    return { valid: false, errors };
  }

  // Check for duplicate node IDs
  const nodeIds = new Set<string>();
  for (const node of dag.nodes) {
    if (!node.id || node.id.trim() === '') {
      errors.push('All nodes must have a non-empty id');
    }
    if (nodeIds.has(node.id)) {
      errors.push(`Duplicate node id: "${node.id}"`);
    }
    nodeIds.add(node.id);

    if (!node.name || node.name.trim() === '') {
      errors.push(`Node "${node.id}" must have a name`);
    }
  }

  // Validate edges reference existing nodes
  if (dag.edges) {
    for (const edge of dag.edges) {
      if (!nodeIds.has(edge.source)) {
        errors.push(`Edge "${edge.id}" references non-existent source node "${edge.source}"`);
      }
      if (!nodeIds.has(edge.target)) {
        errors.push(`Edge "${edge.id}" references non-existent target node "${edge.target}"`);
      }
    }
  }

  // Cycle detection
  const cycle = detectCycle(dag);
  if (cycle.length > 0) {
    errors.push(`Circular dependency detected: ${cycle.join(' → ')}`);
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Detect cycles in DAG using DFS
 */
export function detectCycle(dag: DAGDefinition): string[] {
  const adjacency = new Map<string, string[]>();
  for (const node of dag.nodes) {
    adjacency.set(node.id, []);
  }
  for (const edge of dag.edges || []) {
    const targets = adjacency.get(edge.source);
    if (targets) targets.push(edge.target);
  }

  const visited = new Set<string>();
  const stack = new Set<string>();

  function dfs(nodeId: string, path: string[]): string[] {
    if (stack.has(nodeId)) {
      const cycleStart = path.indexOf(nodeId);
      return [...path.slice(cycleStart), nodeId];
    }
    if (visited.has(nodeId)) return [];

    visited.add(nodeId);
    stack.add(nodeId);

    for (const neighbor of adjacency.get(nodeId) || []) {
      const cycle = dfs(neighbor, [...path, nodeId]);
      if (cycle.length > 0) return cycle;
    }

    stack.delete(nodeId);
    return [];
  }

  for (const node of dag.nodes) {
    if (!visited.has(node.id)) {
      const cycle = dfs(node.id, []);
      if (cycle.length > 0) return cycle;
    }
  }

  return [];
}

/**
 * Topological sort of DAG nodes
 * Returns ordered node IDs for execution
 */
export function topologicalSort(dag: DAGDefinition): string[] {
  const inDegree = new Map<string, number>();
  const adjacency = new Map<string, string[]>();

  for (const node of dag.nodes) {
    inDegree.set(node.id, 0);
    adjacency.set(node.id, []);
  }

  for (const edge of dag.edges || []) {
    adjacency.get(edge.source)?.push(edge.target);
    inDegree.set(edge.target, (inDegree.get(edge.target) || 0) + 1);
  }

  const queue: string[] = [];
  for (const [id, deg] of inDegree) {
    if (deg === 0) queue.push(id);
  }

  const sorted: string[] = [];
  while (queue.length > 0) {
    const current = queue.shift()!;
    sorted.push(current);

    for (const neighbor of adjacency.get(current) || []) {
      const newDeg = (inDegree.get(neighbor) || 1) - 1;
      inDegree.set(neighbor, newDeg);
      if (newDeg === 0) queue.push(neighbor);
    }
  }

  return sorted;
}
