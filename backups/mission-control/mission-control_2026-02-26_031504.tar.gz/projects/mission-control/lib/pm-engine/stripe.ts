/**
 * PM Engine - Stripe Subscriptions & Quotas
 * Tier enforcement, token quotas, subscription management
 * NOTE: Stripe SDK not yet installed — this is the logic layer.
 *       Wire up stripe.js SDK when ready for production.
 */

import fs from 'fs';
import path from 'path';
import { SubscriptionTier, TierConfig, TIER_CONFIGS } from './types';

const DATA_DIR = path.join(process.cwd(), 'data', 'pm-engine');
const SUBS_FILE = path.join(DATA_DIR, 'subscriptions.json');
const USAGE_FILE = path.join(DATA_DIR, 'usage.json');

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ==================== Subscription Types ====================

export interface UserSubscription {
  userId: string;
  tier: SubscriptionTier;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  tokensUsed: number;
  projectsUsed: number;
  active: boolean;
}

export interface QuotaCheck {
  allowed: boolean;
  reason?: string;
  remaining?: {
    tokens: number;
    projects: number;
  };
  tier: SubscriptionTier;
  tierConfig: TierConfig;
}

// ==================== Storage ====================

function readSubs(): Record<string, UserSubscription> {
  ensureDir();
  try {
    if (!fs.existsSync(SUBS_FILE)) return {};
    return JSON.parse(fs.readFileSync(SUBS_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function writeSubs(subs: Record<string, UserSubscription>) {
  ensureDir();
  fs.writeFileSync(SUBS_FILE, JSON.stringify(subs, null, 2), 'utf8');
}

// ==================== Subscription Management ====================

/**
 * Get user's current subscription (defaults to free)
 */
export function getSubscription(userId: string): UserSubscription {
  const subs = readSubs();
  if (subs[userId]) return subs[userId];
  
  // Default free tier
  const now = new Date();
  const periodEnd = new Date(now);
  periodEnd.setMonth(periodEnd.getMonth() + 1);
  
  return {
    userId,
    tier: 'free',
    currentPeriodStart: now.toISOString(),
    currentPeriodEnd: periodEnd.toISOString(),
    tokensUsed: 0,
    projectsUsed: 0,
    active: true,
  };
}

/**
 * Create or update subscription
 * In production, this would be called from Stripe webhook
 */
export function upsertSubscription(sub: UserSubscription): UserSubscription {
  const subs = readSubs();
  subs[sub.userId] = sub;
  writeSubs(subs);
  return sub;
}

/**
 * Upgrade/downgrade tier (Stripe webhook handler would call this)
 */
export function changeTier(
  userId: string,
  newTier: SubscriptionTier,
  stripeCustomerId?: string,
  stripeSubscriptionId?: string
): UserSubscription {
  const sub = getSubscription(userId);
  sub.tier = newTier;
  if (stripeCustomerId) sub.stripeCustomerId = stripeCustomerId;
  if (stripeSubscriptionId) sub.stripeSubscriptionId = stripeSubscriptionId;
  return upsertSubscription(sub);
}

// ==================== Quota Enforcement ====================

/**
 * Check if user can perform an action based on their tier
 */
export function checkQuota(
  userId: string,
  action: 'create-project' | 'run-pipeline' | 'use-tokens',
  tokenCount?: number
): QuotaCheck {
  const sub = getSubscription(userId);
  const config = TIER_CONFIGS[sub.tier];

  // Check period reset
  if (new Date() > new Date(sub.currentPeriodEnd)) {
    // Reset period
    const now = new Date();
    const periodEnd = new Date(now);
    periodEnd.setMonth(periodEnd.getMonth() + 1);
    sub.currentPeriodStart = now.toISOString();
    sub.currentPeriodEnd = periodEnd.toISOString();
    sub.tokensUsed = 0;
    sub.projectsUsed = 0;
    upsertSubscription(sub);
  }

  const remainingTokens = config.monthlyTokenQuota - sub.tokensUsed;
  const remainingProjects = config.maxProjects === -1
    ? Infinity
    : config.maxProjects - sub.projectsUsed;

  switch (action) {
    case 'create-project':
      if (remainingProjects <= 0) {
        return {
          allowed: false,
          reason: `Project limit reached (${config.maxProjects}/month). Upgrade to ${sub.tier === 'free' ? 'Pro' : 'Elite'}.`,
          tier: sub.tier,
          tierConfig: config,
        };
      }
      break;

    case 'run-pipeline':
      if (remainingTokens <= 0) {
        return {
          allowed: false,
          reason: `Monthly token quota exhausted. Upgrade for more tokens.`,
          tier: sub.tier,
          tierConfig: config,
        };
      }
      break;

    case 'use-tokens':
      if (tokenCount && tokenCount > remainingTokens) {
        return {
          allowed: false,
          reason: `Insufficient tokens. Need ${tokenCount}, have ${remainingTokens}.`,
          remaining: { tokens: remainingTokens, projects: remainingProjects === Infinity ? -1 : remainingProjects },
          tier: sub.tier,
          tierConfig: config,
        };
      }
      break;
  }

  return {
    allowed: true,
    remaining: {
      tokens: remainingTokens,
      projects: remainingProjects === Infinity ? -1 : remainingProjects,
    },
    tier: sub.tier,
    tierConfig: config,
  };
}

/**
 * Record token usage
 */
export function recordTokenUsage(userId: string, tokensUsed: number): void {
  const sub = getSubscription(userId);
  sub.tokensUsed += tokensUsed;
  upsertSubscription(sub);
}

/**
 * Record project creation
 */
export function recordProjectCreation(userId: string): void {
  const sub = getSubscription(userId);
  sub.projectsUsed++;
  upsertSubscription(sub);
}

/**
 * Check if a feature is available for the user's tier
 */
export function checkFeatureAccess(
  userId: string,
  feature: 'sliders' | 'customAgents' | 'priorityCompute' | 'humanAssist'
): boolean {
  const sub = getSubscription(userId);
  const config = TIER_CONFIGS[sub.tier];

  switch (feature) {
    case 'sliders': return config.slidersEnabled;
    case 'customAgents': return config.customAgents;
    case 'priorityCompute': return config.priorityCompute;
    case 'humanAssist': return config.humanAssist;
    default: return false;
  }
}
