/**
 * PM Engine - Slider → JSON Override Logic
 * Converts slider controls to PROTOCOL_OVERRIDE.json
 */

import { SliderControls, DAGDefinition, DAGNode, DEFAULT_SLIDER_CONTROLS } from './types';
import { ProtocolConfig, ProtocolStep } from '@/lib/protocol-builder/types';
import { topologicalSort } from './dag';

/** Model tiers ordered by cost (cheap → expensive) */
const MODEL_TIERS = [
  'minimax/minimax-m2.5',
  'xai/grok-4-1-fast-reasoning',
  'anthropic/claude-3.5-sonnet',
  'anthropic/claude-3-opus',
];

/**
 * Select model based on cost/speed balance slider
 * 0 = cheapest, 100 = most expensive
 */
export function selectModel(costSpeedBalance: number, allowedModels: string[]): string {
  if (allowedModels.length === 0) return MODEL_TIERS[0];
  
  // Map balance to index in allowed models (ordered by cost)
  const orderedAllowed = MODEL_TIERS.filter(m => allowedModels.includes(m));
  if (orderedAllowed.length === 0) return allowedModels[0];
  
  const index = Math.min(
    Math.floor((costSpeedBalance / 100) * orderedAllowed.length),
    orderedAllowed.length - 1
  );
  return orderedAllowed[index];
}

/**
 * Map DAG node type to protocol step type
 */
function nodeTypeToStepType(nodeType: DAGNode['type']): ProtocolStep['type'] {
  switch (nodeType) {
    case 'plan': return 'task';
    case 'build': return 'task';
    case 'qa': return 'checkpoint';
    case 'deploy': return 'task';
    case 'hotfix': return 'task';
    case 'custom': return 'task';
    default: return 'task';
  }
}

/**
 * Determine if a node should require approval based on automation slider
 */
function shouldRequireApproval(
  node: DAGNode,
  automationPercent: number
): boolean {
  // Explicit approval setting on node takes precedence
  if (node.approvalRequired !== undefined) return node.approvalRequired;
  
  // 0% automation = approve everything, 100% = approve nothing
  if (automationPercent >= 90) return false;
  if (automationPercent <= 10) return true;
  
  // Middle range: approve critical phases only
  if (automationPercent < 50) {
    return ['deploy', 'build', 'qa'].includes(node.type);
  }
  
  // >50 automation: only approve deploy
  return node.type === 'deploy';
}

/**
 * Calculate timeout based on phase weight
 * Higher weight = more time allocated
 */
function calculateTimeout(
  baseTimeout: number,
  phaseWeight: number
): number {
  if (phaseWeight <= 0) return 1; // skip = minimal timeout
  return Math.round(baseTimeout * phaseWeight);
}

/**
 * Convert slider controls + DAG → PROTOCOL_OVERRIDE.json
 * This is the core conversion that makes sliders actionable
 */
export function slidersToProtocolOverride(
  dag: DAGDefinition,
  sliders: SliderControls,
  allowedModels: string[] = MODEL_TIERS
): ProtocolConfig {
  const executionOrder = topologicalSort(dag);
  const selectedModel = selectModel(sliders.costSpeedBalance, allowedModels);
  
  const steps: ProtocolStep[] = [];
  let prevStepId: string | undefined;

  for (const nodeId of executionOrder) {
    const node = dag.nodes.find(n => n.id === nodeId);
    if (!node) continue;

    const phaseWeight = sliders.phaseWeights[node.type] ?? 1;

    // Skip phase if weight is 0
    if (phaseWeight <= 0) continue;

    const baseTimeout = node.timeoutMin || 15;
    const approvalRequired = shouldRequireApproval(node, sliders.automationPercent);

    const step: ProtocolStep = {
      id: node.id,
      name: node.name,
      type: nodeTypeToStepType(node.type),
      enabled: true,
      dependsOn: prevStepId,
      agent: node.agentId,
      model: node.model || selectedModel,
      timeoutMin: calculateTimeout(baseTimeout, phaseWeight),
      retries: node.retries ?? 2,
      approvalRequired,
      config: {
        phaseWeight,
        sourceNodeType: node.type,
        ...(node.config || {}),
      },
    };

    // If approval required, insert an approval step before the main step
    if (approvalRequired && node.type !== 'plan') {
      const approvalStep: ProtocolStep = {
        id: `${node.id}-approval`,
        name: `Approve: ${node.name}`,
        type: 'approval',
        enabled: true,
        dependsOn: prevStepId,
        approvalRequired: true,
        timeoutMin: 60,
      };
      steps.push(approvalStep);
      step.dependsOn = approvalStep.id;
    }

    steps.push(step);
    prevStepId = node.id;
  }

  // Add notification step at end
  steps.push({
    id: 'notify-completion',
    name: 'Notify Completion',
    type: 'notification',
    enabled: true,
    dependsOn: prevStepId,
    timeoutMin: 5,
    retries: 0,
  });

  return {
    version: '1.0.0',
    steps,
    allowedAgents: sliders.agentPool.length > 0
      ? dag.nodes.filter(n => n.agentId).map(n => n.agentId!)
      : undefined,
    defaultTimeoutMin: 30,
    defaultRetries: 2,
  };
}

/**
 * Validate slider values are within range
 */
export function validateSliders(sliders: Partial<SliderControls>): {
  valid: boolean;
  errors: string[];
  normalized: SliderControls;
} {
  const errors: string[] = [];
  
  const normalized: SliderControls = {
    ...DEFAULT_SLIDER_CONTROLS,
    ...sliders,
  };

  if (normalized.automationPercent < 0 || normalized.automationPercent > 100) {
    errors.push('automationPercent must be 0-100');
    normalized.automationPercent = Math.max(0, Math.min(100, normalized.automationPercent));
  }

  if (normalized.costSpeedBalance < 0 || normalized.costSpeedBalance > 100) {
    errors.push('costSpeedBalance must be 0-100');
    normalized.costSpeedBalance = Math.max(0, Math.min(100, normalized.costSpeedBalance));
  }

  for (const [phase, weight] of Object.entries(normalized.phaseWeights)) {
    if (weight < 0 || weight > 2) {
      errors.push(`phaseWeight for "${phase}" must be 0-2`);
      normalized.phaseWeights[phase] = Math.max(0, Math.min(2, weight));
    }
  }

  return { valid: errors.length === 0, errors, normalized };
}
