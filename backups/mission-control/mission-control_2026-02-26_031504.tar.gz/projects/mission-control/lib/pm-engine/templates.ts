/**
 * PM Engine - Template Storage
 * Built-in + user templates for DAG presets
 */

import fs from 'fs';
import path from 'path';
import { PMTemplate, DAGDefinition, SliderControls, DEFAULT_SLIDER_CONTROLS } from './types';

const DATA_DIR = path.join(process.cwd(), 'data', 'pm-engine');
const TEMPLATES_FILE = path.join(DATA_DIR, 'templates.json');

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ==================== Built-in Templates ====================

const WEB_APP_DAG: DAGDefinition = {
  version: '1.0.0',
  nodes: [
    { id: 'plan', name: 'Plan & Requirements', type: 'plan', position: { x: 100, y: 100 }, agentId: 'brain', timeoutMin: 10 },
    { id: 'build-frontend', name: 'Build Frontend', type: 'build', position: { x: 300, y: 50 }, agentId: 'pixel', timeoutMin: 30 },
    { id: 'build-backend', name: 'Build Backend', type: 'build', position: { x: 300, y: 150 }, agentId: 'forge', timeoutMin: 30 },
    { id: 'qa', name: 'QA & Testing', type: 'qa', position: { x: 500, y: 100 }, agentId: 'sentinel', timeoutMin: 15 },
    { id: 'deploy', name: 'Deploy', type: 'deploy', position: { x: 700, y: 100 }, timeoutMin: 10, approvalRequired: true },
  ],
  edges: [
    { id: 'e1', source: 'plan', target: 'build-frontend' },
    { id: 'e2', source: 'plan', target: 'build-backend' },
    { id: 'e3', source: 'build-frontend', target: 'qa' },
    { id: 'e4', source: 'build-backend', target: 'qa' },
    { id: 'e5', source: 'qa', target: 'deploy' },
  ],
};

const API_DAG: DAGDefinition = {
  version: '1.0.0',
  nodes: [
    { id: 'plan', name: 'API Design', type: 'plan', position: { x: 100, y: 100 }, agentId: 'architect', timeoutMin: 10 },
    { id: 'build', name: 'Implement Endpoints', type: 'build', position: { x: 300, y: 100 }, agentId: 'forge', timeoutMin: 30 },
    { id: 'qa', name: 'API Tests & Security', type: 'qa', position: { x: 500, y: 100 }, agentId: 'sentinel', timeoutMin: 15 },
  ],
  edges: [
    { id: 'e1', source: 'plan', target: 'build' },
    { id: 'e2', source: 'build', target: 'qa' },
  ],
};

const DATA_PIPELINE_DAG: DAGDefinition = {
  version: '1.0.0',
  nodes: [
    { id: 'plan', name: 'Pipeline Design', type: 'plan', position: { x: 100, y: 100 }, agentId: 'oracle', timeoutMin: 10 },
    { id: 'build', name: 'Build Pipeline', type: 'build', position: { x: 300, y: 100 }, agentId: 'forge', timeoutMin: 30 },
    { id: 'qa', name: 'Data Validation', type: 'qa', position: { x: 500, y: 100 }, agentId: 'sentinel', timeoutMin: 15 },
    { id: 'deploy', name: 'Deploy Pipeline', type: 'deploy', position: { x: 700, y: 100 }, approvalRequired: true, timeoutMin: 10 },
  ],
  edges: [
    { id: 'e1', source: 'plan', target: 'build' },
    { id: 'e2', source: 'build', target: 'qa' },
    { id: 'e3', source: 'qa', target: 'deploy' },
  ],
};

const BUILT_IN_TEMPLATES: PMTemplate[] = [
  {
    id: 'web-app',
    name: 'Web Application',
    description: 'Full-stack web app with parallel frontend/backend build, QA, and deploy',
    category: 'web-app',
    dag: WEB_APP_DAG,
    sliders: { ...DEFAULT_SLIDER_CONTROLS, phaseWeights: { plan: 1, build: 1.5, qa: 1.2, deploy: 1 } },
    builtIn: true,
    createdAt: '2026-02-24T00:00:00Z',
    updatedAt: '2026-02-24T00:00:00Z',
  },
  {
    id: 'api',
    name: 'API Service',
    description: 'REST/GraphQL API: design → build → test. Lean 3-node pipeline',
    category: 'api',
    dag: API_DAG,
    sliders: { ...DEFAULT_SLIDER_CONTROLS, phaseWeights: { plan: 1, build: 1.5, qa: 1.5, deploy: 0.5 } },
    builtIn: true,
    createdAt: '2026-02-24T00:00:00Z',
    updatedAt: '2026-02-24T00:00:00Z',
  },
  {
    id: 'data-pipeline',
    name: 'Data Pipeline',
    description: 'ETL/data pipeline: design → build → validate → deploy',
    category: 'data-pipeline',
    dag: DATA_PIPELINE_DAG,
    sliders: { ...DEFAULT_SLIDER_CONTROLS, phaseWeights: { plan: 1.2, build: 1, qa: 2, deploy: 1 } },
    builtIn: true,
    createdAt: '2026-02-24T00:00:00Z',
    updatedAt: '2026-02-24T00:00:00Z',
  },
];

// ==================== Storage Operations ====================

function readTemplatesFile(): PMTemplate[] {
  ensureDir();
  try {
    if (!fs.existsSync(TEMPLATES_FILE)) return [];
    return JSON.parse(fs.readFileSync(TEMPLATES_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function writeTemplatesFile(templates: PMTemplate[]) {
  ensureDir();
  fs.writeFileSync(TEMPLATES_FILE, JSON.stringify(templates, null, 2), 'utf8');
}

/**
 * Get all templates (built-in + user)
 */
export function getAllTemplates(): PMTemplate[] {
  const userTemplates = readTemplatesFile();
  return [...BUILT_IN_TEMPLATES, ...userTemplates];
}

/**
 * Get a single template by ID
 */
export function getTemplate(id: string): PMTemplate | null {
  const builtIn = BUILT_IN_TEMPLATES.find(t => t.id === id);
  if (builtIn) return builtIn;

  const userTemplates = readTemplatesFile();
  return userTemplates.find(t => t.id === id) || null;
}

/**
 * Save a user template
 */
export function saveTemplate(template: Omit<PMTemplate, 'builtIn' | 'createdAt' | 'updatedAt'>): PMTemplate {
  const templates = readTemplatesFile();
  const now = new Date().toISOString();
  
  const existing = templates.findIndex(t => t.id === template.id);
  const saved: PMTemplate = {
    ...template,
    builtIn: false,
    createdAt: existing >= 0 ? templates[existing].createdAt : now,
    updatedAt: now,
  };

  if (existing >= 0) {
    templates[existing] = saved;
  } else {
    templates.push(saved);
  }

  writeTemplatesFile(templates);
  return saved;
}

/**
 * Delete a user template (cannot delete built-in)
 */
export function deleteTemplate(id: string): boolean {
  if (BUILT_IN_TEMPLATES.some(t => t.id === id)) return false;
  
  const templates = readTemplatesFile();
  const filtered = templates.filter(t => t.id !== id);
  if (filtered.length === templates.length) return false;
  
  writeTemplatesFile(filtered);
  return true;
}
