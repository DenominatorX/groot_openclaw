import { NextResponse } from 'next/server';
import { getIronSession } from 'iron-session';
import { cookies } from 'next/headers';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import fs from 'fs';
import path from 'path';

const AUTH_PATH = path.join(process.cwd(), 'data', 'auth.json');

export type McUser = {
  id?: string;
  name?: string | null;
  email?: string | null;
  image?: string | null;
  role?: string | null;
};

export async function checkAuth(): Promise<{ authenticated: boolean; user?: McUser; error?: NextResponse }> {
  try {
    // 1. Check NextAuth session first (OAuth users — Google sign-in)
    try {
      const nextAuthSession = await getServerSession(authOptions);
      if (nextAuthSession?.user) {
        return { authenticated: true, user: nextAuthSession.user as any };
      }
    } catch {
      // NextAuth not available, fall through to iron-session
    }

    // 2. Fall back to iron-session (password auth)
    if (!fs.existsSync(AUTH_PATH)) {
      return { authenticated: false, error: NextResponse.json({ error: 'Setup required' }, { status: 403 }) };
    }
    const auth = JSON.parse(fs.readFileSync(AUTH_PATH, 'utf8'));
    if (!auth.passwordHash) {
      return { authenticated: false, error: NextResponse.json({ error: 'Setup required' }, { status: 403 }) };
    }

    const session = await getIronSession<{ authenticated: boolean }>(await cookies(), {
      password: auth.sessionSecret,
      cookieName: 'mc_session',
    });

    if (!session.authenticated) {
      return { authenticated: false, error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
    }

    return { authenticated: true };
  } catch {
    return { authenticated: false, error: NextResponse.json({ error: 'Auth error' }, { status: 500 }) };
  }
}

// Wrapper for protected API routes
export function withAuth(handler: () => Promise<NextResponse>): () => Promise<NextResponse> {
  return async () => {
    const auth = await checkAuth();
    if (!auth.authenticated) return auth.error!;
    return handler();
  };
}
