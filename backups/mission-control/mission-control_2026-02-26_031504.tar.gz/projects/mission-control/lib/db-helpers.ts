/**
 * Database helper functions for Mission Control
 * These replace direct JSON file reads with SQLite queries.
 */
import { getDb } from './database';

// Types
export interface Project {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  [key: string]: any;
}

// New types for enhanced task features (F3)
export interface TeamMember {
  agentId: string;
  role: string;
  model: string;
  rationale: string;
}

export interface AnalysisResult {
  viability: 'still_needed' | 'already_implemented' | 'superseded' | 'too_complex';
  existingFeatureMatch?: string;
  complexity: 'simple' | 'moderate' | 'complex' | 'very_complex';
  suggestedProjectIds?: string[];
  suggestedProjectTitles?: string[];
  team: TeamMember[];
  gameplan: string;
  estimatedCost: string;
  reasoning: string;
  analyzedAt: string;
}

export interface LogEntry {
  ts: string;
  agent: string;
  message: string;
  type: 'info' | 'progress' | 'success' | 'error';
}

export interface ChatMessage {
  id: string;
  agentId: string;
  role: 'user' | 'agent';
  content: string;
  ts: string;
}

export interface Task {
  id: string;
  title: string;
  column: string;
  assignee: string;
  priority: string;
  tags: string[];
  created: string;
  description: string;
  dueDate?: string;
  // New fields for Task Intelligence (F3) - all backward compatible
  instructions?: string;
  teamComposition?: TeamMember[];
  analysisResult?: AnalysisResult;
  executionLog?: LogEntry[];
  executionStatus?: 'idle' | 'running' | 'complete' | 'failed';
  teamChat?: ChatMessage[];
  completedFeatureId?: string;
  pipelineStatus?: 'backlog' | 'active' | 'review' | 'done';
  // Existing linking fields
  projectId?: string;
  parentTaskId?: string | null;
  childProjectIds?: string[];
  creator?: string;
  [key: string]: any;
}

export interface Issue {
  id: string;
  issueNumber: string;
  title: string;
  description: string;
  category: string;
  status: string;
  priority: string;
  assignee: string;
  resolution?: string;
  updatedAt: string;
  [key: string]: any;
}

export interface Agent {
  id: string;
  name: string;
  displayName: string;
  role: string;
  title: string;
  tier: number;
  status: string;
  [key: string]: any;
}

export interface AgentTier {
  tier_id: string;
  label: string;
  defaultModel: string | null;
}

export interface AgentSessionState {
  agent_id: string;
  status: 'idle' | 'active' | 'busy';
  current_task: string | null;
  last_task_at: string | null;
  tasks_completed: number;
  model: string | null;
}

// ============ USERS ============

export interface User {
  id: string;
  google_id: string;
  email: string;
  name: string | null;
  avatar_url: string | null;
  role: 'admin' | 'user' | 'viewer';
  created_at: string;
  updated_at: string;
  last_login_at: string | null;
  onboarding_completed: number;
}

export interface UserSettings {
  user_id: string;
  theme: string;
  layout: string;
  pinned_agents: string | null;
  dashboard_config: string | null;
  notifications_enabled: number;
  updated_at: string;
}

export interface UserChatHistory {
  id: number;
  user_id: string;
  agent_id: string;
  session_key: string | null;
  message: string;
  response: string | null;
  created_at: string;
}

// ============ PROJECTS ============

export function getProjects(): Project[] {
  const db = getDb();
  const rows = db.prepare('SELECT data FROM projects ORDER BY created_at DESC').all() as { data: string }[];
  return rows.map(row => JSON.parse(row.data));
}

export function getProject(id: string): Project | null {
  const db = getDb();
  const row = db.prepare('SELECT data FROM projects WHERE id = ?').get(id) as { data: string } | undefined;
  return row ? JSON.parse(row.data) : null;
}

export function saveProject(project: Project): void {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM projects WHERE id = ?').get(project.id);
  
  if (existing) {
    db.prepare(`UPDATE projects SET data = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(JSON.stringify(project), project.id);
  } else {
    db.prepare('INSERT INTO projects (id, data) VALUES (?, ?)')
      .run(project.id, JSON.stringify(project));
  }
}

export function deleteProject(id: string): void {
  const db = getDb();
  db.prepare('DELETE FROM projects WHERE id = ?').run(id);
}

// ============ TASKS ============

export function getTasks(projectId?: string): Task[] {
  const db = getDb();
  let rows;
  
  if (projectId) {
    rows = db.prepare('SELECT data FROM tasks WHERE project_id = ? ORDER BY created_at DESC')
      .all(projectId) as { data: string }[];
  } else {
    rows = db.prepare('SELECT data FROM tasks ORDER BY created_at DESC').all() as { data: string }[];
  }
  
  return rows.map(row => JSON.parse(row.data));
}

export function getTaskColumns(): string[] {
  const db = getDb();
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('taskColumns') as { value: string } | undefined;
  return row ? JSON.parse(row.value) : ['inbox', 'assigned', 'in-progress', 'review', 'complete'];
}

export function saveTask(task: Task): void {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM tasks WHERE id = ?').get(task.id);
  
  // Extract project_id from task if present
  const projectId = (task as any).projectId || null;
  
  if (existing) {
    db.prepare(`UPDATE tasks SET data = ?, project_id = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(JSON.stringify(task), projectId, task.id);
  } else {
    db.prepare('INSERT INTO tasks (id, project_id, data) VALUES (?, ?, ?)')
      .run(task.id, projectId, JSON.stringify(task));
  }
}

export function deleteTask(id: string): void {
  const db = getDb();
  db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
}

// ============ ISSUES ============

export function getIssues(): Issue[] {
  const db = getDb();
  const rows = db.prepare('SELECT data FROM issues ORDER BY updated_at DESC').all() as { data: string }[];
  return rows.map(row => JSON.parse(row.data));
}

export function getIssueCategories(): string[] {
  const db = getDb();
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('issueCategories') as { value: string } | undefined;
  return row ? JSON.parse(row.value) : [];
}

export function saveIssue(issue: Issue): void {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM issues WHERE id = ?').get(issue.id);
  
  if (existing) {
    db.prepare(`UPDATE issues SET data = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(JSON.stringify(issue), issue.id);
  } else {
    db.prepare('INSERT INTO issues (id, data) VALUES (?, ?)')
      .run(issue.id, JSON.stringify(issue));
  }
}

export function deleteIssue(id: string): void {
  const db = getDb();
  db.prepare('DELETE FROM issues WHERE id = ?').run(id);
}

// ============ SETTINGS ============

export function getSettings(): Record<string, any> {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
  
  const settings: Record<string, any> = {};
  for (const row of rows) {
    settings[row.key] = JSON.parse(row.value);
  }
  return settings;
}

export function getSetting<T>(key: string): T | null {
  const db = getDb();
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? JSON.parse(row.value) : null;
}

export function saveSetting(key: string, value: any): void {
  const db = getDb();
  const existing = db.prepare('SELECT key FROM settings WHERE key = ?').get(key);
  
  if (existing) {
    db.prepare(`UPDATE settings SET value = ?, updated_at = datetime('now') WHERE key = ?`)
      .run(JSON.stringify(value), key);
  } else {
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)')
      .run(key, JSON.stringify(value));
  }
}

// ============ AGENTS ============

export function getAgents(): Agent[] {
  const db = getDb();
  const rows = db.prepare('SELECT data FROM agents').all() as { data: string }[];
  return rows.map(row => JSON.parse(row.data));
}

export function getAgent(id: string): Agent | null {
  const db = getDb();
  const row = db.prepare('SELECT data FROM agents WHERE id = ?').get(id) as { data: string } | undefined;
  return row ? JSON.parse(row.data) : null;
}

export function getAgentTiers(): AgentTier[] {
  const db = getDb();
  const rows = db.prepare('SELECT tier_id, data FROM agent_tiers ORDER BY tier_id ASC').all() as { tier_id: string; data: string }[];
  return rows.map(row => ({
    tier_id: row.tier_id,
    ...JSON.parse(row.data)
  }));
}

export function saveAgent(agent: Agent): void {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM agents WHERE id = ?').get(agent.id);
  
  if (existing) {
    db.prepare(`UPDATE agents SET data = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(JSON.stringify(agent), agent.id);
  } else {
    db.prepare('INSERT INTO agents (id, data) VALUES (?, ?)')
      .run(agent.id, JSON.stringify(agent));
  }
}

export function deleteAgent(id: string): void {
  const db = getDb();
  db.prepare('DELETE FROM agents WHERE id = ?').run(id);
}

// ============ ACTIVITY LOG ============

export function logActivity(
  type: string,
  agentId: string | null,
  description: string,
  metadata?: any
): void {
  const db = getDb();
  db.prepare(`
    INSERT INTO activity_log (type, agent_id, description, metadata)
    VALUES (?, ?, ?, ?)
  `).run(type, agentId, description, metadata ? JSON.stringify(metadata) : null);
}

export function getActivityLog(limit: number = 100): any[] {
  const db = getDb();
  const rows = db.prepare(`
    SELECT id, type, agent_id, description, metadata, created_at 
    FROM activity_log 
    ORDER BY created_at DESC 
    LIMIT ?
  `).all(limit) as any[];
  
  return rows.map(row => ({
    id: row.id,
    agent: row.agent_id,
    action: row.type,
    details: row.description,
    metadata: row.metadata ? JSON.parse(row.metadata) : null,
    timestamp: row.created_at
  }));
}

// ============ AGENT SESSION STATE ============

export function getAgentSessionState(agentId: string): AgentSessionState | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM agent_session_state WHERE agent_id = ?').get(agentId) as any;
  return row || null;
}

export function getAllAgentSessionStates(): AgentSessionState[] {
  const db = getDb();
  return db.prepare('SELECT * FROM agent_session_state').all() as AgentSessionState[];
}

export function updateAgentSessionState(
  agentId: string,
  updates: Partial<AgentSessionState>
): void {
  const db = getDb();
  const existing = db.prepare('SELECT agent_id FROM agent_session_state WHERE agent_id = ?').get(agentId);
  
  const fields: string[] = [];
  const values: any[] = [];
  
  if (updates.status !== undefined) {
    fields.push('status = ?');
    values.push(updates.status);
  }
  if (updates.current_task !== undefined) {
    fields.push('current_task = ?');
    values.push(updates.current_task);
  }
  if (updates.last_task_at !== undefined) {
    fields.push('last_task_at = ?');
    values.push(updates.last_task_at);
  }
  if (updates.tasks_completed !== undefined) {
    fields.push('tasks_completed = ?');
    values.push(updates.tasks_completed);
  }
  if (updates.model !== undefined) {
    fields.push('model = ?');
    values.push(updates.model);
  }
  
  if (fields.length === 0) return;
  
  fields.push(`updated_at = datetime('now')`);
  values.push(agentId);
  
  if (existing) {
    db.prepare(`UPDATE agent_session_state SET ${fields.join(', ')} WHERE agent_id = ?`)
      .run(...values);
  } else {
    db.prepare(`
      INSERT INTO agent_session_state (agent_id, status, current_task, last_task_at, tasks_completed, model)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      agentId,
      updates.status || 'idle',
      updates.current_task || null,
      updates.last_task_at || null,
      updates.tasks_completed || 0,
      updates.model || null
    );
  }
}

// ============ USER CRUD ============

export function getUserByGoogleId(googleId: string): User | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE google_id = ?').get(googleId) as User | undefined;
  return row || null;
}

export function getUserById(id: string): User | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as User | undefined;
  return row || null;
}

export function getUserByEmail(email: string): User | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as User | undefined;
  return row || null;
}

export function createUser(user: {
  id: string;
  google_id: string;
  email: string;
  name?: string;
  avatar_url?: string;
}): User {
  const db = getDb();
  db.prepare(`
    INSERT INTO users (id, google_id, email, name, avatar_url)
    VALUES (?, ?, ?, ?, ?)
  `).run(user.id, user.google_id, user.email, user.name || null, user.avatar_url || null);
  
  // Create default settings for new user
  createUserSettings(user.id);
  
  return getUserById(user.id)!;
}

export function updateUser(id: string, updates: Partial<Pick<User, 'name' | 'avatar_url' | 'role' | 'onboarding_completed'>>): void {
  const db = getDb();
  const fields: string[] = ['updated_at = datetime("now")'];
  const values: any[] = [];

  if (updates.name !== undefined) {
    fields.push('name = ?');
    values.push(updates.name);
  }
  if (updates.avatar_url !== undefined) {
    fields.push('avatar_url = ?');
    values.push(updates.avatar_url);
  }
  if (updates.role !== undefined) {
    fields.push('role = ?');
    values.push(updates.role);
  }
  if (updates.onboarding_completed !== undefined) {
    fields.push('onboarding_completed = ?');
    values.push(updates.onboarding_completed);
  }

  values.push(id);
  db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values);
}

export function updateUserGoogleId(id: string, googleId: string): void {
  const db = getDb();
  db.prepare('UPDATE users SET google_id = ?, updated_at = datetime("now") WHERE id = ?').run(googleId, id);
}

export function updateUserLastLogin(id: string): void {
  const db = getDb();
  db.prepare('UPDATE users SET last_login_at = datetime("now") WHERE id = ?').run(id);
}

export function deleteUser(id: string): void {
  const db = getDb();
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
}

export function getAllUsers(): User[] {
  const db = getDb();
  return db.prepare('SELECT * FROM users ORDER BY created_at DESC').all() as User[];
}

// ============ USER SETTINGS ============

export function getUserSettings(userId: string): UserSettings | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(userId) as UserSettings | undefined;
  return row || null;
}

export function createUserSettings(userId: string): UserSettings {
  const db = getDb();
  db.prepare(`
    INSERT INTO user_settings (user_id, theme, layout, pinned_agents, dashboard_config, notifications_enabled)
    VALUES (?, 'dark', 'default', '[]', '{}', 1)
  `).run(userId);
  
  return getUserSettings(userId)!;
}

export function updateUserSettings(
  userId: string,
  updates: Partial<Pick<UserSettings, 'theme' | 'layout' | 'pinned_agents' | 'dashboard_config' | 'notifications_enabled'>>
): void {
  const db = getDb();
  const fields: string[] = ['updated_at = datetime("now")'];
  const values: any[] = [];
  
  if (updates.theme !== undefined) {
    fields.push('theme = ?');
    values.push(updates.theme);
  }
  if (updates.layout !== undefined) {
    fields.push('layout = ?');
    values.push(updates.layout);
  }
  if (updates.pinned_agents !== undefined) {
    fields.push('pinned_agents = ?');
    values.push(updates.pinned_agents);
  }
  if (updates.dashboard_config !== undefined) {
    fields.push('dashboard_config = ?');
    values.push(updates.dashboard_config);
  }
  if (updates.notifications_enabled !== undefined) {
    fields.push('notifications_enabled = ?');
    values.push(updates.notifications_enabled);
  }
  
  values.push(userId);
  db.prepare(`UPDATE user_settings SET ${fields.join(', ')} WHERE user_id = ?`).run(...values);
}

// ============ USER CHAT HISTORY ============

export function addChatMessage(msg: {
  user_id: string;
  agent_id: string;
  session_key?: string;
  message: string;
  response?: string;
}): number {
  const db = getDb();
  const result = db.prepare(`
    INSERT INTO user_chat_history (user_id, agent_id, session_key, message, response)
    VALUES (?, ?, ?, ?, ?)
  `).run(msg.user_id, msg.agent_id, msg.session_key || null, msg.message, msg.response || null);
  
  return result.lastInsertRowid as number;
}

export function getChatHistory(userId: string, agentId?: string, limit: number = 50): UserChatHistory[] {
  const db = getDb();
  
  if (agentId) {
    return db.prepare(`
      SELECT * FROM user_chat_history 
      WHERE user_id = ? AND agent_id = ?
      ORDER BY created_at DESC 
      LIMIT ?
    `).all(userId, agentId, limit) as UserChatHistory[];
  }
  
  return db.prepare(`
    SELECT * FROM user_chat_history 
    WHERE user_id = ?
    ORDER BY created_at DESC 
    LIMIT ?
  `).all(userId, limit) as UserChatHistory[];
}

export function clearChatHistory(userId: string, agentId?: string): void {
  const db = getDb();
  
  if (agentId) {
    db.prepare('DELETE FROM user_chat_history WHERE user_id = ? AND agent_id = ?').run(userId, agentId);
  } else {
    db.prepare('DELETE FROM user_chat_history WHERE user_id = ?').run(userId);
  }
}

// ============ AGENT CONVERSATIONS ============

export interface AgentConversation {
  id: string;
  agent_id: string;
  with_agent_id: string;
  session_key: string;
  message_count: number;
  started_at: string;
  last_message_at: string | null;
  summary: string | null;
}

export function createAgentConversation(conv: {
  id: string;
  agent_id: string;
  with_agent_id: string;
  session_key: string;
}): AgentConversation {
  const db = getDb();
  db.prepare(`
    INSERT INTO agent_conversations (id, agent_id, with_agent_id, session_key, message_count, started_at)
    VALUES (?, ?, ?, ?, 0, datetime('now'))
  `).run(conv.id, conv.agent_id, conv.with_agent_id, conv.session_key);
  
  return getAgentConversation(conv.id)!;
}

export function getAgentConversation(id: string): AgentConversation | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM agent_conversations WHERE id = ?').get(id) as AgentConversation | undefined;
  return row || null;
}

export function getAgentConversations(agentId: string): AgentConversation[] {
  const db = getDb();
  return db.prepare(`
    SELECT * FROM agent_conversations 
    WHERE agent_id = ? OR with_agent_id = ?
    ORDER BY last_message_at DESC
  `).all(agentId, agentId) as AgentConversation[];
}

export function updateAgentConversation(id: string, updates: Partial<{
  message_count: number;
  last_message_at: string;
  summary: string;
}>): void {
  const db = getDb();
  const fields: string[] = [];
  const values: any[] = [];
  
  if (updates.message_count !== undefined) {
    fields.push('message_count = ?');
    values.push(updates.message_count);
  }
  if (updates.last_message_at !== undefined) {
    fields.push('last_message_at = ?');
    values.push(updates.last_message_at);
  }
  if (updates.summary !== undefined) {
    fields.push('summary = ?');
    values.push(updates.summary);
  }
  
  if (fields.length === 0) return;
  values.push(id);
  
  db.prepare(`UPDATE agent_conversations SET ${fields.join(', ')} WHERE id = ?`).run(...values);
}

// ============ SUBAGENT RUNS ============

export interface SubagentRun {
  id: string;
  label: string;
  spawned_by: string;
  agent_id: string;
  model: string;
  task_summary: string;
  status: 'running' | 'completed' | 'failed';
  result_summary: string | null;
  cost_usd: number;
  duration_ms: number;
  started_at: string;
  completed_at: string | null;
}

export function createSubagentRun(run: {
  id: string;
  label: string;
  spawned_by: string;
  agent_id: string;
  model: string;
  task_summary: string;
}): SubagentRun {
  const db = getDb();
  db.prepare(`
    INSERT INTO subagent_runs (id, label, spawned_by, agent_id, model, task_summary, status, started_at)
    VALUES (?, ?, ?, ?, ?, ?, 'running', datetime('now'))
  `).run(run.id, run.label, run.spawned_by, run.agent_id, run.model, run.task_summary);
  
  return getSubagentRun(run.id)!;
}

export function getSubagentRun(id: string): SubagentRun | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM subagent_runs WHERE id = ?').get(id) as SubagentRun | undefined;
  return row || null;
}

export function getSubagentRuns(limit: number = 100): SubagentRun[] {
  const db = getDb();
  return db.prepare(`
    SELECT * FROM subagent_runs 
    ORDER BY started_at DESC 
    LIMIT ?
  `).all(limit) as SubagentRun[];
}

export function getSubagentRunsByAgent(spawnedBy: string): SubagentRun[] {
  const db = getDb();
  return db.prepare(`
    SELECT * FROM subagent_runs 
    WHERE spawned_by = ?
    ORDER BY started_at DESC
  `).all(spawnedBy) as SubagentRun[];
}

export function updateSubagentRun(id: string, updates: Partial<{
  status: 'running' | 'completed' | 'failed';
  result_summary: string;
  cost_usd: number;
  duration_ms: number;
  completed_at: string;
}>): void {
  const db = getDb();
  const fields: string[] = [];
  const values: any[] = [];
  
  if (updates.status !== undefined) {
    fields.push('status = ?');
    values.push(updates.status);
  }
  if (updates.result_summary !== undefined) {
    fields.push('result_summary = ?');
    values.push(updates.result_summary);
  }
  if (updates.cost_usd !== undefined) {
    fields.push('cost_usd = ?');
    values.push(updates.cost_usd);
  }
  if (updates.duration_ms !== undefined) {
    fields.push('duration_ms = ?');
    values.push(updates.duration_ms);
  }
  if (updates.completed_at !== undefined) {
    fields.push('completed_at = ?');
    values.push(updates.completed_at);
  }
  
  if (fields.length === 0) return;
  values.push(id);
  
  db.prepare(`UPDATE subagent_runs SET ${fields.join(', ')} WHERE id = ?`).run(...values);
}
