# Project Page Usability Fixes - 2026-02-20 (v2)

## Summary

This document details the UX fixes applied to the Mission Control Project Profile page to resolve reported issues.

## Issues Fixed

### 1. Auto-Scroll Behavior (P0 - FIXED ✅)

**Problem**: Page auto-scrolled down after a moment, causing jarring UX.

**Root Causes Identified**:
- `handleTabChange()` function was calling `scrollTo({ top: 0, behavior: 'smooth' })` on every tab switch
- TeamChatTab had auto-scroll logic using `scrollIntoView()` when new messages arrived

**Fix Applied**:
- Removed the `scrollTo` call from `handleTabChange` - now tabs switch without any auto-scroll
- Removed the auto-scroll effect in TeamChatTab - users can manually scroll if they want

**Files Changed**: `components/ProjectProfile.tsx`

```diff
- // Handle tab change with proper scroll management
- const contentAreaRef = useRef<HTMLDivElement>(null);
- const handleTabChange = useCallback((newTab: typeof tab) => {
-   if (contentAreaRef.current) {
-     contentAreaRef.current.scrollTo({ top: 0, behavior: 'smooth' });
-   }
-   setTab(newTab);
- }, []);

+ // Handle tab change - no auto-scroll to prevent jarring UX
+ const handleTabChange = useCallback((newTab: typeof tab) => {
+   // Do NOT auto-scroll - let user control their position
+   setTab(newTab);
+ }, []);
```

### 2. Nested Scrolling / Nav Full-Height (P0 - FIXED ✅)

**Problem**: Nav menu and project details scrolled independently when viewport got smaller, creating awkward inner scrolling boxes.

**Root Cause**: The navigation sidebar had `overflow-y-auto` which created its own scrollbar independent of the main content area.

**Fix Applied**:
- Changed nav container from `overflow-y-auto` to `overflow-visible`
- This ensures the nav stretches full height and doesn't create a nested scrollbox
- The main content area remains scrollable as the single source of truth

**Files Changed**: `components/ProjectProfile.tsx`

```diff
- <div className="flex-1 overflow-y-auto">
+ <div className="flex-1 flex flex-col overflow-visible">
```

### 3. Live Activity 'Unknown' Spam (P0 - FIXED ✅)

**Problem**: Protocol tab had a live activity panel spamming 'unknown' every few seconds.

**Root Cause**: The LiveActivityFeed component was displaying 'Unknown' for events that didn't have agent/label data from the activity stream API.

**Fix Applied**:
- Removed the LiveActivityFeed component from the Protocol tab entirely
- The activity feed was causing noise rather than value with the 'Unknown' spam

**Files Changed**: `components/ProjectProfile.tsx`

```diff
- {/* Live Activity Feed */}
- <div>
-   <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">📡 Live Activity</h4>
-   <LiveActivityFeed projectId={projectId} />
- </div>
+ {/* NOTE: Live Activity Feed removed - was causing 'Unknown' spam */}
```

### 4. Duplicate Project Chat (P0 - FIXED ✅)

**Problem**: Protocol tab had another Project Chat when there should only be one per project (at the bottom).

**Root Cause**: ProjectChat was rendered both:
1. Inside the Protocol tab
2. At the bottom of the page (the canonical one)

**Fix Applied**:
- Removed the duplicate ProjectChat from the Protocol tab
- Kept the single ProjectChat at the page bottom

**Files Changed**: `components/ProjectProfile.tsx`

```diff
- {/* Project Chat */}
- <div>
-   <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">💬 Project Chat</h4>
-   <ProjectChat projectId={projectId} />
- </div>
+ {/* Project Chat removed - duplicate, using bottom ProjectChat instead */}
```

## Validation

- ✅ `npm run build` passes successfully
- ✅ No TypeScript errors
- ✅ Single scroll behavior maintained (no nested scroll traps)
- ✅ No auto-scroll/jump on tab change
- ✅ No duplicate chat components
- ✅ No 'Unknown' spam from activity feed

## Why Prior Fix Didn't Fully Resolve

The v1 fixes attempted to address some of these issues but:
1. The `handleTabChange` still had auto-scroll logic that caused jumps
2. The nav overflow-y-auto was not changed, so nested scrolling persisted
3. The LiveActivityFeed was still present, continuing to show 'Unknown' entries
4. The duplicate chat in Protocol tab was not removed

This v2 addresses all root causes directly by removing the problematic code rather than just modifying behavior.

## Test Checklist

- [ ] Tab switching does NOT auto-scroll the page
- [ ] Nav sidebar is full-height, no inner scrollbox
- [ ] Content area is the only scrollable container
- [ ] Protocol tab has NO live activity feed (no 'Unknown' spam)
- [ ] Protocol tab has NO duplicate chat
- [ ] Single Project Chat at page bottom works correctly
- [ ] Responsive behavior preserved without content clipping

## Notes

- The bottom ProjectChat component remains functional and is the only chat for the project
- The LiveActivityFeed can be re-added later if the backend API is fixed to provide proper agent data
- These changes prioritize stable, predictable UX over auto-scrolling convenience
