# Mission Control Plugin Architecture

## Overview

Mission Control uses a modular plugin system to allow apps to be installed, enabled, configured, and disabled independently. Core features (agents, projects, tasks, issues, chat, settings) are built-in. Everything else is a plugin.

## Plugin Manifest

Each plugin lives in `plugins/<plugin-id>/` and contains a `manifest.json`:

```json
{
  "id": "maxtarget",
  "name": "MaxTarget",
  "version": "1.0.0",
  "description": "Full-stack marketing automation suite",
  "author": "Mission Control",
  "category": "app",
  "icon": "target",
  "routes": ["/api/apps/maxtarget"],
  "components": ["MaxTargetDashboard"],
  "settings": [
    { "key": "apiKey", "label": "API Key", "type": "secret" }
  ],
  "permissions": ["ai:call", "data:read", "data:write"],
  "requires": [],
  "openclawMinVersion": "0.1.0"
}
```

### Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | ✅ | Unique plugin identifier (kebab-case) |
| `name` | string | ✅ | Display name |
| `version` | string | ✅ | Semver version |
| `description` | string | ✅ | Short description |
| `author` | string | | Plugin author |
| `category` | enum | ✅ | `app`, `integration`, `theme`, `analytics` |
| `icon` | string | | Lucide icon name |
| `routes` | string[] | | API route prefixes the plugin owns |
| `components` | string[] | | UI components it provides |
| `settings` | PluginSetting[] | | User-configurable settings |
| `permissions` | string[] | | Required permission scopes |
| `requires` | Dependency[] | | Other plugins this depends on |
| `openclawMinVersion` | string | | Minimum OpenClaw version |

## Plugin Registry

Plugins are tracked in a SQLite `plugins` table:

```sql
CREATE TABLE IF NOT EXISTS plugins (
  id TEXT PRIMARY KEY,
  manifest JSON NOT NULL,
  enabled INTEGER DEFAULT 1,
  config JSON DEFAULT '{}',
  installed_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
```

## Plugin Lifecycle

```
discover → install → enable → configure → disable → uninstall
```

1. **Discover**: Scan `plugins/` directory for `manifest.json` files
2. **Install**: Insert manifest into `plugins` table (enabled=0)
3. **Enable**: Set `enabled=1`, plugin routes and UI become active
4. **Configure**: User updates plugin-specific settings via UI
5. **Disable**: Set `enabled=0`, routes return 404, UI hidden
6. **Uninstall**: Remove from `plugins` table (data optionally preserved)

## Plugin API Surface

Plugins can use:

- **Database**: `getDb()` from `lib/database.ts` — plugins create own tables prefixed with `plugin_<id>_`
- **Auth**: `checkAuth()` from `lib/api-auth.ts`
- **Activity Log**: `logActivity()` from `lib/activity.ts`
- **Settings**: `getSettings()` / `saveSetting()` from `lib/settings.ts`
- **AI**: Access to configured AI providers via environment variables
- **Plugin Config**: `getPluginConfig(id)` / `savePluginConfig(id, config)`

## Security Model

### Permission Scopes

| Scope | Description |
|-------|-------------|
| `data:read` | Read from the database |
| `data:write` | Write to the database |
| `ai:call` | Make AI API calls |
| `files:read` | Read from the filesystem |
| `files:write` | Write to the filesystem |
| `network:external` | Make external HTTP requests |
| `secrets:read` | Access stored secrets |

### Sandboxing

- Plugins can only access their own `plugin_<id>_*` database tables
- Plugin routes are namespaced under `/api/apps/<plugin-id>/`
- File storage is scoped to `data/apps/<plugin-id>/`
- Disabled plugins have their routes short-circuited with 404

## UI Integration

Plugins register UI presence through their manifest:

- **Sidebar Tab**: Plugins with `category: 'app'` get a sidebar entry with their `icon` and `name`
- **Pages**: Plugin components are lazy-loaded when the user navigates to `/apps/<plugin-id>`
- **Settings**: Plugin settings appear under Settings → Plugins → [Plugin Name]

### Route Middleware

A middleware checks `isPluginEnabled(id)` before routing to any plugin API endpoint. Disabled plugins return `{ error: "Plugin disabled", status: 404 }`.

## SaaS Tier Integration

Plugin availability can be gated by subscription tier:

```typescript
interface TierPluginAccess {
  tier: 'free' | 'pro' | 'enterprise';
  plugins: string[];  // Plugin IDs available at this tier
}
```

The plugin enable/disable flow checks tier access before allowing activation. This is enforced at the API layer, not the manifest.

## Migration Strategy

1. **Phase 1** (current): Create framework + manifests. No code moves.
2. **Phase 2**: Add middleware to gate existing routes behind plugin checks.
3. **Phase 3**: Refactor apps to be fully self-contained plugin packages.
4. **Phase 4**: Support third-party plugin installation from a registry.
