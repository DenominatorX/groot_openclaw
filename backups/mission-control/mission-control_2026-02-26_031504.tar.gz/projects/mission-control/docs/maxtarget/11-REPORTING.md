# Analytics & Reporting — Requirements Document

## Current State

**What exists now:**
- Main app has Analytics tab: Summary cards (Total Leads, MQLs, SQLs, Closed Won, Active Campaigns, Total Spent, Avg ROAS) + top campaigns list
- `ReportingPanel.tsx` with 7 tabs: Client Report, Proposal, Case Study, ROI, Pitch Deck, Review, Invoice
- **Client Report**: Input client, date range, metrics → AI generates report
- **Proposal**: Input client, services, budget → AI generates proposal
- **Case Study**: Input client, challenge, results → AI generates case study
- **ROI**: Input cost, revenue, conversions, LTV → AI calculates and explains ROI
- **Pitch Deck**: Static placeholder text
- **Review**: Static placeholder text
- **Invoice**: Input client, services, amount, due date → AI generates invoice

**What it actually does:**
- AI generates documents → display → copy to clipboard
- Analytics in main app shows summary cards with mock data (from `/api/apps/maxtarget/analytics`)

**Missing:**
- Real data in analytics (currently empty/null)
- Report scheduling
- Report templates library
- Automated report delivery
- Dashboard customization

---

## Gap Analysis

| Feature | Current | Databox/Superset | Gap |
|---------|---------|------------------|-----|
| Real Data | Empty/null | Live data connections | HIGH |
| Custom Dashboards | Not supported | Drag-drop widgets | HIGH |
| Scheduled Reports | Not supported | Email, Slack delivery | HIGH |
| Report Templates | AI generation | Template library | MEDIUM |
| Data Visualization | Summary cards only | Charts, graphs, tables | HIGH |
| KPI Tracking | Not tracked | Goal tracking | HIGH |
| Export | Copy text | PDF, CSV, scheduled | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Analytics Dashboard (Real)**
   - Connect to campaign data
   - Lead pipeline metrics
   - Campaign performance metrics
   - Summary cards with real numbers

2. **Custom Report Builder**
   - Select metrics to include
   - Date range picker
   - Group by: campaign, source, stage
   - Preview and export

3. **Report Templates**
   - Save generated reports as templates
   - Edit templates
   - Use templates for new reports

4. **Data Visualization**
   - Charts: line, bar, pie, area
   - Trend indicators
   - Comparison to previous period

### P2 — Should Have
5. **Scheduled Reports**
   - Set up recurring reports (daily, weekly, monthly)
   - Export to file (mock delivery)

6. **KPI Tracking**
   - Define KPI targets
   - Track progress
   - Alert on missed targets

7. **Client Portal (Mock)**
   - Generate shareable report links

### P3 — Nice to Have
8. **Dashboard Customization** — Drag-drop widgets
9. **Drill-down** — Click-through to details
10. **Real-time Data** — WebSocket updates

---

## Data Model

```typescript
interface AnalyticsSummary {
  // Pipeline
  totalLeads: number;
  mqls: number;
  sqls: number;
  opportunities: number;
  closedWon: number;
  closedLost: number;
  
  // Campaigns
  activeCampaigns: number;
  totalCampaigns: number;
  totalSpent: number;
  totalImpressions: number;
  totalClicks: number;
  totalConversions: number;
  
  // Calculated
  avgRoas: number;
  avgCpa: number;
  conversionRate: number;
  
  // Time periods
  period: { start: string; end: string };
  previousPeriod: { start: string; end: string };
  comparison: {
    leadsChange: number;
    revenueChange: number;
    roasChange: number;
  };
}

interface SavedReport {
  id: string;
  name: string;
  type: 'client_report' | 'proposal' | 'case_study' | 'roi' | 'invoice' | 'custom';
  
  // Content
  template: string;
  variables: Record<string, any>;
  
  // Scheduling
  schedule?: {
    frequency: 'daily' | 'weekly' | 'monthly';
    recipients: string[];
    nextRun: string;
  };
  
  // Metadata
  createdBy?: string;
  createdDate: string;
  updatedDate: string;
}

interface KPI {
  id: string;
  name: string;
  description?: string;
  
  // Configuration
  metric: string;
  target: number;
  period: 'daily' | 'weekly' | 'monthly' | 'quarterly';
  
  // Tracking
  currentValue: number;
  previousValue: number;
  trend: 'up' | 'down' | 'stable';
  
  // Alerts
  alertThreshold?: number; // percentage
  alertOnMiss: boolean;
}

interface ChartConfig {
  id: string;
  name: string;
  type: 'line' | 'bar' | 'pie' | 'area' | 'number';
  
  // Data
  metric: string;
  dimensions?: string[];
  filters?: Filter[];
  dateRange: { start: string; end: string };
  
  // Display
  title?: string;
  showLegend: boolean;
  colors?: string[];
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Report Generation** | Current: Generate. Add: Save as template | P1 |
| **Insights** | AI identifies key findings from data | P1 |
| **Forecasting** | AI predicts future metrics | P2 |
| **Recommendations** | AI suggests actions based on trends | P2 |

---

## UI/UX Recommendations

### Analytics Dashboard
- Header: Date range picker, refresh button
- KPI cards row: Lead, MQL, SQL, Won
- Charts row: Traffic, Conversions, Revenue
- Campaign performance table

### Report Builder
- Step 1: Select type
- Step 2: Configure parameters
- Step 3: Preview
- Step 4: Export/Schedule

### Report List
- Table: Name, type, last generated, schedule
- Actions: Run, Edit, Duplicate, Delete

---

## Acceptance Criteria

- [ ] Analytics dashboard shows real data from campaigns/leads
- [ ] KPI cards display with trend indicators
- [ ] Charts render with campaign data
- [ ] Can create and save reports
- [ ] Report templates can be reused
- [ ] AI generates client reports, proposals, case studies
- [ ] ROI calculator works with real data
- [ ] Invoice generation works
- [ ] Data persists to database
