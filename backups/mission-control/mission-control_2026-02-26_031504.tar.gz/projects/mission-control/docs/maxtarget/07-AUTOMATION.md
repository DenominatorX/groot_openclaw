# Marketing Automation — Requirements Document

## Current State

**What exists now:**
- `AutomationPanel.tsx` with 3 tabs: Builder, Templates, Simulator
- **Builder Tab**: Visual representation of triggers, conditions, actions
  - Left panel: Trigger buttons (Form Submit, Page Visit, etc.)
  - Middle panel: Condition options (If score > X, If industry = Y, etc.)
  - Right panel: Action options (Send Email, Add Tag, etc.)
  - Flow editing: Select flow → add steps (condition/action/wait)
  - Active toggle (persists to local state only)
- **Templates Tab**: Static list of 5 pre-built flows (Welcome Sequence, Lead Nurture, etc.) — "Use Template" button creates flow
- **Simulator Tab**: Select flow and test lead → run simulation (mock results)

**What it actually does:**
- UI for building automation flows
- Flows stored in local React state (not persisted)
- Steps are descriptions only (no execution engine)
- Templates are read-only examples
- Simulator shows mock results

**Missing:**
- Execution engine (triggers don't actually fire)
- Real trigger integrations (webhooks, form submissions)
- Action execution (emails don't send, tags don't apply)
- Flow analytics (enrollments, completions, drop-offs)
- Version control

---

## Gap Analysis

| Feature | Current | HubSpot/Marketo | Gap |
|---------|---------|-----------------|-----|
| Execution Engine | Not supported | Real-time trigger handling | HIGH |
| Trigger Types | UI only | Webhooks, forms, scores, dates | HIGH |
| Action Execution | Not supported | Email, CRM, SMS, notifications | HIGH |
| Flow Analytics | Not supported | Enrollment, completion, drop-off | HIGH |
| Version Control | Not supported | Rollback, version history | MEDIUM |
| Testing | Mock simulation | Step-by-step debug mode | MEDIUM |
| Templates | Static list | Template library with categories | MEDIUM |
| Visual Editor | Basic UI | Drag-drop, validation, preview | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Automation Engine (Core)**
   - Execute flows when triggers fire
   - Process steps sequentially
   - Handle conditions and branching
   - Execute actions (mock initially)

2. **Trigger System**
   - Webhook receiver for external triggers
   - Form submission triggers
   - Score threshold triggers
   - Manual trigger (button click)

3. **Action Types**
   - Send email (queue for sending)
   - Add/remove tag
   - Update lead score
   - Create task
   - Notify (internal notification)

4. **Flow Management**
   - Create, edit, delete flows
   - Activate/deactivate flows
   - Duplicate flows

### P2 — Should Have
5. **Flow Analytics**
   - Enrollment count
   - Step completion rates
   - Drop-off points
   - Flow performance metrics

6. **Testing/Debug Mode**
   - Run flow with test data
   - Step-by-step execution view
   - Error logging

7. **Condition Types**
   - Lead score comparison
   - Field value (equals, contains)
   - Activity presence
   - Contact tag presence

### P3 — Nice to Have
8. **Advanced Actions** — CRM sync, SMS, HTTP webhooks
9. **Wait Conditions** — Wait for duration, wait until date, wait for activity
10. **A/B Automation** — Branch testing within flows

---

## Data Model

```typescript
interface AutomationFlow {
  id: string;
  name: string;
  description?: string;
  status: 'draft' | 'active' | 'paused';
  
  trigger: {
    type: 'form_submit' | 'page_visit' | 'score_threshold' | 'date' | 'webhook' | 'manual';
    config: {
      formId?: string;
      pageUrl?: string;
      scoreThreshold?: number;
      operator?: 'greater_than' | 'less_than' | 'equals';
      cronExpression?: string;
      webhookPath?: string;
    };
  };
  
  steps: AutomationStep[];
  
  // Analytics
  enrolledCount: number;
  completedCount: number;
  
  // Metadata
  createdBy?: string;
  createdDate: string;
  updatedDate: string;
  lastRunDate?: string;
}

interface AutomationStep {
  id: string;
  order: number;
  type: 'trigger' | 'condition' | 'action' | 'wait' | 'split';
  
  config: {
    // Condition
    field?: string;
    operator?: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than';
    value?: any;
    
    // Action
    actionType?: 'send_email' | 'add_tag' | 'remove_tag' | 'update_score' | 'create_task' | 'notify';
    emailTemplateId?: string;
    tagId?: string;
    scoreDelta?: number;
    taskTitle?: string;
    notifyMessage?: string;
    
    // Wait
    duration?: number;
    unit?: 'minutes' | 'hours' | 'days';
    
    // Split
    branches?: Array<{
      name: string;
      condition: any;
    }>;
  };
}

interface AutomationEnrollment {
  id: string;
  flowId: string;
  contactId: string;
  currentStepId: string;
  status: 'active' | 'completed' | 'failed' | 'paused';
  startedAt: string;
  completedAt?: string;
  stepHistory: Array<{
    stepId: string;
    enteredAt: string;
    exitedAt?: string;
    result: 'success' | 'failed' | 'skipped';
  }>;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Flow Builder** | AI suggests flow structure based on goal | P1 |
| **Condition Recommendations** | AI recommends conditions based on common patterns | P2 |
| **Optimization** | AI identifies underperforming flows and suggests fixes | P2 |
| **Template Generation** | AI creates flows from description | P2 |

---

## UI/UX Recommendations

### Flow Builder
- Canvas-based visual editor
- Drag steps from palette
- Connect steps with lines
- Click step to configure
- Validate flow before activation

### Flow List
- Table: Name, status, enrolled, completed rate
- Quick actions: Edit, Activate, Duplicate, Delete

### Analytics
- Funnel visualization: enrolled → completed
- Step-by-step conversion rates
- Time to complete

---

## Acceptance Criteria

- [ ] Can create automation flows with triggers and actions
- [ ] Flows persist to database
- [ ] Can activate/deactivate flows
- [ ] Trigger system processes events (mock OK)
- [ ] Actions execute (mock OK for email, real for tags/score)
- [ ] Flow analytics show enrollment/completion
- [ ] Templates can be used to create flows
- [ ] AI suggests flow configurations
- [ ] Mobile-responsive flow list
