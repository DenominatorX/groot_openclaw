# Conversion Rate Optimization (CRO) — Requirements Document

## Current State

**What exists now:**
- `ConversionPanel.tsx` with 5 tabs: Audit, CTA, Form, Proof, Pricing
- **Audit Tab**: Input page URL/description → AI generates CRO audit with recommendations
- **CTA Tab**: Input goal + audience → AI generates CTA button text variants
- **Form Tab**: Input current fields → AI optimizes form (fewer fields, better order)
- **Proof Tab**: Input data points → AI generates social proof elements
- **Pricing Tab**: Input tiers + features → AI optimizes pricing page

**What it actually does:**
- AI generates optimization suggestions → copy to clipboard
- No real page analysis, no A/B testing, no tracking

**Missing:**
- A/B testing framework
- Form analytics
- Heatmaps and session recordings
- Real page audits with actual data

---

## Gap Analysis

| Feature | Current | Optimizely/VWO | Gap |
|---------|---------|----------------|-----|
| A/B Testing | Not supported | Create variants, allocate traffic | HIGH |
| Heatmaps | Not supported | Click, scroll, attention maps | HIGH |
| Session Recording | Not supported | Visitor behavior replay | HIGH |
| Form Analytics | Not supported | Field-level conversion tracking | HIGH |
| Personalization | Not supported | Visitor segment-based content | HIGH |
| Testing Analytics | Not supported | Statistical significance, confidence | HIGH |

---

## Requirements

### P1 — Must Have
1. **A/B Test Manager**
   - Create tests with variants
   - Traffic allocation settings
   - Goal definition (conversion, click, time on page)
   - Status management (draft, running, paused, completed)

2. **Test Results Dashboard**
   - Show variant performance
   - Conversion rates, lift
   - Statistical significance indicator
   - Confidence level

3. **CTA Library**
   - Save generated CTAs
   - Organize by use case
   - A/B test CTAs

4. **Form Optimizer**
   - Input current form fields
   - AI suggestions for optimization
   - Track form submissions

### P2 — Should Have
5. **Heatmap Integration (Mock)**
   - Mock click/attention maps for demo
   - Issue identification

6. **Conversion Funnel**
   - Define funnel steps
   - Track drop-off points
   - Funnel visualization

7. **Personalization Rules**
   - Define audience segments
   - Assign content variants to segments

### P3 — Nice to Have
8. **Session Recordings** — Mock viewer
9. **Real Heatmaps** — Integration with Hotjar/FullStory
10. **Dynamic Content** — Personalization engine

---

## Data Model

```typescript
interface ABTest {
  id: string;
  name: string;
  description?: string;
  pageUrl: string;
  status: 'draft' | 'running' | 'paused' | 'completed';
  
  // Configuration
  trafficAllocation: number; // percentage
  variants: TestVariant[];
  goal: {
    type: 'conversion' | 'click' | 'time_on_page' | 'scroll_depth';
    targetElement?: string;
  };
  
  // Results
  startDate?: string;
  endDate?: string;
  results?: {
    totalVisitors: number;
    conversions: number;
    confidence: number;
    winner?: string;
    variantResults: {
      [variantId: string]: {
        visitors: number;
        conversions: number;
        conversionRate: number;
        lift: number;
      };
    };
  };
  
  createdDate: string;
}

interface TestVariant {
  id: string;
  name: string; // "Control", "Variant A", etc.
  changes: {
    type: 'text' | 'style' | 'element' | 'redirect';
    selector?: string;
    content?: string;
    styles?: Record<string, string>;
  }[];
}

interface CTA {
  id: string;
  text: string;
  useCase: string;
  category?: string;
  testedIn?: string; // Test ID
  results?: {
    clicks: number;
    conversionRate: number;
  };
  createdDate: string;
}

interface FormOptimization {
  id: string;
  formUrl: string;
  fields: FormField[];
  submissions: number;
  abandonmentRate?: number;
  suggestions: string[];
}

interface FormField {
  name: string;
  label: string;
  type: string;
  required: boolean;
  order: number;
  conversionRate?: number; // If tracked
}

interface ConversionFunnel {
  id: string;
  name: string;
  steps: FunnelStep[];
  dateRange: { start: string; end: string };
  totalVisitors: number;
  conversionRate: number;
}

interface FunnelStep {
  id: string;
  name: string;
  urlPattern: string;
  visitors: number;
  dropoff: number;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **CTA Generation** | Current: Generate variants. Add: A/B test recommendations | P1 |
| **Form Optimization** | Current: Suggest fewer fields. Add: Reorder based on data | P1 |
| **Audit Generation** | Current: AI suggestions. Add: Prioritized by impact | P1 |
| **Social Proof** | Current: Generate elements. Add: Test effectiveness | P2 |
| **Variant Suggestions** | AI recommends changes based on best practices | P2 |

---

## UI/UX Recommendations

### A/B Test Dashboard
- List of tests with status
- Quick create button
- Results summary per test

### Test Editor
- URL input
- Visual editor for variants (mock)
- Traffic slider
- Goal configuration

### Results View
- Variant cards with metrics
- Primary metric highlighted
- Confidence indicator (color-coded)
- Charts: Conversion over time

---

## Acceptance Criteria

- [ ] Can create A/B tests with multiple variants
- [ ] Can configure traffic allocation
- [ ] Test results show conversion rates and lift
- [ ] Statistical confidence displayed
- [ ] CTA library stores and retrieves CTAs
- [ ] Form optimizer suggests improvements
- [ ] AI generates audit recommendations
- [ ] Data persists to database
