# Project Stats & Plan Integrity Fixes

**Date:** 2026-02-20  
**Status:** ✅ Implemented

---

## Summary

Implemented fixes for project stats integrity, model attribution, timezone correctness, plan-generator ownership, and completion gating in Mission Control.

---

## Files Changed

### 1. `app/api/plan/generate/route.ts`

**Changes:**
- Added `getPMModel()` function to determine the model for plan generation based on the project's assigned PM (Project Manager)
- If no PM assigned, falls back to Groot's model, then to `anthropic/claude-opus-4-6`
- Uses PM's assigned model for plan generation API calls instead of hardcoded `claude-haiku-4-5`
- Expanded the plan generation prompt to include all required sections:
  - Executive Summary
  - Phases with milestones
  - Tasks per Phase with agent assignments
  - **Handoffs** - Clear handoff points between agents/teams
  - **Validations** - Code review checkpoints, testing requirements, documentation sign-offs
  - **Security Checks** - Input validation, authentication/authorization, data protection
  - **Agent Check-ins** - Status update frequency, escalation criteria
  - **Deliverables** - PRD, Design Doc, Tech Spec, Test Plan for each phase
  - **Lifecycle Coverage** - Initialization, execution, monitoring, cleanup
  - Risk Mitigation
  - Dependencies & Blockers
  - Timeline
  - Success Criteria
  - **Completion Checklist** - Required checklist before marking project complete

**Before:** Hardcoded model `claude-haiku-4-5`, basic plan structure  
**After:** Uses PM's assigned model, comprehensive plan with handoffs, validations, security checks, agent check-ins, lifecycle coverage, and completion checklist

---

### 2. `components/ActivityFeed.tsx`

**Changes:**
- Added `formatTimestamp()` function with timezone safety
- Added future timestamp detection (allows 1 minute tolerance for clock skew)
- Logs warning when future timestamp detected
- Returns "⚠️ future" indicator instead of showing incorrect future dates

**Before:** Could display timestamps in the future due to timezone conversion bugs  
**After:** Validates timestamps, prevents display of future dates, shows warning indicator

---

### 3. `components/LiveActivityFeed.tsx`

**Changes:**
- Added future timestamp detection in `formatTime()` function
- Logs warning when future timestamp detected
- Returns "⚠️" indicator for invalid timestamps

**Before:** Could display future timestamps  
**After:** Validates and shows warning indicator for future timestamps

---

### 4. `components/ProjectProfile.tsx`

**Changes (Stats Tab):**

- **Agent Breakdown Table:**
  - Added "Model" column showing the model used by each agent
  - Prefers actual usage data (from API calls), falls back to agent's default model
  - Shows abbreviated model name (e.g., "grok-4" instead of full path)

- **Activity Timeline:**
  - Added timestamp validation to prevent showing future dates
  - Shows "⚠️ future" indicator if timestamp is in the future
  - Uses consistent timezone conversion with error handling

**Before:** Stats showed only agent name, tokens, cost, tasks; no model column  
**After:** Stats include model column, proper timezone handling, future date prevention

---

### 5. `app/api/projects/route.ts`

**Changes:**
- Added `validateProjectCompletion()` function to check if project can be marked complete
- Validates:
  - All phases are complete
  - All tasks are complete
  - All goals are complete
  - Required documents exist (README.md, PRD.md)
- Modified PATCH handler to block completion with clear error message if requirements not met
- Returns structured error response with `code: 'COMPLETION_BLOCKED'` and list of reasons

**Before:** Could mark project as complete without any validation  
**After:** Validates phases, tasks, goals, and documents before allowing completion; returns clear failure reasons

---

## Validation

- ✅ `npm run build` - Passed
- No test harness found (no existing tests)
- Changes are production-safe and minimal-risk

---

## API Response Examples

### Completion Gating Error Response

```json
{
  "error": "Cannot complete project - requirements not met",
  "code": "COMPLETION_BLOCKED",
  "reasons": [
    "2 phase(s) incomplete: Phase 1, Phase 2",
    "5 task(s) incomplete",
    "Missing required documents: PRD.md"
  ],
  "hint": "Complete all phases, tasks, goals, and required documents before marking as complete"
}
```

### Plan Generation Response (with PM Model)

```json
{
  "plan": "...",
  "pmModel": "anthropic/claude-opus-4-6"
}
```

---

## Notes

- Timestamps are stored in UTC (ISO 8601) and rendered in local timezone
- Future timestamp detection allows 1 minute tolerance for clock skew
- Stats rollups use real API usage data from `/api/usage` endpoint
- Plan generation now requires PM model and includes completion checklist in output
