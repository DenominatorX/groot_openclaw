# VR Mode PRD — Mission Control v3

## 1. Overview

**VR Mode** transforms Mission Control into an immersive 3D virtual command center. Users can interact with key dashboard data (tasks, health, agents, chat) in a futuristic sci-fi environment—either via VR headset (WebXR) or desktop (orbit controls + mouse).

> **Feasibility Note:** Target hardware is M4 Mac Mini (16GB RAM). Three.js with low-poly geometry and minimal textures will run at 60fps without issue. WebXR requires compatible browser (Safari TP or Chrome with headset).

---

## 2. User Experience

### 2.1 The Virtual Command Center

A dark sci-fi room with:
- **Floor**: Reflective dark grid (GridHelper, subtle glow)
- **Walls**: Semi-transparent dark panels with cyan accent lighting
- **Ceiling**: Open to space/stars with subtle particle effect
- **Ambient**: Cyan/magenta accent lights, low fog

### 2.2 Floating Panels (Holographic UI)

Four floating data panels positioned around the user:

| Panel | Position | Data Shown |
|-------|----------|-------------|
| **Task Board** | Front-left | Kanban summary: todo/in-progress/done counts, current sprint tasks |
| **Health Vitals** | Front-right | Oura data: sleep score, readiness, HRV, resting HR |
| **Agent Status** | Back-left | Grid of agent avatars with status indicators (active/idle/error) |
| **Brain Chat** | Back-right | Quick access to Brain agent for voice commands |

### 2.3 Interaction Modes

**Desktop Mode (Fallback — Default):**
- OrbitControls: rotate view with mouse drag
- Zoom: scroll wheel
- Click panel → expand to full view
- Keyboard: WASD for fly-through, ESC to exit panel

**VR Mode (WebXR):**
- Enter VR button in corner
- Gaze cursor for selection
- Controller pointing for panel interaction
- Teleport locomotion (optional)

### 2.4 Visual Design

- **Color Palette**: 
  - Background: `#0a0a0f` (near black)
  - Accent Primary: `#00ffff` (cyan)
  - Accent Secondary: `#ff00ff` (magenta)
  - Panel Glass: `rgba(0, 20, 40, 0.8)` with blur
  - Text: `#e0e0e0` (light gray)
  
- **Typography**: Monospace/terminal aesthetic (JetBrains Mono or system mono)
- **Effects**: Subtle bloom on accent elements, panel hover glow

---

## 3. Technical Architecture

### 3.1 Component Structure

```
components/
├── VRMode.tsx          # Main wrapper, mode detection
├── VRCanvas.tsx        # React Three Fiber canvas (client-only dynamic import)
├── CommandRoom.tsx     # 3D scene: room geometry, lights, panels
├── FloatingPanel.tsx   # Reusable holographic panel component
├── TaskPanel.tsx       # Task board data visualization
├── HealthPanel.tsx     # Health vitals display
├── AgentGridPanel.tsx  # Agent status grid
└── BrainChatPanel.tsx  # Brain chat interface
```

### 3.2 Data Flow

- VRMode fetches data on mount from existing MC API routes:
  - `/api/tasks` → task counts
  - `/api/health` or `/api/oura/summary` → health data
  - `/api/agents` → agent status
  - `/api/brain/chat` → recent messages
- Data passed as props to panels
- Polling every 30s for live updates

### 3.3 Performance Optimizations (M4 Mac Mini)

- **Dynamic import**: `next/dynamic` with `ssr: false` for Three.js components
- **Low-poly geometry**: BoxGeometry, PlaneGeometry, simple shapes
- **No textures**: Procedural materials only (MeshStandardMaterial with colors/emissive)
- **Instance meshes**: For repeated elements (agent dots)
- **Frustum culling**: Default Three.js behavior
- **Target**: 60fps at 1080p

### 3.4 WebXR Integration

- `@react-three/xr` for WebXR support
- Fallback to OrbitControls when VR unavailable
- "Enter VR" button only shown when `navigator.xr` is supported
- Session management: requestSession on button click

---

## 4. Phase Plan

### Phase 1: Prototype (This Sprint) ✅
- [x] PRD creation
- [x] Basic 3D room with 4 floating panels
- [x] Desktop orbit controls
- [x] Mock data (no API yet)
- [x] Build verification

### Phase 2: Data Integration (Next Sprint)
- [ ] Connect to MC API routes for real data
- [ ] Implement polling/real-time updates
- [ ] Panel click → expand modal with details

### Phase 3: VR Support
- [ ] WebXR integration with @react-three/xr
- [ ] Gaze/pointer selection
- [ ] Controller support

### Phase 4: Polish
- [ ] Animations (panel float, data transitions)
- [ ] Sound effects (ambient, interaction)
- [ ] Performance tuning

---

## 5. Acceptance Criteria

1. ✅ VRMode component renders without SSR errors
2. ✅ 3D room displays with 4 floating panels
3. ✅ OrbitControls allow desktop navigation
4. ✅ Build passes: `npx next build` completes without errors
5. ✅ VR tab appears in sidebar navigation
6. ✅ Aesthetic matches Agent World (dark sci-fi)
7. ✅ Responsive: works on desktop, graceful degradation on mobile (static view)

---

## 6. Dependencies

Already installed:
- `three` (v0.172.0)
- `@react-three/fiber` (v9.1.2)
- `@react-three/drei` (v10.0.0)

To add for VR:
- `@react-three/xr` (WebXR support)

---

## 7. File Changes

| File | Action |
|------|--------|
| `VR_MODE_PRD.md` | Create (this file) |
| `components/VRMode.tsx` | Create |
| `components/TabNavSidebar.tsx` | Add 'vr' to Tab type and nav |
| `app/page.tsx` | Import and render VRMode |
| `data/projects.json` | Add VR Mode project entry |

---

*PRD Version: 1.0*  
*Created: 2026-02-14*  
*Status: Phase 1 Complete*
