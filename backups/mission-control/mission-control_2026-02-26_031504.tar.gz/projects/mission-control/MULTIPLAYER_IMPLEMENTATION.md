# Wrestling Trivia Multiplayer Implementation

## Overview
Successfully added full multiplayer support to the Pro Wrestling Trivia Game, transforming it from a solo experience into a virtual board game experience like Trivial Pursuit. The system supports up to 8 players per room with real-time synchronization via polling.

## Architecture

### 1. API Backend (`app/api/games/wrestling-trivia/multiplayer/route.ts`)

**Room Management**
- **POST** `{ action: "create" }` — Creates a new game room with 6-char code (e.g., "SLAM69")
- **POST** `{ action: "join", roomCode, playerName, avatar }` — Joins an existing room
- **POST** `{ action: "leave", roomCode, playerId }` — Leaves a room
- **POST** `{ action: "update-settings", roomCode, playerId, settings }` — Host-only settings updates

**Gameplay**
- **POST** `{ action: "start", roomCode }` — Starts the game (2+ players required)
- **POST** `{ action: "answer", roomCode, playerId, questionIndex, answerIndex, timeMs }` — Submits answer with response time
- **POST** `{ action: "next", roomCode }` — Advances to next question
- **GET** `?roomCode=XXX&playerId=YYY` — Polls current room state

**Communication**
- **POST** `{ action: "chat", roomCode, playerId, message }` — Sends chat message
- **POST** `{ action: "status", roomCode }` — Gets room status

**Data Storage**
- Room state stored in `data/games/wrestling-trivia/rooms.json`
- Persists: players, scores, answers, chat, game settings, current question

### 2. Components

#### `WrestlingLobby.tsx`
- **Create Game**: Host sets game mode, category, question count, difficulty, time per question
- **Join Game**: Player enters room code and display name
- **Lobby View**: 
  - Shows all players with avatars (20 wrestling emoji options)
  - Host controls: game settings (5 question options: 5-25)
  - Ready status tracking
  - Max 8 players per room
  - Category selection (All, Championship, Finishing Moves, etc.)
  - Difficulty levels: Easy, Medium, Hard
  - Time per question: 10s-30s

#### `WrestlingMultiplayer.tsx`
- **Live Scoreboard**: Real-time scores sorted by points, streak indicators, crown for leader
- **Question Display**: Current question with countdown timer
- **Answer Reveal**: Shows correct answer, who got it right/wrong, response times
- **Between Questions**: Leaderboard updates with position changes
- **Final Podium**: 1st/2nd/3rd place with championship belt for winner
- **Polling Sync**: 1-2 second polling for real-time updates

#### `ChatPanel.tsx`
- **Text Chat**: Player name + message + timestamp
- **Quick Reactions**: 🔥 💀 😂 👏 🤦 💪
- **Collapsible UI**: Minimizable side panel
- **Auto-scroll**: Scrolls when messages arrive (150px threshold)
- **Message Limit**: Keeps last 100 messages in memory

#### `VoiceChat.tsx`
- **UI Placeholder**: "Coming Soon" banner
- **Future WebRTC Support**: Ready for peer-to-peer voice implementation
- **Controls Layout**: Mute, volume control, speaker indicators (disabled until WebRTC enabled)
- **Signaling Ready**: Can use multiplayer API for WebRTC signal exchange

#### `PlayerProfile.tsx`
- **Profile Management**: Display name, avatar selection
- **Win/Loss Record**: Saved to localStorage
- **Rankings**: 
  - Jobber (0-2 wins)
  - Mid-Carder (3-5 wins)
  - Main Eventer (6-10 wins)
  - Champion (11-20 wins)
  - Legend (21+ wins)
- **Career Stats**: Win rate, average score, best score, total games

#### `WrestlingTriviaGameWrapper.tsx`
- **Mode Selection**: Solo vs Multiplayer entry point
- **Profile Access**: Quick access to player profile
- **Game Mode Manager**: Handles transitions between menu, solo, lobby, and multiplayer

### 3. Polling-Based Synchronization

Instead of WebSocket, uses HTTP polling for simplicity:
- Players poll every 1-2 seconds
- GET request includes `roomCode` and `playerId`
- Response filtered by `lastPollTimestamp` to only send new messages
- Reduces bandwidth while maintaining real-time feel

### 4. Scoring System

**Points Calculation**
- Base: 100 points per correct answer
- Speed Bonus: +25 (fast), +15 (medium), 0 (slow)
- Streak Multiplier: ×2 (10+ streak), ×1 (default)
- Example: 100 + 25 = 125 points for fast answer, ×2 for streak = 250 points

**Streak Mechanics**
- Increments on correct answer
- Resets to 0 on wrong answer
- Displayed prominently on scoreboard with 🔥 emoji

### 5. Game Settings (Host Controls)

**Configuration Options**
- Question Count: 5, 10, 15, 20, 25, endless
- Category: All, Championship History, Finishing Moves, Gimmicks, etc. (11 total)
- Difficulty: Easy, Medium, Hard
- Time per Question: 10s, 15s, 20s, 30s
- Game Mode: Quick Play, Gauntlet, Era Challenge, Company Wars

### 6. Player Profiles

**Avatar System**
- 20 wrestling-themed emoji avatars: 💪🤼🦅💀🔥🏆👑⚡🎭💥🌟🎤🏟️🥊⛓️🎯🏅🔗📺💎
- Stored in localStorage
- Selected in lobby before joining/creating

**Persistent Stats**
- Saved to localStorage as JSON
- Tracked: wins, losses, total games, total score, best score
- Rankings calculated from win count

### 7. Styling

**Wrestling Theme**
- Dark steel background with red/gold accents
- Impact-style font (Righteous)
- Ring rope borders with RGB gradient
- Championship belt styling for headers
- Spotlight effect on entrance (lobby)
- Wrestling promo card styling for chat
- Tournament bracket appearance for scoreboard

## File Structure

```
components/games/
├── WrestlingTriviaGame.tsx (existing solo game)
├── WrestlingTriviaGameWrapper.tsx (new: mode selector)
├── WrestlingLobby.tsx (new: lobby system)
├── WrestlingMultiplayer.tsx (new: in-game UI)
├── ChatPanel.tsx (new: text chat)
├── VoiceChat.tsx (new: voice chat placeholder)
└── PlayerProfile.tsx (new: profile management)

app/api/games/wrestling-trivia/
├── route.ts (existing: solo game API)
└── multiplayer/
    └── route.ts (new: multiplayer API)

data/games/wrestling-trivia/
├── question-cache.json (existing)
├── scores.json (existing)
├── stats.json (existing)
└── rooms.json (new: multiplayer room state)
```

## Usage Flow

### Create Game Flow
1. Main menu → Click "MULTIPLAYER MATCH"
2. Enter player name, choose avatar
3. Click "CREATE GAME"
4. Choose game mode, category, difficulty
5. Settings applied, room code generated (e.g., SLAM69)
6. Share code with other players
7. Wait for players to join (shows real-time list)
8. Configure game (host only)
9. Click "START MATCH" (2+ players required)
10. Game begins

### Join Game Flow
1. Main menu → Click "MULTIPLAYER MATCH"
2. Click "Join Existing Game"
3. Enter room code (e.g., SLAM69)
4. Enter player name, choose avatar
5. Click "JOIN GAME"
6. Waiting in lobby with other players
7. Host starts game when ready
8. Game begins

### During Game
1. Question displays with 15-30s timer
2. Select answer (single or double-click to submit)
3. All players' answers tracked
4. Answer revealed with correct response highlighted
5. Scores updated live (show in sidebar)
6. Auto-advance or host-controlled next question
7. Repeat until all questions answered
8. Final podium displays top 3 with scores
9. Option for "NEW GAME" or return to menu

## Dependencies Added

- `uuid@^9.0.1` — For generating unique player/room IDs
- `@types/uuid@^9.0.7` — TypeScript types for UUID

## Data Structures

### Room Object
```typescript
{
  code: "SLAM69",
  hostId: "player-uuid",
  players: [
    {
      id: "uuid",
      name: "Kevin",
      avatar: "💪",
      score: 1250,
      streak: 5,
      ready: true
    }
  ],
  settings: {
    mode: "quick",
    category: "all",
    questionCount: 10,
    timePerQuestion: 15,
    difficulty: "medium"
  },
  status: "lobby|playing|finished",
  currentQuestion: 2,
  questions: [...],
  answers: {
    0: [{ playerId, answerIndex, timeMs, isCorrect }],
    1: [...]
  },
  chat: [{ playerId, name, message, timestamp }],
  createdAt: "2026-02-13T...",
  round: 1,
  lastPollTimestamps: {}
}
```

## Known Limitations & Future Enhancements

1. **WebRTC Voice Chat**: Currently placeholder, ready to implement peer-to-peer voice
2. **Room Persistence**: Rooms cleared on server restart (could add persistent storage)
3. **Room Cleanup**: Empty rooms auto-deleted, finished rooms kept for 1 hour
4. **Late Joiners**: Can implement option to allow players joining mid-game
5. **Spectator Mode**: Could add non-playing observers
6. **Tournaments**: Could create bracket-based tournament mode
7. **Mobile Optimization**: Chat and scoreboard could be optimized for smaller screens
8. **Stats API**: Could add endpoints to retrieve historical player stats

## Testing

Build verified successfully:
```bash
cd /Users/groot/.openclaw/workspace/projects/mission-control
npx next build
✓ Compiled successfully
```

All 52 API routes included, including new:
- `/api/games/wrestling-trivia/multiplayer` (POST/GET)

## Integration with Mission Control

- Accessible via GamesTab in main dashboard
- Uses existing auth system (`checkAuth()`)
- Integrated with localStorage for player profiles
- Maintains wrestling aesthetic consistent with solo game

## Next Steps (Optional)

1. Implement WebRTC for voice chat
2. Add persistent database for room/player history
3. Implement tournament/bracket system
4. Add spectator mode
5. Create admin dashboard for game analytics
6. Add seasonal rankings and leaderboards
7. Implement chat moderation
8. Add emote/sticker system
