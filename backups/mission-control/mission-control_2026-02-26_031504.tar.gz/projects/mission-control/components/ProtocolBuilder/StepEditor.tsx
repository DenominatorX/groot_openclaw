'use client';

import React from 'react';
import { ProtocolStep } from './ProtocolBuilderTab';

// Predefined options
const AGENT_OPTIONS = [
  'groot', 'pixel', 'nova', 'spark', 'forge', 'brain', 'ceo', 
  'sentinel', 'atlas', 'swift', 'viper', 'oracle', 'dirty-bird', 'floof', 'architect'
];

const MODEL_OPTIONS = [
  'openrouter/minimax/minimax-m2.5',
  'anthropic/claude-opus-4-6',
  'openrouter/google/gemini-2.5-pro',
  'x-ai/grok-3',
  'x-ai/grok-4',
  'openrouter/x-ai/grok-4.1-fast',
  'openrouter/google/gemini-3-pro-preview',
  'lmstudio/gemma-3-12b',
];

const STEP_TYPES = [
  { value: 'task', label: 'Task' },
  { value: 'approval', label: 'Approval' },
  { value: 'notification', label: 'Notification' },
  { value: 'checkpoint', label: 'Checkpoint' },
];

interface StepEditorProps {
  step: ProtocolStep;
  index: number;
  allSteps: ProtocolStep[];
  onUpdate: (updates: Partial<ProtocolStep>) => void;
  onRemove: () => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
}

export default function StepEditor({
  step,
  index,
  allSteps,
  onUpdate,
  onRemove,
  onMoveUp,
  onMoveDown,
}: StepEditorProps) {
  // Get potential dependency options (exclude self)
  const dependencyOptions = allSteps
    .filter(s => s.id !== step.id)
    .map(s => ({ id: s.id, label: `${s.id} (${s.name || s.agent || 'unassigned'})` }));

  return (
    <div className={`bg-mc-bg border rounded-lg transition-colors ${
      step.enabled 
        ? 'border-mc-border' 
        : 'border-mc-border/30 opacity-60'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-mc-border/30">
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={step.enabled}
            onChange={(e) => onUpdate({ enabled: e.target.checked })}
            className="w-4 h-4 rounded border-mc-border text-mc-accent focus:ring-mc-accent"
          />
          <span className="text-xs font-mono text-mc-muted">P{index + 1}</span>
          <input
            type="text"
            value={step.id}
            onChange={(e) => onUpdate({ id: e.target.value })}
            className="bg-transparent border-none text-sm font-medium text-mc-text focus:outline-none focus:ring-0 w-28"
            placeholder="step-id"
          />
          <input
            type="text"
            value={step.name || ''}
            onChange={(e) => onUpdate({ name: e.target.value })}
            className="bg-transparent border border-mc-border rounded px-2 py-0.5 text-xs text-mc-muted focus:outline-none focus:border-mc-accent w-24"
            placeholder="Step name"
          />
          <select
            value={step.type || 'task'}
            onChange={(e) => onUpdate({ type: e.target.value as ProtocolStep['type'] })}
            className="text-[10px] bg-mc-surface border border-mc-border rounded px-1.5 py-0.5 text-mc-text"
          >
            {STEP_TYPES.map(t => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={onMoveUp}
            disabled={index === 0}
            className="p-1 text-mc-muted hover:text-mc-text disabled:opacity-30 text-xs"
            title="Move up"
          >
            ↑
          </button>
          <button
            onClick={onMoveDown}
            disabled={index === allSteps.length - 1}
            className="p-1 text-mc-muted hover:text-mc-text disabled:opacity-30 text-xs"
            title="Move down"
          >
            ↓
          </button>
          <button
            onClick={onRemove}
            className="p-1 text-mc-muted hover:text-red-400 text-xs ml-1"
            title="Remove step"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Fields */}
      <div className="p-3 grid grid-cols-2 gap-x-4 gap-y-2">
        {/* Agent */}
        <div>
          <label className="text-[10px] text-mc-muted block mb-1">Agent</label>
          <select
            value={step.agent || ''}
            onChange={(e) => onUpdate({ agent: e.target.value })}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
          >
            <option value="">Select agent...</option>
            {AGENT_OPTIONS.map(a => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </div>

        {/* Model */}
        <div>
          <label className="text-[10px] text-mc-muted block mb-1">Model</label>
          <select
            value={step.model || ''}
            onChange={(e) => onUpdate({ model: e.target.value })}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
          >
            <option value="">Select model...</option>
            {MODEL_OPTIONS.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>

        {/* Timeout */}
        <div>
          <label className="text-[10px] text-mc-muted block mb-1">Timeout (min)</label>
          <input
            type="number"
            min="1"
            max="60"
            value={step.timeoutMin || 5}
            onChange={(e) => onUpdate({ timeoutMin: parseInt(e.target.value) || 5 })}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
          />
        </div>

        {/* Retries */}
        <div>
          <label className="text-[10px] text-mc-muted block mb-1">Retries</label>
          <input
            type="number"
            min="0"
            max="5"
            value={step.retries || 0}
            onChange={(e) => onUpdate({ retries: parseInt(e.target.value) || 0 })}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
          />
        </div>

        {/* Approval Required */}
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id={`approval-${step.id}`}
            checked={step.approvalRequired || false}
            onChange={(e) => onUpdate({ approvalRequired: e.target.checked })}
            className="w-3.5 h-3.5 rounded border-mc-border text-mc-accent focus:ring-mc-accent"
          />
          <label htmlFor={`approval-${step.id}`} className="text-xs text-mc-text">
            Requires approval
          </label>
        </div>

        {/* Depends On */}
        <div className="col-span-2">
          <label className="text-[10px] text-mc-muted block mb-1">Depends On</label>
          <select
            value={step.dependsOn || ''}
            onChange={(e) => onUpdate({ dependsOn: e.target.value || undefined })}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
          >
            <option value="">No dependency (root step)</option>
            {dependencyOptions.map(opt => (
              <option key={opt.id} value={opt.id}>{opt.label}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}
