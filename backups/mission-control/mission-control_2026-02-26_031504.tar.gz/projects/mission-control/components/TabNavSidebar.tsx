'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export type Tab = 'dashboard' | 'kanban' | 'projects' | 'reports' | 'analytics' | 'usage-ledger' | 'health' | 'home' | 'chat' | 'my-stuff' | 'apps' | 'games' | 'trading' | 'issues' | 'teams' | 'features' | 'vr' | 'tests' | 'brain' | 'vcb';

interface TabGroup {
  label: string;
  id: string;
  tabs: Array<{ id: Tab; label: string; icon: string }>;
}

interface TabNavSidebarProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  isMobile: boolean;
  pathname?: string;
}

export default function TabNavSidebar({ activeTab, onTabChange, isMobile, pathname = '/' }: TabNavSidebarProps) {
  const [collapsed, setCollapsed] = useState(true);
  const [mounted, setMounted] = useState(false);
  const [hoveredTab, setHoveredTab] = useState<Tab | null>(null);

  // Get tab from pathname
  const getTabFromPath = (path: string): Tab => {
    const pathToTab: Record<string, Tab> = {
      '/': 'dashboard',
      '/brain': 'brain',
      '/kanban': 'kanban',
      '/projects': 'projects',
      '/teams': 'teams',
      '/issues': 'issues',
      '/reports': 'reports',
      '/analytics': 'analytics',
      '/usage-ledger': 'usage-ledger',
      '/chat': 'chat',
      '/health': 'health',
      '/home': 'home',

  
      '/my-stuff': 'my-stuff',
      '/apps': 'apps',
      '/games': 'games',
      '/trading': 'trading',
      '/features': 'features',
      '/vr': 'vr',
      '/tests': 'tests',
      '/vcb': 'vcb',
    };
    return pathToTab[path] || 'dashboard';
  };

  const currentTab = getTabFromPath(pathname);

  // Load collapsed state from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('mc-nav-collapsed');
    if (saved !== null) {
      setCollapsed(JSON.parse(saved));
    }
    setMounted(true);
  }, []);

  // Save collapsed state to localStorage
  const toggleCollapsed = () => {
    const newState = !collapsed;
    setCollapsed(newState);
    localStorage.setItem('mc-nav-collapsed', JSON.stringify(newState));
  };

  // Default nav order — can be overridden via saved navOrder in localStorage
  const DEFAULT_GROUPS: TabGroup[] = [
    {
      label: 'HOME',
      id: 'home-group',
      tabs: [
        { id: 'dashboard', label: 'Home', icon: '🏠' },
      ],
    },
    {
      label: 'COMMAND',
      id: 'command',
      tabs: [
        { id: 'kanban', label: 'Kanban', icon: '📋' },
        { id: 'projects', label: 'Projects', icon: '📁' },
        { id: 'teams', label: 'Teams', icon: '👥' },
        { id: 'issues', label: 'Issues Log', icon: '🛡️' },
        { id: 'vcb', label: 'VCB', icon: '🌿' },
        { id: 'tests', label: 'Tests', icon: '🧪' },
        { id: 'reports', label: 'Reports', icon: '📄' },
        { id: 'trading', label: 'Trading', icon: '📈' },
        { id: 'brain', label: 'Brain', icon: '🧠' },
      ],
    },
    {
      label: 'MONITOR',
      id: 'monitor',
      tabs: [
        { id: 'health', label: 'Health', icon: '❤️' },
        { id: 'home', label: 'Smart Home', icon: '💡' },
      ],
    },
    {
      label: 'COMMUNICATE',
      id: 'communicate',
      tabs: [{ id: 'chat', label: 'Chat', icon: '💬' }],
    },

    {
      label: 'TOOLS',
      id: 'tools',
      tabs: [
        { id: 'apps', label: 'Apps', icon: '📱' },
        { id: 'analytics', label: 'Analytics', icon: '📊' },
        { id: 'usage-ledger', label: 'Usage Ledger', icon: '🧾' },
        { id: 'my-stuff', label: 'My Stuff', icon: '🗂️' },
      ],
    },
    {
      label: 'SYSTEM',
      id: 'system',
      tabs: [
        { id: 'features', label: 'Features', icon: '🧩' },
        { id: 'games', label: 'Games', icon: '🎮' },
        { id: 'vr', label: 'VR Mode', icon: '🥽' },
      ],
    },
  ];

  const groups = DEFAULT_GROUPS;

  const [mobileDrawer, setMobileDrawer] = useState(false);

  if (!mounted) return null;

  const pinnedTabs = [
    { id: 'dashboard', label: 'Home', icon: '🏠' },
    { id: 'kanban', label: 'Tasks', icon: '📋' },
    { id: 'chat', label: 'Chat', icon: '💬' },
    { id: 'health', label: 'Health', icon: '❤️' },
  ];

  // Helper to get href from tab
  const getHref = (tab: Tab): string => {
    return tab === 'dashboard' ? '/' : `/${tab}`;
  };

  // Helper to check if tab is active
  const isActive = (tab: Tab): boolean => {
    const href = getHref(tab);
    return pathname === href || (tab === 'dashboard' && pathname === '/');
  };

  if (isMobile) {
    return (
      <>
        {/* Bottom bar: 4 pinned + More button */}
        <div className="fixed bottom-0 left-0 right-0 bg-mc-surface border-t border-mc-border flex items-center px-1 py-1 gap-0.5 z-40">
          {pinnedTabs.map((tab) => {
            const href = getHref(tab.id as Tab);
            const active = pathname === href || (tab.id === 'dashboard' && pathname === '/');
            return (
              <Link
                key={tab.id}
                href={href}
                className={`flex-1 py-1.5 px-1 rounded text-[10px] flex flex-col items-center gap-0.5 transition-colors ${
                  active && !mobileDrawer
                    ? 'bg-mc-accent/20 text-mc-accent'
                    : 'text-mc-muted hover:text-mc-text'
                }`}
              >
                <span className="text-base">{tab.icon}</span>
                <span className="line-clamp-1">{tab.label}</span>
              </Link>
            );
          })}
          <button
            onClick={() => setMobileDrawer(d => !d)}
            className={`flex-1 py-1.5 px-1 rounded text-[10px] flex flex-col items-center gap-0.5 transition-colors ${
              mobileDrawer ? 'bg-mc-accent/20 text-mc-accent' : 'text-mc-muted hover:text-mc-text'
            }`}
          >
            <span className="text-base">⋯</span>
            <span>More</span>
          </button>
        </div>

        {/* Full nav drawer */}
        {mobileDrawer && (
          <>
            <div className="fixed inset-0 bg-black/50 z-30" onClick={() => setMobileDrawer(false)} />
            <div className="fixed bottom-[52px] left-0 right-0 bg-mc-surface border-t border-mc-border rounded-t-xl z-40 max-h-[70vh] overflow-y-auto shadow-2xl">
              <div className="px-4 py-2 border-b border-mc-border flex items-center justify-between">
                <span className="text-xs font-bold text-mc-muted uppercase">All Pages</span>
                <button onClick={() => setMobileDrawer(false)} className="text-mc-muted text-sm">✕</button>
              </div>
              <div className="p-2">
                {groups.map((group) => (
                  <div key={group.id} className="mb-2">
                    <div className="px-2 py-1">
                      <span className="text-[10px] font-bold text-mc-muted/60 uppercase tracking-wider">{group.label}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1">
                      {group.tabs.map((tab) => {
                        const href = getHref(tab.id);
                        const active = pathname === href || (tab.id === 'dashboard' && pathname === '/');
                        return (
                          <Link
                            key={tab.id}
                            href={href}
                            onClick={() => setMobileDrawer(false)}
                            className={`py-2 px-1 rounded flex flex-col items-center gap-1 text-[10px] transition-colors ${
                              active
                                ? 'bg-mc-accent/20 text-mc-accent font-medium'
                                : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                            }`}
                          >
                            <span className="text-xl">{tab.icon}</span>
                            <span className="line-clamp-1 text-center">{tab.label}</span>
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </>
    );
  }

  return (
    <>
      {/* Sidebar */}
      <aside
        className={`
          fixed left-0 top-0 bottom-0 bg-mc-surface border-r border-mc-border overflow-y-auto
          transition-all duration-300 ease-in-out z-30
          ${collapsed ? 'w-16' : 'w-52'}
          flex flex-col
        `}
      >
        {/* Toggle Button */}
        <div className="flex-shrink-0 p-2 border-b border-mc-border">
          <button
            onClick={toggleCollapsed}
            className={`w-full py-2 px-2 rounded flex items-center justify-center transition-colors text-mc-muted hover:text-mc-text hover:bg-mc-bg ${
              collapsed ? '' : 'justify-start gap-2'
            }`}
            title={collapsed ? 'Expand' : 'Collapse'}
          >
            <span className="text-lg">≡</span>
            {!collapsed && <span className="text-sm font-medium">Navigation</span>}
          </button>
        </div>

        {/* Tab Groups */}
        <nav className="flex-1 overflow-y-auto flex flex-col gap-1 p-2">
          {groups.map((group) => (
            <div key={group.id} className="flex flex-col gap-1">
              {/* Group Label */}
              {!collapsed && (
                <div className="px-2 pt-2 pb-1">
                  <span className="text-xs font-bold text-mc-muted/70 uppercase tracking-wide">
                    {group.label}
                  </span>
                </div>
              )}

              {/* Group Divider (collapsed mode) */}
              {collapsed && group !== groups[0] && (
                <div className="my-0.5 border-t border-mc-border/30" />
              )}

              {/* Tabs in Group */}
              {group.tabs.map((tab) => {
                const href = getHref(tab.id);
                const active = pathname === href || (tab.id === 'dashboard' && pathname === '/');
                return (
                  <div key={tab.id} className="relative group">
                    <Link
                      href={href}
                      onMouseEnter={() => setHoveredTab(tab.id)}
                      onMouseLeave={() => setHoveredTab(null)}
                      className={`
                        w-full py-2 px-3 rounded flex items-center gap-3
                        transition-all duration-150 ease-out
                        ${
                          active
                            ? 'bg-mc-accent/20 text-mc-accent font-medium'
                            : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                        }
                        ${collapsed ? 'justify-center' : 'justify-start'}
                      `}
                      title={tab.label}
                    >
                      <span className="text-lg flex-shrink-0">{tab.icon}</span>
                      {!collapsed && <span className="text-sm font-medium truncate">{tab.label}</span>}
                    </Link>

                    {/* Tooltip (collapsed mode) */}
                    {collapsed && hoveredTab === tab.id && (
                      <div className="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-3 py-1.5 bg-mc-bg border border-mc-border rounded whitespace-nowrap text-xs font-medium text-mc-text pointer-events-none z-50 shadow-lg">
                        {tab.label}
                        <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-mc-bg" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Retired section removed (Agent World/older dashboards not needed) */}

        {/* Add New Page Button */}
        <div className="p-2 border-t border-mc-border flex-shrink-0">
          <button
            onClick={() => onTabChange('_new' as Tab)}
            className={`w-full py-2 px-2 rounded flex items-center transition-colors text-mc-muted hover:text-mc-accent hover:bg-mc-accent/10 ${
              collapsed ? 'justify-center' : 'justify-start gap-2'
            }`}
            title="Add new page / idea"
          >
            <span className="text-lg">➕</span>
            {!collapsed && <span className="text-sm font-medium">New Idea</span>}
          </button>
        </div>
      </aside>

      {/* Click-outside overlay to collapse expanded nav */}
      {!collapsed && (
        <div
          className="fixed inset-0 z-20"
          onClick={() => { setCollapsed(true); localStorage.setItem('mc-nav-collapsed', 'true'); }}
        />
      )}
    </>
  );
}