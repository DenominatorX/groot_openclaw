'use client';
import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import MarkdownMessage from './MarkdownMessage';

const CHARACTER_EMOJIS: Record<string, string> = {
  lobster: '🦞', robot: '🤖', humanoid: '🧑', orb: '🔮',
  mech: '⚙️', ghost: '👻', cat: '🐱', tree: '🌳', bee: '🐝', dragonfly: '🪰', hillbilly: '🤠',
};

interface Room {
  id: string; name: string; description: string; icon: string;
  members: string[]; theme: string;
}

interface Agent {
  id: string; name: string; displayName?: string; color: string; avatarType?: string; isExecutiveBoard?: boolean; voice?: string | null;
}

interface Message {
  id: string; room: string; sender: string; senderName: string; senderColor: string; senderEmoji: string;
  text: string; type: 'message' | 'system'; timestamp: string;
  replyTo?: string; pinned?: boolean; meetingId?: string;
}

interface RoomActivity {
  lastMessage?: { text: string; sender: string; timestamp: string };
  unread: number;
  activeMembers: number;
}

export default function ChatRoom() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [currentRoom, setCurrentRoom] = useState('boardroom');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [typingAgents, setTypingAgents] = useState<string[]>([]);
  const [meetingActive, setMeetingActive] = useState(false);
  const [responseStyle, setResponseStyle] = useState('balanced');
  const [meetingTopic, setMeetingTopic] = useState('');
  const [showMeetingInput, setShowMeetingInput] = useState(false);
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [mentionIdx, setMentionIdx] = useState(0);
  const [hoveredMsg, setHoveredMsg] = useState<string | null>(null);
  const [showRoomSettings, setShowRoomSettings] = useState(false);
  const [showNewRoom, setShowNewRoom] = useState(false);
  const [newRoom, setNewRoom] = useState({ id: '', name: '', icon: '💬', description: '', theme: 'default' });
  const [editRoom, setEditRoom] = useState<Room | null>(null);
  const [roomActivity, setRoomActivity] = useState<Record<string, RoomActivity>>({});
  const [lastSeenTimestamps, setLastSeenTimestamps] = useState<Record<string, string>>({});
  const messagesEnd = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Fetch rooms
  useEffect(() => {
    fetch('/api/rooms').then(r => r.json()).then(d => {
      if (d.rooms?.length) setRooms(d.rooms);
    }).catch(() => {});
  }, []);

  // Fetch agents
  useEffect(() => {
    fetch('/api/agents').then(r => r.json()).then(d => setAgents(d.agents || [])).catch(() => {});
  }, []);

  const fetchMessages = useCallback(async () => {
    try {
      const r = await fetch(`/api/chat?room=${currentRoom}`);
      const d = await r.json();
      setMessages(d.messages || []);
      if (d.typing) setTypingAgents(d.typing);
      if (d.meetingActive !== undefined) setMeetingActive(d.meetingActive);
    } catch {}
  }, [currentRoom]);

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 3000);
    return () => clearInterval(interval);
  }, [fetchMessages]);

  // Track last seen for unread counts
  useEffect(() => {
    if (messages.length > 0) {
      setLastSeenTimestamps(prev => ({ ...prev, [currentRoom]: new Date().toISOString() }));
    }
  }, [currentRoom, messages.length]);

  // Fetch activity for all rooms periodically
  useEffect(() => {
    if (rooms.length === 0) return;
    const fetchActivity = async () => {
      const activity: Record<string, RoomActivity> = {};
      for (const room of rooms) {
        try {
          const r = await fetch(`/api/chat?room=${room.id}`);
          const d = await r.json();
          const msgs: Message[] = d.messages || [];
          const lastMsg = msgs.filter(m => m.type === 'message').slice(-1)[0];
          const lastSeen = lastSeenTimestamps[room.id];
          const unread = lastSeen
            ? msgs.filter(m => m.type === 'message' && m.timestamp > lastSeen && m.sender !== 'kevin').length
            : (room.id !== currentRoom ? msgs.filter(m => m.type === 'message' && m.sender !== 'kevin').length : 0);
          const typing = d.typing || [];
          activity[room.id] = {
            lastMessage: lastMsg ? { text: lastMsg.text, sender: lastMsg.senderName, timestamp: lastMsg.timestamp } : undefined,
            unread: room.id === currentRoom ? 0 : unread,
            activeMembers: ((room.members || []).length - 1) + typing.length, // approximate
          };
        } catch {
          activity[room.id] = { unread: 0, activeMembers: 0 };
        }
      }
      setRoomActivity(activity);
    };
    fetchActivity();
    const interval = setInterval(fetchActivity, 10000);
    return () => clearInterval(interval);
  }, [rooms, currentRoom, lastSeenTimestamps]);

  const prevMsgCount = useRef(0);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // Only auto-scroll if user is already near the bottom (within 300px)
    if (messages.length > prevMsgCount.current && chatContainerRef.current) {
      const el = chatContainerRef.current;
      const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 300;
      if (isNearBottom) {
        messagesEnd.current?.scrollIntoView({ behavior: 'auto', block: 'end' });
      }
    }
    prevMsgCount.current = messages.length;
  }, [messages]);

  const pinnedMessages = useMemo(() => messages.filter(m => m.pinned), [messages]);

  const roomMembers = useMemo(() => {
    const room = rooms.find(r => r.id === currentRoom);
    const ids = room ? (room.members || []).filter(m => m !== 'kevin') : [];
    return agents.filter(a => ids.includes(a.id));
  }, [currentRoom, agents, rooms]);

  const filteredMentionAgents = useMemo(() => {
    if (mentionQuery === null) return [];
    const q = mentionQuery.toLowerCase();
    const matched = agents.filter(a => a.id !== 'kevin' && (a.displayName || a.name).toLowerCase().includes(q));
    // Add @everyone option
    if ('everyone'.includes(q)) {
      matched.unshift({ id: 'everyone', name: 'Everyone', displayName: 'Everyone', color: '#eab308', avatarType: 'orb', isExecutiveBoard: false, voice: null } as Agent);
    }
    return matched;
  }, [mentionQuery, agents]);

  const sendMessage = async () => {
    if (!input.trim() || sending) return;
    setSending(true);
    try {
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          room: currentRoom, sender: 'kevin', senderName: 'Kevin',
          senderColor: '#3b82f6', senderEmoji: '🧑', text: input.trim(),
          type: 'message', replyTo: replyTo?.id || undefined, responseStyle,
        }),
      });
      setInput(''); setReplyTo(null); setMentionQuery(null);
      await fetchMessages();
    } catch {}
    setSending(false);
  };

  const startMeeting = async () => {
    if (!meetingTopic.trim()) return;
    setSending(true);
    try {
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          room: currentRoom, sender: 'kevin', senderName: 'Kevin',
          senderColor: '#3b82f6', senderEmoji: '🧑',
          text: meetingTopic.trim(), type: 'message', meeting: 'start', responseStyle,
        }),
      });
      setMeetingTopic(''); setShowMeetingInput(false);
      await fetchMessages();
    } catch {}
    setSending(false);
  };

  const endMeeting = async () => {
    try {
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          room: currentRoom, sender: 'kevin', senderName: 'Kevin',
          senderColor: '#3b82f6', senderEmoji: '🧑',
          text: '📋 Meeting ended.', type: 'system', meeting: 'end',
        }),
      });
      await fetchMessages();
    } catch {}
  };

  const pinMessage = async (msgId: string) => {
    try {
      await fetch('/api/chat', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room: currentRoom, messageId: msgId, action: 'pin' }),
      });
      await fetchMessages();
    } catch {}
  };

  const deleteMessage = async (msgId: string) => {
    try {
      await fetch('/api/chat', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room: currentRoom, messageId: msgId }),
      });
      await fetchMessages();
    } catch {}
  };

  const handleInputChange = (val: string) => {
    setInput(val);
    const cursor = inputRef.current?.selectionStart || val.length;
    const textBefore = val.slice(0, cursor);
    const atMatch = textBefore.match(/@([a-zA-Z0-9-]*)$/);
    if (atMatch) { setMentionQuery(atMatch[1]); setMentionIdx(0); }
    else { setMentionQuery(null); }
  };

  const insertMention = (agent: Agent) => {
    const cursor = inputRef.current?.selectionStart || input.length;
    const textBefore = input.slice(0, cursor);
    const textAfter = input.slice(cursor);
    const newBefore = textBefore.replace(/@[a-zA-Z0-9-]*$/, `@${agent.id} `);
    setInput(newBefore + textAfter);
    setMentionQuery(null);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (mentionQuery !== null && filteredMentionAgents.length > 0) {
      if (e.key === 'ArrowDown') { e.preventDefault(); setMentionIdx(i => Math.min(i + 1, filteredMentionAgents.length - 1)); return; }
      if (e.key === 'ArrowUp') { e.preventDefault(); setMentionIdx(i => Math.max(i - 1, 0)); return; }
      if (e.key === 'Tab' || e.key === 'Enter') { e.preventDefault(); insertMention(filteredMentionAgents[mentionIdx]); return; }
      if (e.key === 'Escape') { setMentionQuery(null); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const renderText = (text: string) => {
    const parts: React.ReactNode[] = [];
    const regex = /@([a-zA-Z0-9-]+)/g;
    let last = 0; let match;
    while ((match = regex.exec(text)) !== null) {
      if (match.index > last) parts.push(text.slice(last, match.index));
      const agentId = match[1];
      const agent = agents.find(a => a.id === agentId || a.name.toLowerCase().replace(/\s+/g, '-') === agentId);
      if (agent) {
        parts.push(
          <span key={match.index} className="font-semibold px-0.5 rounded" style={{ color: agent.color, backgroundColor: agent.color + '18' }}>
            @{agent.displayName || agent.name}
          </span>
        );
      } else {
        parts.push(<span key={match.index} className="text-mc-accent">@{agentId}</span>);
      }
      last = regex.lastIndex;
    }
    if (last < text.length) parts.push(text.slice(last));
    return parts.length ? parts : text;
  };

  // Room management functions
  const saveRoomSettings = async (room: Room) => {
    try {
      await fetch('/api/rooms', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(room),
      });
      setRooms(prev => prev.map(r => r.id === room.id ? room : r));
      setEditRoom(null);
      setShowRoomSettings(false);
    } catch {}
  };

  const createRoom = async () => {
    if (!newRoom.id || !newRoom.name) return;
    const roomId = newRoom.id.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    try {
      const r = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...newRoom, id: roomId, members: ['kevin'] }),
      });
      const d = await r.json();
      if (d.room) {
        setRooms(prev => [...prev, d.room]);
        setCurrentRoom(d.room.id);
        setShowNewRoom(false);
        setNewRoom({ id: '', name: '', icon: '💬', description: '', theme: 'default' });
      }
    } catch {}
  };

  const toggleMember = (agentId: string) => {
    if (!editRoom) return;
    const members = (editRoom.members || []).includes(agentId)
      ? (editRoom.members || []).filter(m => m !== agentId)
      : [...(editRoom.members || []), agentId];
    // Always keep kevin
    if (!members.includes('kevin')) members.unshift('kevin');
    setEditRoom({ ...editRoom, members });
  };

  const findReplyMsg = (id?: string) => id ? messages.find(m => m.id === id) : undefined;
  const formatTime = (ts: string) => new Date(ts).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const currentRoomData = rooms.find(r => r.id === currentRoom);

  const [showRoomList, setShowRoomList] = useState(false);

  return (
    <div className="flex h-[calc(100vh-140px)] md:h-[calc(100vh-100px)] pb-14 md:pb-0">
      {/* Room sidebar - collapsible */}
      <div className={`${showRoomList ? 'block' : 'hidden lg:block'} ${showRoomList ? 'absolute inset-0 z-40' : 'relative'} lg:relative w-full lg:w-56 flex-shrink-0 bg-mc-surface border-r border-mc-border overflow-y-auto`}>
        <div className="p-3 border-b border-mc-border flex items-center justify-between">
          <span className="text-xs font-semibold text-mc-muted uppercase tracking-wider">Rooms</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowNewRoom(true)} className="text-mc-accent hover:text-white text-lg leading-none" title="New Room">+</button>
            <button onClick={() => setShowRoomList(false)} className="lg:hidden text-mc-muted hover:text-red-400 text-sm">✕</button>
          </div>
        </div>
        {rooms.map(r => {
          const activity = roomActivity[r.id];
          const isActive = r.id === currentRoom;
          return (
            <button key={r.id} onClick={() => { setCurrentRoom(r.id); setShowRoomSettings(false); setEditRoom(null); setShowRoomList(false); }}
              className={`w-full text-left px-3 py-2.5 border-b border-mc-border/50 hover:bg-mc-accent/10 transition-colors ${isActive ? 'bg-mc-accent/15 border-l-2 border-l-mc-accent' : ''}`}>
              <div className="flex items-center gap-2">
                <span className="text-base">{r.icon}</span>
                <span className={`text-sm font-medium truncate ${isActive ? 'text-mc-text' : 'text-mc-muted'}`}>{r.name}</span>
                {activity && activity.unread > 0 && (
                  <span className="ml-auto flex-shrink-0 bg-mc-accent text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {activity.unread > 9 ? '9+' : activity.unread}
                  </span>
                )}
              </div>
              {activity?.lastMessage && (
                <div className="text-xs text-mc-muted truncate mt-0.5 ml-6">
                  <span className="opacity-70">{activity.lastMessage.sender}:</span> {activity.lastMessage.text.slice(0, 40)}
                </div>
              )}
              <div className="flex items-center gap-2 mt-0.5 ml-6">
                <span className="text-[10px] text-mc-muted">{(r.members || []).length - 1} agents</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Room header */}
        <div className="px-2 lg:px-4 py-2 border-b border-mc-border bg-mc-surface flex items-center gap-2 lg:gap-3">
          <button onClick={() => setShowRoomList(true)} className="lg:hidden text-mc-muted hover:text-mc-accent text-sm flex-shrink-0">
            ☰
          </button>
          {currentRoomData && (
            <>
              <span className="text-xl">{currentRoomData.icon}</span>
              <button onClick={() => { setEditRoom({ ...currentRoomData }); setShowRoomSettings(!showRoomSettings); }}
                className="hover:text-mc-accent transition-colors">
                <span className="text-sm font-semibold text-mc-text">{currentRoomData.name}</span>
              </button>
              <span className="text-xs text-mc-muted">{currentRoomData.description}</span>
              <span className="text-[10px] text-mc-muted ml-1">• {(currentRoomData.members || []).length - 1} agents</span>
            </>
          )}
          <div className="ml-auto flex items-center gap-2">
            {/* Room members avatars - hidden on mobile */}
            <div className="hidden lg:flex items-center -space-x-1">
              {roomMembers.slice(0, 5).map(a => {
                const emoji = CHARACTER_EMOJIS[a.avatarType || 'lobster'] || '🦞';
                return (
                  <div key={a.id} title={a.displayName || a.name}
                    className="w-6 h-6 rounded-full flex items-center justify-center text-[10px]"
                    style={{ backgroundColor: a.color + '22', border: `1.5px solid ${a.color}` }}>
                    {emoji}
                  </div>
                );
              })}
              {roomMembers.length > 5 && <span className="text-[10px] text-mc-muted ml-2">+{roomMembers.length - 5}</span>}
            </div>
            <div className="hidden lg:flex items-center gap-1 bg-mc-bg rounded-lg border border-mc-border p-0.5">
              {[
                { id: 'brief', label: '⚡ Brief', tip: '1-2 sentences' },
                { id: 'balanced', label: '💬 Balanced', tip: '2-4 sentences' },
                { id: 'detailed', label: '📋 Detailed', tip: 'Comprehensive' },
                { id: 'teaching', label: '🎓 Socratic', tip: 'Step-by-step teaching' },
                { id: 'debate', label: '⚔️ Debate', tip: 'Devil\'s advocate' },
              ].map(s => (
                <button key={s.id} onClick={() => setResponseStyle(s.id)} title={s.tip}
                  className={`px-2 py-1 text-[10px] rounded transition-colors ${
                    responseStyle === s.id
                      ? 'bg-mc-accent text-white font-medium'
                      : 'text-mc-muted hover:text-mc-text hover:bg-mc-surface'
                  }`}>
                  {s.label}
                </button>
              ))}
            </div>
            {/* Mobile: compact style selector */}
            <select value={responseStyle} onChange={e => setResponseStyle(e.target.value)}
              className="lg:hidden bg-mc-bg border border-mc-border rounded px-1.5 py-1 text-[10px] text-mc-muted flex-shrink-0">
              <option value="brief">⚡ Brief</option>
              <option value="balanced">💬 Balanced</option>
              <option value="detailed">📋 Detailed</option>
              <option value="teaching">🎓 Socratic</option>
              <option value="debate">⚔️ Debate</option>
            </select>
            {meetingActive ? (
              <button onClick={endMeeting} className="px-3 py-1.5 bg-red-600/80 text-white rounded-lg text-xs font-medium hover:bg-red-600">
                🛑 End Meeting
              </button>
            ) : (
              <button onClick={() => setShowMeetingInput(!showMeetingInput)}
                className="px-3 py-1.5 bg-mc-surface border border-mc-border text-mc-text rounded-lg text-xs font-medium hover:border-mc-accent">
                🎯 Meeting
              </button>
            )}
          </div>
        </div>

        {/* Room Settings Panel */}
        {showRoomSettings && editRoom && (
          <div className="px-4 py-3 bg-mc-surface border-b border-mc-border space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-mc-text">Room Settings</span>
              <button onClick={() => { setShowRoomSettings(false); setEditRoom(null); }} className="text-mc-muted hover:text-red-400 text-sm">✕</button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] text-mc-muted uppercase">Icon</label>
                <input value={editRoom.icon} onChange={e => setEditRoom({ ...editRoom, icon: e.target.value })}
                  className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text" />
              </div>
              <div className="col-span-2">
                <label className="text-[10px] text-mc-muted uppercase">Name</label>
                <input value={editRoom.name} onChange={e => setEditRoom({ ...editRoom, name: e.target.value })}
                  className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text" />
              </div>
            </div>
            <div>
              <label className="text-[10px] text-mc-muted uppercase">Description</label>
              <input value={editRoom.description} onChange={e => setEditRoom({ ...editRoom, description: e.target.value })}
                className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text" />
            </div>
            <div>
              <label className="text-[10px] text-mc-muted uppercase mb-1 block">Members</label>
              <div className="flex flex-wrap gap-1.5">
                {agents.filter(a => a.id !== 'kevin').map(a => {
                  const isMember = (editRoom.members || []).includes(a.id);
                  const emoji = CHARACTER_EMOJIS[a.avatarType || 'lobster'] || '🦞';
                  return (
                    <button key={a.id} onClick={() => toggleMember(a.id)}
                      className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs border transition-colors ${isMember ? 'border-mc-accent bg-mc-accent/20 text-mc-text' : 'border-mc-border text-mc-muted hover:border-mc-accent/50'}`}>
                      <span className="text-[10px]">{emoji}</span>
                      <span>{a.displayName || a.name}</span>
                      {isMember && <span className="text-mc-accent">✓</span>}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => { setShowRoomSettings(false); setEditRoom(null); }}
                className="px-3 py-1.5 text-xs text-mc-muted hover:text-mc-text">Cancel</button>
              <button onClick={() => saveRoomSettings(editRoom)}
                className="px-3 py-1.5 bg-mc-accent text-white rounded text-xs font-medium hover:opacity-90">Save</button>
            </div>
          </div>
        )}

        {/* New Room Modal */}
        {showNewRoom && (
          <div className="px-4 py-3 bg-mc-surface border-b border-mc-border space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-mc-text">Create New Room</span>
              <button onClick={() => setShowNewRoom(false)} className="text-mc-muted hover:text-red-400 text-sm">✕</button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              <div>
                <label className="text-[10px] text-mc-muted uppercase">Icon</label>
                <input value={newRoom.icon} onChange={e => setNewRoom({ ...newRoom, icon: e.target.value })}
                  className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text" />
              </div>
              <div className="col-span-3">
                <label className="text-[10px] text-mc-muted uppercase">Name</label>
                <input value={newRoom.name} onChange={e => setNewRoom({ ...newRoom, name: e.target.value, id: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
                  placeholder="Room name"
                  className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text placeholder:text-mc-muted" />
              </div>
            </div>
            <input value={newRoom.description} onChange={e => setNewRoom({ ...newRoom, description: e.target.value })}
              placeholder="Description"
              className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm text-mc-text placeholder:text-mc-muted" />
            <div className="flex justify-end gap-2">
              <button onClick={() => setShowNewRoom(false)} className="px-3 py-1.5 text-xs text-mc-muted hover:text-mc-text">Cancel</button>
              <button onClick={createRoom} disabled={!newRoom.name}
                className="px-3 py-1.5 bg-mc-accent text-white rounded text-xs font-medium hover:opacity-90 disabled:opacity-40">Create</button>
            </div>
          </div>
        )}

        {/* Meeting topic input */}
        {showMeetingInput && !meetingActive && (
          <div className="flex gap-2 px-4 py-2 border-b border-mc-border bg-mc-surface">
            <input value={meetingTopic} onChange={e => setMeetingTopic(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') startMeeting(); }}
              placeholder="Meeting topic — all Executive Board agents will respond..."
              className="flex-1 bg-mc-bg border border-yellow-600/50 rounded-lg px-3 py-2 text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-yellow-500" />
            <button onClick={startMeeting} disabled={!meetingTopic.trim()} className="px-4 py-2 bg-yellow-600 text-white rounded-lg text-xs font-medium hover:bg-yellow-500 disabled:opacity-40">
              Go
            </button>
          </div>
        )}

        {/* Pinned messages */}
        {pinnedMessages.length > 0 && (
          <div className="mx-4 mt-2 bg-yellow-900/20 border border-yellow-700/30 rounded-lg p-2 space-y-1 max-h-24 overflow-y-auto">
            <div className="text-[10px] text-yellow-500 font-medium">📌 Pinned</div>
            {pinnedMessages.map(m => (
              <div key={m.id} className="text-xs text-mc-text truncate cursor-pointer hover:bg-yellow-900/20 rounded px-1"
                onClick={() => document.getElementById(`msg-${m.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })}>
                <span style={{ color: m.senderColor }} className="font-medium">{m.senderName}:</span> <MarkdownMessage content={m.text} />
              </div>
            ))}
          </div>
        )}

        {/* Messages */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-2 lg:p-4 space-y-2">
          {messages.length === 0 && (
            <div className="text-center text-mc-muted text-sm py-12">No messages yet. Start the conversation!</div>
          )}
          {messages.map(msg => {
            const replyMsg = findReplyMsg(msg.replyTo);
            const isMeeting = !!msg.meetingId;
            if (msg.type === 'system') {
              return <div key={msg.id} className="text-center text-xs text-mc-muted py-1">{isMeeting && '🎯 '}{msg.text}</div>;
            }
            return (
              <div key={msg.id} id={`msg-${msg.id}`}
                className={`relative group ${isMeeting ? 'border-l-2 border-yellow-600/40 pl-2' : ''}`}
                onMouseEnter={() => setHoveredMsg(msg.id)} onMouseLeave={() => setHoveredMsg(null)}>
                {replyMsg && (
                  <div className="flex items-center gap-1.5 ml-11 mb-0.5 text-xs text-mc-muted border-l-2 pl-2" style={{ borderColor: replyMsg.senderColor }}>
                    <span>↩ replying to</span>
                    <span style={{ color: replyMsg.senderColor }} className="font-medium">{replyMsg.senderName}</span>
                    <span className="truncate max-w-[200px] opacity-60">{replyMsg.text}</span>
                  </div>
                )}
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm"
                    style={{ backgroundColor: msg.senderColor + '22', border: `2px solid ${msg.senderColor}` }}>
                    {msg.senderEmoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2">
                      <span className="text-sm font-medium" style={{ color: msg.senderColor }}>{msg.senderName}</span>
                      {isMeeting && <span className="text-[10px]">🎯</span>}
                      <span className="text-[10px] text-mc-muted opacity-0 group-hover:opacity-100 transition-opacity">
                        {formatTime(msg.timestamp)}
                      </span>
                      {msg.pinned && <span className="text-[10px]">📌</span>}
                    </div>
                    <p className="text-sm text-mc-text mt-0.5 break-words"><MarkdownMessage content={msg.text} /></p>
                  </div>
                  {hoveredMsg === msg.id && (
                    <div className="absolute right-1 top-0 flex items-center gap-0.5 bg-mc-surface border border-mc-border rounded-md shadow-lg px-1 py-0.5 z-10">
                      <button onClick={() => { setReplyTo(msg); inputRef.current?.focus(); }}
                        className="text-xs px-1.5 py-0.5 hover:bg-mc-accent/20 rounded text-mc-muted hover:text-mc-text" title="Reply">↩</button>
                      <button onClick={() => pinMessage(msg.id)}
                        className="text-xs px-1.5 py-0.5 hover:bg-yellow-500/20 rounded text-mc-muted hover:text-yellow-400" title="Pin">📌</button>
                      <button onClick={() => deleteMessage(msg.id)}
                        className="text-xs px-1.5 py-0.5 hover:bg-red-500/20 rounded text-mc-muted hover:text-red-400" title="Delete">🗑️</button>
                      {msg.sender !== 'kevin' && (
                        <button onClick={async () => {
                          const agent = agents.find(a => a.id === msg.sender);
                          if (!agent?.voice) return;
                          try {
                            const r = await fetch('/api/voice', {
                              method: 'POST', headers: {'Content-Type':'application/json'},
                              body: JSON.stringify({ action: 'preview', voice_id: agent.voice, text: msg.text.slice(0, 500) }),
                            });
                            const d = await r.json();
                            if (d.audio) new Audio(d.audio).play();
                          } catch {}
                        }}
                          className="text-xs px-1.5 py-0.5 hover:bg-mc-accent/20 rounded text-mc-muted hover:text-mc-accent" title="Listen">🔊</button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {typingAgents.length > 0 && (
            <div className="flex flex-col gap-0.5 pt-1">
              {typingAgents.map(agentId => {
                const agent = agents.find(a => a.id === agentId);
                if (!agent) return null;
                return (
                  <div key={agentId} className="flex items-center gap-2 text-xs text-mc-muted animate-pulse">
                    <span style={{ color: agent.color }}>{agent.displayName || agent.name}</span>
                    <span>is typing...</span>
                  </div>
                );
              })}
            </div>
          )}
          <div ref={messagesEnd} />
        </div>

        {/* Reply indicator */}
        {replyTo && (
          <div className="mx-4 flex items-center gap-2 px-3 py-1.5 bg-mc-surface rounded-t-lg border border-mc-border border-b-0 text-xs text-mc-muted">
            <span>↩ Replying to</span>
            <span style={{ color: replyTo.senderColor }} className="font-medium">{replyTo.senderName}</span>
            <span className="truncate max-w-[300px] opacity-60">{replyTo.text}</span>
            <button onClick={() => setReplyTo(null)} className="ml-auto text-mc-muted hover:text-red-400">✕</button>
          </div>
        )}

        {/* Input area */}
        <div className="px-4 pb-3 pt-2">
          {mentionQuery !== null && filteredMentionAgents.length > 0 && (
            <div className="bg-mc-surface border border-mc-border rounded-lg mb-1 shadow-xl max-h-40 overflow-y-auto">
              {filteredMentionAgents.map((a, i) => {
                const emoji = CHARACTER_EMOJIS[a.avatarType || 'lobster'] || '🦞';
                return (
                  <button key={a.id} onClick={() => insertMention(a)}
                    className={`w-full flex items-center gap-2 px-3 py-1.5 text-sm text-left hover:bg-mc-accent/20 ${i === mentionIdx ? 'bg-mc-accent/20' : ''}`}>
                    <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px]"
                      style={{ backgroundColor: a.color + '22', border: `1.5px solid ${a.color}` }}>{emoji}</span>
                    <span style={{ color: a.color }} className="font-medium">{a.displayName || a.name}</span>
                    <span className="text-mc-muted text-xs">@{a.id}</span>
                  </button>
                );
              })}
            </div>
          )}
          <div className="flex gap-2">
            <input ref={inputRef} type="text" value={input}
              onChange={e => handleInputChange(e.target.value)} onKeyDown={handleKeyDown}
              placeholder={`Message...`}
              className={`flex-1 bg-mc-surface border border-mc-border px-2 lg:px-4 py-2 lg:py-2.5 text-sm text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent ${replyTo ? 'rounded-b-lg rounded-t-none' : 'rounded-lg'}`} />
            <button onClick={sendMessage} disabled={!input.trim() || sending}
              className={`px-3 lg:px-4 py-2 lg:py-2.5 bg-mc-accent text-white text-sm font-medium hover:opacity-90 disabled:opacity-40 transition-opacity ${replyTo ? 'rounded-b-lg rounded-t-none' : 'rounded-lg'}`}>
              Send
            </button>
          </div>
          <div className="hidden lg:flex items-center gap-1.5 mt-2 overflow-x-auto pb-1">
            <span className="text-[10px] text-mc-muted mr-1">Quick mention:</span>
            {agents.filter(a => a.id !== 'kevin').map(agent => {
              const emoji = CHARACTER_EMOJIS[agent.avatarType || 'lobster'] || '🦞';
              return (
                <button key={agent.id} onClick={() => { setInput(prev => prev + `@${agent.id} `); inputRef.current?.focus(); }}
                  title={`@${agent.displayName || agent.name}`}
                  className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-xs hover:scale-110 transition-transform"
                  style={{ backgroundColor: agent.color + '22', border: `2px solid ${agent.color}` }}>
                  {emoji}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
