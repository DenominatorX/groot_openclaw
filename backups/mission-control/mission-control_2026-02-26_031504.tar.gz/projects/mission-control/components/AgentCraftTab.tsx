'use client';
import { useState, useEffect } from 'react';

function getAgentCraftUrl(): string {
  if (typeof window !== 'undefined' && window.location.hostname.includes('denominatorx.com')) {
    return 'https://agentcraft.denominatorx.com';
  }
  return 'http://localhost:2468';
}

export default function AgentCraftTab() {
  const [url, setUrl] = useState('http://localhost:2468');

  useEffect(() => {
    setUrl(getAgentCraftUrl());
  }, []);

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 160px)', overflow: 'hidden' }}>
      <div className="flex items-center justify-between mb-1 flex-shrink-0">
        <h2 className="text-base md:text-lg font-bold">🏰 AgentCraft</h2>
        <div className="flex items-center gap-2">
          <a href={url} target="_blank" rel="noopener noreferrer"
            className="text-xs text-mc-muted hover:text-mc-accent transition-colors">↗ Open Fullscreen</a>
        </div>
      </div>
      <div className="flex-1 rounded-lg overflow-hidden border border-mc-border" style={{ minHeight: 0 }}>
        <iframe
          src={url}
          className="w-full h-full"
          style={{ border: 'none' }}
          allow="fullscreen"
          title="AgentCraft - RTS Agent Visualization"
        />
      </div>
    </div>
  );
}
