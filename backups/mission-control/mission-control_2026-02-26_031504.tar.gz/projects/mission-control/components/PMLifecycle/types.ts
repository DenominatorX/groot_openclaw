/**
 * PM Lifecycle Tool — shared types (MC-00044)
 */

// ─── DAG Node & Edge Types ──────────────────────────────────────────
export interface DAGNode {
  id: string;
  label: string;
  type: 'agent' | 'gate' | 'checkpoint' | 'start' | 'end';
  agent?: string;
  model?: string;
  x: number;
  y: number;
  config?: Record<string, unknown>;
}

export interface DAGEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  condition?: string;
}

export interface DAGGraph {
  nodes: DAGNode[];
  edges: DAGEdge[];
}

// ─── Slider / Weight Controls ───────────────────────────────────────
export interface PMWeight {
  key: string;
  label: string;
  value: number;         // 0–100
  description?: string;
  category: 'cost' | 'speed' | 'quality' | 'risk';
}

export interface PMControls {
  weights: PMWeight[];
  maxBudget: number;     // USD
  maxAgents: number;
  timeout: number;       // minutes
  autoRetry: boolean;
  approvalGates: boolean;
}

// ─── Template ───────────────────────────────────────────────────────
export interface PMTemplate {
  id: string;
  name: string;
  description: string;
  graph: DAGGraph;
  controls: PMControls;
  tags: string[];
  premium: boolean;
}

// ─── Dashboard ──────────────────────────────────────────────────────
export type RunStatus = 'idle' | 'running' | 'paused' | 'complete' | 'failed';

export interface RunNode {
  nodeId: string;
  status: RunStatus;
  startedAt?: string;
  completedAt?: string;
  output?: string;
  error?: string;
  cost?: number;
}

export interface PMRun {
  id: string;
  projectId: string;
  graph: DAGGraph;
  controls: PMControls;
  status: RunStatus;
  nodes: RunNode[];
  startedAt: string;
  completedAt?: string;
  totalCost: number;
}

// ─── API Payloads ───────────────────────────────────────────────────
export interface PMRunRequest {
  projectId: string;
  graph: DAGGraph;
  controls: PMControls;
  templateId?: string;
}

export interface PMRunResponse {
  run: PMRun;
  ok: boolean;
  error?: string;
}

export interface DAGExport {
  graph: DAGGraph;
  controls: PMControls;
  exportedAt: string;
  version: string;
}
