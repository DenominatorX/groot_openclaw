'use client';

import React, { useCallback } from 'react';
import type { PMControls, PMWeight } from './types';

// ─── Colour by category ─────────────────────────────────────────────
const CAT_COLORS: Record<PMWeight['category'], string> = {
  cost:    'accent-emerald-500',
  speed:   'accent-blue-500',
  quality: 'accent-purple-500',
  risk:    'accent-yellow-500',
};
const CAT_BG: Record<PMWeight['category'], string> = {
  cost:    'bg-emerald-500',
  speed:   'bg-blue-500',
  quality: 'bg-purple-500',
  risk:    'bg-yellow-500',
};

// ─── Default weights factory ────────────────────────────────────────
export function defaultControls(): PMControls {
  return {
    weights: [
      { key: 'cost_sensitivity',  label: 'Cost Sensitivity',  value: 50, category: 'cost',    description: 'How aggressively to minimise spend' },
      { key: 'speed_priority',    label: 'Speed Priority',    value: 50, category: 'speed',   description: 'Parallelism and fast models over accuracy' },
      { key: 'quality_bar',       label: 'Quality Bar',       value: 70, category: 'quality', description: 'Minimum acceptable output quality' },
      { key: 'risk_tolerance',    label: 'Risk Tolerance',    value: 30, category: 'risk',    description: 'Willingness to use experimental models/agents' },
    ],
    maxBudget: 5.0,
    maxAgents: 4,
    timeout: 30,
    autoRetry: true,
    approvalGates: false,
  };
}

// ─── Component ──────────────────────────────────────────────────────
interface PMSlidersProps {
  controls: PMControls;
  onChange: (c: PMControls) => void;
  readOnly?: boolean;
}

export default function PMSliders({ controls, onChange, readOnly }: PMSlidersProps) {
  const updateWeight = useCallback((key: string, value: number) => {
    onChange({
      ...controls,
      weights: controls.weights.map(w => w.key === key ? { ...w, value } : w),
    });
  }, [controls, onChange]);

  const toJSON = (): string => JSON.stringify({
    weights: Object.fromEntries(controls.weights.map(w => [w.key, w.value / 100])),
    maxBudget: controls.maxBudget,
    maxAgents: controls.maxAgents,
    timeout: controls.timeout,
    autoRetry: controls.autoRetry,
    approvalGates: controls.approvalGates,
  }, null, 2);

  return (
    <div className="space-y-5">
      {/* Weight Sliders */}
      <div className="space-y-3">
        <h4 className="text-xs font-semibold text-mc-text uppercase tracking-wider">Weights</h4>
        {controls.weights.map(w => (
          <div key={w.key} className="space-y-1">
            <div className="flex justify-between items-baseline">
              <span className="text-xs text-mc-text">{w.label}</span>
              <span className="text-[10px] font-mono text-mc-muted">{w.value}%</span>
            </div>
            {w.description && (
              <p className="text-[10px] text-mc-muted/60">{w.description}</p>
            )}
            <input
              type="range" min={0} max={100} step={5}
              value={w.value}
              disabled={readOnly}
              onChange={e => updateWeight(w.key, Number(e.target.value))}
              className={`w-full h-1.5 rounded-full appearance-none cursor-pointer
                bg-mc-border ${CAT_COLORS[w.category]}
                [&::-webkit-slider-thumb]:appearance-none
                [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3
                [&::-webkit-slider-thumb]:rounded-full
                [&::-webkit-slider-thumb]:${CAT_BG[w.category]}
                [&::-webkit-slider-thumb]:shadow
                disabled:opacity-50`}
            />
            {/* Visual bar */}
            <div className="h-1 rounded-full bg-mc-border overflow-hidden">
              <div className={`h-full rounded-full ${CAT_BG[w.category]} transition-all`}
                style={{ width: `${w.value}%` }} />
            </div>
          </div>
        ))}
      </div>

      {/* Numeric Controls */}
      <div className="grid grid-cols-3 gap-3">
        <label className="space-y-1">
          <span className="text-[10px] text-mc-muted uppercase">Budget ($)</span>
          <input type="number" min={0} step={0.5} value={controls.maxBudget} disabled={readOnly}
            onChange={e => onChange({ ...controls, maxBudget: Number(e.target.value) })}
            className="w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text" />
        </label>
        <label className="space-y-1">
          <span className="text-[10px] text-mc-muted uppercase">Max Agents</span>
          <input type="number" min={1} max={20} value={controls.maxAgents} disabled={readOnly}
            onChange={e => onChange({ ...controls, maxAgents: Number(e.target.value) })}
            className="w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text" />
        </label>
        <label className="space-y-1">
          <span className="text-[10px] text-mc-muted uppercase">Timeout (min)</span>
          <input type="number" min={1} max={120} value={controls.timeout} disabled={readOnly}
            onChange={e => onChange({ ...controls, timeout: Number(e.target.value) })}
            className="w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text" />
        </label>
      </div>

      {/* Toggles */}
      <div className="flex gap-4">
        <label className="flex items-center gap-2 text-xs text-mc-text cursor-pointer">
          <input type="checkbox" checked={controls.autoRetry} disabled={readOnly}
            onChange={e => onChange({ ...controls, autoRetry: e.target.checked })}
            className="rounded border-mc-border text-mc-accent" />
          Auto-retry on fail
        </label>
        <label className="flex items-center gap-2 text-xs text-mc-text cursor-pointer">
          <input type="checkbox" checked={controls.approvalGates} disabled={readOnly}
            onChange={e => onChange({ ...controls, approvalGates: e.target.checked })}
            className="rounded border-mc-border text-mc-accent" />
          Approval gates
        </label>
      </div>

      {/* JSON preview */}
      <details className="group">
        <summary className="text-[10px] text-mc-muted cursor-pointer hover:text-mc-text">
          ▸ JSON Override Preview
        </summary>
        <pre className="mt-2 p-3 text-[10px] font-mono rounded bg-mc-bg border border-mc-border text-mc-muted overflow-auto max-h-48">
          {toJSON()}
        </pre>
      </details>
    </div>
  );
}
