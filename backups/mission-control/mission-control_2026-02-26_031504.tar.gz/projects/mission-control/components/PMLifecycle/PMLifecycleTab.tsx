'use client';

import React, { useState, useCallback } from 'react';
import DAGEditor from './DAGEditor';
import PMSliders, { defaultControls } from './PMSliders';
import PMDashboard from './PMDashboard';
import PMTemplateSelector from './PMTemplateSelector';
import type { DAGGraph, PMControls, PMRun, RunStatus } from './types';

// ─── Tabs ───────────────────────────────────────────────────────────
type Tab = 'editor' | 'controls' | 'dashboard' | 'templates';
const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'templates', label: 'Templates', icon: '📋' },
  { id: 'editor',    label: 'DAG Editor', icon: '🔀' },
  { id: 'controls',  label: 'Controls',   icon: '⚙️' },
  { id: 'dashboard', label: 'Dashboard',  icon: '📊' },
];

// ─── Component ──────────────────────────────────────────────────────
interface PMLifecycleTabProps {
  projectId: string;
  projectTitle?: string;
}

export default function PMLifecycleTab({ projectId, projectTitle }: PMLifecycleTabProps) {
  const [tab, setTab] = useState<Tab>('templates');
  const [graph, setGraph] = useState<DAGGraph>({ nodes: [], edges: [] });
  const [controls, setControls] = useState<PMControls>(defaultControls());
  const [currentTplId, setCurrentTplId] = useState<string | undefined>();
  const [run, setRun] = useState<PMRun | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ── Template selection ──────────────────────────────────────────
  const handleTemplateSelect = useCallback((g: DAGGraph, c: PMControls) => {
    setGraph(g);
    setControls(c);
    setTab('editor');
  }, []);

  // ── Export DAG as JSON ──────────────────────────────────────────
  const exportDAG = useCallback(() => {
    const payload = {
      graph,
      controls: {
        weights: Object.fromEntries(controls.weights.map(w => [w.key, w.value / 100])),
        maxBudget: controls.maxBudget,
        maxAgents: controls.maxAgents,
        timeout: controls.timeout,
        autoRetry: controls.autoRetry,
        approvalGates: controls.approvalGates,
      },
      exportedAt: new Date().toISOString(),
      version: '1.0',
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `dag-${projectId}-${Date.now()}.json`;
    a.click();
  }, [graph, controls, projectId]);

  // ── Start run (calls /api/projects/:id/pm-run) ─────────────────
  const startRun = useCallback(async () => {
    setError(null);
    setSaving(true);
    try {
      const res = await fetch(`/api/projects/${projectId}/pm-run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ graph, controls }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `HTTP ${res.status}`);
      }
      const data = await res.json();
      setRun(data.run);
      setTab('dashboard');
    } catch (e: any) {
      setError(e.message);
      // If endpoint not ready, create mock run for demo
      if (e.message.includes('404') || e.message.includes('fetch')) {
        setRun(mockRun(graph, controls, projectId));
        setTab('dashboard');
        setError(null);
      }
    } finally {
      setSaving(false);
    }
  }, [graph, controls, projectId]);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-mc-text">PM Lifecycle</h2>
          <p className="text-[10px] text-mc-muted">Visual pipeline editor — {projectTitle || projectId}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={exportDAG}
            className="px-3 py-1 text-xs rounded border border-mc-border text-mc-muted hover:text-mc-accent hover:border-mc-accent transition">
            ⬇ Export
          </button>
          <button onClick={startRun} disabled={saving || graph.nodes.length === 0}
            className="px-3 py-1 text-xs rounded bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 disabled:opacity-40 transition">
            {saving ? '…' : '▶ Run'}
          </button>
        </div>
      </div>

      {error && (
        <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded px-3 py-2">
          {error}
        </div>
      )}

      {/* Tab bar */}
      <div className="flex gap-1 border-b border-mc-border">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-3 py-2 text-xs transition border-b-2 -mb-px ${
              tab === t.id
                ? 'border-mc-accent text-mc-accent'
                : 'border-transparent text-mc-muted hover:text-mc-text'
            }`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="min-h-[400px]">
        {tab === 'templates' && (
          <PMTemplateSelector onSelect={handleTemplateSelect} currentTemplateId={currentTplId} />
        )}
        {tab === 'editor' && (
          <DAGEditor graph={graph} onChange={setGraph} />
        )}
        {tab === 'controls' && (
          <PMSliders controls={controls} onChange={setControls} />
        )}
        {tab === 'dashboard' && (
          <PMDashboard projectId={projectId} run={run} onStart={startRun} />
        )}
      </div>
    </div>
  );
}

// ─── Mock run for demo when backend not yet wired ───────────────────
function mockRun(graph: DAGGraph, controls: PMControls, projectId: string): PMRun {
  return {
    id: `run-mock-${Date.now()}`,
    projectId,
    graph,
    controls,
    status: 'running',
    startedAt: new Date().toISOString(),
    totalCost: 0,
    nodes: graph.nodes.map(n => ({
      nodeId: n.id,
      status: n.type === 'start' ? 'complete' : 'idle' as RunStatus,
      startedAt: n.type === 'start' ? new Date().toISOString() : undefined,
      completedAt: n.type === 'start' ? new Date().toISOString() : undefined,
      cost: n.type === 'start' ? 0 : undefined,
    })),
  };
}
