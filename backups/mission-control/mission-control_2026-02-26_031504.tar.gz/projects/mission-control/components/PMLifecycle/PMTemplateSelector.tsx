'use client';

import React, { useState } from 'react';
import type { PMTemplate, DAGGraph, PMControls } from './types';
import { defaultControls } from './PMSliders';

// ─── Built-in templates ─────────────────────────────────────────────
const BUILTIN_TEMPLATES: PMTemplate[] = [
  {
    id: 'tpl-simple',
    name: 'Simple 3-Node',
    description: 'Start → Agent → End. Minimal pipeline for quick tasks.',
    tags: ['starter', 'simple'],
    premium: false,
    graph: {
      nodes: [
        { id: 'start', label: 'Start', type: 'start', x: 320, y: 40 },
        { id: 'worker', label: 'Worker Agent', type: 'agent', agent: 'worker-b', x: 280, y: 160 },
        { id: 'end', label: 'End', type: 'end', x: 320, y: 300 },
      ],
      edges: [
        { id: 'e1', source: 'start', target: 'worker' },
        { id: 'e2', source: 'worker', target: 'end' },
      ],
    },
    controls: defaultControls(),
  },
  {
    id: 'tpl-review',
    name: 'Build + Review',
    description: 'Agent builds, second agent reviews, gate decides pass/fail.',
    tags: ['review', 'quality'],
    premium: false,
    graph: {
      nodes: [
        { id: 'start', label: 'Start', type: 'start', x: 300, y: 40 },
        { id: 'builder', label: 'Builder', type: 'agent', agent: 'forge', x: 200, y: 160 },
        { id: 'reviewer', label: 'Reviewer', type: 'agent', agent: 'sentinel', x: 400, y: 160 },
        { id: 'gate', label: 'Quality Gate', type: 'gate', x: 300, y: 300 },
        { id: 'end', label: 'End', type: 'end', x: 300, y: 420 },
      ],
      edges: [
        { id: 'e1', source: 'start', target: 'builder' },
        { id: 'e2', source: 'builder', target: 'reviewer' },
        { id: 'e3', source: 'reviewer', target: 'gate' },
        { id: 'e4', source: 'gate', target: 'end' },
      ],
    },
    controls: { ...defaultControls(), approvalGates: true },
  },
  {
    id: 'tpl-parallel',
    name: 'Parallel Workers',
    description: 'Fan-out to 3 agents in parallel, merge at checkpoint.',
    tags: ['parallel', 'speed'],
    premium: false,
    graph: {
      nodes: [
        { id: 'start', label: 'Start', type: 'start', x: 320, y: 40 },
        { id: 'a1', label: 'Agent A', type: 'agent', agent: 'nova', x: 100, y: 180 },
        { id: 'a2', label: 'Agent B', type: 'agent', agent: 'spark', x: 300, y: 180 },
        { id: 'a3', label: 'Agent C', type: 'agent', agent: 'forge', x: 500, y: 180 },
        { id: 'merge', label: 'Merge', type: 'checkpoint', x: 300, y: 320 },
        { id: 'end', label: 'End', type: 'end', x: 320, y: 440 },
      ],
      edges: [
        { id: 'e1', source: 'start', target: 'a1' },
        { id: 'e2', source: 'start', target: 'a2' },
        { id: 'e3', source: 'start', target: 'a3' },
        { id: 'e4', source: 'a1', target: 'merge' },
        { id: 'e5', source: 'a2', target: 'merge' },
        { id: 'e6', source: 'a3', target: 'merge' },
        { id: 'e7', source: 'merge', target: 'end' },
      ],
    },
    controls: { ...defaultControls(), maxAgents: 6 },
  },
  {
    id: 'tpl-full',
    name: 'Full PM Pipeline',
    description: 'Plan → Build → Test → Review → Deploy. Enterprise-grade.',
    tags: ['enterprise', 'full'],
    premium: true,
    graph: {
      nodes: [
        { id: 'start', label: 'Start', type: 'start', x: 320, y: 20 },
        { id: 'plan', label: 'Planner', type: 'agent', agent: 'gork', x: 300, y: 120 },
        { id: 'build', label: 'Builder', type: 'agent', agent: 'forge', x: 200, y: 240 },
        { id: 'test', label: 'Tester', type: 'agent', agent: 'sentinel', x: 420, y: 240 },
        { id: 'gate', label: 'QA Gate', type: 'gate', x: 300, y: 360 },
        { id: 'deploy', label: 'Deploy', type: 'agent', agent: 'swift', x: 300, y: 460 },
        { id: 'end', label: 'End', type: 'end', x: 320, y: 560 },
      ],
      edges: [
        { id: 'e1', source: 'start', target: 'plan' },
        { id: 'e2', source: 'plan', target: 'build' },
        { id: 'e3', source: 'plan', target: 'test' },
        { id: 'e4', source: 'build', target: 'gate' },
        { id: 'e5', source: 'test', target: 'gate' },
        { id: 'e6', source: 'gate', target: 'deploy' },
        { id: 'e7', source: 'deploy', target: 'end' },
      ],
    },
    controls: { ...defaultControls(), maxBudget: 10, approvalGates: true },
  },
];

// ─── Component ──────────────────────────────────────────────────────
interface PMTemplateSelectorProps {
  onSelect: (graph: DAGGraph, controls: PMControls) => void;
  currentTemplateId?: string;
}

export default function PMTemplateSelector({ onSelect, currentTemplateId }: PMTemplateSelectorProps) {
  const [filter, setFilter] = useState('');

  const filtered = BUILTIN_TEMPLATES.filter(t =>
    !filter || t.name.toLowerCase().includes(filter.toLowerCase()) ||
    t.tags.some(tag => tag.includes(filter.toLowerCase()))
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <h4 className="text-xs font-semibold text-mc-text uppercase tracking-wider">Templates</h4>
        <input
          value={filter} onChange={e => setFilter(e.target.value)}
          placeholder="Filter…"
          className="flex-1 px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text placeholder:text-mc-muted/50"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        {filtered.map(tpl => {
          const isActive = currentTemplateId === tpl.id;
          return (
            <button key={tpl.id}
              onClick={() => onSelect(tpl.graph, tpl.controls)}
              className={`text-left rounded-lg border p-3 transition hover:border-mc-accent group ${
                isActive ? 'border-mc-accent bg-mc-accent/5' : 'border-mc-border bg-mc-card'
              }`}>
              <div className="flex items-start justify-between">
                <span className="text-xs font-medium text-mc-text group-hover:text-mc-accent">
                  {tpl.name}
                </span>
                {tpl.premium && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-400 font-medium">
                    PRO
                  </span>
                )}
              </div>
              <p className="text-[10px] text-mc-muted mt-1 line-clamp-2">{tpl.description}</p>
              <div className="flex gap-1 mt-2 flex-wrap">
                {tpl.tags.map(tag => (
                  <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-mc-bg border border-mc-border text-mc-muted">
                    {tag}
                  </span>
                ))}
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-mc-bg border border-mc-border text-mc-muted">
                  {tpl.graph.nodes.length} nodes
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <p className="text-xs text-mc-muted text-center py-4">No templates match "{filter}"</p>
      )}
    </div>
  );
}
