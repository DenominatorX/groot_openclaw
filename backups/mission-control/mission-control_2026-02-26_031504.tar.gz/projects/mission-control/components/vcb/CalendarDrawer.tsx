'use client';

import { useState, useEffect, useMemo } from 'react';
import CalendarDay from './CalendarDay';
import { useVcbCalendar } from '@/hooks/useVcbCalendar';

// TypeScript interfaces from PLAN.md §4
interface Commit {
  id: string;
  branch_id: string;
  message: string;
  author: string;
  hash: string | null;
  parent_commit_id: string | null;
  metadata: Record<string, unknown>;
  timestamp: string;
  branch_name?: string;
  branch_color?: string;
  file_count?: number;
}

interface Snapshot {
  id: string;
  branch_id: string;
  commit_id: string | null;
  label: string;
  description: string | null;
  data: Record<string, unknown>;
  timestamp: string;
  branch_name?: string;
  branch_color?: string;
}

interface CalendarDayData {
  commits: Commit[];
  snapshots: Snapshot[];
}

interface CalendarResponse {
  year: number;
  month: number;
  days: Record<string, CalendarDayData>;
}

interface CalendarDrawerProps {
  open: boolean;
  onClose: () => void;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function getRelativeTime(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function CalendarDrawer({ open, onClose }: CalendarDrawerProps) {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1); // 1-12
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  
  const { data, loading, error } = useVcbCalendar(year, month);
  
  // Reset selected day when month changes
  useEffect(() => {
    setSelectedDay(null);
  }, [year, month]);
  
  // Generate calendar grid
  const calendarDays = useMemo(() => {
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    const daysInMonth = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay();
    
    const days: (number | null)[] = [];
    
    // Empty cells before first day
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push(null);
    }
    
    // Days of month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }
    
    return days;
  }, [year, month]);
  
  const prevMonth = () => {
    if (month === 1) {
      setMonth(12);
      setYear(year - 1);
    } else {
      setMonth(month - 1);
    }
  };
  
  const nextMonth = () => {
    if (month === 12) {
      setMonth(1);
      setYear(year + 1);
    } else {
      setMonth(month + 1);
    }
  };
  
  const getDayIsoDate = (day: number): string => {
    return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };
  
  const getDayData = (day: number): CalendarDayData | null => {
    if (!data?.days) return null;
    const isoDate = getDayIsoDate(day);
    return data.days[isoDate] || null;
  };
  
  const handleDayClick = (day: number) => {
    const isoDate = getDayIsoDate(day);
    setSelectedDay(isoDate);
  };
  
  const selectedDayData = selectedDay && data?.days ? data.days[selectedDay] : null;
  const today = new Date();
  const todayIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  
  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/40 z-40 transition-opacity duration-300 ${
          open ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />
      
      {/* Drawer */}
      <div
        className={`fixed top-0 right-0 h-full w-[420px] max-w-full bg-[--mc-surface] border-l border-[--mc-border] 
                    flex flex-col shadow-2xl z-50 transform transition-transform duration-300 ease-out
                    ${open ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ willChange: 'transform' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[--mc-border]">
          <h2 className="text-[--mc-text] font-bold text-lg">📅 Commit Calendar</h2>
          <button
            onClick={onClose}
            className="text-[--mc-muted] hover:text-[--mc-text] transition-colors p-1"
          >
            ✕
          </button>
        </div>
        
        {/* Month Navigator */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[--mc-border]">
          <button
            onClick={prevMonth}
            className="text-[--mc-muted] hover:text-[--mc-text] transition-colors text-sm"
          >
            ‹ Prev
          </button>
          <span className="font-semibold text-[--mc-text]">
            {MONTH_NAMES[month - 1]} {year}
          </span>
          <button
            onClick={nextMonth}
            className="text-[--mc-muted] hover:text-[--mc-text] transition-colors text-sm"
          >
            Next ›
          </button>
        </div>
        
        {/* Calendar Grid */}
        <div className="flex-shrink-0 px-4 py-3">
          {/* Day of week headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {DAY_NAMES.map((day) => (
              <div
                key={day}
                className="text-center text-[--mc-muted] text-xs font-medium py-1"
              >
                {day}
              </div>
            ))}
          </div>
          
          {/* Day cells */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, index) => {
              if (day === null) {
                return <div key={`empty-${index}`} className="h-10" />;
              }
              
              const dayData = getDayData(day);
              const isoDate = getDayIsoDate(day);
              const commitCount = dayData?.commits.length || 0;
              const snapshotCount = dayData?.snapshots.length || 0;
              
              // Collect branch colors for dots
              const branchColors: string[] = [];
              if (dayData) {
                const colorSet = new Set<string>();
                dayData.commits.forEach((c) => c.branch_color && colorSet.add(c.branch_color));
                dayData.snapshots.forEach((s) => s.branch_color && colorSet.add(s.branch_color));
                branchColors.push(...Array.from(colorSet).slice(0, 3));
              }
              
              return (
                <CalendarDay
                  key={day}
                  date={day}
                  isoDate={isoDate}
                  isToday={isoDate === todayIso}
                  isSelected={selectedDay === isoDate}
                  commitCount={commitCount}
                  snapshotCount={snapshotCount}
                  branchColors={branchColors}
                  onClick={() => handleDayClick(day)}
                />
              );
            })}
          </div>
        </div>
        
        {/* Event List */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 border-t border-[--mc-border]">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-pulse text-[--mc-muted]">Loading...</div>
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-400 text-sm">{error}</div>
          ) : selectedDayData ? (
            <div className="py-3">
              <h3 className="text-[--mc-text] font-semibold text-sm mb-3">
                {selectedDay} — {selectedDayData.commits.length} commits, {selectedDayData.snapshots.length} snapshot{selectedDayData.snapshots.length !== 1 ? 's' : ''}
              </h3>
              
              {/* Commits */}
              {selectedDayData.commits.map((commit) => (
                <div
                  key={commit.id}
                  className="flex flex-col gap-0.5 py-2 border-b border-[--mc-border]/50"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ background: commit.branch_color || '#6366f1' }}
                    />
                    <span className="text-[--mc-muted] text-xs">
                      {commit.branch_name} · {getRelativeTime(commit.timestamp)}
                    </span>
                  </div>
                  <p className="text-[--mc-text] text-sm">{commit.message}</p>
                </div>
              ))}
              
              {/* Snapshots */}
              {selectedDayData.snapshots.map((snapshot) => (
                <div
                  key={snapshot.id}
                  className="flex flex-col gap-0.5 py-2 border-b border-[--mc-border]/50 bg-[--mc-accent]/5"
                >
                  <div className="flex items-center gap-2">
                    <span>📸</span>
                    <span className="text-[--mc-text] text-sm font-medium">
                      {snapshot.label}
                    </span>
                    <span className="text-[--mc-muted] text-xs">
                      · {snapshot.branch_name} · {getRelativeTime(snapshot.timestamp)}
                    </span>
                  </div>
                  {snapshot.description && (
                    <p className="text-[--mc-muted] text-xs">{snapshot.description}</p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-[--mc-muted] text-sm italic">
                {selectedDay ? 'No activity on this day.' : 'Select a day to view events'}
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
