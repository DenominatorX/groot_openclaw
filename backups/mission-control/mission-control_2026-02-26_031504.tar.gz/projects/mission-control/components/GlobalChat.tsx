'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import MarkdownMessage from './MarkdownMessage';

interface Agent { id: string; displayName?: string; name: string; emoji?: string; title?: string; }
interface ChatMsg { role: 'user' | 'assistant' | 'system'; content: string; sender?: string; timestamp?: string; }
interface Session {
  id: string;
  sessionKey: string;
  agentId: string;
  model: string;
  title: string;
  status: 'active' | 'idle' | 'closed';
  createdAt: string;
  lastMessageAt?: string | null;
  lastMessagePreview?: string | null;
}

interface GlobalChatProps {
  currentTab: string;
  currentContext?: string;
}

const MODEL_OPTIONS = [
  { value: "anthropic/claude-opus-4-6", label: "Opus ($$$)" },
  { value: "anthropic/claude-sonnet-4", label: "Sonnet ($$)" },
  { value: "anthropic/claude-haiku-4-5", label: "Haiku ($)" },
  { value: "openrouter/minimax/minimax-m2.5", label: "MiniMax ($)" },
  { value: "xai/grok-4", label: "Grok 4 (Free)" },
  { value: "openrouter/x-ai/grok-4.1-fast", label: "Grok Fast (¢)" },
  { value: "nvidia/moonshotai/kimi-k2-instruct", label: "Kimi K2 (Free)" },
];

export default function GlobalChat({ currentTab, currentContext }: GlobalChatProps) {
  const [open, setOpen] = useState(false);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [selectedAgent, setSelectedAgent] = useState('architect');
  const [selectedModel, setSelectedModel] = useState('anthropic/claude-sonnet-4');
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [showAgentPicker, setShowAgentPicker] = useState(false);

  // Dragging
  const [pos, setPos] = useState({ x: -1, y: -1 });
  const [size, setSize] = useState({ w: 600, h: 550 });
  const [dragging, setDragging] = useState(false);
  const [resizing, setResizing] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });
  const chatRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch agents
  useEffect(() => {
    fetch('/api/agents').then(r => r.json()).then(d => setAgents(d.agents || [])).catch(() => {});
  }, []);

  // Fetch sessions list
  const fetchSessions = useCallback(async () => {
    setLoadingSessions(true);
    try {
      const r = await fetch('/api/chat/sessions');
      const data = await r.json();
      setSessions(data.sessions || []);
    } catch (err) {
      console.error('Failed to fetch sessions:', err);
    } finally {
      setLoadingSessions(false);
    }
  }, []);

  // Initial sessions load
  useEffect(() => {
    if (open) {
      fetchSessions();
    }
  }, [open, fetchSessions]);

  // Initialize position
  useEffect(() => {
    if (pos.x === -1) {
      const isMobile = window.innerWidth < 768;
      if (isMobile) {
        setPos({ x: 8, y: 60 });
        setSize({ w: window.innerWidth - 16, h: window.innerHeight - 80 });
      } else {
        setPos({ x: window.innerWidth - 620, y: window.innerHeight - 570 });
      }
    }
  }, []);

  // Auto-scroll when messages change
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const prevMsgCount = useRef(0);
  useEffect(() => {
    if (messages.length > prevMsgCount.current && chatContainerRef.current) {
      const el = chatContainerRef.current;
      const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 300;
      if (isNearBottom) {
        messagesEndRef.current?.scrollIntoView({ behavior: 'auto', block: 'end' });
      }
    }
    prevMsgCount.current = messages.length;
  }, [messages]);

  // Drag handlers
  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, input, textarea, select')) return;
    setDragging(true);
    dragOffset.current = { x: e.clientX - pos.x, y: e.clientY - pos.y };
    e.preventDefault();
  }, [pos]);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('button, input, textarea, select')) return;
    const t = e.touches[0];
    setDragging(true);
    dragOffset.current = { x: t.clientX - pos.x, y: t.clientY - pos.y };
  }, [pos]);

  useEffect(() => {
    if (!dragging && !resizing) return;
    const onMove = (e: MouseEvent) => {
      if (dragging) {
        setPos({ x: Math.max(0, e.clientX - dragOffset.current.x), y: Math.max(0, e.clientY - dragOffset.current.y) });
      }
      if (resizing) {
        setSize(s => ({ w: Math.max(400, e.clientX - pos.x), h: Math.max(400, e.clientY - pos.y) }));
      }
    };
    const onUp = () => { setDragging(false); setResizing(false); };
    const onTouchMove = (e: TouchEvent) => {
      const t = e.touches[0];
      if (dragging) setPos({ x: Math.max(0, t.clientX - dragOffset.current.x), y: Math.max(0, t.clientY - dragOffset.current.y) });
    };
    const onTouchEnd = () => { setDragging(false); setResizing(false); };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    window.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('touchend', onTouchEnd);
    return () => { 
      window.removeEventListener('mousemove', onMove); 
      window.removeEventListener('mouseup', onUp); 
      window.removeEventListener('touchmove', onTouchMove); 
      window.removeEventListener('touchend', onTouchEnd); 
    };
  }, [dragging, resizing, pos]);

  // Create new session
  const createSession = async () => {
    try {
      const r = await fetch('/api/chat/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: selectedAgent,
          model: selectedModel,
          title: `Chat with ${agents.find(a => a.id === selectedAgent)?.displayName || selectedAgent}`,
        }),
      });
      const data = await r.json();
      
      if (data.sessionKey) {
        const newSession: Session = {
          id: data.sessionId,
          sessionKey: data.sessionKey,
          agentId: selectedAgent,
          model: selectedModel,
          title: data.title || `Chat with ${agents.find(a => a.id === selectedAgent)?.displayName || selectedAgent}`,
          status: 'active',
          createdAt: new Date().toISOString(),
        };
        setSessions(prev => [newSession, ...prev]);
        setCurrentSession(newSession);
        setMessages([]);
      }
    } catch (err) {
      console.error('Failed to create session:', err);
    }
  };

  // Load session messages
  const loadSessionMessages = async (session: Session) => {
    try {
      const r = await fetch(`/api/chat/sessions/${session.sessionKey}/messages?limit=50`);
      const data = await r.json();
      setMessages(data.messages || []);
    } catch (err) {
      console.error('Failed to load messages:', err);
      setMessages([]);
    }
  };

  // Select a session
  const selectSession = async (session: Session) => {
    setCurrentSession(session);
    await loadSessionMessages(session);
  };

  // Send message
  const sendMessage = async () => {
    if (!input.trim() || sending || !currentSession) return;
    
    const msg = input.trim();
    setInput('');
    setSending(true);

    // Add user message immediately
    const userMsg: ChatMsg = { role: 'user', content: msg, sender: 'You', timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);

    try {
      const r = await fetch(`/api/chat/sessions/${currentSession.sessionKey}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg }),
      });
      
      const data = await r.json();
      
      if (data.error) {
        setMessages(prev => [...prev, { role: 'assistant', content: `Error: ${data.error}`, sender: 'System' }]);
      } else if (data.response) {
        setMessages(prev => [...prev, { role: 'assistant', content: data.response, sender: currentSession.agentId, timestamp: new Date().toISOString() }]);
      } else {
        // Response may come async — poll for it
        await new Promise(resolve => setTimeout(resolve, 3000));
        await loadSessionMessages(currentSession);
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Connection error', sender: 'System' }]);
    }
    
    setSending(false);
  };

  // Close session
  const closeSession = async (sessionKey: string) => {
    try {
      await fetch(`/api/chat/sessions/${sessionKey}`, { method: 'DELETE' });
      setSessions(prev => prev.map(s => s.sessionKey === sessionKey ? { ...s, status: 'closed' } : s));
      if (currentSession?.sessionKey === sessionKey) {
        setCurrentSession(null);
        setMessages([]);
      }
    } catch (err) {
      console.error('Failed to close session:', err);
    }
  };

  // Minimized button
  if (!open) {
    return (
      <button onClick={() => setOpen(true)}
        style={{ touchAction: 'none' }}
        onPointerDown={(e) => {
          const el = e.currentTarget as HTMLElement;
          const startX = e.clientX - el.offsetLeft;
          const startY = e.clientY - el.offsetTop;
          let moved = false;
          const onMove = (ev: PointerEvent) => {
            moved = true;
            el.style.left = `${ev.clientX - startX}px`;
            el.style.top = `${ev.clientY - startY}px`;
            el.style.right = 'auto';
            el.style.bottom = 'auto';
          };
          const onUp = () => {
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            if (moved) { e.preventDefault(); }
          };
          document.addEventListener('pointermove', onMove);
          document.addEventListener('pointerup', onUp);
        }}
        className="fixed bottom-20 md:bottom-6 right-3 md:right-6 z-30 w-9 h-9 md:w-12 md:h-12 rounded-full bg-mc-accent/80 shadow-md flex items-center justify-center text-white text-sm md:text-xl hover:bg-mc-accent hover:scale-110 transition-all cursor-grab active:cursor-grabbing"
        title="Open Global Chat">
        💬
      </button>
    );
  }

  return (
    <div ref={chatRef}
      className="fixed z-50 bg-mc-surface border border-mc-border rounded-lg shadow-2xl flex overflow-hidden"
      style={{ left: pos.x, top: pos.y, width: size.w, height: size.h }}>

      {/* Sidebar - Session List */}
      <div className="w-48 border-r border-mc-border flex flex-col bg-mc-bg/50 flex-shrink-0">
        {/* New Chat Button */}
        <div className="p-2 border-b border-mc-border">
          <button onClick={createSession}
            className="w-full px-3 py-2 bg-mc-accent text-white rounded text-xs font-medium hover:bg-mc-accent/80 transition-colors">
            + New Chat
          </button>
        </div>

        {/* Agent + Model Selectors */}
        <div className="p-2 border-b border-mc-border space-y-2">
          <select value={selectedAgent} onChange={e => setSelectedAgent(e.target.value)}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text">
            {agents.filter(a => a.id !== 'kevin').map(a => (
              <option key={a.id} value={a.id}>{a.emoji || '🤖'} {a.displayName || a.name}</option>
            ))}
          </select>
          <select value={selectedModel} onChange={e => setSelectedModel(e.target.value)}
            className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text">
            {MODEL_OPTIONS.map(m => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
        </div>

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto">
          {loadingSessions ? (
            <div className="p-3 text-xs text-mc-muted">Loading...</div>
          ) : sessions.length === 0 ? (
            <div className="p-3 text-xs text-mc-muted">No sessions yet</div>
          ) : (
            sessions.map(session => (
              <div key={session.id}
                onClick={() => selectSession(session)}
                className={`p-2 border-b border-mc-border/50 cursor-pointer hover:bg-mc-surface transition-colors ${
                  currentSession?.id === session.id ? 'bg-mc-accent/10 border-l-2 border-l-mc-accent' : ''
                }`}>
                <div className="text-xs font-medium text-mc-text truncate">{session.title}</div>
                <div className="text-[10px] text-mc-muted flex items-center justify-between mt-1">
                  <span>{session.agentId}</span>
                  <span className={`w-2 h-2 rounded-full ${session.status === 'active' ? 'bg-green-500' : session.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'}`} />
                </div>
                {session.lastMessagePreview && (
                  <div className="text-[9px] text-mc-muted/70 truncate mt-1">{session.lastMessagePreview}</div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="px-3 py-2 border-b border-mc-border flex items-center gap-2 cursor-move flex-shrink-0 bg-mc-bg/50 select-none"
          onMouseDown={onMouseDown} onTouchStart={onTouchStart}>
          <span className="text-sm">💬</span>
          <span className="text-xs font-semibold flex-1 truncate">
            {currentSession ? currentSession.title : 'Select or create a chat'}
          </span>
          {currentSession && (
            <button onClick={() => closeSession(currentSession.sessionKey)}
              className="text-[10px] px-2 py-0.5 bg-red-500/20 text-red-400 rounded hover:bg-red-500/30">
              Close
            </button>
          )}
          <button onClick={() => setOpen(false)} className="text-mc-muted hover:text-mc-text text-sm ml-1">✕</button>
        </div>

        {/* Context bar */}
        <div className="px-3 py-1 border-b border-mc-border/50 text-[10px] text-mc-muted flex items-center gap-2 flex-shrink-0">
          <span>📍 {currentTab}</span>
          {currentContext && <span className="text-mc-accent truncate">{currentContext}</span>}
          {currentSession && (
            <span className="ml-auto flex items-center gap-1">
              {agents.find(a => a.id === currentSession.agentId)?.emoji} {currentSession.agentId}
              <span className="text-mc-muted">•</span>
              <span className="text-mc-muted/70">{currentSession.model}</span>
            </span>
          )}
        </div>

        {/* Messages */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-2 space-y-2 min-h-0">
          {!currentSession ? (
            <div className="text-center py-8 text-mc-muted text-xs">
              <div className="text-2xl mb-1">💬</div>
              <div>Select a session or click <span className="text-mc-accent">+ New Chat</span> to start</div>
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-8 text-mc-muted text-xs">
              <div>Start chatting with {agents.find(a => a.id === currentSession.agentId)?.displayName || currentSession.agentId}</div>
            </div>
          ) : (
            messages.map((m, i) => (
              <div key={i} className={`flex group ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-lg px-3 py-2 text-xs relative ${
                  m.role === 'user'
                    ? 'bg-mc-accent/20 text-mc-accent'
                    : 'bg-mc-bg border border-mc-border text-mc-text'
                }`}>
                  {m.role === 'assistant' && (
                    <div className="text-[10px] font-semibold text-mc-muted mb-1">{m.sender || 'Agent'}</div>
                  )}
                  <MarkdownMessage content={m.content} />
                  {m.timestamp && (
                    <span className="absolute -bottom-4 right-0 text-[9px] text-mc-muted opacity-0 group-hover:opacity-100 transition-opacity">
                      {new Date(m.timestamp).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
          {sending && (
            <div className="flex justify-start">
              <div className="bg-mc-bg border border-mc-border rounded-lg px-3 py-2 text-xs">
                <span className="text-mc-muted animate-pulse">Thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="px-2 py-2 border-t border-mc-border flex gap-2 flex-shrink-0">
          <input value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
            placeholder={!currentSession ? 'Select a session first' : (sending ? 'Thinking...' : 'Type a message...')}
            disabled={sending || !currentSession}
            className="flex-1 bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-xs focus:outline-none focus:border-mc-accent disabled:opacity-50" />
          <button onClick={sendMessage} disabled={sending || !currentSession || !input.trim()}
            className="px-3 py-1.5 bg-mc-accent text-white rounded text-xs hover:bg-mc-accent/80 disabled:opacity-50">
            {sending ? '⏳' : '→'}
          </button>
        </div>
      </div>

      {/* Resize handle */}
      <div className="absolute bottom-0 right-0 w-4 h-4 cursor-nwse-resize"
        onMouseDown={(e) => { setResizing(true); e.preventDefault(); e.stopPropagation(); }}>
        <svg viewBox="0 0 16 16" className="w-full h-full text-mc-muted/30">
          <path d="M14 14L8 14L14 8Z" fill="currentColor" />
        </svg>
      </div>
    </div>
  );
}