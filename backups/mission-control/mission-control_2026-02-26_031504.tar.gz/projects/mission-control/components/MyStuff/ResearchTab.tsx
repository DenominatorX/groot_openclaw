'use client';
import { useEffect, useMemo, useState } from 'react';
import MyStuffCard from './MyStuffCard';

type Item = { id: string; title: string; content?: string; metadata?: string; updated_at?: number };

export default function ResearchTab() {
  const [items, setItems] = useState<Item[]>([]);
  const [q, setQ] = useState('');
  const [tag, setTag] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);

  const load = async () => {
    const r = await fetch('/api/my-stuff?type=research');
    const j = await r.json();
    setItems(j.items || []);
  };
  useEffect(() => { load(); }, []);

  const tags = useMemo(() => {
    const all = new Set<string>();
    items.forEach((i) => {
      try { (JSON.parse(i.metadata || '{}').tags || []).forEach((t: string) => all.add(t)); } catch {}
    });
    return Array.from(all);
  }, [items]);

  const filtered = items.filter((i) => {
    const md: any = (() => { try { return JSON.parse(i.metadata || '{}'); } catch { return {}; } })();
    const hay = `${i.title || ''} ${i.content || ''}`.toLowerCase();
    const okQ = !q || hay.includes(q.toLowerCase());
    const okTag = !tag || (md.tags || []).includes(tag);
    return okQ && okTag;
  });

  const del = async (id: string) => { await fetch(`/api/my-stuff/${id}`, { method: 'DELETE' }); load(); };

  if (!items.length) return <p className="text-mc-muted">No research yet. Run <code>rv add &lt;url&gt;</code> from your terminal to save research here.</p>;

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search research..." className="px-3 py-2 rounded bg-mc-surface border border-mc-border" />
        <button onClick={() => setTag('')} className="px-2 py-1 border border-mc-border rounded">All</button>
        {tags.map((t) => <button key={t} onClick={() => setTag(t)} className="px-2 py-1 border border-mc-border rounded text-mc-accent">{t}</button>)}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((i) => {
          let md: any = {}; try { md = JSON.parse(i.metadata || '{}'); } catch {}
          return <MyStuffCard key={i.id}><div className="flex justify-between gap-2"><h3 className="font-semibold text-mc-text">{i.title}</h3><button className="text-red-400" onClick={() => del(i.id)}>Delete</button></div><p className="text-mc-muted text-sm mt-1">{expanded===i.id?i.content:(i.content||'').slice(0,160)}</p><div className="mt-2 flex gap-2 flex-wrap">{(md.tags||[]).map((t:string)=><span key={t} className="text-xs px-2 py-1 rounded bg-mc-border">{t}</span>)}</div>{md.url && <a className="text-mc-accent text-sm" href={md.url} target="_blank">Open source ↗</a>}<div><button className="text-xs text-mc-muted" onClick={()=>setExpanded(expanded===i.id?null:i.id)}>{expanded===i.id?'Collapse':'Expand'}</button></div></MyStuffCard>;
        })}
      </div>
    </div>
  );
}
