'use client';
export default function FilesTab() {
  return <div className="bg-mc-surface border border-mc-border rounded-lg p-4 text-mc-muted">Files tab coming soon.</div>;
}
