'use client';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MarkdownMessageProps {
  content: string;
}

export default function MarkdownMessage({ content }: MarkdownMessageProps) {
  return (
    <div className="text-xs md:text-sm text-mc-text/90 leading-relaxed">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Tables
          table: ({ children }) => (
            <div className="overflow-x-auto my-2">
              <table className="min-w-full text-xs border border-mc-border rounded overflow-hidden">
                {children}
              </table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-mc-bg/50">{children}</thead>
          ),
          tbody: ({ children }) => (
            <tbody className="divide-y divide-mc-border/50">{children}</tbody>
          ),
          tr: ({ children }) => (
            <tr className="even:bg-mc-bg/30">{children}</tr>
          ),
          th: ({ children }) => (
            <th className="px-3 py-1.5 text-left font-semibold text-mc-text border-b border-mc-border">{children}</th>
          ),
          td: ({ children }) => (
            <td className="px-3 py-1.5 text-mc-text/80">{children}</td>
          ),
          
          // Code blocks
          code: ({ className, children, ...props }) => {
            const isInline = !className;
            if (isInline) {
              return (
                <code className="bg-mc-bg/50 rounded px-1 text-mc-text/90 font-mono text-xs" {...props}>
                  {children}
                </code>
              );
            }
            return (
              <code className={`${className} block bg-mc-bg border border-mc-border rounded p-3 my-2 overflow-x-auto text-xs font-mono text-mc-text/90`} {...props}>
                {children}
              </code>
            );
          },
          pre: ({ children }) => (
            <pre className="overflow-x-auto my-2">{children}</pre>
          ),
          
          // Lists
          ul: ({ children }) => (
            <ul className="list-disc list-inside my-1 space-y-0.5 text-mc-text/90">{children}</ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal list-inside my-1 space-y-0.5 text-mc-text/90">{children}</ol>
          ),
          li: ({ children }) => (
            <li className="text-mc-text/90">{children}</li>
          ),
          
          // Blockquotes
          blockquote: ({ children }) => (
            <blockquote className="border-l-2 border-mc-accent/50 pl-3 my-2 text-mc-muted italic">
              {children}
            </blockquote>
          ),
          
          // Text formatting
          strong: ({ children }) => (
            <strong className="font-semibold text-mc-text">{children}</strong>
          ),
          em: ({ children }) => (
            <em className="italic text-mc-text/80">{children}</em>
          ),
          p: ({ children }) => (
            <p className="my-1">{children}</p>
          ),
          
          // Headings
          h1: ({ children }) => (
            <h1 className="text-lg font-bold text-mc-text mt-3 mb-1">{children}</h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-base font-bold text-mc-text mt-2 mb-1">{children}</h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-sm font-semibold text-mc-text mt-2 mb-1">{children}</h3>
          ),
          
          // Links
          a: ({ children, href }) => (
            <a href={href} className="text-mc-accent hover:underline" target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          ),
          
          // Horizontal rule
          hr: () => (
            <hr className="my-3 border-mc-border" />
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
