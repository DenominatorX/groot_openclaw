'use client';

import { useState, useEffect, useRef, Suspense } from 'react';
import dynamic from 'next/dynamic';
// XR store removed temporarily - VR entry will be re-added with proper WebXR integration

// Dynamic import for Three.js components (client-only, no SSR)
const VRCanvas = dynamic(() => import('./VRCanvas'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full bg-mc-bg">
      <div className="text-center">
        <div className="text-4xl mb-4">🥽</div>
        <div className="text-mc-muted">Loading VR Environment...</div>
      </div>
    </div>
  )
});

// Types for VR Mode
interface TaskSummary {
  todo: number;
  inProgress: number;
  done: number;
  total: number;
}

interface HealthData {
  sleepScore?: number;
  readiness?: number;
  hrv?: number;
  restingHR?: number;
}

interface Agent {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'error' | 'busy';
  tier: number;
}

// Fetch data from MC APIs
async function fetchTaskSummary(): Promise<TaskSummary> {
  try {
    const res = await fetch('/api/tasks');
    const data = await res.json();
    const tasks = data.tasks || data.data?.tasks || [];
    return {
      todo: tasks.filter((t: any) => t.status === 'todo').length,
      inProgress: tasks.filter((t: any) => t.status === 'in-progress').length,
      done: tasks.filter((t: any) => t.status === 'done').length,
      total: tasks.length
    };
  } catch {
    return { todo: 12, inProgress: 5, done: 28, total: 45 }; // Mock data
  }
}

async function fetchHealthData(): Promise<HealthData> {
  try {
    const res = await fetch('/api/oura/summary');
    if (res.ok) {
      const data = await res.json();
      return {
        sleepScore: data.sleep_score || 75,
        readiness: data.readiness || 80,
        hrv: data.hrv || 45,
        restingHR: data.resting_hr || 58
      };
    }
  } catch {
    // Ignore
  }
  // Fallback mock data
  return { sleepScore: 78, readiness: 82, hrv: 52, restingHR: 56 };
}

async function fetchAgents(): Promise<Agent[]> {
  try {
    const res = await fetch('/api/agents');
    const data = await res.json();
    const agentsList = data?.agents || [];
    if (!Array.isArray(agentsList)) return getMockAgents();
    return agentsList.map((a: any) => ({
      id: a?.id || 'unknown',
      name: a?.displayName || a?.name || 'Unknown',
      status: a?.status === 'active' ? 'active' : 'idle',
      tier: a?.tier || 3
    }));
  } catch {
    return getMockAgents();
  }
}

function getMockAgents(): Agent[] {
  return [
    { id: 'ceo', name: 'CEO', status: 'active', tier: 0 },
    { id: 'brain', name: 'Brain', status: 'active', tier: 1 },
    { id: 'groot', name: 'Groot', status: 'active', tier: 2 },
    { id: 'pixel', name: 'Pixel', status: 'idle', tier: 4 },
    { id: 'forge', name: 'Forge', status: 'busy', tier: 4 },
    { id: 'floof', name: 'Floof', status: 'idle', tier: 4 },
    { id: 'spark', name: 'Spark', status: 'active', tier: 5 },
    { id: 'atlas', name: 'Atlas', status: 'idle', tier: 4 },
  ];
}

interface VRModeProps {
  // Props if needed
}

export default function VRMode({}: VRModeProps) {
  const [taskData, setTaskData] = useState<TaskSummary | null>(null);
  const [healthData, setHealthData] = useState<HealthData | null>(null);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [vrSupported, setVrSupported] = useState(false);
  const [panelExpanded, setPanelExpanded] = useState<string | null>(null);

  // Check VR support
  useEffect(() => {
    if (typeof navigator !== 'undefined' && navigator.xr) {
      navigator.xr.isSessionSupported('immersive-vr').then(supported => {
        setVrSupported(supported);
      }).catch(() => setVrSupported(false));
    }
  }, []);

  // Fetch data on mount
  useEffect(() => {
    async function loadData() {
      const [tasks, health, agentList] = await Promise.all([
        fetchTaskSummary(),
        fetchHealthData(),
        fetchAgents()
      ]);
      setTaskData(tasks);
      setHealthData(health);
      setAgents(agentList);
      setLoading(false);
    }
    loadData();

    // Refresh data every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  // Handle panel click - expand to full view
  const handlePanelClick = (panelId: string) => {
    setPanelExpanded(panelId === panelExpanded ? null : panelId);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-mc-surface border-b border-mc-border">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🥽</span>
          <div>
            <h2 className="text-sm font-bold text-mc-text">VR Command Center</h2>
            <p className="text-xs text-mc-muted">
              {vrSupported ? '🎮 VR Headset supported' : '🖥️ Desktop mode active'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {vrSupported && (
            <button 
              onClick={() => alert('WebXR VR mode coming soon — use desktop 3D view for now')}
              className="px-3 py-1.5 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 transition-colors"
            >
              Enter VR
            </button>
          )}
          <button 
            onClick={() => window.location.reload()}
            className="px-3 py-1.5 text-xs text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
            title="Refresh data"
          >
            🔄
          </button>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex-1 flex items-center justify-center bg-mc-bg">
          <div className="text-center">
            <div className="animate-pulse text-4xl mb-4">⚡</div>
            <div className="text-mc-muted">Loading dashboard data...</div>
          </div>
        </div>
      )}

      {/* 3D Canvas */}
      {!loading && (
        <div className="flex-1 relative bg-black">
          <VRCanvas 
            taskData={taskData} 
            healthData={healthData} 
            agents={agents}
            panelExpanded={panelExpanded}
            onPanelClick={handlePanelClick}
          />
          
          {/* Floating 2D overlays for expanded panels */}
          {panelExpanded && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
              <div className="bg-mc-surface border border-mc-accent/50 rounded-lg p-6 max-w-2xl w-full mx-4 shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-mc-accent">
                    {panelExpanded === 'tasks' && '📋 Task Board Details'}
                    {panelExpanded === 'health' && '❤️ Health Vitals'}
                    {panelExpanded === 'agents' && '🤖 Agent Status'}
                    {panelExpanded === 'brain' && '🧠 Brain Chat'}
                  </h3>
                  <button 
                    onClick={() => setPanelExpanded(null)}
                    className="text-mc-muted hover:text-mc-text text-xl"
                  >
                    ✕
                  </button>
                </div>
                <div className="text-mc-muted text-sm">
                  {/* Detailed view content would go here */}
                  <p>Click a panel in 3D view to interact with detailed data.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Legend / Controls */}
      <div className="px-4 py-2 bg-mc-surface border-t border-mc-border text-xs text-mc-muted">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span>🖱️ Drag to rotate</span>
            <span>🔍 Scroll to zoom</span>
            <span>👆 Click panel to expand</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            <span>Live</span>
          </div>
        </div>
      </div>
    </div>
  );
}
