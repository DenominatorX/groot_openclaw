'use client';

import React, { useState, useEffect } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Spinner } from '@/components/ui/Spinner';
import './PitchDeckApp.css';

// Types
interface CompanyBasics {
  name: string;
  tagline: string;
  industry: string;
  stage: 'seed' | 'series-a' | 'series-b' | 'growth';
}

interface Slide {
  slideNumber: number;
  type: string;
  title: string;
  content: Record<string, any>;
  notes?: string;
}

interface Deck {
  id: string;
  name: string;
  template: string;
  companyBasics: CompanyBasics;
  slides: Slide[];
  createdAt: string;
  updatedAt: string;
  version: number;
}

interface Template {
  id: string;
  name: string;
  stage: string;
  slideOrder: string[];
  description: string;
}

interface InvestorProfile {
  name: string;
  firm: string;
  focus: string;
  portfolio: string[];
  pitchTips: string[];
}

const TEMPLATES: Template[] = [
  {
    id: 'seed-stage',
    name: 'Seed Stage',
    stage: 'seed',
    slideOrder: ['cover', 'problem', 'solution', 'market', 'business-model', 'team', 'ask'],
    description: 'Perfect for early-stage startups seeking seed funding.',
  },
  {
    id: 'series-a',
    name: 'Series A',
    stage: 'series-a',
    slideOrder: ['cover', 'problem', 'solution', 'market', 'traction', 'business-model', 'financials', 'team', 'ask'],
    description: 'For growing companies demonstrating traction.',
  },
  {
    id: 'saas',
    name: 'B2B SaaS',
    stage: 'seed',
    slideOrder: ['cover', 'problem', 'solution', 'market', 'unit-economics', 'traction', 'business-model', 'financials', 'team', 'ask'],
    description: 'Optimized for SaaS businesses.',
  },
  {
    id: 'marketplace',
    name: 'Marketplace',
    stage: 'seed',
    slideOrder: ['cover', 'problem', 'solution', 'market', 'unit-economics', 'traction', 'go-to-market', 'team', 'ask'],
    description: 'For marketplace and platform businesses.',
  },
  {
    id: 'hardware',
    name: 'Hardware',
    stage: 'seed',
    slideOrder: ['cover', 'problem', 'solution', 'market', 'product', 'traction', 'manufacturing', 'team', 'ask'],
    description: 'For hardware startups.',
  },
  {
    id: 'biotech',
    name: 'Biotech',
    stage: 'seed',
    slideOrder: ['cover', 'problem', 'science', 'market', 'development', 'team', 'ask'],
    description: 'For biotech and life sciences companies.',
  },
];

const SLIDE_TEMPLATES: Record<string, { title: string; description: string; fields: string[] }> = {
  cover: {
    title: 'Title Slide',
    description: 'Your company name, tagline, and opening impression.',
    fields: ['company_name', 'tagline', 'subtitle'],
  },
  problem: {
    title: 'Problem',
    description: 'Define the problem you\'re solving.',
    fields: ['problem_statement', 'problem_size', 'current_solutions'],
  },
  solution: {
    title: 'Solution',
    description: 'How your product solves the problem.',
    fields: ['solution_description', 'key_features', 'competitive_advantage'],
  },
  market: {
    title: 'Market Size',
    description: 'TAM, SAM, SOM analysis.',
    fields: ['tam', 'sam', 'som', 'market_trends'],
  },
  traction: {
    title: 'Traction',
    description: 'Metrics showing product-market fit progress.',
    fields: ['users', 'revenue', 'growth_rate', 'key_metrics'],
  },
  'business-model': {
    title: 'Business Model',
    description: 'How you make money.',
    fields: ['revenue_model', 'pricing', 'customer_acquisition'],
  },
  financials: {
    title: 'Financials',
    description: 'Revenue projections and unit economics.',
    fields: ['revenue_projections', 'gross_margin', 'unit_economics'],
  },
  team: {
    title: 'Team',
    description: 'Your founding and leadership team.',
    fields: ['team_members', 'key_experience', 'roles'],
  },
  ask: {
    title: 'Ask',
    description: 'Funding amount and use of funds.',
    fields: ['funding_amount', 'use_of_funds', 'timeline'],
  },
  'unit-economics': {
    title: 'Unit Economics',
    description: 'LTV, CAC, and payback period.',
    fields: ['ltv', 'cac', 'payback_period', 'margins'],
  },
  'go-to-market': {
    title: 'Go-to-Market',
    description: 'Your launch and growth strategy.',
    fields: ['gtm_strategy', 'channels', 'partnerships'],
  },
  product: {
    title: 'Product',
    description: 'Product details and development status.',
    fields: ['product_description', 'development_stage', 'timeline'],
  },
  science: {
    title: 'Science',
    description: 'Scientific foundation and innovation.',
    fields: ['research_background', 'ip_protection', 'research_stage'],
  },
  manufacturing: {
    title: 'Manufacturing',
    description: 'Production and supply chain details.',
    fields: ['manufacturing_plan', 'suppliers', 'cost_of_goods'],
  },
  development: {
    title: 'Development',
    description: 'Regulatory and development milestones.',
    fields: ['development_milestones', 'regulatory_path', 'timeline'],
  },
};

export function PitchDeckApp() {
  const [view, setView] = useState<'library' | 'editor' | 'practice' | 'investor-research'>('library');
  const [decks, setDecks] = useLocalStorage('pitch-decks', {} as Record<string, Deck>);
  const [currentDeck, setCurrentDeck] = useState<Deck | null>(null);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [editingCompanyBasics, setEditingCompanyBasics] = useState(false);
  const [practiceMode, setPracticeMode] = useState(false);
  const [investorName, setInvestorName] = useState('');
  const [investorProfile, setInvestorProfile] = useState<InvestorProfile | null>(null);

  // Create new deck
  const createNewDeck = async (templateId: string, companyBasics: CompanyBasics, autoGenerate: boolean = false) => {
    setIsLoading(true);

    const template = TEMPLATES.find((t) => t.id === templateId);
    if (!template) return;

    const newDeck: Deck = {
      id: `deck-${Date.now()}`,
      name: companyBasics.name,
      template: templateId,
      companyBasics,
      slides: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1,
    };

    if (autoGenerate) {
      // Call AI to generate all slides
      try {
        const response = await fetch('/api/apps/pitch-deck', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'generate-full-deck',
            template: templateId,
            companyBasics,
            slideOrder: template.slideOrder,
          }),
        });

        if (!response.ok) throw new Error('Failed to generate deck');
        const data = await response.json();
        newDeck.slides = data.slides;
      } catch (error) {
        console.error(error);
        // Create empty slides
        newDeck.slides = template.slideOrder.map((slideType, idx) => ({
          slideNumber: idx + 1,
          type: slideType,
          title: SLIDE_TEMPLATES[slideType]?.title || slideType,
          content: {},
        }));
      }
    } else {
      // Create empty slides
      newDeck.slides = template.slideOrder.map((slideType, idx) => ({
        slideNumber: idx + 1,
        type: slideType,
        title: SLIDE_TEMPLATES[slideType]?.title || slideType,
        content: {},
      }));
    }

    const updatedDecks = { ...decks, [newDeck.id]: newDeck };
    setDecks(updatedDecks);
    setCurrentDeck(newDeck);
    setCurrentSlideIndex(0);
    setView('editor');
    setIsLoading(false);
  };

  // Generate single slide content
  const generateSlideContent = async (slideType: string) => {
    if (!currentDeck) return;

    setIsLoading(true);

    try {
      const response = await fetch('/api/apps/pitch-deck', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate-slide',
          slideType,
          companyBasics: currentDeck.companyBasics,
        }),
      });

      if (!response.ok) throw new Error('Failed to generate slide content');
      const data = await response.json();

      const updatedSlides = [...currentDeck.slides];
      updatedSlides[currentSlideIndex].content = data.content;
      updatedSlides[currentSlideIndex].notes = data.notes;

      const updated = { ...currentDeck, slides: updatedSlides, updatedAt: new Date().toISOString() };
      setCurrentDeck(updated);

      const updatedDecks = { ...decks, [updated.id]: updated };
      setDecks(updatedDecks);
    } catch (error) {
      console.error(error);
    }

    setIsLoading(false);
  };

  // Update slide content
  const updateSlideContent = (slideIndex: number, newContent: Record<string, any>) => {
    if (!currentDeck) return;

    const updatedSlides = [...currentDeck.slides];
    updatedSlides[slideIndex].content = newContent;

    const updated = { ...currentDeck, slides: updatedSlides, updatedAt: new Date().toISOString() };
    setCurrentDeck(updated);

    const updatedDecks = { ...decks, [updated.id]: updated };
    setDecks(updatedDecks);
  };

  // Save deck
  const saveDeck = () => {
    if (!currentDeck) return;

    const updated = { ...currentDeck, updatedAt: new Date().toISOString() };
    setCurrentDeck(updated);

    const updatedDecks = { ...decks, [updated.id]: updated };
    setDecks(updatedDecks);
  };

  // Delete deck
  const deleteDeck = (deckId: string) => {
    const updatedDecks = { ...decks };
    delete updatedDecks[deckId];
    setDecks(updatedDecks);

    if (currentDeck?.id === deckId) {
      setCurrentDeck(null);
      setView('library');
    }
  };

  // Duplicate deck
  const duplicateDeck = (deckId: string) => {
    const original = decks[deckId];
    if (!original) return;

    const newDeck: Deck = {
      ...original,
      id: `deck-${Date.now()}`,
      name: `${original.name} (Copy)`,
      version: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updatedDecks = { ...decks, [newDeck.id]: newDeck };
    setDecks(updatedDecks);
  };

  // Export as markdown
  const exportAsMarkdown = (deck: Deck): string => {
    let md = `# ${deck.companyBasics.name}\n\n`;
    md += `> ${deck.companyBasics.tagline}\n\n`;

    deck.slides.forEach((slide) => {
      md += `## ${slide.title}\n\n`;
      md += Object.entries(slide.content)
        .map(([key, value]) => `- **${key}**: ${value}`)
        .join('\n');
      md += '\n\n';
    });

    return md;
  };

  // Research investor
  const researchInvestor = async () => {
    if (!investorName.trim()) return;

    setIsLoading(true);

    try {
      const response = await fetch('/api/apps/pitch-deck', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'research-investor',
          investorName,
        }),
      });

      if (!response.ok) throw new Error('Failed to research investor');
      const data = await response.json();

      setInvestorProfile(data.profile);
    } catch (error) {
      console.error(error);
      // Fallback
      setInvestorProfile({
        name: investorName,
        firm: 'Investment Firm',
        focus: 'Early-stage startups',
        portfolio: ['Company A', 'Company B'],
        pitchTips: [
          'Focus on market size and traction',
          'Be clear about your competitive advantage',
          'Have a strong go-to-market strategy',
        ],
      });
    }

    setIsLoading(false);
  };

  // Practice mode question
  const askPracticeQuestion = async () => {
    if (!currentDeck) return;

    setIsLoading(true);

    try {
      const response = await fetch('/api/apps/pitch-deck', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'practice-question',
          companyBasics: currentDeck.companyBasics,
        }),
      });

      if (!response.ok) throw new Error('Failed to generate question');
      const data = await response.json();

      // In a real implementation, this would show a Q&A interface
      alert(`Investor Question: ${data.question}\n\nYou: [Practice your answer]`);
    } catch (error) {
      console.error(error);
    }

    setIsLoading(false);
  };

  // View: Library
  if (view === 'library') {
    return (
      <div className="pitch-deck-container">
        <div className="deck-library">
          <div className="library-header">
            <h1>📊 Pitch Deck Builder</h1>
            <p>Create professional pitch decks with AI assistance</p>
          </div>

          {Object.keys(decks).length === 0 ? (
            <div className="empty-state">
              <p>No decks yet. Create one to get started.</p>
            </div>
          ) : (
            <div className="decks-grid">
              {Object.entries(decks).map(([id, deck]) => (
                <div key={id} className="deck-card">
                  <div className="deck-card-header">
                    <h3>{deck.name}</h3>
                    <span className="template-badge">{TEMPLATES.find((t) => t.id === deck.template)?.name}</span>
                  </div>
                  <p className="deck-meta">
                    {deck.slides.length} slides • {new Date(deck.createdAt).toLocaleDateString()}
                  </p>
                  <div className="deck-card-actions">
                    <button className="btn-edit" onClick={() => { setCurrentDeck(deck); setView('editor'); }}>
                      Edit
                    </button>
                    <button className="btn-duplicate" onClick={() => duplicateDeck(id)}>
                      Duplicate
                    </button>
                    <button className="btn-delete" onClick={() => deleteDeck(id)}>
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="new-deck-section">
            <h2>Create New Deck</h2>
            <div className="templates-grid">
              {TEMPLATES.map((template) => (
                <div key={template.id} className="template-card">
                  <h4>{template.name}</h4>
                  <p>{template.description}</p>
                  <button className="btn-select-template" onClick={() => {
                    const name = prompt('Company name:', 'My Startup');
                    const tagline = prompt('Tagline:', 'Solving a real problem');
                    if (name && tagline) {
                      const companyBasics: CompanyBasics = {
                        name,
                        tagline,
                        industry: 'Technology',
                        stage: 'seed',
                      };
                      createNewDeck(template.id, companyBasics, false);
                    }
                  }}>
                    Create from template
                  </button>
                </div>
              ))}
            </div>

            <div className="quick-generate">
              <h3>Or generate a full deck instantly...</h3>
              <div className="quick-form">
                <input type="text" placeholder="Describe your startup in 2 sentences..." id="quick-desc" />
                <button className="btn-generate-full" onClick={() => {
                  const desc = (document.getElementById('quick-desc') as HTMLInputElement)?.value;
                  if (desc) {
                    const companyBasics: CompanyBasics = {
                      name: 'My Startup',
                      tagline: desc.substring(0, 100),
                      industry: 'Technology',
                      stage: 'seed',
                    };
                    createNewDeck('seed-stage', companyBasics, true);
                  }
                }}>
                  🤖 Generate Full Deck
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="sidebar-actions">
          <button className="btn-investor-research" onClick={() => setView('investor-research')}>
            👔 Investor Research
          </button>
          <button className="btn-practice" onClick={() => { setPracticeMode(true); setView('practice'); }}>
            🎯 Practice Mode
          </button>
        </div>
      </div>
    );
  }

  // View: Editor
  if (view === 'editor' && currentDeck) {
    const currentSlide = currentDeck.slides[currentSlideIndex];
    const slideTemplate = SLIDE_TEMPLATES[currentSlide.type];

    return (
      <div className="pitch-deck-container editor-mode">
        <div className="editor-header">
          <div className="deck-title-section">
            <button className="btn-back" onClick={() => { saveDeck(); setView('library'); }}>
              ← Back
            </button>
            <h1>{currentDeck.name}</h1>
            <button className="btn-export" onClick={() => {
              const md = exportAsMarkdown(currentDeck);
              navigator.clipboard.writeText(md);
              alert('Deck exported to clipboard!');
            }}>
              📋 Export as Markdown
            </button>
          </div>
        </div>

        <div className="editor-layout">
          {/* Slide Thumbnails */}
          <div className="slide-nav">
            <div className="nav-header">
              <h3>Slides</h3>
              <p className="nav-count">{currentSlideIndex + 1} / {currentDeck.slides.length}</p>
            </div>
            <div className="slide-list">
              {currentDeck.slides.map((slide, idx) => (
                <button
                  key={idx}
                  className={`slide-thumbnail ${idx === currentSlideIndex ? 'active' : ''}`}
                  onClick={() => setCurrentSlideIndex(idx)}
                >
                  <span className="slide-number">{slide.slideNumber}</span>
                  <span className="slide-title">{slide.title}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Slide Editor */}
          <div className="slide-editor">
            <div className="slide-panel">
              <div className="slide-header">
                <h2>{currentSlide.title}</h2>
                <p className="slide-type">{slideTemplate?.description}</p>
              </div>

              {editingCompanyBasics ? (
                <div className="company-basics-edit">
                  <h3>Company Basics</h3>
                  <input
                    type="text"
                    placeholder="Company name"
                    value={currentDeck.companyBasics.name}
                    onChange={(e) => {
                      setCurrentDeck({
                        ...currentDeck,
                        companyBasics: { ...currentDeck.companyBasics, name: e.target.value },
                      });
                    }}
                  />
                  <input
                    type="text"
                    placeholder="Tagline"
                    value={currentDeck.companyBasics.tagline}
                    onChange={(e) => {
                      setCurrentDeck({
                        ...currentDeck,
                        companyBasics: { ...currentDeck.companyBasics, tagline: e.target.value },
                      });
                    }}
                  />
                  <input
                    type="text"
                    placeholder="Industry"
                    value={currentDeck.companyBasics.industry}
                    onChange={(e) => {
                      setCurrentDeck({
                        ...currentDeck,
                        companyBasics: { ...currentDeck.companyBasics, industry: e.target.value },
                      });
                    }}
                  />
                  <button className="btn-done" onClick={() => setEditingCompanyBasics(false)}>
                    Done
                  </button>
                </div>
              ) : (
                <div className="slide-content">
                  {slideTemplate?.fields.map((field) => (
                    <div key={field} className="field-group">
                      <label>{field.replace(/_/g, ' ')}</label>
                      <textarea
                        placeholder={`Enter ${field.replace(/_/g, ' ')}...`}
                        value={currentSlide.content[field] || ''}
                        onChange={(e) => {
                          const newContent = { ...currentSlide.content, [field]: e.target.value };
                          updateSlideContent(currentSlideIndex, newContent);
                        }}
                        rows={3}
                      />
                    </div>
                  ))}

                  <div className="slide-actions">
                    <button className="btn-ai-generate" onClick={() => generateSlideContent(currentSlide.type)} disabled={isLoading}>
                      {isLoading ? <Spinner /> : '🤖 Generate Content'}
                    </button>
                    <button className="btn-company-basics" onClick={() => setEditingCompanyBasics(true)}>
                      ⚙️ Company Basics
                    </button>
                  </div>

                  {currentSlide.notes && (
                    <div className="slide-notes">
                      <h4>Speaker Notes</h4>
                      <p>{currentSlide.notes}</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Slide Preview */}
            <div className="slide-preview">
              <div className="preview-card">
                <h3>{currentSlide.title}</h3>
                <div className="preview-content">
                  {Object.entries(currentSlide.content).map(([key, value]) => (
                    <div key={key} className="preview-field">
                      <strong>{key}:</strong> {value}
                    </div>
                  ))}
                </div>
              </div>

              <div className="preview-navigation">
                <button
                  disabled={currentSlideIndex === 0}
                  onClick={() => setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))}
                >
                  ← Previous
                </button>
                <span>{currentSlideIndex + 1} / {currentDeck.slides.length}</span>
                <button
                  disabled={currentSlideIndex === currentDeck.slides.length - 1}
                  onClick={() => setCurrentSlideIndex(Math.min(currentDeck.slides.length - 1, currentSlideIndex + 1))}
                >
                  Next →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // View: Practice Mode
  if (view === 'practice') {
    return (
      <div className="pitch-deck-container practice-mode">
        <button className="btn-back" onClick={() => setView('library')}>
          ← Back to Library
        </button>

        <div className="practice-container">
          <h1>🎯 Practice Mode</h1>
          <p>Practice pitching to an AI investor. Answer tough questions and improve your pitch.</p>

          {currentDeck ? (
            <div className="practice-section">
              <p className="current-deck">Practicing with: {currentDeck.name}</p>

              <div className="practice-interface">
                <h3>Investor Question:</h3>
                <div className="question-box">
                  <p>Tell me about your company and why it's going to succeed.</p>
                </div>

                <h3>Your Answer:</h3>
                <textarea className="answer-input" placeholder="Practice your pitch..." rows={6} />

                <button className="btn-next-question" onClick={() => askPracticeQuestion()}>
                  {isLoading ? <Spinner /> : '📋 Next Question'}
                </button>
              </div>
            </div>
          ) : (
            <div className="empty-state">
              <p>Select a deck from the library to start practicing.</p>
              <button className="btn-library" onClick={() => setView('library')}>
                Go to Library
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // View: Investor Research
  if (view === 'investor-research') {
    return (
      <div className="pitch-deck-container investor-research-mode">
        <button className="btn-back" onClick={() => setView('library')}>
          ← Back to Library
        </button>

        <div className="research-container">
          <h1>👔 Investor Research</h1>
          <p>Learn about investors and how to pitch to them effectively.</p>

          <div className="research-input-section">
            <h3>Search for an Investor</h3>
            <div className="search-form">
              <input
                type="text"
                placeholder="Investor name or firm..."
                value={investorName}
                onChange={(e) => setInvestorName(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') researchInvestor();
                }}
              />
              <button className="btn-search" onClick={() => researchInvestor()} disabled={isLoading}>
                {isLoading ? <Spinner /> : '🔍 Research'}
              </button>
            </div>
          </div>

          {investorProfile && (
            <div className="investor-profile">
              <div className="profile-header">
                <h2>{investorProfile.name}</h2>
                <p className="profile-firm">{investorProfile.firm}</p>
              </div>

              <div className="profile-section">
                <h3>Focus Area</h3>
                <p>{investorProfile.focus}</p>
              </div>

              <div className="profile-section">
                <h3>Portfolio Companies</h3>
                <ul className="portfolio-list">
                  {(investorProfile.portfolio || []).map((company, idx) => (
                    <li key={idx}>{company}</li>
                  ))}
                </ul>
              </div>

              <div className="profile-section">
                <h3>Pitching Tips</h3>
                <ul className="tips-list">
                  {(investorProfile.pitchTips || []).map((tip, idx) => (
                    <li key={idx}>{tip}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
}
