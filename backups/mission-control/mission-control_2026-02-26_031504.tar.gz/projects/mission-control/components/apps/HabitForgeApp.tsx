'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Flame, Crown, Zap, Target, TrendingUp, Calendar, BarChart3, AlertCircle, Save, Plus, X, Share2, CheckCircle2 } from 'lucide-react';

interface Habit {
  id: string;
  name: string;
  category: 'health' | 'fitness' | 'productivity' | 'learning' | 'mindfulness' | 'social' | 'financial';
  frequency: 'daily' | 'weekly' | 'MWF' | 'weekdays';
  difficulty: 'easy' | 'medium' | 'hard';
  targetTime?: string;
  createdAt: Date;
  active: boolean;
}

interface CheckIn {
  habitId: string;
  date: string;
  completed: boolean;
  notes: string;
}

interface ProgressData {
  habitId: string;
  currentStreak: number;
  bestStreak: number;
  totalCompleted: number;
  completionRate: number;
}

interface UserProgress {
  totalXP: number;
  level: number;
  title: string;
  badges: string[];
  challengesActive: Array<{ name: string; daysCompleted: number; targetDays: number }>;
}

const TITLES = ['Novice', 'Apprentice', 'Journeyman', 'Expert', 'Master', 'Grandmaster'];
const XP_PER_LEVEL = 500;
const CATEGORY_COLORS = {
  health: '#ef4444',
  fitness: '#f97316',
  productivity: '#3b82f6',
  learning: '#8b5cf6',
  mindfulness: '#06b6d4',
  social: '#ec4899',
  financial: '#10b981',
};

const HabitForgeApp: React.FC = () => {
  const [view, setView] = useState<'dashboard' | 'add-habit' | 'today' | 'progress' | 'coaching'>('dashboard');
  const [habits, setHabits] = useState<Habit[]>([]);
  const [checkIns, setCheckIns] = useState<CheckIn[]>([]);
  const [progress, setProgress] = useState<Record<string, ProgressData>>({});
  const [userProgress, setUserProgress] = useState<UserProgress>({
    totalXP: 0,
    level: 1,
    title: TITLES[0],
    badges: [],
    challengesActive: [],
  });

  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [dayRating, setDayRating] = useState<number | null>(null);
  const [coachMessage, setCoachMessage] = useState<string>('');
  const [loading, setLoading] = useState(false);

  // Form state
  const [newHabit, setNewHabit] = useState({
    name: '',
    category: 'health' as 'health' | 'fitness' | 'productivity' | 'learning' | 'mindfulness' | 'social' | 'financial',
    frequency: 'daily' as 'daily' | 'weekly' | 'MWF' | 'weekdays',
    difficulty: 'medium' as 'easy' | 'medium' | 'hard',
    targetTime: '',
  });

  // Load data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('habit-forge-saves');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setHabits(data.habits || []);
        setCheckIns(data.checkIns || []);
        setProgress(data.progress || {});
        setUserProgress(data.userProgress || {
          totalXP: 0,
          level: 1,
          title: TITLES[0],
          badges: [],
          challengesActive: [],
        });
      } catch (e) {
        console.error('Failed to load saved data');
      }
    }
  }, []);

  // Save data to localStorage
  const saveData = useCallback(() => {
    localStorage.setItem('habit-forge-saves', JSON.stringify({
      habits,
      checkIns,
      progress,
      userProgress,
    }));
  }, [habits, checkIns, progress, userProgress]);

  useEffect(() => {
    saveData();
  }, [habits, checkIns, progress, userProgress, saveData]);

  const addHabit = () => {
    if (!newHabit.name.trim()) return;

    const habit: Habit = {
      id: Date.now().toString(),
      name: newHabit.name,
      category: newHabit.category as 'health' | 'fitness' | 'productivity' | 'learning' | 'mindfulness' | 'social' | 'financial',
      frequency: newHabit.frequency,
      difficulty: newHabit.difficulty,
      targetTime: newHabit.targetTime,
      createdAt: new Date(),
      active: true,
    };

    setHabits((prev) => [...prev, habit]);
    setProgress((prev) => ({
      ...prev,
      [habit.id]: { habitId: habit.id, currentStreak: 0, bestStreak: 0, totalCompleted: 0, completionRate: 0 },
    }));

    setNewHabit({ name: '', category: 'health', frequency: 'daily', difficulty: 'medium', targetTime: '' });
    setView('dashboard');

    // Generate AI suggestion
    generateAiSuggestion();
  };

  const toggleHabitCompletion = (habitId: string) => {
    const newCheckIn: CheckIn = {
      habitId,
      date: selectedDate,
      completed: !isHabitCompletedToday(habitId),
      notes: '',
    };

    const existing = checkIns.findIndex((ci) => ci.habitId === habitId && ci.date === selectedDate);
    let updated: CheckIn[];

    if (existing >= 0) {
      updated = [...checkIns];
      updated[existing] = newCheckIn;
    } else {
      updated = [...checkIns, newCheckIn];
    }

    setCheckIns(updated);

    // Award XP
    if (newCheckIn.completed) {
      const habit = habits.find((h) => h.id === habitId);
      if (habit) {
        const xpReward = habit.difficulty === 'easy' ? 10 : habit.difficulty === 'medium' ? 25 : 50;
        addXP(xpReward);
        updateStreak(habitId, true);
      }
    } else {
      updateStreak(habitId, false);
    }
  };

  const updateStreak = (habitId: string, completed: boolean) => {
    setProgress((prev) => {
      const p = prev[habitId];
      let newStreak = completed ? (p.currentStreak || 0) + 1 : 0;

      const badges = [...userProgress.badges];
      if (newStreak === 7 && !badges.includes('7-day-streak')) badges.push('7-day-streak');
      if (newStreak === 30 && !badges.includes('30-day-streak')) badges.push('30-day-streak');

      setUserProgress((up) => ({ ...up, badges }));

      return {
        ...prev,
        [habitId]: {
          ...p,
          currentStreak: newStreak,
          bestStreak: Math.max(p.bestStreak || 0, newStreak),
        },
      };
    });
  };

  const addXP = (xp: number) => {
    setUserProgress((prev) => {
      const newXP = prev.totalXP + xp;
      const newLevel = Math.floor(newXP / XP_PER_LEVEL) + 1;
      const newTitle = TITLES[Math.min(newLevel - 1, TITLES.length - 1)];

      return {
        ...prev,
        totalXP: newXP,
        level: newLevel,
        title: newTitle,
      };
    });
  };

  const isHabitCompletedToday = (habitId: string): boolean => {
    return checkIns.some((ci) => ci.habitId === habitId && ci.date === selectedDate && ci.completed);
  };

  const getTodayCompletionCount = (): number => {
    return checkIns.filter((ci) => ci.date === selectedDate && ci.completed).length;
  };

  const generateAiSuggestion = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/apps/habit-forge/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'motivation',
          habits: habits.slice(0, 5),
          progress: Object.values(progress),
          userProgress,
        }),
      });

      const data = await response.json();
      setCoachMessage(data.message);
    } catch (error) {
      console.error('Failed to get coaching:', error);
      setCoachMessage('Keep up the great work! You\'re building momentum.');
    } finally {
      setLoading(false);
    }
  };

  const getWeekCompletion = (): number => {
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weekCheckIns = checkIns.filter(
      (ci) => new Date(ci.date) >= weekAgo && ci.completed
    ).length;
    const potentialCheckIns = habits.length * 7;
    return potentialCheckIns > 0 ? Math.round((weekCheckIns / potentialCheckIns) * 100) : 0;
  };

  const renderDashboard = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-5xl font-bold text-orange-500 mb-2">Habit Forge</h1>
              <p className="text-slate-300">Transform your habits, level up your life</p>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-400 uppercase mb-1">Level</div>
              <div className="text-4xl font-bold text-amber-400">{userProgress.level}</div>
              <div className="text-orange-500 font-bold">{userProgress.title}</div>
            </div>
          </div>

          {/* XP Progress */}
          <div className="bg-slate-800 border border-orange-500 rounded p-6">
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm text-slate-400 uppercase">XP Progress</span>
              <span className="text-orange-400 font-bold">{userProgress.totalXP % XP_PER_LEVEL} / {XP_PER_LEVEL}</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-3">
              <div
                className="bg-gradient-to-r from-orange-500 to-amber-400 h-3 rounded-full transition-all duration-500"
                style={{ width: `${((userProgress.totalXP % XP_PER_LEVEL) / XP_PER_LEVEL) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-4 gap-4 mb-12">
          {[
            { id: 'dashboard', icon: Target, label: 'Dashboard' },
            { id: 'today', icon: Calendar, label: 'Today' },
            { id: 'progress', icon: TrendingUp, label: 'Progress' },
            { id: 'coaching', icon: Zap, label: 'Coaching' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setView(tab.id as any)}
              className={`p-4 rounded border-2 transition ${
                view === tab.id
                  ? 'bg-orange-500 border-orange-500 text-slate-900 font-bold'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-orange-500'
              }`}
            >
              <tab.icon className="w-5 h-5 mx-auto mb-2" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-3 gap-8">
          {/* Habits List */}
          <div className="col-span-2">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Active Habits ({habits.filter((h) => h.active).length})</h2>
              <button
                onClick={() => setView('add-habit')}
                className="bg-orange-500 hover:bg-orange-600 text-slate-900 font-bold px-4 py-2 rounded flex items-center gap-2"
              >
                <Plus className="w-5 h-5" /> Add Habit
              </button>
            </div>

            <div className="space-y-4">
              {habits.filter((h) => h.active).map((habit) => {
                const p = progress[habit.id];
                const isCompleted = isHabitCompletedToday(habit.id);

                return (
                  <div key={habit.id} className="bg-slate-800 border border-slate-700 hover:border-orange-500 rounded p-6 transition">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-white mb-1">{habit.name}</h3>
                        <div className="flex gap-2 text-xs mb-3">
                          <span className="bg-slate-700 text-slate-300 px-2 py-1 rounded capitalize">{habit.category}</span>
                          <span className="bg-slate-700 text-slate-300 px-2 py-1 rounded capitalize">{habit.difficulty}</span>
                          <span className="bg-slate-700 text-slate-300 px-2 py-1 rounded capitalize">{habit.frequency}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => toggleHabitCompletion(habit.id)}
                        className={`px-6 py-2 rounded font-bold transition flex items-center gap-2 ${
                          isCompleted
                            ? 'bg-green-600 text-white'
                            : 'bg-slate-700 text-slate-300 hover:bg-orange-500 hover:text-slate-900'
                        }`}
                      >
                        {isCompleted ? (
                          <>
                            <CheckCircle2 className="w-5 h-5" /> Done
                          </>
                        ) : (
                          'Mark Done'
                        )}
                      </button>
                    </div>

                    {/* Streak & Stats */}
                    <div className="grid grid-cols-4 gap-3 text-sm">
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 text-xs uppercase mb-1">Current Streak</div>
                        <div className="text-xl font-bold text-orange-400 flex items-center gap-1">
                          {p?.currentStreak || 0}
                          {(p?.currentStreak || 0) >= 7 && <Flame className="w-5 h-5 text-orange-500" />}
                          {(p?.currentStreak || 0) >= 30 && <Crown className="w-5 h-5 text-yellow-500" />}
                        </div>
                      </div>
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 text-xs uppercase mb-1">Best Streak</div>
                        <div className="text-xl font-bold text-amber-400">{p?.bestStreak || 0}</div>
                      </div>
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 text-xs uppercase mb-1">Completed</div>
                        <div className="text-xl font-bold text-cyan-400">{p?.totalCompleted || 0}</div>
                      </div>
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 text-xs uppercase mb-1">Rate</div>
                        <div className="text-xl font-bold text-green-400">{p?.completionRate || 0}%</div>
                      </div>
                    </div>
                  </div>
                );
              })}

              {habits.length === 0 && (
                <div className="bg-slate-800 border-2 border-dashed border-slate-600 rounded p-12 text-center">
                  <Target className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400 mb-4">No habits yet. Start your journey!</p>
                  <button
                    onClick={() => setView('add-habit')}
                    className="bg-orange-500 hover:bg-orange-600 text-slate-900 font-bold px-6 py-2 rounded"
                  >
                    Create First Habit
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Stats Panel */}
          <div className="space-y-6">
            {/* Today's Completion */}
            <div className="bg-slate-800 border border-orange-500 rounded p-6">
              <h3 className="text-lg font-bold text-orange-400 mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5" /> Today's Progress
              </h3>
              <div className="text-4xl font-bold text-amber-400 mb-2">
                {getTodayCompletionCount()} / {habits.length}
              </div>
              <div className="w-full bg-slate-700 rounded-full h-3 mb-4">
                <div
                  className="bg-gradient-to-r from-orange-500 to-amber-400 h-3 rounded-full"
                  style={{ width: `${habits.length > 0 ? (getTodayCompletionCount() / habits.length) * 100 : 0}%` }}
                />
              </div>
              <div className="text-sm text-slate-400">
                {habits.length > 0 ? `${Math.round((getTodayCompletionCount() / habits.length) * 100)}% complete` : 'Add habits to get started'}
              </div>
            </div>

            {/* Week Overview */}
            <div className="bg-slate-800 border border-slate-700 rounded p-6">
              <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" /> This Week
              </h3>
              <div className="text-3xl font-bold text-cyan-300 mb-2">{getWeekCompletion()}%</div>
              <div className="text-xs text-slate-400">Weekly completion rate</div>
            </div>

            {/* Badges */}
            {userProgress.badges.length > 0 && (
              <div className="bg-slate-800 border border-yellow-600 rounded p-6">
                <h3 className="text-lg font-bold text-yellow-400 mb-4 flex items-center gap-2">
                  <Crown className="w-5 h-5" /> Achievements
                </h3>
                <div className="space-y-2">
                  {userProgress.badges.map((badge) => (
                    <div key={badge} className="bg-yellow-900 text-yellow-200 px-3 py-2 rounded text-xs font-bold">
                      ✓ {badge.replace('-', ' ').toUpperCase()}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const renderAddHabit = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 border border-orange-500 rounded p-8">
          <h2 className="text-3xl font-bold text-orange-400 mb-8">Create New Habit</h2>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              addHabit();
            }}
            className="space-y-6"
          >
            {/* Name */}
            <div>
              <label className="block text-sm font-bold text-orange-400 uppercase mb-2">Habit Name</label>
              <input
                type="text"
                value={newHabit.name}
                onChange={(e) => setNewHabit((prev) => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Morning Run, Read 30 mins"
                className="w-full bg-slate-700 border border-slate-600 text-white p-3 rounded focus:outline-none focus:border-orange-500"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-bold text-orange-400 uppercase mb-3">Category</label>
              <div className="grid grid-cols-3 gap-3">
                {(['health', 'fitness', 'productivity', 'learning', 'mindfulness', 'social', 'financial'] as const).map(
                  (cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setNewHabit((prev) => ({ ...prev, category: cat as any }))}
                      className={`py-2 rounded font-bold uppercase text-sm transition ${
                        newHabit.category === cat
                          ? 'bg-orange-500 text-slate-900'
                          : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                    >
                      {cat.split('')[0].toUpperCase() + cat.slice(1).split('-').join(' ')}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Frequency */}
            <div>
              <label className="block text-sm font-bold text-orange-400 uppercase mb-3">Frequency</label>
              <div className="grid grid-cols-2 gap-3">
                {(['daily', 'weekly', 'MWF', 'weekdays'] as const).map((freq) => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => setNewHabit((prev) => ({ ...prev, frequency: freq as any }))}
                    className={`py-2 rounded font-bold uppercase text-sm transition ${
                      newHabit.frequency === freq
                        ? 'bg-orange-500 text-slate-900'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {freq}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty */}
            <div>
              <label className="block text-sm font-bold text-orange-400 uppercase mb-3">Difficulty</label>
              <div className="grid grid-cols-3 gap-3">
                {(['easy', 'medium', 'hard'] as const).map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => setNewHabit((prev) => ({ ...prev, difficulty: diff }))}
                    className={`py-2 rounded font-bold uppercase text-sm transition ${
                      newHabit.difficulty === diff
                        ? 'bg-orange-500 text-slate-900'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Target Time */}
            <div>
              <label className="block text-sm font-bold text-orange-400 uppercase mb-2">Target Time (optional)</label>
              <input
                type="time"
                value={newHabit.targetTime}
                onChange={(e) => setNewHabit((prev) => ({ ...prev, targetTime: e.target.value }))}
                className="w-full bg-slate-700 border border-slate-600 text-white p-3 rounded focus:outline-none focus:border-orange-500"
              />
            </div>

            {/* Submit */}
            <div className="grid grid-cols-2 gap-4 pt-6">
              <button
                type="button"
                onClick={() => setView('dashboard')}
                className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-orange-500 hover:bg-orange-600 text-slate-900 font-bold py-3 rounded"
              >
                Create Habit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  const renderTodayView = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-orange-400 mb-4">Today's Check-In</h2>
          <div className="flex items-center gap-4">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-white p-3 rounded"
            />
            <div className="ml-auto">
              <label className="block text-sm text-slate-400 uppercase mb-2">How was your day?</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => setDayRating(rating)}
                    className={`w-10 h-10 rounded font-bold transition ${
                      dayRating === rating
                        ? 'bg-orange-500 text-slate-900'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {rating}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Today's Habits */}
        <div className="space-y-4">
          {habits.filter((h) => h.active).map((habit) => {
            const isCompleted = isHabitCompletedToday(habit.id);

            return (
              <button
                key={habit.id}
                onClick={() => toggleHabitCompletion(habit.id)}
                className={`w-full p-6 rounded border-2 text-left transition ${
                  isCompleted
                    ? 'bg-green-900 border-green-500'
                    : 'bg-slate-800 border-slate-700 hover:border-orange-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className={`text-lg font-bold mb-2 ${isCompleted ? 'text-green-200 line-through' : 'text-white'}`}>
                      {habit.name}
                    </h3>
                    <div className="flex gap-2">
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded capitalize">{habit.category}</span>
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded capitalize">{habit.difficulty}</span>
                    </div>
                  </div>
                  {isCompleted ? (
                    <div className="text-4xl">✓</div>
                  ) : (
                    <CheckCircle2 className="w-8 h-8 text-slate-600" />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );

  const renderCoachingView = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-orange-400 mb-8">AI Coach</h2>

        <div className="bg-slate-800 border border-orange-500 rounded p-8">
          <div className="mb-8">
            <h3 className="text-xl font-bold text-orange-400 mb-4">🤖 Daily Motivation</h3>
            <div className="bg-slate-700 p-6 rounded italic text-slate-200 mb-6 min-h-32">
              {coachMessage || 'Loading your personalized motivation...'}
            </div>
            <button
              onClick={generateAiSuggestion}
              disabled={loading}
              className="bg-orange-500 hover:bg-orange-600 text-slate-900 font-bold px-6 py-2 rounded disabled:opacity-50"
            >
              {loading ? 'Loading...' : 'Get New Message'}
            </button>
          </div>

          {/* Other coaching features */}
          <div className="grid grid-cols-2 gap-6 pt-8 border-t border-slate-700">
            {[
              { title: '💡 Habit Suggestions', desc: 'AI recommends new habits to complement your goals' },
              { title: '📊 Weekly Review', desc: 'Deep analysis of your week and actionable feedback' },
              { title: '💪 Accountability', desc: 'AI challenges you on missed habits (supportively!)' },
              { title: '🎯 Stack Suggestions', desc: 'Pair habits for maximum effectiveness' },
            ].map((feature) => (
              <div key={feature.title} className="bg-slate-700 p-4 rounded">
                <h4 className="font-bold text-amber-400 mb-2">{feature.title}</h4>
                <p className="text-sm text-slate-300">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderProgressView = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-orange-400 mb-8">Progress Analytics</h2>

        {/* Category Breakdown */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          {(['health', 'fitness', 'productivity', 'learning', 'mindfulness', 'social', 'financial'] as const).map(
            (cat) => {
              const catHabits = habits.filter((h) => h.category === cat);
              const completed = catHabits.filter((h) =>
                checkIns.some((ci) => ci.habitId === h.id && ci.date === selectedDate && ci.completed)
              ).length;
              const percentage = catHabits.length > 0 ? (completed / catHabits.length) * 100 : 0;

              return (
                <div key={cat} className="bg-slate-800 border border-slate-700 rounded p-6">
                  <h3 className="font-bold capitalize mb-3 text-white">{cat}</h3>
                  <div className="text-2xl font-bold mb-3" style={{ color: CATEGORY_COLORS[cat] }}>
                    {completed} / {catHabits.length}
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%`, backgroundColor: CATEGORY_COLORS[cat] }}
                    />
                  </div>
                </div>
              );
            }
          )}
        </div>

        {/* Month Overview Placeholder */}
        <div className="bg-slate-800 border border-slate-700 rounded p-8">
          <h3 className="text-xl font-bold text-cyan-400 mb-6">Month at a Glance</h3>
          <div className="grid grid-cols-7 gap-2">
            {Array.from({ length: 31 }).map((_, i) => {
              const date = new Date(new Date().getFullYear(), new Date().getMonth(), i + 1)
                .toISOString()
                .split('T')[0];
              const dayCompletions = checkIns.filter((ci) => ci.date === date && ci.completed).length;
              const intensity = dayCompletions / Math.max(habits.length, 1);

              return (
                <div
                  key={i}
                  className="aspect-square rounded text-xs font-bold flex items-center justify-center"
                  style={{
                    backgroundColor: `rgba(249, 115, 22, ${intensity * 0.8 + 0.1})`,
                    color: intensity > 0.5 ? '#000' : '#fff',
                  }}
                >
                  {i + 1}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );

  if (view === 'add-habit') return renderAddHabit();
  if (view === 'today') return renderTodayView();
  if (view === 'progress') return renderProgressView();
  if (view === 'coaching') return renderCoachingView();
  return renderDashboard();
};

export default HabitForgeApp;
