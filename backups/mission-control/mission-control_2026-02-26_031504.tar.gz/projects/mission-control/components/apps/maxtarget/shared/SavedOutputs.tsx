'use client';

import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface SavedOutputsProps {
  panel: string;
  onSave?: (title: string, content: string) => Promise<void>;
}

export default function SavedOutputs({ panel, onSave }: SavedOutputsProps) {
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);
  const [success, setSuccess] = useState('');

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch(`/api/apps/maxtarget/ai-outputs?panel=${panel}`);
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, [panel]);

  const saveCurrentOutput = async (title: string, content: string) => {
    // If onSave callback provided, use it (for panels that want custom handling)
    if (onSave) {
      await onSave(title, content);
      return;
    }
    // Default API save
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel, title, content, tags: [panel] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
        setTimeout(() => setSuccess(''), 2000);
      }
    } catch (e) {
      console.error('Failed to save output:', e);
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
        setTimeout(() => setSuccess(''), 2000);
      }
    } catch (e) {
      console.error('Failed to delete output:', e);
    }
  };

  return (
    <div className="border-t border-gray-700 pt-4 mt-6">
      {success && (
        <div className="mb-3 p-2 bg-emerald-600/20 text-emerald-400 rounded text-sm">
          {success}
        </div>
      )}
      <button
        onClick={() => setOutputsExpanded(!outputsExpanded)}
        className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
      >
        <span className="text-lg">📁</span>
        Saved Outputs
        <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
          {savedOutputs.length}
        </span>
        <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
          ▼
        </span>
      </button>

      {outputsExpanded && (
        <div className="mt-3 space-y-3">
          {outputsLoading ? (
            <div className="text-gray-500 text-sm">Loading...</div>
          ) : savedOutputs.length === 0 ? (
            <div className="text-gray-500 text-sm">No saved outputs yet</div>
          ) : (
            savedOutputs.map(output => (
              <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                <div 
                  className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                  onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                >
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-100">{output.title}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {new Date(output.createdAt).toLocaleDateString()}
                    </div>
                    {expandedOutput !== output.id && (
                      <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                        {output.content.substring(0, 150)}...
                      </div>
                    )}
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                    className="text-xs text-red-400 hover:text-red-300 ml-2"
                  >
                    ✕
                  </button>
                </div>
                {expandedOutput === output.id && (
                  <div className="px-3 pb-3">
                    <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                      {output.content}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <button
                        onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); setTimeout(() => setSuccess(''), 2000); }}
                        className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                      >
                        📋 Copy
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
