'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface KeywordData {
  keyword: string;
  difficulty: 'low' | 'medium' | 'high';
  searchIntent: 'informational' | 'commercial' | 'transactional' | 'navigational';
  contentAngle: string;
  monthlySearches?: number;
}

interface SEOAnalysis {
  titleTag: string;
  metaDescription: string;
  h1: string;
  headingStructure: string[];
  keywordDensity: number;
  readabilityScore: number;
  internalLinks: number;
  externalLinks: number;
  imageAltTags: number;
  schemaMarkup: boolean;
  suggestions: string[];
}

interface SavedKeyword {
  keyword: string;
  volume: number;
  difficulty: string;
  savedAt: string;
}

interface ContentBrief {
  id: string;
  topic: string;
  brief: string;
  savedAt: string;
}

export default function SEOPanel() {
  const [seoTab, setSeoTab] = useState<'keywords' | 'analyzer' | 'gap' | 'preview' | 'meta' | 'briefs' | 'audit'>('keywords');
  const [keywords, setKeywords] = useState<KeywordData[]>([]);
  const [analysis, setAnalysis] = useState<SEOAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved state
  const [savedKeywords, setSavedKeywords] = useState<SavedKeyword[]>([]);
  const [contentBriefs, setContentBriefs] = useState<ContentBrief[]>([]);
  
  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=seo');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'seo', title, content, tags: ['seo'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };
  const [auditChecklist, setAuditChecklist] = useState<Record<string, boolean>>({
    'Title tags optimized': false,
    'Meta descriptions unique': false,
    'H1 tags present on all pages': false,
    'Image alt text added': false,
    'Internal linking structure': false,
    'XML sitemap submitted': false,
    'Robots.txt configured': false,
    'Schema markup implemented': false,
    'Mobile-friendly design': false,
    'Page speed optimized': false,
    'SSL certificate active': false,
    'Canonical tags set': false,
    'No broken links (404s)': false,
    'Open Graph tags present': false,
    'Structured data validated': false,
  });

  const generateKeywords = async (topic: string) => {
    if (!topic.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/seo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'keywords', topic }),
      });
      if (res.ok) {
        const data = await res.json();
        setKeywords(data.keywords || []);
        setSuccess('Keywords generated');
      } else {
        setError('Failed to generate keywords');
      }
    } catch (e) {
      setError('Error generating keywords');
    } finally {
      setLoading(false);
    }
  };

  const analyzeContent = async (urlOrHtml: string) => {
    if (!urlOrHtml.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/seo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'analyze', urlOrHtml }),
      });
      if (res.ok) {
        const data = await res.json();
        setAnalysis(data.analysis);
        setSuccess('Analysis complete');
      } else {
        setError('Failed to analyze content');
      }
    } catch (e) {
      setError('Error analyzing content');
    } finally {
      setLoading(false);
    }
  };

  const analyzeGap = async (yourSite: string, competitorSite: string) => {
    if (!yourSite.trim() || !competitorSite.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/seo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'gap', yourSite, competitorSite }),
      });
      if (res.ok) {
        const data = await res.json();
        setKeywords(data.gaps || []);
        setSuccess('Gap analysis complete');
      } else {
        setError('Failed to analyze gap');
      }
    } catch (e) {
      setError('Error analyzing gap');
    } finally {
      setLoading(false);
    }
  };

  const generateMeta = async (topic: string) => {
    if (!topic.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/seo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'meta', topic }),
      });
      if (res.ok) {
        const data = await res.json();
        setAnalysis(data.meta as any);
        setSuccess('Meta tags generated');
      } else {
        setError('Failed to generate meta tags');
      }
    } catch (e) {
      setError('Error generating meta tags');
    } finally {
      setLoading(false);
    }
  };

  const saveKeyword = (kw: KeywordData) => {
    setSavedKeywords(prev => [...prev, {
      keyword: kw.keyword,
      volume: kw.monthlySearches || 0,
      difficulty: kw.difficulty,
      savedAt: new Date().toISOString(),
    }]);
    setSuccess('Keyword saved');
  };

  const renderKeywords = () => (
    <div className="space-y-4 bg-gray-950 text-white">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Research Topic</label>
        <input type="text" placeholder="e.g., AI marketing tools, SaaS onboarding..."
          onKeyPress={(e) => { if (e.key === 'Enter') generateKeywords((e.target as HTMLInputElement).value); }}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={(e) => { const input = (e.currentTarget.previousElementSibling as HTMLInputElement); generateKeywords(input.value); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '🔍 Generate Keywords'}
        </button>
      </div>

      {/* Saved Keywords */}
      {savedKeywords.length > 0 && (
        <div className="bg-gray-800 rounded p-4 border border-emerald-700/50">
          <div className="text-sm font-semibold text-emerald-400 mb-3">📌 Saved Keywords ({savedKeywords.length})</div>
          <div className="space-y-1">
            {savedKeywords.map((sk, i) => (
              <div key={i} className="flex justify-between items-center text-sm py-1">
                <span className="text-gray-100">{sk.keyword}</span>
                <div className="flex gap-2 items-center">
                  <span className="text-xs text-gray-500">{sk.volume > 0 ? `${sk.volume.toLocaleString()} /mo` : ''}</span>
                  <span className={`text-xs px-2 py-0.5 rounded ${
                    sk.difficulty === 'low' ? 'bg-green-500/20 text-green-400' :
                    sk.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                  }`}>{sk.difficulty}</span>
                  <button onClick={() => setSavedKeywords(prev => prev.filter((_, j) => j !== i))}
                    className="text-xs text-red-400 hover:text-red-300">✕</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {keywords.length === 0 && !loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">🔍</div>
          <div className="text-gray-400 mb-2">Enter a topic to discover keywords</div>
          <div className="text-gray-500 text-sm">Get volume estimates, difficulty scores, and content angles</div>
        </div>
      )}

      <div className="space-y-2">
        {keywords.map((kw, i) => (
          <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700 hover:border-red-600/30">
            <div className="flex justify-between items-start mb-2">
              <div className="font-semibold text-gray-100">{kw.keyword}</div>
              <div className="flex gap-2">
                <span className={`text-xs px-2 py-1 rounded ${
                  kw.difficulty === 'low' ? 'bg-green-500/20 text-green-400' :
                  kw.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                }`}>{kw.difficulty} difficulty</span>
                <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-400 rounded">{kw.searchIntent}</span>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-2">{kw.contentAngle}</p>
            {kw.monthlySearches && <div className="text-xs text-gray-500">📊 {kw.monthlySearches.toLocaleString()} monthly searches</div>}
            <div className="flex gap-2 mt-2">
              <button onClick={() => { navigator.clipboard.writeText(kw.keyword); setSuccess('Keyword copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => saveKeyword(kw)}
                className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAnalyzer = () => (
    <div className="space-y-4 bg-gray-950 text-white">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Page URL or HTML</label>
        <textarea placeholder="Paste your page URL or HTML content..." rows={4}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500"
          onKeyDown={(e) => { if (e.ctrlKey && e.key === 'Enter') analyzeContent((e.target as HTMLTextAreaElement).value); }} />
        <button onClick={(e) => { const textarea = (e.currentTarget.previousElementSibling as HTMLTextAreaElement); analyzeContent(textarea.value); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Analyzing...' : '🔎 Analyze Page'}
        </button>
      </div>
      {analysis && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Title Tag', value: analysis.titleTag },
              { label: 'Readability', value: `${analysis.readabilityScore}/100`, color: 'text-green-400 font-semibold' },
              { label: 'Meta Description', value: analysis.metaDescription },
              { label: 'Keyword Density', value: `${analysis.keywordDensity}%` },
              { label: 'Internal Links', value: analysis.internalLinks },
              { label: 'External Links', value: analysis.externalLinks },
              { label: 'Image Alt Tags', value: analysis.imageAltTags },
              { label: 'Schema Markup', value: analysis.schemaMarkup ? '✓ Present' : '✗ Missing', color: analysis.schemaMarkup ? 'text-green-400' : 'text-red-400' },
            ].map((item, i) => (
              <div key={i}><div className="text-xs text-gray-500">{item.label}</div><div className={`text-sm mt-1 ${item.color || 'text-gray-100'}`}>{String(item.value)}</div></div>
            ))}
          </div>
          <div className="pt-3 border-t border-gray-700">
            <div className="font-semibold text-gray-100 mb-2">💡 Suggestions</div>
            <ul className="space-y-1">{(analysis.suggestions || []).map((s, i) => <li key={i} className="text-sm text-gray-300">• {s}</li>)}</ul>
          </div>
        </div>
      )}
    </div>
  );

  const renderGap = () => (
    <div className="space-y-4 bg-gray-950 text-white">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Your Site</label>
          <input type="text" placeholder="yourdomain.com" id="yourSite" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Competitor Site</label>
          <input type="text" placeholder="competitor.com" id="competitorSite" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          const yourSite = (document.getElementById('yourSite') as HTMLInputElement).value;
          const competitorSite = (document.getElementById('competitorSite') as HTMLInputElement).value;
          analyzeGap(yourSite, competitorSite);
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Analyzing...' : '📊 Analyze Gap'}
        </button>
      </div>
      {keywords.length > 0 && (
        <div className="space-y-2">
          <h3 className="font-semibold text-gray-100">Topics You're Missing</h3>
          {keywords.map((kw, i) => (
            <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700">
              <div className="font-semibold text-gray-100 mb-1">{kw.keyword}</div>
              <p className="text-sm text-gray-400">{kw.contentAngle}</p>
              <div className="flex gap-2 mt-2">
                <button onClick={() => { navigator.clipboard.writeText(kw.keyword); setSuccess('Copied'); }} className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
                <button onClick={() => saveKeyword(kw)} className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderPreview = () => {
    const [title, setTitle] = useState('');
    const [url, setUrl] = useState('');
    const [desc, setDesc] = useState('');
    return (
      <div className="space-y-4 bg-gray-950 text-white">
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <label className="block text-sm font-medium text-gray-300 mb-2">Page Title</label>
          <input type="text" placeholder="Your page title..." value={title} onChange={e => setTitle(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 mb-3" />
          <div className="text-xs text-gray-500 mb-3">{title.length}/60 characters {title.length > 60 && <span className="text-red-400">(too long)</span>}</div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Page URL</label>
          <input type="text" placeholder="yourdomain.com/page..." value={url} onChange={e => setUrl(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 mb-3" />
          <label className="block text-sm font-medium text-gray-300 mb-2">Meta Description</label>
          <textarea placeholder="Your meta description (160 characters)..." value={desc} onChange={e => setDesc(e.target.value)} rows={3}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          <div className="text-xs text-gray-500 mt-1">{desc.length}/160 characters {desc.length > 160 && <span className="text-red-400">(too long)</span>}</div>
        </div>
        <div className="bg-white rounded p-4">
          <div className="text-blue-600 text-lg font-medium mb-1 hover:underline cursor-pointer">{title || 'Your Page Title'}</div>
          <div className="text-green-700 text-sm mb-1">{url || 'yourdomain.com'}</div>
          <div className="text-gray-600 text-sm">{desc || 'Your meta description preview appears here...'}</div>
        </div>
      </div>
    );
  };

  const renderMeta = () => (
    <div className="space-y-4 bg-gray-950 text-white">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <label className="block text-sm font-medium text-gray-300 mb-2">Page Topic</label>
        <input type="text" placeholder="e.g., Best project management tools for teams..." id="metaTopic"
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        <button onClick={() => { const topic = (document.getElementById('metaTopic') as HTMLInputElement).value; generateMeta(topic); }}
          disabled={loading} className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '✨ Generate Meta Tags'}
        </button>
      </div>
      {analysis && (
        <div className="space-y-3">
          {[
            { label: 'Meta Title Tag', value: analysis.titleTag },
            { label: 'Meta Description', value: analysis.metaDescription },
          ].map((item, i) => (
            <div key={i} className="bg-gray-800 rounded p-4 border border-gray-700">
              <div className="text-xs text-gray-500 mb-2">{item.label}</div>
              <div className="text-sm text-gray-100 font-mono bg-gray-700 p-2 rounded mb-2">{item.value}</div>
              <button onClick={() => { navigator.clipboard.writeText(item.value); setSuccess('Copied!'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            </div>
          ))}
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-xs text-gray-500 mb-2">OG Tags</div>
            <div className="text-xs text-gray-100 font-mono bg-gray-700 p-2 rounded space-y-1 mb-2">
              <div>&lt;meta property="og:title" content="{analysis.titleTag}" /&gt;</div>
              <div>&lt;meta property="og:description" content="{analysis.metaDescription}" /&gt;</div>
            </div>
            <button onClick={() => { navigator.clipboard.writeText(`<meta property="og:title" content="${analysis.titleTag}" />\n<meta property="og:description" content="${analysis.metaDescription}" />`); setSuccess('Copied!'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy All</button>
          </div>
        </div>
      )}
    </div>
  );

  const renderBriefs = () => {
    const [briefTopic, setBriefTopic] = useState('');
    const [generatedBrief, setGeneratedBrief] = useState('');
    const [briefLoading, setBriefLoading] = useState(false);

    const generateBrief = async () => {
      if (!briefTopic.trim()) return;
      setBriefLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/seo', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'meta', topic: `Content brief for: ${briefTopic}` }),
        });
        if (res.ok) {
          const data = await res.json();
          const brief = data.meta?.metaDescription || `Content brief for "${briefTopic}":\n\n• Target keyword: ${briefTopic}\n• Word count: 1,500-2,000\n• Format: Long-form guide\n• Key sections: Introduction, Problem, Solution, Examples, Conclusion\n• CTA: Demo request`;
          setGeneratedBrief(brief);
          setSuccess('Brief generated');
        }
      } catch { setError('Failed to generate brief'); }
      finally { setBriefLoading(false); }
    };

    return (
      <div className="space-y-4 bg-gray-950 text-white">
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <label className="block text-sm font-medium text-gray-300 mb-2">Content Topic</label>
          <input type="text" value={briefTopic} onChange={e => setBriefTopic(e.target.value)} placeholder="e.g., How to choose a CRM for startups"
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          <button onClick={generateBrief} disabled={briefLoading}
            className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
            {briefLoading ? '⏳ Generating...' : '📝 Generate Content Brief'}
          </button>
        </div>

        {generatedBrief && (
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-sm text-gray-100 whitespace-pre-wrap mb-3">{generatedBrief}</div>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(generatedBrief); setSuccess('Brief copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => {
                setContentBriefs(prev => [...prev, { id: Date.now().toString(), topic: briefTopic, brief: generatedBrief, savedAt: new Date().toISOString() }]);
                setSuccess('Brief saved');
              }} className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
            </div>
          </div>
        )}

        {contentBriefs.length > 0 && (
          <div>
            <div className="text-sm font-semibold text-gray-300 mb-2">📚 Saved Briefs ({contentBriefs.length})</div>
            <div className="space-y-2">
              {contentBriefs.map(b => (
                <div key={b.id} className="bg-gray-800 rounded p-3 border border-gray-700">
                  <div className="flex justify-between items-start">
                    <div className="font-semibold text-gray-100 text-sm">{b.topic}</div>
                    <button onClick={() => setContentBriefs(prev => prev.filter(x => x.id !== b.id))} className="text-xs text-red-400 hover:text-red-300">✕</button>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">{new Date(b.savedAt).toLocaleDateString()}</div>
                  <div className="text-xs text-gray-400 mt-2 line-clamp-2">{b.brief}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {contentBriefs.length === 0 && !generatedBrief && (
          <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
            <div className="text-4xl mb-3">📝</div>
            <div className="text-gray-400 mb-2">No content briefs yet</div>
            <div className="text-gray-500 text-sm">Generate and save briefs to build your content pipeline</div>
          </div>
        )}
      </div>
    );
  };

  const renderAudit = () => (
    <div className="space-y-4 bg-gray-950 text-white">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="text-sm font-semibold text-gray-100 mb-3">✅ Site Audit Checklist</div>
        <div className="text-xs text-gray-500 mb-3">
          {Object.values(auditChecklist).filter(Boolean).length} / {Object.keys(auditChecklist).length} completed
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
          <div className="bg-emerald-500 h-2 rounded-full transition-all" style={{ width: `${(Object.values(auditChecklist).filter(Boolean).length / Object.keys(auditChecklist).length) * 100}%` }} />
        </div>
        <div className="space-y-2">
          {Object.entries(auditChecklist).map(([item, checked]) => (
            <label key={item} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer hover:text-gray-100">
              <input type="checkbox" checked={checked} onChange={() => setAuditChecklist(prev => ({ ...prev, [item]: !prev[item] }))}
                className="rounded border-gray-600" />
              <span className={checked ? 'line-through text-gray-500' : ''}>{item}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4 bg-gray-950 text-white">
      {error && <div className="p-3 bg-red-600/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}

      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'keywords', label: '🔍 Keywords' },
          { id: 'briefs', label: '📝 Briefs' },
          { id: 'audit', label: '✅ Site Audit' },
          { id: 'analyzer', label: '📊 Analyzer' },
          { id: 'gap', label: '📈 Gap' },
          { id: 'preview', label: '👁️ SERP' },
          { id: 'meta', label: '🏷️ Meta Tags' },
        ].map(t => (
          <button key={t.id} onClick={() => setSeoTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              seoTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>

      {seoTab === 'keywords' && renderKeywords()}
      {seoTab === 'briefs' && renderBriefs()}
      {seoTab === 'audit' && renderAudit()}
      {seoTab === 'analyzer' && renderAnalyzer()}
      {seoTab === 'gap' && renderGap()}
      {seoTab === 'preview' && renderPreview()}
      {seoTab === 'meta' && renderMeta()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
