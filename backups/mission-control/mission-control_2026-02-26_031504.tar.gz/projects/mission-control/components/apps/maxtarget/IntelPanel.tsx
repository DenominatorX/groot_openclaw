'use client';

import { useState } from 'react';
import { SavedOutputs } from './shared';

const EXEC_SUMMARY = `## The Situation

SpecTarget is a 20+ year B2B digital marketing firm specializing in IP targeting, geo-fencing, and programmatic advertising. The competitive landscape has shifted dramatically with AI-native platforms and ABM technology vendors converging on the same market.

## Top Threats

### 🔴 HIGH THREAT
**El Toro, Simpli.fi, StackAdapt, Metadata.io, WebFX** — Direct overlap with SpecTarget's core services; stronger tech, larger teams, AI-powered.

### 🟡 MEDIUM THREAT
**Demandbase, 6sense, Terminus, RollWorks, Directive, NP Digital, Wpromote, Madison Logic** — Adjacent competitors moving into SpecTarget's space; enterprise-grade ABM platforms.

### 🟢 LOW THREAT
**Albert.ai, Pixis, Smartly, Jasper, Influ2, AccountInsight, Transmission** — Different segment or niche; less direct competition.

## 5 Critical Gaps Andy Must Close

1. **No Intent Data** — Every serious B2B competitor uses intent data to identify in-market accounts. This is now table stakes.
2. **No AI Campaign Optimization** — Competitors use autonomous AI for bidding, creative testing, and budget allocation. Manual management can't compete.
3. **No Client Dashboard** — Clients expect real-time, self-serve reporting. PDF reports on a schedule are outdated.
4. **No CTV/OTT Offering** — The fastest-growing programmatic channel. Easy to add via StackAdapt (no minimums).
5. **No Branded Methodology** — Top agencies have named frameworks. SpecTarget needs a "Precision Targeting Engine™" or similar.

## The AI Opportunity (Dollar Impact)

- **Time savings (AI automation):** 25-40 hrs/week freed up = capacity for 3-5 more clients
- **Cost reduction (AI vs hiring):** Save $200-400K/year vs hiring 5 people
- **New revenue streams (CTV, ABM, AI creative):** $50-150K additional annual revenue
- **Margin improvement:** 20-30% through AI-augmented delivery
- **Client retention improvement:** 20-30% churn reduction through better reporting

## 3-Phase Roadmap

### Phase 1: Quick Wins (Month 1-2) — $2-3K/mo
AI content generation, automated reporting dashboards, CTV/OTT via StackAdapt, LinkedIn thought leadership, 3 case studies, branded methodology.

### Phase 2: Build Out (Month 3-6) — $5-8K/mo
Intent data integration (Bombora), AI-Powered ABM (RollWorks), AI campaign optimization (Metadata.io), client dashboard portal, website redesign, webinar series.

### Phase 3: Untouchable (Month 6-12) — $8-15K/mo
"SpecTarget Intelligence Platform" (proprietary), AI agents for autonomous campaigns, vertical playbooks, predictive pipeline scoring, revenue-based pricing, strategic partnerships.

## The Bottom Line

Andy's 20 years of targeting expertise is a genuine competitive advantage — but it's currently under-leveraged. By layering AI tools, intent data, and modern client experiences on top of that expertise, SpecTarget can:

- **Operate like a team of 7** while remaining a lean operation
- **Charge 2-3x current rates** with premium AI-augmented services
- **Win against larger agencies** by combining boutique attention with enterprise-level technology
- **Build recurring revenue** through platform-style service offerings

**The blue ocean opportunity:** No competitor owns the "boutique agency with enterprise-level AI" position. That's SpecTarget's to claim.`;

const FULL_REPORT_SECTIONS = [
  {
    title: "Executive Summary",
    content: "SpecTarget operates in a rapidly evolving B2B digital marketing landscape where AI-native platforms, ABM technology vendors, and full-service agencies are converging. Andy's 20+ years of experience and hyper-specific targeting expertise is a genuine asset — but the market is moving fast. Competitors are embedding AI into every layer of their operations, from autonomous campaign optimization to AI-generated creative at scale.\n\nThe bottom line: SpecTarget's core offering (IP targeting, geo-fencing, programmatic) remains valuable, but without AI augmentation, better client dashboards, and scalable automation, the firm risks being outpaced by both platform players (Demandbase, 6sense) and AI-augmented agencies (WebFX, Directive, NP Digital)."
  },
  {
    title: "Category 1: Programmatic / IP Targeting Specialists",
    content: "These are SpecTarget's closest direct competitors — companies offering similar services with bigger teams and more technology.",
    competitors: [
      { name: "El Toro", detail: "167 employees, $37.7M revenue. 22 patents on IP-to-location matching. Venue replay, CTV/OTT, foot traffic analytics. Deloitte Fast 500." },
      { name: "Simpli.fi", detail: "400+ employees. GPS-based addressable geo-fencing (not just IP). 1M+ addresses per campaign. 90% match rate. Self-serve + managed." },
      { name: "Basis Technologies", detail: "201-1,000 employees. Full DSP platform. Unified workflow from planning to billing. AI-powered bid optimization." },
      { name: "StackAdapt", detail: "700+ employees. AI-powered DSP. No minimum spend. Proprietary B2B ID graph. Native/display/video/CTV/audio/in-game." },
      { name: "AccountInsight", detail: "20-50 employees. B2B DSP with pay-as-you-go pricing. Live intent signals. Focused exclusively on B2B." },
    ]
  },
  {
    title: "Category 2: ABM Platforms",
    content: "Enterprise ABM platforms combining technology, advertising, and intent data. These represent the 'platform' approach to what SpecTarget does as a service.",
    competitors: [
      { name: "Demandbase", detail: "800+ employees. Native B2B DSP with AI-optimized bidder. $50K-$200K+/year. Deep Salesforce/HubSpot integrations." },
      { name: "6sense", detail: "1,000+ employees. Best-in-class intent data. Predictive buying stage identification. 'Dark funnel' visibility. $60K-$250K+/year." },
      { name: "Terminus", detail: "300+ employees. Multi-channel ABM (display, LinkedIn, email, CTV). Account engagement scoring. $30K-$100K+/year." },
      { name: "RollWorks", detail: "Part of NextRoll (~400 employees). AI-powered ABM. 5x ROI claim. Strong HubSpot integration. More accessible pricing." },
      { name: "Madison Logic", detail: "200+ employees, $50-100M revenue. 45M accounts / 417M contacts intent data. Content syndication + programmatic." },
      { name: "Influ2", detail: "50-100 employees. Person-based advertising (contact-level, not just account). Individual engagement tracking." },
    ]
  },
  {
    title: "Category 3: AI-Native Marketing Platforms",
    content: "These platforms use AI as their core differentiator — autonomous campaign management, AI-generated creative, and predictive optimization.",
    competitors: [
      { name: "Albert.ai", detail: "50-100 employees. 200+ autonomous AI skills. Self-learning optimization. Cross-channel budget rebalancing. 30%+ ROAS improvement." },
      { name: "Metadata.io", detail: "100-200 employees. AI agents for end-to-end paid campaign execution. Optimizes to pipeline/revenue, not vanity metrics. $43K+/year." },
      { name: "Pixis", detail: "447-526 employees, ~$57.9M revenue. Codeless AI infrastructure. AI-generated creative at scale. $100M+ in funding." },
      { name: "Smartly.io", detail: "676+ employees, ~$150M revenue. Creative + media unified. Billions in ad spend managed. Dynamic ad personalization." },
      { name: "Jasper", detail: "300+ employees. AI marketing content platform. AI agents for marketing workflows. Brand voice management. From $49/mo." },
    ]
  },
  {
    title: "Category 4: Full-Service Digital Agencies",
    content: "These agencies compete for the same clients but offer broader services. They represent what SpecTarget could become with AI augmentation.",
    competitors: [
      { name: "WebFX", detail: "500+ employees, $500M-$1B revenue. Proprietary RevenueCloudFX platform. $10B+ client revenue generated. 24M+ leads." },
      { name: "Directive Consulting", detail: "192 employees, ~$20M revenue. B2B SaaS specialist. 'Customer Generation' methodology. $1B+ client revenue." },
      { name: "NP Digital", detail: "1,000+ employees, $100M+ revenue. Neil Patel brand. Proprietary tools (Ubersuggest, AnswerThePublic). AI-first." },
      { name: "Wpromote", detail: "500+ employees. Proprietary Polaris intelligence platform. Outcome-first agile approach. B2B + B2C." },
      { name: "Transmission", detail: "B2B specialist agency. Global presence. Enterprise-focused technology marketing." },
    ]
  },
  {
    title: "5 Critical Gaps",
    content: "1. **No Intent Data** — Every serious B2B competitor uses Bombora, TechTarget, or proprietary intent data. SpecTarget flies blind.\n\n2. **No AI Campaign Optimization** — El Toro, StackAdapt, Albert.ai, and Metadata.io all use AI for autonomous bidding and creative testing. Manual management can't keep up.\n\n3. **No Client Dashboard** — WebFX has RevenueCloudFX. Wpromote has Polaris. SpecTarget sends PDF reports. Clients expect real-time, self-serve access.\n\n4. **No CTV/OTT Offering** — Connected TV is the fastest-growing programmatic channel. El Toro, Simpli.fi, StackAdapt, and Terminus all offer it. StackAdapt has no minimums.\n\n5. **No Branded Methodology** — Directive has 'Customer Generation.' WebFX has 'RevenueCloudFX.' SpecTarget needs a named, differentiated framework."
  },
  {
    title: "The Blue Ocean",
    content: "No competitor currently owns the position of 'boutique agency with enterprise-level AI.' The large agencies (WebFX, NP Digital) lack personal touch. The platforms (Demandbase, 6sense) lack strategy and execution. The AI tools (Albert.ai, Metadata.io) lack the human expertise.\n\nSpecTarget can combine 20 years of targeting expertise + AI augmentation + boutique attention to create a category of one. This is the play."
  }
];

export default function IntelPanel() {
  const [view, setView] = useState<'exec' | 'full'>('exec');

  const renderMarkdown = (text: string) => {
    // Simple markdown renderer
    return text.split('\n\n').map((block, i) => {
      if (block.startsWith('### ')) {
        return <h4 key={i} className="text-lg font-semibold text-white mt-4 mb-2">{block.replace('### ', '')}</h4>;
      }
      if (block.startsWith('## ')) {
        return <h3 key={i} className="text-xl font-bold text-white mt-6 mb-3 pb-2 border-b border-gray-700">{block.replace('## ', '')}</h3>;
      }

      // Handle lists
      const lines = block.split('\n');
      if (lines.every(l => l.match(/^[-*\d.]/))) {
        return (
          <ul key={i} className="space-y-2 my-3">
            {lines.map((line, j) => {
              const cleaned = line.replace(/^[-*]\s*/, '').replace(/^\d+\.\s*/, '');
              return (
                <li key={j} className="text-gray-300 flex gap-2">
                  <span className="text-[#DC143C] mt-1 shrink-0">•</span>
                  <span dangerouslySetInnerHTML={{ __html: cleaned.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>') }} />
                </li>
              );
            })}
          </ul>
        );
      }

      // Regular paragraph
      return (
        <p key={i} className="text-gray-300 my-2 leading-relaxed" dangerouslySetInnerHTML={{
          __html: block.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>')
        }} />
      );
    });
  };

  const renderExecSummary = () => (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-[#DC143C]/20 to-transparent border border-[#DC143C]/30 rounded-lg p-6">
        <h2 className="text-2xl font-bold text-white mb-1">SpecTarget Competitive Intelligence</h2>
        <p className="text-gray-400 text-sm">Executive Summary — Prepared for Andy | February 16, 2026</p>
        <p className="text-gray-500 text-xs mt-1">by Maverick Steele, CMO & AI Marketing Specialist</p>
      </div>
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        {renderMarkdown(EXEC_SUMMARY)}
      </div>
    </div>
  );

  const renderFullReport = () => (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-[#DC143C]/20 to-transparent border border-[#DC143C]/30 rounded-lg p-6">
        <h2 className="text-2xl font-bold text-white mb-1">Full Competitive Intelligence Report</h2>
        <p className="text-gray-400 text-sm">21 Competitors Analyzed • 4 Categories • Gap Analysis • Roadmap</p>
        <p className="text-gray-500 text-xs mt-1">by Maverick Steele, CMO & AI Marketing Specialist</p>
      </div>

      {FULL_REPORT_SECTIONS.map((section, i) => (
        <div key={i} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-xl font-bold text-white mb-3 pb-2 border-b border-gray-700">{section.title}</h3>
          <p className="text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{
            __html: section.content.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>').replace(/\n\n/g, '<br/><br/>')
          }} />

          {section.competitors && (
            <div className="mt-4 space-y-3">
              {section.competitors.map((comp, j) => (
                <div key={j} className="bg-gray-900 rounded p-4 border-l-2 border-[#DC143C]">
                  <div className="font-semibold text-white">{comp.name}</div>
                  <div className="text-sm text-gray-400 mt-1">{comp.detail}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex gap-3">
        <button
          onClick={() => setView('exec')}
          className={`px-4 py-2 rounded font-medium transition-colors ${
            view === 'exec'
              ? 'bg-[#DC143C]/20 text-[#DC143C] border border-[#DC143C]/50'
              : 'bg-gray-800 text-gray-400 hover:text-gray-300 border border-gray-700'
          }`}
        >
          📋 Executive Summary
        </button>
        <button
          onClick={() => setView('full')}
          className={`px-4 py-2 rounded font-medium transition-colors ${
            view === 'full'
              ? 'bg-[#DC143C]/20 text-[#DC143C] border border-[#DC143C]/50'
              : 'bg-gray-800 text-gray-400 hover:text-gray-300 border border-gray-700'
          }`}
        >
          📊 Full Report (21 Competitors)
        </button>
      </div>

      {view === 'exec' ? renderExecSummary() : renderFullReport()}
    <SavedOutputs panel="intel" />
    </div>
  );
}
