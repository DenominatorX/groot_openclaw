'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface ABTestEntry {
  id: string;
  testName: string;
  variantA: string;
  variantB: string;
  winner: 'A' | 'B' | 'pending';
  liftPercent?: number;
  status: 'running' | 'completed';
}

const LANDING_CHECKLIST = [
  { category: 'Hero Section', items: ['Clear headline (< 10 words)', 'Subheadline with value prop', 'Hero image/video', 'Primary CTA above fold'] },
  { category: 'Social Proof', items: ['Customer logos', 'Testimonials', 'Case study metrics', 'Trust badges / certifications'] },
  { category: 'Content', items: ['Benefits (not just features)', 'Problem → Solution flow', 'Visual hierarchy', 'Scannable bullet points'] },
  { category: 'CTA & Form', items: ['Single clear CTA', 'Minimal form fields', 'Submit button with action verb', 'No distracting links'] },
  { category: 'Technical', items: ['Mobile responsive', 'Page speed < 3s', 'Form validation', 'Thank you page / confirmation'] },
];

const SEED_TESTS: ABTestEntry[] = [
  { id: '1', testName: 'Homepage Hero CTA', variantA: 'Start Free Trial', variantB: 'Get Started Now', winner: 'B', liftPercent: 23, status: 'completed' },
  { id: '2', testName: 'Pricing Page Layout', variantA: '3-column cards', variantB: '2-column with toggle', winner: 'A', liftPercent: 12, status: 'completed' },
  { id: '3', testName: 'Demo Form Length', variantA: '5 fields', variantB: '3 fields', winner: 'B', liftPercent: 34, status: 'completed' },
];

export default function ConversionPanel() {
  const [conversionTab, setConversionTab] = useState<'checklist' | 'abtests' | 'audit' | 'cta'>('checklist');
  const [content, setContent] = useState('');
  const [ctas, setCtas] = useState<string[]>([]);
  const [abTests, setAbTests] = useState<ABTestEntry[]>(SEED_TESTS);
  const [checklist, setChecklist] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=conversion');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'conversion', title, content, tags: ['conversion'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateContent = async (action: string, params: Record<string, string>) => {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/conversion', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...params }),
      });
      if (res.ok) {
        const data = await res.json();
        if (action === 'cta') { setCtas(data.ctas || []); }
        else { setContent(data.content || JSON.stringify(data, null, 2)); }
        setSuccess('Content generated');
      } else { setError('Failed to generate content'); }
    } catch { setError('Error generating content'); }
    finally { setLoading(false); }
  };

  const totalItems = LANDING_CHECKLIST.reduce((sum, cat) => sum + cat.items.length, 0);
  const checkedItems = Object.values(checklist).filter(Boolean).length;

  const renderChecklist = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="flex justify-between items-center mb-3">
          <div className="text-sm font-semibold text-gray-100">🚀 Landing Page Checklist</div>
          <div className="text-xs text-gray-500">{checkedItems}/{totalItems} complete</div>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
          <div className="bg-emerald-500 h-2 rounded-full transition-all" style={{ width: `${totalItems > 0 ? (checkedItems / totalItems) * 100 : 0}%` }} />
        </div>

        <div className="space-y-4">
          {LANDING_CHECKLIST.map(cat => (
            <div key={cat.category}>
              <div className="text-xs font-semibold text-[#DC143C] uppercase tracking-wide mb-2">{cat.category}</div>
              <div className="space-y-1.5">
                {cat.items.map(item => {
                  const key = `${cat.category}:${item}`;
                  return (
                    <label key={key} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer hover:text-gray-100">
                      <input type="checkbox" checked={!!checklist[key]}
                        onChange={() => setChecklist(prev => ({ ...prev, [key]: !prev[key] }))}
                        className="rounded border-gray-600" />
                      <span className={checklist[key] ? 'line-through text-gray-500' : ''}>{item}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderABTests = () => {
    const [newTest, setNewTest] = useState({ name: '', varA: '', varB: '' });
    const [showAdd, setShowAdd] = useState(false);

    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="text-sm font-semibold text-gray-100">🧪 A/B Test Tracker</div>
          <button onClick={() => setShowAdd(!showAdd)}
            className="text-xs px-3 py-1.5 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">
            + New Test
          </button>
        </div>

        {showAdd && (
          <div className="bg-gray-800 rounded p-4 border border-[#DC143C]/50 space-y-3">
            <input type="text" value={newTest.name} onChange={e => setNewTest({ ...newTest, name: e.target.value })}
              placeholder="Test name..." className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 text-sm" />
            <div className="grid grid-cols-2 gap-3">
              <input type="text" value={newTest.varA} onChange={e => setNewTest({ ...newTest, varA: e.target.value })}
                placeholder="Variant A..." className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 text-sm" />
              <input type="text" value={newTest.varB} onChange={e => setNewTest({ ...newTest, varB: e.target.value })}
                placeholder="Variant B..." className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500 text-sm" />
            </div>
            <div className="flex gap-2">
              <button onClick={() => {
                if (!newTest.name.trim()) return;
                setAbTests(prev => [...prev, {
                  id: Date.now().toString(), testName: newTest.name, variantA: newTest.varA, variantB: newTest.varB,
                  winner: 'pending', status: 'running',
                }]);
                setNewTest({ name: '', varA: '', varB: '' });
                setShowAdd(false);
                setSuccess('A/B test created');
              }} className="px-3 py-1.5 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded text-sm">Create</button>
              <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-gray-700 text-gray-300 rounded text-sm">Cancel</button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {abTests.map(test => (
            <div key={test.id} className="bg-gray-800 rounded p-4 border border-gray-700">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="text-sm font-semibold text-gray-100">{test.testName}</div>
                  <div className={`text-xs mt-1 ${test.status === 'running' ? 'text-yellow-400' : 'text-emerald-400'}`}>
                    {test.status === 'running' ? '🟡 Running' : '✅ Completed'}
                  </div>
                </div>
                {test.liftPercent && (
                  <div className="text-right">
                    <div className="text-lg font-bold text-emerald-400">+{test.liftPercent}%</div>
                    <div className="text-xs text-gray-500">lift</div>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className={`p-2 rounded text-sm ${test.winner === 'A' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-gray-700 text-gray-300'}`}>
                  <span className="text-xs text-gray-500">A: </span>{test.variantA}
                  {test.winner === 'A' && <span className="text-xs ml-1">🏆</span>}
                </div>
                <div className={`p-2 rounded text-sm ${test.winner === 'B' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-gray-700 text-gray-300'}`}>
                  <span className="text-xs text-gray-500">B: </span>{test.variantB}
                  {test.winner === 'B' && <span className="text-xs ml-1">🏆</span>}
                </div>
              </div>
              {test.status === 'running' && (
                <div className="flex gap-2 mt-3">
                  <button onClick={() => setAbTests(prev => prev.map(t => t.id === test.id ? { ...t, winner: 'A', liftPercent: Math.floor(Math.random() * 40) + 5, status: 'completed' as const } : t))}
                    className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">A Wins</button>
                  <button onClick={() => setAbTests(prev => prev.map(t => t.id === test.id ? { ...t, winner: 'B', liftPercent: Math.floor(Math.random() * 40) + 5, status: 'completed' as const } : t))}
                    className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">B Wins</button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderAudit = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Page URL or Description</label>
          <textarea placeholder="Paste your page URL or describe your page..." id="auditPage" rows={3}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => { generateContent('audit', { page: (document.getElementById('auditPage') as HTMLTextAreaElement).value }); }}
          disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Auditing...' : '🔍 CRO Audit'}
        </button>
      </div>
      {loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-2xl mb-2 animate-pulse">🔍</div>
          <div className="text-gray-400 text-sm">Running CRO audit...</div>
        </div>
      )}
      {content && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="bg-gray-700 p-3 rounded text-xs text-gray-100 whitespace-pre-wrap max-h-96 overflow-y-auto mb-3">{content}</div>
          <button onClick={() => { navigator.clipboard.writeText(content); setSuccess('Audit copied'); }}
            className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
        </div>
      )}
    </div>
  );

  const renderCTA = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Goal</label>
          <input type="text" placeholder="e.g., Sign up, Download guide, Book demo..." id="ctaGoal"
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Audience</label>
          <input type="text" placeholder="e.g., Busy executives, budget-conscious SMBs..." id="ctaAudience"
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateContent('cta', { goal: (document.getElementById('ctaGoal') as HTMLInputElement).value, audience: (document.getElementById('ctaAudience') as HTMLInputElement).value });
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '🎯 Generate CTAs'}
        </button>
      </div>
      {ctas.length === 0 && !loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">🎯</div>
          <div className="text-gray-400 mb-2">Generate high-converting CTAs</div>
          <div className="text-gray-500 text-sm">Enter your goal and audience to get CTA variations</div>
        </div>
      )}
      <div className="space-y-2">
        {ctas.map((cta, i) => (
          <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700 flex justify-between items-center">
            <div>
              <div className="text-sm text-gray-100 font-semibold">Variant {i + 1}</div>
              <div className="text-sm text-gray-300 mt-1">{cta}</div>
            </div>
            <button onClick={() => { navigator.clipboard.writeText(cta); setSuccess('CTA copied'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋</button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'checklist', label: '✅ Checklist' },
          { id: 'abtests', label: '🧪 A/B Tests' },
          { id: 'audit', label: '🔍 CRO Audit' },
          { id: 'cta', label: '🎯 CTAs' },
        ].map(t => (
          <button key={t.id} onClick={() => setConversionTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              conversionTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {conversionTab === 'checklist' && renderChecklist()}
      {conversionTab === 'abtests' && renderABTests()}
      {conversionTab === 'audit' && renderAudit()}
      {conversionTab === 'cta' && renderCTA()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
