'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface ABMAccount {
  id: string;
  company: string;
  tier: 'Tier 1' | 'Tier 2' | 'Tier 3';
  engagementScore: number;
  stage: 'Identified' | 'Engaged' | 'MQA' | 'Opportunity' | 'Customer';
  nextAction: string;
  lastTouched: string;
  timeline: Array<{ date: string; event: string }>;
}

interface Play {
  id: string;
  name: string;
  tier: string;
  steps: string[];
}

const SEED_ACCOUNTS: ABMAccount[] = [
  { id: '1', company: 'Acme Corp', tier: 'Tier 1', engagementScore: 85, stage: 'MQA', nextAction: 'Schedule exec meeting', lastTouched: '2026-02-14',
    timeline: [{ date: '2026-01-10', event: 'Initial outreach via LinkedIn' }, { date: '2026-01-25', event: 'Opened case study email' }, { date: '2026-02-05', event: 'Attended webinar' }, { date: '2026-02-14', event: 'Requested demo' }] },
  { id: '2', company: 'TechNova Solutions', tier: 'Tier 1', engagementScore: 72, stage: 'Engaged', nextAction: 'Send personalized case study', lastTouched: '2026-02-12',
    timeline: [{ date: '2026-01-20', event: 'Website visit from target IP' }, { date: '2026-02-01', event: 'Downloaded whitepaper' }, { date: '2026-02-12', event: 'Clicked email CTA' }] },
  { id: '3', company: 'GlobalScale Inc', tier: 'Tier 2', engagementScore: 58, stage: 'Engaged', nextAction: 'Invite to exclusive event', lastTouched: '2026-02-10',
    timeline: [{ date: '2026-02-01', event: 'Cold outreach sent' }, { date: '2026-02-10', event: 'Reply received — interested' }] },
  { id: '4', company: 'Meridian Health', tier: 'Tier 2', engagementScore: 35, stage: 'Identified', nextAction: 'Research key contacts', lastTouched: '2026-02-08',
    timeline: [{ date: '2026-02-08', event: 'Added to target list' }] },
  { id: '5', company: 'Apex Financial', tier: 'Tier 3', engagementScore: 20, stage: 'Identified', nextAction: 'Initial outreach', lastTouched: '2026-02-06',
    timeline: [{ date: '2026-02-06', event: 'Identified as potential fit' }] },
];

const SEED_PLAYS: Play[] = [
  { id: '1', name: 'Tier 1 — Executive Air Cover', tier: 'Tier 1', steps: ['C-level LinkedIn connection request', 'Personalized video message', 'Custom research brief', 'Executive dinner invite', 'Direct mail package', 'Champion development meeting'] },
  { id: '2', name: 'Tier 2 — Multi-Thread Engagement', tier: 'Tier 2', steps: ['Multi-channel outreach (email + LinkedIn)', 'Industry-specific case study', 'Webinar invite', 'Personalized landing page', 'SDR follow-up call'] },
  { id: '3', name: 'Tier 3 — Programmatic ABM', tier: 'Tier 3', steps: ['Display ad targeting (company IP)', 'Automated email nurture', 'Content syndication', 'Retargeting campaign', 'Score-based escalation to Tier 2'] },
];

export default function ABMPanel() {
  const [abmTab, setAbmTab] = useState<'accounts' | 'plays' | 'intelligence' | 'health'>('accounts');
  const [accounts, setAccounts] = useState<ABMAccount[]>(SEED_ACCOUNTS);
  const [plays] = useState<Play[]>(SEED_PLAYS);
  const [selectedAccount, setSelectedAccount] = useState<ABMAccount | null>(null);
  const [intelligence, setIntelligence] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=abm');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'abm', title, content, tags: ['abm'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateIntelligence = async (company: string) => {
    if (!company.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/abm', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'intelligence', company }),
      });
      if (res.ok) { const data = await res.json(); setIntelligence(data.intelligence || ''); setSuccess('Account intelligence generated'); }
      else { setError('Failed to generate intelligence'); }
    } catch { setError('Error generating intelligence'); }
    finally { setLoading(false); }
  };

  const tierColors: Record<string, string> = { 'Tier 1': 'text-[#DC143C]', 'Tier 2': 'text-yellow-400', 'Tier 3': 'text-gray-400' };
  const stageColors: Record<string, string> = { 'Identified': 'bg-gray-700', 'Engaged': 'bg-blue-500/20 text-blue-400', 'MQA': 'bg-yellow-500/20 text-yellow-400', 'Opportunity': 'bg-purple-500/20 text-purple-400', 'Customer': 'bg-emerald-500/20 text-emerald-400' };

  const renderAccounts = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="text-sm font-semibold text-gray-100">🎖️ Target Accounts ({accounts.length})</div>
        <button onClick={() => {
          const newAcct: ABMAccount = {
            id: Date.now().toString(), company: 'New Account', tier: 'Tier 3', engagementScore: 0,
            stage: 'Identified', nextAction: 'Research & qualify', lastTouched: new Date().toISOString().split('T')[0], timeline: [{ date: new Date().toISOString().split('T')[0], event: 'Added to target list' }],
          };
          setAccounts(prev => [...prev, newAcct]);
          setSuccess('Account added');
        }} className="text-xs px-3 py-1.5 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">+ Add Account</button>
      </div>

      {/* Account Table */}
      <div className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
        <div className="grid grid-cols-6 gap-2 p-3 border-b border-gray-700 text-xs font-semibold text-gray-500 uppercase">
          <div className="col-span-2">Company</div>
          <div>Tier</div>
          <div>Score</div>
          <div>Stage</div>
          <div>Action</div>
        </div>
        {accounts.map(acct => (
          <div key={acct.id} onClick={() => setSelectedAccount(acct)}
            className={`grid grid-cols-6 gap-2 p-3 border-b border-gray-700 last:border-0 cursor-pointer hover:bg-gray-700/50 transition-colors ${
              selectedAccount?.id === acct.id ? 'bg-gray-700/50' : ''
            }`}>
            <div className="col-span-2 text-sm text-gray-100 font-medium">{acct.company}</div>
            <div className={`text-sm font-semibold ${tierColors[acct.tier]}`}>{acct.tier}</div>
            <div className="flex items-center gap-2">
              <div className="w-12 bg-gray-700 rounded-full h-1.5">
                <div className={`h-1.5 rounded-full ${acct.engagementScore >= 70 ? 'bg-emerald-500' : acct.engagementScore >= 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                  style={{ width: `${acct.engagementScore}%` }} />
              </div>
              <span className="text-xs text-gray-400">{acct.engagementScore}</span>
            </div>
            <div><span className={`text-xs px-2 py-0.5 rounded ${stageColors[acct.stage] || 'bg-gray-700'}`}>{acct.stage}</span></div>
            <div className="text-xs text-gray-400 truncate">{acct.nextAction}</div>
          </div>
        ))}
      </div>

      {/* Account Detail / Timeline */}
      {selectedAccount && (
        <div className="bg-gray-800 rounded p-4 border border-[#DC143C]/30">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="text-lg font-semibold text-gray-100">{selectedAccount.company}</div>
              <div className="flex gap-2 mt-1">
                <span className={`text-xs font-semibold ${tierColors[selectedAccount.tier]}`}>{selectedAccount.tier}</span>
                <span className={`text-xs px-2 py-0.5 rounded ${stageColors[selectedAccount.stage]}`}>{selectedAccount.stage}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-emerald-400">{selectedAccount.engagementScore}</div>
              <div className="text-xs text-gray-500">Engagement</div>
            </div>
          </div>

          <div className="mb-4">
            <div className="text-xs text-gray-500 mb-1">Next Action</div>
            <div className="text-sm text-gray-100">{selectedAccount.nextAction}</div>
          </div>

          <div>
            <div className="text-xs font-semibold text-gray-400 uppercase mb-2">Engagement Timeline</div>
            <div className="space-y-2 border-l-2 border-gray-700 pl-4">
              {selectedAccount.timeline.map((event, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-[#DC143C] border-2 border-gray-800" />
                  <div className="text-xs text-gray-500">{event.date}</div>
                  <div className="text-sm text-gray-300">{event.event}</div>
                </div>
              ))}
            </div>
          </div>

          <button onClick={() => generateIntelligence(selectedAccount.company)} disabled={loading}
            className="w-full mt-4 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50 text-sm">
            {loading ? '⏳ Researching...' : '🔍 Get Deep Intelligence'}
          </button>

          {intelligence && (
            <div className="mt-3 bg-gray-900 rounded p-3 text-xs text-gray-100 whitespace-pre-wrap max-h-48 overflow-y-auto">
              {intelligence}
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderPlays = () => (
    <div className="space-y-4">
      <div className="text-sm font-semibold text-gray-100">📋 ABM Plays Library</div>
      {plays.map(play => (
        <div key={play.id} className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="flex justify-between items-start mb-2">
            <div className="text-sm font-semibold text-gray-100">{play.name}</div>
            <span className={`text-xs font-semibold ${tierColors[play.tier]}`}>{play.tier}</span>
          </div>
          <div className="space-y-1.5 border-l-2 border-gray-600 pl-3 mt-3">
            {play.steps.map((step, i) => (
              <div key={i} className="text-xs text-gray-300 relative">
                <span className="absolute -left-[11px] top-1 w-1.5 h-1.5 rounded-full bg-gray-500" />
                <span className="text-gray-500 mr-1">Step {i + 1}:</span> {step}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  const renderIntelligence = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Company</label>
          <input type="text" placeholder="Company name..." id="targetCompany" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => { generateIntelligence((document.getElementById('targetCompany') as HTMLInputElement).value); }}
          disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Researching...' : '🔍 Get Intelligence'}
        </button>
      </div>
      {loading && (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-2xl mb-2 animate-pulse">🔍</div>
          <div className="text-gray-400 text-sm">Researching account...</div>
        </div>
      )}
      {intelligence && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="bg-gray-700 p-3 rounded text-xs text-gray-100 whitespace-pre-wrap max-h-96 overflow-y-auto mb-3">{intelligence}</div>
          <button onClick={() => { navigator.clipboard.writeText(intelligence); setSuccess('Intelligence copied'); }}
            className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
        </div>
      )}
    </div>
  );

  const renderHealth = () => {
    const healthy = accounts.filter(a => a.engagementScore >= 70).length;
    const atRisk = accounts.filter(a => a.engagementScore >= 40 && a.engagementScore < 70).length;
    const cold = accounts.filter(a => a.engagementScore < 40).length;

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-xs text-gray-500 mb-1">Healthy Accounts</div>
            <div className="text-3xl font-bold text-emerald-400">{healthy}</div>
            <div className="text-xs text-gray-400 mt-1">Engagement &gt; 70%</div>
          </div>
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-xs text-gray-500 mb-1">At-Risk Accounts</div>
            <div className="text-3xl font-bold text-yellow-500">{atRisk}</div>
            <div className="text-xs text-gray-400 mt-1">Engagement 40-70%</div>
          </div>
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="text-xs text-gray-500 mb-1">Cold Accounts</div>
            <div className="text-3xl font-bold text-red-500">{cold}</div>
            <div className="text-xs text-gray-400 mt-1">Engagement &lt; 40%</div>
          </div>
        </div>

        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-semibold text-gray-100 mb-3">Account Health Distribution</div>
          <div className="space-y-2">
            {accounts.sort((a, b) => b.engagementScore - a.engagementScore).map(acct => (
              <div key={acct.id} className="flex items-center gap-3">
                <div className="text-sm text-gray-300 w-36 truncate">{acct.company}</div>
                <div className="flex-1 bg-gray-700 rounded-full h-3">
                  <div className={`h-3 rounded-full transition-all ${
                    acct.engagementScore >= 70 ? 'bg-emerald-500' : acct.engagementScore >= 40 ? 'bg-yellow-500' : 'bg-red-500'
                  }`} style={{ width: `${acct.engagementScore}%` }} />
                </div>
                <div className="text-xs text-gray-400 w-8 text-right">{acct.engagementScore}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'accounts', label: '🎖️ Accounts' },
          { id: 'plays', label: '📋 Plays' },
          { id: 'intelligence', label: '🔍 Intelligence' },
          { id: 'health', label: '❤️ Health' },
        ].map(t => (
          <button key={t.id} onClick={() => setAbmTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              abmTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {abmTab === 'accounts' && renderAccounts()}
      {abmTab === 'plays' && renderPlays()}
      {abmTab === 'intelligence' && renderIntelligence()}
      {abmTab === 'health' && renderHealth()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
