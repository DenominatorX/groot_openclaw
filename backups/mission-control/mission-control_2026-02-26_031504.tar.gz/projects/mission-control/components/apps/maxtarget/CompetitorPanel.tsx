'use client';

import { SavedOutputs } from './shared';
import { useState, useEffect } from 'react';

interface Competitor {

  id: string;

  name: string;

  website: string;

  threatLevel?: string;

  category?: string;

  founded?: string;

  estSize?: string;

  strengths: string[];

  weaknesses: string[];

  marketPosition: string;

  whatTheyDoBetter?: string;

  lastUpdated: string;

}

export default function CompetitorPanel() {

  const [competitors, setCompetitors] = useState<Competitor[]>([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState('');

  useEffect(() => {

    const loadCompetitors = async () => {

      try {

        const res = await fetch('/api/apps/maxtarget/competitors');

        if (res.ok) {

          const compData = await res.json();

          setCompetitors(Array.isArray(compData) ? compData : compData.competitors || []);

        }

      } catch (e) {

        setError('Failed to load competitors');

      } finally {

        setLoading(false);

      }

    };

    loadCompetitors();

  }, []);

  if (loading) {

    return <div className="text-gray-400">Loading Competitors...</div>;

  }

  const threatColors: Record<string, string> = {

    high: 'bg-red-500/20 text-red-400 border-red-500/30',

    medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',

    low: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',

  };

  const threatIcons: Record<string, string> = { high: '🔴', medium: '🟡', low: '🟢' };

  // Group by threat level

  const grouped = { high: [] as Competitor[], medium: [] as Competitor[], low: [] as Competitor[] };

  competitors.forEach(c => {

    const level = (c.threatLevel || 'medium') as keyof typeof grouped;

    if (grouped[level]) grouped[level].push(c);

    else grouped.medium.push(c);

  });

  return (

    <div className="space-y-6 bg-gray-950 text-white">

      {error && <div className="p-3 bg-red-600/20 text-red-400 rounded">{error}</div>}

      {/* Summary */}

      <div className="grid grid-cols-3 gap-3">

        <div className="bg-gray-800 rounded p-4 border border-red-500/30 text-center">

          <div className="text-2xl font-bold text-red-400">{grouped.high.length}</div>

          <div className="text-sm text-gray-400">🔴 High Threat</div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-yellow-500/30 text-center">

          <div className="text-2xl font-bold text-yellow-400">{grouped.medium.length}</div>

          <div className="text-sm text-gray-400">🟡 Medium Threat</div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-emerald-500/30 text-center">

          <div className="text-2xl font-bold text-emerald-400">{grouped.low.length}</div>

          <div className="text-sm text-gray-400">🟢 Low Threat</div>

        </div>

      </div>

      {/* Competitor Cards */}

      {(['high', 'medium', 'low'] as const).map(level => (

        grouped[level].length > 0 && (

          <div key={level}>

            <h3 className="text-lg font-semibold text-gray-300 mb-3 flex items-center gap-2">

              {threatIcons[level]} {level.charAt(0).toUpperCase() + level.slice(1)} Threat Competitors

            </h3>

            <div className="space-y-3">

              {grouped[level].map(comp => (

                <div key={comp.id} className={`bg-gray-800 rounded p-4 border ${threatColors[level]}`}>

                  <div className="flex justify-between items-start mb-2">

                    <div>

                      <div className="font-semibold text-gray-100 text-lg">{comp.name}</div>

                      {comp.category && <div className="text-xs text-gray-500">{comp.category}</div>}

                    </div>

                    <div className="text-right">

                      {comp.website && (

                        <div className="text-xs text-blue-400">{comp.website.replace('https://', '')}</div>

                      )}

                      {comp.estSize && <div className="text-xs text-gray-500 mt-1">{comp.estSize}</div>}

                    </div>

                  </div>

                  <div className="text-sm text-gray-400 mb-3">{comp.marketPosition}</div>

                  {comp.whatTheyDoBetter && (

                    <div className="text-xs text-[#DC143C] mb-3 bg-[#DC143C]/10 rounded p-2">

                      ⚡ <strong>What they do that we don't:</strong> {comp.whatTheyDoBetter}

                    </div>

                  )}

                  <div className="grid grid-cols-2 gap-3">

                    <div>

                      <div className="text-xs text-gray-500 mb-1 font-medium">Strengths</div>

                      <div className="space-y-1">

                        {(comp.strengths || []).slice(0, 4).map((s, i) => (

                          <div key={i} className="text-xs text-emerald-400">✓ {s}</div>

                        ))}

                      </div>

                    </div>

                    <div>

                      <div className="text-xs text-gray-500 mb-1 font-medium">Weaknesses</div>

                      <div className="space-y-1">

                        {(comp.weaknesses || []).length > 0 ? (

                          comp.weaknesses.slice(0, 4).map((w, i) => (

                            <div key={i} className="text-xs text-red-400">✗ {w}</div>

                          ))

                        ) : (

                          <div className="text-xs text-gray-600">No weaknesses identified</div>

                        )}

                      </div>

                    </div>

                  </div>

                </div>

              ))}

            </div>

          </div>

        )

      ))}

    <SavedOutputs panel="competitor" />
    </div>

  );

}