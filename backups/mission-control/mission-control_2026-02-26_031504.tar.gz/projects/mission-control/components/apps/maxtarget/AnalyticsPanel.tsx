'use client';

import { useState, useEffect } from 'react';
import { SavedOutputs } from './shared';

interface Lead {

  id: string;

  companyName: string;

  contactName: string;

  email: string;

  phone: string;

  source: string;

  score: number;

  stage: 'Lead' | 'MQL' | 'SQL' | 'Opportunity' | 'Closed Won' | 'Closed Lost';

  notes: string;

  createdDate: string;

  lastTouched: string;

}

interface Campaign {

  id: string;

  name: string;

  type: 'email' | 'display' | 'social' | 'search' | 'programmatic' | 'ABM';

  status: 'draft' | 'active' | 'paused' | 'completed';

  budget: number;

  spent: number;

  startDate: string;

  endDate: string;

  targetAudience: string;

  channels: string[];

  metrics: {

    impressions: number;

    clicks: number;

    conversions: number;

    ctr?: number;

    cpa?: number;

    roas?: number;

  };

}

const STAGES = ['Lead', 'MQL', 'SQL', 'Opportunity', 'Closed Won', 'Closed Lost'];

export default function AnalyticsPanel() {

  const [leads, setLeads] = useState<Lead[]>([]);

  const [campaigns, setCampaigns] = useState<Campaign[]>([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState('');

  useEffect(() => {

    const loadData = async () => {

      try {

        const [leadsRes, campaignsRes] = await Promise.all([

          fetch('/api/apps/maxtarget/leads'),

          fetch('/api/apps/maxtarget/campaigns'),

        ]);

        if (leadsRes.ok) { const d = await leadsRes.json(); setLeads(Array.isArray(d) ? d : d.leads || []); }

        if (campaignsRes.ok) setCampaigns((await campaignsRes.json()).campaigns || []);

      } catch (e) {

        setError('Failed to load data');

      } finally {

        setLoading(false);

      }

    };

    loadData();

  }, []);

  if (loading) {

    return <div className="text-gray-400">Loading Analytics...</div>;

  }

  const totalLeads = leads.length;

  const stageCount = (stage: string) => leads.filter(l => l.stage === stage).length;

  const activeCampaigns = campaigns.filter(c => c.status === 'active').length;

  const totalSpent = campaigns.reduce((s, c) => s + c.spent, 0);

  const totalConversions = campaigns.reduce((s, c) => s + c.metrics.conversions, 0);

  const totalImpressions = campaigns.reduce((s, c) => s + c.metrics.impressions, 0);

  const totalClicks = campaigns.reduce((s, c) => s + c.metrics.clicks, 0);

  const avgRoas = campaigns.filter(c => c.metrics.roas).length > 0

    ? (campaigns.reduce((s, c) => s + (c.metrics.roas || 0), 0) / campaigns.filter(c => c.metrics.roas).length) : 0;

  const channelData: Record<string, { spent: number; conversions: number }> = {};

  campaigns.forEach(c => {

    const key = c.type || 'other';

    if (!channelData[key]) channelData[key] = { spent: 0, conversions: 0 };

    channelData[key].spent += c.spent;

    channelData[key].conversions += c.metrics.conversions;

  });

  const sourceData: Record<string, number> = {};

  leads.forEach(l => { sourceData[l.source] = (sourceData[l.source] || 0) + 1; });

  const maxSourceCount = Math.max(...Object.values(sourceData), 1);

  const maxChannelSpend = Math.max(...Object.values(channelData).map(d => d.spent), 1);

  return (

    <div className="space-y-6 bg-gray-950 text-white">

      {error && <div className="p-3 bg-red-600/20 text-red-400 rounded">{error}</div>}

      {/* KPI Cards */}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">

        { [

          { label: 'Total Leads', value: totalLeads, color: 'text-blue-400' },

          { label: 'MQLs', value: stageCount('MQL'), color: 'text-yellow-400' },

          { label: 'SQLs', value: stageCount('SQL'), color: 'text-orange-400' },

          { label: 'Opportunities', value: stageCount('Opportunity'), color: 'text-purple-400' },

          { label: 'Closed Won', value: stageCount('Closed Won'), color: 'text-emerald-400' },

          { label: 'Active Campaigns', value: activeCampaigns, color: 'text-[#DC143C]' },

          { label: 'Total Spent', value: `$${totalSpent.toLocaleString()}`, color: 'text-white' },

          { label: 'Avg ROAS', value: `${avgRoas.toFixed(1)}x`, color: avgRoas >= 3 ? 'text-emerald-400' : 'text-yellow-400' },

        ].map((kpi, i) => (

          <div key={i} className="bg-gray-800 rounded p-4 border border-gray-700">

            <div className="text-sm text-gray-400">{kpi.label}</div>

            <div className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</div>

          </div>

        )) }

      </div>

      {/* Pipeline Conversion Funnel */}

      <div className="bg-gray-800 rounded p-4 border border-gray-700">

        <div className="font-semibold text-gray-100 mb-4">Pipeline Conversion Funnel</div>

        <div className="flex items-end gap-1 justify-center" style={{ height: '160px' }}>

          {STAGES.map((stage, i) => {

            const count = stageCount(stage);

            const maxCount = Math.max(...STAGES.map(s => stageCount(s)), 1);

            const height = Math.max((count / maxCount) * 140, 8);

            const colors = ['bg-blue-500', 'bg-yellow-500', 'bg-orange-500', 'bg-purple-500', 'bg-emerald-500', 'bg-red-500'];

            return (

              <div key={stage} className="flex flex-col items-center flex-1">

                <div className="text-xs font-bold text-white mb-1">{count}</div>

                <div className={`w-full max-w-[60px] ${colors[i]} rounded-t transition-all`} style={{ height: `${height}px` }} />

                <div className="text-xs text-gray-500 mt-2 text-center leading-tight">{stage}</div>

              </div>

            );

          })}

        </div>

      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

        {/* Campaign Performance by Type */}

        <div className="bg-gray-800 rounded p-4 border border-gray-700">

          <div className="font-semibold text-gray-100 mb-4">Spend by Campaign Type</div>

          <div className="space-y-3">

            {Object.entries(channelData).sort((a, b) => b[1].spent - a[1].spent).map(([channel, data]) => (

              <div key={channel}>

                <div className="flex justify-between text-xs mb-1">

                  <span className="text-gray-400 capitalize">{channel}</span>

                  <span className="text-white">${data.spent.toLocaleString()} • {data.conversions} conv</span>

                </div>

                <div className="bg-gray-900 rounded-full h-3 overflow-hidden">

                  <div className="h-full bg-[#DC143C] rounded-full transition-all" style={{ width: `${(data.spent / maxChannelSpend) * 100}%` }} />

                </div>

              </div>

            ))}

          </div>

        </div>

        {/* Lead Source Breakdown */}

        <div className="bg-gray-800 rounded p-4 border border-gray-700">

          <div className="font-semibold text-gray-100 mb-4">Lead Sources</div>

          <div className="space-y-3">

            {Object.entries(sourceData).sort((a, b) => b[1] - a[1]).map(([source, count]) => (

              <div key={source}>

                <div className="flex justify-between text-xs mb-1">

                  <span className="text-gray-400">{source}</span>

                  <span className="text-white">{count} leads</span>

                </div>

                <div className="bg-gray-900 rounded-full h-3 overflow-hidden">

                  <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${(count / maxSourceCount) * 100}%` }} />

                </div>

              </div>

            ))}

          </div>

        </div>

      </div>

      {/* Top Campaigns */}

      <div className="bg-gray-800 rounded p-4 border border-gray-700">

        <div className="font-semibold text-gray-100 mb-3">Top Performing Campaigns (by ROAS)</div>

        <div className="space-y-2">

          {campaigns.filter(c => c.metrics.roas).sort((a, b) => (b.metrics.roas || 0) - (a.metrics.roas || 0)).slice(0, 5).map((c, i) => (

            <div key={c.id} className="flex justify-between items-center text-sm bg-gray-900 rounded p-3">

              <div className="flex items-center gap-3">

                <span className="text-gray-600 w-5">{i + 1}.</span>

                <div>

                  <span className="text-gray-200">{c.name}</span>

                  <span className="text-xs text-gray-500 ml-2">{c.type}</span>

                </div>

              </div>

              <div className="flex items-center gap-4 text-xs">

                <span className="text-gray-400">{c.metrics.conversions} conv</span>

                <span className="text-gray-400">${c.spent.toLocaleString()}</span>

                <span className={`font-bold ${(c.metrics.roas || 0) >= 4 ? 'text-emerald-400' : 'text-yellow-400'}`}>

                  {(c.metrics.roas || 0).toFixed(1)}x ROAS

                </span>

              </div>

            </div>

          ))}

        </div>

      </div>

      {/* Quick Stats */}

      <div className="grid grid-cols-3 gap-3">

        <div className="bg-gray-800 rounded p-4 border border-gray-700 text-center">

          <div className="text-sm text-gray-400">Total Impressions</div>

          <div className="text-xl font-bold text-white">{totalImpressions.toLocaleString()}</div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-gray-700 text-center">

          <div className="text-sm text-gray-400">Total Clicks</div>

          <div className="text-xl font-bold text-white">{totalClicks.toLocaleString()}</div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-gray-700 text-center">

          <div className="text-sm text-gray-400">Avg CTR</div>

          <div className="text-xl font-bold text-white">{totalImpressions ? ((totalClicks / totalImpressions) * 100).toFixed(2) : 0}%</div>

        </div>

      </div>

      <SavedOutputs panel="analytics" />
    </div>

  );

}