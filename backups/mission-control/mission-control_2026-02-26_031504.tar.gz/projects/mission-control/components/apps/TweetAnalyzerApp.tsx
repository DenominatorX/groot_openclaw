'use client';

import React, { useState, useEffect } from 'react';
import styles from './TweetAnalyzerApp.module.css';

interface TeamAssessment {
  score: number;
  assessment: string;
}

interface Analysis {
  id: string;
  timestamp: string;
  tweetUrl: string | null;
  tweetText: string;
  author: {
    handle: string;
    name: string;
    avatar: string | null;
    followers: number | null;
  };
  analysis: {
    deepResearch: string;
    citations: string[];
    teamAssessments: {
      ceo: TeamAssessment;
      dirtyBird: TeamAssessment;
      forge: TeamAssessment;
      brain: TeamAssessment;
    };
    compatibilityScore: number;
    compatibilityBreakdown: {
      tech: number;
      expertise: number;
      marketNeed: number;
      resources: number;
    };
    implementationReport: string;
    actionItems: Array<{ task: string; assignee: string; dueDate: string }>;
  };
}

interface HistoryItem {
  id: string;
  timestamp: string;
  tweetUrl: string | null;
  author: { handle: string; name: string };
  compatibilityScore: number;
  preview: string;
}

const TweetAnalyzerApp: React.FC = () => {
  const [input, setInput] = useState('');
  const [inputMode, setInputMode] = useState<'url' | 'text'>('url');
  const [currentAnalysis, setCurrentAnalysis] = useState<Analysis | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Load history on mount
  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const res = await fetch('/api/apps/tweet-analyzer');
      if (res.ok) {
        const data = await res.json();
        setHistory(data.analyses || []);
      }
    } catch (err) {
      console.error('Failed to load history:', err);
    }
  };

  const handleAnalyze = async () => {
    if (!input.trim()) {
      setError('Please enter a tweet URL or text');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const payload = inputMode === 'url' ? { url: input } : { text: input };
      const res = await fetch('/api/apps/tweet-analyzer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || `HTTP ${res.status}`);
      }

      const analysis = await res.json();
      setCurrentAnalysis(analysis);
      setInput('');
      loadHistory(); // Refresh history
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const handleHistoryClick = (analysisId: string) => {
    const analysis = history.find(h => h.id === analysisId);
    if (analysis) {
      // Fetch full analysis
      fetchFullAnalysis(analysisId);
    }
  };

  const fetchFullAnalysis = async (id: string) => {
    try {
      const res = await fetch(`/api/apps/tweet-analyzer?id=${id}`);
      if (res.ok) {
        const analysis = await res.json();
        setCurrentAnalysis(analysis);
      }
    } catch (err) {
      console.error('Failed to fetch analysis:', err);
    }
  };

  const handleDeleteAnalysis = async (id: string) => {
    try {
      const res = await fetch(`/api/apps/tweet-analyzer`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });

      if (res.ok) {
        loadHistory();
        setCurrentAnalysis(null);
      }
    } catch (err) {
      console.error('Failed to delete analysis:', err);
    }
  };

  const filteredHistory = history.filter(
    h =>
      h.author.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.preview.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const scoreColor = (score: number) => {
    if (score >= 75) return '#10b981'; // green
    if (score >= 50) return '#f59e0b'; // amber
    return '#ef4444'; // red
  };

  return (
    <div className={styles.container}>
      <h1>🐦 Tweet Analyzer — X Intelligence Hub</h1>

      {/* Input Panel */}
      <div className={styles.inputPanel}>
        <div className={styles.modeToggle}>
          <button
            className={inputMode === 'url' ? styles.active : ''}
            onClick={() => setInputMode('url')}
          >
            🔗 URL
          </button>
          <button
            className={inputMode === 'text' ? styles.active : ''}
            onClick={() => setInputMode('text')}
          >
            📝 Text
          </button>
        </div>

        <input
          type="text"
          placeholder={
            inputMode === 'url'
              ? 'Paste tweet URL (https://twitter.com/...)'
              : 'Paste tweet text...'
          }
          value={input}
          onChange={e => {
            setInput(e.target.value);
            setError(null);
          }}
          onKeyPress={e => e.key === 'Enter' && handleAnalyze()}
          className={styles.input}
        />

        <button
          onClick={handleAnalyze}
          disabled={loading || !input.trim()}
          className={styles.analyzeButton}
        >
          {loading ? '⏳ Analyzing...' : '🔍 Analyze Tweet'}
        </button>

        {error && <div className={styles.error}>{error}</div>}
      </div>

      {/* Analysis Dashboard */}
      {currentAnalysis && (
        <div className={styles.dashboard}>
          {/* Tweet Card */}
          <div className={styles.tweetCard}>
            <div className={styles.tweetHeader}>
              {currentAnalysis.author.avatar && (
                <img
                  src={currentAnalysis.author.avatar}
                  alt={currentAnalysis.author.name}
                  className={styles.avatar}
                />
              )}
              <div className={styles.tweetMeta}>
                <div className={styles.authorName}>{currentAnalysis.author.name}</div>
                <div className={styles.authorHandle}>@{currentAnalysis.author.handle}</div>
                <div className={styles.timestamp}>{new Date(currentAnalysis.timestamp).toLocaleDateString()}</div>
              </div>
            </div>
            <div className={styles.tweetText}>{currentAnalysis.tweetText}</div>
          </div>

          {/* Author Profile Card */}
          <div className={styles.profileCard}>
            <h3>Author Profile</h3>
            <div className={styles.profileGrid}>
              <div>
                <div className={styles.label}>Followers</div>
                <div className={styles.value}>
                  {currentAnalysis.author.followers
                    ? `${(currentAnalysis.author.followers / 1000).toFixed(1)}K`
                    : 'N/A'}
                </div>
              </div>
              <div>
                <div className={styles.label}>Handle</div>
                <div className={styles.value}>@{currentAnalysis.author.handle}</div>
              </div>
            </div>
          </div>

          {/* Deep Research */}
          <div className={styles.researchCard}>
            <h3>📚 Deep Research</h3>
            <p>{currentAnalysis.analysis.deepResearch}</p>
            {(currentAnalysis.analysis.citations || []).length > 0 && (
              <div className={styles.citations}>
                <h4>Sources:</h4>
                {(currentAnalysis.analysis.citations || []).map((url, i) => (
                  <a
                    key={i}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={styles.citationLink}
                  >
                    {url.substring(0, 50)}...
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Team Assessment Cards */}
          <div className={styles.assessmentsGrid}>
            {/* CEO Card */}
            <div className={styles.assessmentCard}>
              <div className={styles.cardHeader}>💼 CEO</div>
              <div className={styles.scoreBar}>
                <div
                  className={styles.scoreFill}
                  style={{
                    width: `${currentAnalysis.analysis.teamAssessments.ceo.score}%`,
                    backgroundColor: scoreColor(currentAnalysis.analysis.teamAssessments.ceo.score),
                  }}
                />
              </div>
              <div className={styles.score}>
                {currentAnalysis.analysis.teamAssessments.ceo.score}/100
              </div>
              <p className={styles.assessment}>
                {currentAnalysis.analysis.teamAssessments.ceo.assessment}
              </p>
            </div>

            {/* Dirty Bird Card */}
            <div className={styles.assessmentCard}>
              <div className={styles.cardHeader}>⚖️ Dirty Bird</div>
              <div className={styles.scoreBar}>
                <div
                  className={styles.scoreFill}
                  style={{
                    width: `${currentAnalysis.analysis.teamAssessments.dirtyBird.score}%`,
                    backgroundColor: scoreColor(currentAnalysis.analysis.teamAssessments.dirtyBird.score),
                  }}
                />
              </div>
              <div className={styles.score}>
                {currentAnalysis.analysis.teamAssessments.dirtyBird.score}/100
              </div>
              <p className={styles.assessment}>
                {currentAnalysis.analysis.teamAssessments.dirtyBird.assessment}
              </p>
            </div>

            {/* Forge Card */}
            <div className={styles.assessmentCard}>
              <div className={styles.cardHeader}>🔧 Forge</div>
              <div className={styles.scoreBar}>
                <div
                  className={styles.scoreFill}
                  style={{
                    width: `${currentAnalysis.analysis.teamAssessments.forge.score}%`,
                    backgroundColor: scoreColor(currentAnalysis.analysis.teamAssessments.forge.score),
                  }}
                />
              </div>
              <div className={styles.score}>
                {currentAnalysis.analysis.teamAssessments.forge.score}/100
              </div>
              <p className={styles.assessment}>
                {currentAnalysis.analysis.teamAssessments.forge.assessment}
              </p>
            </div>

            {/* Brain Card */}
            <div className={styles.assessmentCard}>
              <div className={styles.cardHeader}>🧠 Brain</div>
              <div className={styles.scoreBar}>
                <div
                  className={styles.scoreFill}
                  style={{
                    width: `${currentAnalysis.analysis.teamAssessments.brain.score}%`,
                    backgroundColor: scoreColor(currentAnalysis.analysis.teamAssessments.brain.score),
                  }}
                />
              </div>
              <div className={styles.score}>
                {currentAnalysis.analysis.teamAssessments.brain.score}/100
              </div>
              <p className={styles.assessment}>
                {currentAnalysis.analysis.teamAssessments.brain.assessment}
              </p>
            </div>
          </div>

          {/* Compatibility Score */}
          <div className={styles.compatibilityCard}>
            <h3>🎯 Compatibility Score</h3>
            <div className={styles.bigScore}>{currentAnalysis.analysis.compatibilityScore}</div>
            <p className={styles.scoreLabel}>out of 100</p>
            <div className={styles.breakdown}>
              <div>Tech: {currentAnalysis.analysis.compatibilityBreakdown.tech}/30</div>
              <div>Expertise: {currentAnalysis.analysis.compatibilityBreakdown.expertise}/30</div>
              <div>Market Need: {currentAnalysis.analysis.compatibilityBreakdown.marketNeed}/25</div>
              <div>Resources: {currentAnalysis.analysis.compatibilityBreakdown.resources}/15</div>
            </div>
          </div>

          {/* Implementation Report */}
          <div className={styles.implementationCard}>
            <h3>🛠️ Implementation Report</h3>
            <p>{currentAnalysis.analysis.implementationReport}</p>
          </div>

          {/* Action Items */}
          <div className={styles.actionItemsCard}>
            <h3>📋 Action Items</h3>
            {(currentAnalysis.analysis.actionItems || []).length > 0 ? (
              <ul>
                {(currentAnalysis.analysis.actionItems || []).map((item, i) => (
                  <li key={i}>
                    <strong>{item.task}</strong> — {item.assignee} ({item.dueDate})
                  </li>
                ))}
              </ul>
            ) : (
              <p>No action items.</p>
            )}
          </div>
        </div>
      )}

      {/* History Panel */}
      <div className={styles.historyPanel}>
        <h3>📜 Analysis History</h3>
        <input
          type="text"
          placeholder="Search history..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className={styles.searchInput}
        />

        {filteredHistory.length > 0 ? (
          <div className={styles.historyTable}>
            <div className={styles.historyHeader}>
              <div>Date</div>
              <div>Author</div>
              <div>Preview</div>
              <div>Score</div>
              <div>Actions</div>
            </div>
            {filteredHistory.map(item => (
              <div
                key={item.id}
                className={styles.historyRow}
                onClick={() => handleHistoryClick(item.id)}
              >
                <div>{new Date(item.timestamp).toLocaleDateString()}</div>
                <div>@{item.author.handle}</div>
                <div className={styles.preview}>{item.preview.substring(0, 40)}...</div>
                <div
                  style={{
                    color: scoreColor(item.compatibilityScore),
                    fontWeight: 'bold',
                  }}
                >
                  {item.compatibilityScore}
                </div>
                <div>
                  <button
                    className={styles.deleteButton}
                    onClick={e => {
                      e.stopPropagation();
                      handleDeleteAnalysis(item.id);
                    }}
                  >
                    🗑️
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className={styles.emptyHistory}>No analyses yet. Start by analyzing a tweet!</p>
        )}
      </div>
    </div>
  );
};

export default TweetAnalyzerApp;
