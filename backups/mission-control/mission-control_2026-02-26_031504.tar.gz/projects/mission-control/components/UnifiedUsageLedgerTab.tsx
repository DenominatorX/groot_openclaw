'use client';

import { useEffect, useMemo, useState } from 'react';

type Provider = 'openrouter' | 'openai' | 'google' | 'xai' | 'anthropic' | 'nvidia';

type UsageEvent = {
  id?: number;
  provider: Provider;
  model: string;
  timestamp: string;
  tokens_in: number;
  tokens_out: number;
  cache_read?: number;
  cache_write?: number;
  request_id?: string | null;
  cost_usd: number;
  source: string;
};

type Metrics = {
  total_cost_usd: number;
  total_tokens_in: number;
  total_tokens_out: number;
  total_requests: number;
};

type DatePreset = '1h' | '24h' | '3d' | '7d' | '30d' | 'custom';

type SyncStatusRow = {
  provider: Provider;
  last_sync_status: 'success_with_records' | 'success_no_history_api' | 'success_zero_records' | 'failed' | 'running' | null;
  last_sync_at: string | null;
  last_sync_error: string | null;
  records_synced: number;
};

type IngestionHealth = {
  lastEventTimestamp: string | null;
  totalEvents: number;
  last24hTotalEvents: number;
  byProviderLast24h: Record<Provider, number>;
};

const PROVIDERS: Provider[] = ['openrouter', 'openai', 'google', 'xai', 'anthropic', 'nvidia'];

function toLocalInputValue(date: Date) {
  const tzOffsetMs = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - tzOffsetMs).toISOString().slice(0, 16);
}

function getRangeForPreset(preset: Exclude<DatePreset, 'custom'>) {
  const end = new Date();
  const start = new Date(end);

  if (preset === '1h') start.setHours(start.getHours() - 1);
  if (preset === '24h') start.setHours(start.getHours() - 24);
  if (preset === '3d') start.setDate(start.getDate() - 3);
  if (preset === '7d') start.setDate(start.getDate() - 7);
  if (preset === '30d') start.setDate(start.getDate() - 30);

  return {
    start: toLocalInputValue(start),
    end: toLocalInputValue(end),
  };
}

function fmtUsd(v: number) {
  return `$${(v || 0).toFixed(4)}`;
}

function fmtNum(v: number) {
  return (v || 0).toLocaleString();
}

function syncStatusLabel(status: SyncStatusRow['last_sync_status']) {
  switch (status) {
    case 'success_with_records': return '✅ Synced records';
    case 'success_no_history_api': return 'ℹ️ No history API (request-time only)';
    case 'success_zero_records': return '✅ History API returned zero records';
    case 'failed': return '❌ Failed';
    case 'running': return '⏳ Running';
    default: return 'n/a';
  }
}

export default function UnifiedUsageLedgerTab() {
  const [provider, setProvider] = useState<string>('');
  const [model, setModel] = useState('');
  const [datePreset, setDatePreset] = useState<DatePreset>('1h');
  const defaultRange = getRangeForPreset('1h');
  const [startDate, setStartDate] = useState(defaultRange.start);
  const [endDate, setEndDate] = useState(defaultRange.end);
  const [limit, setLimit] = useState(100);

  const [events, setEvents] = useState<UsageEvent[]>([]);
  const [models, setModels] = useState<string[]>([]);
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatusRow[]>([]);
  const [ingestionHealth, setIngestionHealth] = useState<IngestionHealth | null>(null);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const [sortBy, setSortBy] = useState<keyof UsageEvent>('timestamp');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (provider) p.set('provider', provider);
    if (model) p.set('model', model);
    if (startDate) p.set('startDate', new Date(startDate).toISOString());
    if (endDate) p.set('endDate', new Date(endDate).toISOString());
    p.set('limit', String(limit));
    return p.toString();
  }, [provider, model, startDate, endDate, limit]);

  async function load() {
    setLoading(true);
    try {
      const [eventsRes, metricsRes, statusRes, healthRes] = await Promise.all([
        fetch(`/api/usage-ledger/events?${query}`),
        fetch(`/api/usage-ledger/metrics?${query}`),
        fetch('/api/usage-ledger/sync/status'),
        fetch('/api/usage-ledger/health'),
      ]);

      const eventsJson = await eventsRes.json();
      const metricsJson = await metricsRes.json();
      const statusJson = await statusRes.json();
      const healthJson = await healthRes.json();

      setEvents(eventsJson.events || []);
      setModels(eventsJson.filters?.models || []);
      setMetrics(metricsJson.metrics || null);
      setSyncStatus(Array.isArray(statusJson.status) ? statusJson.status : []);
      setIngestionHealth(healthJson.health || null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [query]);

  function requestSort(key: keyof UsageEvent) {
    if (sortBy === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else {
      setSortBy(key);
      setSortDir('desc');
    }
  }

  const sortedEvents = useMemo(() => {
    const arr = [...events];
    arr.sort((a, b) => {
      const av: any = a[sortBy] ?? '';
      const bv: any = b[sortBy] ?? '';
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return arr;
  }, [events, sortBy, sortDir]);

  async function runSync(selectedProvider?: string) {
    setSyncing(true);
    try {
      await fetch('/api/usage-ledger/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(selectedProvider ? { provider: selectedProvider } : {}),
      });
      await load();
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="flex flex-wrap gap-2 items-end">
          <div>
            <label className="text-xs text-mc-muted block mb-1">Service</label>
            <select value={provider} onChange={(e) => setProvider(e.target.value)} className="px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm">
              <option value="">All Providers</option>
              {PROVIDERS.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs text-mc-muted block mb-1">Model</label>
            <input list="usage-models" value={model} onChange={(e) => setModel(e.target.value)} placeholder="All models" className="px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm" />
            <datalist id="usage-models">
              {models.map(m => <option key={m} value={m} />)}
            </datalist>
          </div>

          <div>
            <label className="text-xs text-mc-muted block mb-1">Time Range</label>
            <select
              value={datePreset}
              onChange={(e) => {
                const nextPreset = e.target.value as DatePreset;
                setDatePreset(nextPreset);
                if (nextPreset !== 'custom') {
                  const range = getRangeForPreset(nextPreset);
                  setStartDate(range.start);
                  setEndDate(range.end);
                }
              }}
              className="px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm"
            >
              <option value="1h">Last Hour</option>
              <option value="24h">Last 24 Hours</option>
              <option value="3d">Last 3 Days</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last Month</option>
              <option value="custom">Custom</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-mc-muted block mb-1">Start</label>
            <input
              type="datetime-local"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setDatePreset('custom');
              }}
              className="px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm"
            />
          </div>

          <div>
            <label className="text-xs text-mc-muted block mb-1">End</label>
            <input
              type="datetime-local"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setDatePreset('custom');
              }}
              className="px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm"
            />
          </div>

          <div>
            <label className="text-xs text-mc-muted block mb-1">Rows</label>
            <select value={limit} onChange={(e) => setLimit(Number(e.target.value))} className="px-2 py-1.5 bg-mc-bg border border-mc-border rounded text-sm">
              {[50, 100, 200, 500].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>

          <button
            onClick={() => {
              const range = getRangeForPreset('1h');
              setProvider('');
              setModel('');
              setDatePreset('1h');
              setStartDate(range.start);
              setEndDate(range.end);
            }}
            className="px-3 py-1.5 text-sm rounded border border-mc-border hover:bg-mc-bg"
          >
            Reset
          </button>
          <button onClick={() => runSync(provider || undefined)} disabled={syncing} className="px-3 py-1.5 text-sm rounded bg-mc-accent text-white hover:opacity-90 disabled:opacity-50">{syncing ? 'Syncing…' : provider ? `Sync ${provider}` : 'Sync All'}</button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-mc-surface border border-mc-border rounded p-3">
          <div className="text-xs text-mc-muted">Total Cost</div>
          <div className="text-lg font-bold">{fmtUsd(metrics?.total_cost_usd || 0)}</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded p-3">
          <div className="text-xs text-mc-muted">Tokens In</div>
          <div className="text-lg font-bold">{fmtNum(metrics?.total_tokens_in || 0)}</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded p-3">
          <div className="text-xs text-mc-muted">Tokens Out</div>
          <div className="text-lg font-bold">{fmtNum(metrics?.total_tokens_out || 0)}</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded p-3">
          <div className="text-xs text-mc-muted">Requests</div>
          <div className="text-lg font-bold">{fmtNum(metrics?.total_requests || 0)}</div>
        </div>
      </div>

      <div className="bg-mc-surface border border-mc-border rounded-lg p-4 text-xs">
        <div className="text-sm font-semibold mb-2">Ingestion Health</div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <div>Total events: {fmtNum(ingestionHealth?.totalEvents || 0)}</div>
          <div>Events (24h): {fmtNum(ingestionHealth?.last24hTotalEvents || 0)}</div>
          <div>Last event: {ingestionHealth?.lastEventTimestamp ? new Date(ingestionHealth.lastEventTimestamp).toLocaleString() : 'never'}</div>
        </div>
      </div>

      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="text-sm font-semibold mb-2">Sync Status</div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
          {syncStatus.map((s) => (
            <div key={s.provider} className="border border-mc-border rounded p-2">
              <div className="font-semibold">{s.provider}</div>
              <div>Status: {syncStatusLabel(s.last_sync_status)}</div>
              <div>Last: {s.last_sync_at ? new Date(s.last_sync_at).toLocaleString() : 'never'}</div>
              <div>Records: {s.records_synced ?? 0}</div>
              {s.last_sync_error && (
                <div className={s.last_sync_status === 'failed' ? 'text-red-400' : 'text-mc-muted'}>
                  {s.last_sync_status === 'failed' ? 'Err: ' : 'Note: '}
                  {s.last_sync_error}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="text-sm font-semibold mb-3">Usage Events</div>
        {loading ? (
          <div className="text-mc-muted text-sm">Loading usage ledger…</div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-mc-border text-mc-muted">
                  <th className="text-left py-2 cursor-pointer" onClick={() => requestSort('timestamp')}>Time</th>
                  <th className="text-left py-2 cursor-pointer" onClick={() => requestSort('provider')}>Provider</th>
                  <th className="text-left py-2 cursor-pointer" onClick={() => requestSort('model')}>Model</th>
                  <th className="text-right py-2 cursor-pointer" onClick={() => requestSort('tokens_in')}>In</th>
                  <th className="text-right py-2 cursor-pointer" onClick={() => requestSort('tokens_out')}>Out</th>
                  <th className="text-right py-2 cursor-pointer" onClick={() => requestSort('cost_usd')}>Cost (USD)</th>
                  <th className="text-left py-2">Request ID</th>
                  <th className="text-left py-2">Source</th>
                </tr>
              </thead>
              <tbody>
                {sortedEvents.map((e, idx) => (
                  <tr key={`${e.provider}-${e.request_id || idx}-${e.timestamp}`} className="border-b border-mc-border/40">
                    <td className="py-2 pr-2 whitespace-nowrap">{new Date(e.timestamp).toLocaleString()}</td>
                    <td className="py-2 pr-2">{e.provider}</td>
                    <td className="py-2 pr-2">{e.model}</td>
                    <td className="py-2 pr-2 text-right">{fmtNum(e.tokens_in)}</td>
                    <td className="py-2 pr-2 text-right">{fmtNum(e.tokens_out)}</td>
                    <td className="py-2 pr-2 text-right font-mono">{fmtUsd(e.cost_usd)}</td>
                    <td className="py-2 pr-2 max-w-[200px] truncate" title={e.request_id || ''}>{e.request_id || '—'}</td>
                    <td className="py-2 pr-2">{e.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {sortedEvents.length === 0 && (
              <div className="text-mc-muted text-sm py-4 space-y-1">
                <div>No usage events for current filters.</div>
                <div>
                  {ingestionHealth?.totalEvents
                    ? `Ledger has ${fmtNum(ingestionHealth.totalEvents)} total events, but none match the current filter range.`
                    : 'Ledger has no usage events yet. Generate model traffic (chat/agent/project/task calls) and refresh.'}
                </div>
                <div>
                  Tip: run Sync for providers with history APIs (OpenAI), and rely on request-time ingestion for providers without history APIs.
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
