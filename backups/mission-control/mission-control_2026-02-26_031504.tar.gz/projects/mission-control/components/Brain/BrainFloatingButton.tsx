'use client';
import { useState } from 'react';
import BrainChat from './BrainChat';

export default function BrainFloatingButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-[100] w-16 h-16 bg-gradient-to-r from-mc-accent to-purple-600 text-white rounded-full shadow-2xl hover:shadow-3xl hover:scale-110 active:scale-95 transition-all duration-200 flex items-center justify-center text-2xl font-bold drop-shadow-lg"
        aria-label="Open Brain chat"
        title="🧠 Brain - Universal memory & dispatch"
      >
        🧠
      </button>

      {isOpen && (
        <div
          className="fixed inset-0 z-[99] bg-black/60 backdrop-blur-sm flex justify-end"
          onClick={() => setIsOpen(false)}
        >
          <div
            className="w-full max-w-4xl h-full bg-mc-bg/95 backdrop-blur-md border-l-2 border-mc-accent shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-mc-border/50 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-mc-accent to-purple-500 bg-clip-text text-transparent mb-1">
                  🧠 Brain 2.0
                </h2>
                <p className="text-sm text-mc-muted">Universal memory system</p>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-2xl hover:text-mc-accent transition-colors p-2 rounded-lg hover:bg-mc-bg/50"
                aria-label="Close"
              >
                ×
              </button>
            </div>
            <BrainChat userId="kevin" />
          </div>
        </div>
      )}
    </>
  );
}
