/* @ts-nocheck */
'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Spinner } from '@/components/ui/Spinner';
import './AIDungeonGame.css';

// Types
interface Character {
  name: string;
  class: 'Warrior' | 'Mage' | 'Rogue' | 'Healer' | 'Bard';
  traits: string[];
  level: number;
  xp: number;
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
  statPoints: {
    strength: number;
    intelligence: number;
    dexterity: number;
    wisdom: number;
    charisma: number;
  };
}

interface InventoryItem {
  id: string;
  name: string;
  type: 'weapon' | 'armor' | 'potion' | 'misc';
  value?: number;
  quantity?: number;
}

interface GameScene {
  id: string;
  narrative: string;
  haiku: string;
  choices: Choice[];
  enemies?: Enemy[];
  inCombat: boolean;
}

interface Choice {
  id: string;
  text: string;
  consequence?: string;
}

interface Enemy {
  id: string;
  name: string;
  health: number;
  maxHealth: number;
  damage: number;
}

interface GameSave {
  id: string;
  character: Character;
  inventory: InventoryItem[];
  currentScene: GameScene;
  sceneHistory: GameScene[];
  campaign: 'fantasy' | 'sci-fi' | 'horror' | 'apocalypse' | 'pirate';
  achievements: string[];
  playTime: number;
  timestamp: string;
  slotName: string;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  unlocked: boolean;
}

const CAMPAIGNS = ['fantasy', 'sci-fi', 'horror', 'apocalypse', 'pirate'] as const;
const CLASSES = ['Warrior', 'Mage', 'Rogue', 'Healer', 'Bard'] as const;
const TRAITS = ['brave', 'cunning', 'wise', 'charismatic'];

const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  { id: 'first-kill', name: 'First Blood', description: 'Defeat your first enemy', unlocked: false },
  { id: 'level-10', name: 'Leveling Up', description: 'Reach level 10', unlocked: false },
  { id: 'dragon-slayer', name: 'Dragon Slayer', description: 'Defeat a dragon', unlocked: false },
  { id: 'pacifist', name: 'Pacifist', description: 'Complete a run without combat', unlocked: false },
  { id: 'speedrun', name: 'Speedrunner', description: 'Complete a campaign in under 30 minutes', unlocked: false },
];

export function AIDungeonGame() {
  const [gameState, setGameState] = useState<'menu' | 'character-creation' | 'playing' | 'loading'>('menu');
  const [character, setCharacter] = useState<Character | null>(null);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [currentScene, setCurrentScene] = useState<GameScene | null>(null);
  const [campaign, setCampaign] = useState<'fantasy' | 'sci-fi' | 'horror' | 'apocalypse' | 'pirate'>('fantasy');
  const [saves, setSaves] = useLocalStorage('dungeon-saves', {} as Record<string, GameSave>);
  const [achievements, setAchievements] = useState<Achievement[]>(DEFAULT_ACHIEVEMENTS);
  const [sceneHistory, setSceneHistory] = useState<GameScene[]>([]);
  const [selectedTraits, setSelectedTraits] = useState<string[]>([]);
  const [characterName, setCharacterName] = useState('');
  const [selectedClass, setSelectedClass] = useState<Character['class']>('Warrior');
  const historyRef = useRef<HTMLDivElement>(null);
  const startTimeRef = useRef<number>(Date.now());

  // Scroll to bottom of history
  useEffect(() => {
    if (historyRef.current) {
      historyRef.current.scrollTop = historyRef.current.scrollHeight;
    }
  }, [sceneHistory]);

  // Initialize game with new character
  const startNewGame = async (selectedCampaign: typeof campaign) => {
    setGameState('loading');
    setCampaign(selectedCampaign);

    const newCharacter: Character = {
      name: characterName || 'Adventurer',
      class: selectedClass,
      traits: selectedTraits.length ? selectedTraits : [TRAITS[0]],
      level: 1,
      xp: 0,
      health: selectedClass === 'Warrior' ? 100 : 60,
      maxHealth: selectedClass === 'Warrior' ? 100 : 60,
      mana: selectedClass === 'Mage' ? 100 : 30,
      maxMana: selectedClass === 'Mage' ? 100 : 30,
      statPoints: {
        strength: selectedClass === 'Warrior' ? 18 : 10,
        intelligence: selectedClass === 'Mage' ? 18 : 10,
        dexterity: selectedClass === 'Rogue' ? 18 : 10,
        wisdom: selectedClass === 'Healer' ? 18 : 10,
        charisma: selectedClass === 'Bard' ? 18 : 10,
      },
    };

    setCharacter(newCharacter);
    setInventory([
      { id: 'start-weapon', name: `${selectedClass} Starting Weapon`, type: 'weapon', quantity: 1 },
      { id: 'start-potion', name: 'Health Potion', type: 'potion', quantity: 3 },
    ]);
    setSceneHistory([]);
    setSelectedTraits([]);
    setCharacterName('');
    startTimeRef.current = Date.now();

    // Generate opening scene via API
    await generateOpeningScene(selectedCampaign, newCharacter);

    setGameState('playing');
  };

  const generateOpeningScene = async (camp: typeof campaign, char: Character) => {
    try {
      const response = await fetch('/api/games/dungeon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'open-scene',
          campaign: camp,
          character: char,
          inventory: [],
        }),
      });

      if (!response.ok) throw new Error('Failed to generate opening scene');
      const data = await response.json();
      setCurrentScene(data.scene);
      setSceneHistory([data.scene]);
    } catch (error) {
      console.error(error);
      // Fallback scene
      setCurrentScene({
        id: 'scene-1',
        narrative: `You wake in a mysterious realm. As a ${char.class} named ${char.name}, you feel the weight of destiny upon your shoulders.`,
        haiku: 'New world awaits\nYour journey begins anew\nChoose your first step now',
        choices: [
          { id: 'choice-1', text: 'Explore the nearby forest' },
          { id: 'choice-2', text: 'Head toward the distant city' },
          { id: 'choice-3', text: 'Rest and prepare equipment' },
        ],
        inCombat: false,
      });
    }
  };

  const makeChoice = async (choiceId: string) => {
    if (!currentScene || !character) return;

    setGameState('loading');
    const choice = (currentScene.choices || []).find((c) => c.id === choiceId);

    try {
      const response = await fetch('/api/games/dungeon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'next-scene',
          currentScene,
          choiceId,
          character,
          inventory,
          campaign,
        }),
      });

      if (!response.ok) throw new Error('Failed to generate next scene');
      const data = await response.json();

      // Update character if leveled up
      if (data.character) {
        setCharacter(data.character);
        checkAchievements(data.character);
      }

      // Update inventory if items gained
      if (data.inventory) setInventory(data.inventory);

      setCurrentScene(data.scene);
      setSceneHistory((prev) => [...prev, data.scene]);
    } catch (error) {
      console.error(error);
    }

    setGameState('playing');
  };

  const performCombatAction = async (action: 'attack' | 'defend' | 'magic' | 'item' | 'flee') => {
    if (!currentScene || !character) return;

    setGameState('loading');

    try {
      const response = await fetch('/api/games/dungeon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'combat',
          combatAction: action,
          currentScene,
          character,
          inventory,
          campaign,
        }),
      });

      if (!response.ok) throw new Error('Failed to resolve combat');
      const data = await response.json();

      if (data.character) {
        setCharacter(data.character);
        checkAchievements(data.character);
      }

      if (data.inventory) setInventory(data.inventory);

      setCurrentScene(data.scene);
      setSceneHistory((prev) => [...prev, data.scene]);
    } catch (error) {
      console.error(error);
    }

    setGameState('playing');
  };

  const checkAchievements = (updatedChar: Character) => {
    const newAchievements = [...achievements];

    if (updatedChar.level >= 10) {
      const idx = newAchievements.findIndex((a) => a.id === 'level-10');
      if (idx !== -1) newAchievements[idx].unlocked = true;
    }

    setAchievements(newAchievements);
  };

  const saveGame = (slotName: string) => {
    if (!character || !currentScene) return;

    const save: GameSave = {
      id: `save-${Date.now()}`,
      character,
      inventory,
      currentScene,
      sceneHistory,
      campaign,
      achievements: achievements.filter((a) => a.unlocked).map((a) => a.id),
      playTime: Math.floor((Date.now() - startTimeRef.current) / 1000),
      timestamp: new Date().toISOString(),
      slotName,
    };

    setSaves({ ...saves, [save.id]: save });
  };

  const loadGame = (saveId: string) => {
    const save = saves[saveId];
    if (!save) return;

    setCharacter(save.character);
    setInventory(save.inventory);
    setCurrentScene(save.currentScene);
    setSceneHistory(save.sceneHistory);
    setCampaign(save.campaign);
    setAchievements(achievements.map((a) => ({ ...a, unlocked: (save.achievements || []).includes(a.id) })));
    startTimeRef.current = Date.now() - save.playTime * 1000;
    setGameState('playing');
  };

  const getThemeClass = () => {
    const themeMap: Record<typeof campaign, string> = {
      fantasy: 'theme-fantasy',
      'sci-fi': 'theme-scifi',
      horror: 'theme-horror',
      apocalypse: 'theme-apocalypse',
      pirate: 'theme-pirate',
    };
    return themeMap[campaign];
  };

  // Render: Main Menu
  if (gameState === 'menu') {
    return (
      <div className={`ai-dungeon-container ${getThemeClass()}`}>
        <div className="parchment-panel main-menu">
          <div className="scrollwork-top"></div>
          <h1 className="title">🐉 AI Dungeon Master</h1>
          <p className="subtitle">An AI-powered adventure awaits</p>

          <div className="menu-section">
            <h2>New Game</h2>
            <div className="campaign-buttons">
              {CAMPAIGNS.map((c) => (
                <button
                  key={c}
                  className="campaign-btn"
                  onClick={() => {
                    setCampaign(c);
                    setGameState('character-creation');
                  }}
                >
                  {c === 'fantasy' && '⚔️'} {c === 'sci-fi' && '🚀'} {c === 'horror' && '👻'}{' '}
                  {c === 'apocalypse' && '☢️'} {c === 'pirate' && '🏴‍☠️'} {c}
                </button>
              ))}
            </div>
          </div>

          {Object.keys(saves).length > 0 && (
            <div className="menu-section">
              <h2>Load Game</h2>
              {Object.entries(saves).map(([id, save]) => (
                <button key={id} className="save-slot-btn" onClick={() => loadGame(id)}>
                  <span>{save.slotName}</span>
                  <span className="meta">Lv{save.character.level} • {save.campaign}</span>
                </button>
              ))}
            </div>
          )}

          <div className="menu-section">
            <h3>Achievements</h3>
            <div className="achievements-grid">
              {achievements.map((ach) => (
                <div key={ach.id} className={`achievement ${ach.unlocked ? 'unlocked' : 'locked'}`}>
                  <span title={ach.description}>{ach.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="scrollwork-bottom"></div>
        </div>
      </div>
    );
  }

  // Render: Character Creation
  if (gameState === 'character-creation') {
    return (
      <div className={`ai-dungeon-container ${getThemeClass()}`}>
        <div className="parchment-panel character-creator">
          <div className="scrollwork-top"></div>
          <h1>Create Your Character</h1>

          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              value={characterName}
              onChange={(e) => setCharacterName(e.target.value)}
              placeholder="Your hero's name"
            />
          </div>

          <div className="form-group">
            <label>Class</label>
            <div className="class-buttons">
              {CLASSES.map((cls) => (
                <button
                  key={cls}
                  className={`class-btn ${selectedClass === cls ? 'selected' : ''}`}
                  onClick={() => setSelectedClass(cls)}
                >
                  {cls}
                </button>
              ))}
            </div>
            <p className="class-hint">
              {selectedClass === 'Warrior' && 'Strong and durable. High health, strong attacks.'}
              {selectedClass === 'Mage' && 'Master of magic. High mana, powerful spells.'}
              {selectedClass === 'Rogue' && 'Swift and cunning. High dexterity, quick attacks.'}
              {selectedClass === 'Healer' && 'Wise and compassionate. Healing and support spells.'}
              {selectedClass === 'Bard' && 'Charismatic performer. Buffs and crowd control.'}
            </p>
          </div>

          <div className="form-group">
            <label>Traits (select up to 2)</label>
            <div className="trait-buttons">
              {TRAITS.map((trait) => (
                <button
                  key={trait}
                  className={`trait-btn ${selectedTraits.includes(trait) ? 'selected' : ''}`}
                  onClick={() => {
                    if (selectedTraits.includes(trait)) {
                      setSelectedTraits(selectedTraits.filter((t) => t !== trait));
                    } else if (selectedTraits.length < 2) {
                      setSelectedTraits([...selectedTraits, trait]);
                    }
                  }}
                >
                  {trait}
                </button>
              ))}
            </div>
          </div>

          <div className="action-buttons">
            <button className="btn-primary" onClick={() => startNewGame(campaign)}>
              Begin Adventure in {campaign}
            </button>
            <button className="btn-secondary" onClick={() => setGameState('menu')}>
              Back
            </button>
          </div>

          <div className="scrollwork-bottom"></div>
        </div>
      </div>
    );
  }

  // Render: Playing
  if (gameState === 'playing' && character && currentScene) {
    return (
      <div className={`ai-dungeon-container ${getThemeClass()}`}>
        <div className="game-layout">
          {/* Sidebar */}
          <div className="sidebar">
            <div className="parchment-panel character-panel">
              <h3>{character.name}</h3>
              <p className="class-badge">{character.class} • Level {character.level}</p>

              {/* Health Bar */}
              <div className="stat-bar">
                <label>Health</label>
                <div className="bar-bg">
                  <div
                    className="bar-fill health"
                    style={{ width: `${(character.health / character.maxHealth) * 100}%` }}
                  ></div>
                </div>
                <span>
                  {character.health} / {character.maxHealth}
                </span>
              </div>

              {/* Mana Bar */}
              <div className="stat-bar">
                <label>Mana</label>
                <div className="bar-bg">
                  <div
                    className="bar-fill mana"
                    style={{ width: `(${character.mana / character.maxMana}) * 100%` }}
                  ></div>
                </div>
                <span>
                  {character.mana} / {character.maxMana}
                </span>
              </div>

              {/* XP */}
              <p className="xp-text">XP: {character.xp} / {character.level * 100}</p>
            </div>

            {/* Inventory */}
            <div className="parchment-panel inventory-panel">
              <h4>Inventory ({inventory.length})</h4>
              <div className="inventory-list">
                {inventory.map((item) => (
                  <div key={item.id} className={`inventory-item type-${item.type}`}>
                    <span>{item.name}</span>
                    {item.quantity && item.quantity > 1 && <span className="qty">×{item.quantity}</span>}
                  </div>
                ))}
              </div>
            </div>

            {/* Achievements */}
            <div className="parchment-panel achievements-panel">
              <h4>Achievements</h4>
              <div className="achievements-mini">
                {achievements
                  .filter((a) => a.unlocked)
                  .map((a) => (
                    <div key={a.id} className="badge">
                      {a.name}
                    </div>
                  ))}
              </div>
            </div>

            {/* Quick Save */}
            <input
              type="text"
              className="save-input"
              placeholder="Save name..."
              onKeyPress={(e) => {
                if (e.key === 'Enter' && e.currentTarget.value) {
                  saveGame(e.currentTarget.value);
                  e.currentTarget.value = '';
                }
              }}
            />
          </div>

          {/* Main Content */}
          <div className="main-content">
            <div className="parchment-panel scene-panel">
              <div className="scrollwork-top"></div>

              {/* Haiku */}
              <div className="haiku">
                <pre>{currentScene.haiku}</pre>
              </div>

              {/* Scene History (Scrollable) */}
              <div className="scene-history" ref={historyRef}>
                {sceneHistory.map((scene) => (
                  <div key={scene.id} className="history-entry">
                    <p className="narrative">{scene.narrative}</p>
                  </div>
                ))}
              </div>

              {/* Current Narrative */}
              <div className="current-narrative">
                <p>{currentScene.narrative}</p>
              </div>

              {/* Combat UI (if in combat) */}
              {currentScene.inCombat && currentScene.enemies && (
                <div className="combat-section">
                  <h3>⚔️ Combat!</h3>
                  {currentScene.enemies.map((enemy) => (
                    <div key={enemy.id} className="enemy-card">
                      <h4>{enemy.name}</h4>
                      <div className="enemy-health">
                        <div className="bar-bg">
                          <div className="bar-fill enemy-hp" style={{ width: `${(enemy.health / enemy.maxHealth) * 100}%` }}></div>
                        </div>
                        {enemy.health} / {enemy.maxHealth}
                      </div>
                    </div>
                  ))}

                  <div className="combat-actions">
                    <button className="combat-btn attack" onClick={() => performCombatAction('attack')}>
                      ⚔️ Attack
                    </button>
                    <button className="combat-btn defend" onClick={() => performCombatAction('defend')}>
                      🛡️ Defend
                    </button>
                    <button className="combat-btn magic" onClick={() => performCombatAction('magic')}>
                      ✨ Magic
                    </button>
                    <button className="combat-btn item" onClick={() => performCombatAction('item')}>
                      💊 Item
                    </button>
                    <button className="combat-btn flee" onClick={() => performCombatAction('flee')}>
                      🏃 Flee
                    </button>
                  </div>
                </div>
              )}

              {/* Choices */}
              {!currentScene.inCombat && (
                <div className="choices-section">
                  <h3>What do you do?</h3>
                  {(currentScene.choices || []).map((choice) => (
                    <button key={choice.id} className="choice-btn" onClick={() => makeChoice(choice.id)}>
                      {choice.text}
                    </button>
                  ))}
                </div>
              )}

              <div className="scrollwork-bottom"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render: Loading
  if (gameState === 'loading') {
    return (
      <div className={`ai-dungeon-container ${getThemeClass()}`}>
        <div className="loading-container">
          <Spinner />
          <p>Initializing your adventure...</p>
        </div>
      </div>
    );
  }

  // Default fallback (should not reach here)
  return <div>Error: Unknown game state</div>;
}

export default AIDungeonGame;
