'use client';
import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

interface Player {
  id: string;
  name: string;
  avatar: string;
  score: number;
  streak: number;
  ready: boolean;
}

interface GameSettings {
  mode: string;
  category: string;
  questionCount: number;
  timePerQuestion: number;
  difficulty: string;
}

interface Question {
  question: string;
  options: string[];
  correct: number;
  funFact: string;
  difficulty: string;
  category: string;
}

interface Answer {
  playerId: string;
  answerIndex: number;
  timeMs: number;
  isCorrect: boolean;
}

interface ChatMessage {
  playerId: string;
  name: string;
  message: string;
  timestamp: string;
}

interface Room {
  code: string;
  hostId: string;
  players: Player[];
  settings: GameSettings;
  status: string;
  currentQuestion: number;
  question: Question | null;
  answers: Answer[];
  chat: ChatMessage[];
}

const WRESTLER_AVATARS = ['💪', '🤼', '🦅', '💀', '🔥', '🏆', '👑', '⚡', '🎭', '💥', '🌟', '🎤', '🏟️', '🥊', '⛓️', '🎯', '🏅', '🔗', '📺', '💎'];

const CATEGORIES = [
  { id: 'championship', emoji: '🏆', name: 'Championship History' },
  { id: 'finishing-moves', emoji: '💥', name: 'Finishing Moves' },
  { id: 'gimmicks', emoji: '🎭', name: 'Gimmicks & Characters' },
  { id: 'classic-moments', emoji: '📺', name: 'Classic Moments' },
  { id: 'wrestlemania', emoji: '🏟️', name: 'WrestleMania' },
  { id: 'attitude-era', emoji: '🔥', name: 'Attitude Era' },
  { id: 'hardcore-extreme', emoji: '💀', name: 'Hardcore & Extreme' },
  { id: 'international', emoji: '🌏', name: 'International Wrestling' },
  { id: 'aew', emoji: '🦅', name: 'AEW' },
  { id: 'golden-era', emoji: '👴', name: 'Golden Era' },
  { id: 'all', emoji: '🎲', name: 'All Categories' },
];

const MODES = [
  { id: 'quick', name: 'Quick Play', desc: '10 questions, fast-paced' },
  { id: 'gauntlet', name: 'Gauntlet', desc: '20 questions, survival mode' },
  { id: 'era-challenge', name: 'Era Challenge', desc: 'Pick an era' },
  { id: 'company-wars', name: 'Company Wars', desc: 'WWE vs AEW vs WCW' },
];

const DIFFICULTIES = [
  { id: 'easy', name: 'Easy' },
  { id: 'medium', name: 'Medium' },
  { id: 'hard', name: 'Hard' },
];

export interface WrestlingLobbyProps {
  onGameStart: (room: Room) => void;
  onBack?: () => void;
}

export default function WrestlingLobby({ onGameStart, onBack }: WrestlingLobbyProps) {
  const [mode, setMode] = useState<'create' | 'join' | 'lobby'>('create');
  const [playerId] = useState(() => {
    if (typeof window !== 'undefined') {
      let id = localStorage.getItem('wrestling-player-id');
      if (!id) {
        id = uuidv4();
        localStorage.setItem('wrestling-player-id', id);
      }
      return id;
    }
    return uuidv4();
  });

  const [playerName, setPlayerName] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('wrestling-player-name') || '';
    }
    return '';
  });

  const [selectedAvatar, setSelectedAvatar] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('wrestling-avatar') || WRESTLER_AVATARS[0];
    }
    return WRESTLER_AVATARS[0];
  });

  const [roomCode, setRoomCode] = useState('');
  const [room, setRoom] = useState<Room | null>(null);
  const [isHost, setIsHost] = useState(false);
  const [loading, setLoading] = useState(false);

  // Settings (host only)
  const [gameMode, setGameMode] = useState('quick');
  const [category, setCategory] = useState('all');
  const [questionCount, setQuestionCount] = useState(10);
  const [difficulty, setDifficulty] = useState('medium');

  // Save player profile
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('wrestling-player-name', playerName);
      localStorage.setItem('wrestling-avatar', selectedAvatar);
    }
  }, [playerName, selectedAvatar]);

  const createGame = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create',
          playerId,
          mode: gameMode,
          category,
          questionCount,
          difficulty,
        }),
      });

      const data = await res.json();
      if (data.success && data.room) {
        setRoom({ ...data.room, players: data.room.players || [], answers: data.room.answers || [], chat: data.room.chat || [] });
        setRoomCode(data.roomCode);
        setIsHost(true);
        setMode('lobby');
      }
    } catch (error) {
      console.error('Failed to create game:', error);
    } finally {
      setLoading(false);
    }
  };

  const joinGame = async () => {
    if (!roomCode.trim() || !playerName.trim()) {
      alert('Please enter room code and name');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'join',
          roomCode: roomCode.toUpperCase(),
          playerId,
          playerName,
          avatar: selectedAvatar,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setRoom(data.room);
        setRoomCode(data.room.code);
        setIsHost(false);
        setMode('lobby');
      } else {
        alert(data.error || 'Failed to join game');
      }
    } catch (error) {
      console.error('Failed to join game:', error);
      alert('Failed to join game');
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (updates: Partial<GameSettings>) => {
    if (!room) return;

    try {
      const res = await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update-settings',
          roomCode: room.code,
          playerId,
          settings: updates,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setRoom(data.room);
        if (updates.mode) setGameMode(updates.mode);
        if (updates.category) setCategory(updates.category);
        if (updates.questionCount) setQuestionCount(updates.questionCount);
        if (updates.difficulty) setDifficulty(updates.difficulty);
      }
    } catch (error) {
      console.error('Failed to update settings:', error);
    }
  };

  const startGame = async () => {
    if (!room || room.players.length < 2) {
      alert('Need at least 2 players to start');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'start',
          roomCode: room.code,
          playerId,
        }),
      });

      const data = await res.json();
      if (data.success) {
        onGameStart(data.room);
      }
    } catch (error) {
      console.error('Failed to start game:', error);
    } finally {
      setLoading(false);
    }
  };

  const leaveGame = async () => {
    if (!room) return;

    try {
      await fetch('/api/games/wrestling-trivia/multiplayer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'leave',
          roomCode: room.code,
          playerId,
        }),
      });

      setRoom(null);
      setRoomCode('');
      setMode('create');
    } catch (error) {
      console.error('Failed to leave game:', error);
    }
  };

  // CREATE MODE
  if (mode === 'create') {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
          
          .wrestling-title {
            font-family: 'Righteous', cursive;
            font-size: 2rem;
            font-weight: 900;
            color: #FFD700;
            text-shadow: 
              2px 2px 0 #DC143C,
              4px 4px 0 #000,
              6px 6px 0 #0000FF;
            letter-spacing: 2px;
          }

          .ring-rope {
            border: 3px solid;
            border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
            box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
          }

          .championship-belt {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
            color: #1a1a1a;
            font-weight: 900;
          }
        `}</style>

        <div className="text-center wrestling-title mb-8">🤼 MULTIPLAYER ARENA 🤼</div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Player Profile */}
          <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
            <div className="text-lg font-bold text-yellow-400">YOUR PROFILE</div>
            
            <div>
              <label className="block text-sm font-semibold text-white mb-2">Display Name</label>
              <input
                type="text"
                value={playerName}
                onChange={e => setPlayerName(e.target.value)}
                placeholder="Enter your wrestling name"
                maxLength={20}
                className="w-full px-3 py-2 bg-slate-700 border-2 border-slate-600 rounded text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-white mb-2">Choose Avatar</label>
              <div className="grid grid-cols-5 gap-2">
                {WRESTLER_AVATARS.map(avatar => (
                  <button
                    key={avatar}
                    onClick={() => setSelectedAvatar(avatar)}
                    className={`text-3xl p-2 rounded transition-all ${
                      selectedAvatar === avatar
                        ? 'bg-yellow-500 scale-110'
                        : 'bg-slate-700 hover:bg-slate-600'
                    }`}
                  >
                    {avatar}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3 bg-slate-700 rounded text-center">
              <div className="text-2xl mb-2">{selectedAvatar}</div>
              <div className="text-sm font-semibold text-white">{playerName || 'Your Name'}</div>
            </div>
          </div>

          {/* Game Mode Selection */}
          <div className="space-y-4">
            <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
              <div className="text-lg font-bold text-yellow-400">CREATE GAME</div>

              <div>
                <label className="block text-sm font-semibold text-white mb-2">Game Mode</label>
                <div className="space-y-2">
                  {MODES.map(m => (
                    <button
                      key={m.id}
                      onClick={() => setGameMode(m.id)}
                      className={`w-full p-3 rounded text-left transition-all ${
                        gameMode === m.id
                          ? 'bg-yellow-500 text-black font-bold'
                          : 'bg-slate-700 text-white hover:bg-slate-600'
                      }`}
                    >
                      <div className="font-semibold">{m.name}</div>
                      <div className="text-xs opacity-80">{m.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={createGame}
                disabled={!playerName.trim() || loading}
                className="w-full py-3 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:opacity-50 text-white font-bold rounded ring-rope transform hover:scale-105 transition-all"
              >
                {loading ? '⏳ Creating...' : '✨ CREATE GAME'}
              </button>
            </div>

            <button
              onClick={() => setMode('join')}
              className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded transition-colors"
            >
              → Join Existing Game
            </button>
          </div>
        </div>

        {onBack && (
          <button
            onClick={onBack}
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded transition-colors"
          >
            ← Back
          </button>
        )}
      </div>
    );
  }

  // JOIN MODE
  if (mode === 'join') {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
          
          .wrestling-title {
            font-family: 'Righteous', cursive;
            font-size: 2rem;
            font-weight: 900;
            color: #FFD700;
            text-shadow: 
              2px 2px 0 #DC143C,
              4px 4px 0 #000,
              6px 6px 0 #0000FF;
            letter-spacing: 2px;
          }

          .ring-rope {
            border: 3px solid;
            border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
            box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
          }
        `}</style>

        <div className="text-center wrestling-title mb-8">🎫 JOIN ARENA 🎫</div>

        <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
          <div>
            <label className="block text-sm font-semibold text-white mb-2">Display Name</label>
            <input
              type="text"
              value={playerName}
              onChange={e => setPlayerName(e.target.value)}
              placeholder="Enter your wrestling name"
              maxLength={20}
              className="w-full px-3 py-2 bg-slate-700 border-2 border-slate-600 rounded text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-white mb-2">Room Code</label>
            <input
              type="text"
              value={roomCode}
              onChange={e => setRoomCode(e.target.value.toUpperCase())}
              placeholder="e.g., SLAM69"
              maxLength={6}
              className="w-full px-3 py-2 bg-slate-700 border-2 border-slate-600 rounded text-white text-center text-2xl font-bold placeholder-gray-400 focus:border-yellow-400 focus:outline-none tracking-widest"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-white mb-2">Choose Avatar</label>
            <div className="grid grid-cols-5 gap-2">
              {WRESTLER_AVATARS.map(avatar => (
                <button
                  key={avatar}
                  onClick={() => setSelectedAvatar(avatar)}
                  className={`text-3xl p-2 rounded transition-all ${
                    selectedAvatar === avatar
                      ? 'bg-yellow-500 scale-110'
                      : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                >
                  {avatar}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={joinGame}
            disabled={!playerName.trim() || !roomCode.trim() || loading}
            className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 text-white font-bold rounded ring-rope transform hover:scale-105 transition-all"
          >
            {loading ? '⏳ Joining...' : '🎪 JOIN GAME'}
          </button>
        </div>

        <div className="space-y-2">
          <button
            onClick={() => setMode('create')}
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded transition-colors"
          >
            ← Create New Game
          </button>
          {onBack && (
            <button
              onClick={onBack}
              className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded transition-colors"
            >
              ← Back
            </button>
          )}
        </div>
      </div>
    );
  }

  // LOBBY MODE
  if (mode === 'lobby' && room) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
          
          .wrestling-title {
            font-family: 'Righteous', cursive;
            font-size: 1.8rem;
            font-weight: 900;
            color: #FFD700;
            text-shadow: 
              2px 2px 0 #DC143C,
              4px 4px 0 #000;
          }

          .ring-rope {
            border: 3px solid;
            border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
            box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
          }

          .championship-belt {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
            color: #1a1a1a;
            font-weight: 900;
          }
        `}</style>

        <div className="text-center wrestling-title mb-8">🏟️ ARENA LOBBY 🏟️</div>

        {/* Room Code */}
        <div className="championship-belt p-4 rounded-lg text-center">
          <div className="text-sm font-semibold">ROOM CODE</div>
          <div className="text-4xl font-bold tracking-widest">{room.code}</div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Players */}
          <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
            <div className="text-lg font-bold text-yellow-400">FIGHTERS IN RING</div>
            <div className="space-y-2">
              {room.players.map(player => (
                <div
                  key={player.id}
                  className={`p-3 rounded text-center ${
                    player.id === playerId
                      ? 'bg-gradient-to-r from-yellow-500 to-yellow-600'
                      : 'bg-slate-700'
                  }`}
                >
                  <div className="text-2xl mb-1">{player.avatar}</div>
                  <div className="text-sm font-semibold text-white">{player.name}</div>
                  {player.id === room.hostId && (
                    <div className="text-xs text-red-400 font-bold">👑 HOST</div>
                  )}
                </div>
              ))}
            </div>
            <div className="text-xs text-gray-400 text-center">
              {room.players.length}/8 Players
            </div>
          </div>

          {/* Settings (Host Only) */}
          {isHost && (
            <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
              <div className="text-lg font-bold text-yellow-400">GAME SETTINGS</div>

              <div>
                <label className="block text-xs font-semibold text-white mb-1">Questions</label>
                <select
                  value={questionCount}
                  onChange={e =>
                    updateSettings({ questionCount: parseInt(e.target.value) })
                  }
                  className="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                >
                  {[5, 10, 15, 20, 25].map(n => (
                    <option key={n} value={n}>
                      {n} questions
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-white mb-1">Category</label>
                <select
                  value={category}
                  onChange={e => updateSettings({ category: e.target.value })}
                  className="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat.id} value={cat.id}>
                      {cat.emoji} {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-white mb-1">Difficulty</label>
                <select
                  value={difficulty}
                  onChange={e => updateSettings({ difficulty: e.target.value })}
                  className="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                >
                  {DIFFICULTIES.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-white mb-1">
                  Time per Question
                </label>
                <select
                  value={room.settings.timePerQuestion}
                  onChange={e =>
                    updateSettings({ timePerQuestion: parseInt(e.target.value) })
                  }
                  className="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                >
                  {[10, 15, 20, 30].map(n => (
                    <option key={n} value={n}>
                      {n} seconds
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Ready Check */}
          <div className="bg-slate-800 p-6 rounded-lg ring-rope space-y-4">
            <div className="text-lg font-bold text-yellow-400">STATUS</div>

            <div className="space-y-2">
              <div className="text-sm text-white">
                <span className="font-semibold">Players Ready:</span> {room.players.length}/{room.players.length}
              </div>
            </div>

            {isHost && (
              <button
                onClick={startGame}
                disabled={room.players.length < 2 || loading}
                className="w-full py-3 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:opacity-50 text-white font-bold rounded ring-rope transform hover:scale-105 transition-all"
              >
                {loading ? '⏳ Starting...' : '🎪 START MATCH'}
              </button>
            )}

            <button
              onClick={leaveGame}
              className="w-full py-2 bg-red-700 hover:bg-red-800 text-white rounded transition-colors text-sm"
            >
              ← Leave Game
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
