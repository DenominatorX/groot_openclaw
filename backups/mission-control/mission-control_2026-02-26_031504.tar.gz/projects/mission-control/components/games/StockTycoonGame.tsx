'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { BarChart3, TrendingUp, TrendingDown, Trophy, Zap, Wallet, AlertCircle, RefreshCw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface Company {
  id: string;
  ticker: string;
  name: string;
  sector: string;
  currentPrice: number;
  volatility: number;
  description: string;
}

interface Holding {
  ticker: string;
  shares: number;
  buyPrice: number;
  currentPrice: number;
}

interface GameState {
  cash: number;
  holdings: Holding[];
  day: number;
  priceHistory: Record<string, number[]>;
  achievements: string[];
  totalGainLoss: number;
  difficulty: 'bull' | 'bear' | 'chaos';
}

interface MarketEvent {
  headline: string;
  impact: Record<string, number>;
  sentiment: 'positive' | 'negative' | 'neutral';
}

const StockTycoonGame: React.FC = () => {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [gameState, setGameState] = useState<GameState>({
    cash: 100000,
    holdings: [],
    day: 1,
    priceHistory: {},
    achievements: [],
    totalGainLoss: 0,
    difficulty: 'bull',
  });
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [buyQuantity, setBuyQuantity] = useState('1');
  const [latestEvent, setLatestEvent] = useState<MarketEvent | null>(null);
  const [gameOver, setGameOver] = useState(false);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [gameRunName, setGameRunName] = useState('');

  // Load companies
  useEffect(() => {
    const loadCompanies = async () => {
      try {
        const response = await fetch('/api/games/stock-tycoon/companies');
        const raw = await response.json();
        const data = Array.isArray(raw) ? raw : raw.companies || [];
        setCompanies(data);
        // Initialize price history
        const history: Record<string, number[]> = {};
        data.forEach((company: Company) => {
          history[company.ticker] = [company.currentPrice];
        });
        setGameState((prev) => ({ ...prev, priceHistory: history }));
      } catch (error) {
        console.error('Failed to load companies:', error);
      }
    };
    loadCompanies();
  }, []);

  // Load leaderboard
  useEffect(() => {
    const loadLeaderboard = async () => {
      try {
        const response = await fetch('/api/games/stock-tycoon/leaderboard');
        const data = await response.json();
        setLeaderboard((Array.isArray(data) ? data : data.leaderboard || []).sort((a: any, b: any) => b.finalValue - a.finalValue).slice(0, 10));
      } catch (error) {
        console.error('Failed to load leaderboard:', error);
      }
    };
    loadLeaderboard();
  }, []);

  const calculatePortfolioValue = useCallback(() => {
    const holdingsValue = gameState.holdings.reduce((sum, holding) => {
      const company = companies.find((c) => c.ticker === holding.ticker);
      return sum + (holding.shares * (company?.currentPrice || 0));
    }, 0);
    return gameState.cash + holdingsValue;
  }, [gameState.holdings, gameState.cash, companies]);

  const getAchievements = useCallback(() => {
    const newAchievements = [...gameState.achievements];
    const portfolioValue = calculatePortfolioValue();
    const gainLoss = portfolioValue - 100000;

    if (gameState.holdings.length === 1 && !newAchievements.includes('First Trade')) {
      newAchievements.push('First Trade');
    }
    if (gainLoss >= 10000 && !newAchievements.includes('10% Gain')) {
      newAchievements.push('10% Gain');
    }
    if (portfolioValue >= 200000 && !newAchievements.includes('Double Your Money')) {
      newAchievements.push('Double Your Money');
    }
    if (gameState.day >= 365 && !newAchievements.includes('Endurance')) {
      newAchievements.push('Endurance');
    }

    return newAchievements;
  }, [gameState.achievements, gameState.holdings, gameState.day, calculatePortfolioValue]);

  const nextDay = async () => {
    if (gameState.day >= 365) {
      endGame();
      return;
    }

    try {
      const response = await fetch('/api/games/stock-tycoon/event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ difficulty: gameState.difficulty }),
      });

      const event: MarketEvent = await response.json();
      setLatestEvent(event);

      // Update prices
      const updatedCompanies = companies.map((company) => {
        const priceChange = event.impact[company.ticker] || 0;
        const changePercent = 1 + priceChange / 100;
        return {
          ...company,
          currentPrice: Math.max(company.currentPrice * changePercent, 1),
        };
      });
      setCompanies(updatedCompanies);

      // Update price history
      const newPriceHistory = { ...gameState.priceHistory };
      updatedCompanies.forEach((company) => {
        if (!newPriceHistory[company.ticker]) {
          newPriceHistory[company.ticker] = [];
        }
        newPriceHistory[company.ticker].push(company.currentPrice);
        if (newPriceHistory[company.ticker].length > 30) {
          newPriceHistory[company.ticker].shift();
        }
      });

      const newAchievements = getAchievements();
      const newPortfolioValue = calculatePortfolioValue();

      setGameState((prev) => ({
        ...prev,
        day: prev.day + 1,
        priceHistory: newPriceHistory,
        achievements: newAchievements,
        totalGainLoss: newPortfolioValue - 100000,
      }));
    } catch (error) {
      console.error('Failed to get market event:', error);
    }
  };

  const buyStock = async () => {
    if (!selectedCompany) return;
    const shares = parseInt(buyQuantity);
    const cost = shares * selectedCompany.currentPrice;

    if (cost > gameState.cash) {
      alert('Insufficient funds');
      return;
    }

    const newHoldings = [...gameState.holdings];
    const existingHolding = newHoldings.find((h) => h.ticker === selectedCompany.ticker);
    if (existingHolding) {
      existingHolding.shares += shares;
    } else {
      newHoldings.push({
        ticker: selectedCompany.ticker,
        shares,
        buyPrice: selectedCompany.currentPrice,
        currentPrice: selectedCompany.currentPrice,
      });
    }

    setGameState((prev) => ({
      ...prev,
      cash: prev.cash - cost,
      holdings: newHoldings,
      achievements: getAchievements(),
    }));
    setBuyQuantity('1');
  };

  const sellStock = (ticker: string) => {
    const holdingIndex = gameState.holdings.findIndex((h) => h.ticker === ticker);
    if (holdingIndex === -1) return;

    const holding = gameState.holdings[holdingIndex];
    const company = companies.find((c) => c.ticker === ticker);
    if (!company) return;

    const proceeds = holding.shares * company.currentPrice;
    const newHoldings = gameState.holdings.filter((_, i) => i !== holdingIndex);

    setGameState((prev) => ({
      ...prev,
      cash: prev.cash + proceeds,
      holdings: newHoldings,
    }));
  };

  const endGame = async () => {
    const finalValue = calculatePortfolioValue();
    setGameState((prev) => ({ ...prev, totalGainLoss: finalValue - 100000 }));
    setGameOver(true);

    if (gameRunName.trim()) {
      try {
        await fetch('/api/games/stock-tycoon/leaderboard', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            playerName: gameRunName,
            finalValue,
            day: gameState.day,
            difficulty: gameState.difficulty,
            achievements: gameState.achievements,
          }),
        });
      } catch (error) {
        console.error('Failed to save leaderboard entry:', error);
      }
    }
  };

  const resetGame = () => {
    setGameState({
      cash: 100000,
      holdings: [],
      day: 1,
      priceHistory: {},
      achievements: [],
      totalGainLoss: 0,
      difficulty: 'bull',
    });
    setGameOver(false);
    setGameRunName('');
    setLatestEvent(null);
  };

  const portfolioValue = calculatePortfolioValue();
  const dayProgressPercent = (gameState.day / 365) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 text-white">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-10 h-10 text-green-400" />
              <h1 className="text-4xl font-bold">Stock Market Tycoon</h1>
            </div>
            <button
              onClick={() => setShowLeaderboard(!showLeaderboard)}
              className="px-4 py-2 bg-amber-500/20 hover:bg-amber-500/30 rounded-lg transition flex items-center gap-2"
            >
              <Trophy className="w-5 h-5" />
              Leaderboard
            </button>
          </div>

          {/* Game Over Screen */}
          {gameOver && (
            <div className="bg-slate-800/80 border border-amber-400 rounded-lg p-8 mb-6">
              <h2 className="text-3xl font-bold text-amber-400 mb-4">Game Over!</h2>
              <p className="text-xl mb-2">
                Final Portfolio Value: <span className="text-green-400 font-bold">${portfolioValue.toFixed(2)}</span>
              </p>
              <p className={`text-lg mb-6 ${gameState.totalGainLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                Total Gain/Loss: {gameState.totalGainLoss >= 0 ? '+' : ''}{gameState.totalGainLoss.toFixed(2)}
              </p>
              <input
                type="text"
                placeholder="Enter your name for leaderboard"
                value={gameRunName}
                onChange={(e) => setGameRunName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded mb-4 text-white"
              />
              <button
                onClick={resetGame}
                className="px-6 py-3 bg-green-500 hover:bg-green-600 rounded-lg font-semibold transition"
              >
                Play Again
              </button>
            </div>
          )}

          {/* Difficulty Selector */}
          {gameState.day === 1 && !gameOver && (
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 mb-6">
              <p className="text-sm mb-3 font-semibold">Select Difficulty:</p>
              <div className="flex gap-3">
                {(['bull', 'bear', 'chaos'] as const).map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setGameState((prev) => ({ ...prev, difficulty: diff }))}
                    className={`px-4 py-2 rounded capitalize font-semibold transition ${
                      gameState.difficulty === diff
                        ? 'bg-green-500 text-slate-900'
                        : 'bg-slate-700 hover:bg-slate-600'
                    }`}
                  >
                    {diff === 'bull' && '📈 Bull Market'}
                    {diff === 'bear' && '📉 Bear Market'}
                    {diff === 'chaos' && '⚡ Chaos Mode'}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Portfolio Stats */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
              <p className="text-sm text-slate-400 mb-1">Portfolio Value</p>
              <p className="text-2xl font-bold text-green-400">${portfolioValue.toFixed(0)}</p>
            </div>
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
              <p className="text-sm text-slate-400 mb-1">Cash Available</p>
              <p className="text-2xl font-bold text-blue-400">${gameState.cash.toFixed(0)}</p>
            </div>
            <div className={`bg-slate-800/50 border border-slate-700 rounded-lg p-4 ${gameState.totalGainLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              <p className="text-sm text-slate-400 mb-1">Total Gain/Loss</p>
              <p className="text-2xl font-bold">{gameState.totalGainLoss >= 0 ? '+' : ''}{gameState.totalGainLoss.toFixed(0)}</p>
            </div>
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
              <p className="text-sm text-slate-400 mb-1">Day {gameState.day} / 365</p>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-green-400 to-blue-400 h-2 rounded-full transition-all"
                  style={{ width: `${dayProgressPercent}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-3 gap-6">
          {/* Left: Market & Trading */}
          <div className="col-span-2 space-y-6">
            {/* Latest News Event */}
            {latestEvent && (
              <div className={`border-l-4 rounded-lg p-4 ${
                latestEvent.sentiment === 'positive'
                  ? 'bg-green-900/20 border-green-400'
                  : latestEvent.sentiment === 'negative'
                  ? 'bg-red-900/20 border-red-400'
                  : 'bg-blue-900/20 border-blue-400'
              }`}>
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Market News - Day {gameState.day}</p>
                    <p className="text-sm mt-1">{latestEvent.headline}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Stock Market */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Market</h2>
              <div className="grid grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                {companies.map((company) => (
                  <button
                    key={company.id}
                    onClick={() => setSelectedCompany(company)}
                    className={`p-3 rounded-lg text-left transition ${
                      selectedCompany?.id === company.id
                        ? 'bg-green-500/30 border border-green-400'
                        : 'bg-slate-700/50 hover:bg-slate-700 border border-slate-600'
                    }`}
                  >
                    <div className="font-bold text-sm">{company.ticker}</div>
                    <div className="text-xs text-slate-400">{company.name}</div>
                    <div className="text-green-400 font-semibold text-sm mt-1">${company.currentPrice.toFixed(2)}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Trading Panel */}
            {selectedCompany && !gameOver && (
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <h3 className="text-lg font-bold mb-4">{selectedCompany.name}</h3>
                <div className="space-y-3 mb-4">
                  <div>
                    <p className="text-sm text-slate-400 mb-2">Current Price: ${selectedCompany.currentPrice.toFixed(2)}</p>
                    <p className="text-xs text-slate-500">{selectedCompany.description}</p>
                  </div>
                  <div>
                    <label className="text-sm mb-2 block">Shares to Buy:</label>
                    <input
                      type="number"
                      min="1"
                      value={buyQuantity}
                      onChange={(e) => setBuyQuantity(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                    />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Cost: ${(parseInt(buyQuantity || '0') * selectedCompany.currentPrice).toFixed(2)}</p>
                  </div>
                </div>
                <button
                  onClick={buyStock}
                  disabled={parseInt(buyQuantity || '0') * selectedCompany.currentPrice > gameState.cash}
                  className="w-full px-4 py-2 bg-green-500 hover:bg-green-600 disabled:bg-slate-700 rounded font-semibold transition"
                >
                  Buy
                </button>
              </div>
            )}
          </div>

          {/* Right: Portfolio & Actions */}
          <div className="space-y-6">
            {/* Holdings */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Holdings ({gameState.holdings.length})</h2>
              <div className="space-y-3 max-h-48 overflow-y-auto">
                {gameState.holdings.length === 0 ? (
                  <p className="text-sm text-slate-400">No holdings yet</p>
                ) : (
                  gameState.holdings.map((holding) => {
                    const company = companies.find((c) => c.ticker === holding.ticker);
                    const gain = company ? (company.currentPrice - holding.buyPrice) * holding.shares : 0;
                    return (
                      <div key={holding.ticker} className="bg-slate-700/50 p-3 rounded border border-slate-600">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-bold text-sm">{holding.ticker}</p>
                            <p className="text-xs text-slate-400">{holding.shares} shares</p>
                          </div>
                          <button
                            onClick={() => sellStock(holding.ticker)}
                            disabled={gameOver}
                            className="px-2 py-1 bg-red-500/50 hover:bg-red-500 disabled:opacity-50 rounded text-xs font-semibold transition"
                          >
                            Sell
                          </button>
                        </div>
                        <p className={`text-xs ${gain >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {gain >= 0 ? '+' : ''}{gain.toFixed(2)}
                        </p>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Achievements */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
              <h2 className="text-lg font-bold mb-4">🏆 Achievements</h2>
              <div className="space-y-2">
                {gameState.achievements.length === 0 ? (
                  <p className="text-xs text-slate-400">Keep trading to earn achievements!</p>
                ) : (
                  gameState.achievements.map((ach) => (
                    <div key={ach} className="text-xs bg-slate-700/50 px-3 py-2 rounded">
                      ✓ {ach}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Game Controls */}
            {!gameOver && gameState.day < 365 && (
              <button
                onClick={nextDay}
                className="w-full px-6 py-3 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 rounded-lg font-bold transition flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                Next Day
              </button>
            )}

            {gameState.day >= 365 && !gameOver && (
              <button
                onClick={endGame}
                className="w-full px-6 py-3 bg-gradient-to-r from-amber-500 to-red-500 hover:from-amber-600 hover:to-red-600 rounded-lg font-bold transition"
              >
                End Game
              </button>
            )}
          </div>
        </div>

        {/* Leaderboard Modal */}
        {showLeaderboard && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 max-w-md w-full">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">🏆 Top 10 Players</h2>
                <button onClick={() => setShowLeaderboard(false)} className="text-2xl">✕</button>
              </div>
              <div className="space-y-3">
                {leaderboard.length === 0 ? (
                  <p className="text-slate-400">No scores yet. Be the first!</p>
                ) : (
                  leaderboard.map((entry, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 bg-slate-700/50 rounded">
                      <div>
                        <p className="font-bold">#{idx + 1} {entry.playerName}</p>
                        <p className="text-xs text-slate-400">{entry.difficulty} • Day {entry.day}</p>
                      </div>
                      <p className="font-bold text-green-400">${entry.finalValue.toFixed(0)}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StockTycoonGame;
