'use client';
import CyberHeistGame from './CyberHeistGame';

export default function CyberHeistGameWrapper() {
  return <CyberHeistGame />;
}
