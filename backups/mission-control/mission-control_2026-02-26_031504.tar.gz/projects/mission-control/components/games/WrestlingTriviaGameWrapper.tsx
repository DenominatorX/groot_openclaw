'use client';
import { useState } from 'react';
import WrestlingTriviaGame from './WrestlingTriviaGame';
import WrestlingLobby from './WrestlingLobby';
import WrestlingMultiplayer from './WrestlingMultiplayer';
import VoiceChat from './VoiceChat';
import PlayerProfile from './PlayerProfile';
import { v4 as uuidv4 } from 'uuid';

interface Room {
  code: string;
  hostId: string;
  players: Array<{ id: string; name: string; avatar: string; score: number; streak: number; ready: boolean }>;
  settings: {
    mode: string;
    category: string;
    questionCount: number;
    timePerQuestion: number;
    difficulty: string;
  };
  status: string;
  currentQuestion: number;
  question: any | null;
  answers: any[];
  chat: any[];
}

type GameMode = 'menu' | 'solo' | 'lobby' | 'multiplayer';

export default function WrestlingTriviaGameWrapper() {
  const [gameMode, setGameMode] = useState<GameMode>('menu');
  const [room, setRoom] = useState<Room | null>(null);
  const [playerId] = useState(() => {
    if (typeof window !== 'undefined') {
      let id = localStorage.getItem('wrestling-player-id');
      if (!id) {
        id = uuidv4();
        localStorage.setItem('wrestling-player-id', id);
      }
      return id;
    }
    return uuidv4();
  });

  const [playerName, setPlayerName] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('wrestling-player-name') || '';
    }
    return '';
  });

  const [showProfile, setShowProfile] = useState(false);

  const handleSoloGame = () => {
    setGameMode('solo');
  };

  const handleMultiplayerLobby = () => {
    setGameMode('lobby');
  };

  const handleGameStart = (startRoom: Room) => {
    setRoom(startRoom);
    setGameMode('multiplayer');
  };

  const handleGameEnd = () => {
    setRoom(null);
    setGameMode('menu');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-black p-4 md:p-8">
      {/* Menu State */}
      {gameMode === 'menu' && (
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <style>{`
            @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
            
            .wrestling-title {
              font-family: 'Righteous', cursive;
              font-size: 3rem;
              font-weight: 900;
              color: #FFD700;
              text-shadow: 
                2px 2px 0 #DC143C,
                4px 4px 0 #000,
                6px 6px 0 #0000FF;
              letter-spacing: 2px;
              transform: skewY(-2deg);
            }

            .ring-rope {
              border: 3px solid;
              border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
              box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
            }
          `}</style>

          <div className="wrestling-title mb-4">🤼 WRESTLING TRIVIA 🤼</div>
          <div className="text-xl text-red-400 font-bold tracking-widest mb-8">
            IT'S STILL REAL TO ME™
          </div>

          <div className="space-y-3">
            <button
              onClick={handleSoloGame}
              className="w-full py-4 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              🏆 SOLO CHALLENGE
            </button>

            <button
              onClick={handleMultiplayerLobby}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              👥 MULTIPLAYER MATCH
            </button>

            <button
              onClick={() => setShowProfile(true)}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              👤 MY PROFILE
            </button>
          </div>
        </div>
      )}

      {/* Solo Game Mode */}
      {gameMode === 'solo' && (
        <WrestlingTriviaGame />
      )}

      {/* Multiplayer Lobby */}
      {gameMode === 'lobby' && (
        <WrestlingLobby
          onGameStart={handleGameStart}
          onBack={() => setGameMode('menu')}
        />
      )}

      {/* Multiplayer Game */}
      {gameMode === 'multiplayer' && room && playerName && (
        <>
          <WrestlingMultiplayer
            roomCode={room.code}
            playerId={playerId}
            playerName={playerName}
            room={room}
            onGameEnd={handleGameEnd}
          />
          <VoiceChat
            roomCode={room.code}
            playerId={playerId}
            playerName={playerName}
            players={room.players}
          />
        </>
      )}

      {/* Player Profile Modal */}
      <PlayerProfile
        isOpen={showProfile}
        onClose={() => setShowProfile(false)}
      />
    </div>
  );
}
