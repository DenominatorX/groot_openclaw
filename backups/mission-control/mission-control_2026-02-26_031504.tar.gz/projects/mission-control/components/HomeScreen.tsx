'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import MarkdownMessage from './MarkdownMessage';
import ContextHealth from './ContextHealth';
import SubagentFeed from './SubagentFeed';
import DailyModelUpdates from './Brain/DailyModelUpdates';
// LiveActivityFeed removed (not useful vs Context Health)
// DiscordSessionManager removed (already in Context Health via filters)

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  model?: string;
  timestamp: string;
}

interface FocusItem {
  icon: string;
  label: string;
  value: string;
  color: string;
  detail?: string;
  tab?: string;
}

const MODELS = [
  { id: 'claude-opus-4-6', label: 'Opus 4.6', provider: 'anthropic', icon: '🟣' },
  { id: 'claude-sonnet-4-5', label: 'Sonnet 4.5', provider: 'anthropic', icon: '🔵' },
  { id: 'claude-haiku-4-5', label: 'Haiku 4.5', provider: 'anthropic', icon: '⚪' },
  { id: 'grok-4', label: 'Grok 4', provider: 'grok', icon: '🟠' },
  { id: 'grok-4-1-fast', label: 'Grok 4.1 Fast', provider: 'grok', icon: '⚡' },
  { id: 'minimax/minimax-m2.5', label: 'MiniMax M2.5', provider: 'openrouter', icon: '🟢' },
  { id: 'google/gemini-2.5-pro', label: 'Gemini 2.5 Pro', provider: 'openrouter', icon: '💎' },
  { id: 'moonshotai/kimi-k2-instruct', label: 'Kimi K2', provider: 'nvidia', icon: '🌙' },
];

const CHAT_FILE = 'brain-home';

interface HomeScreenProps {
  onNavigate?: (tab: string) => void;
}

export default function HomeScreen({ onNavigate }: HomeScreenProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [model, setModel] = useState(MODELS[0].id);
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [focusItems, setFocusItems] = useState<FocusItem[]>([]);
  const [briefing, setBriefing] = useState<string>('');
  const [loadingBriefing, setLoadingBriefing] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Load chat history
  useEffect(() => {
    fetch(`/api/chat?room=${CHAT_FILE}`, { credentials: 'include' })
      .then(r => r.json())
      .then(d => setMessages(d.messages || []))
      .catch(() => {});
  }, []);

  // Load focus items (dashboard stats)
  useEffect(() => {
    Promise.all([
      fetch('/api/tasks').then(r => r.json()).catch(() => ({ tasks: [] })),
      fetch('/api/projects').then(r => r.json()).catch(() => ({ projects: [] })),
      fetch('/api/agents').then(r => r.json()).catch(() => ({ agents: [] })),
      fetch('/api/issues').then(r => r.json()).catch(() => ({ issues: [] })),
      fetch('/api/health').then(r => r.json()).catch(() => ({})),
    ]).then(([tasksData, projData, agentsData, issuesData, healthData]) => {
      const tasks = tasksData.tasks || [];
      const projects = projData.projects || [];
      const agents = agentsData.agents || [];
      const issues = issuesData.issues || [];

      const inProgress = tasks.filter((t: any) => t.column === 'in-progress').length;
      const inbox = tasks.filter((t: any) => t.column === 'inbox').length;
      const openIssues = issues.filter((i: any) => i.status === 'open' || i.status === 'in-progress').length;
      const activeProjects = projects.filter((p: any) => p.status === 'in-progress').length;

      setFocusItems([
        { icon: '🔨', label: 'In Progress', value: `${inProgress}`, color: 'text-yellow-400', detail: `${inbox} in inbox`, tab: 'kanban' },
        { icon: '📁', label: 'Active Projects', value: `${activeProjects}`, color: 'text-blue-400', detail: `${projects.length} total`, tab: 'projects' },
        { icon: '🤖', label: 'Agents', value: `${agents.length}`, color: 'text-purple-400', detail: 'online', tab: 'analytics' },
        { icon: '🛡️', label: 'Open Issues', value: `${openIssues}`, color: 'text-red-400', detail: `${issues.length} total`, tab: 'issues' },
      ]);
    });
  }, []);

  // Generate briefing — cached for 24h, manual refresh available
  const [refreshingBriefing, setRefreshingBriefing] = useState(false);
  const briefingInFlight = useRef(false);

  const fetchBriefing = useCallback((force = false) => {
    // Check cache first
    if (!force) {
      try {
        const cached = localStorage.getItem('mc-brain-briefing');
        if (cached) {
          const { text, ts } = JSON.parse(cached);
          const age = Date.now() - ts;
          if (age < 24 * 60 * 60 * 1000 && text) { // 24 hours
            setBriefing(text);
            setLoadingBriefing(false);
            return;
          }
        }
      } catch {}
    }

    // Dedupe — prevent multiple concurrent requests
    if (briefingInFlight.current) return;
    briefingInFlight.current = true;

    setLoadingBriefing(true);
    if (force) setRefreshingBriefing(true);
    fetch('/api/chat/agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agentId: 'brain',
        message: 'Give me a brief executive status update. What should I focus on today? Keep it to 3-5 bullet points, concise. No greeting, just the bullets. This is a single daily briefing request — do not mention request counts or loops.',
        room: 'brain-briefing',
        skipSave: true,
      }),
    })
      .then(r => r.json())
      .then(d => {
        const text = d.reply || 'Brain is offline.';
        setBriefing(text);
        try { localStorage.setItem('mc-brain-briefing', JSON.stringify({ text, ts: Date.now() })); } catch {}
      })
      .catch(() => setBriefing('Could not reach Brain.'))
      .finally(() => { setLoadingBriefing(false); setRefreshingBriefing(false); briefingInFlight.current = false; });
  }, []);

  useEffect(() => { fetchBriefing(); }, [fetchBriefing]);

  // Auto-scroll chat — only after user has sent a message (not on initial load)
  const hasInteracted = useRef(false);
  useEffect(() => {
    if (!chatContainerRef.current || !hasInteracted.current) return;
    const el = chatContainerRef.current;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 150;
    if (nearBottom) chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || sending) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setSending(true);
    hasInteracted.current = true;

    try {
      // Save user message
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ room: CHAT_FILE, message: text, sender: 'Kevin' }),
      });

      // Get Brain response with selected model
      const res = await fetch('/api/chat/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          agentId: 'brain',
          message: text,
          room: CHAT_FILE,
          model: model,
        }),
      });
      const data = await res.json();

      const assistantMsg: Message = {
        id: `msg-${Date.now()}-reply`,
        role: 'assistant',
        content: data.reply || 'No response.',
        model: model,
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, assistantMsg]);

      // Save assistant message
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ room: CHAT_FILE, message: data.reply, sender: 'Brain' }),
      });
    } catch {
      setMessages(prev => [...prev, {
        id: `msg-${Date.now()}-err`,
        role: 'system',
        content: '⚠️ Failed to get response.',
        timestamp: new Date().toISOString(),
      }]);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }, [input, sending, model]);

  const currentModel = MODELS.find(m => m.id === model) || MODELS[0];

  return (
    <div className="flex flex-col h-full gap-3">
      {/* Focus Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {focusItems.map((item, i) => (
          <button key={i} onClick={() => item.tab && onNavigate?.(item.tab)}
            className="bg-mc-surface border border-mc-border rounded-lg p-2.5 md:p-3 hover:border-mc-accent/50 hover:bg-mc-accent/5 transition-colors text-left cursor-pointer">
            <div className="flex items-center gap-2">
              <span className="text-lg">{item.icon}</span>
              <div>
                <div className={`text-lg md:text-xl font-bold ${item.color}`}>{item.value}</div>
                <div className="text-xs md:text-sm font-semibold text-mc-text flex items-center justify-between"><span>{item.label}</span>{item.detail && <span className="text-mc-muted text-[10px]">{item.detail}</span>}<span>→</span></div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Briefing + Chat — side by side */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3" style={{ minHeight: '400px' }}>
        {/* Briefing */}
        <div className="bg-mc-surface border border-mc-border rounded-lg p-3 overflow-auto max-h-[500px]">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm">🧠</span>
            <span className="text-xs font-semibold text-mc-text">Brain&apos;s Daily Briefing</span>
            {loadingBriefing && <span className="text-xs text-mc-muted animate-pulse">thinking...</span>}
            <button onClick={() => fetchBriefing(true)} disabled={refreshingBriefing}
              className="ml-auto text-[10px] text-mc-muted hover:text-mc-accent disabled:opacity-50"
              title="Refresh briefing">
              {refreshingBriefing ? '⏳' : '🔄'}
            </button>
          </div>
          {briefing ? (
            <MarkdownMessage content={briefing} />
          ) : (
            <div className="text-xs text-mc-muted">Loading briefing...</div>
          )}
        </div>

        {/* Chat Area — half width */}
        <div className="flex flex-col bg-mc-surface border border-mc-border rounded-lg overflow-hidden min-h-0">
        {/* Chat Header */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-mc-border">
          <div className="flex items-center gap-2">
            <span className="text-sm">🧠</span>
            <span className="text-xs font-semibold text-mc-text">Brain</span>
            <span className="text-[10px] text-mc-muted">· Chief Intelligence Officer</span>
          </div>
          {/* Model Picker */}
          <div className="relative">
            <button
              onClick={() => setShowModelPicker(p => !p)}
              className="flex items-center gap-1.5 px-2 py-1 rounded bg-mc-bg border border-mc-border text-xs text-mc-muted hover:text-mc-text hover:border-mc-accent/50 transition-colors"
            >
              <span>{currentModel.icon}</span>
              <span className="hidden sm:inline">{currentModel.label}</span>
              <span className="text-[10px]">▼</span>
            </button>
            {showModelPicker && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setShowModelPicker(false)} />
                <div className="absolute right-0 top-full mt-1 bg-mc-surface border border-mc-border rounded-lg shadow-xl z-50 w-48 py-1">
                  {MODELS.map(m => (
                    <button
                      key={m.id}
                      onClick={() => { setModel(m.id); setShowModelPicker(false); }}
                      className={`w-full px-3 py-1.5 text-xs text-left flex items-center gap-2 hover:bg-mc-bg transition-colors ${
                        model === m.id ? 'text-mc-accent font-medium' : 'text-mc-text'
                      }`}
                    >
                      <span>{m.icon}</span>
                      <span>{m.label}</span>
                      {model === m.id && <span className="ml-auto text-mc-accent">✓</span>}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Messages */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0">
          {messages.length === 0 && (
            <div className="text-center text-mc-muted text-xs py-8">
              <p className="text-2xl mb-2">🧠</p>
              <p>Talk to Brain. Ask anything about your projects, health, goals, or tasks.</p>
              <p className="mt-1 opacity-60">Memory persists across sessions.</p>
            </div>
          )}
          {messages.map(msg => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] md:max-w-[75%] rounded-lg px-3 py-2 ${
                msg.role === 'user'
                  ? 'bg-mc-accent/20 text-mc-text'
                  : msg.role === 'system'
                  ? 'bg-red-500/10 text-red-400'
                  : 'bg-mc-bg text-mc-text border border-mc-border'
              }`}>
                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-[10px]">🧠</span>
                    <span className="text-[10px] text-mc-muted font-medium">Brain</span>
                    {msg.model && (
                      <span className="text-[9px] text-mc-muted/60 ml-1">
                        via {MODELS.find(m => m.id === msg.model)?.label || msg.model}
                      </span>
                    )}
                  </div>
                )}
                <MarkdownMessage content={msg.content} />
                <div className="text-[9px] text-mc-muted/50 mt-1 text-right">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="bg-mc-bg border border-mc-border rounded-lg px-3 py-2">
                <div className="flex items-center gap-2 text-xs text-mc-muted">
                  <span>🧠</span>
                  <span className="animate-pulse">thinking...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-mc-border p-2">
          <div className="flex gap-2">
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Ask Brain anything..."
              rows={1}
              className="flex-1 px-3 py-2 bg-mc-bg border border-mc-border rounded-lg text-sm text-mc-text placeholder:text-mc-muted resize-none focus:outline-none focus:border-mc-accent/50"
            />
            <button
              onClick={sendMessage}
              disabled={sending || !input.trim()}
              className="px-3 md:px-4 py-2 bg-mc-accent text-white rounded-lg text-sm font-medium hover:opacity-90 disabled:opacity-40 transition-opacity"
            >
              {sending ? '...' : '→'}
            </button>
          </div>
        </div>
        </div>

        {/* Model Updates — 3rd panel */}
        <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden max-h-[500px]">
          <DailyModelUpdates />
        </div>
      </div>

      {/* Context Health — full width */}
      <div className="min-h-0 overflow-auto max-h-[600px]">
        <ContextHealth embedded={true} />
      </div>

      {/* Live Activity Feed removed (replaced by Context Health + Sub-agent Activity) */}

      {/* Discord Sessions removed (already visible in Context Health via filter) */}

      {/* Subagent Feed — full width */}
      <div className="min-h-0 overflow-auto max-h-[500px]">
        <SubagentFeed />
      </div>
    </div>
  );
}
