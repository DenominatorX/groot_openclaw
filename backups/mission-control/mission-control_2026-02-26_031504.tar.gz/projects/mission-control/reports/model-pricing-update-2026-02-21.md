# Model Pricing Update — 2026-02-21

Updated file: `components/SettingsPanel.tsx` (Models tab reference list)

## Sources consulted
- Anthropic pricing: https://platform.claude.com/docs/en/about-claude/pricing
- xAI model docs/pricing: https://docs.x.ai/developers/models
- OpenRouter models index (model-specific values not fully verified): https://openrouter.ai/models

## Changes applied

| Model ID | Old Cost Detail | New Cost Detail | Source | Confidence |
|---|---|---|---|---|
| anthropic/claude-opus-4-6 | $15/M in · $75/M out | $5/M in · $25/M out | Anthropic pricing page | Medium |
| anthropic/claude-sonnet-4 | $3/M in · $15/M out | $3/M in · $15/M out | Anthropic pricing page | High |
| anthropic/claude-haiku-4-5 | $0.25/M in · $1.25/M out | $1/M in · $5/M out | Anthropic pricing page | Medium |
| xai/grok-4 | $0 (direct) | $0 (direct) - TBD (xAI API pricing is $3/M in · $15/M out) | xAI docs | Medium |
| openrouter/minimax/minimax-m2.5 | $0.30/M in · $1.20/M out | $0.30/M in · $1.20/M out (TBD verify) | OpenRouter models index | Low |
| openrouter/google/gemini-2.5-pro | $1.25/M in · $10/M out | $1.25/M in · $10/M out (TBD verify) | OpenRouter models index | Low |
| openrouter/google/gemini-3-pro-preview | $2/M in · $12/M out | $2/M in · $12/M out (TBD verify) | OpenRouter models index | Low |
| openrouter/x-ai/grok-4.1-fast | $0.20/M in · $0.50/M out | $0.20/M in · $0.50/M out | xAI docs + existing config | Medium |
| nvidia/moonshotai/kimi-k2-instruct | $0 (5K credits) | $0 (5K credits) - TBD (verify official NVIDIA pricing for direct integration) | Existing config + limited public references | Low |

## Notes
- Local models (LM Studio / Ollama) remain `$0`.
- OpenRouter values are marked `TBD verify` where direct model-specific pricing could not be confidently scraped/confirmed in this pass.
- Recommend a follow-up validation pass using OpenRouter per-model API metadata or manual per-model pricing pages.
