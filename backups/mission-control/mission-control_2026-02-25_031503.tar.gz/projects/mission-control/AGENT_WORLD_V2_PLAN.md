# Agent World v2 — NPC Behavior, Task Assignment & Agent Chat

## Overview
Transform Agent World from a static 3D visualization into an interactive Animal Crossing-style experience where agents wander as NPCs, can be clicked to assign tasks or chat, and visually move to workshops when working.

## Current State
- ✅ 11 character types, 3 biomes, idle wandering (tiny radius 1.5)
- ✅ Agents register on MC startup, position/move/action via IPC
- ✅ Click agent → profile panel (read-only, no task/chat)
- ✅ Agent sidebar in WorldTab
- ❌ Reset button doesn't reliably re-register (API→IPC timing issue)
- ❌ Wander radius too small — agents barely move
- ❌ No task assignment from Agent World
- ❌ No 1:1 agent chat
- ❌ Agent sidebar open by default (should be minimized)
- ❌ Room circles clipped on ocean floor (FIXED — raised to y=1.0)

## Plan of Attack

### Phase A: Fix Foundations (1-2 hours)
1. **Fix reset agents** — inline the registration logic into the world-reset endpoint; add retry; verify IPC connection
2. **Increase wander radius** — 1.5 → 6.0, with varied per-agent radii; increase pause variety
3. **Agent sidebar minimized by default** — flip `panelOpen` initial state to `false`
4. **Smoother walking** — increase move speed, add bobbing animation

### Phase B: Click-to-Interact from Agent World (2-3 hours)
1. **Click agent → action menu** (not just profile):
   - 💬 Chat — opens 1:1 chat panel
   - 📋 Assign Task — opens task picker (existing tasks + create new)
   - 👤 View Profile — opens current profile modal
2. **Task assignment from both MC and Agent World**:
   - MC: Task detail panel already has assignee dropdown
   - Agent World: Click → Assign Task → dropdown of existing tasks OR create new
   - Assigned agent walks to relevant room/workshop

### Phase C: Agent 1:1 Chat Tab in Profile (2-3 hours)
1. **Add "Chat" tab to AgentProfile modal** (4th tab: Overview | Personality | Chat | Stats)
2. **Chat persists per agent** in `data/chat/agent-{id}.json`
3. **Messages sent to agent via Anthropic API** (or agent's configured model)
4. **Agent responds in-character** using personality traits from profile
5. **Accessible from both**:
   - MC: Click agent in sidebar → Profile → Chat tab
   - Agent World: Click agent → Chat option → same panel

### Phase D: Visual Task Behavior (2-3 hours)
1. **When agent is assigned a task**: walks to nearest relevant room (Workshop for dev, Med Bay for health, etc.)
2. **Working animation** — agent paces/gestures at room location
3. **Task complete** — agent returns to idle wandering
4. **Status indicators** — floating icon above agent (💬 chatting, ⚡ working, 💤 idle)

### Phase E: Graphics Enhancement (Stretch)
1. **Better lighting** — volumetric rays, god rays for ocean
2. **Particle effects** — sparkles when agent completes task
3. **Smoother character animations** — procedural walk cycle, head tracking
4. **Name plates floating above agents** (already have labels, could improve)
5. **Mini-map** in corner showing agent positions

## Priority Order
A → B → C → D → E (each phase delivers standalone value)

## Cost Strategy
- Phase A-B: Groot (Opus) — architectural + UI
- Phase C chat API: Use Haiku for agent responses (cheap)
- Phase D-E: Sub-agent with Sonnet/Haiku for repetitive code

## Files to Modify
- `openclaw-world/src/scene/agent-idle.ts` — wander radius + behavior
- `openclaw-world/src/main.ts` — click handler, action menu
- `projects/mission-control/components/WorldTab.tsx` — sidebar default, reset button
- `projects/mission-control/components/AgentProfile.tsx` — add Chat tab
- `projects/mission-control/app/api/agents/world-reset/route.ts` — fix reset
- `projects/mission-control/app/api/chat/agent/route.ts` — NEW: 1:1 agent chat
- `projects/mission-control/data/chat/` — per-agent chat history
