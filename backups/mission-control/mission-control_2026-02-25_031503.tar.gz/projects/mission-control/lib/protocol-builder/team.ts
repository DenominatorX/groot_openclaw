/**
 * Protocol Builder - Team Integration
 * Handles team context, suggestions, and decisions for protocol generation
 */

import fs from 'fs';
import path from 'path';
import { 
  ProjectTeamMember, 
  TeamSuggestion, 
  TeamDecision, 
  ProtocolConfig, 
  ProtocolStep,
  DEFAULT_PROTOCOL
} from './types';

const PROJECTS_BASE = process.env.MC_PROJECTS_BASE || '/Users/groot/.openclaw/workspace/projects';
const TEAMS_PATH = path.join(process.cwd(), 'data', 'agents.json');

/**
 * Get a team's decision history file path
 */
export function getTeamDecisionPath(projectId: string): string {
  return path.join(PROJECTS_BASE, projectId, 'TEAM_DECISION.json');
}

/**
 * Read the current project team from the database
 * Returns the agents array from project data
 */
export async function getProjectTeam(projectId: string): Promise<ProjectTeamMember[]> {
  try {
    // Dynamic import to avoid circular dependencies
    const { getDb } = await import('@/lib/database');
    const db = getDb();
    
    const row = db.prepare('SELECT data FROM projects WHERE id = ?').get(projectId) as { data: string } | undefined;
    if (!row) return [];
    
    const project = JSON.parse(row.data);
    
    // Support both 'agents' (legacy) and 'team' (newer) formats
    if (project.team && Array.isArray(project.team)) {
      return project.team.map((member: any) => ({
        agentId: member.agentId || member.assignedAgentId || (member.pmAssign ? '' : ''),
        role: member.role || member.roleTitle || '',
        roleId: member.roleId,
        roleTitle: member.roleTitle,
        rules: member.rules,
        expectedDocuments: member.expectedDocuments,
        modelOverride: member.modelOverride,
        pmAssign: member.pmAssign,
        assignedAgentId: member.assignedAgentId,
      }));
    }
    
    if (project.agents && Array.isArray(project.agents)) {
      return project.agents.map((agent: any) => ({
        agentId: agent.agentId,
        role: agent.role,
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error reading project team:', error);
    return [];
  }
}

/**
 * Read available agents for team suggestions
 */
function getAvailableAgents(): any[] {
  try {
    const agentsData = JSON.parse(fs.readFileSync(TEAMS_PATH, 'utf8'));
    return agentsData.agents || [];
  } catch {
    return [];
  }
}

/**
 * Generate team suggestions based on project characteristics
 * Uses a simple heuristic approach
 */
export function generateTeamSuggestions(
  projectId: string,
  projectName?: string,
  projectDescription?: string
): TeamSuggestion[] {
  const agents = getAvailableAgents();
  const suggestions: TeamSuggestion[] = [];
  
  // Simple heuristics based on project name/description keywords
  const nameLower = (projectName || '').toLowerCase();
  const descLower = (projectDescription || '').toLowerCase();
  const combined = nameLower + ' ' + descLower;
  
  // Always suggest a PM
  const pmCandidate = agents.find((a: any) => ['ceo', 'groot', 'brain'].includes(a.id));
  if (pmCandidate) {
    suggestions.push({
      agentId: pmCandidate.id,
      role: 'Project Manager',
      roleTitle: 'Project Manager',
      reason: 'Standard project leadership role',
      model: pmCandidate.model,
      score: 90,
    });
  }
  
  // Detect project type and suggest appropriate roles
  if (combined.includes('web') || combined.includes('frontend') || combined.includes('ui') || combined.includes('react')) {
    const frontendDev = agents.find((a: any) => ['pixel', 'nova', 'swift'].includes(a.id));
    if (frontendDev) {
      suggestions.push({
        agentId: frontendDev.id,
        role: 'Frontend Developer',
        roleTitle: 'Frontend Developer',
        reason: 'Project involves frontend development',
        model: frontendDev.model,
        score: 85,
      });
    }
  }
  
  if (combined.includes('backend') || combined.includes('api') || combined.includes('server') || combined.includes('database')) {
    const backendDev = agents.find((a: any) => ['forge', 'floof', 'viper'].includes(a.id));
    if (backendDev) {
      suggestions.push({
        agentId: backendDev.id,
        role: 'Backend Developer',
        roleTitle: 'Backend Developer',
        reason: 'Project involves backend development',
        model: backendDev.model,
        score: 85,
      });
    }
  }
  
  if (combined.includes('fullstack') || combined.includes('full-stack')) {
    const fullstackDev = agents.find((a: any) => ['nova', 'pixel'].includes(a.id));
    if (fullstackDev) {
      suggestions.push({
        agentId: fullstackDev.id,
        role: 'Full-Stack Developer',
        roleTitle: 'Full-Stack Developer',
        reason: 'Full-stack development project',
        model: fullstackDev.model,
        score: 80,
      });
    }
  }
  
  if (combined.includes('data') || combined.includes('analytics') || combined.includes('analysis')) {
    const dataAnalyst = agents.find((a: any) => ['oracle', 'viper'].includes(a.id));
    if (dataAnalyst) {
      suggestions.push({
        agentId: dataAnalyst.id,
        role: 'Data Analyst',
        roleTitle: 'Data Analyst',
        reason: 'Data analysis project',
        model: dataAnalyst.model,
        score: 80,
      });
    }
  }
  
  if (combined.includes('research') || combined.includes('study') || combined.includes('investigation')) {
    const researcher = agents.find((a: any) => ['oracle', 'architect'].includes(a.id));
    if (researcher) {
      suggestions.push({
        agentId: researcher.id,
        role: 'Researcher',
        roleTitle: 'Research Lead',
        reason: 'Research-oriented project',
        model: researcher.model,
        score: 80,
      });
    }
  }
  
  if (combined.includes('test') || combined.includes('qa') || combined.includes('quality')) {
    const qaAgent = agents.find((a: any) => ['sentinel', 'scout'].includes(a.id));
    if (qaAgent) {
      suggestions.push({
        agentId: qaAgent.id,
        role: 'QA Engineer',
        roleTitle: 'QA Lead',
        reason: 'Quality assurance required',
        model: qaAgent.model,
        score: 75,
      });
    }
  }
  
  // Default: suggest a general developer if no specific matches
  if (suggestions.length < 2) {
    const defaultDev = agents.find((a: any) => ['groot', 'forge', 'pixel'].includes(a.id));
    if (defaultDev && !suggestions.find(s => s.agentId === defaultDev.id)) {
      suggestions.push({
        agentId: defaultDev.id,
        role: 'Developer',
        roleTitle: 'Lead Developer',
        reason: 'General development support',
        model: defaultDev.model,
        score: 70,
      });
    }
  }
  
  // Add a documentation role
  const docAgent = agents.find((a: any) => ['brain', 'archivist'].includes(a.id));
  if (docAgent && !suggestions.find(s => s.agentId === docAgent.id)) {
    suggestions.push({
      agentId: docAgent.id,
      role: 'Documentation',
      roleTitle: 'Technical Writer',
      reason: 'Documentation and knowledge management',
      model: docAgent.model,
      score: 60,
    });
  }
  
  return suggestions;
}

/**
 * Generate protocol steps based on team members
 * Maps team agents to appropriate protocol steps
 */
export function generateProtocolFromTeam(
  team: ProjectTeamMember[],
  defaultProtocol: ProtocolConfig = DEFAULT_PROTOCOL
): ProtocolConfig {
  if (!team || team.length === 0) {
    return { ...defaultProtocol };
  }
  
  // Extract agent IDs from team
  const agentIds = team
    .filter(m => m.agentId && !m.pmAssign)
    .map(m => m.agentId);
  
  // If team has members with agents, customize steps to use those agents
  if (agentIds.length > 0) {
    // Create a copy of default protocol with customized agent assignments
    const customizedSteps = defaultProtocol.steps.map(step => {
      // Try to match step type to team roles
      const matchingMember = team.find(m => {
        if (!m.agentId || m.pmAssign) return false;
        const roleLower = (m.role || '').toLowerCase();
        const stepNameLower = (step.name || '').toLowerCase();
        
        if (stepNameLower.includes('analyze') && roleLower.includes('analyst')) return true;
        if (stepNameLower.includes('plan') && (roleLower.includes('pm') || roleLower.includes('manager'))) return true;
        if (stepNameLower.includes('execute') && (roleLower.includes('developer') || roleLower.includes('dev'))) return true;
        if (stepNameLower.includes('verify') && (roleLower.includes('qa') || roleLower.includes('test'))) return true;
        if (stepNameLower.includes('notify') && (roleLower.includes('writer') || roleLower.includes('doc'))) return true;
        if (stepNameLower.includes('approve') && (roleLower.includes('pm') || roleLower.includes('manager'))) return true;
        
        return false;
      });
      
      if (matchingMember) {
        return { ...step, agent: matchingMember.agentId };
      }
      
      // Default: assign first available agent to steps without specific assignment
      if (!step.agent && agentIds.length > 0) {
        const roleLower = (step.type || '').toLowerCase();
        if (roleLower === 'task') {
          return { ...step, agent: agentIds[0] };
        }
      }
      
      return step;
    });
    
    return {
      ...defaultProtocol,
      steps: customizedSteps,
      allowedAgents: agentIds,
    };
  }
  
  return { ...defaultProtocol };
}

/**
 * Save team decision for audit purposes
 */
export function saveTeamDecision(projectId: string, decision: TeamDecision): boolean {
  try {
    const decisionPath = getTeamDecisionPath(projectId);
    const dir = path.dirname(decisionPath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    // Read existing decisions
    let existingDecisions: TeamDecision[] = [];
    if (fs.existsSync(decisionPath)) {
      try {
        const content = fs.readFileSync(decisionPath, 'utf8');
        existingDecisions = JSON.parse(content);
        if (!Array.isArray(existingDecisions)) {
          existingDecisions = [existingDecisions];
        }
      } catch {
        existingDecisions = [];
      }
    }
    
    // Add new decision
    existingDecisions.push(decision);
    
    // Keep only last 10 decisions
    if (existingDecisions.length > 10) {
      existingDecisions = existingDecisions.slice(-10);
    }
    
    fs.writeFileSync(decisionPath, JSON.stringify(existingDecisions, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('Error saving team decision:', error);
    return false;
  }
}

/**
 * Read team decision history
 */
export function getTeamDecision(projectId: string): TeamDecision | null {
  try {
    const decisionPath = getTeamDecisionPath(projectId);
    
    if (!fs.existsSync(decisionPath)) {
      return null;
    }
    
    const content = fs.readFileSync(decisionPath, 'utf8');
    const decisions: TeamDecision[] = JSON.parse(content);
    
    // Return most recent decision
    if (decisions && decisions.length > 0) {
      return decisions[decisions.length - 1];
    }
    
    return null;
  } catch (error) {
    console.error('Error reading team decision:', error);
    return null;
  }
}
