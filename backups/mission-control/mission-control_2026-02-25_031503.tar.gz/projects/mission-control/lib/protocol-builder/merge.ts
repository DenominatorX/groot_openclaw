/**
 * Protocol Builder Merge
 * Merge default + override with cycle detection and topological validation
 */

import { ProtocolConfig, ProtocolStep, ProtocolValidation, ProtocolMergeResult, DEFAULT_PROTOCOL } from './types';
import { validateProtocolConfig } from './schema';

/**
 * Detect cycles in the dependency graph using DFS
 * Returns array of step IDs involved in cycle, or empty if no cycle
 */
function detectCycle(steps: ProtocolStep[]): string[] {
  const stepMap = new Map<string, ProtocolStep>();
  steps.forEach(s => stepMap.set(s.id, s));
  
  const visited = new Set<string>();
  const recursionStack = new Set<string>();
  const cyclePath: string[] = [];
  
  function dfs(stepId: string, path: string[]): boolean {
    if (recursionStack.has(stepId)) {
      // Found cycle - extract cycle path
      const cycleStart = path.indexOf(stepId);
      cyclePath.push(...path.slice(cycleStart), stepId);
      return true;
    }
    
    if (visited.has(stepId)) return false;
    
    visited.add(stepId);
    recursionStack.add(stepId);
    
    const step = stepMap.get(stepId);
    if (step?.dependsOn) {
      if (dfs(step.dependsOn, [...path, stepId])) return true;
    }
    
    recursionStack.delete(stepId);
    return false;
  }
  
  for (const step of steps) {
    if (!visited.has(step.id)) {
      if (dfs(step.id, [])) {
        return cyclePath;
      }
    }
  }
  
  return [];
}

/**
 * Validate protocol step ordering (topological validation)
 */
function validateStepOrdering(steps: ProtocolStep[]): string[] {
  const errors: string[] = [];
  const stepIds = new Set(steps.map(s => s.id));
  
  // Check all dependencies exist
  for (const step of steps) {
    if (step.dependsOn && !stepIds.has(step.dependsOn)) {
      errors.push(`Step "${step.id}" depends on non-existent step "${step.dependsOn}"`);
    }
  }
  
  // Detect cycles
  const cycle = detectCycle(steps);
  if (cycle.length > 0) {
    errors.push(`Circular dependency detected: ${cycle.join(' -> ')}`);
  }
  
  return errors;
}

/**
 * Validate agent and model allowlists
 */
function validateAllowlists(
  protocol: ProtocolConfig,
  projectOverride?: ProtocolConfig
): string[] {
  const errors: string[] = [];
  
  const allowedAgents = projectOverride?.allowedAgents ?? protocol.allowedAgents;
  const modelAllowlist = projectOverride?.modelAllowlist ?? protocol.modelAllowlist;
  
  // Validate steps against allowlists
  for (const step of protocol.steps) {
    if (step.agent && allowedAgents && allowedAgents.length > 0) {
      if (!allowedAgents.includes(step.agent)) {
        errors.push(`Step "${step.id}" uses unauthorized agent "${step.agent}". Allowed: ${allowedAgents.join(', ')}`);
      }
    }
    
    if (step.model && modelAllowlist && modelAllowlist.length > 0) {
      if (!modelAllowlist.includes(step.model)) {
        errors.push(`Step "${step.id}" uses unauthorized model "${step.model}". Allowed: ${modelAllowlist.join(', ')}`);
      }
    }
  }
  
  return errors;
}

/**
 * Merge default protocol with project override
 * Override takes precedence over default
 */
export function mergeProtocols(
  defaultProtocol: ProtocolConfig,
  projectOverride?: ProtocolConfig | null
): ProtocolMergeResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  // If no override, return default as-is (validated)
  if (!projectOverride) {
    return {
      effectiveProtocol: defaultProtocol,
      validation: { valid: true, errors: [], warnings: [] },
    };
  }
  
  // Validate the override first
  const validation = validateProtocolConfig(projectOverride);
  if (!validation.success) {
    return {
      effectiveProtocol: defaultProtocol,
      validation: {
        valid: false,
        errors: validation.errors,
        warnings: [],
      },
    };
  }
  
  // Merge: override values take precedence
  const mergedProtocol: ProtocolConfig = {
    version: projectOverride.version ?? defaultProtocol.version,
    steps: projectOverride.steps ?? defaultProtocol.steps,
    allowedAgents: projectOverride.allowedAgents ?? defaultProtocol.allowedAgents,
    modelAllowlist: projectOverride.modelAllowlist ?? defaultProtocol.modelAllowlist,
    defaultTimeoutMin: projectOverride.defaultTimeoutMin ?? defaultProtocol.defaultTimeoutMin,
    defaultRetries: projectOverride.defaultRetries ?? defaultProtocol.defaultRetries,
  };
  
  // Add warnings for overridden fields
  if (projectOverride.version && projectOverride.version !== defaultProtocol.version) {
    warnings.push(`Version overridden from "${defaultProtocol.version}" to "${projectOverride.version}"`);
  }
  
  // Validate step ordering
  const orderingErrors = validateStepOrdering(mergedProtocol.steps);
  errors.push(...orderingErrors);
  
  // Validate allowlists if present
  const allowlistErrors = validateAllowlists(mergedProtocol, projectOverride);
  errors.push(...allowlistErrors);
  
  return {
    effectiveProtocol: mergedProtocol,
    validation: {
      valid: errors.length === 0,
      errors,
      warnings,
    },
  };
}

/**
 * Full validation of a protocol (used for PUT validation)
 */
export function validateProtocol(protocol: ProtocolConfig): ProtocolValidation {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  // Schema validation
  const schemaResult = validateProtocolConfig(protocol);
  if (!schemaResult.success) {
    return {
      valid: false,
      errors: schemaResult.errors,
      warnings: [],
    };
  }
  
  // Ordering validation
  const orderingErrors = validateStepOrdering(protocol.steps);
  errors.push(...orderingErrors);
  
  // Allowlist validation (for override - warn if not set)
  if (!protocol.allowedAgents || protocol.allowedAgents.length === 0) {
    warnings.push('No allowedAgents defined - any agent can be used');
  }
  if (!protocol.modelAllowlist || protocol.modelAllowlist.length === 0) {
    warnings.push('No modelAllowlist defined - any model can be used');
  }
  
  // Allowlist step validation (pass override as both to check against itself)
  const allowlistErrors = validateAllowlists(protocol, protocol);
  errors.push(...allowlistErrors);
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}
