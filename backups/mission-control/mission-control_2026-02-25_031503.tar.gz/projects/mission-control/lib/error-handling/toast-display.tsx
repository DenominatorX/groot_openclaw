// Toast Notification Display Component
// Renders all toasts from the global store

'use client';

import { useEffect } from 'react';
import { useAppStore } from '@/lib/stores/app-store';
import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from 'lucide-react';

const iconMap = {
  success: CheckCircle,
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info,
};

const colorMap = {
  success: 'bg-green-900/80 border-green-600 text-green-100',
  error: 'bg-red-900/80 border-red-600 text-red-100',
  warning: 'bg-yellow-900/80 border-yellow-600 text-yellow-100',
  info: 'bg-blue-900/80 border-blue-600 text-blue-100',
};

export function ToastDisplay() {
  const { toasts, removeToast } = useAppStore();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-md">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={() => removeToast(toast.id)} />
      ))}
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { toast: import('@/lib/stores/app-store').Toast; onDismiss: () => void }) {
  const Icon = iconMap[toast.type];

  useEffect(() => {
    if (toast.duration === 0) return; // 0 = persistent

    const timer = setTimeout(onDismiss, toast.duration ?? 5000);
    return () => clearTimeout(timer);
  }, [toast.duration, onDismiss]);

  return (
    <div
      className={`flex items-start gap-3 px-4 py-3 rounded-lg border shadow-lg backdrop-blur-sm animate-in slide-in-from-right ${colorMap[toast.type]}`}
      role="alert"
    >
      <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
      <p className="flex-1 text-sm font-medium">{toast.message}</p>
      {toast.dismissible && (
        <button
          onClick={onDismiss}
          className="flex-shrink-0 p-1 rounded hover:bg-white/10 transition-colors"
          aria-label="Dismiss"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}