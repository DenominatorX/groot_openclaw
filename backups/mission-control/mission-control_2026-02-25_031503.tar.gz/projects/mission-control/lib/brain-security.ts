/**
 * Brain Orchestration Security Module - Phase 3
 * 
 * Implements:
 * 1. Role-based context filtering
 * 2. Encrypted meeting transcript storage
 * 3. Capability-based delegation limits
 * 4. Consensus verification and randomization
 */

import crypto from 'crypto';

// ============================================================================
// CONFIGURATION
// ============================================================================

// Encryption key derived from settings (in production, use proper key management)
const ENCRYPTION_KEY = process.env.BRAIN_ENCRYPTION_KEY || 
  crypto.createHash('sha256').update('mission-control-brain-key-v1').digest();

// Agent role tiers for access control
export const AGENT_TIERS = {
  OWNER: 0,           // Kevin - full access
  EXECUTIVE: 1,       // Executive board members
  VP: 2,              // VP level
  DIRECTOR: 3,        // Directors
  MANAGER: 4,         // Managers
  SENIOR_STAFF: 5,    // Senior staff
  FRONTLINE: 6,       // Frontline staff
} as const;

// Sensitive data categories that require filtering
const SENSITIVE_CATEGORIES = {
  PERSONAL: ['password', 'ssn', 'social_security', 'credit_card', 'bank_account', 'medical', 'health', 'personal_email', 'phone_number', 'address'],
  FINANCIAL: ['financial', 'salary', 'compensation', 'revenue', 'profit', 'loss', 'investment', 'portfolio', 'trading'],
  BUSINESS: ['business_plan', 'strategy', 'roadmap', 'acquisition', 'merger', 'ip', 'intellectual_property', 'client_list', 'customer_data'],
  PRIVATE: ['private', 'confidential', 'sensitive', 'restricted', 'internal_only', 'kevin_private', 'personal'],
} as const;

// ============================================================================
// 1. ROLE-BASED CONTEXT FILTERING
// ============================================================================

export interface AgentRole {
  id: string;
  tier: number;
  name: string;
  department?: string;
  isExecutiveBoard?: boolean;
  capabilities?: string[];
  clearances?: string[];
}

export interface FilterConfig {
  minTier: number;           // Minimum tier to see sensitive data
  blockedCategories: string[];  // Categories to block
  redactPatterns: RegExp[];  // Patterns to redact
}

/**
 * Filter context data based on agent role/tier
 */
export function filterContextByRole(
  context: string,
  agent: AgentRole
): { filtered: string; hadSensitive: boolean; redactedItems: string[] } {
  const redactedItems: string[] = [];
  let hadSensitive = false;
  
  // Tier 0 (Kevin) has full access
  if (agent.tier === AGENT_TIERS.OWNER || agent.isExecutiveBoard) {
    return { filtered: context, hadSensitive: false, redactedItems: [] };
  }

  let filtered = context;

  // Check for sensitive patterns and redact
  const allSensitivePatterns = [
    ...SENSITIVE_CATEGORIES.PERSONAL,
    ...SENSITIVE_CATEGORIES.FINANCIAL,
    ...SENSITIVE_CATEGORIES.BUSINESS,
    ...SENSITIVE_CATEGORIES.PRIVATE,
  ];

  allSensitivePatterns.forEach((keyword) => {
    const regex = new RegExp(`\\[?${keyword}\\]?:?\\s*[\\w\\d\\.\\-_@]+`, 'gi');
    const matches = filtered.match(regex);
    if (matches) {
      matches.forEach((match) => {
        const redacted = match.replace(/[\w\d\.\-_@]+/g, '[REDACTED]');
        filtered = filtered.replace(match, redacted);
        redactedItems.push(keyword);
        hadSensitive = true;
      });
    }
  });

  // Redact specific patterns
  const personalPatterns = [
    /\b\d{3}-\d{2}-\d{4}\b/g,                    // SSN
    /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g, // Credit card
    /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, // Email
    /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,             // Phone
  ];

  personalPatterns.forEach((regex) => {
    const matches = filtered.match(regex);
    if (matches) {
      matches.forEach(() => {
        filtered = filtered.replace(regex, '[REDACTED]');
        redactedItems.push('personal_info');
        hadSensitive = true;
      });
    }
  });

  // Add classification header
  const classification = agent.tier <= 2 ? 'INTERNAL' : 'RESTRICTED';
  filtered = `[${classification} - Tier ${agent.tier}] ${filtered}`;

  return { filtered, hadSensitive, redactedItems: [...new Set(redactedItems)] };
}

/**
 * Filter agent data before sharing with other agents
 */
export function filterAgentData(
  sourceAgent: AgentRole,
  targetAgentId: string,
  agentData: Record<string, any>
): Record<string, any> {
  const filtered = { ...agentData };

  // Remove sensitive fields based on tier difference
  if (sourceAgent.tier > AGENT_TIERS.EXECUTIVE) {
    // Non-executives can't see sensitive profile data
    delete filtered.preferences;
    delete filtered.stats;
    delete filtered.voice;
  }

  // Remove personal contact info for non-board members
  if (!sourceAgent.isExecutiveBoard) {
    delete filtered.personalEmail;
    delete filtered.phone;
  }

  // Keep basic info for delegation
  return {
    id: filtered.id,
    name: filtered.name,
    title: filtered.title,
    department: filtered.department,
    capabilities: filtered.capabilities,
    tier: filtered.tier,
  };
}

// ============================================================================
// 2. ENCRYPTED MEETING TRANSCRIPT STORAGE
// ============================================================================

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;

/**
 * Encrypt sensitive meeting data
 */
export function encryptMeetingData(data: string): string {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
  
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  // Return iv:authTag:encrypted
  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
}

/**
 * Decrypt meeting data
 */
export function decryptMeetingData(encryptedData: string): string {
  try {
    const [ivHex, authTagHex, encrypted] = encryptedData.split(':');
    if (!ivHex || !authTagHex || !encrypted) {
      throw new Error('Invalid encrypted data format');
    }
    
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    
    const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    throw new Error('Failed to decrypt meeting data');
  }
}

/**
 * Store meeting with encryption
 */
export interface SecureMeeting {
  id: string;
  topic: string;
  agents: { id: string; name: string }[];
  encryptedTranscript?: string;
  transcript?: string; // Only present for authorized access
  actionItems: string[];
  createdAt: string;
  classification: 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
  minTierToView: number;
}

/**
 * Create encrypted meeting record
 */
export function createSecureMeeting(
  meeting: Omit<SecureMeeting, 'encryptedTranscript' | 'classification' | 'minTierToView'>,
  classification: 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED' = 'INTERNAL'
): SecureMeeting {
  const minTierToView = classification === 'PUBLIC' ? 6 :
    classification === 'INTERNAL' ? 4 :
    classification === 'CONFIDENTIAL' ? 2 : 0;

  // Encrypt the transcript
  const encryptedTranscript = encryptMeetingData(meeting.transcript || '');

  return {
    ...meeting,
    transcript: undefined, // Don't store plain text
    encryptedTranscript,
    classification,
    minTierToView,
  };
}

/**
 * Get decrypted transcript if authorized
 */
export function getDecryptedTranscript(
  meeting: SecureMeeting,
  requesterTier: number
): { transcript: string; authorized: boolean } {
  if (requesterTier < meeting.minTierToView) {
    return { transcript: '[ACCESS DENIED - INSUFFICIENT CLEARANCE]', authorized: false };
  }

  if (!meeting.encryptedTranscript) {
    return { transcript: meeting.transcript || '', authorized: true };
  }

  try {
    const transcript = decryptMeetingData(meeting.encryptedTranscript);
    return { transcript, authorized: true };
  } catch {
    return { transcript: '[DECRYPTION ERROR]', authorized: false };
  }
}

// ============================================================================
// 3. CAPABILITY-BASED DELEGATION LIMITS
// ============================================================================

export interface DelegationCapability {
  canDelegate: boolean;
  maxDelegationDepth: number;        // How many hops allowed
  allowedTargetTiers: number[];     // Which tier levels can be targets
  blockedCapabilities: string[];     // Can't delegate these
  requireApproval: boolean;          // Need approval for sensitive delegations
  auditLog: boolean;                 // Log all delegations
}

export const DEFAULT_DELEGATION_LIMITS: DelegationCapability = {
  canDelegate: true,
  maxDelegationDepth: 2,
  allowedTargetTiers: [0, 1, 2, 3, 4, 5, 6],
  blockedCapabilities: ['security', 'admin', 'financial', 'owner'],
  requireApproval: true,
  auditLog: true,
};

export const TIER_DELEGATION_LIMITS: Record<number, DelegationCapability> = {
  // Owner (Tier 0) - Full delegation
  0: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 5, requireApproval: false },
  
  // Executive (Tier 1)
  1: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 4, requireApproval: false },
  
  // VP (Tier 2)
  2: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 3 },
  
  // Director (Tier 3)
  3: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 2, blockedCapabilities: [...DEFAULT_DELEGATION_LIMITS.blockedCapabilities, 'strategic'] },
  
  // Manager (Tier 4)
  4: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 1, blockedCapabilities: [...DEFAULT_DELEGATION_LIMITS.blockedCapabilities, 'strategic', 'budget'] },
  
  // Senior Staff (Tier 5)
  5: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 1, allowedTargetTiers: [4, 5, 6], requireApproval: true },
  
  // Frontline (Tier 6)
  6: { ...DEFAULT_DELEGATION_LIMITS, maxDelegationDepth: 0, allowedTargetTiers: [6] },
};

/**
 * Check if delegation is allowed
 */
export function checkDelegationAllowed(
  sourceAgent: AgentRole,
  targetAgent: AgentRole,
  capability?: string
): { allowed: boolean; reason?: string; requiresApproval?: boolean } {
  const limits = TIER_DELEGATION_LIMITS[sourceAgent.tier] || DEFAULT_DELEGATION_LIMITS;

  if (!limits.canDelegate) {
    return { allowed: false, reason: 'Agent not authorized to delegate' };
  }

  // Check target tier
  if (!limits.allowedTargetTiers.includes(targetAgent.tier)) {
    return { allowed: false, reason: `Target tier ${targetAgent.tier} not in allowed list` };
  }

  // Check blocked capabilities
  if (capability && limits.blockedCapabilities.includes(capability)) {
    return { allowed: false, reason: `Capability "${capability}" is restricted from delegation` };
  }

  // Check if approval required
  if (limits.requireApproval) {
    return { allowed: true, requiresApproval: true };
  }

  return { allowed: true };
}

/**
 * Validate delegation chain to prevent exploitation
 */
export function validateDelegationChain(
  chain: AgentRole[]
): { valid: boolean; reason?: string; depth: number } {
  if (chain.length === 0) return { valid: false, reason: 'Empty chain', depth: 0 };

  const depth = chain.length - 1;
  const sourceAgent = chain[0];
  const limits = TIER_DELEGATION_LIMITS[sourceAgent.tier] || DEFAULT_DELEGATION_LIMITS;

  if (depth > limits.maxDelegationDepth) {
    return { valid: false, reason: `Delegation depth ${depth} exceeds limit of ${limits.maxDelegationDepth}`, depth };
  }

  // Check for circular delegation
  const agentIds = chain.map(a => a.id);
  if (new Set(agentIds).size !== agentIds.length) {
    return { valid: false, reason: 'Circular delegation detected', depth };
  }

  return { valid: true, depth };
}

// ============================================================================
// 4. CONSENSUS VERIFICATION AND RANDOMIZATION
// ============================================================================

export interface ConsensusVote {
  agentId: string;
  agentName: string;
  position: 'agree' | 'disagree' | 'abstain';
  reasoning: string;
  weight: number;
  timestamp: string;
}

export interface ConsensusResult {
  consensus: string;
  dissentingViews: string[];
  confidence: number;
  recommendation: string;
  votes: ConsensusVote[];
  verification: {
    isValid: boolean;
    manipulationDetected: boolean;
    outlierAgents: string[];
    randomizationApplied: boolean;
    hash: string;
  };
}

/**
 * Verify consensus votes and detect manipulation
 */
export function verifyConsensus(
  votes: ConsensusVote[],
  agentTiers: Record<string, number>
): { isValid: boolean; manipulationDetected: boolean; outlierAgents: string[] } {
  if (votes.length < 2) {
    return { isValid: false, manipulationDetected: false, outlierAgents: [] };
  }

  const agreeVotes = votes.filter(v => v.position === 'agree');
  const disagreeVotes = votes.filter(v => v.position === 'disagree');
  const abstainVotes = votes.filter(v => v.position === 'abstain');

  // Check for single agent dominance (potential manipulation)
  const totalWeight = votes.reduce((sum, v) => sum + v.weight, 0);
  const maxWeight = Math.max(...votes.map(v => v.weight));
  
  let manipulationDetected = false;
  const outlierAgents: string[] = [];

  // If one agent has >50% weight, flag as potential manipulation
  if (maxWeight > totalWeight * 0.5) {
    manipulationDetected = true;
    const dominantAgent = votes.find(v => v.weight === maxWeight);
    if (dominantAgent) outlierAgents.push(dominantAgent.agentId);
  }

  // Check for suspicious voting patterns (all agree except one)
  if (agreeVotes.length === votes.length - 1 && disagreeVotes.length === 1) {
    // Single dissenting vote might be legitimate, but verify reasoning
    const loneDissenter = disagreeVotes[0];
    if (loneDissenter.reasoning.length < 20) {
      outlierAgents.push(loneDissenter.agentId);
      manipulationDetected = true;
    }
  }

  // Check tier-weighted manipulation
  const highTierVoters = votes.filter(v => (agentTiers[v.agentId] || 6) <= 2);
  const lowTierVoters = votes.filter(v => (agentTiers[v.agentId] || 6) > 4);
  
  if (highTierVoters.length > 0 && lowTierVoters.length === 0 && disagreeVotes.length > 0) {
    // Only high-tier agents disagreed - might be excluding lower-tier input
    manipulationDetected = true;
  }

  return {
    isValid: votes.length >= 2,
    manipulationDetected,
    outlierAgents,
  };
}

/**
 * Apply randomization to prevent consensus manipulation
 */
export function applyConsensusRandomization(
  agents: { id: string; tier: number }[],
  options?: { randomizeOrder?: boolean; shuffleVoting?: boolean }
): { agents: { id: string; tier: number }[]; randomizationSeed: string } {
  const opts = { randomizeOrder: true, shuffleVoting: true, ...options };
  let randomizedAgents = [...agents];

  if (opts.randomizeOrder) {
    // Fisher-Yates shuffle
    for (let i = randomizedAgents.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [randomizedAgents[i], randomizedAgents[j]] = [randomizedAgents[j], randomizedAgents[i]];
    }
  }

  // Generate seed for verification
  const randomizationSeed = crypto.randomBytes(8).toString('hex');

  return {
    agents: randomizedAgents,
    randomizationSeed,
  };
}

/**
 * Calculate weighted consensus with manipulation resistance
 */
export function calculateWeightedConsensus(
  votes: ConsensusVote[],
  agentTiers: Record<string, number>
): { consensus: string; dissentingViews: string[]; confidence: number } {
  if (votes.length === 0) {
    return { consensus: 'No votes recorded', dissentingViews: [], confidence: 0 };
  }

  if (votes.length === 1) {
    return {
      consensus: votes[0].reasoning,
      dissentingViews: [],
      confidence: votes[0].weight * 50,
    };
  }

  // Weight by inverse tier (lower tier = higher weight)
  const weightedVotes = votes.map(v => {
    const tier = agentTiers[v.agentId] || 6;
    const tierWeight = (6 - tier + 1); // Tier 0 = 7, Tier 6 = 1
    return {
      ...v,
      adjustedWeight: v.weight * tierWeight,
    };
  });

  const totalWeight = weightedVotes.reduce((sum, v) => sum + v.adjustedWeight, 0);
  const agreeWeight = weightedVotes.filter(v => v.position === 'agree').reduce((sum, v) => sum + v.adjustedWeight, 0);
  const disagreeWeight = weightedVotes.filter(v => v.position === 'disagree').reduce((sum, v) => sum + v.adjustedWeight, 0);
  const abstainWeight = weightedVotes.filter(v => v.position === 'abstain').reduce((sum, v) => sum + v.adjustedWeight, 0);

  const agreeRatio = totalWeight > 0 ? agreeWeight / totalWeight : 0;
  const disagreeRatio = totalWeight > 0 ? disagreeWeight / totalWeight : 0;

  // Confidence based on consensus strength
  let confidence = Math.round(Math.max(agreeRatio, disagreeRatio) * 100);
  
  // Reduce confidence if high abstain rate
  const abstainRatio = totalWeight > 0 ? abstainWeight / totalWeight : 0;
  if (abstainRatio > 0.3) {
    confidence = Math.round(confidence * 0.7);
  }

  // Get dissenting reasoning
  const dissentingViews = weightedVotes
    .filter(v => v.position === 'disagree')
    .map(v => `${v.agentName}: ${v.reasoning}`);

  // Simple consensus text (in production, use LLM to synthesize)
  const consensus = agreeRatio > disagreeRatio 
    ? `Majority agreement (${Math.round(agreeRatio * 100)}%)`
    : `No consensus reached`;

  return { consensus, dissentingViews, confidence };
}

/**
 * Generate consensus result with verification
 */
export function generateVerifiedConsensus(
  votes: ConsensusVote[],
  agentTiers: Record<string, number>,
  baseConsensus: string,
  baseRecommendation: string
): ConsensusResult {
  const verification = verifyConsensus(votes, agentTiers);
  const { consensus, dissentingViews, confidence } = calculateWeightedConsensus(votes, agentTiers);

  // Create hash for verification
  const hash = crypto
    .createHash('sha256')
    .update(JSON.stringify(votes) + Date.now().toString())
    .digest('hex')
    .substring(0, 16);

  return {
    consensus: verification.manipulationDetected ? `${baseConsensus} [VERIFIED]` : baseConsensus,
    dissentingViews,
    confidence,
    recommendation: baseRecommendation,
    votes,
    verification: {
      isValid: verification.isValid,
      manipulationDetected: verification.manipulationDetected,
      outlierAgents: verification.outlierAgents,
      randomizationApplied: true,
      hash,
    },
  };
}

// ============================================================================
// AUDIT LOGGING
// ============================================================================

export interface AuditLogEntry {
  timestamp: string;
  action: 'delegate' | 'meeting' | 'consensus' | 'filter' | 'encrypt' | 'decrypt';
  sourceAgent: string;
  targetAgent?: string;
  details: string;
  sensitiveDataRedacted?: boolean;
  manipulationDetected?: boolean;
  success: boolean;
}

const auditLog: AuditLogEntry[] = [];

export function logBrainAction(entry: Omit<AuditLogEntry, 'timestamp'>): void {
  auditLog.push({
    ...entry,
    timestamp: new Date().toISOString(),
  });
  
  // Keep only last 1000 entries
  if (auditLog.length > 1000) {
    auditLog.shift();
  }
}

export function getAuditLog(limit = 100): AuditLogEntry[] {
  return auditLog.slice(-limit);
}
