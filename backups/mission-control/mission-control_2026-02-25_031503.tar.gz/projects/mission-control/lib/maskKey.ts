/**
 * Mask API keys for secure display
 * Shows only last 4 characters, hides the rest with dots
 */
export const maskApiKey = (key: string | null | undefined): string => {
  if (!key) return '';
  if (key.length <= 4) return '••••';
  return '••••' + key.slice(-4);
};

/**
 * Mask an API key showing only first and last 4 characters
 */
export const maskApiKeyFull = (key: string | null | undefined): string => {
  if (!key) return '';
  if (key.length <= 8) return '••••••••';
  return key.slice(0, 4) + '••••••••' + key.slice(-4);
};

/**
 * Check if a string looks like an API key (has alphanumeric chars, reasonable length)
 */
export const looksLikeApiKey = (value: string | null | undefined): boolean => {
  if (!value) return false;
  // API keys typically have letters, numbers, and some special chars
  // Length between 10-500 chars
  return value.length >= 10 && value.length <= 500 && /^[a-zA-Z0-9_\-./+=]+$/.test(value);
};
