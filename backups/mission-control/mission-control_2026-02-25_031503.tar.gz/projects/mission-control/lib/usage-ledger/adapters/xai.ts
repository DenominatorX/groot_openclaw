/**
 * xAI (Grok) Usage Adapter
 * 
 * xAI provides usage data via their API with the response metadata.
 * 
 * CAVEATS:
 * - xAI does not provide a programmatic usage history API
 * - Usage must be tracked at request time from response metadata
 * - Token counts provided in response usage field
 */

import { BaseProviderAdapter } from './base';
import { UsageEvent, Provider } from '../types';
import { calculateCost } from '../costs';

export class XAIAdapter extends BaseProviderAdapter {
  readonly provider: Provider = 'xai';
  readonly supportsUsageFetch = false; // No usage history API

  async fetchUsageEvents(_since?: Date): Promise<UsageEvent[]> {
    // xAI doesn't provide a usage history API
    // Usage must be tracked at request time
    console.log('[UsageLedger] xAI: No usage API available, usage tracked at request time');
    return [];
  }

  async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return false;
    }
    
    try {
      // Test with a minimal chat completion request
      const response = await fetch('https://api.x.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'grok-2',
          messages: [{ role: 'user', content: 'test' }],
          max_tokens: 1,
        }),
      });
      
      // A 400 means the model exists, just bad request
      // A 401 means auth failed
      return response.ok || response.status === 400;
    } catch {
      return false;
    }
  }

  /**
   * Create a usage event from xAI API response
   */
  static createEventFromResponse(
    model: string,
    usage: { prompt_tokens?: number; completion_tokens?: number },
    requestId?: string
  ): UsageEvent {
    const tokensIn = usage.prompt_tokens || 0;
    const tokensOut = usage.completion_tokens || 0;
    
    return {
      provider: 'xai',
      model,
      timestamp: new Date().toISOString(),
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cache_read: 0,
      cache_write: 0,
      request_id: requestId || null,
      cost_usd: calculateCost('xai', model, tokensIn, tokensOut),
      raw_payload: JSON.stringify(usage),
      source: 'request',
    };
  }
}