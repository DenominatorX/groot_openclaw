/**
 * OpenAI Usage Adapter
 *
 * Historical usage API availability depends on org-level permissions.
 * Request-time ingestion is still the primary source of truth.
 */

import { BaseProviderAdapter } from './base';
import { UsageEvent, Provider } from '../types';
import { calculateCost } from '../costs';

export class OpenAIAdapter extends BaseProviderAdapter {
  readonly provider: Provider = 'openai';
  readonly supportsUsageFetch = true;

  private async fetchFromOrgUsage(apiKey: string, since: Date, until: Date): Promise<UsageEvent[]> {
    const startTime = Math.floor(since.getTime() / 1000);
    const endTime = Math.floor(until.getTime() / 1000);

    const url = new URL('https://api.openai.com/v1/organization/usage/completions');
    url.searchParams.set('start_time', String(startTime));
    url.searchParams.set('end_time', String(endTime));

    const response = await fetch(url.toString(), {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`OpenAI org usage endpoint failed (${response.status}): ${text.slice(0, 300)}`);
    }

    const body = await response.json() as any;
    const buckets = Array.isArray(body?.data) ? body.data : [];
    const events: UsageEvent[] = [];

    for (const bucket of buckets) {
      const bucketTs = bucket?.start_time ? new Date(bucket.start_time * 1000).toISOString() : new Date().toISOString();
      const results = Array.isArray(bucket?.results) ? bucket.results : [];
      for (const item of results) {
        const model = item?.model || 'unknown';
        const tokensIn = Number(item?.input_tokens || 0);
        const tokensOut = Number(item?.output_tokens || 0);
        const requestCount = Number(item?.num_model_requests || 0);

        events.push({
          provider: 'openai',
          model,
          timestamp: bucketTs,
          tokens_in: Math.max(0, Math.floor(tokensIn)),
          tokens_out: Math.max(0, Math.floor(tokensOut)),
          cache_read: 0,
          cache_write: 0,
          request_id: item?.request_id || item?.batch || null,
          cost_usd: calculateCost('openai', model, tokensIn, tokensOut),
          raw_payload: JSON.stringify({ ...item, requestCount }),
          source: 'history_api',
        });
      }
    }

    return events;
  }

  async fetchUsageEvents(since?: Date): Promise<UsageEvent[]> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const endDate = new Date();
    const startDate = since || new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    return this.fetchFromOrgUsage(apiKey, startDate, endDate);
  }

  async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return false;
    }

    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  static createEventFromResponse(
    model: string,
    usage: { prompt_tokens?: number; completion_tokens?: number },
    requestId?: string
  ): UsageEvent {
    const tokensIn = usage.prompt_tokens || 0;
    const tokensOut = usage.completion_tokens || 0;

    return {
      provider: 'openai',
      model,
      timestamp: new Date().toISOString(),
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cache_read: 0,
      cache_write: 0,
      request_id: requestId || null,
      cost_usd: calculateCost('openai', model, tokensIn, tokensOut),
      raw_payload: JSON.stringify(usage),
      source: 'request',
    };
  }
}
