import { Provider } from '@/lib/usage-ledger/types';
import { ProviderAdapter } from './base';
import { OpenRouterAdapter } from './openrouter';
import { OpenAIAdapter } from './openai';
import { GoogleAdapter } from './google';
import { XAIAdapter } from './xai';
import { AnthropicAdapter } from './anthropic';
import { NVIDIAAdapter } from './nvidia';

export * from './base';
export { OpenRouterAdapter, OpenAIAdapter, GoogleAdapter, XAIAdapter, AnthropicAdapter, NVIDIAAdapter };

export function createProviderAdapter(provider: Provider): ProviderAdapter | null {
  switch (provider) {
    case 'openrouter': return new OpenRouterAdapter();
    case 'openai': return new OpenAIAdapter();
    case 'google': return new GoogleAdapter();
    case 'xai': return new XAIAdapter();
    case 'anthropic': return new AnthropicAdapter();
    case 'nvidia': return new NVIDIAAdapter();
    default: return null;
  }
}
