import { insertUsageEvent } from '@/lib/usage-ledger/ledger';
import { calculateCost } from '@/lib/usage-ledger/costs';
import { Provider } from '@/lib/usage-ledger/types';

function asNumber(v: any): number {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function inferProvider(model?: string, endpointUrl?: string): Provider | null {
  const m = (model || '').toLowerCase();
  const u = (endpointUrl || '').toLowerCase();

  if (u.includes('openrouter.ai')) return 'openrouter';
  if (u.includes('api.anthropic.com')) return 'anthropic';
  if (u.includes('api.openai.com')) return 'openai';
  if (u.includes('api.x.ai')) return 'xai';
  if (u.includes('generativelanguage.googleapis.com')) return 'google';
  if (u.includes('api.nvcf.nvidia.com') || u.includes('api.ngc.nvidia.com')) return 'nvidia';

  if (m.startsWith('openai/') || m.startsWith('gpt-')) return 'openai';
  if (m.startsWith('anthropic/') || m.startsWith('claude')) return 'anthropic';
  if (m.startsWith('xai/') || m.includes('grok')) return 'xai';
  if (m.startsWith('google/') || m.startsWith('gemini')) return 'google';
  if (m.startsWith('nvidia/')) return 'nvidia';
  if (m.includes('/')) return 'openrouter';

  return null;
}

function extractUsage(provider: Provider, payload: any): {
  tokensIn: number;
  tokensOut: number;
  cacheRead: number;
  cacheWrite: number;
} {
  const usage = payload?.usage || payload?.usage_metadata || payload?.usageMetadata || {};

  if (provider === 'anthropic') {
    return {
      tokensIn: asNumber(usage.input_tokens),
      tokensOut: asNumber(usage.output_tokens),
      cacheRead: asNumber(usage.cache_read_tokens),
      cacheWrite: asNumber(usage.cache_creation_tokens),
    };
  }

  if (provider === 'google') {
    return {
      tokensIn: asNumber(usage.promptTokenCount),
      tokensOut: asNumber(usage.candidatesTokenCount),
      cacheRead: asNumber(payload?.cachedContentTokenCount),
      cacheWrite: 0,
    };
  }

  if (provider === 'nvidia') {
    return {
      tokensIn: asNumber(usage.input_tokens),
      tokensOut: asNumber(usage.output_tokens),
      cacheRead: 0,
      cacheWrite: 0,
    };
  }

  // OpenAI/OpenRouter/xAI compatible shape
  const tokensIn = asNumber(usage.prompt_tokens ?? usage.input_tokens);
  const tokensOut = asNumber(usage.completion_tokens ?? usage.output_tokens);

  return {
    tokensIn,
    tokensOut,
    cacheRead: asNumber(usage.cache_read_tokens),
    cacheWrite: asNumber(usage.cache_creation_tokens),
  };
}

function extractRequestId(payload: any, headers?: Headers, explicitRequestId?: string | null): string | null {
  return (
    explicitRequestId ||
    payload?.id ||
    payload?.request_id ||
    headers?.get('x-request-id') ||
    headers?.get('request-id') ||
    null
  );
}

export function logRequestUsage(params: {
  provider?: Provider | null;
  model?: string;
  endpointUrl?: string;
  payload: any;
  headers?: Headers;
  requestId?: string | null;
  timestamp?: string;
  source?: string;
}): { inserted: boolean; provider: Provider | null; requestId: string | null } {
  const provider = params.provider || inferProvider(params.model, params.endpointUrl);
  if (!provider) {
    return { inserted: false, provider: null, requestId: null };
  }

  const model = params.model || params.payload?.model || 'unknown';
  const requestId = extractRequestId(params.payload, params.headers, params.requestId);
  const { tokensIn, tokensOut, cacheRead, cacheWrite } = extractUsage(provider, params.payload);

  // If provider returned explicit cost, use it; otherwise compute from pricing tables
  const explicitCost = Number(
    params.payload?.cost_usd ??
    params.payload?.cost ??
    params.payload?.usage?.cost ??
    NaN
  );

  const costUsd = Number.isFinite(explicitCost) && explicitCost >= 0
    ? explicitCost
    : calculateCost(provider, model, tokensIn, tokensOut, cacheRead, cacheWrite);

  const rowId = insertUsageEvent({
    provider,
    model,
    timestamp: params.timestamp || new Date().toISOString(),
    tokens_in: tokensIn,
    tokens_out: tokensOut,
    cache_read: cacheRead,
    cache_write: cacheWrite,
    request_id: requestId,
    cost_usd: costUsd,
    raw_payload: JSON.stringify(params.payload || {}),
    source: params.source || 'request',
  });

  return {
    inserted: rowId > 0,
    provider,
    requestId,
  };
}
