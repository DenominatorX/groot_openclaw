/**
 * Cost calculation utilities for Unified Usage Ledger
 * Provides consistent cost computation even when providers return partial fields
 */

import { Provider, ProviderCostConfig } from './types';

// Default cost configs (USD per 1M tokens)
export const DEFAULT_COST_CONFIGS: Record<Provider, ProviderCostConfig> = {
  openrouter: {
    inputCostPerMToken: 0.0,  // Variable by model, we'll estimate from raw payload
    outputCostPerMToken: 0.0,
  },
  openai: {
    inputCostPerMToken: 2.50,  // gpt-4o default
    outputCostPerMToken: 10.00,
  },
  google: {
    inputCostPerMToken: 1.25,  // gemini-1.5-pro default
    outputCostPerMToken: 5.00,
  },
  xai: {
    inputCostPerMToken: 5.00,  // grok-2 default
    outputCostPerMToken: 15.00,
  },
  anthropic: {
    inputCostPerMToken: 3.00,  // claude-3-5-sonnet default
    outputCostPerMToken: 15.00,
    cacheReadDiscount: 0.10,   // 90% discount for cache reads
    cacheWriteDiscount: 0.10,  // 90% discount for cache writes
  },
  nvidia: {
    inputCostPerMToken: 0.0,  // GPU access pricing varies
    outputCostPerMToken: 0.0,
  },
};

// Model-specific overrides (most common models)
export const MODEL_COST_OVERRIDES: Record<string, ProviderCostConfig> = {
  // OpenAI
  'gpt-4o': { inputCostPerMToken: 2.50, outputCostPerMToken: 10.00 },
  'gpt-4o-mini': { inputCostPerMToken: 0.15, outputCostPerMToken: 0.60 },
  'gpt-4-turbo': { inputCostPerMToken: 10.00, outputCostPerMToken: 30.00 },
  'gpt-4': { inputCostPerMToken: 30.00, outputCostPerMToken: 60.00 },
  'gpt-3.5-turbo': { inputCostPerMToken: 0.50, outputCostPerMToken: 1.50 },
  
  // Anthropic
  'claude-3-5-sonnet': { inputCostPerMToken: 3.00, outputCostPerMToken: 15.00, cacheReadDiscount: 0.10, cacheWriteDiscount: 0.10 },
  'claude-3-opus': { inputCostPerMToken: 15.00, outputCostPerMToken: 75.00, cacheReadDiscount: 0.10, cacheWriteDiscount: 0.10 },
  'claude-3-sonnet': { inputCostPerMToken: 3.00, outputCostPerMToken: 15.00, cacheReadDiscount: 0.10, cacheWriteDiscount: 0.10 },
  'claude-3-haiku': { inputCostPerMToken: 0.25, outputCostPerMToken: 1.25, cacheReadDiscount: 0.10, cacheWriteDiscount: 0.10 },
  
  // Google
  'gemini-1.5-pro': { inputCostPerMToken: 1.25, outputCostPerMToken: 5.00 },
  'gemini-1.5-flash': { inputCostPerMToken: 0.075, outputCostPerMToken: 0.30 },
  'gemini-1.5-flash-8b': { inputCostPerMToken: 0.0375, outputCostPerMToken: 0.15 },
  'gemini-pro': { inputCostPerMToken: 1.00, outputCostPerMToken: 4.00 },
  
  // xAI
  'grok-2': { inputCostPerMToken: 5.00, outputCostPerMToken: 15.00 },
  'grok-2-vision': { inputCostPerMToken: 5.00, outputCostPerMToken: 15.00 },
  'grok-beta': { inputCostPerMToken: 10.00, outputCostPerMToken: 20.00 },
  
  // OpenRouter (varies by underlying model)
  'openrouter/anthropic/claude-3.5-sonnet': { inputCostPerMToken: 3.00, outputCostPerMToken: 15.00 },
  'openrouter/google/gemini-pro-1.5': { inputCostPerMToken: 1.25, outputCostPerMToken: 5.00 },
  'openrouter/openai/gpt-4o': { inputCostPerMToken: 2.50, outputCostPerMToken: 10.00 },
  
  // NVIDIA (placeholder - actual pricing requires API)
  'nvidia/nemotron': { inputCostPerMToken: 1.00, outputCostPerMToken: 4.00 },
};

export function getCostConfig(provider: Provider, model?: string): ProviderCostConfig {
  if (!model) {
    return DEFAULT_COST_CONFIGS[provider];
  }
  
  // Check for exact model match
  if (MODEL_COST_OVERRIDES[model]) {
    return MODEL_COST_OVERRIDES[model];
  }
  
  // Check for provider-prefixed model
  const prefixedModel = `${provider}/${model}`;
  if (MODEL_COST_OVERRIDES[prefixedModel]) {
    return MODEL_COST_OVERRIDES[prefixedModel];
  }
  
  // Check if model contains known model name
  for (const [key, config] of Object.entries(MODEL_COST_OVERRIDES)) {
    if (model.toLowerCase().includes(key.toLowerCase()) || 
        key.toLowerCase().includes(model.toLowerCase())) {
      return config;
    }
  }
  
  // Fall back to provider default
  return DEFAULT_COST_CONFIGS[provider];
}

export function calculateCost(
  provider: Provider,
  model: string | undefined,
  tokensIn: number,
  tokensOut: number,
  cacheRead: number = 0,
  cacheWrite: number = 0
): number {
  const config = getCostConfig(provider, model);
  
  const inputCost = (tokensIn / 1_000_000) * config.inputCostPerMToken;
  const outputCost = (tokensOut / 1_000_000) * config.outputCostPerMToken;
  
  let cacheCost = 0;
  if (config.cacheReadDiscount !== undefined) {
    const effectiveCacheReadCost = config.inputCostPerMToken * config.cacheReadDiscount;
    cacheCost += (cacheRead / 1_000_000) * effectiveCacheReadCost;
  }
  if (config.cacheWriteDiscount !== undefined) {
    const effectiveCacheWriteCost = config.inputCostPerMToken * config.cacheWriteDiscount;
    cacheCost += (cacheWrite / 1_000_000) * effectiveCacheWriteCost;
  }
  
  return inputCost + outputCost + cacheCost;
}