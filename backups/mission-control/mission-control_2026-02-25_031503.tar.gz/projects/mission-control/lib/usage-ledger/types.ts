/**
 * Types for Unified Usage Ledger
 */

export type Provider = 'openrouter' | 'openai' | 'google' | 'xai' | 'anthropic' | 'nvidia';

export interface UsageEvent {
  id?: number;
  provider: Provider;
  model: string;
  timestamp: string;
  tokens_in: number;
  tokens_out: number;
  cache_read: number;
  cache_write: number;
  request_id: string | null;
  cost_usd: number;
  raw_payload: string | null;
  source: string;
  synced_at?: string;
}

export type SyncState =
  | 'success_with_records'
  | 'success_no_history_api'
  | 'success_zero_records'
  | 'failed'
  | 'running'
  | null;

export interface SyncStatus {
  provider: Provider;
  last_sync_at: string | null;
  last_sync_status: SyncState;
  last_sync_error: string | null;
  records_synced: number;
}

export interface AggregatedMetrics {
  total_cost_usd: number;
  total_tokens_in: number;
  total_tokens_out: number;
  total_requests: number;
  total_cache_read: number;
  total_cache_write: number;
  by_provider: Record<Provider, {
    cost_usd: number;
    tokens_in: number;
    tokens_out: number;
    requests: number;
  }>;
  by_model: Record<string, {
    cost_usd: number;
    tokens_in: number;
    tokens_out: number;
    requests: number;
  }>;
}

export interface UsageQueryFilter {
  provider?: Provider;
  model?: string;
  startDate?: string;
  endDate?: string;
  limit?: number;
  offset?: number;
}

export interface ProviderCostConfig {
  inputCostPerMToken: number;
  outputCostPerMToken: number;
  cacheReadDiscount?: number;
  cacheWriteDiscount?: number;
}