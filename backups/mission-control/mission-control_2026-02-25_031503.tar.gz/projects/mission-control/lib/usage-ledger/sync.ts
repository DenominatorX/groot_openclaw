import { createProviderAdapter } from '@/lib/usage-ledger/adapters';
import { getSyncStatus, insertUsageEvents, updateSyncStatus } from '@/lib/usage-ledger/ledger';
import { Provider, SyncState } from '@/lib/usage-ledger/types';
import { getSetting } from '@/lib/db-helpers';

const PROVIDERS: Provider[] = ['openrouter', 'openai', 'google', 'xai', 'anthropic', 'nvidia'];

export interface SyncOptions {
  provider?: Provider;
  since?: string;
  force?: boolean;
}

export interface SyncResult {
  provider: Provider;
  status: Exclude<SyncState, null | 'running'>;
  recordsSynced: number;
  fetchedRecords?: number;
  error?: string;
}

const NO_HISTORY_API_REASON: Record<Provider, string> = {
  openrouter: 'Provider does not expose a historical usage API; request-time ingestion is the source of truth.',
  openai: '',
  google: 'Provider endpoint in this integration has no historical usage API; request-time ingestion is the source of truth.',
  xai: 'Provider does not expose a historical usage API; request-time ingestion is the source of truth.',
  anthropic: 'Provider does not expose a historical usage API; request-time ingestion is the source of truth.',
  nvidia: 'No stable programmatic historical usage API for this integration; request-time ingestion is the source of truth.',
};

function getSinceDate(provider: Provider, explicitSince?: string): Date | undefined {
  if (explicitSince) {
    const date = new Date(explicitSince);
    return Number.isNaN(date.getTime()) ? undefined : date;
  }

  const status = getSyncStatus(provider) as any;
  if (status?.last_sync_at) {
    const d = new Date(status.last_sync_at);
    if (!Number.isNaN(d.getTime())) return d;
  }

  const cfg = getSetting<{ defaultLookbackHours?: number }>('usageLedgerConfig');
  const lookback = Math.max(1, Math.min(24 * 30, Number(cfg?.defaultLookbackHours || 24)));
  return new Date(Date.now() - lookback * 60 * 60 * 1000);
}

function persistStatus(provider: Provider, state: SyncState, recordsSynced: number, error: string | null = null): void {
  updateSyncStatus({
    provider,
    last_sync_at: new Date().toISOString(),
    last_sync_status: state,
    last_sync_error: error,
    records_synced: recordsSynced,
  });
}

export async function syncProviderUsage(provider: Provider, options: SyncOptions = {}): Promise<SyncResult> {
  const adapter = createProviderAdapter(provider);
  if (!adapter) {
    return { provider, status: 'failed', recordsSynced: 0, error: 'Unknown provider' };
  }

  if (!adapter.supportsUsageFetch) {
    const reason = NO_HISTORY_API_REASON[provider] || 'No history API available for this provider';
    persistStatus(provider, 'success_no_history_api', 0, reason);
    return { provider, status: 'success_no_history_api', recordsSynced: 0, error: reason };
  }

  const since = getSinceDate(provider, options.since);
  persistStatus(provider, 'running', 0, null);

  try {
    const events = await adapter.fetchUsageEvents(since);
    const inserted = insertUsageEvents(events);

    if (inserted > 0) {
      persistStatus(provider, 'success_with_records', inserted, null);
      return { provider, status: 'success_with_records', recordsSynced: inserted, fetchedRecords: events.length };
    }

    persistStatus(provider, 'success_zero_records', 0, null);
    return { provider, status: 'success_zero_records', recordsSynced: 0, fetchedRecords: events.length };
  } catch (error: any) {
    const message = error?.message || 'Unknown error';
    persistStatus(provider, 'failed', 0, message);

    return {
      provider,
      status: 'failed',
      recordsSynced: 0,
      error: message,
    };
  }
}

export async function syncUsage(options: SyncOptions = {}): Promise<SyncResult[]> {
  if (options.provider) {
    const single = await syncProviderUsage(options.provider, options);
    return [single];
  }

  const results: SyncResult[] = [];
  for (const provider of PROVIDERS) {
    // Sequential by design to avoid rate-limit spikes.
    // eslint-disable-next-line no-await-in-loop
    const result = await syncProviderUsage(provider, options);
    results.push(result);
  }
  return results;
}
