/**
 * Migration 002: User Isolation
 *
 * - Adds user_id to tables that don't have it yet (tasks)
 * - Creates tables for reports, tests, risks, teams if missing (with user_id)
 * - Ensures indexes on all user_id columns
 * - Migrates Kevin's existing data (sets user_id where NULL)
 *
 * Kevin's user id: 7904b809-5e4b-4018-9d1b-998305e58678
 */

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const KEVIN_ID = '7904b809-5e4b-4018-9d1b-998305e58678';
const DB_PATH = path.join(process.cwd(), 'data', 'mission-control.db');

function run() {
  if (!fs.existsSync(DB_PATH)) {
    console.error(`[002-user-isolation] DB not found at ${DB_PATH}`);
    process.exit(1);
  }

  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = OFF'); // Disable FK checks during migration

  console.log('[002-user-isolation] Starting migration...');

  const runStep = (label: string, sql: string) => {
    try {
      db.exec(sql);
      console.log(`  ✓ ${label}`);
    } catch (e: any) {
      // SQLite doesn't support IF NOT EXISTS on ALTER TABLE — handle gracefully
      if (e.message?.includes('duplicate column name')) {
        console.log(`  – ${label} (column already exists, skipping)`);
      } else {
        console.error(`  ✗ ${label}: ${e.message}`);
        throw e;
      }
    }
  };

  // ── 1. projects (already has user_id — just ensure index + migrate) ───────
  runStep(
    'projects: ADD COLUMN user_id',
    `ALTER TABLE projects ADD COLUMN user_id TEXT REFERENCES users(id)`
  );
  runStep(
    'projects: CREATE INDEX idx_projects_user_id',
    `CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id)`
  );

  // ── 2. agents (already has user_id — just ensure index + migrate) ─────────
  runStep(
    'agents: ADD COLUMN user_id',
    `ALTER TABLE agents ADD COLUMN user_id TEXT REFERENCES users(id)`
  );
  runStep(
    'agents: CREATE INDEX idx_agents_user_id',
    `CREATE INDEX IF NOT EXISTS idx_agents_user_id ON agents(user_id)`
  );

  // ── 3. issues (already has user_id — just ensure index + migrate) ─────────
  runStep(
    'issues: ADD COLUMN user_id',
    `ALTER TABLE issues ADD COLUMN user_id TEXT REFERENCES users(id)`
  );
  runStep(
    'issues: CREATE INDEX idx_issues_user_id',
    `CREATE INDEX IF NOT EXISTS idx_issues_user_id ON issues(user_id)`
  );

  // ── 4. tasks (MISSING user_id — add it) ───────────────────────────────────
  runStep(
    'tasks: ADD COLUMN user_id',
    `ALTER TABLE tasks ADD COLUMN user_id TEXT REFERENCES users(id)`
  );
  runStep(
    'tasks: CREATE INDEX idx_tasks_user_id',
    `CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id)`
  );

  // ── 5. reports (create table if not exists, with user_id) ─────────────────
  runStep(
    'reports: CREATE TABLE IF NOT EXISTS',
    `CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      user_id TEXT REFERENCES users(id)
    )`
  );
  runStep(
    'reports: CREATE INDEX idx_reports_user_id',
    `CREATE INDEX IF NOT EXISTS idx_reports_user_id ON reports(user_id)`
  );

  // ── 6. tests (create table if not exists, with user_id) ───────────────────
  runStep(
    'tests: CREATE TABLE IF NOT EXISTS',
    `CREATE TABLE IF NOT EXISTS tests (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      project_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      user_id TEXT REFERENCES users(id)
    )`
  );
  runStep(
    'tests: CREATE INDEX idx_tests_user_id',
    `CREATE INDEX IF NOT EXISTS idx_tests_user_id ON tests(user_id)`
  );

  // ── 7. risks (create table if not exists, with user_id) ───────────────────
  runStep(
    'risks: CREATE TABLE IF NOT EXISTS',
    `CREATE TABLE IF NOT EXISTS risks (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      project_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      user_id TEXT REFERENCES users(id)
    )`
  );
  runStep(
    'risks: CREATE INDEX idx_risks_user_id',
    `CREATE INDEX IF NOT EXISTS idx_risks_user_id ON risks(user_id)`
  );

  // ── 8. teams (create table if not exists, with user_id) ───────────────────
  runStep(
    'teams: CREATE TABLE IF NOT EXISTS',
    `CREATE TABLE IF NOT EXISTS teams (
      id TEXT PRIMARY KEY,
      data JSON NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      user_id TEXT REFERENCES users(id)
    )`
  );
  runStep(
    'teams: CREATE INDEX idx_teams_user_id',
    `CREATE INDEX IF NOT EXISTS idx_teams_user_id ON teams(user_id)`
  );

  // ── 9. Migrate Kevin's existing data ──────────────────────────────────────
  console.log('\n[002-user-isolation] Migrating Kevin\'s existing data...');

  const tables = ['projects', 'agents', 'issues', 'tasks', 'reports', 'tests', 'risks', 'teams'];
  for (const table of tables) {
    try {
      const result = db.prepare(
        `UPDATE ${table} SET user_id = ? WHERE user_id IS NULL`
      ).run(KEVIN_ID);
      console.log(`  ✓ ${table}: ${result.changes} rows assigned to Kevin`);
    } catch (e: any) {
      console.error(`  ✗ ${table}: ${e.message}`);
    }
  }

  // ── 10. Verify ─────────────────────────────────────────────────────────────
  console.log('\n[002-user-isolation] Verification:');
  for (const table of tables) {
    try {
      const total = (db.prepare(`SELECT COUNT(*) as n FROM ${table}`).get() as any).n;
      const kevinRows = (db.prepare(`SELECT COUNT(*) as n FROM ${table} WHERE user_id = ?`).get(KEVIN_ID) as any).n;
      const nullRows = (db.prepare(`SELECT COUNT(*) as n FROM ${table} WHERE user_id IS NULL`).get() as any).n;
      console.log(`  ${table}: total=${total}, kevin=${kevinRows}, null=${nullRows}`);
    } catch (e: any) {
      console.error(`  ${table}: ${e.message}`);
    }
  }

  db.pragma('foreign_keys = ON');
  db.close();
  console.log('\n[002-user-isolation] Migration complete ✓');
}

run();
