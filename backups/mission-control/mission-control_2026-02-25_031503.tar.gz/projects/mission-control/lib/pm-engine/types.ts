/**
 * PM Engine Types
 * Core types for the visual PM lifecycle manager (MC-00044)
 */

// ==================== DAG Types ====================

export interface DAGNode {
  id: string;
  name: string;
  type: 'plan' | 'build' | 'qa' | 'deploy' | 'hotfix' | 'custom';
  /** Position in visual editor */
  position: { x: number; y: number };
  /** Agent assigned to this node */
  agentId?: string;
  /** Model override for this node */
  model?: string;
  /** Timeout in minutes */
  timeoutMin?: number;
  /** Retries on failure */
  retries?: number;
  /** Whether this node requires human approval before proceeding */
  approvalRequired?: boolean;
  /** Node-specific config */
  config?: Record<string, unknown>;
  /** Node status at runtime */
  status?: 'pending' | 'running' | 'success' | 'failed' | 'skipped' | 'paused';
}

export interface DAGEdge {
  id: string;
  source: string;
  target: string;
  /** Condition for branching (e.g., "if build fails → hotfix") */
  condition?: string;
  /** Edge label */
  label?: string;
}

export interface DAGDefinition {
  nodes: DAGNode[];
  edges: DAGEdge[];
  version: string;
}

// ==================== Slider Controls ====================

export interface SliderControls {
  /** 0-100: Manual gates vs full-auto */
  automationPercent: number;
  /** 0-100: 0=cheap/slow (Haiku), 100=expensive/fast (Opus) */
  costSpeedBalance: number;
  /** Per-phase weights: 0=skip, 1=normal, 2=emphasize */
  phaseWeights: Record<string, number>;
  /** Selected agent pool */
  agentPool: string[];
}

export const DEFAULT_SLIDER_CONTROLS: SliderControls = {
  automationPercent: 50,
  costSpeedBalance: 50,
  phaseWeights: {
    plan: 1,
    build: 1,
    qa: 1,
    deploy: 1,
  },
  agentPool: ['minimax/minimax-m2.5', 'xai/grok-4-1-fast-reasoning'],
};

// ==================== Templates ====================

export interface PMTemplate {
  id: string;
  name: string;
  description: string;
  category: 'web-app' | 'api' | 'data-pipeline' | 'custom';
  dag: DAGDefinition;
  sliders: SliderControls;
  /** Is this a built-in or user-created template */
  builtIn: boolean;
  createdAt: string;
  updatedAt: string;
}

// ==================== Marketplace ====================

export interface MarketplaceAgent {
  id: string;
  agentId: string;
  name: string;
  description: string;
  specialty: string;
  /** Default model for this agent */
  defaultModel: string;
  /** Recommended weight allocation (0-100%) */
  recommendedWeight: number;
  /** Tags for search/filter */
  tags: string[];
  /** Usage count */
  usageCount: number;
  /** Average rating */
  rating: number;
  /** Is this a built-in agent */
  builtIn: boolean;
}

// ==================== Stripe / Tiers ====================

export type SubscriptionTier = 'free' | 'pro' | 'elite';

export interface TierConfig {
  tier: SubscriptionTier;
  maxProjects: number;
  maxAgentsPerProject: number;
  slidersEnabled: boolean;
  customAgents: boolean;
  priorityCompute: boolean;
  humanAssist: boolean;
  allowedModels: string[];
  monthlyTokenQuota: number;
}

export const TIER_CONFIGS: Record<SubscriptionTier, TierConfig> = {
  free: {
    tier: 'free',
    maxProjects: 3,
    maxAgentsPerProject: 3,
    slidersEnabled: false,
    customAgents: false,
    priorityCompute: false,
    humanAssist: false,
    allowedModels: ['minimax/minimax-m2.5'],
    monthlyTokenQuota: 100_000,
  },
  pro: {
    tier: 'pro',
    maxProjects: 10,
    maxAgentsPerProject: 8,
    slidersEnabled: true,
    customAgents: false,
    priorityCompute: false,
    humanAssist: false,
    allowedModels: [
      'minimax/minimax-m2.5',
      'xai/grok-4-1-fast-reasoning',
      'anthropic/claude-3.5-sonnet',
    ],
    monthlyTokenQuota: 1_000_000,
  },
  elite: {
    tier: 'elite',
    maxProjects: -1, // unlimited
    maxAgentsPerProject: -1,
    slidersEnabled: true,
    customAgents: true,
    priorityCompute: true,
    humanAssist: true,
    allowedModels: [
      'minimax/minimax-m2.5',
      'xai/grok-4-1-fast-reasoning',
      'anthropic/claude-3.5-sonnet',
      'anthropic/claude-3-opus',
    ],
    monthlyTokenQuota: 10_000_000,
  },
};

// ==================== PM Run ====================

export interface PMRunRequest {
  projectId: string;
  dag: DAGDefinition;
  sliders: SliderControls;
  templateId?: string;
  /** Dry run = validate + estimate only */
  dryRun?: boolean;
}

export interface PMRunResponse {
  runId: string;
  projectId: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'paused';
  protocolOverride: Record<string, unknown>;
  estimatedCost?: number;
  estimatedTimeMin?: number;
  startedAt?: string;
  completedAt?: string;
  nodeStatuses: Record<string, DAGNode['status']>;
  logs: string[];
}
