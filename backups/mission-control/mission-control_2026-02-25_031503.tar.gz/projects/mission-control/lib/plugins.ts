import { getDb } from './database';

// ── Types ──────────────────────────────────────────────────────────

export interface PluginManifest {
  id: string;
  name: string;
  version: string;
  description: string;
  author?: string;
  category: 'app' | 'integration' | 'theme' | 'analytics';
  icon?: string;

  routes?: string[];
  components?: string[];
  settings?: PluginSetting[];
  permissions?: string[];

  requires?: { plugin: string; version: string }[];
  openclawMinVersion?: string;
}

export interface PluginSetting {
  key: string;
  label: string;
  type: 'string' | 'boolean' | 'number' | 'select' | 'secret';
  default?: any;
  options?: { value: string; label: string }[];
  required?: boolean;
}

export interface PluginRecord {
  id: string;
  manifest: PluginManifest;
  enabled: boolean;
  config: Record<string, any>;
  installed_at: string;
  updated_at: string;
}

// ── Schema ─────────────────────────────────────────────────────────

export function ensurePluginsTable(): void {
  const db = getDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS plugins (
      id TEXT PRIMARY KEY,
      manifest JSON NOT NULL,
      enabled INTEGER DEFAULT 1,
      config JSON DEFAULT '{}',
      installed_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);
}

// ── Queries ────────────────────────────────────────────────────────

function parseRow(row: any): PluginRecord {
  return {
    id: row.id,
    manifest: typeof row.manifest === 'string' ? JSON.parse(row.manifest) : row.manifest,
    enabled: row.enabled === 1,
    config: typeof row.config === 'string' ? JSON.parse(row.config) : row.config,
    installed_at: row.installed_at,
    updated_at: row.updated_at,
  };
}

export function getInstalledPlugins(): PluginRecord[] {
  ensurePluginsTable();
  const db = getDb();
  const rows = db.prepare('SELECT * FROM plugins ORDER BY id').all();
  return rows.map(parseRow);
}

export function getPlugin(id: string): PluginRecord | null {
  ensurePluginsTable();
  const db = getDb();
  const row = db.prepare('SELECT * FROM plugins WHERE id = ?').get(id);
  return row ? parseRow(row) : null;
}

export function installPlugin(manifest: PluginManifest, enabled = true): PluginRecord {
  ensurePluginsTable();
  const db = getDb();
  db.prepare(`
    INSERT INTO plugins (id, manifest, enabled, config)
    VALUES (?, ?, ?, '{}')
    ON CONFLICT(id) DO UPDATE SET
      manifest = excluded.manifest,
      updated_at = datetime('now')
  `).run(manifest.id, JSON.stringify(manifest), enabled ? 1 : 0);
  return getPlugin(manifest.id)!;
}

export function enablePlugin(id: string): boolean {
  ensurePluginsTable();
  const db = getDb();
  const result = db.prepare(
    "UPDATE plugins SET enabled = 1, updated_at = datetime('now') WHERE id = ?"
  ).run(id);
  return result.changes > 0;
}

export function disablePlugin(id: string): boolean {
  ensurePluginsTable();
  const db = getDb();
  const result = db.prepare(
    "UPDATE plugins SET enabled = 0, updated_at = datetime('now') WHERE id = ?"
  ).run(id);
  return result.changes > 0;
}

export function uninstallPlugin(id: string): boolean {
  ensurePluginsTable();
  const db = getDb();
  const result = db.prepare('DELETE FROM plugins WHERE id = ?').run(id);
  return result.changes > 0;
}

export function isPluginEnabled(id: string): boolean {
  ensurePluginsTable();
  const db = getDb();
  const row: any = db.prepare('SELECT enabled FROM plugins WHERE id = ?').get(id);
  return row?.enabled === 1;
}

export function getPluginConfig(id: string): Record<string, any> {
  const plugin = getPlugin(id);
  return plugin?.config ?? {};
}

export function savePluginConfig(id: string, config: Record<string, any>): boolean {
  ensurePluginsTable();
  const db = getDb();
  const result = db.prepare(
    "UPDATE plugins SET config = ?, updated_at = datetime('now') WHERE id = ?"
  ).run(JSON.stringify(config), id);
  return result.changes > 0;
}
