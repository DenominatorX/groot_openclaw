import fs from 'fs';
import path from 'path';

const ACTIVITY_PATH = path.join(process.cwd(), 'data', 'activity.json');
const MAX_ENTRIES = 200;

/**
 * Log an activity entry server-side (call from API routes or server actions)
 */
export function logActivity(agent: string, action: string, details?: string) {
  try {
    let data = { entries: [] as any[] };
    try {
      data = JSON.parse(fs.readFileSync(ACTIVITY_PATH, 'utf8'));
    } catch {}

    data.entries.push({
      id: Date.now().toString(),
      agent,
      action,
      details: details || '',
      timestamp: new Date().toISOString(),
    });

    if (data.entries.length > MAX_ENTRIES) {
      data.entries = data.entries.slice(-MAX_ENTRIES);
    }

    fs.writeFileSync(ACTIVITY_PATH, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('[Activity Log Error]', e);
  }
}
