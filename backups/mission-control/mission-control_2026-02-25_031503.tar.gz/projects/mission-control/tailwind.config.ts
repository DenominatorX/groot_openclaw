import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        mc: {
          bg: 'var(--mc-bg)',
          surface: 'var(--mc-surface)',
          border: 'var(--mc-border)',
          text: 'var(--mc-text)',
          muted: 'var(--mc-muted)',
          accent: 'var(--mc-accent)',
          success: '#22c55e',
          warning: '#f59e0b',
          danger: '#ef4444',
          info: '#3b82f6',
        }
      }
    },
  },
  plugins: [],
}
export default config
