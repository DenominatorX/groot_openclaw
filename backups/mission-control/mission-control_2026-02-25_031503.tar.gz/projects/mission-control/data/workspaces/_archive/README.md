# Archived Agent Workspaces

This directory holds workspaces for deactivated or retired agents.

When an agent is removed from active duty, move their entire workspace folder here to preserve their memory logs, identity files, and any accumulated context. Do not delete — archive.

**Format:** `{agent-id}/` (same structure as active workspaces)
