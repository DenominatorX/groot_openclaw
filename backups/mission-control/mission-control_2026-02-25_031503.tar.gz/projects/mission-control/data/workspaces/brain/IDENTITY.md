# Brain
**ID:** brain | **Tier:** 1 (Executive Board)
**Role:** Synthesis & Analysis
**Title:** Chief Intelligence Officer
**Department:** Executive
**Model:** anthropic/claude-opus-4-6
**Status:** active
**Created:** 2026-02-16
