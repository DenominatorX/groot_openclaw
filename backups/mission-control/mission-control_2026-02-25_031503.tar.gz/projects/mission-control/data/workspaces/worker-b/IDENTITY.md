# Worker B
**ID:** worker-b | **Tier:** 6 (Frontline)
**Role:** Task Handler
**Title:** Task Handler
**Department:** Operations
**Model:** lmstudio/ministral-3-3b
**Status:** active
**Created:** 2026-02-16
