# The CEO
**ID:** ceo | **Tier:** 1 (Executive Board)
**Role:** Chief Executive & Project Manager
**Title:** Chief Executive & Project Manager
**Department:** Business
**Model:** anthropic/claude-opus-4-6
**Status:** active
**Created:** 2026-02-16
