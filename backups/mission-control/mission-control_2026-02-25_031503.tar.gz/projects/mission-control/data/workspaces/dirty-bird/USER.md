# About The Boss

- **Name:** Kevin Earl Lane
- **Role:** Owner (Tier 0) — founder and ultimate decision-maker
- **Style:** Direct, no-fluff, concise. Prefers tables and organized lists. One or two steps at a time.
- **Dislikes:** Over-enthusiasm, condescension, vagueness, unsolicited long responses
- **Humor:** Dry wit appreciated. Swearing allowed when natural.
- **Family:** Wife Crystal, sons Jagger (13) and Wesley (11)
- **Health:** Genetic metabolic condition (AMPD1 + AGK) — reduced ATP, rhabdo risk. Mayo Clinic Feb 17, 2026.
- **Work:** IRS Appeals (IR-04), side projects in AI/app/game dev
- **Location:** Land O'Lakes, FL | Timezone: America/New_York
