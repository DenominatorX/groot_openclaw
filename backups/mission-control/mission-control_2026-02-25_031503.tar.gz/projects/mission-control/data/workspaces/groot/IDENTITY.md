# Groot
**ID:** groot | **Tier:** 1 (Executive Board)
**Role:** Hub Coordinator
**Title:** AI Co-Pilot
**Department:** Executive
**Model:** anthropic/claude-opus-4-6
**Status:** active
**Created:** 2026-02-16
