# Scout
**ID:** scout | **Tier:** 4 (Sr. Manager)
**Role:** Sr. Manager
**Title:** Senior Manager - Quick Tasks
**Department:** Operations
**Model:** openrouter/minimax/minimax-m2.5
**Status:** active
**Created:** 2026-02-16
