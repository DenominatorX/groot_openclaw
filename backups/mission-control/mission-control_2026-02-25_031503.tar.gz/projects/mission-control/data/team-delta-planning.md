# Team Delta — Project Planning Session

**Date:** 2026-02-13 04:22 AM EST  
**Duration:** 62 minutes  
**Attendees:** Tank (ideation), Dirty Bird (legal/strategy), Floof (creative director), The Interrogator (market analyst)  
**Status:** ✅ Approved for development sprint

---

## 🎯 Ideation Phase — Tank Pitches the Vision

**Tank:** "Alright team, I've been synthesizing user behavior patterns across MC and competitive games. Here's what I see: users crave two things that nobody's nailing together—*intellectual challenge* and *personal growth*.

**Concept 1 — Debate Arena**
A competitive debate game where AI judges your persuasion skills. Think: courtroom drama meets gaming. Players pick topics (Pop Culture, Tech, Philosophy, Sports, Food, History, Hypotheticals, Business), choose a side, and debate against AI opponents of escalating difficulty (Pushover → Philosopher King). 

Each round: 60-second opening, 45-second rebuttal, 30-second closing. AI scores you on Logic (25%), Evidence (25%), Persuasion (25%), Style (25%). Rank system: Rookie → Debater → Orator → Senator → Supreme Court Justice.

Four game modes: Solo Practice, Quick Debate (60-sec arguments), Tournament (4 rounds escalating difficulty), Devil's Advocate (AI assigns the *unpopular* side, bonus for winning).

Revenue: Premium difficulty tiers, competitive leagues with entry fees, debate coach personas (AI), topic packs. Could easily hit $20-50 ARPU if we build leagues right.

**Concept 2 — Habit Forge**
A gamified habit-tracking app with AI coaching that feels *personal*, not preachy. Problem: Most habit apps are clunky Sisyphean loops. We make it feel like leveling up.

Core: You add habits (name, category: health/fitness/productivity/learning/mindfulness/social/financial), set frequency, difficulty (easy/medium/hard). Daily check-in—toggle done, add notes, rate your day 1-5. You earn XP: easy=10, medium=25, hard=50. Level up every 500 XP. Titles: Novice → Grandmaster.

Visual rewards: Streak counters (🔥 at 7+, 👑 at 30+), calendar heatmap showing completion %, weekly/monthly burndown.

AI Coach provides:
- Daily Motivation: Personalized pep talk based on *your* streaks and goals
- Habit Suggestions: AI recommends next habit to stack (e.g., "After morning run, meditate?")
- Weekly Review: AI analyzes your week, pinpoints what stuck, what failed, actionable advice
- Accountability Check: AI *challenges* you on missed habits (firm but empathetic)

Revenue: Premium AI coaching ($6.99/mo), team accountability groups (social leaderboards), custom challenge packs.

Both projects address deeper needs: *mastery* (Debate) and *self-improvement* (Habit). Both have strong AI integration, competitive/social hooks, and clear monetization paths. Debate hits gamers + intellectuals. Habit hits self-improvement + health-conscious demographics. Together, they're a narrative: *Become sharper, stronger, better.*"

---

## 💭 Review Phase — Dirty Bird Evaluates Risk

**Dirty Bird:** "Tank, solid vision. But let me grill you on compliance, liability, and revenue model sustainability.

**On Debate Arena:**
- **Content moderation**: If AI judges controversial debates (politics, religion, identity), we're one bad score away from backlash. 'AI said I lost because of bias'—lawsuits? Trust erosion?
- **Term liability**: If users rage-quit after a 'bad decision' by AI, blame us. Do we need disclaimers? Dispute resolution?
- **Entry fees for leagues**: That's gambling-adjacent in some jurisdictions. Prize pools? Regulatory headache. I recommend: Entry fee stays in-game currency only (earned, not purchased), or we cap real-money leagues to US/EU only with age verification.
- **AI persona 'coaches'**: If users treat AI debate opponents like real people and get emotionally invested, we have parasocial risk. Not legal per se, but reputation/ethics.

**On Habit Forge:**
- **Health claims**: 'Complete habits, get healthier'—NOT a medical claim. We can't say 'This app improves your mental health.' Terms of service must clarify: advisory only, not treatment.
- **Data sensitivity**: Users logging health/fitness/mental wellness data. GDPR, HIPAA (if healthcare users), CCPA. How are we storing, encrypting, deleting data?
- **Streaks and punishment**: Gamification can be psychologically manipulative. If a user breaks a 100-day streak, rage, self-harm (extreme case). We need clear language: 'Streaks are for fun, not worth your wellbeing.'
- **Premium tiers and exploitation**: Don't price-gate core accountability features. Let them use core tracker free, monetize add-ons (coaches, challenges, themes).

**My recommendations:**

For **Debate Arena**:
1. AI scores are *advisory*—not definitive. Add a 'dispute decision' button that flags for human review (free tier).
2. League entry fees → in-game currency earned through play, not purchased.
3. Real-money tournaments restricted to US/EU, 18+, IP verification.
4. Terms must state: 'AI judges are not infallible. This is entertainment, not coaching.'

For **Habit Forge**:
1. Terms of service explicitly state: Not a medical tool. Users should consult doctors, therapists for health decisions.
2. Encrypt user data at rest. Offer 'delete all data' button in settings.
3. Design accountability features (streaks, challenges) to *encourage* without *punishing*.
4. Core app (tracking, basic AI motivation) is free. Premium tiers are add-ons, not essential.

**Risk Level:** 🟡 MEDIUM (manageable with legal guardrails)

**Tank:** "Solid. I'll bake those into feature specs. Debate Arena league entry stays in-game currency, dispute system built in. Habit Forge core is free, premium is optional. Terms updated before launch."

**Dirty Bird:** "Good. One more thing—analytics. Track engagement metrics, identify users at risk for compulsive behavior (logging 5+ habits daily, spending 2+ hours in leaderboards). Consider adding 'take a break' nudges. Not required, but ethical. You'll also reduce churn long-term because you're protecting mental health."

---

## 🎨 Creative Direction — Floof Pushes the Aesthetics

**Floof:** "Okay, NOW we're talking. Let me paint the vibe.

**Debate Arena** → Courtroom Prestige
- Dark background (charcoal #1a1a1a)
- Gold accents (#d4af37) for debate rounds, badges, leaderboard ranks
- Navy blue (#1e3a8a) for buttons, cards, sidebars
- Serif fonts (Georgia or Playfair Display) for titles—*important*, *formal*, *prestigious*
- Gavel icon 🔨 as primary CTA
- Podium-style UI: your avatar at bottom center, AI opponent at top, judges panel on sides
- Scoreboard design inspired by court transcripts: clean typography, minimal whitespace
- Dark wood texture (subtle CSS background) on main cards—leather-bound law book vibes
- Achievement badges: gavel, scales of justice, gavels with laurel wreaths
- Difficulty badges: Pushover (bronze), Moderate (silver), Challenging (gold), Ruthless (platinum), Philosopher King (diamond)

**Habit Forge** → Warm Motivation
- Dark background (#111827, slightly warmer than Debate)
- Orange accents (#f97316) for streaks, XP gains, level-ups
- Amber (#f59e0b) for secondary buttons, habit completion checkmarks
- Sans-serif (Inter or system font) for clean, modern feel—approachable, not cold
- Fire emoji 🔥 for streaks, crown 👑 for legendary (30+ days)
- Calendar heatmap inspired by GitHub contributions—green intensity = completion %
- Daily check-in card: big satisfying checkboxes, simple animation on toggle
- Progress bars for each category, mini-stats cards (This Week: 4/7, Momentum: +12%, Best Streak: 21 days)
- AI Coach appears as a rounded avatar bubble with personality (neutral, supportive emoji)
- Badges: fire, crown, gear (consistency), rocket (momentum), brain (learning), heart (mindfulness)

**Design Philosophy:**
- **Debate**: Make users feel *smart, competitive, prestigious*. Design says 'This is serious intellectual combat.'
- **Habit**: Make users feel *supported, encouraged, proud*. Design says 'You're crushing it. Keep going.'

**Floof:** "Both apps use dark mode as primary (reduces eye strain, helps with evening scrolling, feels premium). Light mode is optional toggle. Animations are *snappy* but not distracting—focus on content, not flash."

---

## 🔍 Market Analysis — The Interrogator Challenges Assumptions

**The Interrogator:** "Hold up. Before we greenlight, I need to interrogate these assumptions.

**Debate Arena Competition:**
- **Chess.com (puzzles)**, **Duolingo (learning games)**, **Kahoot (trivia)** all combine learning + competition + leaderboards. What's our moat?
- **Factorio**, **Civilization** teach strategy thinking. **Reddit** literally has debate communities.
- **Character.ai** lets users debate fictional characters. What makes our *AI judge* special vs. just... chatting with a smart opponent?
- **My concern:** The value prop is 'get judged by AI.' That's... okay? Where's the sticky retention hook? Why return daily?

**Tank's Response:**
"Tournament mode. Leaderboards. Competitive leagues. If we add league seasons (monthly resets, prizes), it becomes 'my rank this season vs. last.' Also: argument library—users save best arguments, remix them, *share* them (look what I won with). That's social. And if we do 'debate of the day' like Chess.com, users return for fresh challenges."

**The Interrogator:** "Okay, that's better. Seasonal competition + shareable wins. Viable. But:
- How do we differentiate difficulty? 'Philosopher King' sounds cool, but *why* is it hard? Is it just more aggressive rebuttals, or does it actually understand edge cases?
- What if users min-max the game (memorize debate templates, beat easy difficulty, never improve)?
- Whales: Who spends money? Competitive gamers on cosmetics? Or coaches (paying to unlock debate coach personas)?

**Habit Forge Competition:**
- **Streakboard**, **Done**, **Habitica** (with RPG mechanics), **Stridekick** (social challenges), **Apple Health**, **Oura Ring**.
- Most are free or freemium. **Habitica** is closest to yours (gamified RPG + habits). Why should someone switch?

**The Interrogator:** "Here's my bigger concern: *Habit fatigue*. Users add 5-10 habits, miss one, spiral into shame, quit. We're seeing this in Habitica forums. How do we solve this?

**Tank's Response:**
"AI Coach actively addresses this. When they miss a habit, AI doesn't say 'You failed.' It says 'You crushed 4 other habits—keep that momentum. Struggling with morning run? Let's adjust the time or swap it for yoga.' We're *coaching*, not *shaming*. Plus, habit stacking: we suggest linking new habits to existing ones. Less overwhelm, more anchor."

**The Interrogator:** "That's good... *if the AI is actually good*. Can Haiku generate genuinely personalized, context-aware coaching, or will it feel generic?

**Tank:** "Fair question. We'll fine-tune prompts with actual user data—track what works (e.g., 'Users who reduce habit count from 10 to 3 stick 40% longer'). Coaching adapts to engagement patterns."

**The Interrogator:** "Okay. Final market questions:

1. **TAM (Total Addressable Market):** 
   - Debate Arena: ~50M competitive gamers globally, ~2% might try educational games = 1M potential users. If 10% convert to paying ($10 ARPU), that's $1M MRR potential. *Realistic but mid-tier.*
   - Habit Forge: 1.3B fitness app users + 500M productivity app users. TAM is HUGE. But fragmented—users juggle 5+ apps. Why consolidate with us? *High TAM, uncertain CAC (customer acquisition cost).*

2. **Retention Benchmarks:**
   - Debate: Casual gamers average 3-4 month churn. Competitive gamers stick 6-12 months if ladder is active.
   - Habit: 70% of habit app users churn within 30 days. 20% hit 90+ days. We need to be in that 20%.

3. **Geographic Expansion:**
   - Debate Arena: English-only initially (competitive language games are hard to localize). EU + US + Commonwealth = 350M English speakers.
   - Habit Forge: Could localize easier—habits are universal. But UI/UX design principles matter globally. Cultural differences (e.g., social accountability is shameful in some cultures).

**The Interrogator's Recommendation:**
- **Debate Arena: GREENLIGHT** — Clear positioning, IP-defensible with good content, strong retention if we nail seasonal competition.
- **Habit Forge: GREENLIGHT with caution** — TAM is huge but saturation is real. Differentiation is AI coaching quality. We must deliver *genuinely smart* personalization, not generic tips.

**Both projects have strong revenue potential if execution is sharp. Risk is product-market fit. Mitigation: Launch MVP, measure day-7 retention and NPS, iterate hard on the first 500 users.**"

---

## 🔧 Technical Architecture — Tank + Floof Bridge Vision to Reality

**Tank:** "Alright, here's the engineering structure:

**Debate Arena Game**
- `components/games/DebateArenaGame.tsx` (main container, mode router)
- `components/games/debate/TopicGenerator.tsx` (displays topic, selected difficulty)
- `components/games/debate/DebateRound.tsx` (timer, text input for argument)
- `components/games/debate/AiOpponent.tsx` (displays AI response + analysis)
- `components/games/debate/ScoreBreakdown.tsx` (Logic/Evidence/Persuasion/Style bars)
- `components/games/debate/RankBadge.tsx` (Rookie → Supreme Court Justice)
- `components/games/debate/TournamentBracket.tsx` (4-round visual)
- `components/games/debate/ArgumentLibrary.tsx` (saved arguments, searchable)
- `components/games/debate/LeaderboardPanel.tsx` (ranked by wins, points, title)

**Habit Forge App**
- `components/apps/HabitForgeApp.tsx` (main router, state manager)
- `components/apps/habit/HabitInput.tsx` (add habit form: name, category, frequency, difficulty)
- `components/apps/habit/DailyCheckIn.tsx` (big checkboxes, note field, day rating)
- `components/apps/habit/StreakVisual.tsx` (fire emoji, counter, legend at 7/30)
- `components/apps/habit/CalendarHeatmap.tsx` (CSS grid, green intensity by completion %)
- `components/apps/habit/CategoryBreakdown.tsx` (% bars per category)
- `components/apps/habit/XpAndLevel.tsx` (progress bar, title display, next milestone)
- `components/apps/habit/AiCoachPanel.tsx` (Daily Motivation, Suggestions, Weekly Review, Accountability)
- `components/apps/habit/ChallengeModal.tsx` (7-day, 21-day, 30-day badge triggers)
- `components/apps/habit/ShareProgress.tsx` (formatted text export)

**API Routes:**
- `app/api/games/debate-arena/route.ts` — POST: topic generation (Haiku), scoring (Haiku), opponent response (Haiku)
- `app/api/games/debate-arena/save.ts` — POST/GET: save/load game state
- `app/api/games/debate-arena/leaderboard.ts` — GET: ranked users
- `app/api/apps/habit-forge/route.ts` — CRUD habits, check-ins
- `app/api/apps/habit-forge/coach.ts` — POST: AI motivation/suggestions/review/accountability (Haiku)

**Data Schemas:**
- `data/games/debate-arena/topics.json` — Pre-loaded debate topics by category
- `data/games/debate-arena/saves.json` — Active games (user_id, round_scores, arguments)
- `data/games/debate-arena/rankings.json` — Top 100 all-time, seasonal leaderboards
- `data/games/debate-arena/arguments.json` — Saved arguments (user library)
- `data/apps/habit-forge/habits.json` — User habits (id, name, category, frequency, difficulty, created_at)
- `data/apps/habit-forge/checkins.json` — Daily check-ins (habit_id, date, completed, notes, day_rating)
- `data/apps/habit-forge/progress.json` — Aggregates (streaks, xp, level, badges earned, best week)

**Frontend State:** React hooks (useState, useContext) for MVP. Could upgrade to Zustand if multiplayer is added.

**AI Integration:** 
- All Haiku calls via `claude-haiku-4-5-20250414` (lightweight, fast, cost-efficient)
- Prompt templates in `lib/prompts/` for consistency
- Response caching for debate topics (reuse topics across users, reduce API calls)

---

## 📋 Final Plan & Assignments

| Component | Owner | Start | Est. Completion | Status |
|-----------|-------|-------|-----------------|--------|
| Debate Arena Game | Tank (design), Floof (UI/CSS) | Today | Day 4 | In Progress |
| Habit Forge App | Tank (design), Floof (UI/CSS) | Today | Day 5 | In Progress |
| API Routes (Debate) | Tank (logic), backend | Today | Day 2 | In Progress |
| API Routes (Habit) | Tank (logic), backend | Day 1 | Day 3 | In Progress |
| Data Schemas | Tank | Today | Day 1 | In Progress |
| AI Prompts (Haiku) | Dirty Bird (review), Tank (write) | Day 1 | Day 2 | In Progress |
| MC Tab Integration | Tank | Day 4 | Day 5 | Pending |
| Legal Review | Dirty Bird | Day 1 | Day 3 | In Progress |
| Market Validation | The Interrogator | Day 6 | Day 7 | Pending |
| QA + Deployment | All | Day 6 | Day 7 | Pending |

**Key Dependencies:**
- Data schemas ready → APIs can be stubbed → Frontend can mock data
- Haiku prompts finalized → APIs can call Haiku → Scoring/Coaching works
- Frontend + APIs integrated → Floof can polish CSS/animations
- All features tested → Dirty Bird's legal review passed → Ready to launch

**Risk Mitigation:**
- If Haiku response time is slow: Implement prompt caching, pre-generate common topics
- If UI is complex: Floof prioritizes core interaction (debate/checkin), defers nice-to-haves (animations)
- If scoring algorithm feels unfair: Add dispute mechanism (Debate), adjust coaching tone (Habit)
- If time constrained: Cut post-launch: Argument sharing (Debate), Team challenges (Habit)

**Success Criteria:**
- **Debate Arena**: All 4 game modes working, difficulty scaling functional, tournament bracket UI done, <1s Haiku latency, dark courtroom aesthetic polished
- **Habit Forge**: Full CRUD habits, daily check-in flow, XP/level system, AI coach generating personalized messages, calendar heatmap rendering, dark warm aesthetic polished
- **Both**: Zero errors on launch, <2s API response, full responsive mobile design, terms of service updated

---

## 🎬 Next Steps & Timeline

1. **Today (Feb 13)**:
   - Tank: Finalize data schemas, write Haiku prompts
   - Floof: Design mockups (Figma), CSS framework setup
   - Dirty Bird: Draft terms of service, review liability language
   - The Interrogator: Validate TAM, sketch user acquisition strategy

2. **Day 2 (Feb 14)**:
   - Tank: Complete API skeleton, stub routes
   - Floof: Build component shells, implement dark theme
   - Dirty Bird: Final legal review, update ToS
   - The Interrogator: Competitive feature comparison

3. **Day 3-4 (Feb 15-16)**:
   - Tank + Floof: Debate Arena MVP (game loop, scoring, UI polish)
   - The Interrogator: Feature prioritization for launch

4. **Day 5-6 (Feb 17-18)**:
   - Tank + Floof: Habit Forge MVP (CRUD, check-in, AI coach)
   - Dirty Bird: Final compliance review

5. **Day 7 (Feb 19)**:
   - Tank: MC tab integration (GamesTab, AppsTab)
   - Floof: Final polish, responsive testing
   - All: QA, bug fixes, edge cases
   - Launch target: **2026-02-20**

---

## 💰 Monetization & Growth Strategy

**Debate Arena:**
- **Free tier:** Solo Practice (unlimited), Quick Debate (unlimited), easy difficulty
- **Premium ($4.99/mo):** All difficulty levels, tournament mode, debate coach personas
- **Competitive leagues:** In-game currency entry (earned through play), seasonal rankings, cosmetic rewards
- **Expansion (Post-launch):** Real-money tournaments (US/EU only, age-gated), topic packs ($2.99)

**Habit Forge:**
- **Free tier:** Core tracking (habits, check-ins), basic motivation, calendar view
- **Premium ($6.99/mo):** AI coaching (Daily/Weekly/Accountability), custom challenges, advanced analytics
- **Team plans:** $19.99/mo (5-10 users, shared accountability boards, leaderboards)
- **Expansion:** Custom challenge packs ($2.99), themed habit templates ($1.99)

**Year 1 Revenue Target:**
- Debate Arena: 50K users, 8% conversion to Premium = 4K × $60 annual = $240K MRR potential (blended with leagues)
- Habit Forge: 100K users, 15% conversion to Premium = 15K × $84 annual = $1.26M MRR potential

---

## ✅ Approval

**Dirty Bird:** "Liabilities addressed, legal framework in place. ✅"

**Floof:** "Aesthetic vision is clear. CSS will be chef's kiss. ✅"

**The Interrogator:** "Market fit is solid. Execution risk is real but manageable. ✅"

**Tank:** "All systems go. Let's build something people will *want* to use."

---

**Approved by:** Tank, Dirty Bird, Floof, The Interrogator  
**Budget:** Team Delta dev resources (no external spend, API calls via existing Haiku quota)  
**Confidence Level:** 🟢 HIGH — clear vision, manageable scope, strong team chemistry, defensible competitive positioning
