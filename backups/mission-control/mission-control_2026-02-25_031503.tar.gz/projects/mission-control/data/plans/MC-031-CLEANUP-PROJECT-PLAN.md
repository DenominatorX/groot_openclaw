# MC-031: Mission Control Enhancement Suite — Cleanup Project
**Created:** 2026-02-18  
**Status:** Active  
**Priority:** High  
**Category:** Cleanup  
**PM:** CEO (gork/grok-4-1-fast-reasoning)  
**Project ID:** MC-031

---

## Project Overview

A major MC v3 enhancement sprint covering 7 feature areas. Focus is **cost-efficient + powerful** — MiniMax for coding, Haiku for docs/admin, Sentinel (Sonnet 4-6) for all QA and testing. Sonnet 4-6 as fallback for any model failures.

---

## Team Roster

| Role | Agent | Model | Responsibilities |
|------|-------|-------|-----------------|
| Project Manager | CEO | gork (xai/grok-4-1-fast-reasoning) | Coordination, sequencing, concurrent task management |
| Backend Engineer | Forge | openrouter/minimax/minimax-m2.5 | APIs, DB schema, cron system, activity feed backend |
| Frontend Engineer | Pixel | openrouter/minimax/minimax-m2.5 | UI panels, components, settings pages |
| QA / Code Review | Sentinel | anthropic/claude-sonnet-4-6 | ALL code review + testing — nothing ships without Sentinel signoff |
| Documentation | Archivist | anthropic/claude-haiku-4-5 | Project docs, agent workspace updates, audit logs |
| Hub / Oversight | Groot | anthropic/claude-sonnet-4-6 | Direction, blocker resolution |

**Fallback model:** `anthropic/claude-sonnet-4-6` for any agent hitting model errors.

---

## Feature Specifications

### Feature 1: Discord Session Manager Panel
**Priority:** High | **Owner:** Forge (backend) + Pixel (frontend)

**What:** Separate Discord sessions from main Context Health panel on MC Home Page.

**Backend requirements:**
- New API endpoint: `GET /api/discord-sessions` — returns only Discord channel sessions with metadata (model, token count, last activity, status)
- New endpoints: `POST /api/discord-sessions/[sessionKey]/compact`, `/reset`, `/model` (change model)
- Auto-compaction toggle stored in settings (per-session or global)
- All actions logged to activity feed via `logActivity()`
- Compaction summary: "Compacted #mission-control — 45K → 12K tokens (saved 33K)"

**Frontend requirements:**
- New `DiscordSessionManager` component on Home page, positioned near (but separate from) Context Health
- Per-session card showing: channel name, current model, token usage bar, last active
- Per-session action buttons: Compact, Reset, Change Model (dropdown), auto-compact toggle
- Global "Compact All" and "Reset All" buttons
- Activity feed entries auto-append when actions taken

**Discord Channel Map (hardcoded or from config):**
```
1472849769050411101 → #mission-control
1472849770002513920 → #development  
1472849771264741437 → #ideas
1472849772095209507 → #bugs-and-defects
1472849773592576041 → #existing-features
1472849774251085896 → #crazy-ideas
1472849778546053263 → #random-stuff
1472849783252058115 → #search-the-web
1472849784539840625 → #search-twitter
1472849785026379902 → #other
```

---

### Feature 2: Enhanced Context Health Panel
**Priority:** High | **Owner:** Forge (backend) + Pixel (frontend)

**What:** Enhance existing Context Health panel with more session management controls.

**Backend requirements:**
- Extend context-health API to support: bulk compact, bulk reset, per-session model change, per-session context cap change
- All actions logged to activity feed
- Return enriched session data: model name (human-readable), provider, context %, last message preview

**Frontend requirements:**
- Add to each session row: model dropdown (change model inline), context cap input, compact/reset buttons
- Add global controls: "Compact All Over 80%", "Reset All Idle > 2hrs"
- Filter/sort: by agent, by token %, by last active, by channel
- Session type filter tabs: All | Webchat | Discord | Agent | Sub-agent
- All actions append to activity feed with summary

---

### Feature 3: Cron System Fix + Verification
**Priority:** High | **Owner:** Forge

**What:** Debug and fix why Kevin's crons haven't been working. Make them reliable.

**Investigation checklist:**
1. Check cron job entries in `~/.openclaw/cron/` or wherever stored
2. Check gateway logs for cron execution errors
3. Verify `schedule.kind` format is correct
4. Verify `payload.kind` and `sessionTarget` pairings
5. Test a simple recurring cron end-to-end

**Fix:**
- Create a MC Settings > Cron Manager page listing all active crons
- Show: name, schedule, last run, next run, status, last result
- Buttons: Run Now, Enable/Disable, Edit, Delete
- New cron button with form builder (schedule type, payload, delivery)
- Verify "sonnet" alias = anthropic/claude-sonnet-4-6 in config (already done 2026-02-18)

**Cron Manager API:**
- `GET /api/crons` — proxy to gateway cron list
- `POST /api/crons` — create new cron via gateway
- `PUT /api/crons/[id]` — update
- `DELETE /api/crons/[id]` — remove
- `POST /api/crons/[id]/run` — trigger now

---

### Feature 4: Agent Workspace Config Broadcaster
**Priority:** Medium | **Owner:** Forge (backend) + Archivist (execution/docs)

**What:** Tool to broadcast config changes (model updates, alias changes, new agents) to all 25 agent workspace MEMORY.md and IDENTITY.md files.

**Implementation:**
- MC Settings > Config Broadcaster page
- Shows diff of what changed in config
- One-click "Broadcast to All Agents" pushes update to `projects/mission-control/data/workspaces/{agent-id}/MEMORY.md`
- Also updates IDENTITY.md model references if changed
- Activity feed: "Broadcast sent to 25 agents — sonnet alias updated to claude-sonnet-4-6"
- Document as MC Feature in Settings sidebar

**API:**
- `POST /api/broadcast-config` — body: `{ field, oldValue, newValue, affectedAgents }`
- Reads each agent workspace, appends update note to MEMORY.md

---

### Feature 5: Intelligent Tier Restructure Helper
**Priority:** Medium | **Owner:** CEO (design) + Forge (backend) + Pixel (frontend)

**What:** MC tool for safely restructuring agent tiers, detecting safe concurrent operations.

**Logic:**
- Load current agent tier assignments from `agents.json`
- Display current tier map visually
- Proposed changes wizard: select agent → select new tier → validate (checks for conflicts)
- Concurrency detection: changes that don't affect the same agent's spawn chains can run simultaneously
- Step-by-step execution with undo per step
- Dry-run mode: shows what would change without applying

**UI:** Settings > Tier Restructure — wizard UI, drag-drop tier assignment, conflict warnings

---

### Feature 6: Complete Sub-agent Activity System
**Priority:** High | **Owner:** Forge (backend) + Pixel (frontend)

**What:** Comprehensive activity tracking across all agents, viewable per agent and globally.

**Components:**

**A. Global Activity Feed (MC Home)**
- Real-time live feed of ALL activity: agent messages, sub-agent spawns, completions, tool calls, project updates, chat messages, cron fires
- Shows agent name, action type, timestamp, summary
- Filters: by agent, by type, by project, by time range
- Auto-refreshes every 5-10s (SSE preferred)
- Backed up daily to `data/activity-archive/YYYY-MM-DD.json`

**B. Per-Agent Activity Feed**
- Each agent profile page shows their own activity feed
- Includes: messages sent/received, sub-agents they spawned, tools used, projects they worked on

**C. Per-Agent Chat History**
- Agent profile page: "Conversations" tab
- Shows all conversations this agent participated in (with other agents, with Kevin)
- Each conversation expandable with full message history
- "Boss Mode" for Kevin: can see all agents' histories from main account view

**D. Sub-agent Logging**
- All sub-agents tracked with: name, spawned by, model, task, status, API cost, duration, result summary
- "Sub-agents" tab globally + per-agent
- OpenClaw `sessions_spawn` completions captured and logged with agent names

**E. Boss Mode**
- Kevin's account: all agents, all histories, all activity
- Other users (future): scoped to their agents only
- Current state: all agents are under Kevin's account

**DB Schema additions needed:**
```sql
CREATE TABLE IF NOT EXISTS activity_log (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  action_type TEXT,  -- 'message', 'spawn', 'complete', 'tool', 'cron', 'compact', etc.
  summary TEXT,
  detail TEXT,  -- JSON blob
  project_id TEXT,
  session_key TEXT,
  cost_usd REAL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_conversations (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  with_agent_id TEXT,
  session_key TEXT,
  message_count INTEGER,
  started_at TEXT,
  last_message_at TEXT,
  summary TEXT
);

CREATE TABLE IF NOT EXISTS subagent_runs (
  id TEXT PRIMARY KEY,
  label TEXT,
  spawned_by TEXT,
  agent_id TEXT,
  model TEXT,
  task_summary TEXT,
  status TEXT,  -- 'running', 'completed', 'failed'
  result_summary TEXT,
  cost_usd REAL,
  duration_ms INTEGER,
  started_at TEXT,
  completed_at TEXT
);
```

**API endpoints:**
- `GET /api/activity` — paginated, filterable
- `POST /api/activity` — log new activity (called by agents/crons)
- `GET /api/activity/agent/[id]` — per-agent feed
- `GET /api/subagents` — all subagent runs
- `GET /api/subagents/agent/[id]` — per-agent subagents
- `GET /api/conversations/agent/[id]` — per-agent chat history

---

### Feature 7: Dynamic Model Context Window Settings
**Priority:** Medium | **Owner:** Forge (backend) + Pixel (frontend)

**What:** Context Health max-tokens shows the actual model's context window, not a hardcoded 150K. Editable per model in settings.

**Backend requirements:**
- Model registry with known context windows (to be defined):
  - anthropic/claude-sonnet-4-6: 200K
  - anthropic/claude-haiku-4-5: 200K
  - anthropic/claude-opus-4-6: 200K
  - x-ai/grok-4: 131K
  - xai/grok-4: 131K
  - openrouter/minimax/minimax-m2.5: 204K
  - openrouter/google/gemini-2.5-pro: 1M
  - openai/gpt-5.2: 1M
  - openai/gpt-5-mini: 1M
  - lmstudio/gemma-3-12b: 8K
  - etc.
- API: `GET /api/models/context-windows` — returns map of model → contextWindow
- API: `PATCH /api/models/[id]/context-window` — update
- Fix: Grok sessions currently show 150K cap (wrong) → should show 131K
- 150K is the session context cap in OpenClaw config (separate from model max)

**Frontend requirements:**
- Settings > Models page: add "Context Window" and "Max Output Tokens" columns, editable inline
- Context Health panel: max-tokens display uses agent's actual model context window
- Visual indicator when session context > 80% of model's actual window
- Tooltip on context bar: "X / Y tokens (model max: Z)"

---

## Execution Phases

### Phase 0: Kick-off (CEO)
- Create project in MC, assign team, document plan
- Confirm technical approach, check for blockers
- Spawn Forge + Pixel with feature assignments

### Phase 1: Backend (Forge/MiniMax) — parallel where safe
- DB schema migrations (activity_log, agent_conversations, subagent_runs)
- All API routes for Features 1, 2, 3, 4, 6, 7
- Cron system investigation + fix

### Phase 2: Frontend (Pixel/MiniMax) — can run parallel to backend
- Discord Session Manager component
- Enhanced Context Health panel
- Cron Manager settings page
- Config Broadcaster settings page
- Sub-agent Activity Feed components
- Per-agent conversation history
- Dynamic context window in Model Settings page

### Phase 3: Sentinel Review Round 1 (Sentinel/Sonnet 4-6)
- Review all backend code
- Review all frontend code
- File defect reports as GitHub issues or MC issues
- Nothing merges/builds without Sentinel sign-off

### Phase 4: Fix + Rebuild
- Forge/Pixel address Sentinel's defects
- Re-submit to Sentinel for re-review

### Phase 5: Sentinel Final QA
- End-to-end testing: each feature tested against spec
- Performance check
- Build verification: `npm run build` passes clean

### Phase 6: Documentation (Archivist/Haiku)
- Update README
- Document each new feature in MC Settings help text
- Update all 25 agent MEMORY.md files with: "Sonnet 4-6 is available via 'sonnet' alias. MC now includes Discord Session Manager, enhanced Context Health, Sub-agent Activity Feed, Cron Manager."
- Document Project Protocol retrospective structure

### Phase 7: Project Protocol Retrospective
Each agent submits:
- 3 things that made their job easier
- 3 things that made their job harder

CEO (PM) submits:
- 5 skill ideas that would enhance running this type of project
- 5 least effective parts of the process
- What PM would do to simplify while keeping same output

Archivist compiles into `MC-031-RETROSPECTIVE.md`.

---

## Definition of Done
- [ ] All 7 features working in production (port 3001)
- [ ] `npm run build` passes with zero errors
- [ ] Sentinel has signed off all code
- [ ] Activity feed logging all actions
- [ ] Cron system verified working with test cron
- [ ] All agent workspaces updated
- [ ] Retrospective document complete

---

## File Paths
- MC root: `/Users/groot/.openclaw/workspace/projects/mission-control/`
- DB: `data/mission-control.db`
- Activity log API: `app/api/activity/`
- Context health API: `app/api/context-health/route.ts`
- New: `app/api/discord-sessions/`
- New: `components/DiscordSessionManager.tsx`
- New: `app/api/crons/`
- New: `app/api/activity/`
- New: `app/api/subagents/` (tracking)
- New: `app/api/models/`
- New: `app/(dashboard)/settings/crons/`
- New: `app/(dashboard)/settings/config-broadcaster/`
- New: `app/(dashboard)/settings/tier-restructure/`

---

## Cost Targets
- MiniMax M2.5: $0.03/1K input, $0.12/1K output — primary coding
- Haiku: $0.0008/1K input, $0.004/1K output — docs/admin
- gork: reasoning tasks only — minimal use
- Sonnet 4-6: Sentinel review + fallback only
- Target total: <$5 for this project
