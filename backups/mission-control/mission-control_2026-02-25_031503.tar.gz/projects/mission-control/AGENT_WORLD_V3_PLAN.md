# Agent World v3 — AAA-Quality RTS Sci-Fi Base

## Vision
A Warcraft/StarCraft-inspired isometric 3D base where Kevin's AI agents live, work, and level up. Real textured 3D models, proper buildings assembled from modular pieces, agents visibly working at stations, XP/leveling system, click-to-interact with profile cards.

## Asset Inventory (What We Have)

### Buildings — Quaternius Modular Sci-Fi MegaKit (190 glTF pieces + PBR textures)
**Path**: `assets/buildings/Modular SciFi MegaKit[Standard]/.../glTF/`
- **Walls (84)**: Wall panels, corners (round/square), windows, cables, astra, metal, short walls
- **Platforms (38)**: Floor tiles, stairs, ramps, doors, rails, round platforms
- **Props (28)**: Computers, barrels, crates, cables, vents, lights, fans, access points, rails
- **Columns (8)**: Support pillars
- **Decals (29)**: Surface details
- **Aliens (3)**: Cyclop, Oculichrysalis, Scolitex — potential NPC creatures
- **Textures (21 PBR maps)**: BaseColor, Normal, ORM (Occlusion/Roughness/Metallic), Emissive, DetailMask

### Buildings — Kenney Space Kit (153 GLB — self-contained)
**Path**: `assets/buildings/kenney_space-kit/Models/GLTF format/`
- Hangars, corridors, structures, machines, turrets, rockets, terrain, pipes, monorail, desks
- These are GLB (embedded textures) — easiest to load

### Buildings — Cyberpunk Game Kit (71 pieces, glTF available)
**Path**: `assets/buildings/Cyberpunk Game Kit - Quaternius.../`
- Platforms, signs, cables, fences, lights, antennas, AC units
- Character model (cyberpunk character.gltf)
- Great for detail/decoration pieces

### Characters (GLB)
- steampunk_robot.glb (4.4MB) — Groot
- sphere-bot-with-hydraulics.glb (15MB, has animations) — Dr. Al
- Friendly_Robot.glb (7.5MB) — CEO
- RoboticScorpion.glb (1.2MB) — Dirty Bird
- WALL-E.glb (232K) — Brain (scale issues, maybe swap)
- military_mercenary.glb (492K) — Jimmy T
- cyberpunk_humanoid.glb (1.9MB) — Worker B
- Cyberpunk Character from Quaternius kit — potential alt for Worker B or new agents
- Alien_Cyclop/Oculichrysalis/Scolitex — NPC wanderers

## Architecture Plan

### Phase 1: Asset Pipeline & Terrain (Foundation)
**Goal**: Get real textured models loading reliably, build proper terrain

1. **Symlink all glTF/GLB assets to `public/assets/`**:
   - `public/assets/scifi/` ← Quaternius MegaKit glTF + textures
   - `public/assets/kenney/` ← Kenney Space Kit GLBs
   - `public/assets/cyberpunk/` ← Cyberpunk Kit glTFs
   - `public/assets/characters/` ← already done
   
2. **Textured terrain**: Replace flat colored plane with a proper ground
   - Use Kenney terrain pieces OR create a large textured plane
   - Grid-pattern metallic floor (sci-fi base look) using Quaternius Platform_Metal tiles
   - Or: Single large plane with repeating sci-fi floor texture from Quaternius textures

3. **GLTFLoader with texture support**: Ensure Quaternius textures load properly
   - glTF files reference .bin geometry + texture paths
   - Copy textures alongside glTF files so relative paths resolve

4. **Post-processing**: Add EffectComposer with:
   - UnrealBloomPass (neon glow on emissive materials)
   - SSAOPass or subtle AO (depth)
   - Optional: OutlinePass for selected agents

### Phase 2: Real Buildings (The Base)
**Goal**: Replace ALL procedural geometry with modular asset buildings

Each building = assembled from multiple Quaternius wall/platform/prop pieces:

1. **Command HQ** (center, largest):
   - Base: Platform_Metal (4-wide) + Platform_Stairs_4Wide (entrance)
   - Walls: WallAstra_Straight × 4 + corners
   - Roof: TopAstra pieces
   - Props: Prop_Computer × 2, Prop_Light_Wide, Prop_AccessPoint
   - Door: Door_Frame_SquareTall + Door_DarkMetal

2. **Dev Workshop** (open-front hangar style):
   - Base: Platform_Simple2 × 6 (large floor)
   - Walls: WallWindow_Straight × 3 (back + sides), open front
   - Props: Prop_Computer × 4, Prop_Cable × 2, desk_computer (Kenney)
   - Kenney: machine_generatorLarge, machine_wirelessCable

3. **Med Bay**:
   - Base: Platform_CenterPlate × 4
   - Walls: WallBand_Straight (clean medical look)
   - Props: Prop_Light_Floor, Prop_Chest (supply), Prop_Vent_Small
   - Kenney: structure_detailed

4. **Legal Office**:
   - Base: Platform_DarkPlates × 4
   - Walls: ShortWall_DarkMetal2 × 4 + columns
   - Props: Prop_Computer, Prop_Barrel_Large (document storage)
   - Columns: 2 flanking entrance

5. **Research Lab**:
   - Base: Platform_Round1 (center) + Platform_Simple around
   - Walls: Mixed wall types creating lab feel
   - Props: Prop_Fan_Small, Prop_AccessPoint, Prop_Cable × 3
   - Kenney: chimney_detailed, turret_single (antenna)

6. **Operations Hub**:
   - Base: Platform_3Plates × 4
   - Walls: TopCables walls (industrial)
   - Props: Prop_Vent_Big × 2, Prop_PipeHolder × 4
   - Kenney: pipe_corner, pipe_cross, pipe_entrance

7. **Supply Depot** (bonus — agent rest/spawn area):
   - Kenney: hangar_largeA + crates/barrels
   
8. **Perimeter**: Cyberpunk fences, lights, signs around the base edge

### Phase 3: Agent Behaviors & Leveling
**Goal**: Agents visibly work, gain XP, level up

1. **Work Stations**: Specific positions INSIDE each building where agents stand
   - Agent walks to their assigned building when dispatched
   - Stands at a workstation (near a Prop_Computer or desk)
   - Subtle "working" animation: slight rotation, particle effects (sparks/data streams)

2. **XP & Leveling System**:
   - Every task completed = XP (varies by task difficulty)
   - Levels: 1-50 (or unlimited)
   - Level thresholds: 0, 100, 300, 600, 1000, 1500, 2200, 3000...
   - Visual level indicator: floating badge above agent, gets fancier with level
   - Level-up celebration: particle burst, sound cue, notification
   - Store in agents.json: `stats.xp`, `stats.level`, `stats.tasksCompleted`

3. **Status Effects (visual)**:
   - 💤 Idle — gentle bob, wandering
   - ⚡ Working — at workstation, sparks/particles
   - 💬 Chatting — speech bubble particles
   - 🔬 Researching — data stream effect
   - ⬆️ Level Up! — gold particle explosion

### Phase 4: Click Interactions & Profile Cards
**Goal**: Rich click interactions, mini profile cards

1. **Click Agent → Profile Card** (not just action buttons):
   - Floating card near agent with:
     - Name, Title, Tier badge
     - Level + XP bar
     - Current status/task
     - Model name
     - 3 action buttons: 💬 Chat, 📋 Task, 👤 Full Profile
   - Styled like a game character card (dark, neon accents)

2. **Click Building → Building Info Card**:
   - Building name, type, assigned agents
   - Current projects being worked on
   - Activity indicator

3. **Agent name plates always visible**:
   - Larger font, always on top
   - Show: Name + Level badge
   - Color-coded by tier

### Phase 5: Polish & Atmosphere
**Goal**: AAA feel

1. **Skybox**: Dark space/nebula skybox (or deep ocean if ocean theme)
2. **Ambient particles**: Floating dust/data motes in the air
3. **Building lights**: Each building has interior glow, exterior accent lights
4. **Shadows**: Proper shadow maps from all buildings
5. **Sound design**: Ambient hum (optional, toggle)
6. **Weather effects**: Tie to MC weather widget (rain particles, etc.)
7. **Day/night cycle**: Subtle lighting shift over time
8. **NPC creatures**: Load Quaternius aliens as ambient wandering NPCs

## Performance Budget
- **Total loaded assets**: < 80MB
- **Draw calls**: < 200
- **Triangle count**: < 500K
- **Target FPS**: 60 on M4 Mac Mini
- **LOD**: Use simpler models when camera is far

## Implementation Priority
1. Phase 1 (asset pipeline) — MUST DO FIRST
2. Phase 2 (real buildings) — core visual upgrade
3. Phase 4 (profile cards) — user interaction
4. Phase 3 (leveling) — engagement loop
5. Phase 5 (polish) — the wow factor

## Key Technical Notes
- Quaternius glTF files are `.gltf` + `.bin` (separate geometry) — textures referenced via relative paths
- Must copy Quaternius `Textures/` folder alongside glTF files for materials to load
- Kenney GLBs are self-contained (embedded textures) — just load and place
- Use `THREE.EffectComposer` + `UnrealBloomPass` for neon glow
- For modular buildings: load individual pieces, position them relative to a parent Group
- Each building should be a pre-configured function that returns a positioned THREE.Group
