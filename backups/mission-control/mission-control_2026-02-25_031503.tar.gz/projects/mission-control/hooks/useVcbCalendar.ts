'use client';

import { useState, useEffect, useRef, useCallback } from 'react';

interface Commit {
  id: string;
  branch_id: string;
  message: string;
  author: string;
  hash: string | null;
  parent_commit_id: string | null;
  metadata: Record<string, unknown>;
  timestamp: string;
  branch_name?: string;
  branch_color?: string;
  file_count?: number;
}

interface Snapshot {
  id: string;
  branch_id: string;
  commit_id: string | null;
  label: string;
  description: string | null;
  data: Record<string, unknown>;
  timestamp: string;
  branch_name?: string;
  branch_color?: string;
}

interface CalendarDay {
  commits: Commit[];
  snapshots: Snapshot[];
}

interface CalendarResponse {
  year: number;
  month: number;
  days: Record<string, CalendarDay>;
}

interface UseVcbCalendarResult {
  data: CalendarResponse | null;
  loading: boolean;
  error: string | null;
}

interface CacheEntry {
  data: CalendarResponse;
  timestamp: number;
}

const CACHE_MAX_AGE = 5 * 60 * 1000; // 5 minutes

export function useVcbCalendar(year: number, month: number): UseVcbCalendarResult {
  const [data, setData] = useState<CalendarResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const cacheRef = useRef<Map<string, CacheEntry>>(new Map());

  const getCacheKey = (y: number, m: number) => `${y}-${m}`;

  const fetchCalendar = useCallback(async () => {
    const cacheKey = getCacheKey(year, month);
    const cached = cacheRef.current.get(cacheKey);

    // Check if cached entry is still valid
    if (cached && Date.now() - cached.timestamp < CACHE_MAX_AGE) {
      setData(cached.data);
      setLoading(false);
      return;
    }

    // Clean old cache entries (keep last 3 months)
    const now = Date.now();
    for (const [key, entry] of cacheRef.current.entries()) {
      if (now - entry.timestamp > CACHE_MAX_AGE) {
        cacheRef.current.delete(key);
      }
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`/api/vcb/calendar?year=${year}&month=${month}`);
      if (!res.ok) {
        throw new Error('Failed to fetch calendar data');
      }
      const result: CalendarResponse = await res.json();
      
      // Cache the result
      cacheRef.current.set(cacheKey, {
        data: result,
        timestamp: Date.now(),
      });
      
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  }, [year, month]);

  useEffect(() => {
    fetchCalendar();
  }, [fetchCalendar]);

  return {
    data,
    loading,
    error,
  };
}
