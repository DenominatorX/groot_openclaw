'use client';

import { useState, useEffect, useCallback } from 'react';

interface Branch {
  id: string;
  name: string;
  parent_id: string | null;
  status: 'active' | 'merged' | 'archived' | 'stale';
  description: string | null;
  color: string;
  created_at: string;
  updated_at: string;
  last_commit_id?: string;
  last_commit_message?: string;
  last_commit_author?: string;
  last_commit_at?: string;
  commit_count?: number;
  snapshot_count?: number;
}

interface UseVcbBranchesResult {
  branches: Branch[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useVcbBranches(): UseVcbBranchesResult {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBranches = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/vcb/branches');
      if (!res.ok) {
        throw new Error('Failed to fetch branches');
      }
      const data = await res.json();
      setBranches(data.branches || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBranches();
  }, [fetchBranches]);

  return {
    branches,
    loading,
    error,
    refetch: fetchBranches,
  };
}