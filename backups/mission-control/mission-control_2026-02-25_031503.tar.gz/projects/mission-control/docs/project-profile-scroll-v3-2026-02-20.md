# Project Profile Scroll v3 + Overview Description Fix

**Date:** 2026-02-20  
**Status:** ✅ Shipped

## Issues Fixed

### 1. Auto-scroll on Project Page (MC-00038)
**Problem:** Project page was auto-scrolling down after a moment, causing the header to disappear.

**Root Cause:** The `ProjectChat` component at the bottom of the ProjectProfile used `scrollIntoView({ behavior: 'smooth' })` to scroll to new messages. This was causing the entire page to scroll down when:
- New messages arrived via polling (every 5 seconds)
- User sent a message

**Fix Applied:**
- Added `style={{ overflowAnchor: 'none' }}` to the messages container in `ProjectChat.tsx`
- This prevents the browser's auto-scroll anchor from affecting the parent page scroll position
- The chat now scrolls internally without moving the entire page

**File Changed:** `components/ProjectChat.tsx`
```diff
- <div className="flex-1 overflow-y-auto p-3 space-y-2">
+ <div className="flex-1 overflow-y-auto p-3 space-y-2" style={{ overflowAnchor: 'none' }}>
```

### 2. Overview Description Field Too Small
**Problem:** The description field in the Overview tab was only showing 3 rows by default, cutting off content.

**Fix Applied:**
- Increased `rows={3}` to `rows={6}` 
- Added `min-h-[120px]` for better default visibility
- This allows more description content to be visible without needing to resize

**File Changed:** `components/ProjectProfile.tsx`
```diff
- rows={3} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm resize-none"
+ rows={6} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm resize-none min-h-[120px]"
```

## Verification
- ✅ `npm run build` completed successfully
- ✅ Only one Project Chat remains at the bottom (verified no duplicates)
- ✅ No other scroll triggers found in ProjectProfile or child components

## Files Changed
1. `components/ProjectChat.tsx` - Added overflow-anchor CSS to prevent page scroll
2. `components/ProjectProfile.tsx` - Increased Overview description field size
