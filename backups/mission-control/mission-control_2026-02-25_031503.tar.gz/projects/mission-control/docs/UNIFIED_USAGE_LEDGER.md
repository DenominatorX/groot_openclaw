# Unified Usage Ledger

## Overview

Mission Control now includes a **Unified Usage Ledger** that normalizes usage/cost events across:

- OpenRouter
- OpenAI
- Google Gemini
- xAI / Grok
- Anthropic
- NVIDIA NIM

The ledger is implemented as a normalized SQLite table (`usage_events`) with idempotent ingestion and provider adapter architecture for future expansion.

## Schema

`usage_events` fields:

- `provider`
- `model`
- `timestamp`
- `tokens_in`
- `tokens_out`
- `cache_read`
- `cache_write`
- `request_id`
- `cost_usd`
- `raw_payload`
- `source`

Additional table:

- `usage_sync_status` (tracks last sync state per provider)

Sync states are now explicit:
- `success_with_records`
- `success_no_history_api`
- `success_zero_records`
- `failed`

## API Endpoints

### Query events

`GET /api/usage-ledger/events`

Query params:

- `provider`
- `model`
- `startDate`
- `endDate`
- `limit`
- `offset`

### Aggregated metrics

`GET /api/usage-ledger/metrics`

Query params:

- `provider`
- `model`
- `startDate`
- `endDate`

Returns summary cards data (cost, tokens in/out, requests) plus provider/model aggregates.

### Manual sync trigger

`POST /api/usage-ledger/sync`

Body:

```json
{
  "provider": "openai",
  "since": "2026-02-01T00:00:00.000Z"
}
```

Both fields are optional.

### Sync status

`GET /api/usage-ledger/sync/status`

Optional query param:

- `provider`

### Cron-friendly sync trigger

`POST /api/usage-ledger/sync/cron`

Auth:

- `Authorization: Bearer <MC_USAGE_LEDGER_CRON_TOKEN or config token>`
- or header `x-cron-token`

Fallback for local internal only (if no token configured):

- `x-mc-cron-local: 1`

## Settings & Credentials

The ledger supports secure credential/config retrieval in this order:

1. Existing `settings.apiKeys` entries (for backward compatibility)
2. Encrypted secret store (`/api/settings/secrets`)
3. Environment variables

Provider key names recognized:

- OpenRouter: `openrouter`, `OPENROUTER_API_KEY`
- OpenAI: `openai`, `OPENAI_API_KEY`
- Google: `google`, `GOOGLE_API_KEY`
- xAI: `xai`, `XAI_API_KEY`
- Anthropic: `anthropic`, `ANTHROPIC_API_KEY`
- NVIDIA: `nvidia`, `NVIDIA_API_KEY`

Ledger config endpoint:

- `GET /api/settings/usage-ledger`
- `PUT /api/settings/usage-ledger`

## Provider Caveats / Availability

### OpenRouter

- No public historical usage API.
- Programmatic sync is a stub.
- Best-effort tracking should be done at request-time via response usage metadata.

### OpenAI

- Billing/usage endpoint requires proper org permissions.
- Historical granularity may be daily and can lag.
- Request-level details should still be tracked at request-time for highest fidelity.

### Google Gemini

- No direct historical usage endpoint currently used here.
- Adapter is wired and connection-test capable.
- Request-time tracking is recommended.

### xAI / Grok

- No public historical usage endpoint currently used here.
- Adapter is wired and request-time tracking helper is included.

### Anthropic

- Usage metadata available in request responses.
- Prompt caching fields (`cache_read`, `cache_write`) are modeled.
- Historical API not currently available in this integration.

### NVIDIA

- API and billing surfaces vary by deployment.
- Adapter is wired with conservative stub sync implementation.

## Request-time Ingestion Coverage

Request-time ledger writes are wired into active Mission Control call paths including:
- Global room chat (`/api/chat`)
- Agent chat (`/api/chat/agent`)
- Project chat (`/api/chat/project`, `/api/projects/[id]/chat`)
- Task analysis/execution (`/api/tasks/analyze-task`, `/api/tasks/execute`)
- Project analysis/execution (`/api/projects/analyze`, `/api/projects` execution action)
- Plan generation (`/api/plan/generate`)

Provider caveat for current app flows:
- Direct request paths currently invoke OpenRouter, Anthropic, OpenAI, and xAI.
- Google/NVIDIA direct APIs are adapter-plumbed for ledger + sync status, but are not currently first-class direct execution routes in these core flows.

## Cost Consistency

Cost normalization rules:

1. Prefer explicit provider-returned cost in payload if present.
2. If missing, compute from normalized tokens using model/provider pricing tables.
3. If still unknown/partial, default to `0` rather than producing invalid values.

This ensures consistent rollups even with incomplete provider payloads.

## Idempotency

Ingestion uses `INSERT OR IGNORE` with uniqueness on provider/request/timestamp and update fallback for known request IDs.

This makes repeated sync invocations safe for cron-based operation.

## Example cron usage

```bash
curl -X POST http://localhost:3000/api/usage-ledger/sync/cron \
  -H "Authorization: Bearer $MC_USAGE_LEDGER_CRON_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"since":"2026-02-20T00:00:00.000Z"}'
```
