# Gateway Chat Protocol — MC ↔ OpenClaw Agent Sessions

## Overview
Mission Control chat panels become direct communication channels to OpenClaw agent sessions. Each chat is backed by a persistent Gateway session that the agent lives in.

## Architecture

```
┌─────────────────┐     ┌──────────────┐     ┌─────────────────┐
│  MC Chat UI      │────▶│  MC Next.js  │────▶│  OpenClaw       │
│  (Browser)       │◀────│  API Routes  │◀────│  Gateway :18789 │
│                  │ SSE │              │ HTTP│                  │
└─────────────────┘     └──────────────┘     └─────────────────┘
```

## Session Lifecycle

### 1. Create Session
```
POST /api/chat/sessions
Body: { agentId: "jimmy-t", model: "openrouter/minimax/minimax-m2.5" }
→ Gateway: POST /api/sessions/spawn { agentId, task: "Interactive MC session", model }
← { sessionKey, status: "active" }
```

### 2. Send Message
```
POST /api/chat/sessions/:sessionKey/messages
Body: { message: "Fix the login page CSS" }
→ Gateway: POST /api/sessions/send { sessionKey, message }
← { response: "..." }
```

### 3. List Sessions
```
GET /api/chat/sessions
→ Gateway: GET /api/sessions?kinds=subagent
← [{ sessionKey, agentId, model, lastMessage, createdAt }]
```

### 4. Get History
```
GET /api/chat/sessions/:sessionKey/history
→ Gateway: GET /api/sessions/:key/history
← [{ role, content, timestamp }]
```

### 5. Close Session
```
DELETE /api/chat/sessions/:sessionKey
→ (mark inactive in MC DB, session auto-expires in Gateway)
```

## MC Database Schema (SQLite)

### sessions table
```sql
CREATE TABLE sessions (
  id TEXT PRIMARY KEY,           -- MC-generated UUID
  session_key TEXT UNIQUE,       -- OpenClaw Gateway session key
  agent_id TEXT NOT NULL,
  model TEXT,
  title TEXT,                    -- User-editable session title
  status TEXT DEFAULT 'active',  -- active | idle | closed
  created_at TEXT DEFAULT (datetime('now')),
  last_message_at TEXT,
  message_count INTEGER DEFAULT 0
);
```

### messages table (local cache for fast UI)
```sql
CREATE TABLE messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT REFERENCES sessions(id),
  role TEXT NOT NULL,            -- user | assistant | system
  content TEXT NOT NULL,
  timestamp TEXT DEFAULT (datetime('now'))
);
```

### secrets table
```sql
CREATE TABLE secrets (
  key TEXT PRIMARY KEY,          -- e.g. "OPENROUTER_API_KEY"
  value TEXT NOT NULL,           -- encrypted blob
  label TEXT,                    -- human-friendly name
  masked TEXT,                   -- "sk-or-****2d62" for display
  updated_at TEXT DEFAULT (datetime('now'))
);
```

## Secure Settings Protocol

### GET /api/settings/secrets
Returns masked keys only:
```json
[
  { "key": "OPENROUTER_API_KEY", "label": "OpenRouter", "masked": "sk-or-****2d62" },
  { "key": "ANTHROPIC_API_KEY", "label": "Anthropic", "masked": "sk-ant-****f3a1" }
]
```

### PUT /api/settings/secrets/:key
Accepts full key, stores encrypted:
```json
{ "value": "sk-or-v1-full-key-here" }
```

### Encryption
- AES-256-GCM with key derived from user's login password via PBKDF2
- Salt stored in DB, IV per-secret
- On app start, user login unlocks the master key for the session
- Keys never returned in plaintext via API

## Frontend Chat Component

### Props
```typescript
interface AgentChatProps {
  agentId?: string;          // Pre-selected agent
  model?: string;            // Pre-selected model
  sessionKey?: string;       // Resume existing session
  allowModelSwitch?: boolean;
  allowAgentSwitch?: boolean;
}
```

### Features
- Agent selector dropdown (from /api/agents)
- Model selector dropdown (from tier defaults + available models)
- Persistent sessions (resume where you left off)
- Message history with scroll-back
- "Agent is working..." indicator during long tasks
- File change notifications (when agent modifies code)
- Error handling with retry

## Available Models (from config)
| Model | Cost Tier | Best For |
|-------|-----------|----------|
| anthropic/claude-opus-4-6 | $$$ | Architecture, complex planning |
| anthropic/claude-sonnet-4 | $$ | General dev work |
| anthropic/claude-haiku-4-5 | $ | Simple tasks, bulk ops |
| openrouter/minimax/minimax-m2.5 | $ | Coding, long context |
| xai/grok-4 | Free (API) | General, search-augmented |
| openrouter/x-ai/grok-4.1-fast | ¢ | Quick tasks |
| nvidia/moonshotai/kimi-k2-instruct | Free | Coding |

## Migration Notes
- GlobalChat.tsx → refactor to use this protocol
- ChatRoom.tsx → becomes session-based
- Agent chat panels → all use same underlying component
- Brain orchestration → can spawn sessions programmatically
