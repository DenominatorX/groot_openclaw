# Account-Based Marketing (ABM) — Requirements Document

## Current State

**What exists now:**
- `ABMPanel.tsx` with 5 tabs: Intelligence, Outreach, Scorecard, Campaign, Health
- **Intelligence Tab**: Input company name → AI generates account research (news, execs, recent activity)
- **Outreach Tab**: Input company + contacts → AI generates outreach plan
- **Scorecard Tab**: Add accounts manually, view engagement score (0-100), next action, last touched
- **Campaign Tab**: Form to create ABM campaign (name, accounts, messaging) — button does nothing
- **Health Tab**: Static cards showing Healthy/At-Risk/Cold account counts (hardcoded)

**What it actually does:**
- AI generates research and outreach plans (copy to clipboard)
- Scorecard tracks accounts in local state (not persisted)
- No account data integration, no real engagement tracking
- No campaign execution

**Missing:**
- Real account data sources (LinkedIn, Crunchbase, etc.)
- Engagement tracking and scoring automation
- Multi-channel campaign orchestration
- Account health monitoring with alerts

---

## Gap Analysis

| Feature | Current | Demandbase/Terminus | Gap |
|---------|---------|---------------------|-----|
| Account Discovery | AI research only | Real data sources | HIGH |
| Intent Data | Not supported | Website visits, content downloads | HIGH |
| Engagement Scoring | Manual only | Behavioral scoring algorithm | HIGH |
| Account Health | Hardcoded counts | Real-time monitoring | HIGH |
| Multi-channel Campaigns | Not supported | Email + social + ads + web | HIGH |
| Personalized Content | AI generation only | Dynamic content delivery | MEDIUM |
| Analytics | Not supported | Account journey, attribution | HIGH |
| CRM Integration | Not supported | Salesforce, HubSpot sync | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Account Management**
   - Add/edit/delete target accounts
   - Fields: company name, website, industry, size, location
   - Key contacts per account
   - Import from CSV

2. **Engagement Scoring**
   - Score algorithm: website visits, email engagement, content downloads, ad interactions
   - Score breakdown (what factors contributed)
   - Historical score tracking

3. **Account Health Dashboard**
   - Current: Static counts. Replace with real data
   - Health indicators: engagement trend, last activity, risk factors
   - Alert thresholds

4. **Contact Management per Account**
   - Add contacts (name, title, email, phone)
   - Contact engagement tracking
   - Org chart visualization

### P2 — Should Have
5. **Intent Data Integration**
   - Track content consumption
   - Website activity signals
   - Topic interest mapping

6. **Campaign Orchestration**
   - Create ABM campaigns with accounts and channels
   - Track channel execution status
   - Unified engagement view

7. **Personalized Content**
   - Create account-specific messaging
   - Dynamic landing pages

### P3 — Nice to Have
8. **Real Data Enrichment** — LinkedIn, Crunchbase APIs
9. **Predictive Scoring** — ML-based account scoring
10. **Advertising Integration** — LinkedIn Ads, Google Ads audiences

---

## Data Model

```typescript
interface ABMAccount {
  id: string;
  companyName: string;
  domain: string;
  industry?: string;
  companySize?: string;
  location?: string;
  revenueRange?: string;
  
  // Engagement
  engagementScore: number;
  engagementTrend: 'up' | 'down' | 'stable';
  lastActivityDate?: string;
  healthStatus: 'healthy' | 'at_risk' | 'cold';
  
  // Tracking
  sources: string[]; // where data came from
  tags: string[];
  ownerId?: string;
  
  // Metadata
  createdDate: string;
  updatedDate: string;
}

interface ABMContact {
  id: string;
  accountId: string;
  firstName: string;
  lastName: string;
  title: string;
  email: string;
  phone?: string;
  linkedIn?: string;
  
  // Engagement
  engagementScore: number;
  lastActivityDate?: string;
  
  createdDate: string;
}

interface ABMCampaign {
  id: string;
  name: string;
  description?: string;
  accountIds: string[];
  channels: ('email' | 'social' | 'ads' | 'web')[];
  
  // Messaging
  messagingAngle: string;
  templates?: {
    [channel: string]: string;
  };
  
  status: 'draft' | 'active' | 'paused' | 'completed';
  
  // Tracking
  metrics: {
    emailsSent: number;
    opens: number;
    clicks: number;
    adImpressions: number;
    webVisits: number;
  };
  
  createdDate: string;
  startDate?: string;
  endDate?: string;
}

interface EngagementActivity {
  id: string;
  accountId: string;
  contactId?: string;
  type: 'email_open' | 'email_click' | 'page_visit' | 'content_download' | 'ad_impression' | 'meeting';
  channel: string;
  timestamp: string;
  metadata?: Record<string, any>;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Account Research** | Current: Generate research. Add: Real data enrichment | P1 |
| **Outreach Planning** | Current: Generate plan. Add: Personalize by contact | P1 |
| **Scoring Insights** | AI explains score changes and recommends actions | P1 |
| **Content Recommendations** | AI suggests content for account interests | P2 |
| **Risk Prediction** | AI predicts accounts at risk of churning | P2 |

---

## UI/UX Recommendations

### Account List
- Table with score, health, last activity
- Filter by health, industry, score range
- Quick actions: View, Edit, Add to Campaign

### Account Detail
- Header: Company info, score gauge
- Tabs: Overview, Contacts, Activities, Campaigns
- Activity timeline

### Campaign Builder
- Select accounts (multi-select)
- Choose channels
- Configure messaging per channel
- Preview

---

## Acceptance Criteria

- [ ] Can add/edit/delete target accounts
- [ ] Can add contacts per account
- [ ] Engagement score calculated and displayed
- [ ] Account health shows real data
- [ ] Can create ABM campaigns with account selection
- [ ] AI generates account research
- [ ] AI generates outreach plans
- [ ] Activity tracking (mock data OK)
- [ ] Data persists to database
