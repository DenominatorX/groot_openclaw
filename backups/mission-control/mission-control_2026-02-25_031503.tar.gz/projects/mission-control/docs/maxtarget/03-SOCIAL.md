# Social Media Management — Requirements Document

## Current State

**What exists now:**
- `SocialPanel.tsx` with 6 tabs: Generator, Calendar, Hashtags, Captions, Ad Copy, Templates
- AI generation for posts, hashtags, captions
- Generator: Select platform (LinkedIn, Twitter, Facebook, Instagram, TikTok), enter topic → generate post
- Templates: Static list of post types (Quick Win, Educational, etc.)
- Calendar and Templates show "Coming Soon" placeholders

**What it actually does:**
- Generate social posts via AI → copy to clipboard
- Generate hashtags → copy to clipboard
- Generate captions for images → copy to clipboard
- No posting, no scheduling, no analytics

**Missing:**
- No social platform integration (API connections)
- No post scheduling
- No engagement tracking
- No comment/reply management
- No analytics/reporting

---

## Gap Analysis

| Feature | Current | Hootsuite/Sprout | Gap |
|---------|---------|-------------------|-----|
| Post Scheduling | Not supported | Calendar with time slots | HIGH |
| Multi-platform | Generator only | All major platforms | MEDIUM |
| Publishing | Not supported | Direct publish via APIs | HIGH |
| Engagement | Not tracked | Comments, likes, shares | HIGH |
| Analytics | Not supported | Engagement metrics, reach, impressions | HIGH |
| Content Calendar | Placeholder | Visual calendar view | HIGH |
| Asset Library | Not supported | Images, videos, docs | MEDIUM |
| Collaboration | Not supported | Team workflows, approvals | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Content Calendar**
   - Monthly/weekly view with post previews
   - Drag-and-drop rescheduling
   - Color-coded by platform
   - Filter by platform, status, campaign

2. **Post Composer**
   - Multi-platform compose (write once, adapt per platform)
   - Platform-specific character limits
   - Media attachment support (images, videos)
   - Hashtag suggestions
   - Preview per platform

3. **Scheduling**
   - Schedule posts for future publish
   - Best time suggestions
   - Recurring posts

4. **Post Library**
   - Save posts as drafts
   - Reuse past posts
   - Archive published posts

### P2 — Should Have
5. **Analytics Dashboard**
   - Engagement metrics per post
   - Follower growth
   - Best performing content
   - Platform comparison

6. **Hashtag Tools**
   - Hashtag sets by category
   - Performance tracking per hashtag
   - Trending hashtag suggestions

7. **Template Library**
   - Save custom templates
   - Industry-specific templates
   - Clone and modify

### P3 — Nice to Have
8. **Social Listening** — Keyword monitoring
9. **Competitor Tracking** — Competitor social activity
10. **Team Collaboration** — Approvals, assignments

---

## Data Model

```typescript
interface SocialPost {
  id: string;
  content: string;
  platforms: ('linkedin' | 'twitter' | 'facebook' | 'instagram' | 'tiktok')[];
  mediaUrls?: string[];
  scheduledAt?: string;
  publishedAt?: string;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  
  // Content variations per platform (auto-generated or manual)
  variations?: {
    [platform: string]: {
      content: string;
      mediaUrls?: string[];
    };
  };
  
  campaignId?: string;
  hashtags: string[];
  mentions: string[];
  link?: string;
  
  metrics?: {
    likes: number;
    comments: number;
    shares: number;
    impressions: number;
    reach: number;
    clicks: number;
  };
  
  createdDate: string;
  updatedDate: string;
}

interface ContentTemplate {
  id: string;
  name: string;
  description: string;
  category: 'announcement' | 'educational' | 'engagement' | 'promotional' | 'behind_scenes' | 'industry' | 'custom';
  platforms: string[];
  structure: string; // Template with placeholders
  usageCount: number;
  createdDate: string;
}

interface HashtagSet {
  id: string;
  name: string;
  tags: string[];
  category: string;
  usageCount: number;
}

interface SocialAnalytics {
  platform: string;
  date: string;
  followers: number;
  following: number;
  posts: number;
  engagement: {
    likes: number;
    comments: number;
    shares: number;
  };
  impressions: number;
  reach: number;
  topPosts: string[]; // Post IDs
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Post Generation** | Current: Generate from topic. Add: Platform-specific optimization | P1 |
| **Content Calendar** | AI suggests content mix by platform | P1 |
| **Hashtag Suggestions** | AI recommends hashtags based on content | P1 |
| **Best Time to Post** | AI predicts optimal posting times | P2 |
| **Engagement Prediction** | AI predicts likely engagement | P2 |
| **Content Repurposing** | AI adapts content across platforms | P2 |

---

## UI/UX Recommendations

### Calendar View
- Full-month grid with post cards
- Click day to view/add posts
- Drag posts to reschedule
- Color dots for platform

### Composer
- Left panel: Write content
- Right panel: Preview tabs per platform
- Bottom: Media gallery, hashtag picker
- Top: Platform toggles

### Analytics
- KPI cards: Followers, Engagement Rate, Reach
- Line chart: Growth over time
- Bar chart: Posts vs engagement
- Table: Top performing posts

---

## Acceptance Criteria

- [ ] Content calendar displays scheduled/published posts
- [ ] Can compose post with multi-platform variations
- [ ] Can schedule posts for future
- [ ] Post library shows all drafts and published
- [ ] Can create and use hashtag sets
- [ ] AI generates platform-optimized posts
- [ ] Analytics show engagement metrics (mock data OK)
- [ ] Mobile-responsive calendar view
