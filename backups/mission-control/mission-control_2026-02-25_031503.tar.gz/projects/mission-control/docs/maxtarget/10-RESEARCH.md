# Market Research — Requirements Document

## Current State

**What exists now:**
- `ResearchPanel.tsx` with 7 tabs: Industry, SWOT, Persona, Value Prop, Competitors, Market, Trends
- **Industry Tab**: Input industry → AI generates overview (market size, trends, key players)
- **SWOT Tab**: Input company → AI generates SWOT analysis
- **Persona Tab**: Input target market → AI builds buyer persona
- **Value Prop Tab**: Input product + audience → AI generates value proposition
- **Competitors Tab**: Input competitor → AI generates battle card
- **Market Tab**: Input TAM + market share → shows TAM/SAM/SOM calculator (static)
- **Trends Tab**: Input industry → AI identifies trends

**What it actually does:**
- AI generates research content → display → copy to clipboard
- No data storage, no real-time data, no tracking

**Missing:**
- Research library (saved analyses)
- Competitive intelligence tracking
- Ongoing market monitoring
- Data source integration

---

## Gap Analysis

| Feature | Current | Crunchbase/G2 | Gap |
|---------|---------|---------------|-----|
| Research Library | Not supported | Save, organize, version | MEDIUM |
| Competitive Intel | Single analysis | Ongoing tracking | HIGH |
| Company Data | AI estimation | Real company data | HIGH |
| Market Data | AI estimation | Real market sizing | HIGH |
| Trend Monitoring | Single analysis | Ongoing alerts | MEDIUM |
| Report Generation | Copy only | PDF, share, present | MEDIUM |

---

## Requirements

### P1 — Must Have
1. **Research Library**
   - Save AI-generated research
   - Organize by category (industry, company, topic)
   - Search and filter saved research
   - Edit and update

2. **Competitor Tracking**
   - Add competitors to track
   - Store analysis per competitor
   - Version history (track changes over time)
   - Compare competitors side-by-side

3. **Persona Manager**
   - Save generated personas
   - Edit persona details
   - Link personas to campaigns, content
   - Persona templates

### P2 — Should Have
4. **Market Sizing Tool**
   - Input TAM → calculate SAM, SOM
   - Save calculations
   - Methodology assumptions

5. **Trend Monitoring**
   - Save trend analyses
   - Set up alerts for new trends (mock)
   - Historical trend tracking

6. **Report Builder**
   - Combine research into reports
   - Export to text/markdown
   - Share links

### P3 — Nice to Have
7. **Data Integrations** — LinkedIn, Crunchbase (mock)
8. **Real-time Alerts** — Competitor news, funding
9. **Presentation Mode** — Present research in-app

---

## Data Model

```typescript
interface ResearchReport {
  id: string;
  title: string;
  type: 'industry' | 'company' | 'persona' | 'competitor' | 'market' | 'trends' | 'swot' | 'custom';
  content: string; // Markdown/JSON
  metadata?: Record<string, any>;
  
  // Organization
  tags: string[];
  folderId?: string;
  
  // Versioning
  version: number;
  previousVersions?: string[];
  
  // Status
  status: 'draft' | 'published' | 'archived';
  
  createdDate: string;
  updatedDate: string;
  createdBy?: string;
}

interface CompetitorProfile {
  id: string;
  name: string;
  domain?: string;
  industry?: string;
  
  // Analysis
  swot?: SWOTAnalysis;
  battleCard?: string;
  recentNews?: string[];
  
  // Tracking
  lastAnalyzed?: string;
  analysisHistory: Array<{
    date: string;
    content: string;
  }>;
  
  createdDate: string;
}

interface SWOTAnalysis {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

interface BuyerPersona {
  id: string;
  name: string;
  role?: string;
  
  // Demographics
  demographics: {
    ageRange?: string;
    location?: string;
    companySize?: string;
    industry?: string;
  };
  
  // Psychographics
  goals: string[];
  painPoints: string[];
  motivations: string[];
  
  // Behavior
  preferredChannels: string[];
  contentPreferences: string[];
  buyingTriggers: string[];
  
  // Used In
  linkedCampaigns?: string[];
  linkedContent?: string[];
  
  createdDate: string;
}

interface MarketSizing {
  id: string;
  name: string;
  
  // Inputs
  tam: number;
  samPercent?: number;
  somPercent?: number;
  
  // Calculated
  sam?: number;
  som?: number;
  
  // Methodology
  assumptions?: string;
  sources?: string[];
  
  createdDate: string;
}

interface TrendAnalysis {
  id: string;
  industry: string;
  trends: Trend[];
  
  analyzedAt: string;
}

interface Trend {
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  timeframe: string;
}
```

---

## AI Integration Points

| Use Case | Description | Priority |
|----------|-------------|----------|
| **Research Generation** | Current: Generate once. Add: Save, version, update | P1 |
| **Competitor Analysis** | Current: Single analysis. Add: Track over time | P1 |
| **Persona Building** | Current: Generate. Add: Data-backed with sources | P2 |
| **Trend Identification** | Current: Single. Add: Ongoing monitoring | P2 |

---

## UI/UX Recommendations

### Research Library
- List/grid view
- Filter by type, tags
- Search by title, content
- Quick actions: Edit, Duplicate, Delete

### Competitor Detail
- Header: Name, domain, last analyzed
- Tabs: Overview, SWOT, Battle Card, News, History
- Compare button → select other competitor

### Persona Card
- Profile view with sections
- Edit mode for all fields
- Used in: Campaigns, Content badges

---

## Acceptance Criteria

- [ ] Can save AI-generated research
- [ ] Can view, edit, delete saved research
- [ ] Can add and track competitors
- [ ] Competitor analysis has version history
- [ ] Can create and save buyer personas
- [ ] Market sizing calculator works
- [ ] Research library searchable
- [ ] Data persists to database
