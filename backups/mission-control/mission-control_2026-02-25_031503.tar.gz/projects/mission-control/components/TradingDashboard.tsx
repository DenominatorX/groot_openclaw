'use client';
import { useState, useEffect, useCallback } from 'react';

type SubTab = 'portfolio' | 'market' | 'history' | 'analytics' | 'learning' | 'tax' | 'balance' | 'audit';

interface Holding { asset: string; amount: number; avgCost: number; currentPrice: number; }
interface WatchItem { asset: string; price: number; change24h: number; sentiment: string; sparkline: number[]; }
interface Trade { id: string; date: string; asset: string; type: string; amount: number; price: number; total: number; pnl: number; rationale: string; }
interface AuditEntry { id: string; timestamp: string; action: string; actor: string; detail: string; reason: string; }
interface TaxConfig { costBasisMethod: string; shortTermRate: number; longTermRate: number; stateRate: number; disclaimer: string; }

export default function TradingDashboard() {
  const [sub, setSub] = useState<SubTab>('portfolio');
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [watchlist, setWatchlist] = useState<WatchItem[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [taxConfig, setTaxConfig] = useState<TaxConfig | null>(null);
  const [paperMode, setPaperMode] = useState(true);
  const [cashBalance, setCashBalance] = useState(0);
  const [showLiveConfirm, setShowLiveConfirm] = useState(false);
  const [filterAsset, setFilterAsset] = useState('');
  const [filterType, setFilterType] = useState('');
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [taxReport, setTaxReport] = useState<Record<string, string> | null>(null);

  const load = useCallback(async () => {
    const r = await fetch('/api/trading');
    if (!r.ok) return;
    const d = await r.json();
    if (d.portfolio) {
      setHoldings(d.portfolio.holdings || []);
      setWatchlist(d.portfolio.watchlist || []);
      setPaperMode(d.portfolio.settings?.paperMode ?? true);
      setCashBalance(d.portfolio.cashBalance || 0);
    }
    setTrades(d.trades || []);
    setAudit(d.audit || []);
    setTaxConfig(d.taxConfig || null);
  }, []);

  useEffect(() => { load(); }, [load]);

  const totalValue = holdings.reduce((s, h) => s + h.amount * h.currentPrice, 0) + cashBalance;
  const totalCost = holdings.reduce((s, h) => s + h.amount * h.avgCost, 0) + cashBalance;
  const totalPnl = totalValue - totalCost;
  const totalPnlPct = totalCost > 0 ? (totalPnl / totalCost) * 100 : 0;

  const togglePaperMode = async () => {
    if (paperMode) { setShowLiveConfirm(true); return; }
    await fetch('/api/trading', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'toggle-paper-mode', paperMode: true }) });
    setPaperMode(true);
  };

  const confirmLive = async () => {
    await fetch('/api/trading', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'toggle-paper-mode', paperMode: false, reason: 'User confirmed live trading' }) });
    setPaperMode(false);
    setShowLiveConfirm(false);
  };

  const exportCSV = () => {
    const header = 'Date,Asset,Type,Amount,Price,Total,P&L,Rationale\n';
    const rows = filteredTrades.map(t => `${t.date},${t.asset},${t.type},${t.amount},${t.price},${t.total},${t.pnl},"${t.rationale}"`).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'trades.csv'; a.click();
  };

  const genTaxReport = async () => {
    const r = await fetch('/api/trading', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'generate-tax-report' }) });
    const d = await r.json();
    setTaxReport(d.report);
  };

  const exportAudit = () => {
    const header = 'Timestamp,Action,Actor,Detail,Reason\n';
    const rows = audit.map(a => `${a.timestamp},${a.action},${a.actor},"${a.detail}","${a.reason}"`).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const el = document.createElement('a'); el.href = URL.createObjectURL(blob); el.download = 'audit.csv'; el.click();
  };

  const filteredTrades = trades.filter(t => {
    if (filterAsset && t.asset !== filterAsset) return false;
    if (filterType === 'buy' && t.type !== 'buy') return false;
    if (filterType === 'sell' && t.type !== 'sell') return false;
    if (filterType === 'profit' && t.pnl < 0) return false;
    if (filterType === 'loss' && t.pnl >= 0) return false;
    return true;
  });

  const winningTrades = trades.filter(t => t.pnl > 0);
  const losingTrades = trades.filter(t => t.pnl < 0);
  const winRate = trades.length > 0 ? (winningTrades.length / trades.length) * 100 : 0;
  const avgProfit = trades.length > 0 ? trades.reduce((s, t) => s + t.pnl, 0) / trades.length : 0;
  const largestWin = trades.length > 0 ? Math.max(...trades.map(t => t.pnl)) : 0;
  const largestLoss = trades.length > 0 ? Math.min(...trades.map(t => t.pnl)) : 0;

  // Streak calc
  let streak = 0, streakType = '';
  for (let i = trades.length - 1; i >= 0; i--) {
    const w = trades[i].pnl >= 0;
    if (i === trades.length - 1) { streakType = w ? 'win' : 'loss'; streak = 1; }
    else if ((w && streakType === 'win') || (!w && streakType === 'loss')) streak++;
    else break;
  }

  const subTabs: { id: SubTab; label: string; icon: string }[] = [
    { id: 'portfolio', label: 'Portfolio', icon: '💼' },
    { id: 'market', label: 'Market Watch', icon: '👁️' },
    { id: 'history', label: 'Trade History', icon: '📜' },
    { id: 'analytics', label: 'Analytics', icon: '📊' },
    { id: 'learning', label: 'Learning', icon: '🎓' },
    { id: 'tax', label: 'Tax', icon: '🧾' },
    { id: 'balance', label: 'Balance Sheet', icon: '📒' },
    { id: 'audit', label: 'Audit Trail', icon: '🔍' },
  ];

  const fmt = (n: number) => n.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  const fmtPct = (n: number) => `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`;
  const clr = (n: number) => n >= 0 ? 'text-green-500' : 'text-red-500';

  const Sparkline = ({ data }: { data: number[] }) => {
    const max = Math.max(...data), min = Math.min(...data), range = max - min || 1;
    return (
      <div className="flex items-end gap-px h-6">
        {data.map((v, i) => (
          <div key={i} className="w-1.5 bg-indigo-500 rounded-t" style={{ height: `${((v - min) / range) * 100}%`, minHeight: '2px' }} />
        ))}
      </div>
    );
  };

  const PieChart = () => {
    const total = holdings.reduce((s, h) => s + h.amount * h.currentPrice, 0) + cashBalance;
    const colors = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];
    const items = [...holdings.map(h => ({ label: h.asset, value: h.amount * h.currentPrice })), { label: 'Cash', value: cashBalance }];
    let cumPct = 0;
    const segments = items.map((item, i) => {
      const pct = (item.value / total) * 100;
      const start = cumPct;
      cumPct += pct;
      return { ...item, pct, start, color: colors[i % colors.length] };
    });
    const gradientParts = segments.map(s => `${s.color} ${s.start}% ${s.start + s.pct}%`).join(', ');
    return (
      <div className="flex items-center gap-4">
        <div className="w-24 h-24 rounded-full flex-shrink-0" style={{ background: `conic-gradient(${gradientParts})` }} />
        <div className="flex flex-col gap-1 text-xs">
          {segments.map(s => (
            <div key={s.label} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded" style={{ background: s.color }} />
              <span className="text-mc-text">{s.label}</span>
              <span className="text-mc-muted font-mono">{s.pct.toFixed(1)}%</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const BarChart = ({ data, labels }: { data: number[]; labels: string[] }) => {
    const max = Math.max(...data.map(Math.abs), 1);
    return (
      <div className="flex items-end gap-2 h-32">
        {data.map((v, i) => (
          <div key={i} className="flex flex-col items-center flex-1">
            <div className={`w-full rounded-t ${v >= 0 ? 'bg-green-500' : 'bg-red-500'}`} style={{ height: `${(Math.abs(v) / max) * 100}%`, minHeight: '2px' }} />
            <span className="text-[10px] text-mc-muted mt-1">{labels[i]}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Paper mode badge */}
      {paperMode && (
        <div className="flex justify-end">
          <div className="px-3 py-1 bg-amber-500/20 border border-amber-500/50 rounded text-amber-400 text-xs font-bold">
            📄 PAPER TRADING MODE
          </div>
        </div>
      )}

      {/* Sub-tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        {subTabs.map(t => (
          <button key={t.id} onClick={() => setSub(t.id)}
            className={`px-3 py-1.5 rounded text-xs whitespace-nowrap transition-colors ${sub === t.id ? 'bg-indigo-600 text-white' : 'bg-mc-surface border border-mc-border text-mc-muted hover:text-mc-text'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* PORTFOLIO */}
      {sub === 'portfolio' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <div className="text-mc-muted text-xs mb-1">Total Portfolio Value</div>
              <div className="text-3xl font-bold font-mono text-mc-text">{fmt(totalValue)}</div>
              <div className={`text-sm font-mono ${clr(totalPnl)}`}>{fmt(totalPnl)} ({fmtPct(totalPnlPct)})</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <div className="text-mc-muted text-xs mb-1">Cash Balance</div>
              <div className="text-2xl font-bold font-mono text-mc-text">{fmt(cashBalance)}</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <div className="text-mc-muted text-xs mb-2">Mode</div>
              <button onClick={togglePaperMode} className={`px-4 py-2 rounded text-sm font-bold ${paperMode ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50' : 'bg-red-500/20 text-red-400 border border-red-500/50'}`}>
                {paperMode ? '📄 Paper Trading' : '🔴 LIVE Trading'}
              </button>
              <div className="text-[10px] text-mc-muted mt-1">Click to toggle</div>
            </div>
          </div>

          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold mb-3 text-mc-text">Asset Allocation</h3>
            <PieChart />
          </div>

          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 overflow-x-auto">
            <h3 className="text-sm font-bold mb-3 text-mc-text">Holdings</h3>
            <table className="w-full text-xs">
              <thead><tr className="text-mc-muted border-b border-mc-border">
                <th className="text-left py-2">Asset</th><th className="text-right">Amount</th><th className="text-right">Value</th><th className="text-right">24h%</th><th className="text-right">Avg Cost</th><th className="text-right">P&L</th><th className="text-right">P&L%</th>
              </tr></thead>
              <tbody>
                {holdings.map(h => {
                  const val = h.amount * h.currentPrice;
                  const cost = h.amount * h.avgCost;
                  const pnl = val - cost;
                  const pnlPct = cost > 0 ? (pnl / cost) * 100 : 0;
                  const w = watchlist.find(w => w.asset === h.asset);
                  return (
                    <tr key={h.asset} className="border-b border-mc-border/30">
                      <td className="py-2 font-bold text-mc-text">{h.asset}</td>
                      <td className="text-right font-mono">{h.amount}</td>
                      <td className="text-right font-mono">{fmt(val)}</td>
                      <td className={`text-right font-mono ${clr(w?.change24h || 0)}`}>{fmtPct(w?.change24h || 0)}</td>
                      <td className="text-right font-mono">{fmt(h.avgCost)}</td>
                      <td className={`text-right font-mono ${clr(pnl)}`}>{fmt(pnl)}</td>
                      <td className={`text-right font-mono ${clr(pnlPct)}`}>{fmtPct(pnlPct)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MARKET WATCH */}
      {sub === 'market' && (
        <div className="space-y-4">
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-mc-text">Watchlist</h3>
              <button className="px-3 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-500">+ Add to Watchlist</button>
            </div>
            <div className="space-y-2">
              {watchlist.map(w => (
                <div key={w.asset} className="flex items-center justify-between p-3 bg-mc-bg rounded border border-mc-border/30">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-mc-text text-sm">{w.asset}</span>
                    <span className={`text-xs px-2 py-0.5 rounded ${w.sentiment === 'Bullish' ? 'bg-green-500/20 text-green-400' : w.sentiment === 'Bearish' ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'}`}>
                      {w.sentiment === 'Bullish' ? '🟢' : w.sentiment === 'Bearish' ? '🔴' : '🟡'} {w.sentiment}
                    </span>
                  </div>
                  <div className="flex items-center gap-4">
                    <Sparkline data={w.sparkline} />
                    <div className="text-right">
                      <div className="font-mono text-sm text-mc-text">{w.price < 1 ? `$${w.price}` : fmt(w.price)}</div>
                      <div className={`font-mono text-xs ${clr(w.change24h)}`}>{fmtPct(w.change24h)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">🔥 Top Movers</h3>
            <div className="flex gap-3 flex-wrap">
              {[...watchlist].sort((a, b) => Math.abs(b.change24h) - Math.abs(a.change24h)).slice(0, 3).map(w => (
                <div key={w.asset} className="px-4 py-2 bg-mc-bg rounded border border-mc-border/30">
                  <span className="font-bold text-mc-text">{w.asset}</span>
                  <span className={`ml-2 font-mono text-sm ${clr(w.change24h)}`}>{fmtPct(w.change24h)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TRADE HISTORY */}
      {sub === 'history' && (
        <div className="space-y-4">
          <div className="flex gap-2 flex-wrap items-center">
            <select value={filterAsset} onChange={e => setFilterAsset(e.target.value)} className="bg-mc-surface border border-mc-border text-mc-text text-xs rounded px-2 py-1">
              <option value="">All Assets</option>
              {[...new Set(trades.map(t => t.asset))].map(a => <option key={a} value={a}>{a}</option>)}
            </select>
            <select value={filterType} onChange={e => setFilterType(e.target.value)} className="bg-mc-surface border border-mc-border text-mc-text text-xs rounded px-2 py-1">
              <option value="">All Types</option>
              <option value="buy">Buy</option><option value="sell">Sell</option>
              <option value="profit">Profit</option><option value="loss">Loss</option>
            </select>
            <button onClick={exportCSV} className="px-3 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-500">📥 Export CSV</button>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="text-mc-muted border-b border-mc-border">
                <th className="text-left py-2">Date</th><th className="text-left">Asset</th><th className="text-left">Type</th><th className="text-right">Amount</th><th className="text-right">Price</th><th className="text-right">Total</th><th className="text-right">P&L</th><th className="text-left">Rationale</th>
              </tr></thead>
              <tbody>
                {filteredTrades.map(t => (
                  <tr key={t.id} className="border-b border-mc-border/30 cursor-pointer hover:bg-mc-bg" onClick={() => setSelectedTrade(t)}>
                    <td className="py-2 font-mono">{new Date(t.date).toLocaleDateString()}</td>
                    <td className="font-bold">{t.asset}</td>
                    <td><span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${t.type === 'buy' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{t.type.toUpperCase()}</span></td>
                    <td className="text-right font-mono">{t.amount}</td>
                    <td className="text-right font-mono">{fmt(t.price)}</td>
                    <td className="text-right font-mono">{fmt(t.total)}</td>
                    <td className={`text-right font-mono ${clr(t.pnl)}`}>{fmt(t.pnl)}</td>
                    <td className="text-mc-muted max-w-[200px] truncate">{t.rationale}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {selectedTrade && (
            <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setSelectedTrade(null)}>
              <div className="bg-mc-surface border border-mc-border rounded-xl max-w-lg w-full p-6" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between mb-4">
                  <h3 className="font-bold text-mc-text">🐍 Why did Viper do this?</h3>
                  <button onClick={() => setSelectedTrade(null)} className="text-mc-muted hover:text-mc-text">✕</button>
                </div>
                <div className="space-y-2 text-sm">
                  <div><span className="text-mc-muted">Trade:</span> <span className={`font-bold ${selectedTrade.type === 'buy' ? 'text-green-400' : 'text-red-400'}`}>{selectedTrade.type.toUpperCase()}</span> {selectedTrade.amount} {selectedTrade.asset} @ {fmt(selectedTrade.price)}</div>
                  <div><span className="text-mc-muted">Date:</span> {new Date(selectedTrade.date).toLocaleString()}</div>
                  <div><span className="text-mc-muted">P&L:</span> <span className={clr(selectedTrade.pnl)}>{fmt(selectedTrade.pnl)}</span></div>
                  <div className="mt-3 p-3 bg-mc-bg rounded border border-mc-border/30">
                    <div className="text-mc-muted text-xs mb-1">Viper&apos;s Rationale:</div>
                    <div className="text-mc-text">{selectedTrade.rationale}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ANALYTICS */}
      {sub === 'analytics' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'Win Rate', value: `${winRate.toFixed(1)}%`, color: winRate >= 50 ? 'text-green-500' : 'text-red-500' },
              { label: 'Avg Profit/Trade', value: fmt(avgProfit), color: clr(avgProfit) },
              { label: 'Largest Win', value: fmt(largestWin), color: 'text-green-500' },
              { label: 'Largest Loss', value: fmt(largestLoss), color: 'text-red-500' },
              { label: 'Total Trades', value: String(trades.length), color: 'text-mc-text' },
              { label: 'Winning', value: String(winningTrades.length), color: 'text-green-500' },
              { label: 'Losing', value: String(losingTrades.length), color: 'text-red-500' },
              { label: `Streak (${streakType})`, value: String(streak), color: streakType === 'win' ? 'text-green-500' : 'text-red-500' },
            ].map(s => (
              <div key={s.label} className="bg-mc-surface border border-mc-border rounded-lg p-3">
                <div className="text-mc-muted text-[10px]">{s.label}</div>
                <div className={`text-xl font-bold font-mono ${s.color}`}>{s.value}</div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-2">Sharpe Ratio</h3>
              <div className="text-2xl font-mono text-mc-muted">—</div>
              <div className="text-[10px] text-mc-muted">Requires 30+ trades</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-2">Risk/Reward</h3>
              <div className="text-2xl font-mono text-mc-text">{losingTrades.length > 0 ? (largestWin / Math.abs(largestLoss)).toFixed(2) : '—'}</div>
            </div>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">Monthly Performance</h3>
            <BarChart data={[320, -50, 180, 400, -120, 250]} labels={['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb']} />
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-2">Max Drawdown</h3>
            <div className="text-2xl font-mono text-red-500">-{((Math.abs(largestLoss) / totalValue) * 100).toFixed(2)}%</div>
            <div className="text-[10px] text-mc-muted">From peak portfolio value</div>
          </div>
        </div>
      )}

      {/* LEARNING CENTER */}
      {sub === 'learning' && (
        <div className="space-y-4">
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">🐍 Viper&apos;s Trade Journal</h3>
            <div className="space-y-3">
              {trades.slice(-3).reverse().map(t => (
                <div key={t.id} className="p-3 bg-mc-bg rounded border border-mc-border/30">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold text-mc-text">{t.type.toUpperCase()} {t.asset}</span>
                    <span className="text-mc-muted">{new Date(t.date).toLocaleDateString()}</span>
                  </div>
                  <p className="text-xs text-mc-text">{t.rationale}</p>
                  <div className={`text-xs font-mono mt-1 ${clr(t.pnl)}`}>Result: {fmt(t.pnl)}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">📚 Trading Concepts</h3>
            <div className="space-y-2 text-xs">
              {[
                { term: 'RSI (Relative Strength Index)', def: 'Momentum oscillator measuring speed/change of price movements. Below 30 = oversold, above 70 = overbought.' },
                { term: 'Support/Resistance', def: 'Price levels where buying (support) or selling (resistance) pressure historically concentrates.' },
                { term: 'Stop-Loss', def: 'Predetermined price to exit a losing position to limit downside risk.' },
                { term: 'Dollar Cost Averaging (DCA)', def: 'Investing fixed amounts at regular intervals regardless of price to reduce volatility impact.' },
                { term: 'HODL', def: 'Crypto slang for holding assets long-term rather than trading actively.' },
              ].map(c => (
                <div key={c.term} className="p-2 bg-mc-bg rounded">
                  <span className="font-bold text-indigo-400">{c.term}:</span>{' '}
                  <span className="text-mc-text">{c.def}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">⚠️ Risk Management Lessons</h3>
            <ul className="text-xs text-mc-text space-y-1 list-disc list-inside">
              <li>Never risk more than 2% of portfolio on a single trade</li>
              <li>Always set stop-losses before entering a position</li>
              <li>Diversify across uncorrelated assets</li>
              <li>Paper trade new strategies before going live</li>
              <li>Keep emotions out — stick to the plan</li>
            </ul>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">📐 Market Patterns</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {['Double Bottom', 'Head & Shoulders', 'Bull Flag', 'Cup & Handle', 'Ascending Triangle', 'Descending Wedge'].map(p => (
                <div key={p} className="p-2 bg-mc-bg rounded text-mc-text text-center border border-mc-border/30">{p}</div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAX & COMPLIANCE */}
      {sub === 'tax' && (
        <div className="space-y-4">
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded text-amber-400 text-xs">
            ⚠️ {taxConfig?.disclaimer || 'Not financial advice. Tax calculations are ESTIMATES only. Consult a tax professional.'}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-3">Cost Basis Method</h3>
              <div className="flex gap-2">
                {['FIFO', 'LIFO', 'Specific ID'].map(m => (
                  <button key={m} className={`px-3 py-1.5 rounded text-xs ${taxConfig?.costBasisMethod === m ? 'bg-indigo-600 text-white' : 'bg-mc-bg border border-mc-border text-mc-muted'}`}>{m}</button>
                ))}
              </div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-3">Tax Rates</h3>
              <div className="text-xs space-y-1">
                <div className="flex justify-between"><span className="text-mc-muted">Short-term (&lt;1yr):</span><span className="font-mono">{((taxConfig?.shortTermRate || 0) * 100).toFixed(0)}%</span></div>
                <div className="flex justify-between"><span className="text-mc-muted">Long-term (&gt;1yr):</span><span className="font-mono">{((taxConfig?.longTermRate || 0) * 100).toFixed(0)}%</span></div>
                <div className="flex justify-between"><span className="text-mc-muted">State:</span><span className="font-mono">{((taxConfig?.stateRate || 0) * 100).toFixed(0)}%</span></div>
              </div>
            </div>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-mc-text">Transaction Log (Tax Format)</h3>
              <button onClick={genTaxReport} className="px-3 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-500">📋 Generate Tax Report</button>
            </div>
            <table className="w-full text-xs">
              <thead><tr className="text-mc-muted border-b border-mc-border">
                <th className="text-left py-2">Date</th><th className="text-left">Asset</th><th className="text-left">Type</th><th className="text-right">Amount</th><th className="text-right">Proceeds</th><th className="text-right">Cost Basis</th><th className="text-right">Gain/Loss</th><th className="text-left">Term</th>
              </tr></thead>
              <tbody>
                {trades.map(t => {
                  const daysSince = Math.floor((Date.now() - new Date(t.date).getTime()) / 86400000);
                  const term = daysSince > 365 ? 'Long' : 'Short';
                  return (
                    <tr key={t.id} className="border-b border-mc-border/30">
                      <td className="py-2 font-mono">{new Date(t.date).toLocaleDateString()}</td>
                      <td>{t.asset}</td>
                      <td>{t.type.toUpperCase()}</td>
                      <td className="text-right font-mono">{t.amount}</td>
                      <td className="text-right font-mono">{fmt(t.total + t.pnl)}</td>
                      <td className="text-right font-mono">{fmt(t.total)}</td>
                      <td className={`text-right font-mono ${clr(t.pnl)}`}>{fmt(t.pnl)}</td>
                      <td><span className={`text-[10px] px-1 py-0.5 rounded ${term === 'Long' ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'}`}>{term}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {taxReport && (
            <div className="bg-mc-surface border border-indigo-500/50 rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-3">📊 Tax Report Summary</h3>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div><span className="text-mc-muted">Total Gains:</span> <span className="text-green-500 font-mono">${taxReport.totalGains}</span></div>
                <div><span className="text-mc-muted">Total Losses:</span> <span className="text-red-500 font-mono">${taxReport.totalLosses}</span></div>
                <div><span className="text-mc-muted">Net:</span> <span className={`font-mono ${Number(taxReport.netGainLoss) >= 0 ? 'text-green-500' : 'text-red-500'}`}>${taxReport.netGainLoss}</span></div>
                <div><span className="text-mc-muted">Est. Tax:</span> <span className="text-amber-400 font-mono">${taxReport.estimatedTax}</span></div>
                <div className="col-span-2"><span className="text-mc-muted">Method:</span> {taxReport.costBasisMethod}</div>
              </div>
            </div>
          )}
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-2">🔍 Wash Sale Detector</h3>
            <p className="text-xs text-mc-muted">No wash sales detected. Viper monitors 30-day windows around losses to flag potential wash sale violations.</p>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-2">📋 IRS Compliance Notes</h3>
            <ul className="text-xs text-mc-muted space-y-1 list-disc list-inside">
              <li>Cryptocurrency is treated as property by the IRS</li>
              <li>Every trade (including crypto-to-crypto) is a taxable event</li>
              <li>Report on Form 8949 and Schedule D</li>
              <li>Keep records for at least 3 years (6 years recommended)</li>
            </ul>
          </div>
        </div>
      )}

      {/* BALANCE SHEET */}
      {sub === 'balance' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-green-400 mb-3">Assets</h3>
              <div className="space-y-2 text-xs">
                {holdings.map(h => (
                  <div key={h.asset} className="flex justify-between">
                    <span className="text-mc-text">{h.asset}</span>
                    <span className="font-mono">{fmt(h.amount * h.currentPrice)}</span>
                  </div>
                ))}
                <div className="flex justify-between">
                  <span className="text-mc-text">Cash</span>
                  <span className="font-mono">{fmt(cashBalance)}</span>
                </div>
                <div className="border-t border-mc-border pt-2 flex justify-between font-bold">
                  <span>Total Assets</span>
                  <span className="font-mono">{fmt(totalValue)}</span>
                </div>
              </div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-red-400 mb-3">Liabilities</h3>
              <div className="text-xs text-mc-muted py-4 text-center">No liabilities</div>
              <div className="border-t border-mc-border pt-2 flex justify-between font-bold text-xs">
                <span>Net Worth (Trading)</span>
                <span className="font-mono text-green-400">{fmt(totalValue)}</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-1">Unrealized Gains</h3>
              <div className={`text-2xl font-mono font-bold ${clr(totalPnl)}`}>{fmt(totalPnl)}</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold text-mc-text mb-1">Realized Gains</h3>
              <div className="text-2xl font-mono font-bold text-mc-muted">$0.00</div>
              <div className="text-[10px] text-mc-muted">No closed positions yet</div>
            </div>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold text-mc-text mb-3">Historical Net Worth</h3>
            <BarChart data={[9800, 9950, 10100, 10250, 10450, 10600, totalValue]} labels={['Feb 7', 'Feb 8', 'Feb 9', 'Feb 10', 'Feb 11', 'Feb 12', 'Today']} />
          </div>
        </div>
      )}

      {/* AUDIT TRAIL */}
      {sub === 'audit' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-mc-text">Audit Trail</h3>
            <button onClick={exportAudit} className="px-3 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-500">📥 Export Audit Log</button>
          </div>
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <div className="space-y-2">
              {[...audit].reverse().map(a => (
                <div key={a.id} className="flex items-start gap-3 p-2 bg-mc-bg rounded border border-mc-border/30 text-xs">
                  <span className="text-mc-muted font-mono whitespace-nowrap">{new Date(a.timestamp).toLocaleString()}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${a.action === 'trade' ? 'bg-indigo-500/20 text-indigo-400' : 'bg-amber-500/20 text-amber-400'}`}>{a.action}</span>
                  <span className="text-mc-text font-bold">{a.actor}</span>
                  <span className="text-mc-text flex-1">{a.detail}</span>
                  <span className="text-mc-muted">{a.reason}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 text-[10px] text-mc-muted text-center">🔒 Immutable audit log — entries cannot be modified or deleted</div>
          </div>
        </div>
      )}

      {/* Live trading confirmation modal */}
      {showLiveConfirm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setShowLiveConfirm(false)}>
          <div className="bg-mc-surface border border-red-500/50 rounded-xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-red-400 mb-2">⚠️ Enable Live Trading?</h3>
            <p className="text-sm text-mc-text mb-4">This will switch from paper trading to LIVE mode. Real funds will be at risk. Are you absolutely sure?</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setShowLiveConfirm(false)} className="px-4 py-2 bg-mc-bg border border-mc-border text-mc-text rounded text-sm">Cancel</button>
              <button onClick={confirmLive} className="px-4 py-2 bg-red-600 text-white rounded text-sm font-bold hover:bg-red-500">🔴 Enable Live Trading</button>
            </div>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="text-center text-[10px] text-mc-muted pt-2 border-t border-mc-border/30">
        Not financial advice. Consult a tax professional. All trading data shown is for educational purposes.
      </div>
    </div>
  );
}
