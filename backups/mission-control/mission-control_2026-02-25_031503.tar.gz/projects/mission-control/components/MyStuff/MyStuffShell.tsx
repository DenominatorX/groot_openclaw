'use client';
import { useState } from 'react';
import ResearchTab from './ResearchTab';
import NotesTab from './NotesTab';
import BookmarksTab from './BookmarksTab';
import FilesTab from './FilesTab';

const tabs = ['Research', 'Notes', 'Bookmarks', 'Files'] as const;

type Tab = (typeof tabs)[number];
export default function MyStuffShell() {
  const [tab, setTab] = useState<Tab>('Research');
  return (
    <div className="p-6 space-y-4">
      <h2 className="text-xl font-bold text-mc-text">🗂️ My Stuff</h2>
      <div className="flex gap-2 flex-wrap">{tabs.map((t) => <button key={t} onClick={() => setTab(t)} className={`px-3 py-1 rounded border ${tab===t?'border-mc-accent text-mc-accent':'border-mc-border text-mc-muted'}`}>{t}</button>)}</div>
      {tab === 'Research' && <ResearchTab />}
      {tab === 'Notes' && <NotesTab />}
      {tab === 'Bookmarks' && <BookmarksTab />}
      {tab === 'Files' && <FilesTab />}
    </div>
  );
}
