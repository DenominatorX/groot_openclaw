'use client';
import { useEffect, useState } from 'react';
import MyStuffCard from './MyStuffCard';

type Item = { id: string; title?: string; content?: string; metadata?: string };
export default function BookmarksTab() {
  const [items, setItems] = useState<Item[]>([]);
  const [url, setUrl] = useState('');
  const [label, setLabel] = useState('');
  const load = async () => { const r = await fetch('/api/my-stuff?type=bookmark'); const j = await r.json(); setItems(j.items || []); };
  useEffect(() => { load(); }, []);
  const add = async () => { if (!url.trim()) return; await fetch('/api/my-stuff', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'bookmark', title: label || url, content: url, metadata: { url } }) }); setUrl(''); setLabel(''); load(); };
  const del = async (id: string) => { await fetch(`/api/my-stuff/${id}`, { method: 'DELETE' }); load(); };
  return <div className="space-y-4"><div className="flex gap-2 flex-wrap"><input value={url} onChange={(e)=>setUrl(e.target.value)} placeholder="https://..." className="flex-1 min-w-[260px] px-3 py-2 rounded bg-mc-surface border border-mc-border"/><input value={label} onChange={(e)=>setLabel(e.target.value)} placeholder="Label (optional)" className="px-3 py-2 rounded bg-mc-surface border border-mc-border"/><button onClick={add} className="px-3 py-2 rounded bg-mc-accent text-black">Save</button></div><div className="grid grid-cols-1 md:grid-cols-2 gap-3">{items.map(i=>{let md:any={}; try{md=JSON.parse(i.metadata||'{}')}catch{} const u=md.url||i.content||''; return <MyStuffCard key={i.id}><div className="flex justify-between"><a href={u} target="_blank" className="text-mc-accent">{i.title}</a><button onClick={()=>del(i.id)} className="text-red-400">Delete</button></div><div className="text-xs text-mc-muted break-all">{u}</div></MyStuffCard>})}</div></div>;
}
