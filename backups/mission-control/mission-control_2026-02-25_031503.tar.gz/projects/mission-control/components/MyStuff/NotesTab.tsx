'use client';
import { useEffect, useState } from 'react';
import MyStuffCard from './MyStuffCard';

type Item = { id: string; title?: string; content?: string; updated_at?: number };
export default function NotesTab() {
  const [items, setItems] = useState<Item[]>([]);
  const [text, setText] = useState('');
  const load = async () => { const r = await fetch('/api/my-stuff?type=note'); const j = await r.json(); setItems(j.items || []); };
  useEffect(() => { load(); }, []);
  const add = async () => { if (!text.trim()) return; await fetch('/api/my-stuff', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'note', title: text.slice(0, 40), content: text }) }); setText(''); load(); };
  const del = async (id: string) => { await fetch(`/api/my-stuff/${id}`, { method: 'DELETE' }); load(); };
  return <div className="space-y-4"><div className="flex gap-2"><textarea value={text} onChange={(e)=>setText(e.target.value)} className="w-full rounded bg-mc-surface border border-mc-border p-2" placeholder="Quick note..." /><button onClick={add} className="px-3 py-2 rounded bg-mc-accent text-black">Save</button></div><div className="space-y-2">{items.map(i=><MyStuffCard key={i.id}><div className="flex justify-between"><div><div className="font-medium">{i.title}</div><div className="text-sm text-mc-muted">{i.content}</div></div><button onClick={()=>del(i.id)} className="text-red-400">Delete</button></div></MyStuffCard>)}</div></div>;
}
