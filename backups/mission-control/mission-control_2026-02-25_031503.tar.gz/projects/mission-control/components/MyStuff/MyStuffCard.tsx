'use client';

export default function MyStuffCard({ children }: { children: React.ReactNode }) {
  return <div className="bg-mc-surface border border-mc-border rounded-lg p-4">{children}</div>;
}
