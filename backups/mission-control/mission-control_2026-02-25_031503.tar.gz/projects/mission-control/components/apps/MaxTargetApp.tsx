'use client';
import { useState } from 'react';
import DashboardPanel from './maxtarget/DashboardPanel';
import PipelinePanel from './maxtarget/PipelinePanel';
import CampaignPanel from './maxtarget/CampaignPanel';
import AnalyticsPanel from './maxtarget/AnalyticsPanel';
import CompetitorPanel from './maxtarget/CompetitorPanel';
import SEOPanel from './maxtarget/SEOPanel';
import SocialPanel from './maxtarget/SocialPanel';
import EmailPanel from './maxtarget/EmailPanel';
import AdPanel from './maxtarget/AdPanel';
import ResearchPanel from './maxtarget/ResearchPanel';
import ReportingPanel from './maxtarget/ReportingPanel';
import ClientReportPanel from './maxtarget/ClientReportPanel';
import BrandPanel from './maxtarget/BrandPanel';
import ConversionPanel from './maxtarget/ConversionPanel';
import ABMPanel from './maxtarget/ABMPanel';
import AutomationPanel from './maxtarget/AutomationPanel';
import IntelPanel from './maxtarget/IntelPanel';

export default function MaxTargetApp() {
  const [tab, setTab] = useState<'dashboard' | 'pipeline' | 'campaigns' | 'analytics' | 'reports' | 'competitors' | 'intel' | 'seo' | 'social' | 'email' | 'ads' | 'research' | 'reporting' | 'brand' | 'conversion' | 'abm' | 'automation'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header with Logo */}
      <div className="flex items-center gap-4 mb-6">
        <img src="/maxtarget-logo.png" alt="MaxTarget" className="h-16 w-auto" />
        <div>
          <h1 className="text-2xl font-bold text-white">MaxTarget</h1>
          <p className="text-gray-400 text-sm">Marketing Command Center — SpecTarget on Steroids</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-4 text-sm">
        {[
          { id: 'dashboard', label: '📊 Dashboard' },
          { id: 'pipeline', label: '📊 Pipeline' },
          { id: 'campaigns', label: '📈 Campaigns' },
          { id: 'analytics', label: '📉 Analytics' },
          { id: 'reports', label: '📄 Reports' },
          { id: 'competitors', label: '🔍 Competitors' },
          { id: 'intel', label: '🕵️ Intel' },
          { id: 'seo', label: '🔎 SEO' },
          { id: 'social', label: '📱 Social' },
          { id: 'email', label: '✉️ Email' },
          { id: 'ads', label: '💰 Ads' },
          { id: 'research', label: '🔬 Research' },
          { id: 'reporting', label: '📊 Reporting' },
          { id: 'brand', label: '🎨 Brand' },
          { id: 'conversion', label: '🚀 CRO' },
          { id: 'abm', label: '🎖️ ABM' },
          { id: 'automation', label: '🤖 Automation' },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id as any)}
            className={`px-3 py-1 rounded font-medium transition-colors ${
              tab === t.id
                ? 'bg-red-600/20 text-red-600 border-b-2 border-red-600'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div>
        {tab === 'dashboard' && <DashboardPanel />}
        {tab === 'pipeline' && <PipelinePanel />}
        {tab === 'campaigns' && <CampaignPanel />}
        {tab === 'analytics' && <AnalyticsPanel />}
        {tab === 'reports' && <ClientReportPanel />}
        {tab === 'competitors' && <CompetitorPanel />}
        {tab === 'intel' && <IntelPanel />}
        {tab === 'seo' && <SEOPanel />}
        {tab === 'social' && <SocialPanel />}
        {tab === 'email' && <EmailPanel />}
        {tab === 'ads' && <AdPanel />}
        {tab === 'research' && <ResearchPanel />}
        {tab === 'reporting' && <ReportingPanel />}
        {tab === 'brand' && <BrandPanel />}
        {tab === 'conversion' && <ConversionPanel />}
        {tab === 'abm' && <ABMPanel />}
        {tab === 'automation' && <AutomationPanel />}
      </div>
    </div>
  );
}
