'use client';
import { useState, useEffect } from 'react';

interface QAPair {
  id: string;
  question: string;
  answer: string;
  askedAt: string;
  answeredAt: string;
}

interface PersonalitySummary {
  summary: string;
  updatedAt: string | null;
  answersCount: number;
  generatedBy?: string;
}

interface ProgressInfo {
  questionsAsked: number;
  totalQuestions: number;
  resetAt: string;
}

export default function GetToKnowPanel() {
  const [section, setSection] = useState<'current' | 'history' | 'profile'>('current');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [history, setHistory] = useState<QAPair[]>([]);
  const [personality, setPersonality] = useState<PersonalitySummary | null>(null);
  const [progress, setProgress] = useState<ProgressInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Load initial question and history
  useEffect(() => {
    const loadQuestion = async () => {
      try {
        setLoading(true);
        const res = await fetch('/api/apps/get-to-know');
        if (res.ok) {
          const data = await res.json();
          setQuestion(data.question);
          setHistory(data.history);
          setPersonality(data.personality);
          setProgress(data.progress);
        } else {
          setError('Failed to load question');
        }
      } catch (e) {
        setError('Failed to load question: ' + (e as any).message);
      } finally {
        setLoading(false);
      }
    };

    loadQuestion();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!answer.trim()) {
      setError('Please enter an answer');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      setSuccess('');

      const res = await fetch('/api/apps/get-to-know', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question,
          answer,
          syncToProfile: false
        })
      });

      if (res.ok) {
        const data = await res.json();
        setHistory([...history, data.qa]);
        setAnswer('');
        setSuccess('Answer saved! Loading next question...');
        
        // Reload for next question
        setTimeout(async () => {
          const nextRes = await fetch('/api/apps/get-to-know');
          if (nextRes.ok) {
            const nextData = await nextRes.json();
            setQuestion(nextData.question);
            setProgress(nextData.progress);
            setSuccess('');
          }
        }, 1000);
      } else {
        setError('Failed to save answer');
      }
    } catch (e) {
      setError('Error: ' + (e as any).message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSyncToProfile = async () => {
    try {
      setSyncing(true);
      setError('');
      setSuccess('');

      // Send all history to sync
      for (const qa of history) {
        await fetch('/api/apps/get-to-know', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: qa.question,
            answer: qa.answer,
            syncToProfile: true
          })
        });
      }

      // Reload personality summary
      const res = await fetch('/api/apps/get-to-know');
      if (res.ok) {
        const data = await res.json();
        setPersonality(data.personality);
        setSuccess('Profile synced! Personality summary updated.');
      }
    } catch (e) {
      setError('Failed to sync: ' + (e as any).message);
    } finally {
      setSyncing(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Tabs */}
      <div className="flex gap-2 border-b border-mc-border">
        <button
          onClick={() => setSection('current')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            section === 'current'
              ? 'text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          Current Question
        </button>
        <button
          onClick={() => setSection('history')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            section === 'history'
              ? 'text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          History ({history.length})
        </button>
        <button
          onClick={() => setSection('profile')}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            section === 'profile'
              ? 'text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          Profile
        </button>
      </div>

      {/* Messages */}
      {error && <div className="p-3 bg-red-500/20 text-red-300 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-green-500/20 text-green-300 rounded text-sm">{success}</div>}

      {/* Section: Current Question */}
      {section === 'current' && (
        <div className="space-y-4">
          {progress && (
            <div className="text-sm text-mc-muted">
              Progress: {progress.questionsAsked} of {progress.totalQuestions} questions
              <div className="w-full bg-mc-bg rounded-full h-2 mt-2">
                <div
                  className="bg-mc-accent h-2 rounded-full transition-all"
                  style={{ width: `${(progress.questionsAsked / progress.totalQuestions) * 100}%` }}
                />
              </div>
            </div>
          )}

          <div className="bg-mc-surface border border-mc-border rounded-lg p-6">
            <h3 className="text-lg font-bold text-mc-text mb-4">🤔 {question}</h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Share your thoughts..."
                className="w-full h-32 px-4 py-3 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted focus:outline-none focus:border-mc-accent"
              />

              <button
                type="submit"
                disabled={submitting}
                className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium transition-colors"
              >
                {submitting ? '⏳ Saving...' : '💾 Save & Next'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Section: History */}
      {section === 'history' && (
        <div className="space-y-4">
          {history.length === 0 ? (
            <div className="text-center py-8 text-mc-muted">
              No answers yet. Start with the current question!
            </div>
          ) : (
            <div className="space-y-3">
              {history.map((qa, idx) => (
                <div key={qa.id} className="bg-mc-surface border border-mc-border rounded-lg p-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1 space-y-2">
                      <p className="font-semibold text-mc-accent">Q{idx + 1}: {qa.question}</p>
                      <p className="text-mc-text whitespace-pre-wrap">{qa.answer}</p>
                      <p className="text-xs text-mc-muted">
                        {new Date(qa.answeredAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Section: Profile Summary */}
      {section === 'profile' && (
        <div className="space-y-4">
          {!personality?.summary ? (
            <div className="bg-mc-surface border border-mc-border rounded-lg p-6 text-center">
              <p className="text-mc-muted mb-4">
                Personality summary will be generated once you answer enough questions.
              </p>
              <button
                onClick={handleSyncToProfile}
                disabled={syncing || history.length === 0}
                className="px-6 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium transition-colors"
              >
                {syncing ? '⏳ Generating...' : `🧬 Generate Profile (${history.length} answers)`}
              </button>
            </div>
          ) : (
            <div className="bg-mc-surface border border-mc-border rounded-lg p-6 space-y-4">
              <div>
                <h3 className="font-semibold text-mc-text mb-3">Your Personality Summary</h3>
                <p className="text-mc-text whitespace-pre-wrap leading-relaxed">
                  {personality.summary}
                </p>
              </div>

              <div className="text-sm text-mc-muted pt-4 border-t border-mc-border">
                <p>Based on {personality.answersCount} answers</p>
                <p>Last updated: {new Date(personality.updatedAt || '').toLocaleDateString()}</p>
              </div>

              <button
                onClick={handleSyncToProfile}
                disabled={syncing}
                className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium transition-colors text-sm"
              >
                {syncing ? '⏳ Updating...' : '🔄 Regenerate Summary'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
