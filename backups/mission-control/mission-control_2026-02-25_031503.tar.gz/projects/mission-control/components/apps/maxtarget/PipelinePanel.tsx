'use client';

import { SavedOutputs } from './shared';
import { useState, useEffect, useMemo } from 'react';

import Modal from './shared/Modal';

import StatusBadge from './shared/StatusBadge';

import ProgressBar from './shared/ProgressBar';

import ActivityTimeline from './shared/ActivityTimeline';

interface EngagementEvent {

  date: string;

  type: 'email_open' | 'page_visit' | 'form_submit' | 'meeting' | 'call';

  detail: string;

}

interface Lead {

  id: string;

  companyName: string;

  contactName: string;

  email: string;

  phone: string;

  source: string;

  score: number;

  stage: 'Lead' | 'MQL' | 'SQL' | 'Opportunity' | 'Closed Won' | 'Closed Lost';

  notes: string;

  createdDate: string;

  lastTouched: string;

  engagementHistory?: EngagementEvent[];

  assignedTo?: string;

  estimatedValue?: number;

  tags?: string[];

}

const STAGES = ['Lead', 'MQL', 'SQL', 'Opportunity', 'Closed Won', 'Closed Lost'];

const SOURCES = ['Website Form', 'LinkedIn Campaign', 'Google Ads', 'Referral', 'Conference', 'Cold Outreach', 'Webinar', 'Content Download'];

export default function PipelinePanel() {

  const [leads, setLeads] = useState<Lead[]>([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState('');

  const [success, setSuccess] = useState('');

  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: 'success' | 'error' }>>([]);

  const addToast = (message: string, type: 'success' | 'error' = 'success') => {

    const id = Date.now().toString();

    setToasts(prev => [...prev, { id, message, type }]);

    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);

  };

  const [showAddLead, setShowAddLead] = useState(false);

  const [showEditLead, setShowEditLead] = useState<Lead | null>(null);

  const [leadFilter, setLeadFilter] = useState('');

  const [leadStageFilter, setLeadStageFilter] = useState('all');

  const [sortBy, setSortBy] = useState<'score' | 'date' | 'stage'>('score');

  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {

    const loadLeads = async () => {

      try {

        const res = await fetch('/api/apps/maxtarget/leads');

        if (res.ok) {

          const d = await res.json();

          setLeads(Array.isArray(d) ? d : d.leads || []);

        }

      } catch (e) {

        setError('Failed to load leads');

      } finally {

        setLoading(false);

      }

    };

    loadLeads();

  }, []);

  useEffect(() => {

    if (success || error) {

      const t = setTimeout(() => { setSuccess(''); setError(''); }, 3000);

      return () => clearTimeout(t);

    }

  }, [success, error]);

  const addLead = async (lead: Omit<Lead, 'id'>) => {

    try {

      const res = await fetch('/api/apps/maxtarget/leads', {

        method: 'POST',

        headers: { 'Content-Type': 'application/json' },

        body: JSON.stringify(lead),

      });

      if (res.ok) {

        const data = await res.json();

        setLeads([...leads, data.lead]);

        setSuccess('Lead added');

        addToast('Lead added successfully');

      }

    } catch (e) {

      setError('Failed to add lead');

    }

  };

  const updateLead = async (id: string, updates: Partial<Lead>) => {

    try {

      const res = await fetch('/api/apps/maxtarget/leads', {

        method: 'PUT',

        headers: { 'Content-Type': 'application/json' },

        body: JSON.stringify({ id, ...updates }),

      });

      if (res.ok) {

        setLeads(leads.map(l => l.id === id ? { ...l, ...updates } : l));

        setSuccess('Lead updated');

        addToast('Lead updated');

      }

    } catch (e) {

      setError('Failed to update lead');

    }

  };

  const deleteLead = async (id: string) => {

    try {

      const res = await fetch('/api/apps/maxtarget/leads', {

        method: 'DELETE',

        headers: { 'Content-Type': 'application/json' },

        body: JSON.stringify({ id }),

      });

      if (res.ok) {

        setLeads(leads.filter(l => l.id !== id));

        setSuccess('Lead deleted');

        addToast('Lead deleted');

      }

    } catch (e) {

      setError('Failed to delete lead');

    }

  };

  const LeadForm = ({ lead, onSave, onCancel }: { lead?: Lead; onSave: (data: any) => void; onCancel: () => void }) => {

    const [form, setForm] = useState({

      companyName: lead?.companyName || '',

      contactName: lead?.contactName || '',

      email: lead?.email || '',

      phone: lead?.phone || '',

      source: lead?.source || 'Website Form',

      score: lead?.score || 50,

      stage: lead?.stage || 'Lead',

      notes: lead?.notes || '',

    });

    return (

      <div className="space-y-4">

        <div>

          <label className="block text-sm text-gray-400 mb-1">Company Name *</label>

          <input type="text" value={form.companyName} onChange={e => setForm({ ...form, companyName: e.target.value })}

            className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

        </div>

        <div className="grid grid-cols-2 gap-3">

          <div>

            <label className="block text-sm text-gray-400 mb-1">Contact Name</label>

            <input type="text" value={form.contactName} onChange={e => setForm({ ...form, contactName: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

          </div>

          <div>

            <label className="block text-sm text-gray-400 mb-1">Email</label>

            <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

          </div>

        </div>

        <div className="grid grid-cols-2 gap-3">

          <div>

            <label className="block text-sm text-gray-400 mb-1">Phone</label>

            <input type="tel" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

          </div>

          <div>

            <label className="block text-sm text-gray-400 mb-1">Source</label>

            <select value={form.source} onChange={e => setForm({ ...form, source: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none">

              {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}

            </select>

          </div>

        </div>

        <div className="grid grid-cols-2 gap-3">

          <div>

            <label className="block text-sm text-gray-400 mb-1">Stage</label>

            <select value={form.stage} onChange={e => setForm({ ...form, stage: e.target.value as any })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none">

              {STAGES.map(s => <option key={s} value={s}>{s}</option>)}

            </select>

          </div>

          <div>

            <label className="block text-sm text-gray-400 mb-1">Lead Score (0-100)</label>

            <input type="number" min="0" max="100" value={form.score} onChange={e => setForm({ ...form, score: parseInt(e.target.value) || 0 })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border[#DC143C] focus:outline-none" />

          </div>

        </div>

        <div>

          <label className="block text-sm text-gray-400 mb-1">Notes</label>

          <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3}

            className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border[#DC143C] focus:outline-none resize-none" />

        </div>

        <div className="flex gap-3 pt-2">

          <button onClick={() => {

            if (!form.companyName.trim()) return;

            onSave({ ...form, createdDate: lead?.createdDate || new Date().toISOString(), lastTouched: new Date().toISOString() });

          }} className="flex-1 px-4 py-2 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">

            {lead ? 'Update Lead' : 'Add Lead'}

          </button>

          <button onClick={onCancel} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded">

            Cancel

          </button>

        </div>

      </div>

    );

  };

  if (loading) {

    return <div className="text-gray-400">Loading Pipeline...</div>;

  }

  const filteredLeads = useMemo(() => {
    let result = leads.filter(l => {
      const matchesSearch = !leadFilter || l.companyName.toLowerCase().includes(leadFilter.toLowerCase()) || l.contactName.toLowerCase().includes(leadFilter.toLowerCase());
      const matchesStage = leadStageFilter === 'all' || l.stage === leadStageFilter;
      return matchesSearch && matchesStage;
    });

    // Sort by selected field
    const stageOrder = ['Lead', 'MQL', 'SQL', 'Opportunity', 'Closed Won', 'Closed Lost'];
    result.sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'score') {
        comparison = a.score - b.score;
      } else if (sortBy === 'date') {
        comparison = new Date(a.createdDate).getTime() - new Date(b.createdDate).getTime();
      } else if (sortBy === 'stage') {
        comparison = stageOrder.indexOf(a.stage) - stageOrder.indexOf(b.stage);
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [leads, leadFilter, leadStageFilter, sortBy, sortOrder]);

  const handleSort = (field: 'score' | 'date' | 'stage') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  return (

    <div className="space-y-6 bg-gray-950 text-white">

      {error && <div className="p-3 bg-red-600/20 text-red-400 rounded">{error}</div>}

      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded">{success}</div>}

      {/* Toasts */}

      <div className="fixed top-4 right-4 z-[100] space-y-2" style={{ pointerEvents: 'none' }}>

        {toasts.map(toast => (

          <div key={toast.id} className={`px-4 py-3 rounded-lg shadow-lg border text-sm font-medium animate-pulse ${

            toast.type === 'success' ? 'bg-gray-800 border-emerald-500 text-emerald-400' : 'bg-gray-800 border-red-500 text-red-400'

          }`} style={{ pointerEvents: 'auto', minWidth: '250px' }}>

            {toast.type === 'success' ? '✅' : '❌'} {toast.message}

          </div>

        ))}

      </div>

      {/* Stage Summary */}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">

        {STAGES.map(stage => {

          const count = leads.filter(l => l.stage === stage).length;

          const colors: Record<string, string> = {

            'Lead': 'text-blue-400', 'MQL': 'text-yellow-400', 'SQL': 'text-orange-400',

            'Opportunity': 'text-purple-400', 'Closed Won': 'text-emerald-400', 'Closed Lost': 'text-red-400'

          };

          return (

            <button key={stage} onClick={() => setLeadStageFilter(leadStageFilter === stage ? 'all' : stage)}

              className={`bg-gray-800 rounded p-4 border transition-colors ${leadStageFilter === stage ? 'border-[#DC143C]' : 'border-gray-700 hover:border-gray-600'}`}>

              <div className="text-sm font-medium text-gray-400">{stage}</div>

              <div className={`text-2xl font-bold ${colors[stage] || 'text-[#DC143C]'}`}>{count}</div>

            </button>

          );

        })}

      </div>

      {/* Pipeline Funnel Visualization */}

      <div className="bg-gray-800 rounded p-4 border border-gray-700">

        <div className="text-sm font-medium text-gray-400 mb-3">Pipeline Funnel</div>

        <div className="space-y-2">

          {STAGES.map(stage => {

            const count = leads.filter(l => l.stage === stage).length;

            const maxCount = Math.max(...STAGES.map(s => leads.filter(l => l.stage === s).length), 1);

            const pct = (count / maxCount) * 100;

            const colors: Record<string, string> = {

              'Lead': 'bg-blue-500', 'MQL': 'bg-yellow-500', 'SQL': 'bg-orange-500',

              'Opportunity': 'bg-purple-500', 'Closed Won': 'bg-emerald-500', 'Closed Lost': 'bg-red-500'

            };

            return (

              <div key={stage} className="flex items-center gap-3">

                <div className="w-24 text-xs text-gray-400 text-right shrink-0">{stage}</div>

                <div className="flex-1 bg-gray-900 rounded-full h-6 overflow-hidden">

                  <div className={`h-full ${colors[stage]} rounded-full transition-all flex items-center justify-end pr-2`}

                    style={{ width: `${Math.max(pct, 8)}%` }}>

                    <span className="text-xs font-bold text-white">{count}</span>

                  </div>

                </div>

              </div>

            );

          })}

        </div>

      </div>

      {/* Controls */}

      <div className="flex gap-3 flex-wrap">

        <button onClick={() => setShowAddLead(true)}

          className="px-4 py-2 bg-[#DC143C]/20 text-[#DC143C] hover:bg-[#DC143C]/30 rounded font-medium border border-[#DC143C]/30">

          ➕ Add Lead

        </button>

        <input type="text" placeholder="Search leads..." value={leadFilter} onChange={e => setLeadFilter(e.target.value)}

          className="bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:border-[#DC143C] focus:outline-none flex-1 min-w-[200px]" />

      </div>

      {/* Lead List with Sortable Headers */}

      <div className="space-y-3">

        {/* Sortable Header Row */}

        <div className="flex gap-2 text-xs text-gray-500 font-medium px-4">

          <button onClick={() => handleSort('score')} className="flex-1 text-left hover:text-[#DC143C] transition-colors flex items-center gap-1">

            Score {sortBy === 'score' && (sortOrder === 'desc' ? '↓' : '↑')}

          </button>

          <button onClick={() => handleSort('date')} className="flex-1 text-left hover:text-[#DC143C] transition-colors flex items-center gap-1">

            Date {sortBy === 'date' && (sortOrder === 'desc' ? '↓' : '↑')}

          </button>

          <button onClick={() => handleSort('stage')} className="flex-1 text-left hover:text-[#DC143C] transition-colors flex items-center gap-1">

            Stage {sortBy === 'stage' && (sortOrder === 'desc' ? '↓' : '↑')}

          </button>

        </div>

        {filteredLeads.map(lead => {

          const scoreColor = lead.score >= 80 ? 'text-emerald-400' : lead.score >= 60 ? 'text-yellow-400' : lead.score >= 40 ? 'text-orange-400' : 'text-red-400';

          const stageColors: Record<string, string> = {

            'Lead': 'bg-blue-500/20 text-blue-400', 'MQL': 'bg-yellow-500/20 text-yellow-400',

            'SQL': 'bg-orange-500/20 text-orange-400', 'Opportunity': 'bg-purple-500/20 text-purple-400',

            'Closed Won': 'bg-emerald-500/20 text-emerald-400', 'Closed Lost': 'bg-red-500/20 text-red-400'

          };

          return (

            <div key={lead.id} className="bg-gray-800 rounded p-4 border border-gray-700 hover:border-gray-600 transition-colors">

              <div className="flex justify-between items-start mb-2">

                <div>

                  <div className="font-semibold text-gray-100">{lead.companyName}</div>

                  <div className="text-sm text-gray-400">{lead.contactName} • {lead.email}</div>

                  {lead.notes && <div className="text-xs text-gray-500 mt-1 line-clamp-1">{lead.notes}</div>}

                </div>

                <div className="text-right flex flex-col items-end gap-1">

                  <span className={`text-xs font-medium px-2 py-1 rounded ${stageColors[lead.stage] || 'bg-gray-700 text-gray-400'}`}>{lead.stage}</span>

                  <div className="flex items-center gap-1">

                    <span className="text-xs text-gray-500">Score:</span>

                    <span className={`text-sm font-bold ${scoreColor}`}>{lead.score}</span>

                  </div>

                  <div className="text-xs text-gray-600">{lead.source}</div>

                </div>

              </div>

              <div className="flex gap-2 mt-3">

                <button onClick={() => setShowEditLead(lead)}

                  className="text-xs px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">

                  ✏️ Edit

                </button>

                <select value={lead.stage}

                  onChange={e => updateLead(lead.id, { stage: e.target.value as Lead['stage'], lastTouched: new Date().toISOString() })}

                  className="text-xs bg-gray-700 hover:bg-gray-600 rounded text-gray-300 px-2 py-1 border-none focus:outline-none">

                  {STAGES.map(s => <option key={s} value={s}>{s}</option>)}

                </select>

                <button onClick={() => { if (confirm('Delete this lead?')) deleteLead(lead.id); }}

                  className="text-xs px-3 py-1 bg-red-500/20 hover:bg-red-500/30 rounded text-red-400 ml-auto">

                  🗑️ Delete

                </button>

              </div>

            </div>

          );

        })}

        {filteredLeads.length === 0 && (

          <div className="text-center text-gray-500 py-8">No leads found</div>

        )}

      </div>

      {/* Add Lead Modal */}

      <Modal isOpen={showAddLead} onClose={() => setShowAddLead(false)} title="Add New Lead">

        <LeadForm onSave={(data) => { addLead(data); setShowAddLead(false); }} onCancel={() => setShowAddLead(false)} />

      </Modal>

      {/* Edit Lead Modal */}

      <Modal isOpen={!!showEditLead} onClose={() => setShowEditLead(null)} title="Edit Lead">

        {showEditLead && (

          <LeadForm lead={showEditLead} onSave={(data) => { updateLead(showEditLead.id, data); setShowEditLead(null); }} onCancel={() => setShowEditLead(null)} />

        )}

      </Modal>

      {/* Activity Timeline - All leads */}

      <ActivityTimeline entityType="all" limit={15} compact />

    <SavedOutputs panel="pipeline" />
    </div>

  );

}