'use client';

import { SavedOutputs } from './shared';
import { useState, useEffect } from 'react';

import Modal from './shared/Modal';

interface DailyMetric {

  date: string;

  impressions: number;

  clicks: number;

  conversions: number;

  spent: number;

}

interface CampaignGoals {

  targetConversions: number;

  targetCPA: number;

  targetROAS: number;

}

interface Campaign {

  id: string;

  name: string;

  type: 'email' | 'display' | 'social' | 'search' | 'programmatic' | 'ABM';

  status: 'draft' | 'active' | 'paused' | 'completed';

  budget: number;

  spent: number;

  startDate: string;

  endDate: string;

  targetAudience: string;

  channels: string[];

  metrics: {

    impressions: number;

    clicks: number;

    conversions: number;

    ctr?: number;

    cpa?: number;

    roas?: number;

  };

  dailyMetrics?: DailyMetric[];

  goals?: CampaignGoals;

  creativeAssets?: string[];

  notes?: string;

  createdDate: string;

}

const CAMPAIGN_TYPES = ['email', 'display', 'social', 'search', 'programmatic', 'ABM'];

const CAMPAIGN_STATUSES = ['draft', 'active', 'paused', 'completed'];

export default function CampaignPanel() {

  const [campaigns, setCampaigns] = useState<Campaign[]>([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState('');

  const [success, setSuccess] = useState('');

  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: 'success' | 'error' }>>([]);

  const addToast = (message: string, type: 'success' | 'error' = 'success') => {

    const id = Date.now().toString();

    setToasts(prev => [...prev, { id, message, type }]);

    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);

  };

  const [showAddCampaign, setShowAddCampaign] = useState(false);

  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);

  useEffect(() => {

    const loadCampaigns = async () => {

      try {

        const res = await fetch('/api/apps/maxtarget/campaigns');

        if (res.ok) {

          setCampaigns((await res.json()).campaigns || []);

        }

      } catch (e) {

        setError('Failed to load campaigns');

      } finally {

        setLoading(false);

      }

    };

    loadCampaigns();

  }, []);

  useEffect(() => {

    if (success || error) {

      const t = setTimeout(() => { setSuccess(''); setError(''); }, 3000);

      return () => clearTimeout(t);

    }

  }, [success, error]);

  const CampaignForm = ({ onSave, onCancel }: { onSave: (data: any) => void; onCancel: () => void }) => {

    const [form, setForm] = useState({

      name: '', type: 'programmatic', status: 'draft', budget: 5000, spent: 0,

      startDate: new Date().toISOString().split('T')[0],

      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],

      targetAudience: '', channels: [] as string[],

      metrics: { impressions: 0, clicks: 0, conversions: 0, ctr: 0, cpa: 0, roas: 0 },

    });

    return (

      <div className="space-y-4">

        <div>

          <label className="block text-sm text-gray-400 mb-1">Campaign Name *</label>

          <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}

            className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

        </div>

        <div className="grid grid-cols-2 gap-3">

          <div>

            <label className="block text-sm text-gray-400 mb-1">Type</label>

            <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none">

              {CAMPAIGN_TYPES.map(t => <option key={t} value={t}>{t}</option>)}

            </select>

          </div>

          <div>

            <label className="block text-sm text-gray-400 mb-1">Budget ($)</label>

            <input type="number" value={form.budget} onChange={e => setForm({ ...form, budget: parseInt(e.target.value) || 0 })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

          </div>

        </div>

        <div className="grid grid-cols-2 gap-3">

          <div>

            <label className="block text-sm text-gray-400 mb-1">Start Date</label>

            <input type="date" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

          </div>

          <div>

            <label className="block text-sm text-gray-400 mb-1">End Date</label>

            <input type="date" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })}

              className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" />

          </div>

        </div>

        <div>

          <label className="block text-sm text-gray-400 mb-1">Target Audience</label>

          <input type="text" value={form.targetAudience} onChange={e => setForm({ ...form, targetAudience: e.target.value })}

            className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:border-[#DC143C] focus:outline-none" placeholder="e.g., CFOs at mid-market firms" />

        </div>

        <div className="flex gap-3 pt-2">

          <button onClick={() => { if (!form.name.trim()) return; onSave(form); }}

            className="flex-1 px-4 py-2 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">Create Campaign</button>

          <button onClick={onCancel} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded">Cancel</button>

        </div>

      </div>

    );

  };

  if (loading) {

    return <div className="text-gray-400">Loading Campaigns...</div>;

  }

  const totalBudget = campaigns.reduce((s, c) => s + c.budget, 0);

  const totalSpent = campaigns.reduce((s, c) => s + c.spent, 0);

  const totalConversions = campaigns.reduce((s, c) => s + c.metrics.conversions, 0);

  const activeCampaigns = campaigns.filter(c => c.status === 'active').length;

  const statusColors: Record<string, string> = {

    draft: 'bg-gray-600 text-gray-300', active: 'bg-emerald-500/20 text-emerald-400',

    paused: 'bg-yellow-500/20 text-yellow-400', completed: 'bg-blue-500/20 text-blue-400',

  };

  return (

    <div className="space-y-4 bg-gray-950 text-white">

      {error && <div className="p-3 bg-red-600/20 text-red-400 rounded">{error}</div>}

      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded">{success}</div>}

      <div className="fixed top-4 right-4 z-[100] space-y-2" style={{ pointerEvents: 'none' }}>

        {toasts.map(toast => (

          <div key={toast.id} className={`px-4 py-3 rounded-lg shadow-lg border text-sm font-medium animate-pulse ${

            toast.type === 'success' ? 'bg-gray-800 border-emerald-500 text-emerald-400' : 'bg-gray-800 border-red-500 text-red-400'

          }`} style={{ pointerEvents: 'auto', minWidth: '250px' }}>

            {toast.type === 'success' ? '✅' : '❌'} {toast.message}

          </div>

        ))}

      </div>

      {/* Summary Cards */}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">

        <div className="bg-gray-800 rounded p-4 border border-gray-700">

          <div className="text-sm text-gray-400">Active Campaigns</div>

          <div className="text-2xl font-bold text-emerald-400">{activeCampaigns}</div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-gray-700">

          <div className="text-sm text-gray-400">Total Budget</div>

          <div className="text-2xl font-bold text-white">${totalBudget.toLocaleString()}</div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-gray-700">

          <div className="text-sm text-gray-400">Total Spent</div>

          <div className="text-2xl font-bold text-[#DC143C]">${totalSpent.toLocaleString()}</div>

          <div className="mt-1 bg-gray-900 rounded-full h-2 overflow-hidden">

            <div className="h-full bg-[#DC143C] rounded-full" style={{ width: `${totalBudget ? (totalSpent / totalBudget * 100) : 0}%` }} />

          </div>

        </div>

        <div className="bg-gray-800 rounded p-4 border border-gray-700">

          <div className="text-sm text-gray-400">Total Conversions</div>

          <div className="text-2xl font-bold text-purple-400">{totalConversions}</div>

        </div>

      </div>

      <button onClick={() => setShowAddCampaign(true)}

        className="w-full px-4 py-2 bg-[#DC143C]/20 text-[#DC143C] hover:bg-[#DC143C]/30 rounded font-medium border border-[#DC143C]/30">

        ➕ Create Campaign

      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

        {campaigns.map(campaign => {

          const budgetPct = campaign.budget ? (campaign.spent / campaign.budget * 100) : 0;

          const budgetColor = budgetPct > 90 ? 'bg-red-500' : budgetPct > 70 ? 'bg-yellow-500' : 'bg-emerald-500';

          return (

            <div key={campaign.id} onClick={() => setSelectedCampaign(campaign)} className="bg-gray-800 rounded p-4 border border-gray-700 hover:border-[#DC143C] cursor-pointer transition-all hover:shadow-lg hover:shadow-[#DC143C]/10">

              <div className="flex justify-between items-start mb-2">

                <div className="font-semibold text-gray-100 flex-1 mr-2">{campaign.name}</div>

                <span className={`text-xs px-2 py-1 rounded font-medium ${statusColors[campaign.status]}`}>

                  {campaign.status.toUpperCase()}

                </span>

              </div>

              <div className="text-sm text-gray-400 mb-3">

                {campaign.type} • {campaign.startDate} → {campaign.endDate}

              </div>

              {campaign.targetAudience && (

                <div className="text-xs text-gray-500 mb-3">🎯 {campaign.targetAudience}</div>

              )}

              {/* Budget Bar */}

              <div className="mb-3">

                <div className="flex justify-between text-xs text-gray-400 mb-1">

                  <span>Budget: ${campaign.budget.toLocaleString()}</span>

                  <span>Spent: ${campaign.spent.toLocaleString()} ({budgetPct.toFixed(0)}%)</span>

                </div>

                <div className="bg-gray-900 rounded-full h-2 overflow-hidden">

                  <div className={`h-full ${budgetColor} rounded-full transition-all`} style={{ width: `${Math.min(budgetPct, 100)}%` }} />

                </div>

              </div>

              {/* Metrics Grid */}

              <div className="grid grid-cols-3 gap-2 text-center">

                <div className="bg-gray-900 rounded p-2">

                  <div className="text-xs text-gray-500">Impressions</div>

                  <div className="text-sm font-bold text-white">{(campaign.metrics.impressions || 0).toLocaleString()}</div>

                </div>

                <div className="bg-gray-900 rounded p-2">

                  <div className="text-xs text-gray-500">Clicks</div>

                  <div className="text-sm font-bold text-white">{(campaign.metrics.clicks || 0).toLocaleString()}</div>

                </div>

                <div className="bg-gray-900 rounded p-2">

                  <div className="text-xs text-gray-500">Conversions</div>

                  <div className="text-sm font-bold text-emerald-400">{campaign.metrics.conversions || 0}</div>

                </div>

              </div>

              <div className="grid grid-cols-3 gap-2 text-center mt-2">

                <div className="bg-gray-900 rounded p-2">

                  <div className="text-xs text-gray-500">CTR</div>

                  <div className="text-sm font-bold text-white">{(campaign.metrics.ctr || 0).toFixed(1)}%</div>

                </div>

                <div className="bg-gray-900 rounded p-2">

                  <div className="text-xs text-gray-500">CPA</div>

                  <div className="text-sm font-bold text-white">${(campaign.metrics.cpa || 0).toFixed(0)}</div>

                </div>

                <div className="bg-gray-900 rounded p-2">

                  <div className="text-xs text-gray-500">ROAS</div>

                  <div className={`text-sm font-bold ${(campaign.metrics.roas || 0) >= 3 ? 'text-emerald-400' : (campaign.metrics.roas || 0) >= 2 ? 'text-yellow-400' : 'text-red-400'}`}>

                    {(campaign.metrics.roas || 0).toFixed(1)}x

                  </div>

                </div>

              </div>

              {/* Channels */}

              {campaign.channels && campaign.channels.length > 0 && (

                <div className="flex gap-1 mt-3 flex-wrap">

                  {campaign.channels.map((ch, i) => (

                    <span key={i} className="text-xs bg-gray-700 text-gray-400 px-2 py-0.5 rounded">{ch}</span>

                  ))}

                </div>

              )}

              {/* Status Controls */}

              <div className="mt-3 pt-3 border-t border-gray-700">

                <select value={campaign.status}

                  onChange={e => {

                    const status = e.target.value;

                    fetch('/api/apps/maxtarget/campaigns', {

                      method: 'PUT', headers: { 'Content-Type': 'application/json' },

                      body: JSON.stringify({ id: campaign.id, status }),

                    }).then(res => { if (res.ok) {

                      setCampaigns(campaigns.map(c => c.id === campaign.id ? { ...c, status: status as Campaign['status'] } : c));

                      addToast('Campaign status updated');

                    } });

                  }}

                  className="w-full text-xs bg-gray-700 hover:bg-gray-600 rounded text-gray-300 px-2 py-1.5 border-none focus:outline-none">

                  {CAMPAIGN_STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}

                </select>

              </div>

            </div>

          );

        })}

      </div>

      <Modal isOpen={showAddCampaign} onClose={() => setShowAddCampaign(false)} title="Create Campaign">

        <CampaignForm onSave={(data) => {

          fetch('/api/apps/maxtarget/campaigns', {

            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),

          }).then(res => { if (res.ok) res.json().then(d => {

            setCampaigns([...campaigns, d.campaign]);

            addToast('Campaign created');

          }); });

          setShowAddCampaign(false);

        }} onCancel={() => setShowAddCampaign(false)} />

      </Modal>

      {/* Campaign Detail Modal */}

      <Modal isOpen={!!selectedCampaign} onClose={() => setSelectedCampaign(null)} title={selectedCampaign?.name || 'Campaign Details'}>

        {selectedCampaign && (

          <div className="space-y-6">

            {/* Header Info */}

            <div className="flex justify-between items-center">

              <div>

                <div className="text-lg font-semibold text-white">{selectedCampaign.name}</div>

                <div className="text-sm text-gray-400">{selectedCampaign.type} • {selectedCampaign.startDate} → {selectedCampaign.endDate}</div>

              </div>

              <span className={`text-xs px-3 py-1 rounded font-medium ${statusColors[selectedCampaign.status]}`}>

                {selectedCampaign.status.toUpperCase()}

              </span>

            </div>

            {/* Full Metrics */}

            <div>

              <div className="text-sm font-medium text-gray-400 mb-3">Performance Metrics</div>

              <div className="grid grid-cols-3 gap-3">

                <div className="bg-gray-900 rounded p-3 text-center">

                  <div className="text-xs text-gray-500">Impressions</div>

                  <div className="text-xl font-bold text-white">{selectedCampaign.metrics.impressions?.toLocaleString() || 0}</div>

                </div>

                <div className="bg-gray-900 rounded p-3 text-center">

                  <div className="text-xs text-gray-500">Clicks</div>

                  <div className="text-xl font-bold text-white">{selectedCampaign.metrics.clicks?.toLocaleString() || 0}</div>

                </div>

                <div className="bg-gray-900 rounded p-3 text-center">

                  <div className="text-xs text-gray-500">Conversions</div>

                  <div className="text-xl font-bold text-emerald-400">{selectedCampaign.metrics.conversions || 0}</div>

                </div>

              </div>

              <div className="grid grid-cols-3 gap-3 mt-3">

                <div className="bg-gray-900 rounded p-3 text-center">

                  <div className="text-xs text-gray-500">CTR</div>

                  <div className="text-lg font-bold text-white">{(selectedCampaign.metrics.ctr || 0).toFixed(2)}%</div>

                </div>

                <div className="bg-gray-900 rounded p-3 text-center">

                  <div className="text-xs text-gray-500">CPA</div>

                  <div className="text-lg font-bold text-white">${(selectedCampaign.metrics.cpa || 0).toFixed(2)}</div>

                </div>

                <div className="bg-gray-900 rounded p-3 text-center">

                  <div className="text-xs text-gray-500">ROAS</div>

                  <div className={`text-lg font-bold ${(selectedCampaign.metrics.roas || 0) >= 3 ? 'text-emerald-400' : (selectedCampaign.metrics.roas || 0) >= 2 ? 'text-yellow-400' : 'text-red-400'}`}>

                    {(selectedCampaign.metrics.roas || 0).toFixed(2)}x

                  </div>

                </div>

              </div>

            </div>

            {/* Budget */}

            <div>

              <div className="text-sm font-medium text-gray-400 mb-2">Budget</div>

              <div className="bg-gray-900 rounded p-3">

                <div className="flex justify-between text-sm mb-2">

                  <span className="text-gray-400">Spent: <span className="text-white font-medium">${selectedCampaign.spent.toLocaleString()}</span></span>

                  <span className="text-gray-400">Budget: <span className="text-white font-medium">${selectedCampaign.budget.toLocaleString()}</span></span>

                  <span className="text-gray-400">Remaining: <span className="text-emerald-400 font-medium">${(selectedCampaign.budget - selectedCampaign.spent).toLocaleString()}</span></span>

                </div>

                <div className="bg-gray-800 rounded-full h-3 overflow-hidden">

                  <div className="h-full bg-[#DC143C] rounded-full" style={{ width: `${Math.min((selectedCampaign.spent / selectedCampaign.budget) * 100, 100)}%` }} />

                </div>

              </div>

            </div>

            {/* Daily Breakdown */}

            {selectedCampaign.dailyMetrics && selectedCampaign.dailyMetrics.length > 0 && (

              <div>

                <div className="text-sm font-medium text-gray-400 mb-3">Daily Breakdown</div>

                <div className="max-h-64 overflow-y-auto bg-gray-900 rounded p-3">

                  <table className="w-full text-sm">

                    <thead className="text-gray-500 border-b border-gray-700">

                      <tr>

                        <th className="text-left py-2">Date</th>

                        <th className="text-right py-2">Impr.</th>

                        <th className="text-right py-2">Clicks</th>

                        <th className="text-right py-2">Conv.</th>

                        <th className="text-right py-2">Spent</th>

                      </tr>

                    </thead>

                    <tbody className="divide-y divide-gray-800">

                      {selectedCampaign.dailyMetrics.map((day, i) => (

                        <tr key={i} className="text-gray-300">

                          <td className="py-2">{day.date}</td>

                          <td className="text-right">{day.impressions.toLocaleString()}</td>

                          <td className="text-right">{day.clicks.toLocaleString()}</td>

                          <td className="text-right text-emerald-400">{day.conversions}</td>

                          <td className="text-right">${day.spent.toLocaleString()}</td>

                        </tr>

                      ))}

                    </tbody>

                  </table>

                </div>

              </div>

            )}

            {/* Goals */}

            {selectedCampaign.goals && (

              <div>

                <div className="text-sm font-medium text-gray-400 mb-3">Campaign Goals</div>

                <div className="grid grid-cols-3 gap-3">

                  <div className="bg-gray-900 rounded p-3 text-center">

                    <div className="text-xs text-gray-500">Target Conversions</div>

                    <div className="text-lg font-bold text-white">{selectedCampaign.goals.targetConversions}</div>

                  </div>

                  <div className="bg-gray-900 rounded p-3 text-center">

                    <div className="text-xs text-gray-500">Target CPA</div>

                    <div className="text-lg font-bold text-white">${selectedCampaign.goals.targetCPA}</div>

                  </div>

                  <div className="bg-gray-900 rounded p-3 text-center">

                    <div className="text-xs text-gray-500">Target ROAS</div>

                    <div className="text-lg font-bold text-emerald-400">{selectedCampaign.goals.targetROAS}x</div>

                  </div>

                </div>

              </div>

            )}

            {/* Target Audience & Channels */}

            {(selectedCampaign.targetAudience || (selectedCampaign.channels && selectedCampaign.channels.length > 0)) && (

              <div className="space-y-3">

                {selectedCampaign.targetAudience && (

                  <div>

                    <div className="text-sm font-medium text-gray-400 mb-1">Target Audience</div>

                    <div className="text-sm text-gray-300">🎯 {selectedCampaign.targetAudience}</div>

                  </div>

                )}

                {selectedCampaign.channels && selectedCampaign.channels.length > 0 && (

                  <div>

                    <div className="text-sm font-medium text-gray-400 mb-1">Channels</div>

                    <div className="flex gap-2 flex-wrap">

                      {selectedCampaign.channels.map((ch, i) => (

                        <span key={i} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded">{ch}</span>

                      ))}

                    </div>

                  </div>

                )}

              </div>

            )}

            {/* Edit Button */}

            <div className="pt-2">

              <button onClick={() => setSelectedCampaign(null)} className="w-full px-4 py-2 bg-[#DC143C] hover:bg-[#DC143C]/80 text-white rounded font-medium">

                ✏️ Edit Campaign

              </button>

            </div>

          </div>

        )}

      </Modal>

    <SavedOutputs panel="campaign" />
    </div>

  );

}