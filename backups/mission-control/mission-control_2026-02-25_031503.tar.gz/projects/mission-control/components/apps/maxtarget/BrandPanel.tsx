'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface BrandAsset {
  name: string;
  type: string;
  url?: string;
}

const BRAND_GUIDELINES = {
  colors: [
    { name: 'Primary Red', hex: '#DC143C', usage: 'CTAs, headlines, accent elements' },
    { name: 'Dark Background', hex: '#111827', usage: 'Primary backgrounds' },
    { name: 'Card Background', hex: '#1F2937', usage: 'Cards, panels, modals' },
    { name: 'Border Gray', hex: '#374151', usage: 'Borders, dividers' },
    { name: 'Text White', hex: '#F9FAFB', usage: 'Primary text' },
    { name: 'Text Gray', hex: '#D1D5DB', usage: 'Secondary text' },
  ],
  fonts: [
    { name: 'Inter', weight: 'Regular / Medium / Bold', usage: 'Body text, UI elements' },
    { name: 'Inter', weight: 'Bold / Extra Bold', usage: 'Headlines, titles' },
    { name: 'Mono (JetBrains Mono)', weight: 'Regular', usage: 'Code, technical content' },
  ],
  voice: {
    tone: 'Professional, confident, data-driven. No fluff.',
    personality: 'Expert advisor who cuts through the noise. Direct but not cold.',
    doList: ['Use active voice', 'Lead with data', 'Be specific, not vague', 'Use "you" to address the reader', 'Include clear CTAs'],
    dontList: ['Don\'t use jargon without explanation', 'Don\'t be overly casual', 'Don\'t make unsubstantiated claims', 'Don\'t use passive voice', 'Don\'t bury the lede'],
  },
};

const BRAND_ASSETS: BrandAsset[] = [
  { name: 'SpecTarget Logo (Dark)', type: 'Logo' },
  { name: 'SpecTarget Logo (Light)', type: 'Logo' },
  { name: 'MaxTarget Logo', type: 'Logo' },
  { name: 'Brand Icon Set', type: 'Icons' },
  { name: 'Social Media Templates', type: 'Templates' },
  { name: 'Email Header', type: 'Templates' },
  { name: 'Pitch Deck Template', type: 'Templates' },
];

export default function BrandPanel() {
  const [brandTab, setBrandTab] = useState<'guidelines' | 'assets' | 'voicecheck' | 'naming' | 'taglines'>('guidelines');
  const [content, setContent] = useState('');
  const [voiceCheckResult, setVoiceCheckResult] = useState<{ score: number; feedback: string[] } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=brand');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'brand', title, content, tags: ['brand'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateBrandContent = async (action: string, params: Record<string, string>) => {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/brand', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...params }),
      });
      if (res.ok) { const data = await res.json(); setContent(data.content || JSON.stringify(data, null, 2)); setSuccess('Brand content generated'); }
      else { setError('Failed to generate brand content'); }
    } catch { setError('Error generating brand content'); }
    finally { setLoading(false); }
  };

  const checkBrandVoice = (text: string) => {
    if (!text.trim()) return;
    const feedback: string[] = [];
    let score = 100;

    // Simple heuristic checks
    if (text.includes('synergy') || text.includes('leverage') || text.includes('paradigm')) {
      feedback.push('❌ Contains corporate jargon (synergy, leverage, paradigm). Simplify.');
      score -= 15;
    }
    if (!/\d/.test(text)) {
      feedback.push('⚠️ No data points found. Lead with specific numbers when possible.');
      score -= 10;
    }
    if (text.split('. ').some(s => s.length > 200)) {
      feedback.push('⚠️ Some sentences are very long. Break them up for readability.');
      score -= 10;
    }
    if (/\b(was|were|been|being)\b/i.test(text)) {
      feedback.push('⚠️ Passive voice detected. Prefer active voice.');
      score -= 5;
    }
    if (!/\byou\b/i.test(text)) {
      feedback.push('⚠️ Missing "you" — address the reader directly.');
      score -= 10;
    }
    if (text.length < 50) {
      feedback.push('⚠️ Very short content. Hard to assess voice fully.');
      score -= 5;
    }
    if (feedback.length === 0) {
      feedback.push('✅ Content matches brand voice guidelines well!');
    }

    setVoiceCheckResult({ score: Math.max(score, 0), feedback });
    setSuccess('Voice check complete');
  };

  const renderGuidelines = () => (
    <div className="space-y-6">
      {/* Colors */}
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="text-sm font-semibold text-gray-100 mb-3">🎨 Brand Colors</div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {BRAND_GUIDELINES.colors.map(color => (
            <div key={color.hex} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded border border-gray-600" style={{ backgroundColor: color.hex }} />
              <div>
                <div className="text-sm text-gray-100 font-medium">{color.name}</div>
                <div className="text-xs text-gray-500">{color.hex}</div>
                <div className="text-xs text-gray-400">{color.usage}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fonts */}
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="text-sm font-semibold text-gray-100 mb-3">🔤 Typography</div>
        <div className="space-y-2">
          {BRAND_GUIDELINES.fonts.map((font, i) => (
            <div key={i} className="flex justify-between items-center py-2 border-b border-gray-700 last:border-0">
              <div>
                <div className="text-sm text-gray-100">{font.name} — {font.weight}</div>
                <div className="text-xs text-gray-500">{font.usage}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Voice */}
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="text-sm font-semibold text-gray-100 mb-3">🎤 Brand Voice</div>
        <div className="mb-3">
          <div className="text-xs text-gray-500 mb-1">Tone</div>
          <div className="text-sm text-gray-100">{BRAND_GUIDELINES.voice.tone}</div>
        </div>
        <div className="mb-3">
          <div className="text-xs text-gray-500 mb-1">Personality</div>
          <div className="text-sm text-gray-100">{BRAND_GUIDELINES.voice.personality}</div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-emerald-400 font-semibold mb-2">✅ Do</div>
            <ul className="space-y-1">{BRAND_GUIDELINES.voice.doList.map((item, i) => <li key={i} className="text-xs text-gray-300">• {item}</li>)}</ul>
          </div>
          <div>
            <div className="text-xs text-red-400 font-semibold mb-2">❌ Don't</div>
            <ul className="space-y-1">{BRAND_GUIDELINES.voice.dontList.map((item, i) => <li key={i} className="text-xs text-gray-300">• {item}</li>)}</ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAssets = () => (
    <div className="space-y-4">
      <div className="text-sm font-semibold text-gray-100">📁 Brand Assets</div>
      <div className="space-y-2">
        {BRAND_ASSETS.map((asset, i) => (
          <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700 flex justify-between items-center">
            <div>
              <div className="text-sm text-gray-100">{asset.name}</div>
              <div className="text-xs text-gray-500">{asset.type}</div>
            </div>
            <div className="text-xs px-2 py-1 bg-gray-700 rounded text-gray-400">📁 Asset</div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderVoiceCheck = () => {
    const [checkText, setCheckText] = useState('');
    return (
      <div className="space-y-4">
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-semibold text-gray-100 mb-2">🎤 Brand Voice Checker</div>
          <div className="text-xs text-gray-500 mb-3">Paste your copy to check if it matches SpecTarget brand guidelines</div>
          <textarea value={checkText} onChange={e => setCheckText(e.target.value)} rows={6} placeholder="Paste your marketing copy here..."
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          <button onClick={() => checkBrandVoice(checkText)}
            className="w-full mt-3 px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium">
            🔍 Check Voice
          </button>
        </div>

        {voiceCheckResult && (
          <div className="bg-gray-800 rounded p-4 border border-gray-700">
            <div className="flex justify-between items-center mb-3">
              <div className="text-sm font-semibold text-gray-100">Voice Score</div>
              <div className={`text-2xl font-bold ${
                voiceCheckResult.score >= 80 ? 'text-emerald-400' :
                voiceCheckResult.score >= 60 ? 'text-yellow-400' : 'text-red-400'
              }`}>{voiceCheckResult.score}/100</div>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
              <div className={`h-2 rounded-full transition-all ${
                voiceCheckResult.score >= 80 ? 'bg-emerald-500' :
                voiceCheckResult.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
              }`} style={{ width: `${voiceCheckResult.score}%` }} />
            </div>
            <div className="space-y-2">
              {voiceCheckResult.feedback.map((fb, i) => (
                <div key={i} className="text-sm text-gray-300">{fb}</div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderNaming = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Concept/Idea</label>
          <input type="text" placeholder="What is the product/feature about?" id="namingConcept" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Industry</label>
          <input type="text" placeholder="e.g., SaaS, fintech, healthcare..." id="namingIndustry" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateBrandContent('naming', { concept: (document.getElementById('namingConcept') as HTMLInputElement).value, industry: (document.getElementById('namingIndustry') as HTMLInputElement).value });
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Brainstorming...' : '💡 Generate Names'}
        </button>
      </div>
      {content && (
        <div className="space-y-2">
          {content.split('\n').filter(Boolean).slice(0, 20).map((name, i) => (
            <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700 hover:border-red-600/30 flex justify-between items-center">
              <div className="text-sm text-gray-100 font-semibold">{name}</div>
              <button onClick={() => { navigator.clipboard.writeText(name); setSuccess('Name copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderTaglines = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Brand</label>
          <input type="text" placeholder="Your brand name..." id="taglineBrand" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Mission/Purpose</label>
          <textarea placeholder="What is your brand mission?" id="taglineMission" rows={2} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateBrandContent('taglines', { brand: (document.getElementById('taglineBrand') as HTMLInputElement).value, mission: (document.getElementById('taglineMission') as HTMLTextAreaElement).value });
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '📝 Generate Taglines'}
        </button>
      </div>
      {content && (
        <div className="space-y-2">
          {content.split('\n').filter(Boolean).slice(0, 15).map((tagline, i) => (
            <div key={i} className="bg-gray-800 rounded p-3 border border-gray-700 hover:border-red-600/30 flex justify-between items-center">
              <div className="text-sm text-gray-100">{tagline}</div>
              <button onClick={() => { navigator.clipboard.writeText(tagline); setSuccess('Tagline copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'guidelines', label: '📖 Guidelines' },
          { id: 'assets', label: '📁 Assets' },
          { id: 'voicecheck', label: '🎤 Voice Check' },
          { id: 'naming', label: '💡 Naming' },
          { id: 'taglines', label: '📝 Taglines' },
        ].map(t => (
          <button key={t.id} onClick={() => setBrandTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              brandTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {brandTab === 'guidelines' && renderGuidelines()}
      {brandTab === 'assets' && renderAssets()}
      {brandTab === 'voicecheck' && renderVoiceCheck()}
      {brandTab === 'naming' && renderNaming()}
      {brandTab === 'taglines' && renderTaglines()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
