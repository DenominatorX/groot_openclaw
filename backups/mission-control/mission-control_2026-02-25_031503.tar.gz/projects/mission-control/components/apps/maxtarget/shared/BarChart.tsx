'use client';

interface BarChartData {
  label: string;
  value: number;
  color?: string;
}

interface BarChartProps {
  data: BarChartData[];
  height?: number;
  showLabels?: boolean;
  maxValue?: number;
}

export default function BarChart({ data, height = 160, showLabels = true, maxValue }: BarChartProps) {
  const computedMax = maxValue || Math.max(...data.map(d => d.value), 1);

  return (
    <div className="flex items-end gap-1 justify-center" style={{ height: `${height}px` }}>
      {data.map((item, i) => {
        const barHeight = Math.max((item.value / computedMax) * (height - 30), 8);
        const colors = [
          'bg-blue-500',
          'bg-yellow-500',
          'bg-orange-500',
          'bg-purple-500',
          'bg-emerald-500',
          'bg-red-500',
          'bg-cyan-500',
          'bg-pink-500',
        ];
        const color = item.color || colors[i % colors.length];

        return (
          <div key={i} className="flex flex-col items-center flex-1">
            {showLabels && (
              <div className="text-xs font-bold text-white mb-1">{item.value.toLocaleString()}</div>
            )}
            <div
              className={`w-full max-w-[60px] ${color} rounded-t transition-all`}
              style={{ height: `${barHeight}px` }}
            />
            {showLabels && (
              <div className="text-xs text-gray-500 mt-2 text-center leading-tight truncate max-w-[80px]">
                {item.label}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
