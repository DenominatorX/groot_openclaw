'use client';
import { useState, useEffect } from 'react';

interface SavedOutput {
  id: string;
  panel: string;
  title: string;
  content: string;
  createdAt: string;
  tags: string[];
}

interface AdVariant {
  id: string;
  headline?: string;
  description?: string;
  primaryText?: string;
  platform: string;
  content: string;
  cta?: string;
}

const PLATFORM_CHAR_LIMITS: Record<string, { headline: number; description: number }> = {
  'Google Ads': { headline: 30, description: 90 },
  'LinkedIn': { headline: 70, description: 150 },
  'Meta': { headline: 40, description: 125 },
  'Programmatic': { headline: 50, description: 150 },
};

export default function AdPanel() {
  const [adTab, setAdTab] = useState<'copy' | 'google' | 'library' | 'landing' | 'utm'>('copy');
  const [ads, setAds] = useState<AdVariant[]>([]);
  const [savedAds, setSavedAds] = useState<AdVariant[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState('Google Ads');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Saved Outputs from API
  const [savedOutputs, setSavedOutputs] = useState<SavedOutput[]>([]);
  const [outputsLoading, setOutputsLoading] = useState(false);
  const [outputsExpanded, setOutputsExpanded] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState<string | null>(null);

  // Fetch saved outputs on mount
  useEffect(() => {
    const fetchSavedOutputs = async () => {
      setOutputsLoading(true);
      try {
        const res = await fetch('/api/apps/maxtarget/ai-outputs?panel=ads');
        if (res.ok) {
          const data = await res.json();
          setSavedOutputs(data.outputs || []);
        }
      } catch (e) {
        console.error('Failed to fetch saved outputs:', e);
      } finally {
        setOutputsLoading(false);
      }
    };
    fetchSavedOutputs();
  }, []);

  const saveCurrentOutput = async (title: string, content: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ panel: 'ads', title, content, tags: ['ads'] }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedOutputs(prev => [data.output, ...prev]);
        setSuccess('Output saved');
      } else {
        setError('Failed to save output');
      }
    } catch (e) {
      setError('Failed to save output');
    }
  };

  const deleteSavedOutput = async (id: string) => {
    try {
      const res = await fetch('/api/apps/maxtarget/ai-outputs', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setSavedOutputs(prev => prev.filter(o => o.id !== id));
        setSuccess('Output deleted');
      } else {
        setError('Failed to delete output');
      }
    } catch (e) {
      setError('Failed to delete output');
    }
  };

  const generateAdCopy = async (product: string, audience: string, platform: string) => {
    if (!product.trim() || !audience.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/ads', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'copy', product, audience, platform }) });
      if (res.ok) { const data = await res.json(); setAds((data.ads || []).map((a: any, i: number) => ({ ...a, id: Date.now().toString() + i }))); setSuccess('Ad copy generated'); }
      else { setError('Failed to generate ad copy'); }
    } catch { setError('Error generating ad copy'); }
    finally { setLoading(false); }
  };

  const generateGoogleAds = async (product: string, keywords: string) => {
    if (!product.trim() || !keywords.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/ads', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'google', product, keywords }) });
      if (res.ok) { const data = await res.json(); setAds((data.ads || []).map((a: any, i: number) => ({ ...a, id: Date.now().toString() + i }))); setSuccess('Google Ads generated'); }
      else { setError('Failed to generate Google Ads'); }
    } catch { setError('Error generating Google Ads'); }
    finally { setLoading(false); }
  };

  const generateLandingPage = async (headline: string, productDescription: string) => {
    if (!headline.trim() || !productDescription.trim()) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/apps/maxtarget/ads', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'landing', headline, productDescription }) });
      if (res.ok) { const data = await res.json(); setAds([{ id: Date.now().toString(), platform: 'landing-page', content: data.landingPage }]); setSuccess('Landing page copy generated'); }
      else { setError('Failed to generate landing page'); }
    } catch { setError('Error generating landing page'); }
    finally { setLoading(false); }
  };

  const limits = PLATFORM_CHAR_LIMITS[selectedPlatform] || { headline: 50, description: 150 };

  const renderCopy = () => (
    <div className="space-y-4">
      {/* Platform Tabs */}
      <div className="flex gap-2 flex-wrap">
        {Object.keys(PLATFORM_CHAR_LIMITS).map(p => (
          <button key={p} onClick={() => setSelectedPlatform(p)}
            className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
              selectedPlatform === p ? 'bg-[#DC143C]/20 text-[#DC143C] border border-[#DC143C]/50' : 'bg-gray-800 text-gray-400 border border-gray-700 hover:text-gray-300'
            }`}>{p}</button>
        ))}
      </div>

      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div className="text-xs text-gray-500">Limits: Headline {limits.headline} chars | Description {limits.description} chars</div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Product/Service</label>
          <input type="text" placeholder="What are you selling?" id="adProduct" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Audience</label>
          <input type="text" placeholder="e.g., CMOs, marketing teams..." id="adAudience" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateAdCopy(
            (document.getElementById('adProduct') as HTMLInputElement).value,
            (document.getElementById('adAudience') as HTMLInputElement).value,
            selectedPlatform
          );
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '✨ Generate Ad Copy'}
        </button>
      </div>

      {/* Ad Preview Cards */}
      <div className="space-y-3">
        {ads.map((ad) => (
          <div key={ad.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
            {/* Ad Preview */}
            <div className="bg-gray-900 p-4 border-b border-gray-700">
              <div className="text-[10px] text-gray-500 uppercase mb-2">Ad Preview — {selectedPlatform}</div>
              {selectedPlatform === 'Google Ads' ? (
                <div>
                  <div className="text-blue-400 text-sm font-medium">{ad.headline || ad.content.split('\n')[0]}</div>
                  <div className="text-green-400 text-xs mt-0.5">yoursite.com</div>
                  <div className="text-gray-300 text-xs mt-1">{ad.description || ad.content}</div>
                </div>
              ) : selectedPlatform === 'Meta' ? (
                <div className="border border-gray-700 rounded overflow-hidden">
                  <div className="bg-gray-700 h-20 flex items-center justify-center text-gray-500 text-xs">Image/Video</div>
                  <div className="p-3">
                    <div className="text-sm text-gray-100 font-medium">{ad.headline || 'Ad Headline'}</div>
                    <div className="text-xs text-gray-400 mt-1">{ad.description || ad.content}</div>
                    <button className="mt-2 text-xs bg-[#DC143C] text-white px-3 py-1 rounded">{ad.cta || 'Learn More'}</button>
                  </div>
                </div>
              ) : (
                <div className="p-2">
                  <div className="text-sm text-gray-100 font-medium mb-1">{ad.headline || 'Ad Headline'}</div>
                  <div className="text-xs text-gray-400">{ad.description || ad.content}</div>
                  {ad.cta && <div className="text-xs text-emerald-400 mt-2">CTA: {ad.cta}</div>}
                </div>
              )}
            </div>
            <div className="p-3 flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(ad.content); setSuccess('Ad copy copied'); }}
                className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
              <button onClick={() => { setSavedAds(prev => [...prev, ad]); setSuccess('Ad saved'); }}
                className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderGoogle = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Product</label>
          <input type="text" placeholder="Your product name..." id="googleProduct" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Keywords</label>
          <input type="text" placeholder="keyword1, keyword2, keyword3..." id="googleKeywords" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateGoogleAds((document.getElementById('googleProduct') as HTMLInputElement).value, (document.getElementById('googleKeywords') as HTMLInputElement).value);
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '🔎 Generate Google Ads'}
        </button>
      </div>
      {ads.length > 0 && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-xs text-gray-400 mb-3">Responsive Search Ad (RSA) Preview</div>
          <div className="bg-gray-700 p-3 rounded space-y-2 text-xs mb-3">
            {ads.map((ad, i) => (
              <div key={i} className="border-l-2 border-green-500 pl-2">
                <div className="text-blue-400 font-semibold">{ad.headline}</div>
                <div className="text-gray-300">{ad.description}</div>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={() => { navigator.clipboard.writeText(ads.map(a => `${a.headline}\n${a.description}`).join('\n\n')); setSuccess('Ads copied'); }}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy All</button>
            <button onClick={() => { setSavedAds(prev => [...prev, ...ads]); setSuccess('All ads saved'); }}
              className="text-xs px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 rounded text-emerald-400">📌 Save All</button>
          </div>
        </div>
      )}
    </div>
  );

  const renderLibrary = () => (
    <div className="space-y-4">
      {savedAds.length === 0 ? (
        <div className="bg-gray-800 rounded p-8 border border-gray-700 text-center">
          <div className="text-4xl mb-3">💰</div>
          <div className="text-gray-400 mb-2">No saved ads yet</div>
          <div className="text-gray-500 text-sm">Generate ad copy and save your best variations here</div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="text-sm font-semibold text-gray-100">💰 Saved Ads ({savedAds.length})</div>
          {savedAds.map((ad, i) => (
            <div key={ad.id + i} className="bg-gray-800 rounded p-4 border border-gray-700">
              <div className="flex justify-between items-start">
                <div className="text-xs font-semibold text-red-600 mb-2">{ad.platform}</div>
                <button onClick={() => setSavedAds(prev => prev.filter((_, j) => j !== i))} className="text-xs text-red-400 hover:text-red-300">✕</button>
              </div>
              {ad.headline && <div className="text-sm text-gray-100 font-medium mb-1">{ad.headline}</div>}
              <p className="text-sm text-gray-300">{ad.description || ad.content}</p>
              {ad.cta && <div className="text-xs text-emerald-400 mt-1">CTA: {ad.cta}</div>}
              <button onClick={() => { navigator.clipboard.writeText(ad.content || `${ad.headline}\n${ad.description}`); setSuccess('Ad copied'); }}
                className="text-xs mt-2 px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderLanding = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Hero Headline</label>
          <input type="text" placeholder="Your main value proposition..." id="landingHeadline" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Product Description</label>
          <textarea placeholder="What does your product do? Key features and benefits..." id="landingDesc" rows={4} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          generateLandingPage((document.getElementById('landingHeadline') as HTMLInputElement).value, (document.getElementById('landingDesc') as HTMLTextAreaElement).value);
        }} disabled={loading} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium disabled:opacity-50">
          {loading ? '⏳ Generating...' : '🎨 Generate Landing Page'}
        </button>
      </div>
      {ads.length > 0 && ads[0]?.platform === 'landing-page' && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-xs text-gray-400 mb-3">Landing Page Copy Preview</div>
          <div className="bg-gray-700 p-3 rounded text-xs text-gray-100 whitespace-pre-wrap max-h-96 overflow-y-auto mb-3">{ads[0]?.content}</div>
          <button onClick={() => { navigator.clipboard.writeText(ads[0]?.content || ''); setSuccess('Landing page copied'); }}
            className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copy</button>
        </div>
      )}
    </div>
  );

  const renderUTM = () => (
    <div className="space-y-4">
      <div className="bg-gray-800 rounded p-4 border border-gray-700 space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Campaign Name</label>
          <input type="text" placeholder="e.g., spring-sale, product-launch..." id="utmCampaign" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Source</label>
            <input type="text" placeholder="google, facebook, email..." id="utmSource" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Medium</label>
            <input type="text" placeholder="cpc, organic, email..." id="utmMedium" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Content (Optional)</label>
          <input type="text" placeholder="ad-variant-1, button-text..." id="utmContent" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-gray-100 placeholder-gray-500" />
        </div>
        <button onClick={() => {
          const campaign = (document.getElementById('utmCampaign') as HTMLInputElement).value;
          const source = (document.getElementById('utmSource') as HTMLInputElement).value;
          const medium = (document.getElementById('utmMedium') as HTMLInputElement).value;
          const content = (document.getElementById('utmContent') as HTMLInputElement).value;
          const utm = `https://yoursite.com/landing?utm_campaign=${encodeURIComponent(campaign)}&utm_source=${encodeURIComponent(source)}&utm_medium=${encodeURIComponent(medium)}&utm_content=${encodeURIComponent(content)}`;
          navigator.clipboard.writeText(utm);
          setSuccess('UTM URL copied');
        }} className="w-full px-4 py-2 bg-red-600/20 text-red-600 hover:bg-red-600/30 rounded font-medium">
          🔗 Generate & Copy UTM URL
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {error && <div className="p-3 bg-red-500/20 text-red-400 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded text-sm">{success}</div>}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-3">
        {[
          { id: 'copy', label: '✨ Copy' },
          { id: 'google', label: '🔎 Google' },
          { id: 'library', label: '📚 Library' },
          { id: 'landing', label: '🎨 Landing' },
          { id: 'utm', label: '🔗 UTM' },
        ].map(t => (
          <button key={t.id} onClick={() => setAdTab(t.id as any)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              adTab === t.id ? 'bg-red-600/20 text-red-600' : 'text-gray-400 hover:text-gray-300'
            }`}>{t.label}</button>
        ))}
      </div>
      {adTab === 'copy' && renderCopy()}
      {adTab === 'google' && renderGoogle()}
      {adTab === 'library' && renderLibrary()}
      {adTab === 'landing' && renderLanding()}
      {adTab === 'utm' && renderUTM()}

      {/* Saved Outputs Section */}
      <div className="border-t border-gray-700 pt-4 mt-6">
        <button
          onClick={() => setOutputsExpanded(!outputsExpanded)}
          className="flex items-center gap-2 text-sm font-semibold text-gray-300 hover:text-white transition-colors"
        >
          <span className="text-lg">📁</span>
          Saved Outputs
          <span className="text-xs bg-[#DC143C]/20 text-[#DC143C] px-2 py-0.5 rounded">
            {savedOutputs.length}
          </span>
          <span className={`transform transition-transform ${outputsExpanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </button>

        {outputsExpanded && (
          <div className="mt-3 space-y-3">
            {outputsLoading ? (
              <div className="text-gray-500 text-sm">Loading...</div>
            ) : savedOutputs.length === 0 ? (
              <div className="text-gray-500 text-sm">No saved outputs yet</div>
            ) : (
              savedOutputs.map(output => (
                <div key={output.id} className="bg-gray-800 rounded border border-gray-700 overflow-hidden">
                  <div 
                    className="flex justify-between items-start p-3 cursor-pointer hover:bg-gray-750"
                    onClick={() => setExpandedOutput(expandedOutput === output.id ? null : output.id)}
                  >
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-100">{output.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(output.createdAt).toLocaleDateString()}
                      </div>
                      {expandedOutput !== output.id && (
                        <div className="text-xs text-gray-400 mt-1 line-clamp-2">
                          {output.content.substring(0, 150)}...
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteSavedOutput(output.id); }}
                      className="text-xs text-red-400 hover:text-red-300 ml-2"
                    >
                      ✕
                    </button>
                  </div>
                  {expandedOutput === output.id && (
                    <div className="px-3 pb-3">
                      <div className="text-sm text-gray-300 whitespace-pre-wrap bg-gray-900 p-2 rounded max-h-60 overflow-y-auto">
                        {output.content}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { navigator.clipboard.writeText(output.content); setSuccess('Copied'); }}
                          className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
                        >
                          📋 Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
