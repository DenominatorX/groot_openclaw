'use client';

import { SavedOutputs } from './shared';
import { useEffect, useState } from 'react';
import KPICard from './shared/KPICard';
import BarChart from './shared/BarChart';
import ProgressBar from './shared/ProgressBar';

interface EngagementEvent {
  date: string;
  type: 'email_open' | 'page_visit' | 'form_submit' | 'meeting' | 'call' | 'demo_scheduled' | 'proposal_sent' | 'contract_review' | 'pricing_discussion' | 'case_study_shared' | 'webinar_attended' | 'trade_show_met' | 'referral_intro';
  detail: string;
}

interface Lead {
  id: string;
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  source: string;
  score: number;
  stage: 'Lead' | 'MQL' | 'SQL' | 'Opportunity' | 'Closed Won' | 'Closed Lost';
  notes: string;
  createdDate: string;
  lastTouched: string;
  engagementHistory?: EngagementEvent[];
  assignedTo?: string;
  estimatedValue?: number;
  tags?: string[];
}

interface DailyMetric {
  date: string;
  impressions: number;
  clicks: number;
  conversions: number;
  spent: number;
}

interface Campaign {
  id: string;
  name: string;
  type: 'ip-targeting' | 'geofencing' | 'ctv' | 'retargeting' | 'programmatic' | 'email' | 'ABM';
  status: 'draft' | 'active' | 'paused' | 'completed';
  budget: number;
  spent: number;
  startDate: string;
  endDate: string;
  metrics: {
    impressions: number;
    clicks: number;
    conversions: number;
    ctr: number;
    cpa: number;
    roas: number;
  };
  dailyMetrics?: DailyMetric[];
}

interface Activity {
  id: string;
  entityType: string;
  entityId: string;
  action: string;
  detail: string;
  timestamp: string;
  userId: string;
}

interface DashboardData {
  leads: Lead[];
  campaigns: Campaign[];
  activities: Activity[];
}

interface TrendMetric {
  label: string;
  value: string;
  change: number;
  direction: 'up' | 'down' | 'stable';
}

export default function DashboardPanel() {
  const [data, setData] = useState<DashboardData>({
    leads: [],
    campaigns: [],
    activities: [],
  });
  const [loading, setLoading] = useState(true);
const [error, setError] = useState<string | null>(null);
  const [trends, setTrends] = useState<TrendMetric[]>([]);
  const [topCampaign, setTopCampaign] = useState<Campaign | null>(null);
  const [industryAvgCPA] = useState(20); // Industry average CPA for IP targeting

  useEffect(() => {
    const loadData = async () => {
      try {
        const [leadsRes, campaignsRes, activitiesRes] = await Promise.all([
          fetch('/api/apps/maxtarget/leads'),
          fetch('/api/apps/maxtarget/campaigns'),
          fetch('/api/apps/maxtarget/activities'),
        ]);

        const leadsData = leadsRes.ok ? await leadsRes.json() : [];
        const campaignsData = campaignsRes.ok ? await campaignsRes.json() : { campaigns: [] };
        const activitiesData = activitiesRes.ok ? await activitiesRes.json() : { activities: [] };

        setData({
          leads: Array.isArray(leadsData) ? leadsData : leadsData.leads || [],
          campaigns: campaignsData.campaigns || [],
          activities: (activitiesData.activities || []).slice(0, 15),
        });
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
        setError('Failed to load data — check network.');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Calculate trends from campaign dailyMetrics
  useEffect(() => {
    if (data.campaigns.length === 0) return;

    const calculateTrends = () => {
      const activeCampaigns = data.campaigns.filter(c => c.status === 'active' || c.status === 'completed');
      
      // Calculate totals for last 7 days vs previous 7 days using reduce
      const now = new Date();
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const fourteenDaysAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);

      const { current, previous } = activeCampaigns.reduce((acc, campaign) => {
        if (!campaign.dailyMetrics) return acc;

        return campaign.dailyMetrics.reduce((innerAcc, metric) => {
          const metricDate = new Date(metric.date);
          if (metricDate >= sevenDaysAgo) {
            innerAcc.current.impressions += metric.impressions;
            innerAcc.current.clicks += metric.clicks;
            innerAcc.current.conversions += metric.conversions;
            innerAcc.current.spend += metric.spent;
          } else if (metricDate >= fourteenDaysAgo) {
            innerAcc.previous.impressions += metric.impressions;
            innerAcc.previous.clicks += metric.clicks;
            innerAcc.previous.conversions += metric.conversions;
            innerAcc.previous.spend += metric.spent;
          }
          return innerAcc;
        }, acc);
      }, {
        current: { impressions: 0, clicks: 0, conversions: 0, spend: 0 },
        previous: { impressions: 0, clicks: 0, conversions: 0, spend: 0 },
      });

      const calcChange = (current: number, previous: number) => {
        if (previous === 0) return 0;
        return ((current - previous) / previous) * 100;
      };

      const calcDirection = (change: number) => {
        if (change > 2) return 'up';
        if (change < -2) return 'down';
        return 'stable';
      };

      setTrends([
        {
          label: 'Impressions',
          value: current.impressions.toLocaleString(),
          change: calcChange(current.impressions, previous.impressions),
          direction: calcDirection(calcChange(current.impressions, previous.impressions)),
        },
        {
          label: 'Clicks',
          value: current.clicks.toLocaleString(),
          change: calcChange(current.clicks, previous.clicks),
          direction: calcDirection(calcChange(current.clicks, previous.clicks)),
        },
        {
          label: 'Conversions',
          value: current.conversions.toString(),
          change: calcChange(current.conversions, previous.conversions),
          direction: calcDirection(calcChange(current.conversions, previous.conversions)),
        },
        {
          label: 'Ad Spend',
          value: `$${current.spend.toLocaleString()}`,
          change: calcChange(current.spend, previous.spend),
          direction: calcDirection(calcChange(current.spend, previous.spend)),
        },
      ]);

      // Find top performing campaign (by ROAS)
      const activeWithMetrics = data.campaigns.filter(c => 
        c.metrics && c.metrics.conversions > 0 && c.status !== 'draft'
      );
      
      if (activeWithMetrics.length > 0) {
        const top = activeWithMetrics.reduce((best, current) => 
          (current.metrics.roas || 0) > (best.metrics.roas || 0) ? current : best
        );
        setTopCampaign(top);
      }
    };

    calculateTrends();
  }, [data.campaigns]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-400">{error}</div>
      </div>
    );
  }

  // KPI Calculations
  const totalLeads = data.leads.length;
  const activeCampaigns = data.campaigns.filter(c => c.status === 'active').length;
  const pipelineValue = data.leads.reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);
  const avgLeadScore = totalLeads > 0
    ? Math.round(data.leads.reduce((sum, lead) => sum + lead.score, 0) / totalLeads)
    : 0;

  // Calculate average CPA across all campaigns
  const totalConversions = data.campaigns.reduce((sum, c) => sum + (c.metrics?.conversions || 0), 0);
  const totalSpent = data.campaigns.reduce((sum, c) => sum + c.spent, 0);
  const avgCPA = totalConversions > 0 ? Math.round(totalSpent / totalConversions) : 0;

  // Pipeline funnel data (map to simpler stages)
  const funnelData = [
    { label: 'Prospect', value: data.leads.filter(l => l.stage === 'Lead').length },
    { label: 'Qualified', value: data.leads.filter(l => l.stage === 'MQL').length },
    { label: 'Proposal', value: data.leads.filter(l => l.stage === 'SQL').length },
    { label: 'Negotiation', value: data.leads.filter(l => l.stage === 'Opportunity').length },
    { label: 'Won', value: data.leads.filter(l => l.stage === 'Closed Won').length },
    { label: 'Lost', value: data.leads.filter(l => l.stage === 'Closed Lost').length },
  ];

  // Campaign spend vs budget (top 5 by budget)
  const topCampaigns = [...data.campaigns]
    .sort((a, b) => b.budget - a.budget)
    .slice(0, 5);

  // Activity icons
  const getActionIcon = (action: string): string => {
    switch (action) {
      case 'created': return '➕';
      case 'status_changed': return '🔄';
      case 'stage_updated': return '📈';
      case 'budget_adjusted': return '💰';
      case 'note_added': return '📝';
      case 'completed': return '✅';
      default: return '📌';
    }
  };

  // Format timestamp
  const formatTimestamp = (timestamp: string): string => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Format date for display
  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  // Alert calculations
  const now = new Date();
  const fourteenDaysAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
  const staleLeads = data.leads.filter(lead => {
    const lastTouched = new Date(lead.lastTouched);
    return lastTouched < fourteenDaysAgo;
  });

  const overBudgetCampaigns = data.campaigns.filter(c => c.spent > c.budget);

  const advancedStages = ['SQL', 'Opportunity', 'Closed Won', 'Closed Lost'];
  const lowScoreAdvancedLeads = data.leads.filter(lead =>
    advancedStages.includes(lead.stage) && lead.score < 50
  );

  // Pipeline at Risk: leads with declining engagement or stuck in stage too long
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const pipelineAtRisk = data.leads.filter(lead => {
    // Lead has been in same stage for more than 21 days without progression
    const createdDate = new Date(lead.createdDate);
    const daysInStage = Math.floor((now.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
    const advancedPipeline = ['MQL', 'SQL', 'Opportunity'].includes(lead.stage);
    
    // Check for declining engagement (fewer activities in recent vs older period)
    if (lead.engagementHistory && lead.engagementHistory.length > 1) {
      const recentActivities = lead.engagementHistory.filter(a => new Date(a.date) >= fourteenDaysAgo).length;
      const olderActivities = lead.engagementHistory.filter(a => new Date(a.date) < fourteenDaysAgo && new Date(a.date) >= thirtyDaysAgo).length;
      
      const isDeclining = recentActivities < olderActivities && recentActivities === 0;
      return isDeclining || (advancedPipeline && daysInStage > 21);
    }
    
    return advancedPipeline && daysInStage > 21;
  });

  const hasAlerts = staleLeads.length > 0 || overBudgetCampaigns.length > 0 || lowScoreAdvancedLeads.length > 0;

  return (
    <div className="space-y-6">
      {/* Row 1 — KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KPICard title="Total Leads" value={totalLeads} icon="👥" />
        <KPICard title="Active Campaigns" value={activeCampaigns} icon="📢" />
        <KPICard title="Pipeline Value" value={`$${(pipelineValue / 1000).toFixed(0)}K`} icon="💵" />
        <KPICard title="Avg Lead Score" value={avgLeadScore} icon="⭐" />
      </div>

      {/* Row 2 — Trend Indicators */}
      {trends.length > 0 && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-medium text-gray-400 mb-3">📈 7-Day Trends</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {trends.map((trend, index) => (
              <div key={index} className="flex flex-col">
                <span className="text-xs text-gray-500">{trend.label}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-semibold text-gray-200">{trend.value}</span>
                  <span className={`text-xs flex items-center ${
                    trend.direction === 'up' ? 'text-green-400' : 
                    trend.direction === 'down' ? 'text-red-400' : 'text-gray-400'
                  }`}>
                    {trend.direction === 'up' ? '↑' : trend.direction === 'down' ? '↓' : '→'}
                    {Math.abs(trend.change).toFixed(1)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Row 3 — Top Performing Campaign Spotlight & Competitive Benchmark */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top Performing Campaign */}
        {topCampaign && (
          <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded p-4 border border-gray-700 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#DC143C]/10 rounded-bl-full"></div>
            <div className="text-sm font-medium text-[#DC143C] mb-2">🏆 Top Performer</div>
            <div className="text-lg font-semibold text-gray-200 truncate" title={topCampaign.name}>
              {topCampaign.name}
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3">
              <div>
                <div className="text-xs text-gray-500">ROAS</div>
                <div className="text-sm font-bold text-green-400">{topCampaign.metrics.roas}x</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">CPA</div>
                <div className="text-sm font-bold text-gray-200">${topCampaign.metrics.cpa.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Conv.</div>
                <div className="text-sm font-bold text-gray-200">{topCampaign.metrics.conversions}</div>
              </div>
            </div>
          </div>
        )}

        {/* Competitive Benchmark */}
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-medium text-gray-400 mb-3">📊 CPA Benchmark</div>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-gray-500 mb-1">Your Avg CPA</div>
              <div className={`text-2xl font-bold ${avgCPA <= industryAvgCPA ? 'text-green-400' : 'text-yellow-400'}`}>
                ${avgCPA}
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-gray-500 mb-1">Industry Avg (IP Targeting)</div>
              <div className="text-2xl font-bold text-gray-400">${industryAvgCPA}</div>
            </div>
          </div>
          <div className="mt-3">
            <div className="flex justify-between text-xs text-gray-500 mb-1">
              <span>$15</span>
              <span>$20</span>
              <span>$25</span>
              <span>$30+</span>
            </div>
            <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full ${avgCPA <= industryAvgCPA ? 'bg-green-500' : avgCPA <= 30 ? 'bg-yellow-500' : 'bg-red-500'}`}
                style={{ width: `${Math.min((avgCPA / 35) * 100, 100)}%` }}
              ></div>
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {avgCPA <= industryAvgCPA 
                ? '✅ Performing below industry average' 
                : avgCPA <= 30 
                  ? '⚠️ Slightly above industry average' 
                  : '❌ Significantly above industry average'}
            </div>
          </div>
        </div>
      </div>

      {/* Row 4 — Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pipeline Funnel */}
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-medium text-gray-400 mb-3">Pipeline Funnel</div>
          <BarChart data={funnelData} height={180} />
        </div>

        {/* Campaign Spend vs Budget */}
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-medium text-gray-400 mb-3">Campaign Spend vs Budget</div>
          <div className="space-y-3">
            {topCampaigns.map(campaign => (
              <div key={campaign.id}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-300 truncate max-w-[180px]" title={campaign.name}>
                    {campaign.name}
                  </span>
                  <span className="text-gray-400">
                    ${campaign.spent.toLocaleString()} / ${campaign.budget.toLocaleString()}
                  </span>
                </div>
                <ProgressBar
                  value={campaign.spent}
                  max={campaign.budget}
                  size="sm"
                  showPercent={false}
                />
              </div>
            ))}
            {topCampaigns.length === 0 && (
              <div className="text-gray-500 text-center py-4">No campaigns found</div>
            )}
          </div>
        </div>
      </div>

      {/* Row 5 — Pipeline at Risk */}
      {pipelineAtRisk.length > 0 && (
        <div className="bg-gray-800 rounded p-4 border border-red-500/30">
          <div className="text-sm font-medium text-red-400 mb-3 flex items-center gap-2">
            <span>⚠️</span> Pipeline at Risk — {pipelineAtRisk.length} lead{pipelineAtRisk.length > 1 ? 's' : ''}
          </div>
          <div className="space-y-2">
            {pipelineAtRisk.slice(0, 4).map(lead => {
              const daysInStage = Math.floor((now.getTime() - new Date(lead.createdDate).getTime()) / (1000 * 60 * 60 * 24));
              const lastActivity = lead.engagementHistory && lead.engagementHistory.length > 0 
                ? lead.engagementHistory[lead.engagementHistory.length - 1] 
                : null;
              
              return (
                <div key={lead.id} className="flex items-center justify-between p-2 rounded bg-gray-700/30 border border-gray-600">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-gray-200 font-medium truncate">{lead.companyName}</div>
                    <div className="text-xs text-gray-400">
                      {lead.stage} • {daysInStage} days in stage • Last: {lastActivity ? formatDate(lastActivity.date) : 'N/A'}
                    </div>
                  </div>
                  <div className="text-right shrink-0 ml-2">
                    <div className="text-xs text-gray-400">Suggested Action</div>
                    <div className="text-xs text-[#DC143C] font-medium">
                      {lead.stage === 'MQL' ? 'Schedule demo' : 
                       lead.stage === 'SQL' ? 'Send proposal' : 'Follow up on contract'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Row 6 — Activity Feed */}
      <div className="bg-gray-800 rounded p-4 border border-gray-700">
        <div className="text-sm font-medium text-gray-400 mb-3">Recent Activity</div>
        <div className="space-y-2 max-h-[320px] overflow-y-auto pr-2">
          {data.activities.map(activity => (
            <div key={activity.id} className="flex items-start gap-3 p-2 rounded hover:bg-gray-700/30">
              <span className="text-lg shrink-0">{getActionIcon(activity.action)}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium px-1.5 py-0.5 rounded bg-gray-700 text-gray-300 capitalize">
                    {activity.entityType}
                  </span>
                  <span className="text-xs text-gray-500">{formatTimestamp(activity.timestamp)}</span>
                </div>
                <div className="text-sm text-gray-300 mt-0.5 truncate" title={activity.detail}>
                  {activity.detail}
                </div>
              </div>
            </div>
          ))}
          {data.activities.length === 0 && (
            <div className="text-gray-500 text-center py-4">No recent activity</div>
          )}
        </div>
      </div>

      {/* Row 7 — Alerts */}
      {hasAlerts && (
        <div className="bg-gray-800 rounded p-4 border border-gray-700">
          <div className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
            <span>⚠️</span> Alerts
          </div>
          <div className="space-y-3">
            {/* Stale Leads - Now with actionable details */}
            {staleLeads.length > 0 && (
              <div className="flex items-start gap-2 p-3 rounded bg-yellow-500/10 border border-yellow-500/20">
                <span className="text-yellow-400">⏰</span>
                <div className="flex-1">
                  <div className="text-sm text-yellow-400 font-medium">
                    {staleLeads.length} stale lead{staleLeads.length > 1 ? 's' : ''}
                  </div>
                  <div className="mt-2 space-y-1">
                    {staleLeads.slice(0, 3).map(lead => {
                      const lastActivity = lead.engagementHistory && lead.engagementHistory.length > 0 
                        ? lead.engagementHistory[lead.engagementHistory.length - 1] 
                        : null;
                      return (
                        <div key={lead.id} className="text-xs flex justify-between">
                          <span className="text-gray-300">{lead.companyName}</span>
                          <span className="text-gray-500">
                            Last: {lastActivity ? formatDate(lastActivity.date) : lead.lastTouched}
                            <span className="ml-2 text-yellow-500/70">
                              → {lead.assignedTo === 'Unassigned' ? 'Assign to rep' : 'Re-engage'}
                            </span>
                          </span>
                        </div>
                      );
                    })}
                    {staleLeads.length > 3 && (
                      <div className="text-xs text-gray-500">+{staleLeads.length - 3} more</div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Over-budget Campaigns */}
            {overBudgetCampaigns.length > 0 && (
              <div className="flex items-start gap-2 p-2 rounded bg-red-500/10 border border-red-500/20">
                <span className="text-red-400">💸</span>
                <div>
                  <div className="text-sm text-red-400 font-medium">
                    {overBudgetCampaigns.length} campaign{overBudgetCampaigns.length > 1 ? 's' : ''} over budget
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    {overBudgetCampaigns.slice(0, 3).map(c => c.name).join(', ')}
                    {overBudgetCampaigns.length > 3 && ` +${overBudgetCampaigns.length - 3} more`}
                  </div>
                </div>
              </div>
            )}

            {/* Low-score leads in advanced stages */}
            {lowScoreAdvancedLeads.length > 0 && (
              <div className="flex items-start gap-2 p-2 rounded bg-orange-500/10 border border-orange-500/20">
                <span className="text-orange-400">📉</span>
                <div>
                  <div className="text-sm text-orange-400 font-medium">
                    {lowScoreAdvancedLeads.length} low-score lead{lowScoreAdvancedLeads.length > 1 ? 's' : ''} in advanced stages
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    {lowScoreAdvancedLeads.slice(0, 3).map(l => `${l.companyName} (score: ${l.score})`).join(', ')}
                    {lowScoreAdvancedLeads.length > 3 && ` +${lowScoreAdvancedLeads.length - 3} more`}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      <SavedOutputs panel="dashboard" />
    </div>
  );
}