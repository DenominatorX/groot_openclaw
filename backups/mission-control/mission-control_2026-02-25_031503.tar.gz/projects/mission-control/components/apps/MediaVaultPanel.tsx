'use client';
import { useState, useEffect } from 'react';

interface MediaItem {
  id: string;
  type: 'link' | 'image';
  url: string;
  title: string;
  description?: string;
  tags: string[];
  source?: string;
  savedAt: string;
  thumbnail?: string;
}

export default function MediaVaultPanel() {
  const [section, setSection] = useState<'links' | 'images' | 'all'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [items, setItems] = useState<MediaItem[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [tagFilter, setTagFilter] = useState('');
  const [allTags, setAllTags] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'date' | 'title'>('date');
  const [showAddForm, setShowAddForm] = useState(false);
  const [addType, setAddType] = useState<'link' | 'image'>('link');
  const [formData, setFormData] = useState({
    url: '',
    title: '',
    description: '',
    tags: '',
    source: ''
  });
  const [submitting, setSubmitting] = useState(false);

  // Load items
  useEffect(() => {
    const loadItems = async () => {
      try {
        setLoading(true);
        const params = new URLSearchParams();
        if (section !== 'all') params.append('type', section);
        if (tagFilter) params.append('tag', tagFilter);
        if (searchQuery) params.append('q', searchQuery);

        const res = await fetch(`/api/apps/media-vault?${params}`);
        if (res.ok) {
          const data = await res.json();
          setItems(data.items || []);
          setAllTags(data.tags || []);
        } else {
          setError('Failed to load items');
        }
      } catch (e) {
        setError('Failed to load items: ' + (e as any).message);
      } finally {
        setLoading(false);
      }
    };

    const timer = setTimeout(loadItems, 300); // Debounce
    return () => clearTimeout(timer);
  }, [section, tagFilter, searchQuery]);

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.url.trim() || !formData.title.trim()) {
      setError('URL and title are required');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      setSuccess('');

      const res = await fetch('/api/apps/media-vault', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: addType,
          url: formData.url,
          title: formData.title,
          description: formData.description,
          tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
          source: formData.source
        })
      });

      if (res.ok) {
        const data = await res.json();
        setItems([data.item, ...items]);
        setSuccess('Item added!');
        setShowAddForm(false);
        setFormData({ url: '', title: '', description: '', tags: '', source: '' });
      } else {
        setError('Failed to add item');
      }
    } catch (e) {
      setError('Error: ' + (e as any).message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this item?')) return;

    try {
      const res = await fetch('/api/apps/media-vault', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });

      if (res.ok) {
        setItems(items.filter(i => i.id !== id));
        setSuccess('Item deleted');
      } else {
        setError('Failed to delete item');
      }
    } catch (e) {
      setError('Error: ' + (e as any).message);
    }
  };

  const handleBulkDelete = async () => {
    if (!confirm(`Delete ${selectedIds.size} items?`)) return;

    try {
      const res = await fetch('/api/apps/media-vault', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selectedIds) })
      });

      if (res.ok) {
        setItems(items.filter(i => !selectedIds.has(i.id)));
        setSelectedIds(new Set());
        setSuccess(`${selectedIds.size} items deleted`);
      } else {
        setError('Failed to delete items');
      }
    } catch (e) {
      setError('Error: ' + (e as any).message);
    }
  };

  const toggleSelect = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const sortedItems = [...items].sort((a, b) => {
    if (sortBy === 'date') {
      return new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime();
    }
    return a.title.localeCompare(b.title);
  });

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-4">
      {/* Tabs */}
      <div className="flex gap-2 border-b border-mc-border">
        <button
          onClick={() => { setSection('links'); setSelectedIds(new Set()); }}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            section === 'links'
              ? 'text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          Links
        </button>
        <button
          onClick={() => { setSection('images'); setSelectedIds(new Set()); }}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            section === 'images'
              ? 'text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          Images
        </button>
        <button
          onClick={() => { setSection('all'); setSelectedIds(new Set()); }}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            section === 'all'
              ? 'text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          All ({items.length})
        </button>
      </div>

      {/* Messages */}
      {error && <div className="p-3 bg-red-500/20 text-red-300 rounded text-sm">{error}</div>}
      {success && <div className="p-3 bg-green-500/20 text-green-300 rounded text-sm">{success}</div>}

      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
        <input
          type="text"
          placeholder="Search by title..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 px-4 py-2 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted focus:outline-none focus:border-mc-accent"
        />

        {allTags.length > 0 && (
          <select
            value={tagFilter}
            onChange={(e) => setTagFilter(e.target.value)}
            className="px-4 py-2 bg-mc-bg border border-mc-border rounded text-mc-text focus:outline-none focus:border-mc-accent"
          >
            <option value="">All Tags</option>
            {allTags.map(tag => (
              <option key={tag} value={tag}>{tag}</option>
            ))}
          </select>
        )}

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="px-4 py-2 bg-mc-bg border border-mc-border rounded text-mc-text focus:outline-none focus:border-mc-accent"
        >
          <option value="date">Newest First</option>
          <option value="title">A-Z</option>
        </select>

        <div className="flex gap-2">
          <button
            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
            className="px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-muted hover:text-mc-accent transition-colors"
          >
            {viewMode === 'grid' ? '📋' : '⊞'}
          </button>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium transition-colors"
          >
            {showAddForm ? '✕' : '➕'} Add Item
          </button>
        </div>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4 space-y-3">
          <div className="flex gap-2">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={addType === 'link'}
                onChange={() => setAddType('link')}
                className="w-4 h-4"
              />
              Link
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={addType === 'image'}
                onChange={() => setAddType('image')}
                className="w-4 h-4"
              />
              Image
            </label>
          </div>

          <form onSubmit={handleAddItem} className="space-y-2">
            <input
              type="url"
              placeholder="URL"
              value={formData.url}
              onChange={(e) => setFormData({ ...formData, url: e.target.value })}
              className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted text-sm focus:outline-none focus:border-mc-accent"
              required
            />
            <input
              type="text"
              placeholder="Title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted text-sm focus:outline-none focus:border-mc-accent"
              required
            />
            <input
              type="text"
              placeholder="Description (optional)"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted text-sm focus:outline-none focus:border-mc-accent"
            />
            <input
              type="text"
              placeholder="Tags (comma-separated)"
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted text-sm focus:outline-none focus:border-mc-accent"
            />
            <input
              type="text"
              placeholder="Source (optional)"
              value={formData.source}
              onChange={(e) => setFormData({ ...formData, source: e.target.value })}
              className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text placeholder-mc-muted text-sm focus:outline-none focus:border-mc-accent"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 px-3 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 disabled:opacity-50 rounded font-medium text-sm transition-colors"
              >
                {submitting ? 'Saving...' : 'Save'}
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-2 bg-mc-bg border border-mc-border rounded text-mc-text hover:border-mc-accent text-sm transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Bulk Actions */}
      {selectedIds.size > 0 && (
        <div className="flex items-center gap-2 p-3 bg-mc-surface border border-mc-border rounded">
          <span className="text-sm text-mc-muted">{selectedIds.size} selected</span>
          <button
            onClick={handleBulkDelete}
            className="ml-auto px-3 py-1 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded text-sm transition-colors"
          >
            Delete
          </button>
        </div>
      )}

      {/* Items Grid/List */}
      {sortedItems.length === 0 ? (
        <div className="text-center py-12 text-mc-muted">
          No items found. Add one to get started!
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedItems.map(item => (
            <div
              key={item.id}
              className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition-colors"
            >
              {item.type === 'image' && item.thumbnail && (
                <img
                  src={item.thumbnail}
                  alt={item.title}
                  className="w-full h-40 object-cover rounded mb-3"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              )}

              <label className="flex items-start gap-2 mb-2">
                <input
                  type="checkbox"
                  checked={selectedIds.has(item.id)}
                  onChange={() => toggleSelect(item.id)}
                  className="w-4 h-4 mt-1"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-mc-text text-sm truncate">{item.title}</h4>
                  {item.description && (
                    <p className="text-xs text-mc-muted line-clamp-2">{item.description}</p>
                  )}
                </div>
              </label>

              {item.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-2">
                  {item.tags.map(tag => (
                    <span key={tag} className="text-xs bg-mc-bg text-mc-muted px-2 py-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              <div className="text-xs text-mc-muted mb-3">
                {new Date(item.savedAt).toLocaleDateString()}
                {item.source && ` • ${item.source}`}
              </div>

              <div className="flex gap-2">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 px-3 py-1 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded text-xs transition-colors text-center"
                >
                  Open
                </a>
                <button
                  onClick={() => handleDelete(item.id)}
                  className="px-3 py-1 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded text-xs transition-colors"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {sortedItems.map(item => (
            <div
              key={item.id}
              className="flex items-center gap-4 bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition-colors"
            >
              <input
                type="checkbox"
                checked={selectedIds.has(item.id)}
                onChange={() => toggleSelect(item.id)}
                className="w-4 h-4 flex-shrink-0"
              />

              {item.type === 'image' && item.thumbnail && (
                <img
                  src={item.thumbnail}
                  alt={item.title}
                  className="w-12 h-12 object-cover rounded flex-shrink-0"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              )}

              <div className="flex-1 min-w-0">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-mc-accent hover:underline truncate block"
                >
                  {item.title}
                </a>
                <p className="text-xs text-mc-muted truncate">{item.url}</p>
                {item.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1">
                    {item.tags.map(tag => (
                      <span key={tag} className="text-xs bg-mc-bg text-mc-muted px-2 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="text-xs text-mc-muted flex-shrink-0">
                {new Date(item.savedAt).toLocaleDateString()}
              </div>

              <button
                onClick={() => handleDelete(item.id)}
                className="px-3 py-1 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded text-xs transition-colors flex-shrink-0"
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
