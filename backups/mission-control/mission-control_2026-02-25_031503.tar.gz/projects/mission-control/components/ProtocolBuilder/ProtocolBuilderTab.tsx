'use client';

import React, { useState, useEffect, useCallback } from 'react';
import StepEditor from './StepEditor';
import FlowPreview from './FlowPreview';

// Types for Protocol Builder - aligned with backend
export interface ProtocolStep {
  id: string;
  name?: string;
  type: 'task' | 'approval' | 'notification' | 'checkpoint';
  enabled: boolean;
  dependsOn?: string;
  agent?: string;
  model?: string;
  timeoutMin?: number;
  retries?: number;
  approvalRequired?: boolean;
  config?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

export interface ProtocolBuilderData {
  version: string;
  steps: ProtocolStep[];
  allowedAgents?: string[];
  modelAllowlist?: string[];
  defaultTimeoutMin?: number;
  defaultRetries?: number;
}

interface ProtocolBuilderTabProps {
  projectId: string;
  projectTitle: string;
}

// Default empty protocol
const emptyProtocol: ProtocolBuilderData = {
  version: '1.0',
  steps: [],
};

// Team-related types for UI
interface AssignedTeamMember {
  agentId: string;
  role: string;
  roleId?: string;
  roleTitle?: string;
  rules?: string[];
  expectedDocuments?: string[];
  modelOverride?: string;
  pmAssign?: boolean;
  assignedAgentId?: string;
}

interface TeamSuggestion {
  agentId: string;
  role: string;
  roleTitle: string;
  reason: string;
  model?: string;
  score?: number;
}

interface TeamDecision {
  source: 'assigned' | 'builder-suggested' | 'auto-generated' | 'manual';
  timestamp: string;
  madeBy: string;
  appliedFromSuggestion?: boolean;
}

interface ApiResponse {
  defaultProtocol: ProtocolBuilderData;
  projectOverride: ProtocolBuilderData | null;
  effectiveProtocol: ProtocolBuilderData;
  validation: { valid: boolean; errors: string[]; warnings?: string[] };
  hasOverride: boolean;
  assignedTeam?: AssignedTeamMember[];
  suggestedTeam?: TeamSuggestion[];
  teamDecision?: TeamDecision;
  hasPendingSuggestions?: boolean;
}

export default function ProtocolBuilderTab({ projectId }: ProtocolBuilderTabProps) {
  const [protocol, setProtocol] = useState<ProtocolBuilderData>(emptyProtocol);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [validationResult, setValidationResult] = useState<{ valid: boolean; errors: string[] } | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'editor' | 'preview'>('editor');
  
  // Team state for precedence UI
  const [teamData, setTeamData] = useState<{
    assignedTeam: AssignedTeamMember[];
    suggestedTeam: TeamSuggestion[];
    teamDecision: TeamDecision | null;
    hasPendingSuggestions: boolean;
  }>({
    assignedTeam: [],
    suggestedTeam: [],
    teamDecision: null,
    hasPendingSuggestions: false,
  });
  const [applyingTeam, setApplyingTeam] = useState(false);

  // Load protocol from API (with team suggestions)
  const loadProtocol = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Request team suggestions
      const res = await fetch(`/api/projects/${projectId}/protocol-builder?includeTeamSuggestions=true`);
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const data: ApiResponse = await res.json();
      
      // Use effectiveProtocol from backend (merged with default)
      if (data.effectiveProtocol) {
        setProtocol(data.effectiveProtocol);
      } else if (data.projectOverride) {
        setProtocol(data.projectOverride);
      }
      
      // Update team data for UI
      setTeamData({
        assignedTeam: data.assignedTeam || [],
        suggestedTeam: data.suggestedTeam || [],
        teamDecision: data.teamDecision || null,
        hasPendingSuggestions: data.hasPendingSuggestions || false,
      });
    } catch (e) {
      console.error('Failed to load protocol:', e);
      setProtocol(emptyProtocol);
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    loadProtocol();
  }, [loadProtocol]);

  // Save protocol to API
  const saveProtocol = async () => {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/protocol-builder`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ protocol }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }
      const data = await res.json();
      // Update with any server-side modifications
      if (data.effectiveProtocol) {
        setProtocol(data.effectiveProtocol);
      }
    } catch (e: any) {
      setError(e.message || 'Failed to save protocol');
      console.error('Save error:', e);
    } finally {
      setSaving(false);
    }
  };

  // Apply suggested team (from Protocol Builder)
  const applySuggestedTeam = async () => {
    if (!teamData.suggestedTeam.length) return;
    
    setApplyingTeam(true);
    setError(null);
    try {
      const team = teamData.suggestedTeam.map(s => ({
        agentId: s.agentId,
        role: s.role,
        roleTitle: s.roleTitle,
      }));
      
      const res = await fetch(`/api/projects/${projectId}/protocol-builder`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'apply-suggestions', team }),
      });
      
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }
      
      const data = await res.json();
      
      // Refresh data
      await loadProtocol();
      
      // Show success message
      setError(null);
    } catch (e: any) {
      setError(e.message || 'Failed to apply team suggestions');
      console.error('Apply team error:', e);
    } finally {
      setApplyingTeam(false);
    }
  };

  // Keep assigned team (reject suggestions)
  const keepAssignedTeam = async () => {
    setApplyingTeam(true);
    setError(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/protocol-builder`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'keep-assigned' }),
      });
      
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }
      
      // Refresh to update teamDecision
      await loadProtocol();
    } catch (e: any) {
      setError(e.message || 'Failed to keep assigned team');
      console.error('Keep team error:', e);
    } finally {
      setApplyingTeam(false);
    }
  };

  // Validate protocol locally
  const validateProtocol = () => {
    setValidationResult(null);
    const errors: string[] = [];
    
    // Check for circular dependencies
    const stepIds = new Set(protocol.steps.map(s => s.id));
    
    // Check each step's dependency exists
    protocol.steps.forEach(step => {
      if (step.dependsOn && !stepIds.has(step.dependsOn)) {
        errors.push(`Step "${step.id}" depends on non-existent step "${step.dependsOn}"`);
      }
    });
    
    // Check for empty agent on enabled steps
    protocol.steps.forEach(step => {
      if (step.enabled && !step.agent) {
        errors.push(`Step "${step.id}" has no agent assigned`);
      }
    });

    setValidationResult({
      valid: errors.length === 0,
      errors,
    });
  };

  // Add new step
  const addStep = () => {
    const newStep: ProtocolStep = {
      id: `step-${Date.now()}`,
      name: 'New Step',
      type: 'task',
      enabled: true,
      timeoutMin: 5,
      retries: 0,
      approvalRequired: false,
    };
    setProtocol(prev => ({
      ...prev,
      steps: [...prev.steps, newStep],
    }));
  };

  // Update step
  const updateStep = (stepId: string, updates: Partial<ProtocolStep>) => {
    setProtocol(prev => ({
      ...prev,
      steps: prev.steps.map(s => s.id === stepId ? { ...s, ...updates } : s),
    }));
  };

  // Remove step
  const removeStep = (stepId: string) => {
    setProtocol(prev => ({
      ...prev,
      steps: prev.steps.filter(s => s.id !== stepId),
    }));
  };

  // Reorder steps (simple swap)
  const reorderSteps = (fromIndex: number, toIndex: number) => {
    setProtocol(prev => {
      const newSteps = [...prev.steps];
      const [removed] = newSteps.splice(fromIndex, 1);
      newSteps.splice(toIndex, 0, removed);
      return { ...prev, steps: newSteps };
    });
  };

  // Build effective protocol for preview
  const getEffectiveProtocol = () => {
    const enabledSteps = protocol.steps.filter(s => s.enabled);
    
    return {
      version: protocol.version || '1.0',
      steps: enabledSteps.map((step, idx) => ({
        order: idx + 1,
        id: step.id,
        name: step.name,
        type: step.type,
        agent: step.agent,
        model: step.model,
        timeoutMin: step.timeoutMin,
        retries: step.retries,
        approvalRequired: step.approvalRequired,
        dependsOn: step.dependsOn,
      })),
      allowedAgents: protocol.allowedAgents,
      modelAllowlist: protocol.modelAllowlist,
      defaultTimeoutMin: protocol.defaultTimeoutMin,
      defaultRetries: protocol.defaultRetries,
    };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="text-mc-muted text-sm">Loading protocol builder...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4 overflow-y-auto max-h-[calc(100vh-240px)] pr-2">
      {/* MiniMax Anti-Timeout Guidance Card */}
      <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-lg p-3">
        <div className="flex items-start gap-2">
          <span className="text-lg">⏱️</span>
          <div>
            <h4 className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1">
              MiniMax Anti-Timeout Rules
            </h4>
            <ul className="text-xs text-mc-muted space-y-0.5">
              <li>• <span className="text-amber-300">Small scope:</span> Keep each step focused on one task</li>
              <li>• <span className="text-amber-300">Checkpoint writes:</span> Save progress to files between steps</li>
              <li>• <span className="text-amber-300">Retry ladder:</span> Use retries=2-3 for unreliable operations</li>
              <li>• <span className="text-amber-300">Timeout:</span> Set timeoutMin=10+ for complex multi-file operations</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Team Precedence UI - Protocol Builder vs Assigned Team */}
      {teamData.hasPendingSuggestions && teamData.suggestedTeam.length > 0 && (
        <div className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/30 rounded-lg p-3">
          <div className="flex items-start gap-2 mb-3">
            <span className="text-lg">🏗️</span>
            <div>
              <h4 className="text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-1">
                Protocol Builder Team Suggestions
              </h4>
              <p className="text-[10px] text-mc-muted">
                Assigned Project Team is the source of truth. Protocol Builder can suggest alternatives.
              </p>
            </div>
          </div>
          
          {/* Current Assigned Team */}
          {teamData.assignedTeam.length > 0 && (
            <div className="mb-3">
              <div className="flex items-center gap-1 mb-1">
                <span className="text-[10px] font-semibold text-green-400 uppercase">✓ Current Assigned Team</span>
                <span className="text-[10px] text-mc-muted">(source of truth)</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {teamData.assignedTeam.filter(m => m.agentId && !m.pmAssign).map((member, idx) => (
                  <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-green-500/20 text-green-400 border border-green-500/30">
                    {member.agentId} ({member.role || member.roleTitle})
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* Suggested Team */}
          <div className="mb-3">
            <div className="flex items-center gap-1 mb-1">
              <span className="text-[10px] font-semibold text-yellow-400 uppercase">💡 Suggested Team</span>
              <span className="text-[10px] text-mc-muted">(Protocol Builder)</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {teamData.suggestedTeam.slice(0, 5).map((member, idx) => (
                <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                  {member.agentId} ({member.role})
                </span>
              ))}
            </div>
          </div>
          
          {/* Team Decision Info */}
          {teamData.teamDecision && (
            <div className="text-[10px] text-mc-muted mb-2">
              Decision: <span className="text-mc-text">{teamData.teamDecision.source}</span> by {teamData.teamDecision.madeBy} at {new Date(teamData.teamDecision.timestamp).toLocaleString()}
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={applySuggestedTeam}
              disabled={applyingTeam}
              className="flex-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold disabled:opacity-50"
            >
              {applyingTeam ? '⏳ Applying...' : '✅ Apply Suggested Team'}
            </button>
            <button
              onClick={keepAssignedTeam}
              disabled={applyingTeam}
              className="flex-1 px-3 py-1.5 bg-mc-surface border border-green-500/50 hover:bg-green-500/10 text-green-400 rounded text-xs font-semibold disabled:opacity-50"
            >
              ✓ Keep Assigned Team
            </button>
          </div>
        </div>
      )}

      {/* No team assigned - Builder can suggest */}
      {teamData.assignedTeam.length === 0 && teamData.suggestedTeam.length > 0 && (
        <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-lg p-3">
          <div className="flex items-start gap-2 mb-3">
            <span className="text-lg">👥</span>
            <div>
              <h4 className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">
                No Team Assigned Yet
              </h4>
              <p className="text-[10px] text-mc-muted">
                Protocol Builder can suggest a team based on project details.
              </p>
            </div>
          </div>
          
          {/* Suggested Team */}
          <div className="mb-3">
            <div className="flex items-center gap-1 mb-1">
              <span className="text-[10px] font-semibold text-yellow-400 uppercase">💡 Suggested Team</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {teamData.suggestedTeam.slice(0, 5).map((member, idx) => (
                <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                  {member.agentId} ({member.role})
                </span>
              ))}
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={applySuggestedTeam}
              disabled={applyingTeam}
              className="flex-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold disabled:opacity-50"
            >
              {applyingTeam ? '⏳ Applying...' : '✅ Apply Suggested Team'}
            </button>
          </div>
        </div>
      )}

      {/* Sub-tab navigation */}
      <div className="flex gap-1 border-b border-mc-border pb-2">
        <button
          onClick={() => setActiveSubTab('editor')}
          className={`px-3 py-1.5 text-xs rounded-t-lg transition-colors ${
            activeSubTab === 'editor'
              ? 'bg-mc-accent/20 text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          📝 Step Editor
        </button>
        <button
          onClick={() => setActiveSubTab('preview')}
          className={`px-3 py-1.5 text-xs rounded-t-lg transition-colors ${
            activeSubTab === 'preview'
              ? 'bg-mc-accent/20 text-mc-accent border-b-2 border-mc-accent'
              : 'text-mc-muted hover:text-mc-text'
          }`}
        >
          👁️ Preview ({protocol.steps.filter(s => s.enabled).length} steps)
        </button>
      </div>

      {/* Error display */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-xs text-red-400">
          {error}
        </div>
      )}

      {/* Main content */}
      {activeSubTab === 'editor' ? (
        <div className="space-y-4">
          {/* Metadata section */}
          <div className="bg-mc-bg border border-mc-border rounded-lg p-3">
            <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">Protocol Settings</h4>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-mc-muted block mb-1">Version</label>
                <input
                  type="text"
                  value={protocol.version || ''}
                  onChange={(e) => setProtocol(prev => ({ ...prev, version: e.target.value }))}
                  className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
                  placeholder="1.0"
                />
              </div>
              <div>
                <label className="text-[10px] text-mc-muted block mb-1">Default Timeout (min)</label>
                <input
                  type="number"
                  min="1"
                  value={protocol.defaultTimeoutMin || 30}
                  onChange={(e) => setProtocol(prev => ({ ...prev, defaultTimeoutMin: parseInt(e.target.value) || 30 }))}
                  className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
                />
              </div>
              <div>
                <label className="text-[10px] text-mc-muted block mb-1">Default Retries</label>
                <input
                  type="number"
                  min="0"
                  max="5"
                  value={protocol.defaultRetries || 0}
                  onChange={(e) => setProtocol(prev => ({ ...prev, defaultRetries: parseInt(e.target.value) || 0 }))}
                  className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
                />
              </div>
              <div>
                <label className="text-[10px] text-mc-muted block mb-1">Allowed Agents (comma)</label>
                <input
                  type="text"
                  value={protocol.allowedAgents?.join(', ') || ''}
                  onChange={(e) => setProtocol(prev => ({ 
                    ...prev, 
                    allowedAgents: e.target.value.split(',').map(s => s.trim()).filter(Boolean) 
                  }))}
                  className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
                  placeholder="e.g., groot, pixel"
                />
              </div>
              <div className="col-span-2">
                <label className="text-[10px] text-mc-muted block mb-1">Model Allowlist (comma)</label>
                <input
                  type="text"
                  value={protocol.modelAllowlist?.join(', ') || ''}
                  onChange={(e) => setProtocol(prev => ({ 
                    ...prev, 
                    modelAllowlist: e.target.value.split(',').map(s => s.trim()).filter(Boolean) 
                  }))}
                  className="w-full bg-mc-surface border border-mc-border rounded px-2 py-1 text-xs text-mc-text"
                  placeholder="e.g., minimax/minimax-m2.5"
                />
              </div>
            </div>
          </div>

          {/* Steps list */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">
                Protocol Steps ({protocol.steps.length})
              </h4>
              <button
                onClick={addStep}
                className="px-2 py-1 bg-mc-accent/20 text-mc-accent rounded text-xs hover:bg-mc-accent/30"
              >
                + Add Step
              </button>
            </div>

            {protocol.steps.length === 0 ? (
              <div className="text-center py-8 text-mc-muted text-sm border border-dashed border-mc-border rounded-lg">
                No steps defined. Click "Add Step" to start building your protocol.
              </div>
            ) : (
              <div className="space-y-2">
                {protocol.steps.map((step, index) => (
                  <StepEditor
                    key={step.id}
                    step={step}
                    index={index}
                    allSteps={protocol.steps}
                    onUpdate={(updates) => updateStep(step.id, updates)}
                    onRemove={() => removeStep(step.id)}
                    onMoveUp={() => index > 0 && reorderSteps(index, index - 1)}
                    onMoveDown={() => index < protocol.steps.length - 1 && reorderSteps(index, index + 1)}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex gap-2 pt-2 border-t border-mc-border">
            <button
              onClick={loadProtocol}
              disabled={loading}
              className="flex-1 px-3 py-2 bg-mc-surface border border-mc-border rounded text-xs text-mc-text hover:border-mc-accent/50"
            >
              🔄 Load
            </button>
            <button
              onClick={validateProtocol}
              className="flex-1 px-3 py-2 bg-mc-surface border border-mc-border rounded text-xs text-mc-text hover:border-mc-accent/50"
            >
              ✓ Validate Preview
            </button>
            <button
              onClick={saveProtocol}
              disabled={saving}
              className="flex-1 px-3 py-2 bg-mc-accent text-white rounded text-xs hover:opacity-80 disabled:opacity-50"
            >
              {saving ? '⏳ Saving...' : '💾 Save Override'}
            </button>
          </div>

          {/* Validation result */}
          {validationResult && (
            <div className={`border rounded-lg p-3 text-xs ${
              validationResult.valid
                ? 'bg-green-500/10 border-green-500/30 text-green-400'
                : 'bg-red-500/10 border-red-500/30 text-red-400'
            }`}>
              <div className="font-semibold mb-1">
                {validationResult.valid ? '✅ Protocol is valid' : '❌ Validation failed'}
              </div>
              {validationResult.errors.length > 0 && (
                <ul className="space-y-0.5 ml-4">
                  {validationResult.errors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      ) : (
        <FlowPreview
          protocol={getEffectiveProtocol()}
          onEdit={() => setActiveSubTab('editor')}
        />
      )}
    </div>
  );
}
