'use client';

import React, { useState } from 'react';

interface EffectiveStep {
  order: number;
  id: string;
  name?: string;
  agent?: string;
  model?: string;
  timeoutMin?: number;
  retries?: number;
  approvalRequired?: boolean;
  type: string;
  dependsOn?: string;
}

interface EffectiveProtocol {
  version: string;
  steps: EffectiveStep[];
  allowedAgents?: string[];
  modelAllowlist?: string[];
  defaultTimeoutMin?: number;
  defaultRetries?: number;
}

interface FlowPreviewProps {
  protocol: EffectiveProtocol;
  onEdit: () => void;
}

export default function FlowPreview({ protocol, onEdit }: FlowPreviewProps) {
  const [viewMode, setViewMode] = useState<'json' | 'flow'>('json');

  // Get step color by type
  const getStepColor = (type: string) => {
    switch (type) {
      case 'approval':
        return 'border-yellow-500 bg-yellow-500/10';
      case 'notification':
        return 'border-pink-500 bg-pink-500/10';
      case 'checkpoint':
        return 'border-blue-500 bg-blue-500/10';
      default:
        return 'border-mc-accent bg-mc-accent/10';
    }
  };

  // Get model short name
  const getModelShort = (model?: string) => {
    if (!model) return 'default';
    const parts = model.split('/');
    return parts[parts.length - 1];
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex gap-1">
          <button
            onClick={() => setViewMode('json')}
            className={`px-2 py-1 text-xs rounded ${
              viewMode === 'json'
                ? 'bg-mc-accent/20 text-mc-accent'
                : 'text-mc-muted hover:text-mc-text'
            }`}
          >
            JSON
          </button>
          <button
            onClick={() => setViewMode('flow')}
            className={`px-2 py-1 text-xs rounded ${
              viewMode === 'flow'
                ? 'bg-mc-accent/20 text-mc-accent'
                : 'text-mc-muted hover:text-mc-text'
            }`}
          >
            Flow
          </button>
        </div>
        <button
          onClick={onEdit}
          className="text-xs text-mc-accent hover:underline"
        >
          ← Back to Editor
        </button>
      </div>

      {/* Metadata badges */}
      <div className="flex flex-wrap gap-2">
        <span className="text-[10px] px-2 py-0.5 rounded bg-mc-bg border border-mc-border text-mc-muted">
          v{protocol.version || '1.0'}
        </span>
        {protocol.allowedAgents && protocol.allowedAgents.length > 0 && (
          <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400">
            Team: {protocol.allowedAgents.join(', ')}
          </span>
        )}
        {protocol.modelAllowlist && protocol.modelAllowlist.length > 0 && (
          <span className="text-[10px] px-2 py-0.5 rounded bg-green-500/10 border border-green-500/30 text-green-400">
            Models: {protocol.modelAllowlist.join(', ')}
          </span>
        )}
        <span className="text-[10px] px-2 py-0.5 rounded bg-mc-bg border border-mc-border text-mc-muted">
          {protocol.steps.length} steps
        </span>
      </div>

      {/* Content */}
      {viewMode === 'json' ? (
        <div className="relative">
          <pre className="bg-mc-bg border border-mc-border rounded-lg p-4 text-xs text-mc-text overflow-x-auto max-h-[50vh] overflow-y-auto font-mono">
            {JSON.stringify(protocol, null, 2)}
          </pre>
          <button
            onClick={() => navigator.clipboard.writeText(JSON.stringify(protocol, null, 2))}
            className="absolute top-2 right-2 px-2 py-1 bg-mc-surface border border-mc-border rounded text-[10px] text-mc-muted hover:text-mc-text"
          >
            📋 Copy
          </button>
        </div>
      ) : (
        <div className="bg-mc-bg border border-mc-border rounded-lg p-4 min-h-[300px]">
          {protocol.steps.length === 0 ? (
            <div className="text-center text-mc-muted text-sm py-12">
              No steps to visualize. Add steps in the editor.
            </div>
          ) : (
            <div className="relative">
              {/* Flow visualization - vertical layout */}
              <div className="space-y-3">
                {protocol.steps.map((step, idx) => (
                  <div key={step.id} className="flex items-start gap-3">
                    {/* Order number */}
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-mc-surface border border-mc-border flex items-center justify-center text-[10px] font-bold text-mc-muted">
                      {step.order}
                    </div>
                    
                    {/* Step card */}
                    <div className={`flex-1 border rounded-lg p-2 ${getStepColor(step.type)}`}>
                      <div className="flex items-center justify-between mb-1">
                        <div>
                          <span className="text-xs font-medium text-mc-text">{step.id}</span>
                          {step.name && <span className="text-[10px] text-mc-muted ml-1">- {step.name}</span>}
                        </div>
                        <div className="flex items-center gap-1">
                          {step.type !== 'task' && (
                            <span className="text-[9px] px-1 py-0.5 rounded bg-mc-surface text-mc-muted">
                              {step.type}
                            </span>
                          )}
                          {step.approvalRequired && (
                            <span className="text-[9px] px-1 py-0.5 rounded bg-yellow-500/20 text-yellow-400">
                              ⚠️
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-mc-muted">
                        <span>🤖 {step.agent || 'unassigned'}</span>
                        <span>📦 {getModelShort(step.model)}</span>
                        <span>⏱️ {step.timeoutMin || protocol.defaultTimeoutMin || 30}min</span>
                        {(step.retries || protocol.defaultRetries || 0) > 0 && (
                          <span>🔄 {step.retries || protocol.defaultRetries || 0} retries</span>
                        )}
                      </div>
                      {/* Dependency */}
                      {step.dependsOn && (
                        <div className="mt-1 pt-1 border-t border-mc-border/30">
                          <span className="text-[9px] text-mc-muted">Depends on: </span>
                          <span className="text-[9px] px-1 py-0.5 ml-1 rounded bg-mc-surface text-mc-accent">
                            {step.dependsOn}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="mt-4 pt-3 border-t border-mc-border/50 flex flex-wrap gap-3 text-[10px] text-mc-muted">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded border border-mc-accent bg-mc-accent/10" />
                  <span>Task</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded border border-yellow-500 bg-yellow-500/10" />
                  <span>Approval</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded border border-blue-500 bg-blue-500/10" />
                  <span>Checkpoint</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded border border-pink-500 bg-pink-500/10" />
                  <span>Notification</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Summary stats */}
      <div className="grid grid-cols-4 gap-2">
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-mc-accent">{protocol.steps.length}</div>
          <div className="text-[10px] text-mc-muted">Total Steps</div>
        </div>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-green-400">
            {protocol.steps.filter(s => s.type === 'task').length}
          </div>
          <div className="text-[10px] text-mc-muted">Tasks</div>
        </div>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-yellow-400">
            {protocol.steps.filter(s => s.approvalRequired).length}
          </div>
          <div className="text-[10px] text-mc-muted">Approvals</div>
        </div>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-blue-400">
            {protocol.steps.reduce((sum, s) => sum + (s.retries || 0), 0)}
          </div>
          <div className="text-[10px] text-mc-muted">Total Retries</div>
        </div>
      </div>
    </div>
  );
}
