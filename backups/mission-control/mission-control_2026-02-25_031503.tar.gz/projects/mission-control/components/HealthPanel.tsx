'use client';
import { useEffect, useState, useMemo } from 'react';
import { useSession } from 'next-auth/react';

interface Supplement { name: string; dose: string; timing: string; checked: boolean; }

interface OuraData {
  connected: boolean;
  lastSync?: string;
  error?: string;
  sleep?: { score: number; totalSleep?: number; efficiency?: number; restfulness?: number; deep?: number; rem?: number; day?: string };
  sleepPeriod?: {
    bedtimeStart?: string; bedtimeEnd?: string; totalSleepDuration?: number;
    awake?: number; light?: number; deep?: number; rem?: number;
    averageHR?: number; lowestHR?: number; averageHRV?: number;
    temperatureDeviation?: number;
    sleepPhaseTimeline?: string; hrTimeline?: number[]; hrvTimeline?: number[];
  };
  readiness?: { score: number; temperatureDeviation?: number; hrv?: number; recoveryIndex?: number; restingHR?: number; day?: string };
  activity?: { score: number; steps?: number; activeCalories?: number; totalCalories?: number; targetCalories?: number; targetSteps?: number; class5Min?: string; met?: any; day?: string };
  heartRate?: { current?: number; readings?: { bpm: number; timestamp: string; source?: string }[] };
  stress?: { stressHigh?: number; recoveryHigh?: number; daySummary?: string; day?: string };
  resilience?: { level?: string; contributors?: any; day?: string };
  spo2?: { average?: number; day?: string };
  cardiovascularAge?: { vascularAge?: number; day?: string };
  workouts?: { activity?: string; calories?: number; distance?: number; startDatetime?: string; endDatetime?: string; intensity?: string; label?: string; source?: string; day?: string }[];
}

/* ───────────── Score Ring ───────────── */
function ScoreRing({ score, label, color, icon }: { score: number | null; label: string; color: string; icon: string }) {
  const pct = score != null ? Math.max(0, Math.min(100, score)) : 0;
  const radius = 30;
  const circ = 2 * Math.PI * radius;
  const offset = circ - (pct / 100) * circ;
  return (
    <div className="flex flex-col items-center gap-1 relative">
      <svg width="72" height="72" className="transform -rotate-90">
        <circle cx="36" cy="36" r={radius} fill="none" stroke="currentColor" strokeWidth="5" className="text-mc-border" />
        {score != null && (
          <circle cx="36" cy="36" r={radius} fill="none" stroke={color} strokeWidth="5"
            strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" className="transition-all duration-700" />
        )}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ width: 72, height: 72 }}>
        <span className="text-xs">{icon}</span>
        <span className="text-sm font-bold">{score ?? '--'}</span>
      </div>
      <span className="text-[10px] text-mc-muted">{label}</span>
    </div>
  );
}

/* ───────────── HR Timeline SVG ───────────── */
function HRChart({ readings }: { readings: { bpm: number; timestamp: string }[] }) {
  const data = useMemo(() => {
    if (!readings || readings.length === 0) return [];
    // Group by 5-min buckets
    const buckets: Record<number, number[]> = {};
    readings.forEach(r => {
      const d = new Date(r.timestamp);
      const mins = d.getHours() * 60 + d.getMinutes();
      const bucket = Math.floor(mins / 5) * 5;
      if (!buckets[bucket]) buckets[bucket] = [];
      buckets[bucket].push(r.bpm);
    });
    return Object.entries(buckets)
      .map(([m, bpms]) => ({ min: Number(m), bpm: Math.round(bpms.reduce((a, b) => a + b, 0) / bpms.length) }))
      .sort((a, b) => a.min - b.min);
  }, [readings]);

  if (data.length < 2) return <div className="text-xs text-mc-muted text-center py-6">No HR data yet today</div>;

  const W = 600, H = 140, PAD_L = 32, PAD_R = 8, PAD_T = 10, PAD_B = 24;
  const plotW = W - PAD_L - PAD_R, plotH = H - PAD_T - PAD_B;
  const minBpm = Math.max(40, Math.min(...data.map(d => d.bpm)) - 5);
  const maxBpm = Math.max(...data.map(d => d.bpm)) + 5;
  const minMin = data[0].min;
  const maxMin = data[data.length - 1].min;
  const rangeMin = Math.max(1, maxMin - minMin);
  const rangeBpm = Math.max(1, maxBpm - minBpm);

  const x = (m: number) => PAD_L + ((m - minMin) / rangeMin) * plotW;
  const y = (b: number) => PAD_T + plotH - ((b - minBpm) / rangeBpm) * plotH;

  // Build colored line segments
  const segments: { x1: number; y1: number; x2: number; y2: number; color: string }[] = [];
  for (let i = 0; i < data.length - 1; i++) {
    const avgBpm = (data[i].bpm + data[i + 1].bpm) / 2;
    const color = avgBpm < 70 ? '#34d399' : avgBpm <= 100 ? '#fbbf24' : '#f87171';
    segments.push({ x1: x(data[i].min), y1: y(data[i].bpm), x2: x(data[i + 1].min), y2: y(data[i + 1].bpm), color });
  }

  // Hour labels
  const startHour = Math.floor(minMin / 60);
  const endHour = Math.ceil(maxMin / 60);
  const hours: number[] = [];
  for (let h = startHour; h <= endHour; h += 2) hours.push(h);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" preserveAspectRatio="xMidYMid meet">
      {/* Grid lines */}
      {[70, 100].map(bpm => bpm >= minBpm && bpm <= maxBpm ? (
        <line key={bpm} x1={PAD_L} y1={y(bpm)} x2={W - PAD_R} y2={y(bpm)} stroke="currentColor" strokeWidth="0.5" className="text-mc-border" strokeDasharray="3,3" />
      ) : null)}
      {/* Y-axis labels */}
      {[minBpm, 70, 100, maxBpm].filter((v, i, a) => v >= minBpm && v <= maxBpm && a.indexOf(v) === i).map(bpm => (
        <text key={bpm} x={PAD_L - 4} y={y(bpm) + 3} textAnchor="end" className="fill-mc-muted" fontSize="8">{bpm}</text>
      ))}
      {/* X-axis hour labels */}
      {hours.map(h => {
        const m = h * 60;
        if (m < minMin || m > maxMin) return null;
        return <text key={h} x={x(m)} y={H - 4} textAnchor="middle" className="fill-mc-muted" fontSize="8">{h > 12 ? `${h - 12}p` : h === 0 ? '12a' : h === 12 ? '12p' : `${h}a`}</text>;
      })}
      {/* Line segments */}
      {segments.map((s, i) => (
        <line key={i} x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2} stroke={s.color} strokeWidth="1.5" strokeLinecap="round" />
      ))}
    </svg>
  );
}

/* ───────────── Sleep Stages Bar ───────────── */
function SleepStagesBar({ awake, light, deep, rem }: { awake?: number; light?: number; deep?: number; rem?: number }) {
  const total = (awake || 0) + (light || 0) + (deep || 0) + (rem || 0);
  if (total === 0) return null;
  const pct = (v?: number) => ((v || 0) / total * 100).toFixed(1);
  const stages = [
    { label: 'Awake', value: awake, color: '#f87171', p: pct(awake) },
    { label: 'Light', value: light, color: '#60a5fa', p: pct(light) },
    { label: 'Deep', value: deep, color: '#818cf8', p: pct(deep) },
    { label: 'REM', value: rem, color: '#34d399', p: pct(rem) },
  ];
  return (
    <div>
      <div className="flex h-4 rounded-full overflow-hidden">
        {stages.map(s => s.value ? (
          <div key={s.label} style={{ width: `${s.p}%`, backgroundColor: s.color }} title={`${s.label}: ${fmtDur(s.value)}`} />
        ) : null)}
      </div>
      <div className="flex gap-3 mt-1.5 flex-wrap">
        {stages.map(s => (
          <div key={s.label} className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
            <span className="text-[10px] text-mc-muted">{s.label} {s.value ? fmtDur(s.value) : '--'}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────────── Activity Class Bar ───────────── */
function ActivityClassBar({ class5Min }: { class5Min?: string }) {
  if (!class5Min) return null;
  // 0=rest, 1=inactive, 2=low, 3=medium, 4=high, 5=non-wear
  const colors: Record<string, string> = { '0': '#374151', '1': '#4b5563', '2': '#60a5fa', '3': '#fbbf24', '4': '#f87171', '5': '#1f2937' };
  const labels: Record<string, string> = { '0': 'Rest', '1': 'Inactive', '2': 'Low', '3': 'Medium', '4': 'High' };
  return (
    <div>
      <div className="flex h-3 rounded overflow-hidden">
        {class5Min.split('').map((c, i) => (
          <div key={i} style={{ flex: 1, backgroundColor: colors[c] || '#1f2937' }} />
        ))}
      </div>
      <div className="flex gap-3 mt-1 flex-wrap">
        {['2', '3', '4'].map(k => (
          <div key={k} className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: colors[k] }} />
            <span className="text-[10px] text-mc-muted">{labels[k]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────────── Helpers ───────────── */
function fmtDur(seconds?: number): string {
  if (!seconds) return '--';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function fmtTime(iso?: string): string {
  if (!iso) return '--';
  try { return new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
  catch { return '--'; }
}

function workoutLabel(activity?: string): string {
  if (!activity) return 'Workout';
  return activity.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

function workoutDuration(start?: string, end?: string): string {
  if (!start || !end) return '--';
  const ms = new Date(end).getTime() - new Date(start).getTime();
  return fmtDur(Math.round(ms / 1000));
}

/* ───────────── Card wrapper ───────────── */
function Card({ title, icon, children, className = '' }: { title: string; icon: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-mc-surface border border-mc-border rounded-lg p-4 ${className}`}>
      <h3 className="text-xs font-semibold mb-3 flex items-center gap-1.5">
        <span>{icon}</span> {title}
      </h3>
      {children}
    </div>
  );
}

function MetricRow({ label, value, unit }: { label: string; value?: string | number | null; unit?: string }) {
  return (
    <div className="flex justify-between text-xs">
      <span className="text-mc-muted">{label}</span>
      <span className="text-mc-text font-medium">{value != null && value !== '' ? `${value}${unit || ''}` : '--'}</span>
    </div>
  );
}

/* ═══════════════════════════════════════ MAIN ═══════════════════════════════════════ */
export default function HealthPanel() {
  const { data: session } = useSession();
  const [supplements, setSupplements] = useState<Supplement[]>([]);
  const [oura, setOura] = useState<OuraData | null>(null);
  const [ouraLoading, setOuraLoading] = useState(true);
  const [disconnecting, setDisconnecting] = useState(false);

  useEffect(() => {
    if (!session) { setOuraLoading(false); return; }
    fetch('/api/health').then(r => r.json()).then(d => setSupplements(d.supplements || [])).catch(() => {});
    fetch('/api/oura').then(r => r.json()).then(d => { setOura(d); setOuraLoading(false); }).catch(() => setOuraLoading(false));
  }, [session]);

  const toggleSupplement = async (idx: number) => {
    const updated = [...supplements];
    updated[idx].checked = !updated[idx].checked;
    setSupplements(updated);
    await fetch('/api/health', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'toggle_supplement', index: idx }) });
  };

  const disconnectOura = async () => {
    setDisconnecting(true);
    await fetch('/api/oura', { method: 'DELETE' });
    setOura({ connected: false });
    setDisconnecting(false);
  };

  const checkedCount = supplements.filter(s => s.checked).length;
  const stepsGoal = oura?.activity?.targetSteps || 10000;
  const stepsPct = oura?.activity?.steps ? Math.min(100, Math.round((oura.activity.steps / stepsGoal) * 100)) : 0;

  /* ── Auth gate ── */
  if (!session) {
    return (
      <div className="flex flex-col items-center justify-center bg-mc-surface border border-mc-border rounded-lg p-12 text-center gap-4">
        <span className="text-4xl opacity-40">🔒</span>
        <p className="text-sm text-mc-muted">Sign in to view health data</p>
      </div>
    );
  }

  /* ── Not connected / loading states ── */
  if (ouraLoading) {
    return <div className="bg-mc-surface border border-mc-border rounded-lg p-8 text-center text-sm text-mc-muted">Loading health data...</div>;
  }

  if (!oura?.connected) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        <div className="lg:col-span-2 bg-mc-surface border border-mc-border rounded-lg p-8 text-center">
          <p className="text-sm text-mc-muted mb-3">Connect your Oura Ring to see sleep, readiness, and activity data.</p>
          <a href="/api/oura/authorize" className="inline-flex items-center gap-2 px-5 py-2.5 bg-mc-accent text-white rounded-lg text-sm font-medium hover:opacity-90 transition-opacity">
            💍 Connect Oura Ring
          </a>
          <p className="text-[10px] text-mc-muted mt-2">You&apos;ll be redirected to Oura to authorize access.</p>
        </div>
        <SupplementsPanel supplements={supplements} checkedCount={checkedCount} toggleSupplement={toggleSupplement} />
      </div>
    );
  }

  if (oura.error) {
    return (
      <div className="bg-mc-surface border border-mc-border rounded-lg p-6 text-center">
        <p className="text-sm text-red-400 mb-2">Error: {oura.error}</p>
        <a href="/api/oura/authorize" className="text-xs text-mc-accent hover:underline">Re-authorize</a>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">💍 Health Dashboard</h2>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-green-400 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> Connected</span>
          {oura.lastSync && <span className="text-[10px] text-mc-muted">Synced {fmtTime(oura.lastSync)}</span>}
          <button onClick={disconnectOura} disabled={disconnecting} className="text-[10px] text-mc-muted hover:text-red-400 transition-colors">Disconnect</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {/* ══════ LEFT COLUMN (2/3) ══════ */}
        <div className="lg:col-span-2 space-y-3">

          {/* Score Rings */}
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 justify-items-center">
              <ScoreRing score={oura.sleep?.score ?? null} label="Sleep" color="#818cf8" icon="🌙" />
              <ScoreRing score={oura.readiness?.score ?? null} label="Readiness" color="#34d399" icon="🟢" />
              <ScoreRing score={oura.activity?.score ?? null} label="Activity" color="#fbbf24" icon="🏃" />
              <ScoreRing score={oura.heartRate?.current ?? null} label="Avg HR" color="#f87171" icon="❤️" />
            </div>
          </div>

          {/* Stress + Resilience */}
          {(oura.stress || oura.resilience) && (
            <div className="grid grid-cols-2 gap-3">
              {oura.stress && (
                <div className="bg-mc-surface border border-mc-border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold">😰 Stress</span>
                    {oura.stress.daySummary && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                        oura.stress.daySummary === 'restored' ? 'bg-green-500/20 text-green-400' :
                        oura.stress.daySummary === 'normal' ? 'bg-blue-500/20 text-blue-400' :
                        oura.stress.daySummary === 'strained' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>{oura.stress.daySummary}</span>
                    )}
                  </div>
                  <div className="space-y-1">
                    <MetricRow label="High stress" value={oura.stress.stressHigh} unit=" min" />
                    <MetricRow label="Recovery" value={oura.stress.recoveryHigh} unit=" min" />
                  </div>
                </div>
              )}
              {oura.resilience && (
                <div className="bg-mc-surface border border-mc-border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold">🛡️ Resilience</span>
                    {oura.resilience.level && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                        oura.resilience.level === 'excellent' ? 'bg-green-500/20 text-green-400' :
                        oura.resilience.level === 'good' ? 'bg-blue-500/20 text-blue-400' :
                        oura.resilience.level === 'adequate' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>{oura.resilience.level}</span>
                    )}
                  </div>
                  <div className="space-y-1">
                    <MetricRow label="Sleep recovery" value={oura.resilience.contributors?.sleep_recovery} />
                    <MetricRow label="Daytime recovery" value={oura.resilience.contributors?.daytime_recovery} />
                    <MetricRow label="Stress" value={oura.resilience.contributors?.stress} />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Heart Rate Timeline */}
          <Card title="Heart Rate Timeline" icon="❤️‍🔥">
            <HRChart readings={oura.heartRate?.readings || []} />
            <div className="flex gap-3 mt-2 justify-center">
              {[{ c: '#34d399', l: '<70 rest' }, { c: '#fbbf24', l: '70-100' }, { c: '#f87171', l: '>100' }].map(x => (
                <div key={x.l} className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: x.c }} /><span className="text-[10px] text-mc-muted">{x.l}</span></div>
              ))}
            </div>
          </Card>

          {/* Sleep */}
          <Card title="Sleep" icon="🌙">
            {oura.sleepPeriod ? (
              <div className="space-y-3">
                <SleepStagesBar awake={oura.sleepPeriod.awake} light={oura.sleepPeriod.light} deep={oura.sleepPeriod.deep} rem={oura.sleepPeriod.rem} />
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Duration</div>
                    <div className="text-sm font-bold">{fmtDur(oura.sleepPeriod.totalSleepDuration)}</div>
                  </div>
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Bedtime</div>
                    <div className="text-sm font-bold">{fmtTime(oura.sleepPeriod.bedtimeStart)}</div>
                  </div>
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Wake</div>
                    <div className="text-sm font-bold">{fmtTime(oura.sleepPeriod.bedtimeEnd)}</div>
                  </div>
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Efficiency</div>
                    <div className="text-sm font-bold">{oura.sleep?.efficiency ?? '--'}</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Avg HR</div>
                    <div className="text-sm font-bold">{oura.sleepPeriod.averageHR ?? '--'}<span className="text-[10px] text-mc-muted"> bpm</span></div>
                  </div>
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Lowest HR</div>
                    <div className="text-sm font-bold">{oura.sleepPeriod.lowestHR ?? '--'}<span className="text-[10px] text-mc-muted"> bpm</span></div>
                  </div>
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Avg HRV</div>
                    <div className="text-sm font-bold">{oura.sleepPeriod.averageHRV ?? '--'}<span className="text-[10px] text-mc-muted"> ms</span></div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-mc-muted text-center py-4">No sleep data available</div>
            )}
          </Card>

          {/* Activity */}
          <Card title="Activity" icon="🏃">
            {oura.activity ? (
              <div className="space-y-3">
                {/* Steps progress */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-mc-muted">Steps</span>
                    <span className="font-medium">{oura.activity.steps?.toLocaleString() ?? '--'} / {stepsGoal.toLocaleString()}</span>
                  </div>
                  <div className="h-3 bg-mc-bg rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${stepsPct}%`, backgroundColor: stepsPct >= 100 ? '#34d399' : '#fbbf24' }} />
                  </div>
                </div>
                {/* Calories */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Active Cal</div>
                    <div className="text-sm font-bold">{oura.activity.activeCalories ?? '--'}</div>
                  </div>
                  <div className="bg-mc-bg rounded p-2 text-center">
                    <div className="text-[10px] text-mc-muted">Total Cal</div>
                    <div className="text-sm font-bold">{oura.activity.totalCalories ?? '--'}</div>
                  </div>
                </div>
                {/* Activity classification */}
                {oura.activity.class5Min && (
                  <div>
                    <div className="text-[10px] text-mc-muted mb-1">Activity Timeline</div>
                    <ActivityClassBar class5Min={oura.activity.class5Min} />
                  </div>
                )}
              </div>
            ) : (
              <div className="text-xs text-mc-muted text-center py-4">No activity data</div>
            )}
          </Card>

          {/* Body Metrics + Workouts row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Card title="Body Metrics" icon="🫀">
              <div className="space-y-1.5">
                <MetricRow label="SpO2" value={oura.spo2?.average} unit="%" />
                <MetricRow label="Vascular Age" value={oura.cardiovascularAge?.vascularAge} unit=" yrs" />
                <MetricRow label="Temp Deviation" value={oura.sleepPeriod?.temperatureDeviation != null ? `${oura.sleepPeriod.temperatureDeviation > 0 ? '+' : ''}${oura.sleepPeriod.temperatureDeviation.toFixed(2)}` : null} unit="°C" />
                <MetricRow label="Resting HR" value={oura.readiness?.restingHR} />
                <MetricRow label="HRV Balance" value={oura.readiness?.hrv} />
              </div>
            </Card>

            <Card title="Workouts" icon="💪">
              {oura.workouts && oura.workouts.length > 0 ? (
                <div className="space-y-2">
                  {oura.workouts.map((w, i) => (
                    <div key={i} className="bg-mc-bg rounded p-2">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium">{workoutLabel(w.activity)}</span>
                        <span className="text-mc-muted">{fmtTime(w.startDatetime)}</span>
                      </div>
                      <div className="flex gap-3 mt-1 text-[10px] text-mc-muted">
                        <span>⏱ {workoutDuration(w.startDatetime, w.endDatetime)}</span>
                        {w.calories != null && <span>🔥 {w.calories} cal</span>}
                        {w.distance != null && w.distance > 0 && <span>📏 {(w.distance / 1000).toFixed(1)} km</span>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-mc-muted text-center py-4">No workouts today</div>
              )}
            </Card>
          </div>
        </div>

        {/* ══════ RIGHT COLUMN (1/3) ══════ */}
        <div className="space-y-3">
          <SupplementsPanel supplements={supplements} checkedCount={checkedCount} toggleSupplement={toggleSupplement} />
        </div>
      </div>
    </div>
  );
}

/* ───────────── Supplements Side Panel ───────────── */
function SupplementsPanel({ supplements, checkedCount, toggleSupplement }: { supplements: Supplement[]; checkedCount: number; toggleSupplement: (i: number) => void }) {
  return (
    <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold">💊 Supplements</h3>
        <span className="text-xs text-mc-muted">{checkedCount}/{supplements.length}</span>
      </div>
      {supplements.length > 0 && (
        <div className="h-1.5 bg-mc-bg rounded-full overflow-hidden mb-3">
          <div className="h-full bg-mc-accent rounded-full transition-all" style={{ width: `${supplements.length ? (checkedCount / supplements.length * 100) : 0}%` }} />
        </div>
      )}
      <div className="space-y-1.5">
        {supplements.map((s, i) => (
          <label key={i} className="flex items-center gap-2 cursor-pointer group">
            <input type="checkbox" checked={s.checked} onChange={() => toggleSupplement(i)} className="rounded accent-mc-accent" />
            <span className={`text-sm flex-1 ${s.checked ? 'line-through text-mc-muted' : ''}`}>{s.name}</span>
            <span className="text-[10px] text-mc-muted opacity-0 group-hover:opacity-100">{s.dose}</span>
          </label>
        ))}
      </div>

      {/* Genetic context */}
      <div className="mt-4 pt-3 border-t border-mc-border">
        <h4 className="text-xs font-semibold text-mc-accent mb-2">🧬 Genetic Context</h4>
        <div className="space-y-1 text-[10px] text-mc-muted">
          <div>AMPD1 c.133C&gt;T — ATP recycling ↓20-40%</div>
          <div>AGK c.445A&gt;G + c.764C&gt;T — Cardiolipin ↓15-30%</div>
          <div className="text-yellow-400/70 mt-1">⚠️ Combined: ~35-60% ATP deficit under exertion</div>
        </div>
      </div>

      {/* Mayo Clinic */}
      <div className="mt-3 pt-3 border-t border-mc-border">
        <div className="flex items-center gap-2">
          <span className="text-xs">🏥</span>
          <div>
            <div className="text-xs font-medium">Mayo Clinic</div>
            <div className="text-[10px] text-mc-muted">Feb 17, 2026 — Jacksonville, FL</div>
          </div>
        </div>
      </div>
    </div>
  );
}
