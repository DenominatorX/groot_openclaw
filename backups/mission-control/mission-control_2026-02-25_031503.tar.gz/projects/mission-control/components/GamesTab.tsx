'use client';
import { useState } from 'react';
import WrestlingTriviaGameWrapper from './games/WrestlingTriviaGameWrapper';
import CyberHeistGameWrapper from './games/CyberHeistGameWrapper';
import StockTycoonGame from './games/StockTycoonGame';
import AIDungeonGame from './games/AIDungeonGame';
import DebateArenaGame from './games/DebateArenaGame';

type GameId = 'wrestling-trivia' | 'cyber-heist' | 'stock-tycoon' | 'ai-dungeon' | 'debate-arena' | null;

interface GameDef {
  id: GameId;
  name: string;
  icon: string;
  description: string;
  status: 'available' | 'coming-soon';
  component?: React.ComponentType<any>;
}

const GAMES: GameDef[] = [
  {
    id: 'wrestling-trivia',
    name: 'Wrestling Trivia',
    icon: '🤼',
    description: 'Solo or multiplayer pro wrestling trivia! Compete in real-time matches with up to 8 players, earn rankings, and become a Wrestling Legend!',
    status: 'available',
    component: WrestlingTriviaGameWrapper,
  },
  {
    id: 'cyber-heist',
    name: 'Cyber Heist',
    icon: '🔓',
    description: 'Plan and execute digital heists on AI-generated corporate targets. Assemble teams, strategize, and escape with the data!',
    status: 'available',
    component: CyberHeistGameWrapper,
  },
  {
    id: 'stock-tycoon',
    name: 'Stock Market Tycoon',
    icon: '💰',
    description: 'Manage a virtual portfolio with AI-generated market events. Buy/sell stocks, beat the leaderboard, and build your fortune!',
    status: 'available',
    component: StockTycoonGame,
  },
  {
    id: 'ai-dungeon',
    name: 'AI Dungeon Master',
    icon: '🐉',
    description: 'An AI-powered text RPG adventure. Create your character, make choices, fight monsters, and craft your legend!',
    status: 'available',
    component: AIDungeonGame,
  },
  {
    id: 'debate-arena',
    name: 'Debate Arena',
    icon: '⚖️',
    description: 'Master the art of argumentation. Challenge AI opponents, compete in tournaments, and become the Supreme Court Justice!',
    status: 'available',
    component: DebateArenaGame,
  },
  {
    id: null,
    name: 'Agent Arena',
    icon: '🎮',
    description: 'Battle AI agents in real-time strategy challenges',
    status: 'coming-soon',
  },
  {
    id: null,
    name: 'Mind Games',
    icon: '🧩',
    description: 'Logic puzzles, riddles, and brain teasers',
    status: 'coming-soon',
  },
  {
    id: null,
    name: 'Strategy',
    icon: '🎲',
    description: 'Turn-based strategy and tactical games',
    status: 'coming-soon',
  },
];

export default function GamesTab() {
  const [openGame, setOpenGame] = useState<GameId>(null);

  // If a game is open, render it full-screen
  if (openGame) {
    const game = GAMES.find(g => g.id === openGame);
    if (game?.component) {
      const Comp = game.component;
      return (
        <div>
          <button
            onClick={() => setOpenGame(null)}
            className="mb-4 px-3 py-1.5 text-sm text-mc-muted hover:text-mc-text hover:bg-mc-bg rounded transition-colors"
          >
            ← Back to Games
          </button>
          <Comp />
        </div>
      );
    }
  }

  // Show game grid/store
  return (
    <div className="space-y-4">
      <div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {GAMES.map(game => (
            <div
              key={game.name}
              className="bg-mc-surface border border-mc-border rounded-lg p-4 hover:border-mc-accent/50 transition-colors"
            >
              <div className="text-3xl mb-3">{game.icon}</div>
              <h3 className="text-base font-semibold text-mc-text mb-2">{game.name}</h3>
              <p className="text-sm text-mc-muted mb-4">{game.description}</p>

              {game.status === 'available' ? (
                <button
                  onClick={() => setOpenGame(game.id)}
                  className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 rounded font-medium text-sm transition-colors"
                >
                  🎮 Play
                </button>
              ) : (
                <div className="w-full px-4 py-2 bg-gray-700/30 text-gray-500 rounded text-sm text-center">
                  🔜 Coming Soon
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
