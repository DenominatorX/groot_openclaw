'use client';
import { useState, useEffect, useCallback } from 'react';
import BrainDumpComponent from './BrainDump';
import MarkdownMessage from './MarkdownMessage';
import XPBar from './shared/XPBar';
import XPBadge from './shared/XPBadge';
import EfficiencyMetric from './shared/EfficiencyMetric';

function VoiceSelector({ editing, voiceId, onChange, agentName }: {
  editing: boolean; voiceId: string; onChange: (v: string) => void; agentName: string;
}) {
  const [voices, setVoices] = useState<{voice_id: string; name: string; category: string; preview_url?: string}[]>([]);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (editing && voices.length === 0) {
      fetch('/api/voice').then(r => r.json()).then(d => setVoices(d.voices || [])).catch(() => {});
    }
  }, [editing, voices.length]);

  const preview = async () => {
    if (!voiceId || playing) return;
    setLoading(true);
    try {
      const r = await fetch('/api/voice', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'preview', voice_id: voiceId, text: `Hello, I'm ${agentName}. How can I help you today?` }),
      });
      const d = await r.json();
      if (d.audio) {
        const audio = new Audio(d.audio);
        setPlaying(true);
        audio.onended = () => setPlaying(false);
        audio.play();
      }
    } catch {} finally { setLoading(false); }
  };

  const selectedName = voices.find(v => v.voice_id === voiceId)?.name || voiceId || 'Not configured';

  return (
    <div>
      <label className="text-xs text-mc-muted uppercase tracking-wide">Voice (ElevenLabs)</label>
      {editing ? (
        <div className="flex items-center gap-2 mt-1">
          <select value={voiceId} onChange={e => onChange(e.target.value)}
            className="flex-1 bg-mc-bg border border-mc-border rounded p-2 text-sm">
            <option value="">No voice</option>
            {voices.map(v => (
              <option key={v.voice_id} value={v.voice_id}>{v.name} ({v.category})</option>
            ))}
          </select>
          <button onClick={preview} disabled={!voiceId || loading || playing}
            className="px-2 py-2 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 disabled:opacity-40">
            {loading ? '⏳' : playing ? '🔊' : '▶️'}
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2 mt-1">
          <span className="text-sm text-mc-muted">{selectedName}</span>
          {voiceId && (
            <button onClick={preview} disabled={loading || playing}
              className="text-xs text-mc-accent hover:underline disabled:opacity-40">
              {loading ? '⏳' : playing ? '🔊' : '▶️ Preview'}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

const DEFAULT_CHARACTER_TYPES = [
  { id: 'lobster', name: 'Lobster', emoji: '🦞' },
  { id: 'robot', name: 'Robot', emoji: '🤖' },
  { id: 'humanoid', name: 'Humanoid', emoji: '🧑' },
];

const TIER_LABELS: Record<number, string> = {
  0: 'Owner', 1: 'Executive Board', 2: 'VP', 3: 'Director',
  4: 'Sr. Manager', 5: 'Manager', 6: 'Frontline',
};

const TIER_MODELS: Record<number, string> = {
  0: '',  // Owner — no default
  1: 'anthropic/claude-opus-4-6',
  2: 'anthropic/claude-sonnet-4-20250514',
  3: 'xai/grok-3',
  4: 'anthropic/claude-haiku-4-5',
  5: 'ollama/llama3.1:70b',
  6: 'ollama/llama3.1:8b',
};

const TIER_COLORS: Record<number, string> = {
  0: 'bg-yellow-500/20 text-yellow-400',
  1: 'bg-purple-500/20 text-purple-400',
  2: 'bg-blue-500/20 text-blue-400',
  3: 'bg-cyan-500/20 text-cyan-400',
  4: 'bg-green-500/20 text-green-400',
  5: 'bg-orange-500/20 text-orange-400',
  6: 'bg-gray-500/20 text-gray-400',
};

interface Agent {
  id: string;
  name: string;
  displayName?: string;
  role: string;
  title?: string;
  tier: number;
  status: string;
  emoji?: string;
  bio?: string;
  initials: string;
  color: string;
  avatarType?: string;
  glbModel?: string | null;
  model?: string | null;
  voice?: string | null;
  department?: string;
  parent?: string | null;
  isExecutiveBoard?: boolean;
  capabilities?: string[];
  personality?: Record<string, string>;
  preferences?: Record<string, any>;
  stats?: Record<string, number>;
  createdAt?: string;
  lastActive?: string;
}

interface Props {
  agentId: string;
  onClose: () => void;
  onSelectAgent?: (agentId: string) => void;
}

// ============ Personality Tab ============
function PersonalityTab({ agentId }: { agentId: string }) {
  const [soulContent, setSoulContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch(`/api/agents/workspace?id=${agentId}`)
      .then(r => r.json())
      .then(d => {
        const content = d.files?.['SOUL.md'] || '';
        setSoulContent(content);
        setDraft(content);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [agentId]);

  const save = async () => {
    setSaving(true);
    try {
      await fetch('/api/agents/workspace', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: agentId, filename: 'SOUL.md', content: draft }),
      });
      setSoulContent(draft);
      setEditing(false);
    } catch {} finally { setSaving(false); }
  };

  if (loading) return <div className="text-sm text-mc-muted animate-pulse">Loading personality...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">SOUL.md — Personality & Identity</h3>
        {editing ? (
          <div className="flex gap-1">
            <button onClick={save} disabled={saving} className="px-2 py-1 text-xs bg-mc-accent text-white rounded">{saving ? '...' : 'Save'}</button>
            <button onClick={() => { setEditing(false); setDraft(soulContent); }} className="px-2 py-1 text-xs text-mc-muted bg-mc-bg rounded">Cancel</button>
          </div>
        ) : (
          <button onClick={() => setEditing(true)} className="px-2 py-1 text-xs text-mc-muted hover:text-mc-accent bg-mc-bg rounded">✏️ Edit</button>
        )}
      </div>
      {editing ? (
        <textarea value={draft} onChange={e => setDraft(e.target.value)}
          className="w-full bg-mc-bg border border-mc-border rounded p-3 text-sm font-mono resize-none"
          style={{ minHeight: '400px' }} />
      ) : soulContent ? (
        <div className="bg-mc-bg rounded p-3 text-sm prose prose-invert max-w-none">
          <MarkdownMessage content={soulContent} />
        </div>
      ) : (
        <div className="text-sm text-mc-muted italic">No SOUL.md found. Click Edit to create one.</div>
      )}
    </div>
  );
}

// ============ Stats Tab ============
function StatsTab({ agentId, tierLabel, status, usageData, usageLoading, fetchUsage, usageFrom, usageTo, setUsageFrom, setUsageTo }: {
  agentId: string; tierLabel: string; status: string;
  usageData: { entries: any[]; summary: any; modelBreakdown: any[] } | null;
  usageLoading: boolean; fetchUsage: (id?: string) => void;
  usageFrom: string; usageTo: string; setUsageFrom: (v: string) => void; setUsageTo: (v: string) => void;
}) {
  useEffect(() => { fetchUsage(); }, []);

  const fmt = (n: number) => n >= 1000000 ? `${(n / 1000000).toFixed(1)}M` : n >= 1000 ? `${(n / 1000).toFixed(1)}K` : String(n);

  return (
    <div className="space-y-4">
      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-mc-bg rounded p-2"><div className="text-xs text-mc-muted">Tier</div><div className="text-sm font-medium">{tierLabel}</div></div>
        <div className="bg-mc-bg rounded p-2"><div className="text-xs text-mc-muted">Status</div><div className="text-sm font-medium">{status === 'active' ? '🟢 Active' : '⚪ Idle'}</div></div>
      </div>

      {/* Date Range */}
      <div className="flex items-center gap-2 text-xs">
        <input type="date" value={usageFrom} onChange={e => setUsageFrom(e.target.value)} className="bg-mc-bg border border-mc-border rounded px-2 py-1" />
        <span className="text-mc-muted">to</span>
        <input type="date" value={usageTo} onChange={e => setUsageTo(e.target.value)} className="bg-mc-bg border border-mc-border rounded px-2 py-1" />
        <button onClick={() => fetchUsage()} disabled={usageLoading} className="px-2 py-1 bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30">
          {usageLoading ? '...' : '↻'}
        </button>
      </div>

      {usageData && (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <div className="bg-mc-bg rounded p-2">
              <div className="text-xs text-mc-muted">Requests</div>
              <div className="text-lg font-bold">{usageData.summary.totalRequests}</div>
            </div>
            <div className="bg-mc-bg rounded p-2">
              <div className="text-xs text-mc-muted">Input Tokens</div>
              <div className="text-lg font-bold">{fmt(usageData.summary.totalInputTokens)}</div>
            </div>
            <div className="bg-mc-bg rounded p-2">
              <div className="text-xs text-mc-muted">Output Tokens</div>
              <div className="text-lg font-bold">{fmt(usageData.summary.totalOutputTokens)}</div>
            </div>
            <div className="bg-mc-bg rounded p-2">
              <div className="text-xs text-mc-muted">Total Cost</div>
              <div className="text-lg font-bold text-green-400">${usageData.summary.totalCost.toFixed(2)}</div>
            </div>
          </div>

          {/* Model Breakdown */}
          {usageData.modelBreakdown.length > 0 && (
            <div>
              <h4 className="text-xs text-mc-muted uppercase tracking-wide mb-2">Model Breakdown</h4>
              <div className="space-y-1">
                {usageData.modelBreakdown.sort((a: any, b: any) => b.cost - a.cost).map((m: any) => (
                  <div key={m.model} className="flex items-center justify-between bg-mc-bg rounded px-3 py-2 text-sm">
                    <span className="font-mono text-xs">{m.model.split('/').pop()}</span>
                    <div className="flex gap-4 text-xs text-mc-muted">
                      <span>{m.requests} req</span>
                      <span>{fmt(m.inputTokens + m.outputTokens)} tok</span>
                      <span className="text-green-400">${m.cost.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent Usage */}
          {usageData.entries.length > 0 && (
            <div>
              <h4 className="text-xs text-mc-muted uppercase tracking-wide mb-2">Recent Calls ({usageData.entries.length})</h4>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {usageData.entries.slice(0, 20).map((e: any) => (
                  <div key={e.id} className="flex items-center justify-between bg-mc-bg rounded px-2 py-1 text-xs">
                    <span className="text-mc-muted">{new Date(e.timestamp).toLocaleString()}</span>
                    <span className="font-mono">{(e.model || '').split('/').pop()}</span>
                    <span>{fmt(e.inputTokens + e.outputTokens)} tok</span>
                    <span className="text-green-400">${(e.cost || 0).toFixed(3)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {usageData.entries.length === 0 && (
            <div className="text-sm text-mc-muted italic text-center py-4">No usage data for this period.</div>
          )}
        </>
      )}
    </div>
  );
}

// ============ Activity Tab ============
function ActivityTab({ agentId, activityData, activityLoading }: {
  agentId: string;
  activityData: { tasks: { completed: any[]; active: any[] }; activity: any[]; sessions: any[] } | null;
  activityLoading: boolean;
}) {
  const [data, setData] = useState(activityData);
  const [loading, setLoading] = useState(!activityData);

  useEffect(() => {
    if (activityData) { setData(activityData); setLoading(false); return; }
    setLoading(true);
    fetch(`/api/agents/activity?agentId=${agentId}`)
      .then(r => r.json())
      .then(d => setData(d))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [agentId, activityData]);

  if (loading) return <div className="text-sm text-mc-muted animate-pulse">Loading activity...</div>;
  if (!data) return <div className="text-sm text-mc-muted">Failed to load activity.</div>;

  return (
    <div className="space-y-4">
      {/* Active Tasks */}
      {data.tasks.active.length > 0 && (
        <div>
          <h4 className="text-xs text-mc-muted uppercase tracking-wide mb-2">🔄 Active Tasks ({data.tasks.active.length})</h4>
          <div className="space-y-1">
            {data.tasks.active.map((t: any) => (
              <div key={t.id} className="flex items-center justify-between bg-mc-bg rounded px-3 py-2 text-sm">
                <span>{t.title}</span>
                <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400">{t.column || t.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Completed Tasks */}
      {data.tasks.completed.length > 0 && (
        <div>
          <h4 className="text-xs text-mc-muted uppercase tracking-wide mb-2">✅ Completed ({data.tasks.completed.length})</h4>
          <div className="space-y-1">
            {data.tasks.completed.slice(0, 10).map((t: any) => (
              <div key={t.id} className="flex items-center justify-between bg-mc-bg rounded px-3 py-2 text-sm text-mc-muted">
                <span>{t.title}</span>
                <span className="text-xs">{t.created ? new Date(t.created).toLocaleDateString() : ''}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Activity Log */}
      {data.activity.length > 0 && (
        <div>
          <h4 className="text-xs text-mc-muted uppercase tracking-wide mb-2">⚡ Activity Log</h4>
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {data.activity.slice(0, 30).map((a: any, i: number) => (
              <div key={a.id || i} className="bg-mc-bg rounded px-3 py-2 text-sm">
                <div className="flex justify-between">
                  <span>{a.message || a.details || a.action}</span>
                  <span className="text-xs text-mc-muted">{a.timestamp ? new Date(a.timestamp).toLocaleString() : ''}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {data.tasks.active.length === 0 && data.tasks.completed.length === 0 && data.activity.length === 0 && (
        <div className="text-sm text-mc-muted italic text-center py-8">No activity recorded yet.</div>
      )}
    </div>
  );
}

export default function AgentProfile({ agentId, onClose, onSelectAgent }: Props) {
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);
  const [agent, setAgent] = useState<Agent | null>(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Partial<Agent>>({});
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState<'overview' | 'personality' | 'stats' | 'activity' | 'braindump'>('overview');
  const [chatExpanded, setChatExpanded] = useState(false);
  const [activityData, setActivityData] = useState<{tasks:{completed:any[];active:any[]};activity:any[];sessions:any[]} | null>(null);
  const [activityLoading, setActivityLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState<{role: string; content: string}[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [usageData, setUsageData] = useState<{entries: any[]; summary: any; modelBreakdown: any[]} | null>(null);
  const [usageLoading, setUsageLoading] = useState(false);
  const [usageFrom, setUsageFrom] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() - 7); return d.toISOString().slice(0, 10);
  });
  const [usageTo, setUsageTo] = useState(() => new Date().toISOString().slice(0, 10));
  const [characterTypes, setCharacterTypes] = useState<{id:string;name:string;emoji:string}[]>(DEFAULT_CHARACTER_TYPES);
  const [glbFiles, setGlbFiles] = useState<string[]>([]);

  const [allAgents, setAllAgents] = useState<Agent[]>([]);
  const [xpData, setXpData] = useState<{
    xp: number;
    level: number;
    levelLabel: string;
    progress: number;
    xpToNextLevel: number;
    efficiency: number;
    stats: { totalTasks: number; completedTasks: number };
  } | null>(null);
  const [xpLoading, setXpLoading] = useState(false);

  useEffect(() => {
    fetch('/api/agents').then(r => r.json()).then(data => {
      const agents = Array.isArray(data) ? data : data.agents || [];
      setAllAgents(agents);
      const found = agents.find((a: Agent) => a.id === agentId);
      if (found) { setAgent(found); setDraft(found); }
    });
    // Fetch character types
    fetch('/api/character-types').then(r => r.json()).then(d => {
      if (d.types) setCharacterTypes(d.types.map((t: any) => ({ id: t.id, name: t.name, emoji: t.emoji })));
    }).catch(() => {});
    // Fetch available GLB files
    fetch('/api/assets').then(r => r.json()).then(d => {
      if (d.files) setGlbFiles(d.files);
    }).catch(() => {});
    // Check if we should open chat tab directly
    if ((window as any).__openAgentChat === agentId) {
      setTab('overview' as any);
      delete (window as any).__openAgentChat;
    }
    // Load chat history
    fetch(`/api/chat/agent?agentId=${agentId}`).then(r => r.json()).then(d => {
      if (d.messages) setChatMessages(d.messages);
    }).catch(() => {});
    // Fetch XP data
    setXpLoading(true);
    fetch(`/api/xp?agentId=${agentId}`).then(r => r.json()).then(d => {
      if (!d.error) setXpData(d);
    }).catch(() => {}).finally(() => setXpLoading(false));
  }, [agentId]);

  const fetchUsage = useCallback(async (aId?: string) => {
    setUsageLoading(true);
    try {
      const r = await fetch(`/api/agents/usage?agentId=${aId || agentId}&from=${usageFrom}&to=${usageTo}`);
      const d = await r.json();
      setUsageData(d);
    } catch {} finally { setUsageLoading(false); }
  }, [agentId, usageFrom, usageTo]);

  const sendChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const userMsg = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setChatLoading(true);
    try {
      const r = await fetch('/api/chat/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId, message: userMsg }),
      });
      const d = await r.json();
      if (d.reply) {
        setChatMessages(prev => [...prev, { role: 'assistant', content: d.reply }]);
      }
    } catch (e) {
      setChatMessages(prev => [...prev, { role: 'assistant', content: '⚠️ Failed to get response.' }]);
    }
    setChatLoading(false);
  };

  const save = async () => {
    setSaving(true);
    try {
      await fetch('/api/agents', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: agentId, ...draft }),
      });
      setAgent({ ...agent!, ...draft });
      setEditing(false);
    } catch {}
    setSaving(false);
  };

  if (!agent) return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center" onClick={onClose}>
      <div className="bg-mc-surface rounded-xl p-8 text-mc-muted">Loading...</div>
    </div>
  );

  const charType = characterTypes.find(c => c.id === agent.avatarType) || characterTypes[0];
  const tierLabel = TIER_LABELS[agent.tier] || `Tier ${agent.tier}`;
  const tierColor = TIER_COLORS[agent.tier] || TIER_COLORS[6];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-[70vw] max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}>

        {/* Profile Header Card */}
        <div className="relative p-6 pb-5 border-b border-mc-border" style={{ background: `linear-gradient(135deg, ${agent.color}11 0%, transparent 60%)` }}>
          {/* Actions - top right */}
          <div className="absolute top-4 right-4 flex gap-1">
            {editing ? (
              <>
                <button onClick={save} disabled={saving}
                  className="px-3 py-1.5 text-xs bg-mc-accent text-white rounded hover:opacity-90">
                  {saving ? '...' : 'Save'}
                </button>
                <button onClick={() => { setEditing(false); setDraft(agent); }}
                  className="px-3 py-1.5 text-xs text-mc-muted hover:text-mc-text bg-mc-bg rounded">Cancel</button>
              </>
            ) : (
              <button onClick={() => setEditing(true)}
                className="px-3 py-1.5 text-xs text-mc-muted hover:text-mc-accent bg-mc-bg rounded">✏️ Edit</button>
            )}
            <button onClick={onClose} className="px-2 py-1.5 text-xs text-mc-muted hover:text-red-400">✕</button>
          </div>

          <div className="flex items-start gap-5">
            {/* Large Avatar */}
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-5xl flex-shrink-0"
              style={{ backgroundColor: agent.color + '22', border: `2px solid ${agent.color}`, boxShadow: `0 4px 24px ${agent.color}33` }}>
              {charType.emoji}
            </div>

            <div className="flex-1 min-w-0 pt-1">
              {/* Name row */}
              <div className="flex items-center gap-2 flex-wrap mb-1">
                {editing ? (
                  <input value={draft.displayName || draft.name || ''} onChange={e => setDraft({ ...draft, displayName: e.target.value })}
                    className="text-xl font-bold bg-mc-bg border border-mc-border rounded px-2 py-0.5" />
                ) : (
                  <h2 className="text-xl font-bold">{agent.displayName || agent.name}</h2>
                )}
                <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${agent.status === 'active' ? 'bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.5)]' : 'bg-gray-500'}`}
                  title={agent.status === 'active' ? 'Active' : 'Idle'} />
              </div>

              {/* Role & Title */}
              {editing ? (
                <input value={draft.title || ''} onChange={e => setDraft({ ...draft, title: e.target.value })}
                  className="text-sm text-mc-muted bg-mc-bg border border-mc-border rounded px-2 py-0.5 w-full" />
              ) : (
                <div className="text-sm text-mc-muted">{agent.title || agent.role}</div>
              )}

              {/* Badges row - editable when in edit mode */}
              <div className="flex items-center gap-2 flex-wrap mt-2">
                {editing ? (
                  <>
                    {/* Tier dropdown */}
                    <select value={draft.tier ?? agent.tier} onChange={e => setDraft({ ...draft, tier: parseInt(e.target.value) })}
                      className="text-xs px-2 py-0.5 rounded-full font-medium bg-mc-bg border border-mc-border cursor-pointer">
                      {Object.entries(TIER_LABELS).map(([k, v]) => (
                        <option key={k} value={k}>{v}</option>
                      ))}
                    </select>
                    {/* Model dropdown (Groot locked to inherit default) */}
                    {agent.id === 'groot' ? (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-mc-bg border border-mc-border text-mc-muted">
                        🧠 Inherit default (locked)
                      </span>
                    ) : (
                      <select value={draft.model || agent.model || ''} onChange={e => setDraft({ ...draft, model: e.target.value })}
                        className="text-xs px-2 py-0.5 rounded-full bg-mc-bg border border-mc-border cursor-pointer">
                        <option value="">Default (by Tier)</option>
                        <option value="anthropic/claude-opus-4-6">Opus 4</option>
                        <option value="anthropic/claude-sonnet-4-20250514">Sonnet 4</option>
                        <option value="xai/grok-4">Grok 4</option>
                        <option value="xai/grok-3">Grok 3</option>
                        <option value="anthropic/claude-haiku-4-5">Haiku</option>
                        <option value="openrouter/minimax/minimax-m2.5">MiniMax M2.5</option>
                        <option value="openrouter/google/gemini-2.5-pro">Gemini 2.5 Pro</option>
                      </select>
                    )}
                    {/* Emoji picker - simple text input */}
                    <input value={draft.emoji || charType.emoji || '🤖'} onChange={e => setDraft({ ...draft, emoji: e.target.value })}
                      className="text-xs w-8 px-1 py-0.5 rounded-full bg-mc-bg border border-mc-border text-center" placeholder="🤖" />
                    {/* Color picker */}
                    <input type="color" value={draft.color || agent.color || '#6366f1'} onChange={e => setDraft({ ...draft, color: e.target.value })}
                      className="text-xs w-6 h-6 rounded cursor-pointer" title="Color" />
                  </>
                ) : (
                  <>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${tierColor}`}>{tierLabel}</span>
                    {agent.model && <span className="text-xs px-2 py-0.5 rounded-full bg-mc-bg border border-mc-border">🧠 {agent.model.split('/').pop()}</span>}
                    <span className="text-xs px-2 py-0.5 rounded-full bg-mc-bg border border-mc-border">{charType.emoji} {charType.name}</span>
                  </>
                )}
                {agent.isExecutiveBoard && <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400">⭐ Executive Board</span>}
                <span className="text-xs px-2 py-0.5 rounded-full bg-mc-bg border border-mc-border">🏢 {agent.department || 'Unassigned'}</span>
                <select
                  value={agent.glbModel || ''}
                  onChange={async (e) => {
                    const newVal = e.target.value || null;
                    try {
                      await fetch('/api/agents', {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: agentId, glbModel: newVal }),
                      });
                      setAgent(prev => prev ? { ...prev, glbModel: newVal } : prev);
                    } catch {}
                  }}
                  className="text-xs px-2 py-0.5 rounded-full bg-mc-bg border border-mc-border cursor-pointer"
                >
                  <option value="">🎮 Procedural</option>
                  {glbFiles.map(f => (
                    <option key={f} value={f}>🎮 {f.split('/').pop()}</option>
                  ))}
                </select>
                {agent.lastActive && (
                  <span className="text-xs text-mc-muted ml-auto">Active: {new Date(agent.lastActive).toLocaleDateString()}</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Main Content: Two Columns with Chat */}
        <div className="flex flex-1 overflow-hidden" style={{ maxHeight: 'calc(90vh - 180px)' }}>
          {/* Left: Tabs + Content */}
          <div className="flex flex-1 min-w-0 overflow-hidden">
            {/* Vertical Tabs */}
            <div className="w-20 flex-shrink-0 border-r border-mc-border overflow-y-auto py-1">
              {((['overview', ...(agent?.id === 'brain' ? ['braindump'] : []), 'personality', 'stats', 'activity'] as any[])).map(t => (
                <button key={t} onClick={() => {
                  setTab(t as any);
                  if (t === 'activity' && !activityData && !activityLoading) {
                    setActivityLoading(true);
                    fetch(`/api/agents/activity?agentId=${agentId}`).then(r => r.json()).then(d => setActivityData(d)).catch(() => {}).finally(() => setActivityLoading(false));
                  }
                }}
                  className={`w-full px-1 py-2 text-xs font-medium transition-colors ${
                    tab === t ? 'text-mc-accent bg-mc-accent/10' : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'
                  }`}>
                  {t === 'overview' ? '📋' : t === 'braindump' ? '🧠' : t === 'personality' ? '🎭' : t === 'stats' ? '📊' : '⚡'}
                  <div>{t === 'overview' ? 'Overview' : t === 'braindump' ? 'Brain' : t === 'personality' ? 'Persona' : t === 'stats' ? 'Stats' : 'Activity'}</div>
                </button>
              ))}
            </div>

            {/* Tab Content - Scrollable */}
            <div className="flex-1 overflow-y-auto p-3">
              {/* Overview Tab */}
              {tab === 'overview' && (
                <div className="space-y-3">
                  {/* XP & Performance Section */}
                  {xpData && (
                    <div className="bg-mc-bg/60 rounded-lg border border-mc-border/50 p-3">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">Performance</h3>
                        <XPBadge level={xpData.level} levelLabel={xpData.levelLabel} showLabel />
                      </div>
                      <XPBar 
                        xp={xpData.xp} 
                        xpToNextLevel={xpData.xpToNextLevel} 
                        progress={xpData.progress} 
                        level={xpData.level} 
                        levelLabel={xpData.levelLabel} 
                      />
                      <div className="mt-3 pt-3 border-t border-mc-border/50">
                        <EfficiencyMetric 
                          efficiency={xpData.efficiency} 
                          totalTasks={xpData.stats.totalTasks}
                          completedTasks={xpData.stats.completedTasks}
                          showDetails
                        />
                      </div>
                    </div>
                  )}

                  {/* Bio */}
                  <div>
                    <label className="text-[10px] text-mc-muted uppercase tracking-wider font-semibold">Bio</label>
                    {editing ? (
                      <textarea value={draft.bio || ''} onChange={e => setDraft({ ...draft, bio: e.target.value })}
                        className="w-full mt-1 bg-mc-bg border border-mc-border rounded p-2 text-sm resize-none h-28" />
                    ) : (
                      <p className="text-sm mt-0.5 whitespace-pre-wrap leading-relaxed">{agent.bio || 'No bio set'}</p>
                    )}
                  </div>

                  {/* Compact Info Grid */}
                  <div className="bg-mc-bg/60 rounded-lg border border-mc-border/50 p-2.5">
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-2">
                      {/* Reports To */}
                      {(() => {
                        const parentAgent = allAgents.find(a => a.id === agent.parent);
                        return (
                          <div>
                            <label className="text-[10px] text-mc-muted uppercase tracking-wider font-semibold">Reports To</label>
                            {editing ? (
                              <select value={draft.parent || ''} onChange={e => setDraft({ ...draft, parent: e.target.value || null })}
                                className="w-full mt-0.5 bg-mc-bg border border-mc-border rounded px-1.5 py-1 text-xs">
                                <option value="">None (Top Level)</option>
                                {allAgents.filter(a => a.id !== agentId).map(a => (
                                  <option key={a.id} value={a.id}>{a.displayName || a.name}</option>
                                ))}
                              </select>
                            ) : parentAgent ? (
                              <button onClick={() => { onClose(); setTimeout(() => onSelectAgent?.(parentAgent.id), 100); }}
                                className="text-xs mt-0.5 text-mc-accent hover:underline cursor-pointer block truncate">
                                {parentAgent.displayName || parentAgent.name}
                              </button>
                            ) : (
                              <div className="text-xs mt-0.5 text-mc-muted">—</div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Direct Reports */}
                      {(() => {
                        const directReports = allAgents.filter(a => a.parent === agent.id);
                        return (
                          <div className="col-span-2 lg:col-span-2">
                            <label className="text-[10px] text-mc-muted uppercase tracking-wider font-semibold">Direct Reports ({directReports.length})</label>
                            {directReports.length > 0 ? (
                              <div className="flex flex-wrap gap-1 mt-0.5">
                                {directReports.map(dr => (
                                  <button key={dr.id} onClick={() => { onClose(); setTimeout(() => onSelectAgent?.(dr.id), 100); }}
                                    className="text-[11px] px-1.5 py-0.5 rounded-full bg-mc-bg border border-mc-border text-mc-accent hover:bg-mc-accent/10 cursor-pointer">
                                    {dr.displayName || dr.name}
                                  </button>
                                ))}
                              </div>
                            ) : (
                              <div className="text-xs mt-0.5 text-mc-muted">None</div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Character */}
                      <div>
                        <label className="text-[10px] text-mc-muted uppercase tracking-wider font-semibold">Character</label>
                        <div className="text-xs mt-0.5">{charType.emoji} {charType.name}</div>
                      </div>

                      {/* Model */}
                      <div>
                        <label className="text-[10px] text-mc-muted uppercase tracking-wider font-semibold">Model</label>
                        <div className="text-xs mt-0.5 font-mono">{agent.model ? agent.model.split('/').pop() : `Tier (${tierLabel})`}</div>
                      </div>

                      {/* Color */}
                      <div>
                        <label className="text-[10px] text-mc-muted uppercase tracking-wider font-semibold">Color</label>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="w-3 h-3 rounded" style={{ backgroundColor: agent.color }} />
                          <span className="text-xs font-mono">{agent.color}</span>
                        </div>
                      </div>

                      {/* Voice */}
                      <div className="col-span-2 lg:col-span-3">
                        <VoiceSelector editing={editing} voiceId={editing ? (draft.voice || '') : (agent.voice || '')}
                          onChange={(v: string) => setDraft({ ...draft, voice: v || null })} agentName={agent.displayName || agent.name} />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Brain Dump Tab */}
              {tab === 'braindump' && agent && <BrainDumpComponent agent={agent} />}

              {/* Personality Tab */}
              {tab === 'personality' && <PersonalityTab agentId={agentId} />}

              {/* Stats Tab */}
              {tab === 'stats' && (
                <StatsTab agentId={agentId} tierLabel={tierLabel} status={agent.status}
                  usageData={usageData} usageLoading={usageLoading} fetchUsage={fetchUsage}
                  usageFrom={usageFrom} usageTo={usageTo} setUsageFrom={setUsageFrom} setUsageTo={setUsageTo} />
              )}

              {/* Activity Tab */}
              {tab === 'activity' && (
                <ActivityTab agentId={agentId} activityData={activityData}
                  activityLoading={activityLoading} />
              )}
            </div>
          </div>

          {/* Right: Chat (Always Visible) */}
          <div className="w-[45%] min-w-[320px] max-w-[520px] flex-shrink-0 border-l border-mc-border flex flex-col bg-mc-bg/50">
            <div className="flex items-center justify-between px-3 py-2 bg-mc-bg/50 border-b border-mc-border/50 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-sm">💬</span>
                <span className="text-sm font-medium text-mc-text">Chat</span>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-2">
              {chatMessages.length === 0 && <p className="text-xs text-mc-muted text-center py-4">Chat with {agent.displayName || agent.name}...</p>}
              {chatMessages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] px-2 py-1 rounded-lg text-sm ${msg.role === 'user' ? 'bg-mc-accent text-white' : 'bg-mc-bg border border-mc-border'}`}>
                    <MarkdownMessage content={msg.content} />
                  </div>
                </div>
              ))}
              {chatLoading && <div className="text-xs text-mc-muted animate-pulse">Thinking...</div>}
            </div>
            <div className="flex gap-1 p-2 border-t border-mc-border/50 flex-shrink-0">
              <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') sendChat(); }}
                placeholder="Message..." className="flex-1 bg-mc-bg border border-mc-border rounded px-2 py-1 text-sm focus:outline-none" disabled={chatLoading} />
              <button onClick={sendChat} disabled={chatLoading || !chatInput.trim()} className="px-2 py-1 bg-mc-accent text-white rounded text-sm">Send</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
