'use client';

import React, { useState, useEffect, useCallback } from 'react';
import type { PMRun, RunNode, RunStatus } from './types';

// ─── Status colours ─────────────────────────────────────────────────
const STATUS_STYLE: Record<RunStatus, { dot: string; text: string; bg: string }> = {
  idle:     { dot: 'bg-gray-400',    text: 'text-gray-400',    bg: 'bg-gray-400/10' },
  running:  { dot: 'bg-blue-400',    text: 'text-blue-400',    bg: 'bg-blue-400/10' },
  paused:   { dot: 'bg-yellow-400',  text: 'text-yellow-400',  bg: 'bg-yellow-400/10' },
  complete: { dot: 'bg-emerald-400', text: 'text-emerald-400', bg: 'bg-emerald-400/10' },
  failed:   { dot: 'bg-red-400',     text: 'text-red-400',     bg: 'bg-red-400/10' },
};

function elapsed(start: string, end?: string): string {
  const ms = (end ? new Date(end).getTime() : Date.now()) - new Date(start).getTime();
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  return `${Math.floor(s / 60)}m ${s % 60}s`;
}

// ─── Component ──────────────────────────────────────────────────────
interface PMDashboardProps {
  projectId: string;
  run?: PMRun | null;
  onStart?: () => void;
  onPause?: () => void;
  onCancel?: () => void;
  polling?: boolean;
}

export default function PMDashboard({ projectId, run, onStart, onPause, onCancel, polling }: PMDashboardProps) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  // Live clock for running status
  useEffect(() => {
    if (run?.status !== 'running') return;
    const iv = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(iv);
  }, [run?.status]);

  const completedNodes = run?.nodes.filter(n => n.status === 'complete').length ?? 0;
  const totalNodes = run?.nodes.length ?? 0;
  const progress = totalNodes > 0 ? Math.round((completedNodes / totalNodes) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-semibold text-mc-text">PM Run Dashboard</h3>
          {run && (
            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${STATUS_STYLE[run.status].bg} ${STATUS_STYLE[run.status].text}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${STATUS_STYLE[run.status].dot} ${run.status === 'running' ? 'animate-pulse' : ''}`} />
              {run.status.toUpperCase()}
            </span>
          )}
          {polling && <span className="text-[10px] text-mc-muted animate-pulse">● live</span>}
        </div>
        <div className="flex gap-2">
          {(!run || run.status === 'idle') && onStart && (
            <button onClick={onStart}
              className="px-3 py-1 text-xs rounded bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition">
              ▶ Start Run
            </button>
          )}
          {run?.status === 'running' && onPause && (
            <button onClick={onPause}
              className="px-3 py-1 text-xs rounded bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 transition">
              ⏸ Pause
            </button>
          )}
          {run && run.status !== 'complete' && run.status !== 'failed' && onCancel && (
            <button onClick={onCancel}
              className="px-3 py-1 text-xs rounded bg-red-500/20 text-red-400 hover:bg-red-500/30 transition">
              ✕ Cancel
            </button>
          )}
        </div>
      </div>

      {/* Summary strip */}
      {run && (
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: 'Elapsed', value: elapsed(run.startedAt, run.completedAt) },
            { label: 'Progress', value: `${progress}%` },
            { label: 'Cost', value: `$${run.totalCost.toFixed(4)}` },
            { label: 'Nodes', value: `${completedNodes}/${totalNodes}` },
          ].map(s => (
            <div key={s.label} className="rounded-lg border border-mc-border bg-mc-card p-3 text-center">
              <div className="text-[10px] text-mc-muted uppercase">{s.label}</div>
              <div className="text-lg font-mono text-mc-text">{s.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Progress bar */}
      {run && (
        <div className="h-2 rounded-full bg-mc-border overflow-hidden">
          <div className={`h-full rounded-full transition-all duration-500 ${
            run.status === 'failed' ? 'bg-red-500' :
            run.status === 'complete' ? 'bg-emerald-500' : 'bg-blue-500'
          }`} style={{ width: `${progress}%` }} />
        </div>
      )}

      {/* Node list */}
      {run && (
        <div className="space-y-1">
          <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">Nodes</h4>
          {run.nodes.map((node: RunNode) => {
            const graphNode = run.graph.nodes.find(n => n.id === node.nodeId);
            const st = STATUS_STYLE[node.status];
            const isExpanded = expanded === node.nodeId;
            return (
              <div key={node.nodeId}
                className={`rounded border border-mc-border ${st.bg} transition cursor-pointer`}
                onClick={() => setExpanded(isExpanded ? null : node.nodeId)}>
                <div className="flex items-center gap-3 px-3 py-2">
                  <span className={`w-2 h-2 rounded-full ${st.dot} ${node.status === 'running' ? 'animate-pulse' : ''}`} />
                  <span className="text-xs font-medium text-mc-text flex-1">
                    {graphNode?.label || node.nodeId}
                  </span>
                  {graphNode?.agent && (
                    <span className="text-[10px] text-mc-muted">{graphNode.agent}</span>
                  )}
                  {node.cost != null && (
                    <span className="text-[10px] font-mono text-emerald-400">${node.cost.toFixed(4)}</span>
                  )}
                  <span className={`text-[10px] ${st.text}`}>{node.status}</span>
                  {node.startedAt && (
                    <span className="text-[10px] text-mc-muted">{elapsed(node.startedAt, node.completedAt)}</span>
                  )}
                </div>
                {isExpanded && (
                  <div className="px-3 pb-2 space-y-1">
                    {node.output && (
                      <pre className="text-[10px] font-mono text-mc-muted bg-mc-bg rounded p-2 max-h-32 overflow-auto whitespace-pre-wrap">
                        {node.output}
                      </pre>
                    )}
                    {node.error && (
                      <pre className="text-[10px] font-mono text-red-400 bg-red-500/5 rounded p-2 max-h-32 overflow-auto whitespace-pre-wrap">
                        {node.error}
                      </pre>
                    )}
                    {!node.output && !node.error && (
                      <span className="text-[10px] text-mc-muted italic">No output yet</span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* No run state */}
      {!run && (
        <div className="text-center py-12 text-mc-muted">
          <div className="text-3xl mb-2">🚀</div>
          <p className="text-sm">No active run for this project.</p>
          <p className="text-xs mt-1">Configure your DAG and sliders, then start a run.</p>
        </div>
      )}
    </div>
  );
}
