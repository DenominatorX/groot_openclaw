'use client';

import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { DAGNode, DAGEdge, DAGGraph } from './types';

// ─── Constants ──────────────────────────────────────────────────────
const NODE_W = 160;
const NODE_H = 56;
const GRID = 20;

const NODE_COLORS: Record<DAGNode['type'], { border: string; bg: string; text: string }> = {
  agent:      { border: 'border-emerald-500', bg: 'bg-emerald-500/10', text: 'text-emerald-400' },
  gate:       { border: 'border-yellow-500',  bg: 'bg-yellow-500/10',  text: 'text-yellow-400'  },
  checkpoint: { border: 'border-blue-500',    bg: 'bg-blue-500/10',    text: 'text-blue-400'    },
  start:      { border: 'border-mc-accent',   bg: 'bg-mc-accent/10',   text: 'text-mc-accent'   },
  end:        { border: 'border-pink-500',    bg: 'bg-pink-500/10',    text: 'text-pink-400'    },
};

const snap = (v: number) => Math.round(v / GRID) * GRID;

// ─── Helpers ────────────────────────────────────────────────────────
function edgePath(src: DAGNode, tgt: DAGNode): string {
  const sx = src.x + NODE_W / 2;
  const sy = src.y + NODE_H;
  const tx = tgt.x + NODE_W / 2;
  const ty = tgt.y;
  const my = (sy + ty) / 2;
  return `M ${sx} ${sy} C ${sx} ${my}, ${tx} ${my}, ${tx} ${ty}`;
}

let _idCounter = 0;
function uid(prefix = 'n') {
  _idCounter += 1;
  return `${prefix}-${Date.now()}-${_idCounter}`;
}

// ─── Component ──────────────────────────────────────────────────────
interface DAGEditorProps {
  graph: DAGGraph;
  onChange: (g: DAGGraph) => void;
  readOnly?: boolean;
}

export default function DAGEditor({ graph, onChange, readOnly }: DAGEditorProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [dragging, setDragging] = useState<{ id: string; offX: number; offY: number } | null>(null);
  const [connecting, setConnecting] = useState<string | null>(null);
  const [editNode, setEditNode] = useState<DAGNode | null>(null);

  // ── Drag ────────────────────────────────────────────────────────
  const handleMouseDown = useCallback((e: React.MouseEvent, nodeId: string) => {
    if (readOnly) return;
    e.stopPropagation();
    const node = graph.nodes.find(n => n.id === nodeId);
    if (!node) return;
    setSelected(nodeId);
    setDragging({ id: nodeId, offX: e.clientX - node.x, offY: e.clientY - node.y });
  }, [graph, readOnly]);

  useEffect(() => {
    if (!dragging) return;
    const onMove = (e: MouseEvent) => {
      onChange({
        ...graph,
        nodes: graph.nodes.map(n =>
          n.id === dragging.id
            ? { ...n, x: snap(e.clientX - dragging.offX), y: snap(e.clientY - dragging.offY) }
            : n
        ),
      });
    };
    const onUp = () => setDragging(null);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [dragging, graph, onChange]);

  // ── Edge creation via connecting mode ───────────────────────────
  const handleNodeClick = useCallback((nodeId: string) => {
    if (readOnly) return;
    if (connecting) {
      if (connecting !== nodeId && !graph.edges.find(e => e.source === connecting && e.target === nodeId)) {
        onChange({
          ...graph,
          edges: [...graph.edges, { id: uid('e'), source: connecting, target: nodeId }],
        });
      }
      setConnecting(null);
    }
  }, [connecting, graph, onChange, readOnly]);

  // ── Add node ────────────────────────────────────────────────────
  const addNode = useCallback((type: DAGNode['type']) => {
    const maxY = graph.nodes.reduce((m, n) => Math.max(m, n.y), 0);
    const newNode: DAGNode = {
      id: uid('n'),
      label: type === 'agent' ? 'New Agent' : type.charAt(0).toUpperCase() + type.slice(1),
      type,
      x: 200,
      y: maxY + 100,
    };
    onChange({ ...graph, nodes: [...graph.nodes, newNode] });
    setSelected(newNode.id);
  }, [graph, onChange]);

  // ── Delete ──────────────────────────────────────────────────────
  const deleteSelected = useCallback(() => {
    if (!selected) return;
    onChange({
      nodes: graph.nodes.filter(n => n.id !== selected),
      edges: graph.edges.filter(e => e.source !== selected && e.target !== selected),
    });
    setSelected(null);
  }, [selected, graph, onChange]);

  // ── Edit label ──────────────────────────────────────────────────
  const saveEdit = useCallback(() => {
    if (!editNode) return;
    onChange({
      ...graph,
      nodes: graph.nodes.map(n => n.id === editNode.id ? editNode : n),
    });
    setEditNode(null);
  }, [editNode, graph, onChange]);

  // ── Canvas bounds ───────────────────────────────────────────────
  const maxX = Math.max(800, ...graph.nodes.map(n => n.x + NODE_W + 40));
  const maxY = Math.max(500, ...graph.nodes.map(n => n.y + NODE_H + 40));

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      {!readOnly && (
        <div className="flex flex-wrap gap-2 items-center">
          {(['agent', 'gate', 'checkpoint'] as const).map(t => (
            <button key={t} onClick={() => addNode(t)}
              className="px-3 py-1 text-xs rounded border border-mc-border hover:border-mc-accent text-mc-muted hover:text-mc-accent transition">
              + {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
          <div className="flex-1" />
          {connecting && (
            <span className="text-xs text-yellow-400 animate-pulse">🔗 Click target node…
              <button onClick={() => setConnecting(null)} className="ml-2 text-mc-muted hover:text-red-400">Cancel</button>
            </span>
          )}
          {selected && (
            <>
              <button onClick={() => setConnecting(selected)}
                className="px-2 py-1 text-xs rounded bg-blue-500/20 text-blue-400 hover:bg-blue-500/30">
                Connect →
              </button>
              <button onClick={() => { const n = graph.nodes.find(x => x.id === selected); if (n) setEditNode({ ...n }); }}
                className="px-2 py-1 text-xs rounded bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30">
                Edit
              </button>
              <button onClick={deleteSelected}
                className="px-2 py-1 text-xs rounded bg-red-500/20 text-red-400 hover:bg-red-500/30">
                Delete
              </button>
            </>
          )}
        </div>
      )}

      {/* SVG Canvas */}
      <div className="rounded-lg border border-mc-border bg-mc-bg overflow-auto" style={{ maxHeight: 520 }}>
        <svg ref={svgRef} width={maxX} height={maxY} className="select-none"
          onClick={() => { setSelected(null); setConnecting(null); }}>
          {/* Grid */}
          <defs>
            <pattern id="dag-grid" width={GRID} height={GRID} patternUnits="userSpaceOnUse">
              <circle cx={1} cy={1} r={0.5} fill="rgba(255,255,255,0.04)" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dag-grid)" />

          {/* Edges */}
          {graph.edges.map(edge => {
            const src = graph.nodes.find(n => n.id === edge.source);
            const tgt = graph.nodes.find(n => n.id === edge.target);
            if (!src || !tgt) return null;
            return (
              <g key={edge.id}>
                <path d={edgePath(src, tgt)} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth={2} />
                <path d={edgePath(src, tgt)} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth={10}
                  className="cursor-pointer opacity-0 hover:opacity-30"
                  onClick={e => { e.stopPropagation(); if (!readOnly) onChange({ ...graph, edges: graph.edges.filter(x => x.id !== edge.id) }); }} />
                {/* Arrow */}
                <circle cx={tgt.x + NODE_W / 2} cy={tgt.y - 4} r={3} fill="rgba(255,255,255,0.2)" />
              </g>
            );
          })}

          {/* Nodes */}
          {graph.nodes.map(node => {
            const c = NODE_COLORS[node.type];
            const isSel = node.id === selected;
            return (
              <g key={node.id}
                onMouseDown={e => handleMouseDown(e, node.id)}
                onClick={e => { e.stopPropagation(); handleNodeClick(node.id); setSelected(node.id); }}
                className="cursor-grab active:cursor-grabbing"
              >
                <rect x={node.x} y={node.y} width={NODE_W} height={NODE_H} rx={8}
                  className={`${c.bg} ${isSel ? 'stroke-mc-accent' : ''}`}
                  fill="rgba(30,30,40,0.9)"
                  stroke={isSel ? '#06b6d4' : 'rgba(255,255,255,0.1)'}
                  strokeWidth={isSel ? 2 : 1} />
                <text x={node.x + NODE_W / 2} y={node.y + 22} textAnchor="middle"
                  className={`text-xs font-medium fill-current ${c.text}`} fontSize={12}>
                  {node.label}
                </text>
                <text x={node.x + NODE_W / 2} y={node.y + 40} textAnchor="middle"
                  className="fill-current text-mc-muted" fontSize={10}>
                  {node.agent || node.type}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Edit Modal */}
      {editNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setEditNode(null)}>
          <div className="bg-mc-card border border-mc-border rounded-lg p-5 w-96 space-y-3" onClick={e => e.stopPropagation()}>
            <h3 className="text-sm font-semibold text-mc-text">Edit Node</h3>
            <label className="block text-xs text-mc-muted">
              Label
              <input value={editNode.label} onChange={e => setEditNode({ ...editNode, label: e.target.value })}
                className="mt-1 w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text" />
            </label>
            <label className="block text-xs text-mc-muted">
              Agent
              <input value={editNode.agent || ''} onChange={e => setEditNode({ ...editNode, agent: e.target.value })}
                className="mt-1 w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text" />
            </label>
            <label className="block text-xs text-mc-muted">
              Model
              <input value={editNode.model || ''} onChange={e => setEditNode({ ...editNode, model: e.target.value })}
                className="mt-1 w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text" />
            </label>
            <label className="block text-xs text-mc-muted">
              Type
              <select value={editNode.type} onChange={e => setEditNode({ ...editNode, type: e.target.value as DAGNode['type'] })}
                className="mt-1 w-full px-2 py-1 text-xs rounded bg-mc-bg border border-mc-border text-mc-text">
                {['agent', 'gate', 'checkpoint', 'start', 'end'].map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </label>
            <div className="flex gap-2 justify-end pt-2">
              <button onClick={() => setEditNode(null)} className="px-3 py-1 text-xs rounded border border-mc-border text-mc-muted hover:text-mc-text">Cancel</button>
              <button onClick={saveEdit} className="px-3 py-1 text-xs rounded bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30">Save</button>
            </div>
          </div>
        </div>
      )}

      {/* Node count badge */}
      <div className="flex gap-3 text-[10px] text-mc-muted">
        <span>{graph.nodes.length} nodes</span>
        <span>{graph.edges.length} edges</span>
      </div>
    </div>
  );
}
