'use client';

import { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { RefreshCw, AlertCircle, Cpu, CalendarDays } from 'lucide-react';

interface ModelUpdatesData {
  file: string;
  content: string;
  date?: string;
}

function SkeletonLine({ w = 'w-full' }: { w?: string }) {
  return <div className={`h-3 ${w} bg-mc-border/60 rounded animate-pulse`} />;
}

/** Extract a YYYY-MM-DD date from a filename like model-updates-2025-01-15.md */
function parseDateFromFilename(filename: string): string | null {
  const match = filename.match(/(\d{4}-\d{2}-\d{2})/);
  if (!match) return null;
  try {
    return new Date(match[1]).toLocaleDateString(undefined, {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return match[1];
  }
}

export default function DailyModelUpdates() {
  const [data, setData] = useState<ModelUpdatesData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchUpdates = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/model-updates/latest');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      setError(err.message || 'Failed to load model updates');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUpdates();
  }, []);

  const reportDate = data?.file ? parseDateFromFilename(data.file) : null;

  return (
    <div className="flex flex-col h-full bg-mc-surface border border-mc-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border/50">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-mc-accent" />
          <span className="font-semibold text-sm text-mc-text">Model Updates</span>
          {reportDate && (
            <span className="flex items-center gap-1 text-[10px] text-mc-muted bg-mc-bg px-1.5 py-0.5 rounded border border-mc-border/40">
              <CalendarDays className="w-3 h-3" />
              {reportDate}
            </span>
          )}
        </div>
        <button
          onClick={fetchUpdates}
          disabled={loading}
          className="text-mc-muted hover:text-mc-text transition-colors disabled:opacity-40 p-1 rounded"
          title="Refresh model updates"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-mc-border scrollbar-track-transparent">
        {loading && (
          <div className="space-y-3">
            <SkeletonLine w="w-1/2" />
            <SkeletonLine w="w-full" />
            <SkeletonLine w="w-5/6" />
            <SkeletonLine w="w-full" />
            <SkeletonLine w="w-3/4" />
            <div className="pt-2 space-y-2">
              <SkeletonLine w="w-1/3" />
              <SkeletonLine w="w-full" />
              <SkeletonLine w="w-4/5" />
            </div>
          </div>
        )}
        {!loading && error && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-sm text-red-400">{error}</p>
            <button onClick={fetchUpdates} className="text-xs text-mc-accent hover:underline">Try again</button>
          </div>
        )}
        {!loading && !error && (!data || !data.content) && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <Cpu className="w-6 h-6 text-mc-muted" />
            <p className="text-sm text-mc-muted font-medium">No updates yet</p>
            <p className="text-xs text-mc-muted/70">Model intel reports will appear here once the daily cron runs.</p>
          </div>
        )}
        {!loading && !error && data?.content && (
          <div className="space-y-1">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                h1: ({children}) => <p className="text-xs font-semibold text-mc-text uppercase tracking-wider mt-3 mb-1">{children}</p>,
                h2: ({children}) => <p className="text-xs font-semibold text-mc-text uppercase tracking-wider mt-3 mb-1">{children}</p>,
                h3: ({children}) => <p className="text-[10px] font-semibold text-mc-text uppercase tracking-wider mt-2 mb-0.5">{children}</p>,
                p: ({children}) => <p className="text-xs text-mc-muted leading-relaxed">{children}</p>,
                ul: ({children}) => <ul className="space-y-0.5 list-disc list-inside pl-1">{children}</ul>,
                ol: ({children}) => <ol className="space-y-0.5 list-decimal list-inside pl-1">{children}</ol>,
                li: ({children}) => <li className="text-xs text-mc-muted">{children}</li>,
                strong: ({children}) => <strong className="font-semibold text-mc-text">{children}</strong>,
                em: ({children}) => <em className="italic text-mc-muted">{children}</em>,
                code: ({children}) => <code className="text-[11px] text-mc-accent bg-mc-bg px-1 py-0.5 rounded">{children}</code>,
                pre: ({children}) => <pre className="text-xs bg-mc-bg border border-mc-border/50 rounded p-2 overflow-x-auto">{children}</pre>,
                hr: () => <hr className="border-mc-border/50 my-2" />,
                a: ({href, children}) => <a href={href} className="text-mc-accent hover:underline">{children}</a>,
                blockquote: ({children}) => <blockquote className="border-l-2 border-mc-accent/60 pl-2 text-xs text-mc-muted italic">{children}</blockquote>,
              }}
            >
              {data.content}
            </ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}
