'use client';

import { useState, useEffect } from 'react';
import { RefreshCw, AlertCircle, Calendar, Mail, Cloud, Brain, Clock, Zap } from 'lucide-react';

interface BriefingData {
  activeProjects: Project[];
  todayMemory?: string | null;
  generatedAt?: string;
}

interface Project {
  id: string;
  name: string;
  status: string;
}

interface RichBriefingData {
  weather?: {
    temp: number;
    condition: string;
    location: string;
  };
  calendar?: {
    events: Array<{ title: string; time: string; type: string }>;
    upcomingCount: number;
  };
  emails?: {
    unread: number;
    urgent: number;
  };
  modelUpdates?: Array<{ model: string; update: string; time: string }>;
  generatedAt?: string;
}

function SkeletonLine({ w = 'w-full' }: { w?: string }) {
  return <div className={`h-3 ${w} bg-mc-bg rounded animate-pulse`} />;
}

function SkeletonBox() {
  return (
    <div className="bg-mc-surface border border-mc-border rounded-lg p-3 space-y-2">
      <SkeletonLine w="w-1/2" />
      <SkeletonLine w="w-3/4" />
      <SkeletonLine w="w-1/3" />
    </div>
  );
}

export default function DailyBriefing() {
  const [briefingData, setBriefingData] = useState<BriefingData | null>(null);
  const [richData, setRichData] = useState<RichBriefingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBriefing = async () => {
    setLoading(true);
    setError(null);
    try {
      // Fetch basic briefing
      const basicRes = await fetch('/api/brain/briefing');
      if (!basicRes.ok) throw new Error(`HTTP ${basicRes.status}`);
      const basicJson = await basicRes.json();
      setBriefingData(basicJson);

      // Fetch rich briefing with full=true for more content
      const richRes = await fetch('/api/brain/briefing?full=true');
      if (richRes.ok) {
        const richJson = await richRes.json();
        setRichData(richJson);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load briefing');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBriefing();
  }, []);

  return (
    <div className="flex flex-col h-full bg-mc-bg border border-mc-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-mc-accent" />
          <span className="font-semibold text-sm text-mc-text">Daily Briefing</span>
        </div>
        <button
          onClick={fetchBriefing}
          disabled={loading}
          className="text-mc-muted hover:text-mc-text transition-colors disabled:opacity-40 p-1 rounded"
          title="Refresh briefing"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-mc-border scrollbar-track-transparent">
        {/* Loading skeleton */}
        {loading && (
          <div className="space-y-3">
            <SkeletonBox />
            <SkeletonBox />
            <SkeletonBox />
          </div>
        )}

        {/* Error state */}
        {!loading && error && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-sm text-red-400">{error}</p>
            <button
              onClick={fetchBriefing}
              className="text-xs text-mc-accent hover:underline"
            >
              Try again
            </button>
          </div>
        )}

        {/* Content */}
        {!loading && !error && (
          <>
            {/* Weather Widget */}
            {(richData?.weather || briefingData) && (
              <div className="bg-mc-surface border border-mc-border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Cloud className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-xs font-semibold text-mc-text uppercase tracking-wider">Weather</span>
                </div>
                {richData?.weather ? (
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-bold text-mc-text">{richData.weather.temp}°</span>
                    <div>
                      <p className="text-xs text-mc-text">{richData.weather.condition}</p>
                      <p className="text-[10px] text-mc-muted">{richData.weather.location}</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-mc-muted">Weather data unavailable</p>
                )}
              </div>
            )}

            {/* Calendar Widget */}
            {(richData?.calendar || briefingData) && (
              <div className="bg-mc-surface border border-mc-border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-xs font-semibold text-mc-text uppercase tracking-wider">Today&apos;s Schedule</span>
                  {richData?.calendar?.upcomingCount && (
                    <span className="ml-auto text-[10px] bg-purple-900/50 text-purple-400 px-1.5 py-0.5 rounded">
                      {richData.calendar.upcomingCount} upcoming
                    </span>
                  )}
                </div>
                {richData?.calendar?.events && richData.calendar.events.length > 0 ? (
                  <ul className="space-y-1">
                    {richData.calendar.events.slice(0, 3).map((event, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs">
                        <Clock className="w-3 h-3 text-mc-muted" />
                        <span className="text-mc-muted">{event.time}</span>
                        <span className="text-mc-text truncate">{event.title}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-mc-muted">No events scheduled</p>
                )}
              </div>
            )}

            {/* Email Summary */}
            {(richData?.emails || briefingData) && (
              <div className="bg-mc-surface border border-mc-border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Mail className="w-3.5 h-3.5 text-green-400" />
                  <span className="text-xs font-semibold text-mc-text uppercase tracking-wider">Email</span>
                </div>
                {richData?.emails ? (
                  <div className="flex gap-3">
                    <div className="text-center">
                      <p className="text-lg font-bold text-mc-text">{richData.emails.unread}</p>
                      <p className="text-[10px] text-mc-muted">unread</p>
                    </div>
                    {richData.emails.urgent > 0 && (
                      <div className="text-center">
                        <p className="text-lg font-bold text-red-400">{richData.emails.urgent}</p>
                        <p className="text-[10px] text-mc-muted">urgent</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-mc-muted">Email data unavailable</p>
                )}
              </div>
            )}

            {/* Model Updates / AI Intel */}
            {(richData?.modelUpdates || briefingData) && (
              <div className="bg-mc-surface border border-mc-border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-3.5 h-3.5 text-yellow-400" />
                  <span className="text-xs font-semibold text-mc-text uppercase tracking-wider">AI Updates</span>
                </div>
                {richData?.modelUpdates && richData.modelUpdates.length > 0 ? (
                  <ul className="space-y-1.5">
                    {richData.modelUpdates.slice(0, 3).map((update, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Brain className="w-3 h-3 text-mc-accent mt-0.5" />
                        <div className="min-w-0">
                          <p className="text-xs text-mc-text truncate">{update.update}</p>
                          <p className="text-[10px] text-mc-muted">{update.model} · {update.time}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-mc-muted">No recent model updates</p>
                )}
              </div>
            )}

            {/* Timestamp */}
            {(richData?.generatedAt || briefingData?.generatedAt) && (
              <p className="text-[10px] text-mc-muted/50 text-right">
                Updated {new Date(richData?.generatedAt || briefingData?.generatedAt || '').toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            )}
          </>
        )}

        {/* Empty state */}
        {(!loading && !error && !briefingData && !richData) && (
          <div className="flex flex-col items-center justify-center h-32 text-center gap-2">
            <Brain className="w-6 h-6 text-mc-muted" />
            <p className="text-sm text-mc-muted">No briefing available</p>
          </div>
        )}
      </div>
    </div>
  );
}