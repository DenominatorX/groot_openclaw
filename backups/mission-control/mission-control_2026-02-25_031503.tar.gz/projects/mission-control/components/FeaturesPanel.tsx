'use client';
import { useState, useEffect } from 'react';

// ══════════════════════════════════════════════════════════════
// EXHAUSTIVE FEATURE REGISTRY — Every MC feature documented
// ══════════════════════════════════════════════════════════════

interface Feature {
  name: string;
  description: string;
  status: 'live' | 'beta' | 'planned';
  testStatus?: 'pending' | 'validated' | 'broken';
  lastTested?: string | null;
}

interface TrackedFeature {
  id: string;
  pageId: string;
  name: string;
  description: string;
  status: 'live' | 'beta' | 'planned';
  testStatus: 'pending' | 'validated' | 'broken';
  lastTested: string | null;
  addedVersion: string;
  lastChangedVersion: string | null;
  failureReason?: string | null;
}

interface NewFeatureItem {
  pageId: string;
  pageName: string;
  name: string;
  description: string;
  status: string;
}

interface PageFeatures {
  id: string;
  name: string;
  icon: string;
  description: string;
  route: string;
  techStack: string[];
  dataFiles: string[];
  apiRoutes: string[];
  features: Feature[];
}

const MC_PAGES: PageFeatures[] = [
  {
    id: 'kanban', name: 'Task Board (Kanban)', icon: '📋',
    description: 'Drag-and-drop kanban board for tasks and projects with 4 active columns, inline stats, AI analysis, and completed items archive.',
    route: '/kanban', techStack: ['React DnD', 'Tailwind CSS', 'Next.js API'], dataFiles: ['data/tasks.json', 'data/projects.json'],
    apiRoutes: ['/api/tasks', '/api/projects', '/api/projects/analyze'],
    features: [
      { name: 'Drag-and-drop task cards', description: 'Move tasks between Inbox, Assigned, In Progress, and Review columns', status: 'live' },
      { name: 'Project cards with phase progress', description: 'Projects show phase completion percentage and assignee', status: 'live' },
      { name: 'Inline stat tiles', description: 'Task count, active agents, projects, messages — all in the header row', status: 'live' },
      { name: 'Quick task/project creation', description: 'Add tasks or projects directly from the board with type toggle', status: 'live' },
      { name: 'View mode filters', description: 'Toggle between All, Tasks Only, and Projects Only views', status: 'live' },
      { name: 'AI Analyze & Optimize', description: 'AI scans for duplicates, overlapping work, nesting opportunities, and optimizations', status: 'live' },
      { name: 'Completed items archive', description: 'Dedicated modal for completed tasks and projects — removed from board for space', status: 'live' },
      { name: 'Priority color coding', description: 'Critical (red), High (orange), Medium (yellow), Low (blue) visual indicators', status: 'live' },
      { name: 'Task detail panel', description: 'Click any task for full detail view with edit capabilities', status: 'live' },
      { name: 'Mobile column switcher', description: 'Swipe between columns on mobile with column indicator buttons', status: 'live' },
    ],
  },
  {
    id: 'projects', name: 'Projects', icon: '📁',
    description: 'Full project management system with sortable table, project profiles, lifecycle tracking, team management, test plans, risk assessment, and persistent team chat.',
    route: '/projects', techStack: ['React', 'Tailwind CSS', 'TypeScript'], dataFiles: ['data/projects.json', 'data/teams.json', 'data/chat/project-*.json'],
    apiRoutes: ['/api/projects', '/api/teams', '/api/chat/project', '/api/tests', '/api/risks', '/api/plan', '/api/lifecycle'],
    features: [
      { name: 'Sortable project table', description: 'Sort by name, status, priority, PM, agents, created/updated dates', status: 'live' },
      { name: 'Project IDs (MC-001)', description: 'Every project has a unique sequential identifier for easy reference', status: 'live' },
      { name: 'Status filters', description: 'Filter by All, Planning, Active, On-Hold, Completed', status: 'live' },
      { name: 'Full-text search', description: 'Search across project names, descriptions, PMs, and status', status: 'live' },
      { name: 'Project Profile with left nav', description: 'Vertical tab navigation: Overview, Phases, Agents, Team, Lifecycle, Tasks, Tests, Risks, Stats, Plan, Reports', status: 'live' },
      { name: 'Phase management', description: 'Add/edit/complete phases with progress tracking and percentage bar', status: 'live' },
      { name: 'Team Builder', description: '5 reusable team templates, auto-assign agents by traits/tier, apply to any project', status: 'live' },
      { name: 'Project Lifecycle', description: '8-phase lifecycle tracking with documents, approvals, decisions, and conflicts', status: 'live' },
      { name: 'Test Plan system', description: 'AI-generated test cases, defect scanner, test execution tracking', status: 'live' },
      { name: 'Risk Assessment', description: 'Severity/likelihood matrix with owner assignment and mitigation plans', status: 'live' },
      { name: 'Play The Plan', description: 'AI generates execution plan from project data, then executes step-by-step', status: 'live' },
      { name: 'Persistent team chat', description: 'Always-visible chat at bottom of project profile — persists across sessions', status: 'live' },
      { name: 'Per-project reports', description: 'Reports tab showing all reports linked to the project', status: 'live' },
      { name: 'Prerequisites system', description: 'Auto-detect dependencies between projects', status: 'live' },
      { name: 'Nested projects', description: 'Parent/child project hierarchy with breadcrumbs', status: 'live' },
      { name: 'Per-project agent model override', description: 'Assign specific AI models to agents within a project context', status: 'live' },
      { name: 'Project Teams flyout', description: 'Manage team templates with roles, responsibilities, rules, and instructions', status: 'live' },
    ],
  },
  {
    id: 'issues', name: 'Issues Log', icon: '🛡️',
    description: 'Full issue tracking system managed by Sentinel (Chief Issues Officer). Supports defects, questions, design discussions, requirements, enhancements, tasks, and reminders.',
    route: '/issues', techStack: ['React', 'OpenRouter/MiniMax M2.5'], dataFiles: ['data/issues.json'],
    apiRoutes: ['/api/issues'],
    features: [
      { name: 'Issue creation with categories', description: '7 categories: Defect, Question, Design Discussion, Requirement, Enhancement, Task, Reminder', status: 'live' },
      { name: 'Issue IDs (ISS-001)', description: 'Sequential issue numbering for tracking', status: 'live' },
      { name: 'Special instructions', description: 'Optional field for specific guidance on how to handle the issue', status: 'live' },
      { name: '▶ Play button (AI resolution)', description: 'Sentinel analyzes issue, provides root cause, resolution plan, and project recommendation', status: 'live' },
      { name: 'Status workflow', description: 'Open → In Progress → Resolved / Needs-Project → Closed', status: 'live' },
      { name: 'Category & status filters', description: 'Filter by any category or status combination with search', status: 'live' },
      { name: 'Priority levels', description: 'Critical, High, Medium, Low with color coding', status: 'live' },
      { name: 'Linked projects', description: 'Issues can be linked to specific projects', status: 'live' },
    ],
  },
  {
    id: 'reports', name: 'Reports', icon: '📄',
    description: 'AI-generated reports system with 19+ types across Health, Legal, System, and Project categories. Full editor, print, PDF export, and auto-generate.',
    route: '/reports', techStack: ['React', 'Markdown', 'Claude Haiku'], dataFiles: ['data/reports.json', 'data/custom-report-types.json'],
    apiRoutes: ['/api/reports', '/api/reports/custom-types'],
    features: [
      { name: '19+ report types', description: '7 Health, 6 Legal, 6 System report templates', status: 'live' },
      { name: 'Auto-generate reports', description: '3-column grid for batch generating Health/Legal/System reports', status: 'live' },
      { name: 'AI-powered content', description: 'Reports generated via Claude Haiku using real project/task data', status: 'live' },
      { name: 'Report editor', description: 'Edit report title and content inline', status: 'live' },
      { name: 'Print & PDF export', description: 'Print-optimized layout with PDF save capability', status: 'live' },
      { name: 'Copy to clipboard', description: 'One-click copy full report content', status: 'live' },
      { name: 'Custom report types', description: 'Create and persist custom report templates', status: 'live' },
      { name: 'Per-project reports', description: 'Reports linked to projects via projectId', status: 'live' },
      { name: 'Ranked report view', description: 'Reports sorted by relevance and date', status: 'live' },
      { name: 'Status badges', description: 'Draft, Approved, Final status tracking', status: 'live' },
    ],
  },
  {
    id: 'trading', name: 'Trading Dashboard', icon: '📈',
    description: 'Paper trading system with portfolio tracking, trade history, real crypto prices via Coinbase API, and AI analysis by Viper (Chief Trading Officer).',
    route: '/trading', techStack: ['React', 'Coinbase API', 'xAI/Grok 4'], dataFiles: ['data/trading/portfolio.json', 'data/trading/trades.json', 'data/trading/audit.json'],
    apiRoutes: ['/api/trading'],
    features: [
      { name: 'Paper trading mode', description: '$10K simulated starting balance with real price feeds', status: 'live' },
      { name: 'Portfolio tracker', description: 'Real-time holdings with P&L, average cost, allocation percentages', status: 'live' },
      { name: 'Trade execution', description: 'Buy/sell with quantity, price, and order type', status: 'live' },
      { name: 'Trade history', description: 'Full audit trail of all trades with timestamps', status: 'live' },
      { name: 'Coinbase API integration', description: 'Real-time crypto prices for BTC, ETH, SOL, DOGE', status: 'live' },
      { name: 'Viper AI analysis', description: 'Chief Trading Officer provides market insights and trade recommendations', status: 'live' },
      { name: 'Tax tracking config', description: 'Tax-lot tracking configuration for future reporting', status: 'live' },
    ],
  },
  {
    id: 'health', name: 'Health Dashboard', icon: '❤️',
    description: 'Personal health management with genetic context (AMPD1 + AGK), supplement tracking, exercise protocols, Oura Ring integration, and Mayo Clinic prep.',
    route: '/health', techStack: ['React', 'Oura API', 'OMI MCP'], dataFiles: ['data/health/supplements.json', 'data/health/exercise.json'],
    apiRoutes: ['/api/health', '/api/oura', '/api/omi'],
    features: [
      { name: 'Genetic variant display', description: 'AMPD1 + AGK mutation details with ATP impact assessment', status: 'live' },
      { name: 'Supplement tracker', description: 'Current supplement stack with dosage, timing, and purpose', status: 'live' },
      { name: 'Exercise protocol', description: 'Safe exercise guidelines based on genetic conditions', status: 'live' },
      { name: 'Oura Ring OAuth', description: 'Connect Oura Ring for sleep, HRV, readiness, and activity data', status: 'live' },
      { name: 'OMI device integration', description: 'MCP protocol endpoint for OMI wearable data', status: 'live' },
      { name: 'Mayo Clinic prep', description: 'Appointment info and health summary for Feb 17, 2026 visit', status: 'live' },
      { name: 'CK monitoring concept', description: 'Planned home finger-stick CK monitoring integration', status: 'planned' },
      { name: 'RhabdoReducer™ trial tracking', description: 'Supplement trial protocol tracking (March-May 2026)', status: 'planned' },
    ],
  },
  {
    id: 'home', name: 'Smart Home', icon: '🏠',
    description: '32 Govee smart devices across 9 rooms with on/off, brightness, color, and temperature control.',
    route: '/home', techStack: ['React', 'Govee API'], dataFiles: ['data/settings.json (govee key)'],
    apiRoutes: ['/api/govee'],
    features: [
      { name: '32 device control', description: 'RGB lights (11 models) + Smart plugs (2 models)', status: 'live' },
      { name: '9 room groups', description: 'Kitchen, Dining, Office, Loft, Hallway, Bedroom, Living Room, Outside, Patio', status: 'live' },
      { name: 'On/Off control', description: 'Individual device and room-level power control', status: 'live' },
      { name: 'Brightness control', description: 'Slider 1-100% per device', status: 'live' },
      { name: 'Color picker', description: 'RGB color selection for compatible devices', status: 'live' },
      { name: 'Color temperature', description: '2000K-9000K warm to cool white', status: 'live' },
      { name: 'Favorites system', description: 'Mark frequently used devices for quick access', status: 'live' },
      { name: 'Device state query', description: 'Poll current state of any device', status: 'live' },
    ],
  },
  {
    id: 'chat', name: 'Chat Rooms', icon: '💬',
    description: 'Multi-room AI chat system with 8+ themed rooms, @mention routing to specific agents, response style modes, and persistent history.',
    route: '/chat', techStack: ['React', 'Multi-provider AI routing'], dataFiles: ['data/rooms.json', 'data/chat/*.json'],
    apiRoutes: ['/api/chat', '/api/chat/agent'],
    features: [
      { name: '8+ themed rooms', description: 'Board Room, Trading Floor, Memory Room, Brain Dump, etc.', status: 'live' },
      { name: '@mention agent routing', description: 'Tag specific agents to route messages to them', status: 'live' },
      { name: '5 response style modes', description: 'Per-room response personality configuration', status: 'live' },
      { name: 'Multi-model routing', description: 'Anthropic, xAI, OpenRouter, NVIDIA, Local — automatic per agent', status: 'live' },
      { name: 'Persistent chat history', description: 'All messages saved to JSON, survive refresh/restart', status: 'live' },
      { name: 'Auto-scroll with threshold', description: 'Smart scroll — only auto-scrolls when within 300px of bottom', status: 'live' },
      { name: 'Claude 4.5 models', description: 'Haiku 4.5, Sonnet 4.5, Opus 4.6 — all updated to latest', status: 'live' },
      { name: 'Memory Room (3 agents)', description: 'Archivist, Interrogator (Grok), Therapist — specialized memory processing', status: 'live' },
      { name: 'Brain Dump processor', description: 'Brain agent processes unstructured thoughts into actionable items', status: 'live' },
    ],
  },
  {
    id: 'global-chat', name: 'Global Floating Chat', icon: '💬',
    description: 'Always-available floating chat window that follows you across all MC pages. Context-aware, draggable, resizable, multi-agent.',
    route: '(floating overlay)', techStack: ['React', 'CSS transforms'], dataFiles: ['(uses /api/chat/agent)'],
    apiRoutes: ['/api/chat/agent', '/api/issues'],
    features: [
      { name: 'Draggable window', description: 'Click and drag header to reposition anywhere on page', status: 'live' },
      { name: 'Resizable', description: 'Drag corner handle to resize the chat window', status: 'live' },
      { name: 'Context-aware', description: 'Knows which tab/page you\'re viewing and includes it in agent context', status: 'live' },
      { name: 'Multi-agent selector', description: 'Pick any combination of agents to chat with simultaneously', status: 'live' },
      { name: 'Save to Issues Log', description: 'Save chat as Defect, Question, Design Discussion, Requirement, Enhancement, or Reminder', status: 'live' },
      { name: 'Reminder creation', description: 'Set date/time reminders from chat context', status: 'live' },
      { name: 'Minimizable', description: 'Collapse to small 💬 button, expand when needed', status: 'live' },
    ],
  },
  {
    id: 'world', name: 'Agent World', icon: '🌍',
    description: 'AAA RTS-style 3D agent visualization with 12 modules: buildings, minimap, resource bar, selection, chat, profiles, weather, day/night cycle.',
    route: '/world', techStack: ['Three.js', 'Vite', 'WebSocket', 'TypeScript'], dataFiles: ['openclaw-world/'],
    apiRoutes: ['/api/agents/world-reset'],
    features: [
      { name: '3D agent characters', description: '7 character types: humanoid, robot, mech, cat, ghost, orb, tree', status: 'live' },
      { name: 'RTS-style buildings', description: 'Kenney GLB models for departments (HQ, Medical, Legal, etc.)', status: 'live' },
      { name: 'Minimap', description: 'Real-time overhead map with agent positions', status: 'live' },
      { name: 'Resource bar', description: 'HUD showing agent counts, budget, API calls', status: 'live' },
      { name: 'Agent selection & profiles', description: 'Click agents to view profile panel with stats', status: 'live' },
      { name: 'Chat log overlay', description: 'In-world chat messages between agents', status: 'live' },
      { name: 'Live weather system', description: 'Real weather from zip code 34638 (Land O\' Lakes)', status: 'live' },
      { name: 'Day/night cycle', description: 'Dynamic lighting based on time of day', status: 'live' },
      { name: 'Ocean environment', description: 'Animated water surrounding the island', status: 'live' },
      { name: 'Lobster NPCs', description: 'Animated ambient creatures', status: 'live' },
      { name: 'Viewport controls', description: 'Alt+Left mouse to pan, scroll to zoom, click to select', status: 'live' },
      { name: 'WebSocket real-time sync', description: 'Live agent position updates via port 18800', status: 'live' },
    ],
  },
  {
    id: 'agents', name: 'Agent System', icon: '🤖',
    description: '25 AI agents across 7 model families with tier-based hierarchy, personality traits, cross-project memory, and dispatch system.',
    route: '(sidebar + profiles)', techStack: ['OpenClaw', 'Multi-provider'], dataFiles: ['data/agents.json', 'data/agent-sessions.json', 'data/agent-usage.json'],
    apiRoutes: ['/api/agents', '/api/agents/usage', '/api/dispatch'],
    features: [
      { name: '25 agents', description: 'Kevin, Groot, Jimmy T, CEO, Dr. Al, Dirty Bird, Brain, Sentinel, + 17 more', status: 'live' },
      { name: '7 model families', description: 'Anthropic, xAI, OpenRouter (MiniMax/Gemini/Grok), NVIDIA Kimi, Local (LM Studio/Ollama)', status: 'live' },
      { name: '7-tier hierarchy', description: 'Owner(T0) → Executive(T1) → VP(T2) → Director(T3) → SrMgr(T4) → Manager(T5) → Frontline(T6)', status: 'live' },
      { name: 'Personality traits', description: 'Each agent has unique personality scores influencing behavior', status: 'live' },
      { name: 'Cross-project memory', description: 'Agents remember conversations from all projects and direct chats', status: 'live' },
      { name: 'Agent dispatch', description: 'Bridge MC agent profiles to real OpenClaw sessions', status: 'live' },
      { name: 'Brain agent (12 moods)', description: 'Chief Intelligence Officer with mood-based personality states', status: 'live' },
      { name: 'API usage tracking', description: 'Per-agent token count, cost, model breakdown with date range filter', status: 'live' },
      { name: 'Org chart', description: 'Visual organization hierarchy', status: 'live' },
      { name: 'Agent profiles', description: 'Full profile with overview, personality (SOUL.md), stats (usage/cost/model breakdown), activity (task log), brain dump tabs', status: 'live' },
      { name: 'Per-agent workspace', description: 'Each agent has SOUL.md, IDENTITY.md, MEMORY.md, USER.md, daily memory logs', status: 'live' },
    ],
  },
  {
    id: 'apps', name: 'Apps', icon: '📱',
    description: 'Collection of built-in applications: PrePrompt (11 tabs), Universal Bookmarks, Get-to-Know-You, Media Vault, MaxTarget Marketing, Podcast Hub.',
    route: '/apps', techStack: ['React', 'Various APIs'], dataFiles: ['data/apps/*/'],
    apiRoutes: ['/api/apps/*'],
    features: [
      { name: 'PrePrompt (11 tabs)', description: 'AI control & visibility system with 11 functional tabs', status: 'live' },
      { name: 'Universal Bookmarks', description: 'Bookmark manager with API import and dead link checker', status: 'live' },
      { name: 'Get-to-Know-You', description: '70+ questions for building user profile', status: 'live' },
      { name: 'Media Vault', description: 'Links and images saver with categorization', status: 'live' },
      { name: 'MaxTarget Marketing', description: '17-module marketing dashboard with Andy\'s brand colors', status: 'live' },
      { name: 'Podcast Hub', description: '8 modules, 15 AI tools for podcast production', status: 'live' },
      { name: 'ChatGPT Data Import', description: 'Import and browse ChatGPT conversation history', status: 'live' },
    ],
  },
  {
    id: 'games', name: 'Games', icon: '🎮',
    description: '8 built-in games spanning trivia, simulation, RPG, strategy, and education.',
    route: '/games', techStack: ['React', 'TypeScript'], dataFiles: ['data/games/*/'],
    apiRoutes: [],
    features: [
      { name: 'Wrestling Trivia', description: 'Solo + multiplayer wrestling trivia with championship belt scoring', status: 'live' },
      { name: 'Stock Market Tycoon', description: 'Stock market simulation game', status: 'live' },
      { name: 'AI Dungeon Master', description: 'AI-powered RPG adventure', status: 'live' },
      { name: 'Cyber Heist', description: 'Hacking-themed puzzle game', status: 'live' },
      { name: 'Debate Arena', description: 'AI-judged debate competition', status: 'live' },
      { name: 'Invoice Manager', description: 'Business simulation app', status: 'live' },
      { name: 'Pitch Deck Builder', description: 'Startup pitch deck creator', status: 'live' },
      { name: 'Course Builder', description: 'Online course creation tool', status: 'live' },
      { name: 'Habit Forge', description: 'Habit tracking and building', status: 'live' },
    ],
  },
  {
    id: 'analytics', name: 'Analytics', icon: '📊',
    description: 'System-wide analytics dashboard with task breakdown, agent utilization, project progress, activity timeline, and cost tracking.',
    route: '/analytics', techStack: ['React', 'Chart visualization'], dataFiles: ['data/*.json'],
    apiRoutes: ['/api/analytics', '/api/activity'],
    features: [
      { name: 'Task breakdown by status', description: 'Visual distribution of tasks across columns', status: 'live' },
      { name: 'Agent utilization', description: 'Activity levels per agent', status: 'live' },
      { name: 'Project progress tracking', description: 'Phase completion across all projects', status: 'live' },
      { name: 'Activity timeline', description: 'Chronological feed of all system events', status: 'live' },
      { name: 'Cost estimation', description: 'API usage cost tracking and projection', status: 'live' },
      { name: 'Per-project stats tab', description: 'Detailed statistics within project profiles', status: 'live' },
    ],
  },
  {
    id: 'settings', name: 'Settings', icon: '⚙️',
    description: 'System configuration: API keys (15+), model selection, theme picker, auth management, and page settings.',
    route: '/settings', techStack: ['React', 'bcrypt', 'iron-session'], dataFiles: ['data/settings.json', 'data/auth.json'],
    apiRoutes: ['/api/settings', '/api/auth/*'],
    features: [
      { name: '15+ API key management', description: 'Anthropic, xAI, OpenRouter, Coinbase, Govee, Oura, NVIDIA, ElevenLabs + more', status: 'live' },
      { name: 'Model selection', description: 'Choose from 15+ models across 5 providers', status: 'live' },
      { name: 'Management links', description: '🔗 buttons next to every API key linking to provider management pages', status: 'live' },
      { name: '7 themes', description: 'Dark, Light, Midnight, Neon, Cream, Tropical, Corporate — persists across devices via server-side storage', status: 'live' },
      { name: 'Auth management', description: 'Password change, bcrypt hashing, session management', status: 'live' },
      { name: 'Rate limiting', description: 'API rate limit configuration', status: 'live' },
      { name: 'Port configuration', description: 'Change MC server port from settings', status: 'live' },
    ],
  },
  {
    id: 'security', name: 'Security & Auth', icon: '🔒',
    description: 'Full security layer with bcrypt authentication, iron-session cookies, rate limiting, CSRF protection, and Cloudflare tunnel for public access.',
    route: '(middleware)', techStack: ['bcrypt', 'iron-session', 'Cloudflare'], dataFiles: ['data/auth.json'],
    apiRoutes: ['/api/auth/login', '/api/auth/logout', '/api/auth/setup', '/api/auth/status'],
    features: [
      { name: 'bcrypt password hashing', description: 'Industry-standard password storage', status: 'live' },
      { name: 'Session-based auth', description: 'iron-session encrypted cookies', status: 'live' },
      { name: 'Rate limiting', description: 'Configurable request throttling', status: 'live' },
      { name: 'Cloudflare tunnel', description: 'Public access via dashboard.denominatorx.com', status: 'live' },
      { name: 'Terms of Service', description: 'Legal TOS page at /terms', status: 'live' },
      { name: 'Privacy Policy', description: 'Privacy policy page at /privacy', status: 'live' },
      { name: 'Login/Setup flow', description: 'First-time setup + login pages', status: 'live' },
    ],
  },
  {
    id: 'infra', name: 'Infrastructure', icon: '🏗️',
    description: 'Next.js 14 application with production builds, multi-port architecture, Cloudflare DNS, and mc-server.js process management.',
    route: '(system)', techStack: ['Next.js 14.2', 'React 18', 'TypeScript', 'Tailwind CSS', 'Node.js'],
    dataFiles: ['mc-server.js', 'package.json', 'next.config.js'],
    apiRoutes: ['/api/system', '/api/server/restart'],
    features: [
      { name: 'Production mode (next start)', description: 'Optimized builds with static prerendering', status: 'live' },
      { name: 'mc-server.js manager', description: 'Process manager with hot restart via signal', status: 'live' },
      { name: 'Multi-port architecture', description: 'MC:3001, World:3002/18800, AgentCraft:2468, Karate:3003', status: 'live' },
      { name: 'Cloudflare DNS', description: '6 subdomain routes via tunnel d329...', status: 'live' },
      { name: 'StatusBar', description: 'Live RAM, disk, weather, agent count, task count, uptime', status: 'live' },
      { name: 'Responsive layout', description: '3-column collapsible layout with mobile support', status: 'live' },
      { name: 'LaunchAgent auto-start', description: 'com.denominatorx.mission-control starts MC on macOS boot', status: 'live' },
      { name: 'Agent World auto-registration', description: 'MC auto-registers all agents in 3D world on startup', status: 'live' },
      { name: 'Hybrid persistence', description: 'SQLite for agents/projects/settings, JSON files for teams/usage/chat/config', status: 'live' },
    ],
  },
  {
    id: 'teams', name: 'Project Teams', icon: '👥',
    description: 'Team template management — build reusable project teams with agent assignments, role configs, model overrides, and per-agent rules.',
    route: '/teams', techStack: ['React', 'Tailwind CSS', 'TypeScript'], dataFiles: ['data/teams.json'],
    apiRoutes: ['/api/teams'],
    features: [
      { name: 'Team creation & management', description: 'Create, edit, clone, and delete team templates', status: 'live' },
      { name: 'Role management UI', description: 'Add/edit/remove roles with full configuration panel per team', status: 'live' },
      { name: 'Agent picker', description: 'Dropdown of all MC agents with name, title, tier for role assignment', status: 'live' },
      { name: 'Per-role model override', description: 'Set a specific AI model for each agent within a project context', status: 'live' },
      { name: 'Per-role rules/notes', description: 'Freeform instructions each agent must follow in the team', status: 'live' },
      { name: 'Tier assignment', description: 'Executive/Senior/Mid/Junior tier badges per role', status: 'live' },
      { name: 'Responsibilities tags', description: 'Add/remove chip-style responsibility tags per role', status: 'live' },
      { name: '3 default templates', description: 'Software Dev (6 roles), Research & Analysis (4), Content Creation (4)', status: 'live' },
      { name: 'Apply team to project', description: 'Import a pre-built team template into any project', status: 'live' },
      { name: 'Clone teams', description: 'Duplicate existing teams as starting point for new configs', status: 'live' },
    ],
  },
  {
    id: 'context-health', name: 'Context Health Monitor', icon: '🧠',
    description: 'Real-time monitoring of all OpenClaw sessions — context window usage, token counts, session compaction, and friendly naming.',
    route: '(dashboard widget)', techStack: ['React', 'OpenClaw CLI'], dataFiles: ['data/context-health-cache.json'],
    apiRoutes: ['/api/context-health'],
    features: [
      { name: 'Session grid with health bars', description: 'Visual context usage bars with green/yellow/red status per session', status: 'live' },
      { name: 'Discord channel names', description: 'Maps channel IDs to friendly names like "Discord #mission-control"', status: 'live' },
      { name: 'Sub-agent name resolution', description: 'Cross-references sub-agent UUIDs against MC agent database for real names', status: 'live' },
      { name: 'Session compaction', description: 'One-click compact button — summarizes, flushes memory, resets session', status: 'live' },
      { name: 'Session deletion', description: 'Delete critical (90%+) sessions with confirmation', status: 'live' },
      { name: 'Auto-refresh', description: '60-second polling with manual refresh button', status: 'live' },
      { name: 'Filter by severity', description: 'All / Warning+ / Critical filters', status: 'live' },
      { name: 'Summary badges', description: 'Header shows healthy/warning/critical session counts', status: 'live' },
      { name: 'Collapsible panel', description: 'Click header to collapse/expand the widget', status: 'live' },
    ],
  },
];

// ══════════════════════════════════════════════════════════════
// COMPONENT
// ══════════════════════════════════════════════════════════════

export default function FeaturesPanel() {
  const [expandedPage, setExpandedPage] = useState<string | null>(null);
  const [ideas, setIdeas] = useState<Record<string, string[]>>({});
  const [generating, setGenerating] = useState<string | null>(null);
  const [tab, setTab] = useState<'features' | 'config' | 'stats' | 'tests'>('features');
  
  // Version & Test System State
  const [version, setVersion] = useState('1.0.0');
  const [testFilter, setTestFilter] = useState<'all' | 'pending' | 'validated' | 'broken'>('all');
  const [trackedFeatures, setTrackedFeatures] = useState<TrackedFeature[]>([]);
  const [editingFailure, setEditingFailure] = useState<string | null>(null);
  const [failureReason, setFailureReason] = useState('');
  const [fixingAll, setFixingAll] = useState(false);
  const [addingToTestPlan, setAddingToTestPlan] = useState<Set<string>>(new Set());
  const [addedConfirmation, setAddedConfirmation] = useState<Set<string>>(new Set());
  const [scanning, setScanning] = useState(false);
  const [showNewFeatureModal, setShowNewFeatureModal] = useState(false);
  const [newFeatures, setNewFeatures] = useState<NewFeatureItem[]>([]);
  const [versionLoading, setVersionLoading] = useState(false);

  // Load version and tracked features on mount
  useEffect(() => {
    fetch('/api/version')
      .then(r => r.json())
      .then(d => setVersion(d.version || '1.0.0'))
      .catch(() => {});
    
    fetch('/api/features')
      .then(r => r.json())
      .then(d => setTrackedFeatures(d.features || []))
      .catch(() => {});
  }, []);

  const totalFeatures = MC_PAGES.reduce((s, p) => s + p.features.length, 0);
  const liveFeatures = MC_PAGES.reduce((s, p) => s + p.features.filter(f => f.status === 'live').length, 0);
  const totalApiRoutes = MC_PAGES.reduce((s, p) => s + p.apiRoutes.length, 0);
  const totalDataFiles = MC_PAGES.reduce((s, p) => s + p.dataFiles.length, 0);

  const generateIdeas = async (pageId: string) => {
    setGenerating(pageId);
    const page = MC_PAGES.find(p => p.id === pageId);
    if (!page) return;

    try {
      const r = await fetch('/api/chat/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: 'sentinel',
          message: `Generate exactly 5 new feature ideas for the "${page.name}" page in Mission Control. Current features: ${page.features.map(f => f.name).join(', ')}. Return ONLY a JSON array of 5 strings, each being a concise feature name + brief description. Example: ["Feature Name — brief description"]. No other text.`,
        }),
      });
      const data = await r.json();
      const reply = data.reply || '';
      // Try to parse JSON from reply
      const match = reply.match(/\[[\s\S]*\]/);
      if (match) {
        const parsed = JSON.parse(match[0]);
        setIdeas(prev => ({ ...prev, [pageId]: parsed.slice(0, 5) }));
      } else {
        // Fallback: split by newlines
        const lines = reply.split('\n').filter((l: string) => l.trim().length > 10).slice(0, 5);
        setIdeas(prev => ({ ...prev, [pageId]: lines }));
      }
    } catch {
      setIdeas(prev => ({ ...prev, [pageId]: ['Error generating ideas — try again'] }));
    }
    setGenerating(null);
  };

  const addIdeaAsProject = async (pageId: string, idea: string, index: number) => {
    const title = idea.replace(/^[\d.)\-–—]+\s*/, '').replace(/^"/, '').replace(/"$/, '').slice(0, 80);
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: `[${pageId}] ${title}`, column: 'inbox', priority: 'medium' }),
    });
    // Replace that idea with a new placeholder
    setIdeas(prev => {
      const list = [...(prev[pageId] || [])];
      list[index] = '✅ Added to Kanban — generating replacement...';
      return { ...prev, [pageId]: list };
    });
    // Generate a replacement idea
    try {
      const r = await fetch('/api/chat/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: 'sentinel',
          message: `Generate exactly 1 new feature idea for the "${pageId}" page in Mission Control. NOT any of these: ${(ideas[pageId] || []).join(', ')}. Return ONLY the idea as a single string like: "Feature Name — brief description". No JSON, no quotes, just the text.`,
        }),
      });
      const data = await r.json();
      const newIdea = (data.reply || '').trim().replace(/^["']|["']$/g, '');
      setIdeas(prev => {
        const list = [...(prev[pageId] || [])];
        list[index] = newIdea || 'New idea pending...';
        return { ...prev, [pageId]: list };
      });
    } catch {}
  };

  const removeIdea = (pageId: string, index: number) => {
    setIdeas(prev => {
      const list = [...(prev[pageId] || [])];
      list.splice(index, 1);
      return { ...prev, [pageId]: list };
    });
  };

  // ══════════════════════════════════════════════════════════════
  // VERSION & TEST SYSTEM FUNCTIONS
  // ══════════════════════════════════════════════════════════════

  const scanForNewFeatures = async () => {
    setScanning(true);
    try {
      // Get current tracked features
      const r = await fetch('/api/features');
      const data = await r.json();
      const tracked = data.features || [];
      
      // Compare with MC_PAGES
      const foundNew: NewFeatureItem[] = [];
      const foundChanged: NewFeatureItem[] = [];
      
      for (const page of MC_PAGES) {
        for (const feature of page.features) {
          const existing = tracked.find((f: TrackedFeature) => f.pageId === page.id && f.name === feature.name);
          if (!existing) {
            // New feature
            foundNew.push({
              pageId: page.id,
              pageName: page.name,
              name: feature.name,
              description: feature.description,
              status: feature.status,
            });
          } else if (existing.description !== feature.description || existing.status !== feature.status) {
            // Changed feature
            foundChanged.push({
              pageId: page.id,
              pageName: page.name,
              name: feature.name,
              description: feature.description,
              status: feature.status,
            });
          }
        }
      }
      
      const allNew = [...foundNew, ...foundChanged];
      if (allNew.length > 0) {
        setNewFeatures(allNew);
        setShowNewFeatureModal(true);
      } else {
        alert('No new features found. All features are already tracked.');
      }
    } catch (e) {
      console.error('Scan error:', e);
      alert('Error scanning for new features');
    }
    setScanning(false);
  };

  const saveNewFeatures = async (updateType: 'major' | 'minor' | 'patch') => {
    try {
      // Save features first
      await fetch('/api/features', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'saveScan',
          features: newFeatures,
        }),
      });
      
      // Then update version
      setVersionLoading(true);
      const r = await fetch('/api/version', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: updateType,
          notes: `Added/updated ${newFeatures.length} feature(s)`,
        }),
      });
      const data = await r.json();
      setVersion(data.version);
      
      // Reload tracked features
      const fr = await fetch('/api/features');
      const fdata = await fr.json();
      setTrackedFeatures(fdata.features || []);
      
      setShowNewFeatureModal(false);
      setNewFeatures([]);
    } catch (e) {
      console.error('Save error:', e);
      alert('Error saving features');
    }
    setVersionLoading(false);
  };

  const updateTestStatus = async (featureId: string, newStatus: 'pending' | 'validated' | 'broken') => {
    try {
      const r = await fetch('/api/features', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'updateTestStatus',
          featureId,
          testStatus: newStatus,
        }),
      });
      const data = await r.json();
      if (data.success) {
        setTrackedFeatures(prev => 
          prev.map(f => f.id === featureId ? { ...f, testStatus: newStatus, lastTested: new Date().toISOString() } : f)
        );
      }
    } catch (e) {
      console.error('Update test status error:', e);
    }
  };

  const saveFailureReason = async (featureId: string) => {
    try {
      await fetch('/api/features', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'updateFailureReason', featureId, failureReason }),
      });
      setTrackedFeatures(prev => prev.map(f => f.id === featureId ? { ...f, failureReason } : f));
      setEditingFailure(null);
    } catch (e) { console.error(e); }
  };

  const fixAllBroken = async () => {
    setFixingAll(true);
    const broken = trackedFeatures.filter(f => f.testStatus === 'broken');
    for (const f of broken) {
      await updateTestStatus(f.id, 'pending');
    }
    setFixingAll(false);
  };

  const addToTestPlan = async (feature: TrackedFeature) => {
    setAddingToTestPlan(prev => new Set(prev).add(feature.id));
    try {
      const res = await fetch('/api/reports/add-to-test-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          featureName: feature.name,
          pageId: feature.pageId,
          testStatus: feature.testStatus,
        }),
      });
      if (res.ok) {
        setAddedConfirmation(prev => new Set(prev).add(feature.id));
        setTimeout(() => {
          setAddedConfirmation(prev => {
            const next = new Set(prev);
            next.delete(feature.id);
            return next;
          });
        }, 2000);
      }
    } catch (e) {
      console.error('Add to test plan error:', e);
    }
    setAddingToTestPlan(prev => {
      const next = new Set(prev);
      next.delete(feature.id);
      return next;
    });
  };

  const addAllUntested = async () => {
    const untested = trackedFeatures.filter(f => f.testStatus === 'pending');
    for (const f of untested) {
      await addToTestPlan(f);
    }
  };

  const filteredTrackedFeatures = trackedFeatures.filter(f => 
    testFilter === 'all' || f.testStatus === testFilter
  );

  return (
    <div className="space-y-3">
      {/* Header with version and scan button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-mc-surface border border-mc-border rounded-lg px-4 py-2">
            <div className="text-[10px] text-mc-muted uppercase tracking-wider">Version</div>
            <div className="text-xl font-bold text-mc-accent font-mono">v{version}</div>
          </div>
          <button 
            onClick={scanForNewFeatures} 
            disabled={scanning}
            className="px-4 py-2 bg-mc-accent/20 hover:bg-mc-accent/30 text-mc-accent rounded-lg text-sm disabled:opacity-50 transition-colors"
          >
            {scanning ? '⏳ Scanning...' : '🔍 Check for New Features'}
          </button>
        </div>
        <div className="text-xs text-mc-muted">
          {trackedFeatures.length} tracked • {trackedFeatures.filter(f => f.testStatus === 'pending').length} pending
        </div>
      </div>

      {/* Header stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-mc-accent">{MC_PAGES.length}</div>
          <div className="text-[10px] text-mc-muted">Pages / Systems</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-green-400">{totalFeatures}</div>
          <div className="text-[10px] text-mc-muted">Total Features</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-blue-400">{liveFeatures}</div>
          <div className="text-[10px] text-mc-muted">Live Features</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-purple-400">{totalApiRoutes}</div>
          <div className="text-[10px] text-mc-muted">API Routes</div>
        </div>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-orange-400">{totalDataFiles}</div>
          <div className="text-[10px] text-mc-muted">Data Files</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-mc-border pb-1">
        {(['features', 'tests', 'config', 'stats'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-3 py-1.5 text-xs rounded-t capitalize ${tab === t ? 'bg-mc-accent/20 text-mc-accent border-b-2 border-mc-accent' : 'text-mc-muted hover:text-mc-text'}`}>
            {t === 'features' ? '🧩 Features' : t === 'tests' ? '🧪 Test Status' : t === 'config' ? '⚙️ Configuration' : '📊 Statistics'}
          </button>
        ))}
      </div>

      {/* FEATURES TAB */}
      {tab === 'features' && (
        <div className="space-y-2">
          {MC_PAGES.map(page => (
            <div key={page.id} className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
              {/* Page header */}
              <button onClick={() => setExpandedPage(expandedPage === page.id ? null : page.id)}
                className="w-full px-4 py-3 flex items-center gap-3 hover:bg-mc-bg/50 transition-colors text-left">
                <span className="text-xl">{page.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{page.name}</div>
                  <div className="text-[10px] text-mc-muted truncate">{page.description}</div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-mc-bg text-mc-muted">{page.features.length} features</span>
                  <span className="text-mc-muted">{expandedPage === page.id ? '▼' : '▶'}</span>
                </div>
              </button>

              {/* Expanded details */}
              {expandedPage === page.id && (
                <div className="border-t border-mc-border">
                  {/* Tech details */}
                  <div className="px-4 py-2 bg-mc-bg/30 grid grid-cols-1 md:grid-cols-3 gap-4 text-[10px]">
                    <div>
                      <span className="text-mc-muted uppercase font-semibold">Tech Stack</span>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {page.techStack.map(t => (
                          <span key={t} className="px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400">{t}</span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-mc-muted uppercase font-semibold">Data Files</span>
                      <div className="mt-1 font-mono text-mc-muted">{page.dataFiles.join(', ')}</div>
                    </div>
                    <div>
                      <span className="text-mc-muted uppercase font-semibold">API Routes</span>
                      <div className="mt-1 font-mono text-mc-muted">{page.apiRoutes.length > 0 ? page.apiRoutes.join(', ') : 'None'}</div>
                    </div>
                  </div>

                  {/* Feature list */}
                  <div className="px-4 py-2">
                    <div className="overflow-x-auto"><table className="w-full text-xs min-w-[500px]">
                      <thead>
                        <tr className="text-mc-muted text-[10px]">
                          <th className="text-left py-1 w-8">#</th>
                          <th className="text-left py-1">Feature</th>
                          <th className="text-left py-1 hidden md:table-cell">Description</th>
                          <th className="text-center py-1 w-16">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {page.features.map((f, i) => (
                          <tr key={i} className="border-t border-mc-border/30">
                            <td className="py-1.5 text-mc-muted">{i + 1}</td>
                            <td className="py-1.5 font-medium">{f.name}</td>
                            <td className="py-1.5 text-mc-muted hidden md:table-cell">{f.description}</td>
                            <td className="py-1.5 text-center">
                              <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                                f.status === 'live' ? 'bg-green-500/20 text-green-400' :
                                f.status === 'beta' ? 'bg-yellow-500/20 text-yellow-400' :
                                'bg-blue-500/20 text-blue-400'
                              }`}>{f.status}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table></div>
                  </div>

                  {/* AI Ideas Section */}
                  <div className="px-4 py-3 border-t border-mc-border bg-mc-accent/5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-mc-accent">💡 Suggested New Features</span>
                      <button onClick={() => generateIdeas(page.id)} disabled={generating === page.id}
                        className="px-2 py-1 text-[10px] bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 disabled:opacity-50">
                        {generating === page.id ? '⏳ Generating...' : '🔄 Generate 5 Ideas'}
                      </button>
                    </div>
                    {(ideas[page.id] || []).length > 0 ? (
                      <div className="space-y-1">
                        {(ideas[page.id] || []).map((idea, i) => (
                          <div key={i} className="flex items-center gap-2 bg-mc-bg rounded px-3 py-1.5 text-xs">
                            <span className="flex-1">{idea}</span>
                            <button onClick={() => addIdeaAsProject(page.id, idea, i)}
                              className="text-green-400 hover:text-green-300 text-sm flex-shrink-0" title="Add to Kanban">➕</button>
                            <button onClick={() => removeIdea(page.id, i)}
                              className="text-red-400 hover:text-red-300 text-sm flex-shrink-0" title="Remove">✕</button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-[10px] text-mc-muted">Click "Generate 5 Ideas" to get AI-powered feature suggestions for this page.</div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* CONFIG TAB */}
      {tab === 'config' && (
        <div className="space-y-3">
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-bold">🏗️ Architecture</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div><span className="text-mc-muted">Framework:</span> <span className="font-mono">Next.js 14.2.29</span></div>
              <div><span className="text-mc-muted">Runtime:</span> <span className="font-mono">Node.js v25.5.0</span></div>
              <div><span className="text-mc-muted">Styling:</span> <span className="font-mono">Tailwind CSS</span></div>
              <div><span className="text-mc-muted">Language:</span> <span className="font-mono">TypeScript</span></div>
              <div><span className="text-mc-muted">Auth:</span> <span className="font-mono">bcrypt + iron-session</span></div>
              <div><span className="text-mc-muted">Data:</span> <span className="font-mono">JSON file persistence</span></div>
              <div><span className="text-mc-muted">3D Engine:</span> <span className="font-mono">Three.js (Agent World)</span></div>
              <div><span className="text-mc-muted">AI Backbone:</span> <span className="font-mono">OpenClaw (multi-provider)</span></div>
            </div>
          </div>

          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-bold">🌐 Port Map</h3>
            <div className="overflow-x-auto"><table className="w-full text-xs min-w-[500px]">
              <thead><tr className="text-mc-muted text-[10px]"><th className="text-left py-1">Port</th><th className="text-left py-1">Service</th><th className="text-left py-1">Public URL</th></tr></thead>
              <tbody>
                {[
                  ['3001', 'Mission Control (production)', 'app.denominatorx.com'],
                  ['3002', 'Agent World (Vite frontend)', 'world.denominatorx.com'],
                  ['3003', 'Pinner Karate website', '—'],
                  ['18800', 'Agent World (WebSocket/IPC)', 'world-ws.denominatorx.com'],
                  ['18789', 'OpenClaw Gateway', '—'],
                  ['2468', 'AgentCraft', 'agentcraft.denominatorx.com'],
                  ['1234', 'LM Studio (when active)', '—'],
                ].map(([port, service, url]) => (
                  <tr key={port} className="border-t border-mc-border/30">
                    <td className="py-1.5 font-mono text-mc-accent">{port}</td>
                    <td className="py-1.5">{service}</td>
                    <td className="py-1.5 text-mc-muted">{url}</td>
                  </tr>
                ))}
              </tbody>
            </table></div>
          </div>

          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-bold">🤖 AI Model Routing</h3>
            <div className="overflow-x-auto"><table className="w-full text-xs min-w-[500px]">
              <thead><tr className="text-mc-muted text-[10px]"><th className="text-left py-1">Provider</th><th className="text-left py-1">Models</th><th className="text-left py-1">Route</th><th className="text-left py-1">Cost</th></tr></thead>
              <tbody>
                {[
                  ['Anthropic', 'Opus 4.6, Sonnet 4, Haiku 4.5', 'Direct API', '$0.80-$75/M'],
                  ['xAI', 'Grok 4, Grok 4.1 Fast', 'Direct + OpenRouter', '$0.20-$15/M'],
                  ['MiniMax', 'M2.5 (230B MoE)', 'OpenRouter', '$0.30-$1.20/M'],
                  ['Google', 'Gemini 2.5 Pro, 3 Pro', 'OpenRouter', '$1.25-$12/M'],
                  ['NVIDIA', 'Kimi K2, K2.5', 'NIM API (free)', 'Free (5K credits)'],
                  ['Local', 'Gemma-12b, Gemma-4b, DeepSeek R1', 'LM Studio / Ollama', 'Free'],
                ].map(([provider, models, route, cost]) => (
                  <tr key={provider} className="border-t border-mc-border/30">
                    <td className="py-1.5 font-medium">{provider}</td>
                    <td className="py-1.5 text-mc-muted">{models}</td>
                    <td className="py-1.5">{route}</td>
                    <td className="py-1.5 font-mono text-mc-accent">{cost}</td>
                  </tr>
                ))}
              </tbody>
            </table></div>
          </div>

          <div className="bg-mc-surface border border-mc-border rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-bold">🏢 Agent Tier System</h3>
            <div className="overflow-x-auto"><table className="w-full text-xs min-w-[500px]">
              <thead><tr className="text-mc-muted text-[10px]"><th className="text-left py-1">Tier</th><th className="text-left py-1">Level</th><th className="text-left py-1">Model</th><th className="text-left py-1">Agents</th></tr></thead>
              <tbody>
                {[
                  ['T0', 'Owner', '—', 'Kevin'],
                  ['T1', 'Executive', 'Opus 4.6', 'Groot, Jimmy T, CEO, Dr. Al, Dirty Bird, Brain'],
                  ['T2', 'VP', 'MiniMax M2.5 / Gemini / Grok 4', 'Swift, Pixel, Forge, Oracle, Viper, Archivist, Therapist, Sentinel'],
                  ['T3', 'Director', 'Grok 3 / MiniMax', 'Floof, Nova, Interrogator'],
                  ['T4', 'Sr. Manager', 'MiniMax M2.5', 'Scout, Spark, Atlas, Cipher'],
                  ['T5', 'Manager', 'Ollama 8B / Gemma 4B', 'Tank, Runner'],
                  ['T6', 'Frontline', 'Ministral 3B', 'Worker B'],
                ].map(([tier, level, model, agents]) => (
                  <tr key={tier} className="border-t border-mc-border/30">
                    <td className="py-1.5 font-mono font-bold text-mc-accent">{tier}</td>
                    <td className="py-1.5 font-medium">{level}</td>
                    <td className="py-1.5 text-mc-muted">{model}</td>
                    <td className="py-1.5">{agents}</td>
                  </tr>
                ))}
              </tbody>
            </table></div>
          </div>
        </div>
      )}

      

      {/* TESTS TAB */}
      {tab === 'tests' && (
        <div className="space-y-3">
          {/* Filter buttons */}
          <div className="flex gap-2">
            {(['all', 'pending', 'validated', 'broken'] as const).map(f => (
              <button
                key={f}
                onClick={() => setTestFilter(f)}
                className={`px-3 py-1.5 text-xs rounded-lg capitalize transition-colors ${
                  testFilter === f 
                    ? f === 'all' ? 'bg-mc-accent/20 text-mc-accent' 
                    : f === 'pending' ? 'bg-yellow-500/20 text-yellow-400'
                    : f === 'validated' ? 'bg-green-500/20 text-green-400'
                    : 'bg-red-500/20 text-red-400'
                    : 'bg-mc-bg text-mc-muted hover:text-mc-text'
                }`}
              >
                {f === 'all' ? 'All' : f === 'pending' ? 'Pending Testing' : f} 
                {f !== 'all' && (
                  <span className="ml-1">
                    ({trackedFeatures.filter(t => t.testStatus === f).length})
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Test status summary */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
              <div className="text-xl font-bold text-yellow-400">{trackedFeatures.filter(f => f.testStatus === 'pending').length}</div>
              <div className="text-[10px] text-mc-muted">Pending Testing</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
              <div className="text-xl font-bold text-green-400">{trackedFeatures.filter(f => f.testStatus === 'validated').length}</div>
              <div className="text-[10px] text-mc-muted">Validated</div>
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-3 text-center">
              <div className="text-xl font-bold text-red-400">{trackedFeatures.filter(f => f.testStatus === 'broken').length}</div>
              <div className="text-[10px] text-mc-muted">Broken</div>
            </div>
          </div>

          {/* Fix All Broken Button */}
          {trackedFeatures.filter(f => f.testStatus === 'broken').length > 0 && (
            <button
              onClick={fixAllBroken}
              disabled={fixingAll}
              className="w-full px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg text-sm flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {fixingAll ? '🔧 Fixing...' : '🔧 Run Fix for All Broken Features'}
            </button>
          )}

          {/* Add All Untested to Test Plan */}
          {trackedFeatures.filter(f => f.testStatus === 'pending').length > 0 && (
            <button
              onClick={addAllUntested}
              className="w-full px-4 py-2 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 rounded-lg text-sm flex items-center justify-center gap-2"
            >
              📋 Add All Untested to Test Plan ({trackedFeatures.filter(f => f.testStatus === 'pending').length})
            </button>
          )}

          {/* Feature test list */}
          <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
            {filteredTrackedFeatures.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-mc-muted text-[10px] border-b border-mc-border">
                      <th className="text-left py-2 px-3">Feature</th>
                      <th className="text-left py-2 px-3 hidden md:table-cell">Page</th>
                      <th className="text-center py-2 px-3">Status</th>
                      <th className="text-center py-2 px-3">Test Status</th>
                      <th className="text-center py-2 px-3">Test Plan</th>
                      <th className="text-right py-2 px-3">Last Tested</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTrackedFeatures.map(f => (
                      <tr key={f.id} className="border-b border-mc-border/30 hover:bg-mc-bg/30">
                        <td className="py-2 px-3">
                          <div className="font-medium">{f.name}</div>
                          <div className="text-[10px] text-mc-muted truncate max-w-[200px]">{f.description}</div>
                        </td>
                        <td className="py-2 px-3 hidden md:table-cell text-mc-muted">{f.pageId}</td>
                        <td className="py-2 px-3 text-center">
                          <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                            f.status === 'live' ? 'bg-green-500/20 text-green-400' :
                            f.status === 'beta' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>{f.status}</span>
                        </td>
                        <td className="py-2 px-3">
                          <div className="flex justify-center gap-1">
                            <button
                              onClick={() => updateTestStatus(f.id, 'pending')}
                              className={`px-2 py-0.5 rounded text-[10px] ${
                                f.testStatus === 'pending' ? 'bg-yellow-500/30 text-yellow-400' : 'bg-mc-bg text-mc-muted hover:text-yellow-400'
                              }`}
                              title="Mark as Pending"
                            >
                              ⏳
                            </button>
                            <button
                              onClick={() => updateTestStatus(f.id, 'validated')}
                              className={`px-2 py-0.5 rounded text-[10px] ${
                                f.testStatus === 'validated' ? 'bg-green-500/30 text-green-400' : 'bg-mc-bg text-mc-muted hover:text-green-400'
                              }`}
                              title="Mark as Validated"
                            >
                              ✅
                            </button>
                            <button
                              onClick={() => updateTestStatus(f.id, 'broken')}
                              className={`px-2 py-0.5 rounded text-[10px] ${
                                f.testStatus === 'broken' ? 'bg-red-500/30 text-red-400' : 'bg-mc-bg text-mc-muted hover:text-red-400'
                              }`}
                              title="Mark as Broken"
                            >
                              ❌
                            </button>
                          </div>
                          {f.testStatus === 'broken' && (
                            <div className="mt-1">
                              {editingFailure === f.id ? (
                                <div className="flex gap-1">
                                  <input
                                    value={failureReason}
                                    onChange={e => setFailureReason(e.target.value)}
                                    placeholder="Describe the failure..."
                                    className="flex-1 bg-mc-bg border border-mc-border rounded px-2 py-1 text-[10px]"
                                    autoFocus
                                  />
                                  <button onClick={() => saveFailureReason(f.id)} className="px-2 py-1 bg-mc-accent text-white rounded text-[10px]">Save</button>
                                  <button onClick={() => setEditingFailure(null)} className="px-2 py-1 bg-mc-bg text-mc-muted rounded text-[10px]">✕</button>
                                </div>
                              ) : (
                                <button onClick={() => { setEditingFailure(f.id); setFailureReason(f.failureReason || ''); }} className="text-[10px] text-red-400 hover:underline">
                                  {f.failureReason ? '📝 Edit reason' : '+ Add failure reason'}
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-2 px-3 text-center">
                          {addedConfirmation.has(f.id) ? (
                            <span className="text-green-400 text-xs">Added ✓</span>
                          ) : addingToTestPlan.has(f.id) ? (
                            <span className="text-mc-muted text-xs">⏳</span>
                          ) : (
                            <button
                              onClick={() => addToTestPlan(f)}
                              className="px-2 py-0.5 rounded text-[10px] bg-purple-500/20 text-purple-400 hover:bg-purple-500/30"
                              title="Add to Test Plan"
                            >
                              📋
                            </button>
                          )}
                        </td>
                        <td className="py-2 px-3 text-right text-mc-muted text-[10px]">
                          {f.lastTested ? new Date(f.lastTested).toLocaleDateString() : 'Never'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-8 text-center text-mc-muted text-sm">
                {testFilter === 'all' 
                  ? 'No features tracked yet. Click "Check for New Features" to start tracking.'
                  : `No features with test status "${testFilter}".`
                }
              </div>
            )}
          </div>
        </div>
      )}
{/* STATS TAB */}
      {tab === 'stats' && (
        <div className="space-y-3">
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-bold mb-3">📊 Feature Distribution by Page</h3>
            <div className="space-y-1.5">
              {MC_PAGES.sort((a, b) => b.features.length - a.features.length).map(page => {
                const pct = Math.round((page.features.length / totalFeatures) * 100);
                return (
                  <div key={page.id} className="flex items-center gap-2 text-xs">
                    <span className="w-6 text-center">{page.icon}</span>
                    <span className="w-36 truncate">{page.name}</span>
                    <div className="flex-1 h-4 bg-mc-bg rounded-full overflow-hidden">
                      <div className="h-full bg-mc-accent/40 rounded-full transition-all" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-12 text-right font-mono text-mc-muted">{page.features.length}</span>
                    <span className="w-10 text-right text-mc-muted">{pct}%</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold mb-2">Status Breakdown</h3>
              {['live', 'beta', 'planned'].map(status => {
                const count = MC_PAGES.reduce((s, p) => s + p.features.filter(f => f.status === status).length, 0);
                return (
                  <div key={status} className="flex items-center justify-between text-xs py-1">
                    <span className={`px-2 py-0.5 rounded-full capitalize ${
                      status === 'live' ? 'bg-green-500/20 text-green-400' :
                      status === 'beta' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-blue-500/20 text-blue-400'
                    }`}>{status}</span>
                    <span className="font-bold">{count}</span>
                  </div>
                );
              })}
            </div>
            <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
              <h3 className="text-sm font-bold mb-2">Tech Stack Summary</h3>
              {(() => {
                const techs: Record<string, number> = {};
                MC_PAGES.forEach(p => p.techStack.forEach(t => { techs[t] = (techs[t] || 0) + 1; }));
                return Object.entries(techs).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([tech, count]) => (
                  <div key={tech} className="flex items-center justify-between text-xs py-0.5">
                    <span className="text-mc-muted">{tech}</span>
                    <span className="font-mono">{count}x</span>
                  </div>
                ));
              })()}
            </div>
          </div>
        </div>
      )}

      {/* New Feature Modal */}
      {showNewFeatureModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-mc-surface border border-mc-border rounded-xl max-w-2xl w-full max-h-[80vh] overflow-hidden shadow-2xl">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-mc-border bg-mc-accent/10">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-mc-accent">🆕 New Features Detected</h2>
                  <p className="text-xs text-mc-muted">{newFeatures.length} feature(s) need to be tracked</p>
                </div>
                <button 
                  onClick={() => setShowNewFeatureModal(false)}
                  className="text-mc-muted hover:text-mc-text text-2xl leading-none"
                >
                  ×
                </button>
              </div>
            </div>

            {/* Modal Body - Feature List */}
            <div className="px-6 py-4 overflow-y-auto max-h-[50vh]">
              <div className="space-y-2">
                {newFeatures.map((f, i) => (
                  <div key={i} className="bg-mc-bg rounded-lg p-3 text-xs">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-mc-accent">{f.name}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        f.status === 'live' ? 'bg-green-500/20 text-green-400' :
                        f.status === 'beta' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>{f.status}</span>
                    </div>
                    <div className="text-mc-muted text-[10px]">
                      📁 {f.pageName}
                    </div>
                    <div className="text-mc-muted mt-1">{f.description}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Footer - Actions */}
            <div className="px-6 py-4 border-t border-mc-border bg-mc-bg/50">
              <div className="flex items-center justify-between">
                <div className="text-xs text-mc-muted">
                  Choose version bump type:
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => saveNewFeatures('patch')}
                    disabled={versionLoading}
                    className="px-4 py-2 bg-mc-bg hover:bg-mc-border text-mc-text rounded-lg text-sm disabled:opacity-50 transition-colors"
                  >
                    🔧 Patch (1.0.0 → 1.0.1)
                  </button>
                  <button
                    onClick={() => saveNewFeatures('minor')}
                    disabled={versionLoading}
                    className="px-4 py-2 bg-mc-accent/20 hover:bg-mc-accent/30 text-mc-accent rounded-lg text-sm disabled:opacity-50 transition-colors"
                  >
                    ✨ Minor (1.0.0 → 1.1.0)
                  </button>
                  <button
                    onClick={() => saveNewFeatures('major')}
                    disabled={versionLoading}
                    className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg text-sm disabled:opacity-50 transition-colors"
                  >
                    🚀 Major (1.0.0 → 2.0.0)
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}