'use client';
import { useState } from 'react';

interface Phase {
  id: string;
  name: string;
  description: string;
  requirements: string[];
  status: string;
  tasks: any[];
}

interface Project {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  assignee: string;
  tags: string[];
  goals: string[];
  phases: Phase[];
  activity: any[];
  created: string;
  updated: string;
}

const STATUS_COLORS: Record<string, string> = {
  'planning': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  'in-progress': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'review': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'complete': 'bg-green-500/20 text-green-400 border-green-500/30',
  'blocked': 'bg-red-500/20 text-red-400 border-red-500/30',
  'todo': 'bg-gray-500/20 text-gray-400 border-gray-500/30',
};

const PHASE_STATUSES = ['todo', 'in-progress', 'review', 'complete', 'blocked'];
const PROJECT_STATUSES = ['planning', 'in-progress', 'review', 'complete'];
const PRIORITIES = ['critical', 'high', 'medium', 'low'];

const ASSIGNEES = [
  'Kevin (Me)', 'Groot', 'Jimmy T', 'Dr. Al', 'Dirty Bird', 'CEO', 'Brain',
];

export default function ProjectDetail({ project, onUpdate, onClose }: {
  project: Project;
  onUpdate: (projectId: string, updates: Partial<Project>) => Promise<void>;
  onClose: () => void;
}) {
  const [activeTab, setActiveTab] = useState<'overview' | 'phases' | 'goals'>('overview');
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(project.title);
  const [description, setDescription] = useState(project.description);
  const [status, setStatus] = useState(project.status);
  const [priority, setPriority] = useState(project.priority);
  const [assignee, setAssignee] = useState(project.assignee);
  const [goals, setGoals] = useState(project.goals);
  const [newGoal, setNewGoal] = useState('');
  const [expandedPhase, setExpandedPhase] = useState<string | null>(null);
  const [addingPhase, setAddingPhase] = useState(false);
  const [newPhaseName, setNewPhaseName] = useState('');
  const [newPhaseDesc, setNewPhaseDesc] = useState('');
  const [executing, setExecuting] = useState(false);
  const [execResults, setExecResults] = useState<any>(null);

  const completedPhases = (project.phases || []).filter(p => p.status === 'complete').length;
  const totalPhases = (project.phases || []).length;
  const progressPct = totalPhases > 0 ? Math.round((completedPhases / totalPhases) * 100) : 0;

  const saveBasic = async () => {
    await onUpdate(project.id, { title, description, status, priority, assignee, goals });
    setEditing(false);
  };

  const updatePhaseStatus = async (phaseId: string, newStatus: string) => {
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update-phase', projectId: project.id, phaseId, updates: { status: newStatus }, updatedBy: 'Kevin' }),
    });
  };

  const addPhase = async () => {
    if (!newPhaseName.trim()) return;
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add-phase', projectId: project.id, name: newPhaseName, description: newPhaseDesc, updatedBy: 'Kevin' }),
    });
    setNewPhaseName('');
    setNewPhaseDesc('');
    setAddingPhase(false);
  };

  const removePhase = async (phaseId: string) => {
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'remove-phase', projectId: project.id, phaseId, updatedBy: 'Kevin' }),
    });
  };

  const executeWithTeam = async () => {
    const task = prompt('Enter task description for the team:');
    if (!task) return;
    setExecuting(true);
    setExecResults(null);
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'execute', id: project.id, task, spawnerId: 'ceo' }),
      });
      const data = await res.json();
      setExecResults(data);
    } catch (e: any) {
      setExecResults({ error: e.message });
    } finally {
      setExecuting(false);
    }
  };

  const tabs = [
    { id: 'overview' as const, label: '📋 Overview' },
    { id: 'phases' as const, label: `🔨 Phases (${completedPhases}/${totalPhases})` },
    { id: 'goals' as const, label: `🎯 Goals (${goals.length})` },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-3xl max-h-[95vh] md:max-h-[90vh] overflow-hidden flex flex-col mx-2" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="px-6 py-4 border-b border-mc-border">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              {editing ? (
                <input value={title} onChange={e => setTitle(e.target.value)}
                  className="text-xl font-bold bg-transparent text-mc-text focus:outline-none border-b border-mc-accent w-full" />
              ) : (
                <h2 className="text-xl font-bold">{project.title}</h2>
              )}
              <div className="flex items-center gap-2 mt-2">
                <span className={`text-[10px] px-2 py-0.5 rounded border ${STATUS_COLORS[project.status] || STATUS_COLORS.planning}`}>
                  {project.status.toUpperCase()}
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded border ${STATUS_COLORS[project.priority === 'high' ? 'in-progress' : project.priority === 'critical' ? 'blocked' : 'todo']}`}>
                  {project.priority.toUpperCase()}
                </span>
                <span className="text-xs text-mc-muted">→ {project.assignee}</span>
                {(project.tags || []).map(t => (
                  <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-mc-bg text-mc-muted">#{t}</span>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!editing && <button onClick={() => setEditing(true)} className="text-xs text-mc-muted hover:text-mc-accent">✏️ Edit</button>}
              {!editing && <button onClick={executeWithTeam} disabled={executing} className="text-xs px-2 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded ml-2">
                {executing ? '⏳ Running...' : '🚀 Run Team'}
              </button>}
              {editing && <button onClick={saveBasic} className="text-xs px-3 py-1 bg-mc-accent text-white rounded">Save</button>}
              <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl ml-2">✕</button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs text-mc-muted mb-1">
              <span>Progress</span>
              <span>{progressPct}%</span>
            </div>
            <div className="h-2 bg-mc-bg rounded-full overflow-hidden">
              <div className="h-full bg-mc-accent rounded-full transition-all" style={{ width: `${progressPct}%` }} />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-mc-border px-6">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`px-4 py-2.5 text-sm border-b-2 transition-colors ${activeTab === t.id ? 'border-mc-accent text-mc-accent font-medium' : 'border-transparent text-mc-muted hover:text-mc-text'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">

          {activeTab === 'overview' && (
            <div className="space-y-4">
              {execResults && (
                <div className="p-3 bg-mc-bg border border-mc-border rounded-lg">
                  <div className="text-xs font-medium text-mc-accent mb-2">🤖 Team Execution Results</div>
                  {execResults.error ? (
                    <div className="text-red-400 text-sm">{execResults.error}</div>
                  ) : (
                    <div className="text-sm space-y-2 max-h-40 overflow-y-auto">
                      {execResults.results && Object.entries(execResults.results).map(([agentId, result]: [string, any]) => (
                        <div key={agentId} className="text-xs">
                          <span className="text-purple-400 font-medium">{result.agentName || agentId}</span>
                          <span className="text-mc-muted"> ({result.role})</span>
                          <div className="text-mc-text mt-1 whitespace-pre-wrap">{result.result?.substring(0, 500)}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              {editing ? (
                <>
                  <div>
                    <label className="text-xs text-mc-muted block mb-1">Description</label>
                    <textarea value={description} onChange={e => setDescription(e.target.value)} rows={4}
                      className="w-full px-3 py-2 bg-mc-bg border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-y" />
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-mc-muted block mb-1">Status</label>
                      <select value={status} onChange={e => setStatus(e.target.value)}
                        className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-text focus:outline-none">
                        {PROJECT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-mc-muted block mb-1">Priority</label>
                      <select value={priority} onChange={e => setPriority(e.target.value)}
                        className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-text focus:outline-none">
                        {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-mc-muted block mb-1">Assignee</label>
                      <select value={assignee} onChange={e => setAssignee(e.target.value)}
                        className="w-full px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-text focus:outline-none">
                        {ASSIGNEES.map(a => <option key={a} value={a}>{a}</option>)}
                      </select>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <h3 className="text-sm font-semibold mb-2 text-mc-accent">Description</h3>
                    <p className="text-sm text-mc-text leading-relaxed">{project.description}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span className="text-mc-muted">Created:</span> <span>{new Date(project.created).toLocaleDateString()}</span></div>
                    <div><span className="text-mc-muted">Updated:</span> <span>{new Date(project.updated).toLocaleDateString()}</span></div>
                    <div><span className="text-mc-muted">Phases:</span> <span>{completedPhases}/{totalPhases} complete</span></div>
                  </div>
                </>
              )}
            </div>
          )}

          {activeTab === 'phases' && (
            <div className="space-y-3">
              {(project.phases || []).map((phase, idx) => {
                const isExpanded = expandedPhase === phase.id;
                return (
                  <div key={phase.id} className="bg-mc-bg rounded-lg border border-mc-border overflow-hidden">
                    <div className="flex items-center justify-between p-3 cursor-pointer" onClick={() => setExpandedPhase(isExpanded ? null : phase.id)}>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-mc-muted font-mono w-6">P{idx + 1}</span>
                        <span className="text-sm font-medium">{phase.name}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded border ${STATUS_COLORS[phase.status] || STATUS_COLORS.todo}`}>
                          {phase.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <select value={phase.status}
                          onClick={e => e.stopPropagation()}
                          onChange={e => { updatePhaseStatus(phase.id, e.target.value); }}
                          className="text-[10px] bg-mc-surface border border-mc-border rounded px-1.5 py-0.5 text-mc-text">
                          {PHASE_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <button onClick={e => { e.stopPropagation(); removePhase(phase.id); }}
                          className="text-xs text-mc-muted hover:text-red-400">✕</button>
                        <span className="text-mc-muted text-xs">{isExpanded ? '▼' : '▶'}</span>
                      </div>
                    </div>
                    {isExpanded && (
                      <div className="px-3 pb-3 pt-0 border-t border-mc-border/50">
                        <p className="text-xs text-mc-muted mt-2 mb-3">{phase.description}</p>
                        {(phase.requirements || []).length > 0 && (
                          <div>
                            <h4 className="text-[10px] font-semibold text-mc-accent uppercase tracking-wider mb-1.5">Requirements</h4>
                            <ul className="space-y-1">
                              {(phase.requirements || []).map((req, i) => (
                                <li key={i} className="flex items-start gap-2 text-xs text-mc-text">
                                  <span className="text-mc-muted mt-0.5">•</span>
                                  <span>{req}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Add phase */}
              {addingPhase ? (
                <div className="bg-mc-bg rounded-lg border border-mc-accent/30 p-3 space-y-2">
                  <input value={newPhaseName} onChange={e => setNewPhaseName(e.target.value)}
                    placeholder="Phase name..." className="w-full px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                  <textarea value={newPhaseDesc} onChange={e => setNewPhaseDesc(e.target.value)}
                    placeholder="Phase description..." rows={2}
                    className="w-full px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-y" />
                  <div className="flex gap-2">
                    <button onClick={addPhase} className="px-3 py-1 text-xs bg-mc-accent text-white rounded">Add Phase</button>
                    <button onClick={() => setAddingPhase(false)} className="px-3 py-1 text-xs text-mc-muted border border-mc-border rounded">Cancel</button>
                  </div>
                </div>
              ) : (
                <button onClick={() => setAddingPhase(true)}
                  className="w-full py-2 border border-dashed border-mc-border rounded-lg text-sm text-mc-muted hover:border-mc-accent hover:text-mc-accent transition-colors">
                  + Add Phase
                </button>
              )}
            </div>
          )}

          {activeTab === 'goals' && (
            <div className="space-y-3">
              {goals.map((goal, i) => (
                <div key={i} className="flex items-start gap-3 bg-mc-bg rounded-lg border border-mc-border p-3">
                  <span className="text-mc-accent mt-0.5">🎯</span>
                  {editing ? (
                    <div className="flex-1 flex items-center gap-2">
                      <input value={goal} onChange={e => {
                        const updated = [...goals];
                        updated[i] = e.target.value;
                        setGoals(updated);
                      }} className="flex-1 bg-transparent text-sm text-mc-text focus:outline-none border-b border-mc-border focus:border-mc-accent" />
                      <button onClick={() => setGoals(goals.filter((_, idx) => idx !== i))} className="text-xs text-mc-muted hover:text-red-400">✕</button>
                    </div>
                  ) : (
                    <span className="text-sm text-mc-text">{goal}</span>
                  )}
                </div>
              ))}
              {editing && (
                <div className="flex gap-2">
                  <input value={newGoal} onChange={e => setNewGoal(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && newGoal.trim()) { setGoals([...goals, newGoal.trim()]); setNewGoal(''); } }}
                    placeholder="Add a goal..." className="flex-1 px-3 py-1.5 bg-mc-bg border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                  <button onClick={() => { if (newGoal.trim()) { setGoals([...goals, newGoal.trim()]); setNewGoal(''); } }}
                    className="px-3 py-1.5 text-xs border border-mc-border rounded text-mc-muted hover:border-mc-accent">Add</button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
