'use client';
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';

interface Activity {
  id: string;
  agent: string;
  action: string;
  detail: string;
  timestamp: string;
}

/**
 * Format timestamp safely for local timezone display.
 * All timestamps are stored in UTC (ISO 8601), convert to local for display.
 * Returns null if timestamp is in the future (data integrity check).
 */
function formatTimestamp(ts: string | null | undefined): string {
  if (!ts) return '—';
  
  try {
    const date = new Date(ts);
    const now = new Date();
    
    // Sanity check: if timestamp is in the future, it's a bug - return error indicator
    if (date.getTime() > now.getTime() + 60000) { // Allow 1 minute tolerance for clock skew
      console.warn('[ActivityFeed] Future timestamp detected:', ts);
      return '⚠️ future';
    }
    
    // Use UTC methods to avoid timezone conversion bugs
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
      timeZoneName: undefined // Don't show timezone name to avoid clutter
    });
  } catch {
    return '—';
  }
}

/**
 * Calculate relative time (time ago) from UTC timestamp.
 * Also validates timestamp is not in the future.
 */
function timeAgo(ts: string) {
  if (!ts) return '—';
  
  try {
    const date = new Date(ts);
    const now = new Date();
    
    // Validate timestamp is not in the future
    if (date.getTime() > now.getTime() + 60000) {
      return '⚠️ future';
    }
    
    const diff = now.getTime() - date.getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  } catch {
    return '—';
  }
}

export default function ActivityFeed({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const { data: session } = useSession();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [filter, setFilter] = useState('all');

  const fetchActivity = () => fetch('/api/activity').then(r => r.json()).then(d => setActivities(d.entries || d.activities || [])).catch(() => {});

  useEffect(() => {
    if (!session) return;
    fetchActivity();
    const i = setInterval(fetchActivity, 30000);
    return () => clearInterval(i);
  }, [session]);

  const agents = Array.from(new Set(activities.map(a => a.agent)));
  const sorted = [...activities].sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
  const filtered = filter === 'all' ? sorted : sorted.filter(a => a.agent === filter);

  if (!session) {
    return (
      <div className={`flex flex-col bg-mc-surface border-l border-mc-border transition-all ${collapsed ? 'w-12' : 'w-[280px]'}`}>
        <div className="flex items-center justify-between px-3 py-2 border-b border-mc-border">
          <button onClick={onToggle} className="text-mc-muted hover:text-mc-text text-sm">
            {collapsed ? '«' : '»'}
          </button>
          {!collapsed && <span className="text-xs font-semibold text-mc-muted uppercase tracking-wide">Activity</span>}
        </div>
        {!collapsed && (
          <div className="flex-1 flex flex-col items-center justify-center px-3 py-8 text-center gap-2">
            <span className="text-2xl opacity-40">🔒</span>
            <p className="text-[11px] text-mc-muted">Sign in to see activity</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`flex flex-col bg-mc-surface border-l border-mc-border transition-all ${collapsed ? 'w-12' : 'w-[280px]'}`}>
      <div className="flex items-center justify-between px-3 py-2 border-b border-mc-border">
        <button onClick={onToggle} className="text-mc-muted hover:text-mc-text text-sm">
          {collapsed ? '«' : '»'}
        </button>
        {!collapsed && <span className="text-xs font-semibold text-mc-muted uppercase tracking-wide">Activity</span>}
      </div>
      {!collapsed && (
        <>
          <div className="px-3 py-2 border-b border-mc-border">
            <select
              value={filter}
              onChange={e => setFilter(e.target.value)}
              className="w-full text-xs bg-mc-bg border border-mc-border rounded px-2 py-1 text-mc-text focus:outline-none"
            >
              <option value="all">All Agents</option>
              {agents.map(a => <option key={a} value={a}>{a}</option>)}
            </select>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filtered.map(act => (
              <div key={act.id} className="px-3 py-2 border-b border-mc-border/50 hover:bg-mc-bg transition-colors">
                <div className="text-xs">
                  <span className="font-semibold text-mc-accent">{act.agent}</span>{' '}
                  <span className="text-mc-muted">{act.action}</span>{' '}
                  <span className="text-mc-text">{act.detail || (act as any).details}</span>
                </div>
                <div className="text-[10px] text-mc-muted mt-0.5">{timeAgo(act.timestamp)}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
