// Loading States & Skeleton Components
// Provides consistent loading UI across the application

import { cn } from '@/lib/utils';

// Base Skeleton
// ============

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
  return (
    <div
      className={cn(
        'animate-pulse rounded-md bg-mc-muted/50',
        className
      )}
    />
  );
}

// Skeleton Variants
// =================

export function CardSkeleton({ className }: SkeletonProps) {
  return (
    <div className={cn('rounded-lg border border-mc-muted/30 bg-mc-bg p-4 space-y-3', className)}>
      <Skeleton className="h-4 w-1/3" />
      <Skeleton className="h-8 w-2/3" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-4/5" />
    </div>
  );
}

export function ListItemSkeleton({ className }: SkeletonProps) {
  return (
    <div className={cn('flex items-center gap-3 p-3', className)}>
      <Skeleton className="h-10 w-10 rounded-full" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-4 w-1/3" />
        <Skeleton className="h-3 w-1/2" />
      </div>
      <Skeleton className="h-6 w-16 rounded-full" />
    </div>
  );
}

export function TableRowSkeleton({ columns = 4, className }: { columns?: number } & SkeletonProps) {
  return (
    <tr className={className}>
      {Array.from({ length: columns }).map((_, i) => (
        <td key={i} className="p-3">
          <Skeleton className="h-4" />
        </td>
      ))}
    </tr>
  );
}

export function StatCardSkeleton({ className }: SkeletonProps) {
  return (
    <div className={cn('rounded-lg border border-mc-muted/30 bg-mc-bg p-4', className)}>
      <Skeleton className="h-4 w-20 mb-2" />
      <Skeleton className="h-8 w-16" />
    </div>
  );
}

// Panel Skeleton - for full panel loading
// ======================================

interface PanelSkeletonProps {
  showHeader?: boolean;
  showSidebar?: boolean;
  sidebarItems?: number;
  statCards?: number;
  listItems?: number;
}

export function PanelSkeleton({
  showHeader = true,
  showSidebar = false,
  sidebarItems = 5,
  statCards = 4,
  listItems = 6,
}: PanelSkeletonProps) {
  return (
    <div className="flex gap-4 h-full">
      {/* Sidebar */}
      {showSidebar && (
        <div className="w-64 space-y-2">
          {Array.from({ length: sidebarItems }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 space-y-4">
        {/* Header */}
        {showHeader && (
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {Array.from({ length: statCards }).map((_, i) => (
            <StatCardSkeleton key={i} />
          ))}
        </div>

        {/* List/Table */}
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          {Array.from({ length: listItems }).map((_, i) => (
            <ListItemSkeleton key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

// Loading Spinner
// ===============

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function Spinner({ size = 'md', className }: SpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  return (
    <div
      className={cn(
        'animate-spin rounded-full border-2 border-mc-muted border-t-mc-accent',
        sizeClasses[size],
        className
      )}
    />
  );
}

// Loading Overlay
// ==============

interface LoadingOverlayProps {
  message?: string;
}

export function LoadingOverlay({ message = 'Loading...' }: LoadingOverlayProps) {
  return (
    <div className="absolute inset-0 bg-mc-bg/80 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-10">
      <Spinner size="lg" />
      <p className="text-sm text-mc-muted animate-pulse">{message}</p>
    </div>
  );
}

// Loading Button
// =============

interface LoadingButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  loadingText?: string;
  children: React.ReactNode;
}

export function LoadingButton({
  loading = false,
  loadingText,
  children,
  disabled,
  className,
  ...props
}: LoadingButtonProps) {
  return (
    <button
      className={cn(
        'relative inline-flex items-center justify-center gap-2 px-4 py-2 rounded-md font-medium transition-colors',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        loading && 'cursor-wait',
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <Spinner size="sm" />}
      {loading && loadingText ? loadingText : children}
    </button>
  );
}

// Data Fetching Hook
// ==================

import { useState, useCallback } from 'react';
import { useToast } from '@/lib/error-handling';
import { isApiResponse, ApiResponse } from '@/lib/api-response';

interface UseFetchOptions<T> {
  onSuccess?: (data: T) => void;
  onError?: (error: Error) => void;
  showToastOnError?: boolean;
  errorMessage?: string;
}

interface UseFetchReturn<T> {
  data: T | null;
  loading: boolean;
  error: Error | null;
  execute: () => Promise<void>;
  reset: () => void;
}

export function useFetch<T>(
  url: string,
  options: UseFetchOptions<T> = {}
): UseFetchReturn<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const { error: showError } = useToast();

  const execute = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(url, { credentials: 'include' });
      const json = await response.json();

      // Check for API response format
      if (isApiResponse(json)) {
        if (!json.success) {
          throw new Error(json.error?.message ?? 'Request failed');
        }
        setData(json.data ?? null);
        options.onSuccess?.(json.data as T);
      } else {
        // Fallback for non-standard responses
        setData(json as T);
        options.onSuccess?.(json as T);
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      setError(error);
      if (options.showToastOnError !== false) {
        showError(options.errorMessage ?? error.message);
      }
      options.onError?.(error);
    } finally {
      setLoading(false);
    }
  }, [url, options, showError]);

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setLoading(false);
  }, []);

  return { data, loading, error, execute, reset };
}

// Auto-fetch hook
export function useAutoFetch<T>(
  url: string | null,
  options: UseFetchOptions<T> = {}
): UseFetchReturn<T> {
  const fetch = useFetch<T>(url ?? '', options);

  React.useEffect(() => {
    if (url) {
      fetch.execute();
    }
  }, [url]);

  return fetch;
}