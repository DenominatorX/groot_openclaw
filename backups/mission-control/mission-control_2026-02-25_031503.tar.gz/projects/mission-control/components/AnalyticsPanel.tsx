'use client';
import { useEffect, useState } from 'react';

interface AnalyticsData {
  summary: {
    totalTasks: number;
    tasksByStatus: Record<string, number>;
    activeAgents: number;
    totalAgents: number;
    projectsInProgress: number;
    totalProjects: number;
    messagesToday: number;
    reportsGenerated: number;
    estimatedCostToday: number;
  };
  agentActions: Record<string, number>;
  dailyActivity: Record<string, number>;
  weeklyVelocity: { week: string; count: number }[];
  agents: { id: string; name: string; color: string; tier: number; messages: number; tasks: number; sessions: number }[];
  projects: { id: string; title: string; status: string; phases: number; completedPhases: number }[];
}

interface SystemInfo {
  hostname?: string; platform?: string; cpuModel?: string; cpuCores?: number;
  memTotal?: number; memFree?: number; memUsedPct?: number;
  diskTotal?: number; diskUsed?: number; diskUsedPct?: number;
  uptime?: number; gatewayStatus?: string;
}

const TIER_LABELS: Record<number, string> = {
  0: 'Owner', 1: 'Executive', 2: 'VP', 3: 'Director',
  4: 'Sr. Manager', 5: 'Manager', 6: 'Frontline',
};
const TIER_COSTS: Record<number, number> = {
  0: 0, 1: 0.015, 2: 0.003, 3: 0.005, 4: 0.0008, 5: 0.0002, 6: 0.0001,
};

function formatBytes(b: number) {
  if (b >= 1e12) return (b / 1e12).toFixed(1) + ' TB';
  if (b >= 1e9) return (b / 1e9).toFixed(1) + ' GB';
  return (b / 1e6).toFixed(1) + ' MB';
}
function formatUptime(s: number) {
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  return d > 0 ? `${d}d ${h}h` : h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export default function AnalyticsPanel() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [system, setSystem] = useState<SystemInfo>({});
  const [showInactive, setShowInactive] = useState(false);

  useEffect(() => {
    fetch('/api/analytics').then(r => r.json()).then(setData).catch(() => {});
    fetch('/api/system').then(r => r.json()).then(setSystem).catch(() => {});
  }, []);

  if (!data) return <div className="text-mc-muted text-center py-12">Loading analytics...</div>;

  const maxAgentActions = Math.max(1, ...Object.values(data.agentActions || {}));
  const maxDaily = Math.max(1, ...Object.values(data.dailyActivity || {}));
  const maxVelocity = Math.max(1, ...(data.weeklyVelocity || []).map(w => w.count));

  // SVG line chart for velocity
  const velPoints = (data.weeklyVelocity || []).map((w, i) => ({
    x: 20 + (i / Math.max(1, (data.weeklyVelocity || []).length - 1)) * 260,
    y: 80 - (w.count / maxVelocity) * 60,
  }));
  const velPath = velPoints.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  // Prepare sorted agent lists for activity chart
  const allAgentActivity: { name: string; actions: number; color: string }[] = [];
  (data.agents || []).forEach(agent => {
    allAgentActivity.push({ name: agent.name, actions: (data.agentActions || {})[agent.name] || 0, color: agent.color });
  });
  // Add any extra from agentActions not in agents list
  Object.entries(data.agentActions || {}).forEach(([name, count]) => {
    if (!allAgentActivity.find(a => a.name === name)) {
      allAgentActivity.push({ name, actions: count, color: '#3b82f6' });
    }
  });
  const activeAgents = allAgentActivity.filter(a => a.actions > 0).sort((a, b) => b.actions - a.actions);
  const inactiveAgents = allAgentActivity.filter(a => a.actions === 0).sort((a, b) => a.name.localeCompare(b.name));
  const maxActive = Math.max(1, ...activeAgents.map(a => a.actions));


  return (
    <div className="space-y-4">
      {/* Row 1: Agent Activity (left half) + Daily Activity & Task Velocity (right half) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Agent Activity — sorted, collapsible inactive */}
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <h3 className="text-sm font-semibold mb-3">📊 Agent Activity (Last 7 Days)</h3>
          <div className="space-y-1.5">
            {activeAgents.map(agent => {
              const pct = (agent.actions / maxActive) * 100;
              return (
                <div key={agent.name} className="flex items-center gap-2">
                  <span className="text-[11px] w-20 truncate text-mc-muted">{agent.name}</span>
                  <div className="flex-1 h-5 bg-mc-bg rounded overflow-hidden relative">
                    <div className="h-full rounded transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: agent.color }} />
                    <span className="absolute right-2 top-0 text-[10px] text-mc-muted font-mono leading-5">{agent.actions}</span>
                  </div>
                </div>
              );
            })}
          </div>
          {inactiveAgents.length > 0 && (
            <div className="mt-3 border-t border-mc-border/30 pt-2">
              <button onClick={() => setShowInactive(p => !p)}
                className="flex items-center gap-1.5 text-[11px] text-mc-muted hover:text-mc-text transition-colors">
                <span className="text-[10px]">{showInactive ? '▼' : '▶'}</span>
                <span>Inactive agents ({inactiveAgents.length})</span>
              </button>
              {showInactive && (
                <div className="mt-2 space-y-1">
                  {inactiveAgents.map(agent => (
                    <div key={agent.name} className="flex items-center gap-2">
                      <span className="text-[11px] w-20 truncate text-mc-muted/50">{agent.name}</span>
                      <div className="flex-1 h-4 bg-mc-bg rounded overflow-hidden relative">
                        <span className="absolute right-2 top-0 text-[9px] text-mc-muted/40 font-mono leading-4">0</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right column: Daily Activity stacked with Task Velocity */}
        <div className="flex flex-col gap-4">
          {/* Daily Activity */}
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-semibold mb-3">📈 Daily Activity (7 Days)</h3>
            <div className="flex items-end gap-1 h-20">
              {Object.entries(data.dailyActivity || {}).map(([day, count]) => {
                const pct = (count / maxDaily) * 100;
                return (
                  <div key={day} className="flex-1 flex flex-col items-center gap-1">
                    <span className="text-[9px] text-mc-muted font-mono">{count}</span>
                    <div className="w-full bg-mc-bg rounded-t overflow-hidden" style={{ height: '48px' }}>
                      <div className="w-full bg-mc-accent rounded-t transition-all" style={{ height: `${pct}%`, marginTop: `${100 - pct}%` }} />
                    </div>
                    <span className="text-[9px] text-mc-muted">{day.slice(5)}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Task Velocity */}
          <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
            <h3 className="text-sm font-semibold mb-3">🚀 Task Velocity (Weekly)</h3>
            <svg viewBox="0 0 300 100" className="w-full h-20">
              <line x1="20" y1="20" x2="280" y2="20" stroke="var(--mc-border, #333)" strokeWidth="0.5" />
              <line x1="20" y1="50" x2="280" y2="50" stroke="var(--mc-border, #333)" strokeWidth="0.5" />
              <line x1="20" y1="80" x2="280" y2="80" stroke="var(--mc-border, #333)" strokeWidth="0.5" />
              <path d={velPath} fill="none" stroke="var(--mc-accent, #6366f1)" strokeWidth="2" />
              <path d={`${velPath} L ${velPoints[velPoints.length - 1]?.x || 280} 80 L 20 80 Z`} fill="var(--mc-accent, #6366f1)" opacity="0.1" />
              {velPoints.map((p, i) => (
                <g key={i}>
                  <circle cx={p.x} cy={p.y} r="3" fill="var(--mc-accent, #6366f1)" />
                  <text x={p.x} y={p.y - 8} textAnchor="middle" fontSize="9" fill="var(--mc-muted, #888)">{(data.weeklyVelocity || [])[i]?.count}</text>
                  <text x={p.x} y="95" textAnchor="middle" fontSize="8" fill="var(--mc-muted, #888)">{(data.weeklyVelocity || [])[i]?.week}</text>
                </g>
              ))}
            </svg>
          </div>
        </div>
      </div>

      {/* Row 2: Cost Tracker (left) + System Health (right) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Cost Tracker */}
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <h3 className="text-sm font-semibold mb-3">💰 Cost Tracker by Tier</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10px] text-mc-muted border-b border-mc-border">
                  <th className="text-left py-1.5 pr-2">Tier</th>
                  <th className="text-left py-1.5 pr-2">#</th>
                  <th className="text-left py-1.5 pr-2">Msgs</th>
                  <th className="text-left py-1.5 pr-2">$/1k</th>
                  <th className="text-left py-1.5 pr-2">Cost</th>
                  <th className="text-left py-1.5" style={{ width: '25%' }}></th>
                </tr>
              </thead>
              <tbody>
                {[0, 1, 2, 3, 4, 5, 6].map(tier => {
                  const tierAgents = (data.agents || []).filter(a => a.tier === tier);
                  const totalMsgs = tierAgents.reduce((s, a) => s + a.messages, 0);
                  const tokens = totalMsgs * 500;
                  const cost = (tokens / 1000) * (TIER_COSTS[tier] || 0);
                  const maxCost = Math.max(0.01, ...([0,1,2,3,4,5,6].map(t => {
                    const ta = (data.agents || []).filter(a => a.tier === t);
                    const m = ta.reduce((s, a) => s + a.messages, 0) * 500;
                    return (m / 1000) * (TIER_COSTS[t] || 0);
                  })));
                  const barPct = (cost / maxCost) * 100;
                  return (
                    <tr key={tier} className="border-b border-mc-border/30">
                      <td className="py-1.5 pr-2 text-[11px]">{TIER_LABELS[tier]}</td>
                      <td className="py-1.5 pr-2 text-[11px] text-mc-muted">{tierAgents.length}</td>
                      <td className="py-1.5 pr-2 text-[11px] text-mc-muted">{totalMsgs.toLocaleString()}</td>
                      <td className="py-1.5 pr-2 text-[11px] text-mc-muted">${TIER_COSTS[tier]}</td>
                      <td className="py-1.5 pr-2 text-[11px] font-semibold">${cost.toFixed(2)}</td>
                      <td className="py-1.5">
                        <div className="h-2.5 bg-mc-bg rounded overflow-hidden">
                          <div className="h-full bg-yellow-500/60 rounded transition-all" style={{ width: `${barPct}%` }} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t border-mc-border">
                  <td colSpan={4} className="py-1.5 text-[11px] font-semibold">Total</td>
                  <td className="py-1.5 text-[11px] font-bold text-mc-accent">${(data.summary?.estimatedCostToday || 0).toFixed(2)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* System Health */}
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <h3 className="text-sm font-semibold mb-3">🖥️ System Health</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-mc-bg rounded-lg p-3">
              <div className="text-[10px] text-mc-muted uppercase">Uptime</div>
              <div className="text-sm font-bold mt-1">{system.uptime ? formatUptime(system.uptime) : '--'}</div>
            </div>
            <div className="bg-mc-bg rounded-lg p-3">
              <div className="text-[10px] text-mc-muted uppercase">Memory</div>
              <div className="text-sm font-bold mt-1">{system.memUsedPct ?? '--'}%</div>
              {system.memTotal && <div className="text-[10px] text-mc-muted">{formatBytes(system.memTotal - (system.memFree || 0))} / {formatBytes(system.memTotal)}</div>}
              {system.memUsedPct != null && (
                <div className="h-1.5 bg-mc-surface rounded-full mt-1 overflow-hidden">
                  <div className={`h-full rounded-full ${system.memUsedPct > 80 ? 'bg-red-500' : system.memUsedPct > 60 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{ width: `${system.memUsedPct}%` }} />
                </div>
              )}
            </div>
            <div className="bg-mc-bg rounded-lg p-3">
              <div className="text-[10px] text-mc-muted uppercase">Disk</div>
              <div className="text-sm font-bold mt-1">{system.diskUsedPct ?? '--'}%</div>
              {system.diskTotal && <div className="text-[10px] text-mc-muted">{formatBytes(system.diskUsed || 0)} / {formatBytes(system.diskTotal)}</div>}
              {system.diskUsedPct != null && (
                <div className="h-1.5 bg-mc-surface rounded-full mt-1 overflow-hidden">
                  <div className={`h-full rounded-full ${system.diskUsedPct > 80 ? 'bg-red-500' : system.diskUsedPct > 60 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{ width: `${system.diskUsedPct}%` }} />
                </div>
              )}
            </div>
            <div className="bg-mc-bg rounded-lg p-3">
              <div className="text-[10px] text-mc-muted uppercase">Gateway</div>
              <div className={`text-sm font-bold mt-1 ${system.gatewayStatus === 'online' ? 'text-green-400' : 'text-red-400'}`}>
                {system.gatewayStatus || '--'}
              </div>
              <div className="text-[10px] text-mc-muted">{system.hostname || '--'}</div>
            </div>
          </div>
          {system.cpuModel && <div className="mt-3 text-[10px] text-mc-muted">{system.cpuModel} · {system.cpuCores} cores · {system.platform}</div>}
        </div>
      </div>

      {/* Row 3: Project Progress — full width */}
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <h3 className="text-sm font-semibold mb-3">📁 Project Progress Overview</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
          {(data.projects || []).map(p => {
            const pct = p.phases > 0 ? Math.round((p.completedPhases / p.phases) * 100) : 0;
            const statusColor: Record<string, string> = {
              planning: 'text-blue-400', 'in-progress': 'text-yellow-400',
              review: 'text-orange-400', complete: 'text-green-400',
            };
            return (
              <div key={p.id}>
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-xs truncate flex-1">{p.title}</span>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className={`text-[10px] ${statusColor[p.status] || 'text-mc-muted'}`}>{p.status}</span>
                    <span className="text-[10px] font-mono text-mc-muted w-8 text-right">{pct}%</span>
                  </div>
                </div>
                <div className="h-1.5 bg-mc-bg rounded-full overflow-hidden">
                  <div className="h-full bg-mc-accent rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
