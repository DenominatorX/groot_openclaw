'use client';

import { useRef, useMemo, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Text, Box, Plane, Float, Html } from '@react-three/drei';
import * as THREE from 'three';

// Colors matching Agent World dark sci-fi aesthetic
const COLORS = {
  background: '#050510',
  accentCyan: '#00ffff',
  accentMagenta: '#ff00ff',
  panelGlass: 'rgba(0, 30, 60, 0.85)',
  text: '#e0e0e0',
  grid: '#0a1a2a',
  active: '#00ff88',
  idle: '#ffaa00',
  error: '#ff4444',
  busy: '#ff00ff',
};

// Types
interface TaskSummary {
  todo: number;
  inProgress: number;
  done: number;
  total: number;
}

interface HealthData {
  sleepScore?: number;
  readiness?: number;
  hrv?: number;
  restingHR?: number;
}

interface Agent {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'error' | 'busy';
  tier: number;
}

interface VRCanvasProps {
  taskData: TaskSummary | null;
  healthData: HealthData | null;
  agents: Agent[];
  panelExpanded: string | null;
  onPanelClick: (panelId: string) => void;
}

// Holographic Panel Component
function HolographicPanel({ 
  position, 
  rotation, 
  title, 
  children, 
  panelId,
  onClick,
  isExpanded 
}: { 
  position: [number, number, number];
  rotation?: [number, number, number];
  title: string;
  children: React.ReactNode;
  panelId: string;
  onClick: () => void;
  isExpanded: boolean;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current && !isExpanded) {
      // Subtle floating animation
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 0.5) * 0.05;
    }
  });

  return (
    <group position={position} rotation={rotation ? new THREE.Euler(...rotation) : undefined}>
      <Float speed={2} rotationIntensity={0} floatIntensity={0.2} enabled={!isExpanded}>
        {/* Panel Background */}
        <mesh
          ref={meshRef}
          onClick={onClick}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
        >
          <planeGeometry args={[3, 2.2]} />
          <meshStandardMaterial 
            color={COLORS.panelGlass}
            transparent
            opacity={0.9}
            side={THREE.DoubleSide}
            emissive={hovered ? COLORS.accentCyan : '#001020'}
            emissiveIntensity={hovered ? 0.3 : 0.1}
          />
        </mesh>

        {/* Panel Border Glow */}
        <mesh position={[0, 0, -0.01]}>
          <planeGeometry args={[3.1, 2.3]} />
          <meshBasicMaterial 
            color={hovered ? COLORS.accentCyan : '#003040'} 
            transparent 
            opacity={0.5}
          />
        </mesh>

        {/* Title */}
        <Text
          position={[0, 0.85, 0.01]}
          fontSize={0.18}
          color={COLORS.accentCyan}
          anchorX="center"
          anchorY="middle"
          font="/fonts/JetBrainsMono-Regular.ttf"
        >
          {title}
        </Text>

        {/* Divider Line */}
        <mesh position={[0, 0.65, 0.01]}>
          <planeGeometry args={[2.6, 0.02]} />
          <meshBasicMaterial color={COLORS.accentCyan} transparent opacity={0.6} />
        </mesh>

        {/* Content Area */}
        <Html
          position={[0, -0.1, 0.01]}
          transform
          occlude
          distanceFactor={3}
          style={{
            width: '280px',
            pointerEvents: hovered ? 'auto' : 'none',
            cursor: 'pointer'
          }}
        >
          <div className="text-white p-2 font-mono text-xs">
            {children}
          </div>
        </Html>
      </Float>
    </group>
  );
}

// Task Panel Content
function TaskPanelContent({ data }: { data: TaskSummary | null }) {
  if (!data) return <div className="text-gray-500">Loading...</div>;
  
  const total = data.total || 1;
  const donePercent = Math.round((data.done / total) * 100);

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs">
        <span className="text-yellow-400">📋 Todo: {data.todo}</span>
        <span className="text-blue-400">🔄 In Progress: {data.inProgress}</span>
      </div>
      <div className="flex justify-between text-xs">
        <span className="text-green-400">✅ Done: {data.done}</span>
        <span className="text-gray-400">Total: {data.total}</span>
      </div>
      {/* Progress Bar */}
      <div className="h-2 bg-gray-800 rounded overflow-hidden mt-2">
        <div 
          className="h-full bg-gradient-to-r from-green-500 to-cyan-500 transition-all"
          style={{ width: `${donePercent}%` }}
        />
      </div>
      <div className="text-center text-xs text-cyan-400">{donePercent}% Complete</div>
    </div>
  );
}

// Health Panel Content
function HealthPanelContent({ data }: { data: HealthData | null }) {
  if (!data) return <div className="text-gray-500">No Oura Data</div>;

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="bg-purple-900/50 p-2 rounded">
          <div className="text-purple-400">😴 Sleep</div>
          <div className="text-xl font-bold text-white">{data.sleepScore || '--'}</div>
        </div>
        <div className="bg-green-900/50 p-2 rounded">
          <div className="text-green-400">⚡ Ready</div>
          <div className="text-xl font-bold text-white">{data.readiness || '--'}</div>
        </div>
        <div className="bg-blue-900/50 p-2 rounded">
          <div className="text-blue-400">💓 HRV</div>
          <div className="text-xl font-bold text-white">{data.hrv || '--'}</div>
        </div>
        <div className="bg-red-900/50 p-2 rounded">
          <div className="text-red-400">❤️ RHR</div>
          <div className="text-xl font-bold text-white">{data.restingHR || '--'}</div>
        </div>
      </div>
    </div>
  );
}

// Agent Grid Content
function AgentGridContent({ agents }: { agents: Agent[] }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return COLORS.active;
      case 'idle': return COLORS.idle;
      case 'error': return COLORS.error;
      case 'busy': return COLORS.busy;
      default: return COLORS.idle;
    }
  };

  return (
    <div className="grid grid-cols-4 gap-1">
      {agents.slice(0, 8).map((agent) => (
        <div 
          key={agent.id}
          className="text-center p-1 bg-black/30 rounded"
        >
          <div 
            className="w-3 h-3 rounded-full mx-auto mb-1"
            style={{ backgroundColor: getStatusColor(agent.status) }}
          />
          <div className="text-[8px] text-gray-300 truncate">{agent.name}</div>
        </div>
      ))}
    </div>
  );
}

// Brain Chat Content
function BrainChatContent() {
  return (
    <div className="space-y-2">
      <div className="text-xs text-gray-400">Quick Commands:</div>
      <div className="space-y-1 text-[10px]">
        <div className="bg-cyan-900/30 p-1 rounded text-cyan-300">"What's my focus today?"</div>
        <div className="bg-purple-900/30 p-1 rounded text-purple-300">"Summarize my tasks"</div>
        <div className="bg-green-900/30 p-1 rounded text-green-300">"Health insights"</div>
      </div>
      <div className="text-center text-[10px] text-magenta-400 mt-2">
        🧠 Voice Ready
      </div>
    </div>
  );
}

// Command Room Scene
function CommandRoom({ 
  taskData, 
  healthData, 
  agents, 
  panelExpanded,
  onPanelClick 
}: VRCanvasProps) {
  return (
    <>
      {/* Ambient and Point Lights */}
      <ambientLight intensity={0.2} />
      <pointLight position={[0, 5, 0]} intensity={1} color={COLORS.accentCyan} />
      <pointLight position={[-5, 3, 5]} intensity={0.5} color={COLORS.accentMagenta} />
      <pointLight position={[5, 3, -5]} intensity={0.5} color={COLORS.accentMagenta} />

      {/* Floor grid */}
      <gridHelper args={[30, 30, COLORS.accentCyan, COLORS.grid]} position={[0, -2, 0]} />

      {/* Floor Plane for reflection effect */}
      <mesh position={[0, -2.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial 
          color="#020208"
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Task Panel - Front Left */}
      <HolographicPanel
        position={[-4, 0.5, -3]}
        rotation={[0, 0.3, 0]}
        title="📋 TASK BOARD"
        panelId="tasks"
        onClick={() => onPanelClick('tasks')}
        isExpanded={panelExpanded === 'tasks'}
      >
        <TaskPanelContent data={taskData} />
      </HolographicPanel>

      {/* Health Panel - Front Right */}
      <HolographicPanel
        position={[4, 0.5, -3]}
        rotation={[0, -0.3, 0]}
        title="❤️ HEALTH"
        panelId="health"
        onClick={() => onPanelClick('health')}
        isExpanded={panelExpanded === 'health'}
      >
        <HealthPanelContent data={healthData} />
      </HolographicPanel>

      {/* Agent Status Panel - Back Left */}
      <HolographicPanel
        position={[-4, 0.5, 3]}
        rotation={[0, Math.PI - 0.3, 0]}
        title="🤖 AGENTS"
        panelId="agents"
        onClick={() => onPanelClick('agents')}
        isExpanded={panelExpanded === 'agents'}
      >
        <AgentGridContent agents={agents} />
      </HolographicPanel>

      {/* Brain Chat Panel - Back Right */}
      <HolographicPanel
        position={[4, 0.5, 3]}
        rotation={[0, Math.PI + 0.3, 0]}
        title="🧠 BRAIN CHAT"
        panelId="brain"
        onClick={() => onPanelClick('brain')}
        isExpanded={panelExpanded === 'brain'}
      >
        <BrainChatContent />
      </HolographicPanel>

      {/* Center Info Display */}
      <group position={[0, 1.5, 0]}>
        <Float speed={1.5} rotationIntensity={0} floatIntensity={0.3}>
          <Text
            fontSize={0.4}
            color={COLORS.accentCyan}
            anchorX="center"
            anchorY="middle"
          >
            MISSION CONTROL
          </Text>
          <Text
            position={[0, -0.4, 0]}
            fontSize={0.15}
            color={COLORS.accentMagenta}
            anchorX="center"
            anchorY="middle"
          >
            VR COMMAND CENTER v1.0
          </Text>
        </Float>
      </group>

      {/* Orbital Rings - Decorative */}
      <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[6, 0.02, 16, 100]} />
        <meshBasicMaterial color={COLORS.accentCyan} transparent opacity={0.3} />
      </mesh>
      <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[7, 0.01, 16, 100]} />
        <meshBasicMaterial color={COLORS.accentMagenta} transparent opacity={0.2} />
      </mesh>

      {/* Fog for depth */}
      <fog attach="fog" args={[COLORS.background, 10, 30]} />
    </>
  );
}

// Desktop orbit controls
function DesktopControls() {
  return (
    <OrbitControls
      enablePan={true}
      enableZoom={true}
      enableRotate={true}
      minDistance={3}
      maxDistance={15}
      maxPolarAngle={Math.PI / 1.5}
      minPolarAngle={Math.PI / 4}
    />
  );
}

// Main Canvas Component
export default function VRCanvas(props: VRCanvasProps) {
  return (
    <Canvas
      camera={{ position: [0, 1, 8], fov: 60 }}
      gl={{ antialias: true, alpha: false }}
      style={{ background: COLORS.background }}
    >
      <CommandRoom {...props} />
      <DesktopControls />
    </Canvas>
  );
}
