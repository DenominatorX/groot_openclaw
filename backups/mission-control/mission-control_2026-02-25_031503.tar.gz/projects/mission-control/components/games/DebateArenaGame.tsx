/* @ts-nocheck */
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Scale, Trophy, Zap, BookOpen, Target, AlertCircle, RefreshCw, Save, Share2 } from 'lucide-react';

interface Topic {
  id: string;
  title: string;
  description: string;
  category: 'pop-culture' | 'technology' | 'philosophy' | 'sports' | 'food' | 'history' | 'hypothetical' | 'business';
  sides: [string, string];
  difficulty: 'easy' | 'medium' | 'hard';
}

interface Argument {
  round: 'opening' | 'rebuttal' | 'closing';
  text: string;
  timeSpent: number;
}

interface ScoreBreakdown {
  logic: number;
  evidence: number;
  persuasion: number;
  style: number;
  total: number;
  feedback: string;
}

interface GameState {
  mode: 'menu' | 'solo' | 'quick' | 'tournament' | 'devils-advocate';
  topic: Topic | null;
  userSide: string | null;
  difficulty: 'pushover' | 'moderate' | 'challenging' | 'ruthless' | 'philosopher-king';
  round: 'opening' | 'rebuttal' | 'closing' | 'results';
  timeRemaining: number;
  userArguments: Argument[];
  userScores: ScoreBreakdown[];
  aiResponse: string;
  aiScore: ScoreBreakdown | null;
  totalWins: number;
  rank: 'rookie' | 'debater' | 'orator' | 'senator' | 'supreme-court-justice';
  badges: string[];
  tournamentRound: number;
}

const RANK_THRESHOLDS = {
  'rookie': 0,
  'debater': 10,
  'orator': 25,
  'senator': 50,
  'supreme-court-justice': 100,
};

const RANK_NAMES = ['rookie', 'debater', 'orator', 'senator', 'supreme-court-justice'] as const;

const TIME_LIMITS = {
  opening: 60,
  rebuttal: 45,
  closing: 30,
};

const DebateArenaGame: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    mode: 'menu',
    topic: null,
    userSide: null,
    difficulty: 'moderate',
    round: 'opening',
    timeRemaining: TIME_LIMITS.opening,
    userArguments: [],
    userScores: [],
    aiResponse: '',
    aiScore: null,
    totalWins: 0,
    rank: 'rookie',
    badges: [],
    tournamentRound: 1,
  });

  const [currentArgument, setCurrentArgument] = useState('');
  const [timerActive, setTimerActive] = useState(false);
  const [savedArguments, setSavedArguments] = useState<Array<{ text: string; topic: string; side: string }>>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [loading, setLoading] = useState(false);

  // Load saved data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('debate-arena-saves');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setSavedArguments(data.arguments || []);
        setGameState((prev) => ({
          ...prev,
          totalWins: data.totalWins || 0,
          rank: data.rank || 'rookie',
          badges: data.badges || [],
        }));
      } catch (e) {
        console.error('Failed to load saved data');
      }
    }
  }, []);

  // Timer logic
  useEffect(() => {
    if (!timerActive || gameState.timeRemaining <= 0) {
      if (gameState.timeRemaining === 0 && timerActive) {
        handleRoundComplete();
      }
      return;
    }

    const interval = setInterval(() => {
      setGameState((prev) => ({
        ...prev,
        timeRemaining: Math.max(0, prev.timeRemaining - 1),
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, [timerActive, gameState.timeRemaining]);

  const generateTopic = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/games/debate-arena/topic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ difficulty: gameState.difficulty }),
      });
      const topic: Topic = await response.json();
      setGameState((prev) => ({
        ...prev,
        topic,
        userSide: null,
        round: 'opening',
        timeRemaining: TIME_LIMITS.opening,
        userArguments: [],
        aiResponse: '',
        aiScore: null,
      }));
    } catch (error) {
      console.error('Failed to generate topic:', error);
    } finally {
      setLoading(false);
    }
  };

  const chooseSide = (side: string) => {
    if (gameState.mode === 'devils-advocate') {
      // AI chooses the unpopular side; user gets the other
      setGameState((prev) => ({
        ...prev,
        userSide: prev.topic?.sides[1] === side ? prev.topic?.sides[0] : prev.topic?.sides[1] || side,
      }));
    } else {
      setGameState((prev) => ({
        ...prev,
        userSide: side,
      }));
    }
    setTimerActive(true);
  };

  const handleRoundComplete = async () => {
    setTimerActive(false);

    const round = gameState.round as 'opening' | 'rebuttal' | 'closing' | 'results';
    const timeSpent = round !== 'results' ? TIME_LIMITS[round as 'opening' | 'rebuttal' | 'closing'] - gameState.timeRemaining : 0;
    const newArgument: Argument = {
      round: round as 'opening' | 'rebuttal' | 'closing',
      text: currentArgument,
      timeSpent,
    };

    setGameState((prev) => ({
      ...prev,
      userArguments: [...prev.userArguments, newArgument],
    }));

    // Generate AI response and score
    try {
      const response = await fetch('/api/games/debate-arena/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: gameState.topic,
          userSide: gameState.userSide,
          userArgument: currentArgument,
          round: gameState.round,
          difficulty: gameState.difficulty,
        }),
      });

      const result = await response.json();

      setGameState((prev) => {
        const nextRound = prev.round === 'opening' ? 'rebuttal' : prev.round === 'rebuttal' ? 'closing' : 'results';
        return {
          ...prev,
          aiResponse: result.aiResponse,
          aiScore: result.score,
          round: nextRound,
          timeRemaining: nextRound === 'results' ? 0 : TIME_LIMITS[nextRound],
          userScores: [...prev.userScores, result.score],
        };
      });

      setCurrentArgument('');
    } catch (error) {
      console.error('Failed to evaluate argument:', error);
    }
  };

  const saveArgument = () => {
    if (currentArgument.trim()) {
      const newSave = {
        text: currentArgument,
        topic: gameState.topic?.title || 'Unknown',
        side: gameState.userSide || 'Unknown',
      };
      setSavedArguments((prev) => [...prev, newSave]);

      // Persist to localStorage
      const saves = localStorage.getItem('debate-arena-saves');
      const data = saves ? JSON.parse(saves) : {};
      data.arguments = [...(data.arguments || []), newSave];
      localStorage.setItem('debate-arena-saves', JSON.stringify(data));
    }
  };

  const finishDebate = () => {
    // Calculate total score
    const totalScore = gameState.userScores.reduce((sum, score) => sum + score.total, 0) / Math.max(gameState.userScores.length, 1);

    // Award XP, update rank
    let newWins = gameState.totalWins;
    let newRank = gameState.rank;
    let newBadges = gameState.badges;

    if (totalScore >= 80) {
      newWins += 1;
      // Check rank up
      const nextRankIndex = RANK_NAMES.indexOf(gameState.rank) + 1;
      if (nextRankIndex < RANK_NAMES.length && newWins >= RANK_THRESHOLDS[RANK_NAMES[nextRankIndex]]) {
        newRank = RANK_NAMES[nextRankIndex];
      }
      if (newWins === 10) newBadges = [...new Set([...gameState.badges, 'won-10-debates'])];
      if (totalScore === 100) newBadges = [...new Set([...new Set(gameState.badges), 'perfect-score'])];
    }

    if (gameState.mode === 'devils-advocate' && totalScore >= 80) {
      newBadges = [...new Set([...newBadges, 'devils-advocate-master'])];
    }

    setGameState((prev) => ({
      ...prev,
      mode: 'menu',
      totalWins: newWins,
      rank: newRank,
      badges: newBadges,
    }));

    // Persist updates
    localStorage.setItem('debate-arena-saves', JSON.stringify({
      totalWins: newWins,
      rank: newRank,
      badges: newBadges,
      arguments: savedArguments,
    }));
  };

  const renderMenu = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Scale className="w-12 h-12 text-amber-400" />
            <h1 className="text-5xl font-bold text-amber-400" style={{ fontFamily: 'Georgia, serif' }}>
              DEBATE ARENA
            </h1>
          </div>
          <p className="text-xl text-slate-300 mb-8">Master the art of argumentation. Challenge your mind.</p>

          {/* Rank Badge */}
          <div className="inline-block bg-slate-800 border-2 border-amber-400 rounded px-6 py-3 mb-8">
            <div className="text-amber-400 font-bold uppercase tracking-wider">{gameState.rank.replace('-', ' ')}</div>
            <div className="text-sm text-slate-400">Wins: {gameState.totalWins}</div>
          </div>
        </div>

        {/* Game Modes */}
        <div className="grid grid-cols-2 gap-6 mb-12">
          {[
            { mode: 'solo', title: '⚡ Solo Practice', desc: 'Debate against AI, get scored' },
            { mode: 'quick', title: '⏱️ Quick Debate', desc: '60-second arguments, instant score' },
            { mode: 'tournament', title: '🏆 Tournament', desc: '4 rounds of escalating difficulty' },
            { mode: 'devils-advocate', title: '😈 Devil\'s Advocate', desc: 'AI picks your side, bonus for winning' },
          ].map((m) => (
            <button
              key={m.mode}
              onClick={() => {
                setGameState((prev) => ({
                  ...prev,
                  mode: m.mode as any,
                  difficulty: m.mode === 'tournament' ? 'moderate' : prev.difficulty,
                  tournamentRound: 1,
                }));
                generateTopic();
              }}
              disabled={loading}
              className="bg-gradient-to-br from-slate-700 to-slate-800 border-2 border-blue-500 hover:border-amber-400 hover:from-slate-600 p-6 rounded text-left transition group disabled:opacity-50"
            >
              <div className="text-lg font-bold text-blue-300 group-hover:text-amber-400 mb-2">{m.title}</div>
              <div className="text-sm text-slate-400">{m.desc}</div>
            </button>
          ))}
        </div>

        {/* Difficulty Selector */}
        <div className="bg-slate-800 border border-blue-500 rounded p-6 mb-8">
          <h3 className="text-lg font-bold text-amber-400 mb-4">Difficulty</h3>
          <div className="grid grid-cols-5 gap-3">
            {['pushover', 'moderate', 'challenging', 'ruthless', 'philosopher-king'].map((diff) => (
              <button
                key={diff}
                onClick={() => setGameState((prev) => ({ ...prev, difficulty: diff as any }))}
                className={`py-3 rounded font-bold uppercase text-sm transition ${
                  gameState.difficulty === diff
                    ? 'bg-amber-400 text-slate-900'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {diff.split('-').pop()}
              </button>
            ))}
          </div>
        </div>

        {/* Badges */}
        {gameState.badges.length > 0 && (
          <div className="bg-slate-800 border border-yellow-500 rounded p-6 mb-8">
            <h3 className="text-lg font-bold text-yellow-400 mb-4">Achievements</h3>
            <div className="flex flex-wrap gap-3">
              {gameState.badges.map((badge) => (
                <div key={badge} className="bg-yellow-900 text-yellow-200 px-4 py-2 rounded-full text-sm font-bold">
                  {badge.replace('-', ' ').toUpperCase()}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Leaderboard & Argument Library */}
        <div className="grid grid-cols-2 gap-6">
          <button
            onClick={() => setShowLeaderboard(!showLeaderboard)}
            className="bg-slate-700 hover:bg-slate-600 border border-blue-500 hover:border-amber-400 p-4 rounded text-center transition"
          >
            <Trophy className="w-6 h-6 mx-auto mb-2 text-amber-400" />
            <div className="font-bold text-amber-400">Leaderboard</div>
          </button>
          <button
            className="bg-slate-700 hover:bg-slate-600 border border-blue-500 hover:border-amber-400 p-4 rounded text-center transition"
          >
            <BookOpen className="w-6 h-6 mx-auto mb-2 text-amber-400" />
            <div className="font-bold text-amber-400">Argument Library ({savedArguments.length})</div>
          </button>
        </div>
      </div>
    </div>
  );

  const renderDebate = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8 border-b border-slate-700 pb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-3xl font-bold text-amber-400" style={{ fontFamily: 'Georgia, serif' }}>
              {gameState.topic?.title}
            </h2>
            <button
              onClick={() => setGameState((prev) => ({ ...prev, mode: 'menu' }))}
              className="text-slate-400 hover:text-amber-400"
            >
              ✕
            </button>
          </div>
          <p className="text-slate-300 mb-4">{gameState.topic?.description}</p>
          <div className="flex gap-4 text-sm">
            <div className="bg-blue-900 text-blue-200 px-3 py-1 rounded">You: {gameState.userSide}</div>
            <div className="bg-red-900 text-red-200 px-3 py-1 rounded">AI: {gameState.userSide === gameState.topic?.sides[0] ? gameState.topic?.sides[1] : gameState.topic?.sides[0]}</div>
            <div className="bg-slate-700 text-slate-200 px-3 py-1 rounded">Difficulty: {gameState.difficulty}</div>
          </div>
        </div>

        {gameState.round === 'results' ? (
          <div className="space-y-8">
            {/* Final Scores */}
            <div className="bg-slate-800 border border-amber-400 rounded p-8">
              <h3 className="text-2xl font-bold text-amber-400 mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                DEBATE RESULTS
              </h3>

              {gameState.userScores.map((score, idx) => (
                <div key={idx} className="mb-8 last:mb-0 pb-8 last:pb-0 border-b border-slate-700 last:border-0">
                  <h4 className="text-lg font-bold text-blue-300 mb-4 uppercase">{score.total >= 80 ? '✓' : '✗'} Round {idx + 1}</h4>
                  <div className="grid grid-cols-4 gap-4 mb-4">
                    {[
                      { label: 'Logic', value: score.logic },
                      { label: 'Evidence', value: score.evidence },
                      { label: 'Persuasion', value: score.persuasion },
                      { label: 'Style', value: score.style },
                    ].map((metric) => (
                      <div key={metric.label} className="bg-slate-700 p-3 rounded">
                        <div className="text-xs text-slate-400 uppercase">{metric.label}</div>
                        <div className="text-2xl font-bold text-amber-400">{metric.value}</div>
                      </div>
                    ))}
                  </div>
                  <div className="bg-slate-700 p-3 rounded mb-4">
                    <div className="text-sm text-slate-400 uppercase mb-2">Total Score</div>
                    <div className="text-4xl font-bold text-amber-400">{score.total}</div>
                  </div>
                  <div className="text-slate-300 bg-slate-700 p-4 rounded text-sm italic">
                    {score.feedback}
                  </div>
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={finishDebate}
                className="bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold py-3 rounded"
              >
                Back to Menu
              </button>
              <button
                onClick={() => {
                  setGameState((prev) => ({ ...prev, mode: 'menu' }));
                  generateTopic();
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded"
              >
                Rematch
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Timer */}
            <div className="flex items-center justify-between bg-slate-800 border border-amber-400 rounded p-6">
              <div>
                <div className="text-sm text-slate-400 uppercase mb-2">Round: {gameState.round}</div>
                <div className="text-3xl font-bold text-amber-400">
                  {Math.floor(gameState.timeRemaining / 60)}:{String(gameState.timeRemaining % 60).padStart(2, '0')}
                </div>
              </div>
              {timerActive ? (
                <div className="text-5xl animate-pulse">⏱️</div>
              ) : (
                <div className="text-slate-500">Ready?</div>
              )}
            </div>

            {/* Argument Input */}
            <div>
              <label className="block text-sm font-bold text-amber-400 uppercase mb-3">Your Argument</label>
              <textarea
                value={currentArgument}
                onChange={(e) => setCurrentArgument(e.target.value)}
                disabled={timerActive}
                placeholder="Make your case... (Be clear, logical, and persuasive!)"
                className="w-full h-40 bg-slate-700 border border-slate-600 text-white p-4 rounded focus:outline-none focus:border-amber-400 disabled:opacity-50"
              />
              <div className="text-xs text-slate-400 mt-2">{currentArgument.length} characters</div>
            </div>

            {/* Controls */}
            {!timerActive ? (
              <div className="grid grid-cols-3 gap-4">
                <button
                  onClick={() => setTimerActive(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded flex items-center justify-center gap-2"
                >
                  <Zap className="w-5 h-5" /> Start Round
                </button>
                <button
                  onClick={saveArgument}
                  className="bg-slate-700 hover:bg-slate-600 text-amber-400 font-bold py-3 rounded flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5" /> Save Argument
                </button>
                <button
                  onClick={() => setGameState((prev) => ({ ...prev, mode: 'menu' }))}
                  className="bg-slate-700 hover:bg-slate-600 text-slate-300 font-bold py-3 rounded"
                >
                  Exit
                </button>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );

  return gameState.mode === 'menu' ? renderMenu() : renderDebate();
};

export default DebateArenaGame;
