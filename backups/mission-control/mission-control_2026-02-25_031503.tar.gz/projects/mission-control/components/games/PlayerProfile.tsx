'use client';
import { useEffect, useState } from 'react';

interface PlayerRecord {
  wins: number;
  losses: number;
  totalGames: number;
  totalScore: number;
  bestScore: number;
}

const WRESTLER_AVATARS = ['💪', '🤼', '🦅', '💀', '🔥', '🏆', '👑', '⚡', '🎭', '💥', '🌟', '🎤', '🏟️', '🥊', '⛓️', '🎯', '🏅', '🔗', '📺', '💎'];

const getRankTitle = (wins: number) => {
  if (wins >= 21) return { title: 'Legend', emoji: '👑' };
  if (wins >= 11) return { title: 'Champion', emoji: '🏆' };
  if (wins >= 6) return { title: 'Main Eventer', emoji: '⭐' };
  if (wins >= 3) return { title: 'Mid-Carder', emoji: '📈' };
  return { title: 'Jobber', emoji: '🎪' };
};

export interface PlayerProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PlayerProfile({ isOpen, onClose }: PlayerProfileProps) {
  const [playerName, setPlayerName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(WRESTLER_AVATARS[0]);
  const [record, setRecord] = useState<PlayerRecord>({
    wins: 0,
    losses: 0,
    totalGames: 0,
    totalScore: 0,
    bestScore: 0,
  });

  // Load player profile from localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const name = localStorage.getItem('wrestling-player-name') || '';
      const avatar = localStorage.getItem('wrestling-avatar') || WRESTLER_AVATARS[0];
      setPlayerName(name);
      setSelectedAvatar(avatar);

      // Load game record
      const recordJson = localStorage.getItem('wrestling-player-record');
      if (recordJson) {
        try {
          setRecord(JSON.parse(recordJson));
        } catch (e) {
          console.error('Failed to parse player record:', e);
        }
      }
    }
  }, [isOpen]);

  const saveProfile = () => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('wrestling-player-name', playerName);
      localStorage.setItem('wrestling-avatar', selectedAvatar);
      onClose();
    }
  };

  const rank = getRankTitle(record.wins);
  const winRate = record.totalGames > 0 ? ((record.wins / record.totalGames) * 100).toFixed(1) : 0;
  const avgScore = record.totalGames > 0 ? Math.floor(record.totalScore / record.totalGames) : 0;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
        
        .wrestling-title {
          font-family: 'Righteous', cursive;
          font-size: 1.5rem;
          font-weight: 900;
          color: #FFD700;
          text-shadow: 2px 2px 0 #DC143C;
        }

        .ring-rope {
          border: 3px solid;
          border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
          box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
        }

        .championship-belt {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
          color: #1a1a1a;
          font-weight: 900;
        }
      `}</style>

      <div className="bg-slate-800 rounded-lg ring-rope w-96 max-h-96 overflow-y-auto">
        {/* Header */}
        <div className="championship-belt p-4 flex items-center justify-between">
          <div className="wrestling-title text-sm">FIGHTER PROFILE</div>
          <button
            onClick={onClose}
            className="text-2xl font-bold text-black hover:scale-110"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Avatar */}
          <div className="text-center">
            <div className="text-6xl mb-3">{selectedAvatar}</div>
            <div className="text-2xl font-bold text-white mb-2">{playerName || 'Unknown'}</div>
            <div className="text-sm font-semibold text-yellow-400">
              {rank.emoji} {rank.title}
            </div>
          </div>

          {/* Edit Profile */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-white mb-2">Display Name</label>
              <input
                type="text"
                value={playerName}
                onChange={e => setPlayerName(e.target.value)}
                placeholder="Enter your wrestling name"
                maxLength={20}
                className="w-full px-3 py-2 bg-slate-700 border-2 border-slate-600 rounded text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-white mb-2">Choose Avatar</label>
              <div className="grid grid-cols-5 gap-2">
                {WRESTLER_AVATARS.map(avatar => (
                  <button
                    key={avatar}
                    onClick={() => setSelectedAvatar(avatar)}
                    className={`text-3xl p-2 rounded transition-all ${
                      selectedAvatar === avatar
                        ? 'bg-yellow-500 scale-110'
                        : 'bg-slate-700 hover:bg-slate-600'
                    }`}
                  >
                    {avatar}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-700 p-3 rounded text-center">
              <div className="text-2xl font-bold text-green-400">{record.wins}</div>
              <div className="text-xs font-semibold text-white">WINS</div>
            </div>
            <div className="bg-slate-700 p-3 rounded text-center">
              <div className="text-2xl font-bold text-red-400">{record.losses}</div>
              <div className="text-xs font-semibold text-white">LOSSES</div>
            </div>
            <div className="bg-slate-700 p-3 rounded text-center">
              <div className="text-2xl font-bold text-blue-400">{winRate}%</div>
              <div className="text-xs font-semibold text-white">WIN RATE</div>
            </div>
            <div className="bg-slate-700 p-3 rounded text-center">
              <div className="text-2xl font-bold text-yellow-400">{avgScore}</div>
              <div className="text-xs font-semibold text-white">AVG SCORE</div>
            </div>
          </div>

          {/* Additional Stats */}
          <div className="bg-slate-700 p-3 rounded text-center space-y-2">
            <div className="text-xs font-bold text-yellow-400">CAREER</div>
            <div className="flex justify-around">
              <div>
                <div className="text-lg font-bold text-white">{record.totalGames}</div>
                <div className="text-xs text-gray-400">Games Played</div>
              </div>
              <div>
                <div className="text-lg font-bold text-white">{record.bestScore.toLocaleString()}</div>
                <div className="text-xs text-gray-400">Best Score</div>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <button
            onClick={saveProfile}
            className="w-full py-2 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold rounded ring-rope transition-all transform hover:scale-105"
          >
            💾 SAVE PROFILE
          </button>
        </div>
      </div>
    </div>
  );
}
