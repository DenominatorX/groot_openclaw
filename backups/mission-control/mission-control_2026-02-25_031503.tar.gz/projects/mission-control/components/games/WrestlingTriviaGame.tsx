'use client';
import { useState, useEffect } from 'react';

interface Question {
  question: string;
  options: string[];
  correct: number;
  funFact: string;
  difficulty: string;
  category: string;
}

type GameMode = 'menu' | 'mode-select' | 'category-select' | 'era-select' | 'playing' | 'game-over';

const CATEGORIES = [
  { id: 'championship', emoji: '🏆', name: 'Championship History' },
  { id: 'finishing-moves', emoji: '💥', name: 'Finishing Moves' },
  { id: 'gimmicks', emoji: '🎭', name: 'Gimmicks & Characters' },
  { id: 'classic-moments', emoji: '📺', name: 'Classic Moments' },
  { id: 'wrestlemania', emoji: '🏟️', name: 'WrestleMania' },
  { id: 'attitude-era', emoji: '🔥', name: 'Attitude Era' },
  { id: 'hardcore-extreme', emoji: '💀', name: 'Hardcore & Extreme' },
  { id: 'international', emoji: '🌏', name: 'International Wrestling' },
  { id: 'aew', emoji: '🦅', name: 'AEW' },
  { id: 'golden-era', emoji: '👴', name: 'Golden Era' },
  { id: 'behind-scenes', emoji: '🏢', name: 'Behind the Scenes' },
  { id: 'promos', emoji: '🎤', name: 'Promos & Catchphrases' },
  { id: 'by-numbers', emoji: '📊', name: 'By the Numbers' },
  { id: 'tag-teams', emoji: '🤼‍♂️', name: 'Tag Teams & Stables' },
  { id: 'debuts-returns', emoji: '🌟', name: 'Debuts & Returns' },
  { id: 'entrance-themes', emoji: '🎵', name: 'Entrance Themes' },
  { id: 'year-review', emoji: '📅', name: 'Year in Review' },
  { id: 'hall-of-fame', emoji: '🏅', name: 'Hall of Fame' },
  { id: 'pop-culture', emoji: '🎬', name: 'Wrestling in Pop Culture' },
  { id: 'move-sets', emoji: '💪', name: 'Move Sets' },
];

const ERAS = [
  { id: '70s', name: 'Golden Age (1970s)' },
  { id: '80s', name: 'Territorial Era (1980s)' },
  { id: '90s', name: 'Monday Night Wars (1990s)' },
  { id: '2000s', name: 'Ruthless Aggression (2000s)' },
  { id: '2010s', name: 'Reality Era (2010s)' },
  { id: '2020s', name: 'Modern Era (2020s)' },
];

export default function WrestlingTriviaGame() {
  const [gameState, setGameState] = useState<GameMode>('menu');
  const [gameMode, setGameMode] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedEra, setSelectedEra] = useState<string>('');

  // Game state
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lives, setLives] = useState(3);
  const [answered, setAnswered] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(15);
  const [gameStats, setGameStats] = useState({
    correctCount: 0,
    categoryStats: {} as Record<string, { correct: number; total: number }>,
  });
  const [loading, setLoading] = useState(false);

  // Timer
  useEffect(() => {
    if (!answered && gameState === 'playing' && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }
    if (timeLeft === 0 && !answered && gameState === 'playing') {
      handleAnswer(null);
    }
  }, [timeLeft, answered, gameState]);

  const startGame = async (mode: string) => {
    setGameMode(mode);
    if (mode === 'quick-play') {
      await generateQuestions(null, 10, 'easy');
      setGameState('playing');
    } else if (mode === 'category-dive') {
      setGameState('category-select');
    } else if (mode === 'gauntlet') {
      await generateQuestions(null, 100, 'medium');
      setGameState('playing');
      setLives(3);
    } else if (mode === 'era-challenge') {
      setGameState('era-select');
    } else if (mode === 'company-wars') {
      await generateQuestions(null, 10, 'medium');
      setGameState('playing');
    }
  };

  const generateQuestions = async (
    category: string | null,
    count: number,
    difficulty: string
  ) => {
    setLoading(true);
    try {
      const res = await fetch('/api/games/wrestling-trivia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate',
          category: category || undefined,
          difficulty,
          count,
          era: selectedEra || undefined,
        }),
      });
      const data = await res.json();
      setQuestions(data.questions || []);
      setCurrentQuestionIndex(0);
      setScore(0);
      setStreak(0);
      setGameStats({ correctCount: 0, categoryStats: {} });
      setAnswered(false);
      setSelectedAnswer(null);
      setTimeLeft(15);
    } catch (error) {
      console.error('Failed to generate questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = async (answerIndex: number | null) => {
    if (answered || currentQuestionIndex >= questions.length) return;

    setAnswered(true);
    const question = questions[currentQuestionIndex];
    const isCorrect = answerIndex === question.correct;

    if (isCorrect) {
      let points = 100;
      const speedBonus = timeLeft > 10 ? 25 : timeLeft > 5 ? 50 : 0;
      points += speedBonus;

      // Streak multiplier
      const newStreak = streak + 1;
      const multiplier = newStreak >= 20 ? 5 : newStreak >= 10 ? 3 : newStreak >= 5 ? 2 : 1;
      points *= multiplier;

      setScore(score + points);
      setStreak(newStreak);
      setGameStats(prev => ({
        ...prev,
        correctCount: prev.correctCount + 1,
        categoryStats: {
          ...prev.categoryStats,
          [question.category]: {
            correct: (prev.categoryStats[question.category]?.correct || 0) + 1,
            total: (prev.categoryStats[question.category]?.total || 0) + 1,
          },
        },
      }));
    } else {
      setStreak(0);
      setLives(lives - 1);
      setGameStats(prev => ({
        ...prev,
        categoryStats: {
          ...prev.categoryStats,
          [question.category]: {
            correct: prev.categoryStats[question.category]?.correct || 0,
            total: (prev.categoryStats[question.category]?.total || 0) + 1,
          },
        },
      }));

      if (lives <= 1 && gameMode !== 'quick-play') {
        setTimeout(() => setGameState('game-over'), 1500);
        return;
      }
    }

    setTimeout(() => {
      if (currentQuestionIndex >= questions.length - 1) {
        setGameState('game-over');
      } else {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setAnswered(false);
        setSelectedAnswer(null);
        setTimeLeft(15);
      }
    }, 1500);
  };

  const saveScore = async () => {
    try {
      await fetch('/api/games/wrestling-trivia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save-score',
          score,
          mode: gameMode,
          questionsAnswered: currentQuestionIndex + 1,
          correctAnswers: gameStats.correctCount,
          highestStreak: streak,
        }),
      });
    } catch (error) {
      console.error('Failed to save score:', error);
    }
  };

  const resetGame = () => {
    setGameState('menu');
    setGameMode('');
    setSelectedCategory('');
    setSelectedEra('');
    setScore(0);
    setStreak(0);
    setLives(3);
    setAnswered(false);
    setSelectedAnswer(null);
    setTimeLeft(15);
  };

  const questionContent = gameState === 'playing' && questions.length > 0 ? questions[currentQuestionIndex] : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-black p-4 md:p-8">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Righteous:wght@400;700&display=swap');
        
        .wrestling-bg {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1a1a1a 100%);
          position: relative;
          overflow: hidden;
        }
        
        .wrestling-bg::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-image: repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(255,255,255,0.02) 2px, rgba(255,255,255,0.02) 4px);
          pointer-events: none;
        }
        
        .ring-rope {
          border: 3px solid;
          border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
          box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
        }
        
        .championship-belt {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
          color: #1a1a1a;
          font-weight: 900;
          text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .wrestling-title {
          font-family: 'Righteous', cursive;
          font-size: 3rem;
          font-weight: 900;
          color: #FFD700;
          text-shadow: 
            2px 2px 0 #DC143C,
            4px 4px 0 #000,
            6px 6px 0 #0000FF;
          letter-spacing: 2px;
          transform: skewY(-2deg);
        }
        
        .question-entrance {
          animation: slideInFromTop 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        
        @keyframes slideInFromTop {
          from {
            opacity: 0;
            transform: translateY(-50px) rotateX(90deg);
          }
          to {
            opacity: 1;
            transform: translateY(0) rotateX(0);
          }
        }
        
        .pyro {
          animation: pyroBlast 0.6s ease-out;
        }
        
        @keyframes pyroBlast {
          0% {
            box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.8);
            transform: scale(1);
          }
          50% {
            box-shadow: 0 0 40px 20px rgba(255, 215, 0, 0.4), 0 0 80px 40px rgba(220, 20, 60, 0.2);
          }
          100% {
            box-shadow: 0 0 0 50px rgba(255, 215, 0, 0);
            transform: scale(1.1);
          }
        }
        
        .crowd-boo {
          animation: booBounce 0.4s ease-in-out;
        }
        
        @keyframes booBounce {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-10px); }
          75% { transform: translateX(10px); }
        }
        
        .hype-bar {
          background: linear-gradient(90deg, #DC143C 0%, #FFD700 50%, #DC143C 100%);
          transition: width 0.3s ease;
          box-shadow: 0 0 10px rgba(255, 215, 0, 0.5), inset 0 0 10px rgba(0, 0, 0, 0.3);
        }
        
        .answer-btn {
          transition: all 0.2s ease;
          position: relative;
          overflow: hidden;
        }
        
        .answer-btn::before {
          content: '';
          position: absolute;
          top: -50%;
          left: -50%;
          width: 200%;
          height: 200%;
          background: radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%);
          opacity: 0;
          pointer-events: none;
        }
        
        .answer-btn:hover::before {
          animation: shine 0.5s ease;
        }
        
        @keyframes shine {
          0% {
            opacity: 0;
            transform: translate(-50%, -50%);
          }
          50% {
            opacity: 1;
          }
          100% {
            opacity: 0;
            transform: translate(100%, 100%);
          }
        }
      `}</style>

      {/* MENU STATE */}
      {gameState === 'menu' && (
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <div className="wrestling-title mb-4">🤼 WRESTLING TRIVIA 🤼</div>
          <div className="text-xl text-red-400 font-bold tracking-widest mb-8">
            IT'S STILL REAL TO ME™
          </div>
          
          <div className="space-y-3">
            <button
              onClick={() => startGame('quick-play')}
              className="w-full py-4 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              ⚡ QUICK PLAY (10 Questions)
            </button>
            <button
              onClick={() => startGame('category-dive')}
              className="w-full py-4 bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800 text-black font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              🏆 CATEGORY DEEP DIVE
            </button>
            <button
              onClick={() => startGame('gauntlet')}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              💀 GAUNTLET (3 Lives)
            </button>
            <button
              onClick={() => startGame('era-challenge')}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              📅 ERA CHALLENGE
            </button>
            <button
              onClick={() => startGame('company-wars')}
              className="w-full py-4 bg-gradient-to-r from-gray-700 to-gray-800 hover:from-gray-800 hover:to-gray-900 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
            >
              ⚔️ COMPANY WARS
            </button>
          </div>
        </div>
      )}

      {/* CATEGORY SELECT STATE */}
      {gameState === 'category-select' && (
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="wrestling-title text-center mb-8">SELECT YOUR CATEGORY</div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={async () => {
                  await generateQuestions(cat.id, 50, 'medium');
                  setSelectedCategory(cat.id);
                  setGameState('playing');
                }}
                className="p-3 bg-gradient-to-br from-slate-700 to-slate-800 hover:from-yellow-600 hover:to-yellow-700 rounded-lg ring-rope text-center transform hover:scale-110 transition-all duration-200"
              >
                <div className="text-2xl mb-1">{cat.emoji}</div>
                <div className="text-xs font-bold text-white leading-tight">{cat.name}</div>
              </button>
            ))}
          </div>
          <button
            onClick={() => setGameState('menu')}
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
          >
            ← Back
          </button>
        </div>
      )}

      {/* ERA SELECT STATE */}
      {gameState === 'era-select' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="wrestling-title text-center mb-8">PICK YOUR ERA</div>
          <div className="space-y-3">
            {ERAS.map(era => (
              <button
                key={era.id}
                onClick={async () => {
                  setSelectedEra(era.id);
                  await generateQuestions(null, 10, 'medium');
                  setGameState('playing');
                }}
                className="w-full py-3 bg-gradient-to-r from-slate-700 to-slate-800 hover:from-blue-600 hover:to-blue-700 text-white font-bold rounded-lg ring-rope transform hover:scale-105 transition-all"
              >
                {era.name}
              </button>
            ))}
          </div>
          <button
            onClick={() => setGameState('menu')}
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
          >
            ← Back
          </button>
        </div>
      )}

      {/* PLAYING STATE */}
      {gameState === 'playing' && questionContent && !loading && (
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex justify-between items-center mb-6 p-4 championship-belt rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold">🏆 {score.toLocaleString()}</div>
              <div className="text-xs font-semibold">SCORE</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">🔥 {streak}</div>
              <div className="text-xs font-semibold">STREAK</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">❤️ {lives}</div>
              <div className="text-xs font-semibold">LIVES</div>
            </div>
            <div className="text-center">
              <div className={`text-2xl font-bold ${timeLeft <= 5 ? 'text-red-500 animate-pulse' : ''}`}>
                ⏱️ {timeLeft}s
              </div>
              <div className="text-xs font-semibold">TIME</div>
            </div>
          </div>

          {/* Hype Bar */}
          <div className="mb-6 p-3 bg-slate-900 rounded-lg ring-rope">
            <div className="text-xs font-bold mb-2 text-yellow-400">CROWD ENERGY</div>
            <div className="w-full bg-slate-800 rounded-full h-4 overflow-hidden">
              <div
                className="hype-bar h-full rounded-full"
                style={{ width: `${Math.min((streak / 20) * 100, 100)}%` }}
              />
            </div>
          </div>

          {/* Question */}
          <div className="question-entrance bg-slate-800 p-6 rounded-lg ring-rope mb-6 shadow-xl">
            <div className="text-xs font-bold text-yellow-400 mb-2 uppercase">
              {questionContent.category} • {questionContent.difficulty}
            </div>
            <div className="text-2xl font-bold text-white leading-snug mb-4">
              {questionContent.question}
            </div>
            <div className="h-1 bg-gradient-to-r from-red-600 via-yellow-400 to-blue-600 rounded-full" />
          </div>

          {/* Answers */}
          <div className="space-y-3">
            {questionContent.options.map((option, idx) => {
              const isSelected = selectedAnswer === idx;
              const isCorrect = idx === questionContent.correct;
              const showCorrect = answered && isCorrect;
              const showWrong = answered && isSelected && !isCorrect;

              return (
                <button
                  key={idx}
                  onClick={() => !answered && setSelectedAnswer(idx)}
                  onDoubleClick={() => handleAnswer(idx)}
                  disabled={answered}
                  className={`answer-btn w-full p-4 rounded-lg font-bold text-left transition-all ${
                    showCorrect
                      ? 'pyro bg-green-600 text-white border-2 border-green-400'
                      : showWrong
                      ? 'crowd-boo bg-red-600 text-white border-2 border-red-400'
                      : isSelected
                      ? 'bg-yellow-500 text-black border-2 border-yellow-300'
                      : 'bg-slate-700 hover:bg-slate-600 text-white border-2 border-slate-600'
                  } ${answered ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">
                      {showCorrect ? '✓' : showWrong ? '✗' : ['A', 'B', 'C', 'D'][idx]}
                    </span>
                    <span>{option}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Hint */}
          {answered && (
            <div className="mt-6 p-4 bg-slate-800 border-l-4 border-yellow-400 rounded-lg">
              <div className="text-xs font-bold text-yellow-400 mb-2">💡 FUN FACT</div>
              <div className="text-sm text-white">{questionContent.funFact}</div>
            </div>
          )}
        </div>
      )}

      {/* LOADING STATE */}
      {loading && (
        <div className="max-w-2xl mx-auto text-center space-y-4">
          <div className="wrestling-title">🎙️ ENTERING THE RING... 🎙️</div>
          <div className="text-yellow-400 font-bold text-lg">
            IT'S STILL REAL TO ME™
          </div>
        </div>
      )}

      {/* GAME OVER STATE */}
      {gameState === 'game-over' && (
        <div className="max-w-2xl mx-auto text-center space-y-6">
          <div className="wrestling-title mb-4">
            {lives > 0 ? '🎉 VICTORY! 🎉' : '😤 DEFEATED 😤'}
          </div>

          <div className="bg-slate-800 p-8 rounded-lg ring-rope space-y-4 championship-belt">
            <div className="text-4xl font-bold">{score.toLocaleString()}</div>
            <div className="text-lg font-bold">FINAL SCORE</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-800 p-4 rounded-lg ring-rope">
              <div className="text-2xl font-bold text-green-400">{gameStats.correctCount}</div>
              <div className="text-xs font-semibold">CORRECT</div>
            </div>
            <div className="bg-slate-800 p-4 rounded-lg ring-rope">
              <div className="text-2xl font-bold text-yellow-400">{currentQuestionIndex + 1}</div>
              <div className="text-xs font-semibold">TOTAL</div>
            </div>
            <div className="bg-slate-800 p-4 rounded-lg ring-rope">
              <div className="text-2xl font-bold text-red-400">{streak}</div>
              <div className="text-xs font-semibold">MAX STREAK</div>
            </div>
            <div className="bg-slate-800 p-4 rounded-lg ring-rope">
              <div className="text-2xl font-bold text-blue-400">
                {((gameStats.correctCount / (currentQuestionIndex + 1)) * 100).toFixed(0)}%
              </div>
              <div className="text-xs font-semibold">ACCURACY</div>
            </div>
          </div>

          <button
            onClick={async () => {
              await saveScore();
              resetGame();
            }}
            className="w-full py-4 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold text-lg rounded-lg ring-rope shadow-lg transform hover:scale-105 transition-all"
          >
            🔄 REMATCH
          </button>

          <button
            onClick={() => resetGame()}
            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
          >
            ← Back to Main Menu
          </button>
        </div>
      )}
    </div>
  );
}
