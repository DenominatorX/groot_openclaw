'use client';
import { useState, useRef, useEffect } from 'react';

interface ChatMessage {
  playerId: string;
  name: string;
  message: string;
  timestamp: string;
}

interface ChatPanelProps {
  roomCode: string;
  playerId: string;
  playerName: string;
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
}

const QUICK_REACTIONS = ['🔥', '💀', '😂', '👏', '🤦', '💪'];

export default function ChatPanel({
  roomCode,
  playerId,
  playerName,
  messages,
  onSendMessage,
}: ChatPanelProps) {
  const [messageText, setMessageText] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      const container = messagesEndRef.current.parentElement;
      if (container && container.scrollTop > container.scrollHeight - 200) {
        messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!messageText.trim()) return;
    onSendMessage(messageText);
    setMessageText('');
  };

  const handleQuickReaction = (emoji: string) => {
    onSendMessage(emoji);
  };

  if (isCollapsed) {
    return (
      <button
        onClick={() => setIsCollapsed(false)}
        className="fixed bottom-4 right-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white rounded-full p-4 shadow-lg z-40"
      >
        💬
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-slate-800 rounded-lg ring-rope overflow-hidden shadow-xl z-40">
      <style>{`
        .ring-rope {
          border: 3px solid;
          border-image: linear-gradient(90deg, #DC143C 0%, #FFFFFF 50%, #0000FF 100%) 1;
          box-shadow: 0 0 20px rgba(220, 20, 60, 0.4), inset 0 0 20px rgba(0, 0, 0, 0.5);
        }

        .championship-belt {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);
          color: #1a1a1a;
          font-weight: 900;
        }
      `}</style>

      {/* Header */}
      <div className="championship-belt p-3 flex items-center justify-between">
        <div className="font-bold text-sm">CHAT ARENA 💬</div>
        <button
          onClick={() => setIsCollapsed(true)}
          className="text-lg font-bold hover:scale-110"
        >
          ⎯
        </button>
      </div>

      {/* Messages */}
      <div className="h-64 overflow-y-auto bg-slate-900 border-b border-slate-700 space-y-2 p-3">
        {messages.length === 0 && (
          <div className="text-center text-gray-400 text-sm mt-8">
            <div>No messages yet</div>
            <div className="text-xs mt-2">👇 Be the first to speak! 👇</div>
          </div>
        )}

        {messages.map((msg, idx) => {
          const isMe = msg.playerId === playerId;
          const time = new Date(msg.timestamp).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          });

          return (
            <div key={idx} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                  isMe
                    ? 'bg-yellow-600 text-white'
                    : 'bg-slate-700 text-white'
                }`}
              >
                {!isMe && <div className="text-xs font-bold text-gray-300">{msg.name}</div>}
                <div className="break-words">{msg.message}</div>
                <div className="text-xs opacity-70 mt-1">{time}</div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Reactions */}
      <div className="bg-slate-800 p-2 border-b border-slate-700 flex gap-1 flex-wrap">
        {QUICK_REACTIONS.map(emoji => (
          <button
            key={emoji}
            onClick={() => handleQuickReaction(emoji)}
            className="text-xl hover:scale-125 transition-transform"
          >
            {emoji}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="bg-slate-800 p-3 space-y-2">
        <div className="flex gap-2">
          <input
            type="text"
            value={messageText}
            onChange={e => setMessageText(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
            placeholder="Say something..."
            maxLength={100}
            className="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white text-sm placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
          />
          <button
            onClick={handleSendMessage}
            disabled={!messageText.trim()}
            className="px-3 py-2 bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50 text-white font-semibold rounded transition-colors text-sm"
          >
            Send
          </button>
        </div>
        <div className="text-xs text-gray-400 text-right">{messageText.length}/100</div>
      </div>
    </div>
  );
}
