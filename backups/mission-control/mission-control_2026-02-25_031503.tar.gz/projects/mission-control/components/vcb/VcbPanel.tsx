'use client';

import { useState } from 'react';
import VcbStatusBar from './VcbStatusBar';
import BranchTreeView from './BranchTreeView';
import CalendarDrawer from './CalendarDrawer';
import { useVcbBranches } from '@/hooks/useVcbBranches';

// TypeScript interfaces from PLAN.md §4
interface Branch {
  id: string;
  name: string;
  parent_id: string | null;
  status: 'active' | 'merged' | 'archived' | 'stale';
  description: string | null;
  color: string;
  created_at: string;
  updated_at: string;
  last_commit_id?: string;
  last_commit_message?: string;
  last_commit_author?: string;
  last_commit_at?: string;
  commit_count?: number;
  snapshot_count?: number;
}

export default function VcbPanel() {
  const [calendarOpen, setCalendarOpen] = useState(false);
  const { branches, loading, error, refetch } = useVcbBranches();
  
  return (
    <div className="flex flex-col min-h-[60vh] bg-[--mc-bg]">
      {/* Status Bar with Calendar + New Branch buttons */}
      <VcbStatusBar
        branches={branches}
        onCalendarOpen={() => setCalendarOpen(true)}
      />
      
      {/* Main Content */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        <BranchTreeView
          branches={branches}
          loading={loading}
          onRefresh={refetch}
        />
        
        {error && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
            <p className="text-red-400 text-sm">{error}</p>
            <button
              onClick={refetch}
              className="mt-2 text-red-400 text-xs hover:underline"
            >
              Try again
            </button>
          </div>
        )}
      </div>
      
      {/* Calendar Drawer Overlay */}
      <CalendarDrawer
        open={calendarOpen}
        onClose={() => setCalendarOpen(false)}
      />
    </div>
  );
}
