'use client';

import { useState, useMemo } from 'react';
import BranchCard from './BranchCard';

// TypeScript interfaces from PLAN.md §4
interface Branch {
  id: string;
  name: string;
  parent_id: string | null;
  status: 'active' | 'merged' | 'archived' | 'stale';
  description: string | null;
  color: string;
  created_at: string;
  updated_at: string;
  last_commit_id?: string;
  last_commit_message?: string;
  last_commit_author?: string;
  last_commit_at?: string;
  commit_count?: number;
  snapshot_count?: number;
}

interface BranchTreeViewProps {
  branches: Branch[];
  loading: boolean;
  onRefresh: () => void;
}

interface BranchWithDepth extends Branch {
  depth: number;
  hasChildren: boolean;
}

// Sorting algorithm: roots first, then depth-first children
function sortBranches(branches: Branch[]): BranchWithDepth[] {
  const branchMap = new Map<string, BranchWithDepth>();
  const childrenMap = new Map<string, Branch[]>();
  
  // First pass: create entries and organize children
  branches.forEach((branch) => {
    branchMap.set(branch.id, { ...branch, depth: 0, hasChildren: false });
    
    if (!childrenMap.has(branch.parent_id || '')) {
      childrenMap.set(branch.parent_id || '', []);
    }
    if (branch.parent_id) {
      childrenMap.get(branch.parent_id)?.push(branch);
    }
  });
  
  // Mark which branches have children
  branches.forEach((branch) => {
    const existing = branchMap.get(branch.id);
    if (existing && childrenMap.has(branch.id)) {
      existing.hasChildren = childrenMap.get(branch.id)!.length > 0;
    }
  });
  
  // Depth-first traversal
  const result: BranchWithDepth[] = [];
  
  function addBranchWithChildren(branchId: string, depth: number) {
    const branch = branchMap.get(branchId);
    if (!branch) return;
    
    branch.depth = depth;
    result.push(branch);
    
    const children = childrenMap.get(branchId) || [];
    // Sort children by created_at
    children.sort((a, b) => 
      new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );
    
    children.forEach((child) => addBranchWithChildren(child.id, depth + 1));
  }
  
  // Find roots (parent_id === null) and traverse
  const roots = branches
    .filter((b) => b.parent_id === null)
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  
  roots.forEach((root) => addBranchWithChildren(root.id, 0));
  
  return result;
}

export default function BranchTreeView({ branches, loading, onRefresh }: BranchTreeViewProps) {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  
  const sortedBranches = useMemo(() => sortBranches(branches), [branches]);
  
  const toggleExpand = (id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };
  
  // Loading state: 4 skeleton rows
  if (loading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="animate-pulse bg-[--mc-border] rounded-lg h-16 w-full"
          />
        ))}
      </div>
    );
  }
  
  // Empty state
  if (branches.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <p className="text-[--mc-muted] text-sm mb-4">No branches yet.</p>
        <button
          onClick={onRefresh}
          className="flex items-center gap-2 px-4 py-2 bg-[--mc-surface] border border-[--mc-border] 
                     rounded-lg text-[--mc-text] text-sm hover:border-[--mc-accent]/50 transition-colors"
        >
          <span>＋</span>
          <span>Create branch</span>
        </button>
      </div>
    );
  }
  
  return (
    <div className="space-y-2">
      {sortedBranches.map((branch) => (
        <div key={branch.id}>
          <BranchCard
            branch={branch}
            depth={branch.depth}
            expanded={expandedIds.has(branch.id)}
            hasChildren={branch.hasChildren}
            onToggleExpand={() => toggleExpand(branch.id)}
            onStatusChange={() => {}}
          />
          
          {/* Children with max-height transition */}
          {branch.hasChildren && branch.depth > 0 && (
            <div
              className={`ml-6 border-l border-[--mc-border] pl-4 overflow-hidden transition-all duration-200 ${
                expandedIds.has(branch.id) ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0'
              }`}
            >
              {sortedBranches
                .filter((b) => b.parent_id === branch.id)
                .map((child) => (
                  <div key={child.id} className="mt-2">
                    <BranchCard
                      branch={child}
                      depth={child.depth}
                      expanded={expandedIds.has(child.id)}
                      hasChildren={child.hasChildren}
                      onToggleExpand={() => toggleExpand(child.id)}
                      onStatusChange={() => {}}
                    />
                  </div>
                ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
