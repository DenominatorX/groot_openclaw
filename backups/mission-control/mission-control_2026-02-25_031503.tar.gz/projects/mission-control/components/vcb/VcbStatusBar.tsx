'use client';

import { useState } from 'react';

interface Branch {
  id: string;
  name: string;
  parent_id: string | null;
  status: 'active' | 'merged' | 'archived' | 'stale';
  description: string | null;
  color: string;
  created_at: string;
  updated_at: string;
  last_commit_id?: string;
  last_commit_message?: string;
  last_commit_author?: string;
  last_commit_at?: string;
  commit_count?: number;
  snapshot_count?: number;
}

interface VcbStatusBarProps {
  branches: Branch[];
  onBranchCreated?: () => void;
  onCalendarOpen?: () => void;
}

const COLOR_SWATCHES = [
  '#6366f1',
  '#22c55e',
  '#f59e0b',
  '#ef4444',
  '#3b82f6',
  '#ec4899',
];

export default function VcbStatusBar({ branches, onBranchCreated, onCalendarOpen }: VcbStatusBarProps) {
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState('');
  const [description, setDescription] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLOR_SWATCHES[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const totalBranches = branches.length;
  const activeCount = branches.filter((b) => b.status === 'active').length;
  const mergedCount = branches.filter((b) => b.status === 'merged').length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/vcb/branches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          parent_id: parentId || null,
          description: description.trim() || null,
          color: selectedColor,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to create branch');
      }

      setShowModal(false);
      setName('');
      setParentId('');
      setDescription('');
      setSelectedColor(COLOR_SWATCHES[0]);
      onBranchCreated?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 border-b border-[--mc-border]">
        <div className="flex items-center gap-3">
          {/* Total Branches */}
          <span className="bg-[--mc-surface] text-[--mc-text] text-sm font-medium px-3 py-1 rounded-full border border-[--mc-border]">
            🌿 {totalBranches} Branches
          </span>

          {/* Active */}
          <span className="bg-[--mc-surface] text-[--mc-text] text-sm font-medium px-3 py-1 rounded-full border border-[--mc-border]">
            ✅ {activeCount} Active
          </span>

          {/* Merged */}
          <span className="bg-[--mc-surface] text-[--mc-text] text-sm font-medium px-3 py-1 rounded-full border border-[--mc-border]">
            🔀 {mergedCount} Merged
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Calendar Button */}
          {onCalendarOpen && (
            <button
              onClick={onCalendarOpen}
              className="flex items-center gap-1 px-3 py-1.5 bg-[--mc-surface] border border-[--mc-border] text-[--mc-text] text-sm font-medium rounded-lg hover:border-[--mc-accent]/50 transition-colors"
            >
              <span>📅</span>
              <span>Calendar</span>
            </button>
          )}
          {/* New Branch Button */}
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-1 px-3 py-1.5 bg-[--mc-accent] text-[--mc-bg] text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
          >
            <span>＋</span>
            <span>New Branch</span>
          </button>
        </div>
      </div>

      {/* Modal Overlay */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-[--mc-surface] border border-[--mc-border] rounded-xl p-6 w-full max-w-md">
            <h2 className="text-[--mc-text] font-bold text-lg mb-4">Create New Branch</h2>

            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              {/* Name Input */}
              <div>
                <label className="text-[--mc-muted] text-xs block mb-1">Name *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="feature/my-branch"
                  required
                  maxLength={128}
                  className="w-full px-3 py-2 bg-[--mc-bg] border border-[--mc-border] rounded-lg text-[--mc-text] text-sm focus:outline-none focus:border-[--mc-accent]"
                />
              </div>

              {/* Parent Select */}
              <div>
                <label className="text-[--mc-muted] text-xs block mb-1">Parent Branch</label>
                <select
                  value={parentId}
                  onChange={(e) => setParentId(e.target.value)}
                  className="w-full px-3 py-2 bg-[--mc-bg] border border-[--mc-border] rounded-lg text-[--mc-text] text-sm focus:outline-none focus:border-[--mc-accent]"
                >
                  <option value="">None (root branch)</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Description Input */}
              <div>
                <label className="text-[--mc-muted] text-xs block mb-1">Description</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Optional description..."
                  className="w-full px-3 py-2 bg-[--mc-bg] border border-[--mc-border] rounded-lg text-[--mc-text] text-sm focus:outline-none focus:border-[--mc-accent]"
                />
              </div>

              {/* Color Swatches */}
              <div>
                <label className="text-[--mc-muted] text-xs block mb-2">Color</label>
                <div className="flex gap-2">
                  {COLOR_SWATCHES.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setSelectedColor(color)}
                      className={`w-8 h-8 rounded-full border-2 transition-transform ${
                        selectedColor === color
                          ? 'border-[--mc-text] scale-110'
                          : 'border-transparent'
                      }`}
                      style={{ background: color }}
                    />
                  ))}
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <p className="text-red-400 text-sm">{error}</p>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 border border-[--mc-border] text-[--mc-text] text-sm font-medium rounded-lg hover:bg-[--mc-border]/50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading || !name.trim()}
                  className="flex-1 px-4 py-2 bg-[--mc-accent] text-[--mc-bg] text-sm font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  {loading ? 'Creating...' : 'Create Branch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}