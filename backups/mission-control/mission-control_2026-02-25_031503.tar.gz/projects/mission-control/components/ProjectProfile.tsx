/* @ts-nocheck */
'use client';
import React, { useState, useEffect, useCallback, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import TeamBuilder from './TeamBuilder';
import ProjectLifecycle from './ProjectLifecycle';
import XPBar from './shared/XPBar';
import XPBadge from './shared/XPBadge';
import EfficiencyMetric from './shared/EfficiencyMetric';
import ProjectChat from './ProjectChat';
import ProtocolBuilderTab from './ProtocolBuilder/ProtocolBuilderTab';

interface ProjectAgent { agentId: string; role: string; }
interface Phase {
  id: string; name: string; description: string;
  requirements?: string[]; status: string; tasks?: any[];
}
interface Project {
  id: string; name: string; description: string; status: string;
  priority: string; goals: string[]; agents: ProjectAgent[];
  createdAt: string; updatedAt: string; stats: any;
  title?: string; assignee?: string; roles?: any[]; phases?: Phase[];
  created?: string; updated?: string; tags?: string[];
  activity?: any[];
  parentProjectId?: string | null;
  creator?: string;
  team?: { agentId: string; roleId: string; roleTitle: string; rules: string[]; expectedDocuments: string[] }[];
}

const AVAILABLE_MODELS = [
  'anthropic/claude-opus-4-6',
  'openrouter/minimax/minimax-m2.5',
  'openrouter/google/gemini-2.5-pro',
  'openrouter/google/gemini-3-pro-preview',
  'x-ai/grok-3',
  'x-ai/grok-4',
  'openrouter/x-ai/grok-4.1-fast',
  'lmstudio/gemma-3-12b',
];

const ROLES = [
  'Project Manager', 'Lead Developer', 'Frontend Developer', 'Backend Developer',
  'Full-Stack Developer', 'Designer/UX', 'QA/Testing Lead', 'Requirements & Documentation',
  'DevOps/Infrastructure', 'Data & Analytics', 'Research & Analysis', 'Security',
  'Creative & Content', 'Technical Writer', 'Architect',
];

const STATUS_OPTIONS = ['planning', 'active', 'in-progress', 'on-hold', 'completed', 'review', 'complete'];
const PRIORITY_OPTIONS = ['low', 'medium', 'high', 'critical'];
const PHASE_STATUSES = ['todo', 'in-progress', 'review', 'complete', 'blocked'];
const ASSIGNEES = ['Kevin (Me)', 'Groot', 'Jimmy T', 'Dr. Al', 'Dirty Bird', 'CEO', 'Brain'];
const TASK_ASSIGNEES = ['Kevin (Me)', 'Groot', 'Jimmy T', 'CEO', 'Dr. Al', 'Dirty Bird', 'Brain', 'Swift', 'Pixel', 'Forge', 'Spark', 'Atlas', 'Nova', 'Cipher', 'Runner', 'Tank', 'Worker B', 'The Archivist', 'The Interrogator', 'The Therapist'];

const STATUS_COLORS: Record<string, string> = {
  'planning': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  'active': 'bg-green-500/20 text-green-400 border-green-500/30',
  'in-progress': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'review': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'complete': 'bg-green-500/20 text-green-400 border-green-500/30',
  'completed': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  'blocked': 'bg-red-500/20 text-red-400 border-red-500/30',
  'todo': 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  'on-hold': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
};

// ══════════════════════════════════════════════════════════════
// TEST PLAN TAB
// ══════════════════════════════════════════════════════════════
type TestStatus = 'pending' | 'pass' | 'fail' | 'skip' | 'blocked';
interface TestCase {
  id: string; title: string; description: string; status: TestStatus;
  comment: string; category: string;
}

const TEST_STATUS_COLORS: Record<TestStatus, string> = {
  pending: 'bg-gray-500/20 text-gray-400',
  pass: 'bg-green-500/20 text-green-400',
  fail: 'bg-red-500/20 text-red-400',
  skip: 'bg-yellow-500/20 text-yellow-400',
  blocked: 'bg-orange-500/20 text-orange-400',
};

const TEST_STATUS_ICONS: Record<TestStatus, string> = {
  pending: '⏳', pass: '✅', fail: '❌', skip: '⏭️', blocked: '🚫',
};

function TestPlanTab({ projectId, projectTitle }: { projectId: string; projectTitle: string }) {
  const [tests, setTests] = useState<TestCase[]>([]);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('general');
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [autoGenerating, setAutoGenerating] = useState(false);

  useEffect(() => {
    fetch(`/api/tests?projectId=${projectId}`).then(r => r.json())
      .then(d => setTests(d.tests || []))
      .catch(() => {});
  }, [projectId]);

  const saveTests = async (updated: TestCase[]) => {
    setTests(updated);
    await fetch('/api/tests', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, tests: updated }),
    });
  };

  const addTest = () => {
    if (!newTitle.trim()) return;
    const tc: TestCase = {
      id: `test-${Date.now()}`, title: newTitle.trim(), description: '',
      status: 'pending', comment: '', category: newCategory,
    };
    saveTests([...tests, tc]);
    setNewTitle('');
  };

  const updateTest = (id: string, field: string, value: string) => {
    saveTests(tests.map(t => t.id === id ? { ...t, [field]: value } : t));
  };

  const removeTest = (id: string) => {
    saveTests(tests.filter(t => t.id !== id));
  };

  const scanDefects = async () => {
    setScanning(true);
    setScanResult(null);
    try {
      const r = await fetch('/api/tests/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, projectTitle, tests }),
      });
      const d = await r.json();
      setScanResult(d.plan || d.error || 'No results');
    } catch { setScanResult('Scan failed — check API key settings.'); }
    setScanning(false);
  };

  const autoGenerateTests = async () => {
    setAutoGenerating(true);
    try {
      const r = await fetch('/api/tests/auto-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, projectTitle }),
      });
      const d = await r.json();
      if (d.tests && d.tests.length > 0) {
        const existingTitles = new Set(tests.map(t => t.title.toLowerCase()));
        const newTests = d.tests.filter((t: TestCase) => !existingTitles.has(t.title.toLowerCase()));
        if (newTests.length > 0) saveTests([...tests, ...newTests]);
      }
    } catch {}
    setAutoGenerating(false);
  };

  const passed = tests.filter(t => t.status === 'pass').length;
  const failed = tests.filter(t => t.status === 'fail').length;
  const total = tests.length;
  const categories = [...new Set(tests.map(t => t.category || 'general'))];

  return (
    <div className="space-y-4 relative">
      {/* Summary Stats */}
      <div className="grid grid-cols-5 gap-2">
        {(['pending', 'pass', 'fail', 'skip', 'blocked'] as TestStatus[]).map(s => (
          <div key={s} className={`rounded-lg p-2 text-center text-xs font-semibold ${TEST_STATUS_COLORS[s]}`}>
            {TEST_STATUS_ICONS[s]} {tests.filter(t => t.status === s).length} {s}
          </div>
        ))}
      </div>

      {/* Progress bar */}
      {total > 0 && (
        <div>
          <div className="flex justify-between text-xs text-mc-muted mb-1">
            <span>{passed + failed}/{total} tested</span>
            <span>{total > 0 ? Math.round((passed / total) * 100) : 0}% pass rate</span>
          </div>
          <div className="h-2 bg-mc-bg rounded-full overflow-hidden flex">
            <div className="bg-green-500 h-full transition-all" style={{ width: `${(passed / total) * 100}%` }} />
            <div className="bg-red-500 h-full transition-all" style={{ width: `${(failed / total) * 100}%` }} />
          </div>
        </div>
      )}

      {/* Add Test */}
      <div className="flex gap-2">
        <input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="New test case..."
          onKeyDown={e => e.key === 'Enter' && addTest()}
          className="flex-1 bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm text-mc-text" />
        <select value={newCategory} onChange={e => setNewCategory(e.target.value)}
          className="bg-mc-bg border border-mc-border rounded px-2 py-1.5 text-sm text-mc-text">
          <option value="general">General</option>
          <option value="ui">UI</option>
          <option value="api">API</option>
          <option value="performance">Performance</option>
          <option value="security">Security</option>
          <option value="integration">Integration</option>
        </select>
        <button onClick={addTest} className="bg-mc-accent text-white px-3 py-1.5 rounded text-sm hover:opacity-80">+ Add</button>
        <button onClick={autoGenerateTests} disabled={autoGenerating}
          className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-3 py-1.5 rounded text-sm hover:opacity-90 disabled:opacity-50 whitespace-nowrap">
          {autoGenerating ? '🔄 Generating...' : '🤖 Auto-Generate Tests'}
        </button>
      </div>

      {/* Test Cases by Category */}
      {categories.map(cat => (
        <div key={cat}>
          <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">{cat}</h4>
          <div className="space-y-1">
            {tests.filter(t => (t.category || 'general') === cat).map(tc => (
              <div key={tc.id} className="bg-mc-bg border border-mc-border rounded-lg p-2">
                <div className="flex items-center gap-2">
                  <select value={tc.status} onChange={e => updateTest(tc.id, 'status', e.target.value)}
                    className={`text-xs px-2 py-1 rounded font-semibold ${TEST_STATUS_COLORS[tc.status]} bg-transparent border border-current cursor-pointer`}>
                    {(['pending', 'pass', 'fail', 'skip', 'blocked'] as TestStatus[]).map(s => (
                      <option key={s} value={s}>{TEST_STATUS_ICONS[s]} {s}</option>
                    ))}
                  </select>
                  <span className="text-sm text-mc-text flex-1">{tc.title}</span>
                  <button onClick={() => removeTest(tc.id)} className="text-mc-muted hover:text-red-400 text-xs">✕</button>
                </div>
                {tc.status === 'fail' && (
                  <textarea value={tc.comment} onChange={e => updateTest(tc.id, 'comment', e.target.value)}
                    placeholder="Describe what failed..."
                    className="mt-2 w-full bg-red-500/5 border border-red-500/20 rounded px-2 py-1 text-xs text-mc-text resize-none"
                    rows={2} />
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      {tests.length === 0 && (
        <div className="text-center text-mc-muted py-8 text-sm">
          No test cases yet. Add your first test above.
        </div>
      )}

      {/* AI Defect Scanner */}
      {failed > 0 && (
        <div className="border-t border-mc-border pt-4">
          <button onClick={scanDefects} disabled={scanning}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-2.5 rounded-lg text-sm font-semibold hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2">
            {scanning ? '🔄 Scanning defects...' : '🤖 AI Defect Scanner — Analyze Failures & Create Fix Plan'}
          </button>
          {scanResult && (
            <div className="mt-3 bg-mc-bg border border-mc-border rounded-lg p-3 text-xs text-mc-text whitespace-pre-wrap max-h-64 overflow-y-auto">
              {scanResult}
            </div>
          )}
        </div>
      )}

    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// RISK ASSESSMENT TAB
// ══════════════════════════════════════════════════════════════
type RiskSeverity = 'low' | 'medium' | 'high' | 'critical';
type RiskLikelihood = 'unlikely' | 'possible' | 'likely' | 'certain';
type RiskStatus = 'identified' | 'mitigating' | 'mitigated' | 'accepted' | 'escalated';

interface Risk {
  id: string; title: string; description: string;
  severity: RiskSeverity; likelihood: RiskLikelihood;
  mitigation: string; owner: string; status: RiskStatus;
  createdAt: string;
}

const SEVERITY_COLORS: Record<RiskSeverity, string> = {
  low: 'bg-green-500/20 text-green-400',
  medium: 'bg-yellow-500/20 text-yellow-400',
  high: 'bg-orange-500/20 text-orange-400',
  critical: 'bg-red-500/20 text-red-400',
};

interface Prerequisite {
  id: string; title: string; type: 'project' | 'task' | 'external' | 'config';
  sourceId?: string; status: 'pending' | 'in-progress' | 'met' | 'blocked';
  description: string;
}

function RiskAssessmentTab({ projectId }: { projectId: string }) {
  const [risks, setRisks] = useState<Risk[]>([]);
  const [prereqs, setPrereqs] = useState<Prerequisite[]>([]);
  const [adding, setAdding] = useState(false);
  const [autoGenRisks, setAutoGenRisks] = useState(false);
  const [autoGenPrereqs, setAutoGenPrereqs] = useState(false);
  const [newRisk, setNewRisk] = useState({ title: '', description: '', severity: 'medium' as RiskSeverity, likelihood: 'possible' as RiskLikelihood, mitigation: '', owner: 'Groot' });

  useEffect(() => {
    fetch(`/api/risks?projectId=${projectId}`).then(r => r.json())
      .then(d => { setRisks(d.risks || []); setPrereqs(d.prerequisites || []); })
      .catch(() => {});
  }, [projectId]);

  const savePrereqs = async (updated: Prerequisite[]) => {
    setPrereqs(updated);
    await fetch('/api/risks', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, risks, prerequisites: updated }),
    });
  };

  const autoGenerateRisks = async () => {
    setAutoGenRisks(true);
    try {
      const r = await fetch('/api/risks/auto-generate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId }),
      });
      const d = await r.json();
      if (d.risks?.length) {
        const merged = [...risks, ...d.risks.filter((nr: Risk) => !risks.some(er => er.title === nr.title))];
        saveRisks(merged);
      }
    } catch { /* */ }
    setAutoGenRisks(false);
  };

  const autoGeneratePrereqs = async () => {
    setAutoGenPrereqs(true);
    try {
      const r = await fetch('/api/risks/auto-generate-prereqs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId }),
      });
      const d = await r.json();
      if (d.prerequisites?.length) {
        const merged = [...prereqs, ...d.prerequisites.filter((np: Prerequisite) => !prereqs.some(ep => ep.title === np.title))];
        savePrereqs(merged);
      }
    } catch { /* */ }
    setAutoGenPrereqs(false);
  };

  const saveRisks = async (updated: Risk[]) => {
    setRisks(updated);
    await fetch('/api/risks', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, risks: updated, prerequisites: prereqs }),
    });
  };

  const addRisk = () => {
    if (!newRisk.title.trim()) return;
    const r: Risk = {
      ...newRisk, id: `risk-${Date.now()}`, status: 'identified',
      createdAt: new Date().toISOString(),
    };
    saveRisks([...risks, r]);
    setNewRisk({ title: '', description: '', severity: 'medium', likelihood: 'possible', mitigation: '', owner: 'Groot' });
    setAdding(false);
  };

  const updateRisk = (id: string, field: string, value: string) => {
    saveRisks(risks.map(r => r.id === id ? { ...r, [field]: value } : r));
  };

  const removeRisk = (id: string) => saveRisks(risks.filter(r => r.id !== id));

  const riskScore = (r: Risk) => {
    const sev = { low: 1, medium: 2, high: 3, critical: 4 }[r.severity] || 2;
    const lik = { unlikely: 1, possible: 2, likely: 3, certain: 4 }[r.likelihood] || 2;
    return sev * lik;
  };

  const sorted = [...risks].sort((a, b) => riskScore(b) - riskScore(a));

  return (
    <div className="space-y-4">
      {/* Risk Matrix Summary */}
      <div className="grid grid-cols-4 gap-2">
        {(['critical', 'high', 'medium', 'low'] as RiskSeverity[]).map(s => (
          <div key={s} className={`rounded-lg p-2 text-center text-xs font-semibold ${SEVERITY_COLORS[s]}`}>
            {risks.filter(r => r.severity === s).length} {s}
          </div>
        ))}
      </div>

      {/* Add Risk Button */}
      {!adding ? (
        <button onClick={() => setAdding(true)} className="text-sm text-mc-accent hover:underline">+ Add Risk</button>
      ) : (
        <div className="bg-mc-bg border border-mc-border rounded-lg p-3 space-y-2">
          <input value={newRisk.title} onChange={e => setNewRisk({ ...newRisk, title: e.target.value })}
            placeholder="Risk title..." className="w-full bg-transparent border border-mc-border rounded px-2 py-1.5 text-sm text-mc-text" />
          <textarea value={newRisk.description} onChange={e => setNewRisk({ ...newRisk, description: e.target.value })}
            placeholder="Describe the risk..." className="w-full bg-transparent border border-mc-border rounded px-2 py-1.5 text-xs text-mc-text" rows={2} />
          <div className="flex gap-2">
            <select value={newRisk.severity} onChange={e => setNewRisk({ ...newRisk, severity: e.target.value as RiskSeverity })}
              className="bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text">
              <option value="low">Low</option><option value="medium">Medium</option>
              <option value="high">High</option><option value="critical">Critical</option>
            </select>
            <select value={newRisk.likelihood} onChange={e => setNewRisk({ ...newRisk, likelihood: e.target.value as RiskLikelihood })}
              className="bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text">
              <option value="unlikely">Unlikely</option><option value="possible">Possible</option>
              <option value="likely">Likely</option><option value="certain">Certain</option>
            </select>
            <select value={newRisk.owner} onChange={e => setNewRisk({ ...newRisk, owner: e.target.value })}
              className="bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text">
              {TASK_ASSIGNEES.map(a => <option key={a} value={a}>{a}</option>)}
            </select>
          </div>
          <textarea value={newRisk.mitigation} onChange={e => setNewRisk({ ...newRisk, mitigation: e.target.value })}
            placeholder="Mitigation plan..." className="w-full bg-transparent border border-mc-border rounded px-2 py-1.5 text-xs text-mc-text" rows={2} />
          <div className="flex gap-2">
            <button onClick={addRisk} className="bg-mc-accent text-white px-3 py-1 rounded text-xs">Add Risk</button>
            <button onClick={() => setAdding(false)} className="text-mc-muted text-xs hover:text-mc-text">Cancel</button>
          </div>
        </div>
      )}

      {/* Risk List */}
      {sorted.map(risk => (
        <div key={risk.id} className="bg-mc-bg border border-mc-border rounded-lg p-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs px-2 py-0.5 rounded font-semibold ${SEVERITY_COLORS[risk.severity]}`}>
                  {risk.severity.toUpperCase()}
                </span>
                <span className="text-xs text-mc-muted">{risk.likelihood}</span>
                <span className="text-xs text-mc-muted">Score: {riskScore(risk)}</span>
                <select value={risk.status} onChange={e => updateRisk(risk.id, 'status', e.target.value)}
                  className="ml-auto text-xs bg-transparent border border-mc-border rounded px-1 py-0.5 text-mc-text cursor-pointer">
                  <option value="identified">Identified</option><option value="mitigating">Mitigating</option>
                  <option value="mitigated">Mitigated</option><option value="accepted">Accepted</option>
                  <option value="escalated">Escalated</option>
                </select>
              </div>
              <div className="text-sm font-medium text-mc-text">{risk.title}</div>
              {risk.description && <div className="text-xs text-mc-muted mt-1">{risk.description}</div>}
              {risk.mitigation && (
                <div className="text-xs mt-2 p-2 bg-green-500/5 border border-green-500/20 rounded">
                  <span className="text-green-400 font-semibold">Mitigation:</span> {risk.mitigation}
                </div>
              )}
              <div className="text-xs text-mc-muted mt-1">Owner: {risk.owner}</div>
            </div>
            <button onClick={() => removeRisk(risk.id)} className="text-mc-muted hover:text-red-400 text-xs">✕</button>
          </div>
        </div>
      ))}

      {/* Prerequisites Section */}
      <div className="border-t border-mc-border pt-4">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">📋 Prerequisites</h4>
          <button onClick={autoGeneratePrereqs} disabled={autoGenPrereqs}
            className="text-xs bg-blue-600/20 text-blue-400 px-2 py-1 rounded hover:bg-blue-600/30 disabled:opacity-50">
            {autoGenPrereqs ? '🔄 Analyzing...' : '🤖 Auto-Detect Prerequisites'}
          </button>
        </div>
        {prereqs.length === 0 ? (
          <div className="text-xs text-mc-muted text-center py-3">No prerequisites identified. Hit Auto-Detect to analyze project dependencies.</div>
        ) : (
          <div className="space-y-1">
            {prereqs.map(p => (
              <div key={p.id} className="bg-mc-bg border border-mc-border rounded-lg p-2 flex items-center gap-2">
                <select value={p.status} onChange={e => {
                  savePrereqs(prereqs.map(pr => pr.id === p.id ? { ...pr, status: e.target.value as Prerequisite['status'] } : pr));
                }} className="text-xs bg-transparent border border-mc-border rounded px-1 py-0.5 text-mc-text cursor-pointer">
                  <option value="pending">⏳ Pending</option>
                  <option value="in-progress">🔄 In Progress</option>
                  <option value="met">✅ Met</option>
                  <option value="blocked">🚫 Blocked</option>
                </select>
                <span className={`text-xs px-1.5 py-0.5 rounded ${
                  p.type === 'project' ? 'bg-purple-500/20 text-purple-400' :
                  p.type === 'task' ? 'bg-blue-500/20 text-blue-400' :
                  p.type === 'config' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-gray-500/20 text-gray-400'
                }`}>{p.type}</span>
                <div className="flex-1">
                  <div className="text-sm text-mc-text">{p.title}</div>
                  {p.description && <div className="text-xs text-mc-muted">{p.description}</div>}
                </div>
                <button onClick={() => savePrereqs(prereqs.filter(pr => pr.id !== p.id))}
                  className="text-mc-muted hover:text-red-400 text-xs">✕</button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Auto-Generate Buttons */}
      <div className="border-t border-mc-border pt-4 flex gap-2">
        <button onClick={autoGenerateRisks} disabled={autoGenRisks}
          className="flex-1 bg-gradient-to-r from-orange-600 to-red-600 text-white py-2 rounded-lg text-xs font-semibold hover:opacity-90 disabled:opacity-50">
          {autoGenRisks ? '🔄 Generating...' : '🤖 Auto-Generate Risk Assessment'}
        </button>
      </div>

      {risks.length === 0 && prereqs.length === 0 && !adding && (
        <div className="text-center text-mc-muted py-4 text-sm">No risks or prerequisites yet. Use Auto-Generate or add manually.</div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// TEAM CHAT TAB
// ══════════════════════════════════════════════════════════════
function TeamChatTab({ projectId, projectTitle, agents }: { projectId: string; projectTitle: string; agents: ProjectAgent[] }) {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [mentionDropdown, setMentionDropdown] = useState(false);

  useEffect(() => {
    fetch(`/api/chat/project?projectId=${projectId}`).then(r => r.json())
      .then(d => setMessages(d.messages || []))
      .catch(() => {});
  }, [projectId]);

  const sendMessage = async () => {
    if (!input.trim() || sending) return;
    setSending(true);
    const userMsg = {
      sender: 'kevin',
      senderName: 'Kevin (You)',
      text: input.trim(),
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMsg]);
    const outgoing = input.trim();
    setInput('');

    // Determine which agents should respond
    // If message starts with @agentId, only that agent responds; otherwise first 3 team members
    const mentionMatch = outgoing.match(/^@(\w[\w-]*)/);
    const respondingAgents = mentionMatch
      ? agents.filter(a => a.agentId === mentionMatch[1]).slice(0, 1)
      : agents.slice(0, 3);

    try {
      // Save message to project chat history (fire and forget)
      fetch('/api/chat/project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, message: outgoing, sender: 'kevin', senderName: 'Kevin (You)' }),
      }).catch(() => {});

      // Get per-agent replies in parallel
      if (respondingAgents.length > 0) {
        const replyPromises = respondingAgents.map(agent =>
          fetch(`/api/projects/${projectId}/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: outgoing, agentId: agent.agentId }),
          })
            .then(r => r.json())
            .then(d => ({
              sender: agent.agentId,
              senderName: d.agentName || agent.agentId,
              text: d.content || d.response || '...',
              timestamp: new Date().toISOString(),
              isAgent: true,
            }))
            .catch(() => null)
        );
        const replies = (await Promise.all(replyPromises)).filter(Boolean);
        setMessages(prev => [...prev, ...replies as any[]]);
      }
    } catch {}
    setSending(false);
  };

  const handleMention = (agentId: string) => {
    const agent = agents.find(a => a.agentId === agentId);
    if (agent) {
      setInput(`@${agentId} ${input}`);
      setMentionDropdown(false);
    }
  };

  // NOTE: Removed auto-scroll on new messages to prevent page jump/jarring UX
  // Users can manually scroll if they want to see latest messages
  return (
    <div className="flex flex-col h-full space-y-2 p-2">
      {/* Team presence indicator */}
      {agents.length > 0 && (
        <div className="text-xs text-mc-muted">
          <span className="font-semibold text-mc-accent">Team:</span> {agents.map(a => a.agentId).join(', ')}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-2 bg-mc-bg rounded-lg p-3 border border-mc-border">
        {messages.length === 0 && (
          <div className="text-xs text-mc-muted text-center py-8">No messages yet. Start the team chat...</div>
        )}
        {messages.map((msg, i) => {
          const isKevin = msg.sender === 'kevin';
          const agentColors = ['bg-purple-500','bg-blue-500','bg-green-500','bg-orange-500','bg-pink-500','bg-teal-500'];
          const agentIdx = agents.findIndex(a => a.agentId === msg.sender);
          const avatarColor = agentColors[agentIdx % agentColors.length] || 'bg-mc-accent';
          const initials = (msg.senderName || msg.sender || '?').slice(0,2).toUpperCase();
          return (
            <div key={i} className={`flex items-end gap-2 ${isKevin ? 'justify-end' : 'justify-start'}`}>
              {!isKevin && (
                <div className={`flex-shrink-0 w-6 h-6 rounded-full ${avatarColor} flex items-center justify-center text-[9px] font-bold text-white`}>
                  {initials}
                </div>
              )}
              <div className={`max-w-xs rounded-lg px-3 py-2 text-xs ${
                isKevin ? 'bg-mc-accent/30 text-mc-accent' : 'bg-mc-surface border border-mc-border text-mc-text'
              }`}>
                <div className={`text-[10px] font-semibold ${isKevin ? 'text-mc-accent' : avatarColor.replace('bg-','text-').replace('-500','-400')} mb-0.5`}>
                  {msg.senderName || msg.sender}
                  {msg.timestamp && (
                    <span className="text-[10px] text-mc-muted ml-2">
                      {new Date(msg.timestamp).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
                    </span>
                  )}
                </div>
                <div className="break-words">{msg.text}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input */}
      <div className="space-y-1">
        <div className="relative">
          <input
            value={input}
            onChange={e => {
              setInput(e.target.value);
              setMentionDropdown(e.target.value.includes('@'));
            }}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder={`💬 Message the team... (try @${agents[0]?.agentId || 'agent'})`}
            className="w-full bg-mc-surface border border-mc-border rounded px-3 py-2 text-sm text-mc-text placeholder-mc-muted focus:outline-none focus:border-mc-accent"
          />
          {mentionDropdown && agents.length > 0 && (
            <div className="absolute bottom-full mb-1 left-0 right-0 bg-mc-surface border border-mc-border rounded-lg shadow-lg max-h-40 overflow-y-auto z-10">
              {agents.map(agent => (
                <button
                  key={agent.agentId}
                  onClick={() => handleMention(agent.agentId)}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-mc-accent/20 text-mc-text flex justify-between items-center"
                >
                  <span>@{agent.agentId}</span>
                  <span className="text-[10px] text-mc-muted">{agent.role}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <button
          onClick={sendMessage}
          disabled={sending || !input.trim()}
          className="w-full bg-mc-accent text-white py-2 rounded text-sm font-semibold hover:opacity-80 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {sending ? '⏳ Sending...' : '📤 Send'}
        </button>
      </div>

      {/* Quick actions */}
      {agents.length > 0 && (
        <div className="text-xs space-y-1">
          <div className="text-mc-muted font-semibold">Quick Actions:</div>
          <div className="flex flex-wrap gap-1">
            {agents.slice(0, 3).map(agent => (
              <button
                key={agent.agentId}
                onClick={() => setInput(`@${agent.agentId} review this`)}
                className="px-2 py-1 bg-mc-accent/20 text-mc-accent rounded text-xs hover:bg-mc-accent/30"
              >
                🔍 {agent.agentId}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// PROJECT REPORTS TAB
// ══════════════════════════════════════════════════════════════
function ProjectReportsTab({ projectId, projectTitle, onNavigateTab }: { projectId: string; projectTitle: string; onNavigateTab?: (tab: string) => void }) {
  const [reports, setReports] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  // FIX: Initialize ALL hooks before any conditional returns (React Error #310)
  const [hasRetro, setHasRetro] = useState(false);

  const loadReports = () => {
    fetch('/api/reports').then(r => r.json()).then(d => {
      const all = d.reports || [];
      setReports(all.filter((r: any) => r.projectId === projectId));
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { loadReports(); }, [projectId]);

  useEffect(() => {
    fetch(`/api/projects/${projectId}/retrospective`)
      .then(r => r.json())
      .then(d => setHasRetro(d.exists || false))
      .catch(() => setHasRetro(false));
  }, [projectId]);

  if (loading) return <div className="text-mc-muted text-sm p-4">Loading reports...</div>;

  if (selected) {
    return (
      <div className="space-y-3">
        <button onClick={() => setSelected(null)} className="text-xs text-mc-accent hover:underline">← Back to reports</button>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-lg">{selected.title}</h3>
            <span className={`px-2 py-0.5 rounded-full text-xs ${selected.status === 'approved' ? 'bg-green-500/20 text-green-400' : selected.status === 'draft' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-blue-500/20 text-blue-400'}`}>
              {selected.status}
            </span>
          </div>
          <div className="text-xs text-mc-muted mb-3">
            {selected.type} · {selected.category} · {new Date(selected.createdAt).toLocaleDateString()}
          </div>
          {selected.summary && <p className="text-sm mb-3">{selected.summary}</p>}
          {selected.content && (
            <div className="prose prose-invert prose-sm max-w-none whitespace-pre-wrap text-sm bg-mc-surface p-3 rounded border border-mc-border max-h-[50vh] overflow-y-auto">
              {selected.content}
            </div>
          )}
          {/* Show structured fields */}
          {Array.isArray(selected.features) && selected.features.length > 0 && (
            <div className="mt-3">
              <h4 className="text-xs font-semibold text-mc-muted mb-1">Features</h4>
              {selected.features.map((f: any, i: number) => (
                <div key={i} className="text-sm ml-2 mb-1"><span className="text-mc-accent">•</span> <strong>{f.name}</strong>: {f.description}</div>
              ))}
            </div>
          )}
          {Array.isArray(selected.recommendations) && selected.recommendations.length > 0 && (
            <div className="mt-3">
              <h4 className="text-xs font-semibold text-mc-muted mb-1">Recommendations</h4>
              {selected.recommendations.map((r: any, i: number) => (
                <div key={i} className="text-sm ml-2 mb-1"><span className="text-mc-accent">•</span> {typeof r === 'string' ? r : r.recommendation || JSON.stringify(r)}</div>
              ))}
            </div>
          )}
          {Array.isArray(selected.risks) && selected.risks.length > 0 && (
            <div className="mt-3">
              <h4 className="text-xs font-semibold text-mc-muted mb-1">Risks</h4>
              {selected.risks.map((r: any, i: number) => (
                <div key={i} className="text-sm ml-2 mb-1"><span className="text-red-400">⚠</span> {typeof r === 'string' ? r : r.risk || r.name || JSON.stringify(r)}</div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Quick Link to Retrospective */}
      {hasRetro && (
        <div 
          onClick={() => onNavigateTab?.('retrospective')}
          className="bg-mc-accent/10 border border-mc-accent/30 rounded-lg p-3 cursor-pointer hover:bg-mc-accent/20 transition-colors"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg">📋</span>
              <div>
                <div className="text-sm font-medium text-mc-accent">Project Retrospective</div>
                <div className="text-xs text-mc-muted">Click to view lessons learned</div>
              </div>
            </div>
            <span className="text-mc-accent">→</span>
          </div>
        </div>
      )}
      
      <div className="flex items-center justify-between">
        <div className="text-xs text-mc-muted">{reports.length} report{reports.length !== 1 ? 's' : ''} for this project</div>
      </div>
      {reports.length === 0 ? (
        <div className="text-center py-8 text-mc-muted text-sm">
          <div className="text-3xl mb-2">📝</div>
          <div>No reports yet for this project.</div>
          <div className="text-xs mt-1">Reports are generated during project lifecycle analysis.</div>
        </div>
      ) : (
        <div className="space-y-2">
          {reports.map(r => (
            <div key={r.id} onClick={() => setSelected(r)}
              className="bg-mc-bg border border-mc-border rounded-lg p-3 cursor-pointer hover:border-mc-accent/50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="font-medium text-sm">{r.title}</div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] ${r.status === 'approved' ? 'bg-green-500/20 text-green-400' : r.status === 'draft' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-blue-500/20 text-blue-400'}`}>
                  {r.status}
                </span>
              </div>
              <div className="text-xs text-mc-muted mt-1">{r.type} · {r.category} · {new Date(r.createdAt).toLocaleDateString()}</div>
              {r.summary && <div className="text-xs text-mc-muted mt-1 line-clamp-2">{r.summary}</div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// RETROSPECTIVE TAB
// ══════════════════════════════════════════════════════════════
function RetrospectiveTab({ projectId }: { projectId: string }) {
  const [retrospective, setRetrospective] = useState<{ exists: boolean; content: string | null } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/projects/${projectId}/retrospective`)
      .then(r => r.json())
      .then(d => setRetrospective(d))
      .catch(() => setRetrospective({ exists: false, content: null }))
      .finally(() => setLoading(false));
  }, [projectId]);

  if (loading) {
    return <div className="text-mc-muted text-sm p-4">Loading retrospective...</div>;
  }

  if (!retrospective || !retrospective.exists) {
    return (
      <div className="text-center py-12 px-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-mc-bg mb-4">
          <span className="text-3xl">📋</span>
        </div>
        <h3 className="text-lg font-semibold text-mc-text mb-2">No Retrospective Yet</h3>
        <p className="text-sm text-mc-muted max-w-sm mx-auto">
          Retrospectives are generated at project completion. Check back once the project is marked as complete.
        </p>
      </div>
    );
  }

  // Try to extract date from content (look for date patterns)
  const dateMatch = retrospective.content?.match(/Date:?\s*([^\n]+)/i) 
    || retrospective.content?.match(/Retrospective Date:?\s*([^\n]+)/i)
    || retrospective.content?.match(/##\s*(\d{4}-\d{2}-\d{2})/);

  return (
    <div className="space-y-4">
      {dateMatch && (
        <div className="flex items-center gap-2 text-xs text-mc-muted">
          <span>📅</span>
          <span>{dateMatch[1]?.trim()}</span>
        </div>
      )}
      <div className="bg-mc-bg border border-mc-border rounded-lg p-4 overflow-auto max-h-[60vh]">
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          className="prose prose-invert prose-sm max-w-none"
        >
          {retrospective.content || ''}
        </ReactMarkdown>
      </div>
    </div>
  );
}

// PLAY THE PLAN TAB - Enhanced with real agent execution
// ══════════════════════════════════════════════════════════════
function PlayThePlanTab({ projectId, projectTitle }: { projectId: string; projectTitle: string }) {
  const [generating, setGenerating] = useState(false);
  const [plan, setPlan] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [paused, setPaused] = useState(false);
  const [executionSteps, setExecutionSteps] = useState<any[]>([]);
  const [completedSteps, setCompletedSteps] = useState(0);
  const [activity, setActivity] = useState<string[]>([]);
  const [projectAgents, setProjectAgents] = useState<any[]>([]);
  const [projectPhases, setProjectPhases] = useState<any[]>([]);
  const [documents, setDocuments] = useState<any[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);

  // Agent model mapping
  const agentModelMap: Record<string, string> = {
    'pixel': 'xai/grok-4',
    'nova': 'xai/grok-4',
    'spark': 'anthropic/claude-opus-4-6',
    'floof': 'xai/grok-4',
    'dirty-bird': 'anthropic/claude-opus-4-6',
    'jimmy-t': 'openrouter/minimax/minimax-m2.5',
    'architect': 'anthropic/claude-opus-4-6',
    'viper': 'xai/grok-4',
    'oracle': 'openrouter/google/gemini-2.5-pro',
    'sentinel': 'xai/grok-4',
    'brain': 'xai/grok-4',
    'groot': 'openrouter/minimax/minimax-m2.5',
    'ceo': 'xai/grok-4',
    'forge': 'anthropic/claude-opus-4-6',
    'swift': 'xai/grok-4',
    'atlas': 'anthropic/claude-opus-4-6',
  };

  useEffect(() => {
    // Load project data
    Promise.all([
      fetch(`/api/projects?id=${projectId}`).then(r => r.json()),
      fetch(`/api/plan?projectId=${projectId}`).then(r => r.json()),
    ]).then(([projData, planData]) => {
      if (projData.project) {
        setProjectAgents(projData.project.agents || projData.project.roles || []);
        setProjectPhases(projData.project.phases || []);
      }
      if (planData.plan) setPlan(planData.plan);
    }).catch(() => {});
    
    // Load existing documents
    fetch(`/api/projects/documents?projectId=${projectId}`).then(r => r.json()).then(d => {
      if (d.documents) setDocuments(d.documents);
    }).catch(() => {});
  }, [projectId]);

  const generatePlan = async () => {
    setGenerating(true);
    setExecutionSteps([]);
    setCompletedSteps(0);
    setActivity([]);
    try {
      const r = await fetch('/api/plan/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, projectTitle }),
      });
      const d = await r.json();
      setPlan(d.plan || 'Failed to generate plan.');
      const planText = d.plan || '';
      const stepMatches = planText.match(/^\d+\..+/gm) || [];
      
      // Map steps to agents from project
      const agents = projectAgents.length > 0 ? projectAgents : [{ agentId: 'groot', role: 'Lead' }];
      setExecutionSteps(
        stepMatches.map((step: string, i: number) => ({
          id: `step-${i}`,
          number: i + 1,
          description: step.replace(/^\d+\.\s*/, '').trim(),
          status: 'pending' as const,
          duration: 0,
          agent: agents[i % agents.length]?.agentId || 'groot',
          action: 'analyze',
        }))
      );
    } catch { setPlan('Generation failed.'); }
    setGenerating(false);
  };

  // Execute a single step using Gateway agent
  const executeStep = async (step: any) => {
    const agentId = step.agent || 'groot';
    
    // Log starting
    setActivity(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🤖 ${agentId} is working on: ${step.description.substring(0, 60)}...`]);
    
    try {
      // Call the Gateway API which spawns real OpenClaw agents
      const res = await fetch('/api/projects/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'execute-step',
          projectId: projectId,
          projectTitle: projectTitle,
          phase: step.phase || 'N/A',
          step: step.description,
          agentId: agentId,
        }),
      });
      
      const data = await res.json();
      const result = data.result || 'Task completed';
      
      // Parse result for document creation
      const docMatch = result.match(/Document created:\s*([^\n]+)/i);
      if (docMatch) {
        const docName = docMatch[1].trim();
        if (docName !== 'none') {
          setDocuments(prev => [...prev, { name: docName, createdAt: new Date().toISOString(), agent: agentId }]);
        }
      }
      
      setActivity(prev => [...prev, `[${new Date().toLocaleTimeString()}] ✅ ${agentId} completed: ${result.substring(0, 100)}...`]);
      return result;
    } catch (e: any) {
      setActivity(prev => [...prev, `[${new Date().toLocaleTimeString()}] ❌ ${agentId} error: ${e.message}`]);
      return 'Error: ' + e.message;
    }
  };

  const playPlan = async () => {
    if (!confirm('Execute this plan? Agents will be dispatched to work on each phase.')) return;
    setPlaying(true);
    setPaused(false);
    
    try {
      let currentActivity = [...activity];
      currentActivity.push(`[${new Date().toLocaleTimeString()}] ▶️ Plan execution started with ${executionSteps.length} steps`);
      currentActivity.push(`[${new Date().toLocaleTimeString()}] 👥 Agents: ${[...new Set(executionSteps.map((s: any) => s.agent))].join(', ')}`);
      setActivity([...currentActivity]);
      
      for (let i = 0; i < executionSteps.length; i++) {
        if (paused || !playing) break;
        
        const step = executionSteps[i];
        setExecutionSteps(prev => prev.map((s, idx) => 
          idx === i ? { ...s, status: 'running' as const } : s
        ));
        
        // Execute with real agent
        const startTime = Date.now();
        await executeStep(step);
        const duration = Math.round((Date.now() - startTime) / 1000);
        
        setExecutionSteps(prev => prev.map((s, idx) => 
          idx === i ? { ...s, status: 'done' as const, duration } : s
        ));
        setCompletedSteps(i + 1);
      }
      
      if (!paused && playing) {
        currentActivity.push(`[${new Date().toLocaleTimeString()}] 🎉 Plan execution completed!`);
        currentActivity.push(`[${new Date().toLocaleTimeString()}] 📄 Created ${documents.length} document(s)`);
        setActivity([...currentActivity]);
      }
      
      await fetch('/api/plan/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, plan }),
      });
    } catch (e: any) { 
      setActivity(prev => [...prev, `❌ Execution error: ${e.message}`]);
    }
    setPlaying(false);
  };

  const stopPlan = () => {
    setPlaying(false);
    setPaused(false);
    setActivity(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🛑 Plan execution stopped`]);
    setExecutionSteps(prev => prev.map(s => s.status === 'running' ? { ...s, status: 'pending' } : s));
  };

  const pausePlan = () => {
    setPaused(!paused);
    setActivity(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${!paused ? '⏸️' : '▶️'} Plan execution ${!paused ? 'paused' : 'resumed'}`]);
  };

  const progressPct = executionSteps.length > 0 ? Math.round((completedSteps / executionSteps.length) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="text-xs text-mc-muted">
        Generate an AI-powered execution plan for this project. The plan includes phases, tasks, agent assignments,
        deliverables (PRD, Design Doc, Tech Spec), and a full timeline. Review, edit, then hit Play.
      </div>

      {!plan ? (
        <button onClick={generatePlan} disabled={generating}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-lg text-sm font-semibold hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2">
          {generating ? '🔄 AI is generating your plan...' : '🤖 Generate Execution Plan'}
        </button>
      ) : (
        <>
          {/* Plan Text */}
          <div className="bg-mc-bg border border-mc-border rounded-lg p-4 text-xs text-mc-text whitespace-pre-wrap max-h-72 overflow-y-auto">
            {plan}
          </div>

          {/* Progress & Controls */}
          {executionSteps.length > 0 && (
            <>
              {/* Progress Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-mc-muted">
                  <span>Progress</span>
                  <span>{completedSteps}/{executionSteps.length} steps ({progressPct}%)</span>
                </div>
                <div className="h-2 bg-mc-surface rounded-full overflow-hidden border border-mc-border">
                  <div 
                    className="h-full bg-gradient-to-r from-mc-accent to-green-500 transition-all" 
                    style={{ width: `${progressPct}%` }} 
                  />
                </div>
              </div>

              {/* Execution Steps */}
              <div className="space-y-1">
                <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">Execution Steps</h4>
                <div className="max-h-40 overflow-y-auto space-y-1 bg-mc-surface rounded-lg p-2 border border-mc-border">
                  {executionSteps.map((step, i) => (
                    <div key={step.id} className="flex items-start gap-2 text-xs p-2 rounded bg-mc-bg">
                      <span className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center font-bold ${
                        step.status === 'done' ? 'bg-green-500/20 text-green-400' :
                        step.status === 'running' ? 'bg-blue-500/20 text-blue-400 animate-pulse' :
                        step.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {step.status === 'done' ? '✅' : step.status === 'running' ? '🔄' : step.status === 'failed' ? '❌' : '⏳'}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-mc-text">Step {step.number}</div>
                        <div className="text-mc-muted truncate">{step.description}</div>
                      </div>
                      {step.duration > 0 && <span className="text-mc-muted flex-shrink-0">{step.duration}s</span>}
                    </div>
                  ))}
                </div>
              </div>

              {/* Activity Log */}
              <div className="space-y-1">
                <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">Activity Log</h4>
                <div className="max-h-32 overflow-y-auto space-y-0.5 bg-mc-surface rounded-lg p-2 border border-mc-border">
                  {activity.length === 0 ? (
                    <div className="text-xs text-mc-muted text-center py-2">No activity yet</div>
                  ) : (
                    activity.map((log, i) => (
                      <div key={i} className="text-[10px] text-mc-muted font-mono">{log}</div>
                    ))
                  )}
                </div>
              </div>

              {/* Project Agents */}
              {projectAgents.length > 0 && (
                <div className="space-y-1">
                  <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">👥 Project Agents</h4>
                  <div className="flex flex-wrap gap-1 bg-mc-surface rounded-lg p-2 border border-mc-border">
                    {projectAgents.map((a: any, i: number) => (
                      <span key={i} className="text-[10px] px-2 py-1 rounded-full bg-mc-bg border border-mc-border">
                        {a.agentId} <span className="text-mc-muted">({a.role})</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Created Documents */}
              <div className="space-y-1">
                <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider">📄 Documents Created</h4>
                <div className="max-h-24 overflow-y-auto space-y-1 bg-mc-surface rounded-lg p-2 border border-mc-border">
                  {documents.length === 0 ? (
                    <div className="text-xs text-mc-muted text-center py-2">No documents created yet</div>
                  ) : (
                    documents.map((doc, i) => (
                      <div key={i} className="text-xs flex items-center justify-between bg-mc-bg rounded p-2">
                        <span>📄 {doc.name}</span>
                        <span className="text-mc-muted text-[10px]">{doc.agent}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </>
          )}

          {/* Buttons */}
          <div className="flex gap-2">
            <button onClick={generatePlan} disabled={generating}
              className="flex-1 bg-mc-bg border border-mc-border text-mc-text py-2 rounded-lg text-sm hover:border-mc-accent">
              🔄 Regenerate
            </button>
            {!playing ? (
              <button onClick={playPlan} disabled={playing}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 rounded-lg text-sm font-bold hover:opacity-90">
                ▶️ PLAY THE PLAN
              </button>
            ) : (
              <>
                <button onClick={pausePlan}
                  className="flex-1 bg-yellow-600/60 text-white py-2 rounded-lg text-sm font-bold hover:bg-yellow-600">
                  {paused ? '▶️ Resume' : '⏸️ Pause'}
                </button>
                <button onClick={stopPlan}
                  className="flex-1 bg-red-600/60 text-white py-2 rounded-lg text-sm font-bold hover:bg-red-600">
                  ⏹️ Stop
                </button>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// PROTOCOL TAB - Run State, Plan, Tasks, Live Activity, Chat
// ══════════════════════════════════════════════════════════════
interface ProtocolTask {
  id: number;
  agent: string;
  priority: string;
  desc: string;
  status: 'pending' | 'done';
}

interface ProtocolData {
  plan: string;
  tasks: ProtocolTask[];
  status: 'idle' | 'running' | 'paused';
}

function ProtocolTab({ projectId, projectTitle }: { projectId: string; projectTitle: string }) {
  const [protocolData, setProtocolData] = useState<ProtocolData | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);

  // Poll protocol data every 5 seconds
  useEffect(() => {
    const fetchProtocol = async () => {
      try {
        const res = await fetch(`/api/projects/${projectId}/protocol`);
        const data = await res.json();
        setProtocolData({
          plan: data.plan || '',
          tasks: data.tasks || [],
          status: data.status || 'idle',
        });
      } catch (e) {
        console.error('Failed to fetch protocol:', e);
      } finally {
        setLoading(false);
      }
    };

    fetchProtocol();
    const interval = setInterval(fetchProtocol, 5000);
    return () => clearInterval(interval);
  }, [projectId]);

  const handleAction = async (action: 'run' | 'pause' | 'resume' | 'cancel') => {
    if (action === 'cancel' && !confirmCancel) {
      setConfirmCancel(true);
      setTimeout(() => setConfirmCancel(false), 3000);
      return;
    }

    setActionLoading(action);
    try {
      const res = await fetch(`/api/projects/${projectId}/protocol`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (data.status) {
        setProtocolData(prev => prev ? { ...prev, status: data.status } : null);
      }
    } catch (e) {
      console.error('Protocol action failed:', e);
    }
    setActionLoading(null);
    setConfirmCancel(false);
  };

  const toggleTask = async (taskIndex: number, currentStatus: string) => {
    const newStatus = currentStatus === 'done' ? 'pending' : 'done';
    try {
      await fetch(`/api/projects/${projectId}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskIndex, status: newStatus }),
      });
      // Update local state
      setProtocolData(prev => {
        if (!prev) return null;
        const updatedTasks = [...prev.tasks];
        updatedTasks[taskIndex] = { ...updatedTasks[taskIndex], status: newStatus as 'pending' | 'done' };
        return { ...prev, tasks: updatedTasks };
      });
    } catch (e) {
      console.error('Failed to toggle task:', e);
    }
  };

  const getStatusColor = (status: string) => {
    if (status === 'running') return 'bg-green-500/20 text-green-400 border-green-500/30';
    if (status === 'paused') return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  };

  const getAgentColor = (agent: string) => {
    const colors: Record<string, string> = {
      'groot': 'bg-green-500/20 text-green-400',
      'pixel': 'bg-blue-500/20 text-blue-400',
      'forge': 'bg-orange-500/20 text-orange-400',
      'brain': 'bg-purple-500/20 text-purple-400',
      'ceo': 'bg-red-500/20 text-red-400',
      'sentinel': 'bg-teal-500/20 text-teal-400',
    };
    return colors[agent.toLowerCase()] || 'bg-gray-500/20 text-gray-400';
  };

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      'critical': 'bg-red-500/20 text-red-400',
      'high': 'bg-orange-500/20 text-orange-400',
      'medium': 'bg-yellow-500/20 text-yellow-400',
      'low': 'bg-gray-500/20 text-gray-400',
    };
    return colors[priority.toLowerCase()] || 'bg-gray-500/20 text-gray-400';
  };

  if (loading) {
    return <div className="text-mc-muted text-sm p-4">Loading protocol...</div>;
  }

  const status = protocolData?.status || 'idle';

  return (
    <div className="space-y-4">
      {/* Run State Bar */}
      <div className="bg-mc-bg border border-mc-border rounded-lg p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`w-3 h-3 rounded-full ${
              status === 'running' ? 'bg-green-500 animate-pulse' :
              status === 'paused' ? 'bg-yellow-500' :
              'bg-gray-500'
            }`} />
            <span className={`text-xs px-2 py-0.5 rounded border ${getStatusColor(status)}`}>
              {status.toUpperCase()}
            </span>
          </div>
          <div className="flex gap-2">
            {status === 'idle' && (
              <button
                onClick={() => handleAction('run')}
                disabled={actionLoading === 'run'}
                className="px-3 py-1.5 bg-green-500/20 text-green-400 rounded text-xs font-medium hover:bg-green-500/30 disabled:opacity-50"
              >
                {actionLoading === 'run' ? '⏳' : '▶'} Run Protocol
              </button>
            )}
            {status === 'running' && (
              <button
                onClick={() => handleAction('pause')}
                disabled={actionLoading === 'pause'}
                className="px-3 py-1.5 bg-yellow-500/20 text-yellow-400 rounded text-xs font-medium hover:bg-yellow-500/30 disabled:opacity-50"
              >
                {actionLoading === 'pause' ? '⏳' : '⏸'} Pause
              </button>
            )}
            {status === 'paused' && (
              <button
                onClick={() => handleAction('resume')}
                disabled={actionLoading === 'resume'}
                className="px-3 py-1.5 bg-green-500/20 text-green-400 rounded text-xs font-medium hover:bg-green-500/30 disabled:opacity-50"
              >
                {actionLoading === 'resume' ? '⏳' : '▶'} Resume
              </button>
            )}
            {(status === 'running' || status === 'paused') && (
              <button
                onClick={() => handleAction('cancel')}
                disabled={actionLoading === 'cancel'}
                className={`px-3 py-1.5 rounded text-xs font-medium disabled:opacity-50 ${
                  confirmCancel 
                    ? 'bg-red-500 text-white' 
                    : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                }`}
              >
                {actionLoading === 'cancel' ? '⏳' : confirmCancel ? '⚠️ Confirm?' : '⏹'} Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Plan Viewer */}
      <div>
        <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">📄 Plan</h4>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-3 max-h-48 overflow-y-auto">
          {protocolData?.plan ? (
            <pre className="text-xs text-mc-text whitespace-pre-wrap font-mono">{protocolData.plan}</pre>
          ) : (
            <div className="text-xs text-mc-muted text-center py-4">No plan defined. Run the protocol to generate one.</div>
          )}
        </div>
      </div>

      {/* Tasks Checklist */}
      <div>
        <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">✅ Tasks</h4>
        <div className="bg-mc-bg border border-mc-border rounded-lg divide-y divide-mc-border/30 max-h-64 overflow-y-auto">
          {protocolData?.tasks && protocolData.tasks.length > 0 ? (
            protocolData.tasks.map((task, idx) => (
              <div key={task.id} className={`p-2 flex items-center gap-2 hover:bg-mc-surface/30 ${task.status === 'done' ? 'opacity-60' : ''}`}>
                <input
                  type="checkbox"
                  checked={task.status === 'done'}
                  onChange={() => toggleTask(idx, task.status)}
                  className="flex-shrink-0 w-4 h-4 rounded border-mc-border text-mc-accent focus:ring-mc-accent"
                />
                <span className={`text-xs px-1.5 py-0.5 rounded ${getAgentColor(task.agent)}`}>
                  {task.agent}
                </span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded ${getPriorityColor(task.priority)}`}>
                  {task.priority}
                </span>
                <span className={`flex-1 text-xs ${task.status === 'done' ? 'line-through text-mc-muted' : 'text-mc-text'}`}>
                  {task.desc}
                </span>
              </div>
            ))
          ) : (
            <div className="text-xs text-mc-muted text-center py-4">No tasks defined.</div>
          )}
        </div>
      </div>

      {/* NOTE: Live Activity Feed and Project Chat removed from Protocol Tab to fix:
         1. 'Unknown' spam from activity feed polling
         2. Duplicate chat - there's already one at the bottom of the page
         Users can view live activity and use chat from the main chat area at page bottom.
      */}
      {/* Live Activity Feed removed - was causing 'Unknown' spam */}
      {/* Project Chat removed - duplicate, using bottom ProjectChat instead */}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// DOCUMENT VIEWER MODAL
// ══════════════════════════════════════════════════════════════
function DocumentViewerModal({ doc, onClose }: { doc: { name: string; content: string }; onClose: () => void }) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[60] bg-black/70 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="w-full max-w-3xl max-h-[80vh] bg-mc-surface border border-mc-border rounded-xl flex flex-col shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-mc-border flex-shrink-0">
          <h3 className="font-semibold text-sm text-mc-text">📄 {doc.name}</h3>
          <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            className="prose prose-invert prose-sm max-w-none"
          >
            {doc.content}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}

interface Props {
  projectId: string;
  onClose: () => void;
  agentMap?: Record<string, any>;
  allAgents?: any[];
  /** If true, render as a modal overlay (used from KanbanBoard) */
  modal?: boolean;
}

export default function ProjectProfile({ projectId, onClose, agentMap: externalAgentMap, allAgents: externalAllAgents, modal }: Props) {
  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<any[]>([]);
  const [tab, setTab] = useState<'overview' | 'phases' | 'protocol' | 'protocol-builder' | 'agents' | 'team' | 'lifecycle' | 'tasks' | 'stats' | 'tests' | 'risks' | 'plan' | 'reports' | 'retrospective' | 'docs'>('overview');
  const [showTeamBuilder, setShowTeamBuilder] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const descriptionRef = useRef<HTMLTextAreaElement | null>(null);
  const [newGoal, setNewGoal] = useState('');
  const [showAddAgent, setShowAddAgent] = useState(false);
  const [addAgentId, setAddAgentId] = useState('');
  const [addAgentRole, setAddAgentRole] = useState('');
  const [customRole, setCustomRole] = useState('');
  const [autoAssigning, setAutoAssigning] = useState(false);
  const [suggestions, setSuggestions] = useState<ProjectAgent[] | null>(null);
  const [allProjects, setAllProjects] = useState<any[]>([]);

  // Phase editing state
  const [expandedPhase, setExpandedPhase] = useState<string | null>(null);
  const [editingPhase, setEditingPhase] = useState<string | null>(null);
  const [editPhaseName, setEditPhaseName] = useState('');
  const [editPhaseDesc, setEditPhaseDesc] = useState('');
  const [addingPhase, setAddingPhase] = useState(false);
  const [newPhaseName, setNewPhaseName] = useState('');
  const [newPhaseDesc, setNewPhaseDesc] = useState('');

  // Add task state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskAssignee, setNewTaskAssignee] = useState('');

  // Stats state
  const [usage, setUsage] = useState<any[]>([]);
  const [projectActivity, setProjectActivity] = useState<any[]>([]);

  // Agents (fetched if not provided)
  const [fetchedAgents, setFetchedAgents] = useState<any[]>([]);
  const [fetchedAgentMap, setFetchedAgentMap] = useState<Record<string, any>>({});
  const agentMap = externalAgentMap || fetchedAgentMap;
  const allAgents = externalAllAgents || fetchedAgents;

  // Collapsible nav state
  const [navCollapsed, setNavCollapsed] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('mc-project-nav-collapsed');
      if (stored !== null) return stored === 'true';
      // Default to collapsed on mobile
      return window.innerWidth < 768;
    }
    return false;
  });
  const [chatExpanded, setChatExpanded] = useState(false);

  // Save collapsed state to localStorage
  useEffect(() => {
    localStorage.setItem('mc-project-nav-collapsed', String(navCollapsed));
  }, [navCollapsed]);

  // Handle tab change - no auto-scroll to prevent jarring UX
  const handleTabChange = useCallback((newTab: typeof tab) => {
    // Do NOT auto-scroll - let user control their position
    setTab(newTab);
  }, []);

  // Documents state
  const [docs, setDocs] = useState<{ name: string; size: number; mtime: string }[]>([]);
  const [docsLoading, setDocsLoading] = useState(false);
  const [docModal, setDocModal] = useState<{ name: string; content: string } | null>(null);

  // Cost breakdown state
  const [costData, setCostData] = useState<{ table: { headers: string[]; rows: string[][] } } | null>(null);

  // Project XP state
  const [projectXp, setProjectXp] = useState<{
    xp: number;
    level: number;
    levelLabel: string;
    progress: number;
    xpToNextLevel: number;
    efficiency: number;
    stats: { totalTasks: number; completedTasks: number };
  } | null>(null);
  const [xpLoading, setXpLoading] = useState(false);

  // Run status state for Play/Pause
  const [runStatus, setRunStatus] = useState<'running' | 'paused' | 'idle'>('idle');
  const [runStatusLoading, setRunStatusLoading] = useState(false);
  const [orchestrating, setOrchestrating] = useState(false);

  // Fetch run status
  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/brain/orchestrate?projectId=' + encodeURIComponent(projectId));
        const data = await res.json();
        if (data.status) {
          setRunStatus(data.status);
        }
      } catch (e) {
        console.error('Failed to fetch run status:', e);
      }
    };
    fetchStatus();
    // Poll every 3 seconds
    const interval = setInterval(fetchStatus, 3000);
    return () => clearInterval(interval);
  }, [projectId]);

  const handlePlayPause = async (action: 'play' | 'pause') => {
    setOrchestrating(true);
    try {
      const res = await fetch('/api/brain/orchestrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, action }),
      });
      const data = await res.json();
      if (data.status) {
        setRunStatus(data.status);
      }
    } catch (e) {
      console.error('Orchestrate error:', e);
    }
    setOrchestrating(false);
  };

  const load = () => {
    fetch('/api/projects').then(r => r.json()).then(d => {
      const p = (d.projects || []).find((pr: any) => pr.id === projectId);
      if (p) {
        p.name = p.name || p.title || '';
        p.agents = Array.isArray(p.agents) ? p.agents : Array.isArray(p.roles) ? p.roles.map((r: any) => ({ agentId: r.agentId, role: r.role })) : [];
        p.createdAt = p.createdAt || p.created || '';
        p.updatedAt = p.updatedAt || p.updated || '';
        p.goals = Array.isArray(p.goals) ? p.goals : [];
        p.phases = Array.isArray(p.phases) ? p.phases : [];
        p.tags = Array.isArray(p.tags) ? p.tags : [];
        p.stats = p.stats || {};
        setProject(p);
        setEditName(p.name);
        setEditDesc(p.description || '');
      }
    });
    fetch('/api/tasks').then(r => r.json()).then(d => setTasks((d.tasks || []).filter((t: any) => t.projectId === projectId)));
  };

  useEffect(load, [projectId]);

  // Auto-grow description field so content is visible without an inner scrollbar
  useEffect(() => {
    const el = descriptionRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.max(el.scrollHeight, 160)}px`;
  }, [editDesc, tab]);

  // Fetch project documents
  useEffect(() => {
    setDocsLoading(true);
    fetch(`/api/projects/${projectId}/documents`)
      .then(r => r.json())
      .then(d => setDocs(d.documents || []))
      .catch(() => {})
      .finally(() => setDocsLoading(false));
  }, [projectId]);

  // Fetch cost breakdown
  useEffect(() => {
    fetch(`/api/projects/${projectId}/cost`)
      .then(r => r.json())
      .then(d => setCostData(d))
      .catch(() => {});
  }, [projectId]);

  // Fetch project XP data
  useEffect(() => {
    setXpLoading(true);
    fetch(`/api/xp?projectId=${projectId}`)
      .then(r => r.json())
      .then(d => { if (!d.error) setProjectXp(d); })
      .catch(() => {})
      .finally(() => setXpLoading(false));
  }, [projectId]);

  useEffect(() => {
    fetch('/api/projects').then(r => r.json()).then(d => setAllProjects(d.projects || [])).catch(() => {});
  }, []);

  // Fetch usage & activity for stats
  useEffect(() => {
    const projectAgentIds = (project?.agents || []).map(a => a.agentId);
    fetch('/api/agents/usage').then(r => r.json()).then(d => setUsage(d.entries || [])).catch(() => {});
    fetch('/api/activity').then(r => r.json()).then(d => {
      setProjectActivity((d.entries || []).filter((e: any) => projectAgentIds.includes(e.agent)));
    }).catch(() => {});
  }, [project?.agents]);

  // Fetch agents if not provided externally
  useEffect(() => {
    if (!externalAgentMap || !externalAllAgents) {
      fetch('/api/agents').then(r => r.json()).then(d => {
        const agents = d.agents || [];
        setFetchedAgents(agents);
        const map: Record<string, any> = {};
        agents.forEach((a: any) => { map[a.id] = a; });
        setFetchedAgentMap(map);
      }).catch(() => {});
    }
  }, [externalAgentMap, externalAllAgents]);

  const save = async (updates: any) => {
    setSaving(true);
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id: projectId, updates }),
    });
    setSaving(false);
    load();
  };

  const patchField = async (field: string, value: any) => {
    await save({ [field]: value });
  };

  // Phase operations
  const updatePhaseStatus = async (phaseId: string, newStatus: string) => {
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update-phase', projectId, phaseId, updates: { status: newStatus }, updatedBy: 'Kevin' }),
    });
    load();
  };

  const addPhase = async () => {
    if (!newPhaseName.trim()) return;
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add-phase', projectId, name: newPhaseName, description: newPhaseDesc, updatedBy: 'Kevin' }),
    });
    setNewPhaseName('');
    setNewPhaseDesc('');
    setAddingPhase(false);
    load();
  };

  const removePhase = async (phaseId: string) => {
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'remove-phase', projectId, phaseId, updatedBy: 'Kevin' }),
    });
    load();
  };

  if (!project) return (
    <div className="flex items-center justify-center h-64 text-mc-muted">Loading project...</div>
  );

  const phases = Array.isArray(project.phases) ? project.phases : [];
  const completedPhases = phases.filter(p => p.status === 'complete').length;
  const totalPhases = phases.length;
  const progressPct = totalPhases > 0 ? Math.round((completedPhases / totalPhases) * 100) : 0;

  const projectAgents = Array.isArray(project.agents) ? project.agents : [];
  const availableAgents = Array.isArray(allAgents) ? allAgents.filter(a => a.id !== 'kevin' && !projectAgents.find(pa => pa.agentId === a.id)) : [];

  const addAgent = async () => {
    if (!addAgentId) return;
    const role = customRole || addAgentRole || 'Contributor';
    const newAgents = [...projectAgents, { agentId: addAgentId, role }];
    await patchField('agents', newAgents);
    setShowAddAgent(false); setAddAgentId(''); setAddAgentRole(''); setCustomRole('');
  };

  const removeAgent = async (agentId: string) => {
    await patchField('agents', projectAgents.filter(a => a.agentId !== agentId));
  };

  const updateAgentRole = async (agentId: string, role: string) => {
    await patchField('agents', projectAgents.map(a => a.agentId === agentId ? { ...a, role } : a));
  };

  const autoAssign = async () => {
    setAutoAssigning(true);
    try {
      const res = await fetch('/api/projects/auto-assign', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId }),
      });
      const data = await res.json();
      setSuggestions(data.suggestions || []);
    } catch { }
    setAutoAssigning(false);
  };

  const applySuggestions = async () => {
    if (!suggestions) return;
    await patchField('agents', suggestions);
    setSuggestions(null);
  };

  const addGoal = async () => {
    if (!newGoal.trim()) return;
    await patchField('goals', [...project.goals, newGoal.trim()]);
    setNewGoal('');
  };

  const removeGoal = async (idx: number) => {
    await patchField('goals', project.goals.filter((_: string, i: number) => i !== idx));
  };

  const addTask = async () => {
    if (!newTaskTitle.trim()) return;
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', title: newTaskTitle.trim(), assignee: newTaskAssignee || undefined, column: 'todo', projectId }),
    });
    setNewTaskTitle('');
    setNewTaskAssignee('');
    load();
  };

  const savePhaseEdit = async (phaseId: string) => {
    if (!project) return;
    const updatedPhases = (project.phases || []).map(p =>
      p.id === phaseId ? { ...p, name: editPhaseName, description: editPhaseDesc } : p
    );
    setEditingPhase(null);
    await patchField('phases', updatedPhases);
  };

  const fmtDate = (d: string) => {
    if (!d) return '—';
    try { return new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }); }
    catch { return '—'; }
  };

  const profileTabs = [
    { id: 'overview' as const, label: 'Overview', icon: '📋' },
    { id: 'phases' as const, label: `Phases (${completedPhases}/${totalPhases})`, icon: '🔨' },
    { id: 'protocol' as const, label: 'Protocol', icon: '⚡' },
    { id: 'protocol-builder' as const, label: 'Protocol Builder', icon: '🔧' },
    { id: 'agents' as const, label: 'Agents', icon: '👥' },
    { id: 'team' as const, label: 'Team', icon: '🏗️' },
    { id: 'lifecycle' as const, label: 'Lifecycle', icon: '🔄' },
    { id: 'tasks' as const, label: 'Tasks', icon: '✅' },
    { id: 'tests' as const, label: 'Tests', icon: '🧪' },
    { id: 'risks' as const, label: 'Risks', icon: '⚠️' },
    { id: 'stats' as const, label: 'Stats', icon: '📊' },
    { id: 'plan' as const, label: 'Plan', icon: '🚀' },
    { id: 'docs' as const, label: 'Docs', icon: '📁' },
    { id: 'reports' as const, label: 'Reports', icon: '📝' },
    { id: 'retrospective' as const, label: 'Retrospective', icon: '📋' },
  ];

  const content = (
    <div className="bg-mc-surface border border-mc-border rounded-lg flex flex-col" style={{ overflowAnchor: 'none' }}>
      {/* Header */}
      <div className="px-4 py-3 border-b border-mc-border flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <h2 className="text-lg font-bold truncate">{project.name}</h2>
            {(project as any).projectNumber && (
              <span className="text-xs font-mono text-mc-accent bg-mc-accent/10 px-2 py-0.5 rounded flex-shrink-0">
                {(project as any).projectNumber}
              </span>
            )}
            <span className={`px-2 py-0.5 rounded-full text-xs flex-shrink-0 ${STATUS_COLORS[project.status] || 'bg-mc-bg text-mc-muted'}`}>
              {project.status}
            </span>
            {/* Play/Pause Controls */}
            <div className="flex items-center gap-1 flex-shrink-0">
              <span className={`text-xs flex items-center gap-1 ${
                runStatus === 'running' ? 'text-green-400' :
                runStatus === 'paused' ? 'text-yellow-400' :
                'text-gray-400'
              }`}>
                {runStatus === 'running' ? '🟢' : runStatus === 'paused' ? '⏸️' : '⭕'}
              </span>
              <button
                onClick={() => handlePlayPause(runStatus === 'running' ? 'pause' : 'play')}
                disabled={orchestrating}
                className={`px-2 py-0.5 rounded text-[10px] font-medium flex items-center gap-1 transition-colors ${
                  runStatus === 'running'
                    ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                    : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                } disabled:opacity-50`}
                title={runStatus === 'running' ? 'Pause' : 'Play'}
              >
                {orchestrating ? '⏳' : runStatus === 'running' ? '⏸️ Pause' : '▶ Play'}
              </button>
            </div>
            {project.assignee && <span className="text-xs text-mc-muted flex-shrink-0">→ {project.assignee}</span>}
            {(project.tags || []).map(t => (
              <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-mc-bg text-mc-muted flex-shrink-0">#{t}</span>
            ))}
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {saving && <span className="text-xs text-mc-muted">Saving...</span>}
            <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-xl ml-2">✕</button>
          </div>
        </div>

        {/* Progress bar */}
        {totalPhases > 0 && (
          <div className="mt-2">
            <div className="flex items-center justify-between text-xs text-mc-muted mb-1">
              <span>Phase Progress</span>
              <span>{progressPct}%</span>
            </div>
            <div className="h-1.5 bg-mc-bg rounded-full overflow-hidden">
              <div className="h-full bg-mc-accent rounded-full transition-all" style={{ width: `${progressPct}%` }} />
            </div>
          </div>
        )}

        {/* Project XP & Efficiency */}
        {projectXp && (
          <div className="mt-3 pt-3 border-t border-mc-border/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-mc-muted uppercase tracking-wider">Project XP</span>
              <XPBadge level={projectXp.level} levelLabel={projectXp.levelLabel} showLabel />
            </div>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <XPBar 
                  xp={projectXp.xp} 
                  xpToNextLevel={projectXp.xpToNextLevel} 
                  progress={projectXp.progress} 
                  level={projectXp.level} 
                  levelLabel={projectXp.levelLabel} 
                />
              </div>
              <div className="flex-shrink-0">
                <EfficiencyMetric 
                  efficiency={projectXp.efficiency} 
                  totalTasks={projectXp.stats.totalTasks}
                  completedTasks={projectXp.stats.completedTasks}
                  showDetails
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Left Tab Nav + Content */}
      {/* Fixed: Single scrollable area to prevent nested scroll issues */}
      <div className="flex">
        {/* Vertical tab nav - non-scrolling, fixed width */}
        <div className={`${navCollapsed ? 'w-10' : 'w-36'} flex-shrink-0 border-r border-mc-border bg-mc-bg/30 flex flex-col`}>
          {/* Toggle button */}
          <button
            onClick={() => setNavCollapsed(!navCollapsed)}
            className="w-full px-2 py-2 text-xs text-center text-mc-muted hover:text-mc-accent hover:bg-mc-bg/50 border-b border-mc-border/50 flex-shrink-0"
            title={navCollapsed ? 'Expand navigation' : 'Collapse navigation'}
          >
            {navCollapsed ? '»' : '«'}
          </button>
          <div className="flex-1 flex flex-col overflow-visible">
            {profileTabs.map(t => (
              <button key={t.id} data-tab-id={t.id} onClick={() => handleTabChange(t.id)}
                className={`w-full px-2 py-2 text-xs text-left flex items-center gap-1.5 transition-colors ${tab === t.id ? 'bg-mc-accent/15 text-mc-accent border-r-2 border-mc-accent' : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg/50'}`}>
                <span className="flex-shrink-0">{t.icon}</span>
                {!navCollapsed && <span className="truncate">{t.label}</span>}
              </button>
            ))}
          </div>
        </div>

        {/* Tab content - scrollable area */}
        <div className="flex-1 p-4" id="project-content-area">
        {/* OVERVIEW TAB */}
        {tab === 'overview' && (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-mc-muted mb-1 block">Name</label>
              <input value={editName} onChange={e => setEditName(e.target.value)}
                onBlur={() => editName !== project.name && patchField('name', editName)}
                className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm" />
            </div>
            <div>
              <label className="text-xs text-mc-muted mb-1 block">Description</label>
              <textarea ref={descriptionRef} value={editDesc} onChange={e => setEditDesc(e.target.value)}
                onBlur={() => editDesc !== project.description && patchField('description', editDesc)}
                rows={1} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm resize-none overflow-hidden min-h-[160px]" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-xs text-mc-muted mb-1 block">Status</label>
                <select value={project.status} onChange={e => patchField('status', e.target.value)}
                  className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm">
                  {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                  {!STATUS_OPTIONS.includes(project.status) && <option value={project.status}>{project.status}</option>}
                </select>
              </div>
              <div>
                <label className="text-xs text-mc-muted mb-1 block">Priority</label>
                <select value={project.priority} onChange={e => patchField('priority', e.target.value)}
                  className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm">
                  {PRIORITY_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-mc-muted mb-1 block">Assignee</label>
                <select value={project.assignee || ''} onChange={e => patchField('assignee', e.target.value)}
                  className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm">
                  <option value="">Unassigned</option>
                  {ASSIGNEES.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="text-xs text-mc-muted mb-1 block">Goals</label>
              <div className="space-y-1 mb-2">
                {project.goals.map((g, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="text-mc-accent">🎯</span>
                    <span className="flex-1">{g}</span>
                    <button onClick={() => removeGoal(i)} className="text-red-400 hover:text-red-300 text-xs">✕</button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input value={newGoal} onChange={e => setNewGoal(e.target.value)} placeholder="Add goal..."
                  className="flex-1 bg-mc-bg border border-mc-border rounded px-3 py-1 text-sm"
                  onKeyDown={e => e.key === 'Enter' && addGoal()} />
                <button onClick={addGoal} className="px-2 py-1 text-xs bg-mc-accent/20 text-mc-accent rounded">Add</button>
              </div>
            </div>
            {/* Nesting / Parent */}
            <div>
              <label className="text-xs text-mc-muted mb-1 block">Parent Project</label>
              {project.parentProjectId ? (
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-mc-accent">📁</span>
                  <span>{allProjects.find((p: any) => p.id === project.parentProjectId)?.title || project.parentProjectId}</span>
                  <button onClick={() => patchField('parentProjectId', null)} className="text-red-400 hover:text-red-300 text-xs ml-2">✕ Remove</button>
                </div>
              ) : (
                <select value="" onChange={e => e.target.value && patchField('parentProjectId', e.target.value)}
                  className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm">
                  <option value="">🔗 Nest Under...</option>
                  {allProjects.filter((p: any) => p.id !== project.id).map((p: any) => (
                    <option key={p.id} value={p.id}>{p.title || p.name}</option>
                  ))}
                </select>
              )}
              {/* Breadcrumbs */}
              {project.parentProjectId && (() => {
                const chain: string[] = [];
                let cur = project.parentProjectId;
                for (let i = 0; i < 10 && cur; i++) {
                  const p = allProjects.find((pp: any) => pp.id === cur);
                  if (!p) break;
                  chain.unshift(p.title || p.name);
                  cur = p.parentProjectId;
                }
                return chain.length > 0 ? (
                  <div className="text-[10px] text-mc-muted mt-1">{chain.join(' → ')} → {project.title || project.name}</div>
                ) : null;
              })()}
              {/* Child projects */}
              {allProjects.filter((p: any) => p.parentProjectId === project.id).length > 0 && (
                <div className="mt-2">
                  <div className="text-[10px] text-mc-muted mb-1">Child Projects:</div>
                  {allProjects.filter((p: any) => p.parentProjectId === project.id).map((cp: any) => (
                    <div key={cp.id} className="text-xs ml-2 text-mc-accent">📁 {cp.title || cp.name}</div>
                  ))}
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4 text-xs text-mc-muted pt-2 border-t border-mc-border">
              <div>Created: {fmtDate(project.createdAt)}</div>
              <div>Updated: {fmtDate(project.updatedAt)}</div>
            </div>
            
            {/* Quick Links */}
            <div className="border-t border-mc-border pt-4">
              <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-3">📄 Project Documents</h4>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handleTabChange('reports')}
                  className="text-left p-3 bg-mc-bg border border-mc-border rounded-lg hover:border-mc-accent/50 transition-colors">
                  <div className="text-sm font-medium text-mc-text">📝 Reports</div>
                  <div className="text-xs text-mc-muted">View project reports</div>
                </button>
                <button onClick={() => handleTabChange('retrospective')}
                  className="text-left p-3 bg-mc-bg border border-mc-border rounded-lg hover:border-mc-accent/50 transition-colors">
                  <div className="text-sm font-medium text-mc-text">📋 Retrospective</div>
                  <div className="text-xs text-mc-muted">Project lessons learned</div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PHASES TAB */}
        {tab === 'phases' && (
          <div className="space-y-3">
            {phases.map((phase, idx) => {
              const isExpanded = expandedPhase === phase.id;
              return (
                <div key={phase.id} className="bg-mc-bg rounded-lg border border-mc-border overflow-hidden">
                  <div className="flex items-center justify-between p-3 cursor-pointer" onClick={() => setExpandedPhase(isExpanded ? null : phase.id)}>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-mc-muted font-mono w-6">P{idx + 1}</span>
                      <span className="text-sm font-medium">{phase.name}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded border ${STATUS_COLORS[phase.status] || STATUS_COLORS.todo}`}>
                        {phase.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <select value={phase.status}
                        onClick={e => e.stopPropagation()}
                        onChange={e => updatePhaseStatus(phase.id, e.target.value)}
                        className="text-[10px] bg-mc-surface border border-mc-border rounded px-1.5 py-0.5 text-mc-text">
                        {PHASE_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      <button onClick={e => { e.stopPropagation(); removePhase(phase.id); }}
                        className="text-xs text-mc-muted hover:text-red-400">✕</button>
                      <span className="text-mc-muted text-xs">{isExpanded ? '▼' : '▶'}</span>
                    </div>
                  </div>
                  {isExpanded && (
                    <div className="px-3 pb-3 pt-0 border-t border-mc-border/50">
                      {editingPhase === phase.id ? (
                        <div className="mt-2 space-y-2">
                          <input value={editPhaseName} onChange={e => setEditPhaseName(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && savePhaseEdit(phase.id)}
                            className="w-full bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm text-mc-text focus:outline-none focus:border-mc-accent"
                            placeholder="Phase name" />
                          <textarea value={editPhaseDesc} onChange={e => setEditPhaseDesc(e.target.value)}
                            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); savePhaseEdit(phase.id); } }}
                            rows={2}
                            className="w-full bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-y"
                            placeholder="Phase description" />
                          <div className="flex gap-2">
                            <button onClick={() => savePhaseEdit(phase.id)} className="px-2 py-1 text-xs bg-mc-accent text-white rounded">Save</button>
                            <button onClick={() => setEditingPhase(null)} className="px-2 py-1 text-xs text-mc-muted border border-mc-border rounded">Cancel</button>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-2 mb-3">
                          <div className="flex items-center gap-2">
                            <p className="text-xs text-mc-muted flex-1">{phase.description}</p>
                            <button onClick={e => { e.stopPropagation(); setEditingPhase(phase.id); setEditPhaseName(phase.name); setEditPhaseDesc(phase.description); }}
                              className="text-xs text-mc-muted hover:text-mc-accent" title="Edit phase">✏️</button>
                          </div>
                        </div>
                      )}
                      {(phase.requirements || []).length > 0 && (
                        <div>
                          <h4 className="text-[10px] font-semibold text-mc-accent uppercase tracking-wider mb-1.5">Requirements</h4>
                          <ul className="space-y-1">
                            {(phase.requirements || []).map((req, i) => (
                              <li key={i} className="flex items-start gap-2 text-xs text-mc-text">
                                <span className="text-mc-muted mt-0.5">•</span>
                                <span>{req}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}

            {addingPhase ? (
              <div className="bg-mc-bg rounded-lg border border-mc-accent/30 p-3 space-y-2">
                <input value={newPhaseName} onChange={e => setNewPhaseName(e.target.value)}
                  placeholder="Phase name..." className="w-full px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                <textarea value={newPhaseDesc} onChange={e => setNewPhaseDesc(e.target.value)}
                  placeholder="Phase description..." rows={2}
                  className="w-full px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-sm text-mc-text focus:outline-none focus:border-mc-accent resize-y" />
                <div className="flex gap-2">
                  <button onClick={addPhase} className="px-3 py-1 text-xs bg-mc-accent text-white rounded">Add Phase</button>
                  <button onClick={() => setAddingPhase(false)} className="px-3 py-1 text-xs text-mc-muted border border-mc-border rounded">Cancel</button>
                </div>
              </div>
            ) : (
              <button onClick={() => setAddingPhase(true)}
                className="w-full py-2 border border-dashed border-mc-border rounded-lg text-sm text-mc-muted hover:border-mc-accent hover:text-mc-accent transition-colors">
                + Add Phase
              </button>
            )}

            {phases.length === 0 && !addingPhase && (
              <div className="text-center text-mc-muted py-6 text-sm">No phases defined yet. Add one to track project milestones.</div>
            )}
          </div>
        )}

        {/* PROTOCOL TAB */}
        {tab === 'protocol' && <ProtocolTab projectId={project.id} projectTitle={project.title || project.name} />}

        {tab === 'protocol-builder' && <ProtocolBuilderTab projectId={project.id} projectTitle={project.title || project.name} />}

        {/* AGENTS TAB */}
        {tab === 'agents' && (
          <div className="space-y-3">
            <div className="flex gap-2 mb-3">
              <button onClick={() => setShowAddAgent(true)} className="px-3 py-1.5 bg-mc-accent/20 text-mc-accent rounded text-sm">+ Add Agent</button>
              <button onClick={autoAssign} disabled={autoAssigning}
                className="px-3 py-1.5 bg-purple-500/20 text-purple-400 rounded text-sm disabled:opacity-50">
                {autoAssigning ? '🔄 Analyzing...' : '🤖 Auto-Assign Agents'}
              </button>
            </div>

            {suggestions && (
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <div className="text-sm font-medium text-purple-400 mb-2">AI Suggestions:</div>
                {suggestions.map((s, i) => (
                  <div key={i} className="text-sm flex gap-2">
                    <span className="font-medium">{agentMap[s.agentId]?.displayName || s.agentId}</span>
                    <span className="text-mc-muted">→ {s.role}</span>
                  </div>
                ))}
                <div className="flex gap-2 mt-2">
                  <button onClick={applySuggestions} className="px-2 py-1 bg-mc-accent text-white rounded text-xs">Apply</button>
                  <button onClick={() => setSuggestions(null)} className="px-2 py-1 text-mc-muted text-xs">Dismiss</button>
                </div>
              </div>
            )}

            {showAddAgent && (
              <div className="p-3 bg-mc-bg border border-mc-border rounded-lg space-y-2">
                <select value={addAgentId} onChange={e => setAddAgentId(e.target.value)}
                  className="w-full bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm">
                  <option value="">Select agent...</option>
                  {availableAgents.map(a => <option key={a.id} value={a.id}>{a.displayName || a.name}</option>)}
                </select>
                <div className="flex gap-2">
                  <select value={addAgentRole} onChange={e => { setAddAgentRole(e.target.value); setCustomRole(''); }}
                    className="flex-1 bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm">
                    <option value="">Select role...</option>
                    {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                  <input value={customRole} onChange={e => { setCustomRole(e.target.value); setAddAgentRole(''); }}
                    placeholder="Or type custom role..." className="flex-1 bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm" />
                </div>
                <div className="flex gap-2">
                  <button onClick={addAgent} className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm">Add</button>
                  <button onClick={() => setShowAddAgent(false)} className="px-3 py-1.5 text-mc-muted text-sm">Cancel</button>
                </div>
              </div>
            )}

            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-mc-muted border-b border-mc-border">
                  <th className="text-left px-2 py-1.5">Agent</th>
                  <th className="text-left px-2 py-1.5">Role</th>
                  <th className="px-2 py-1.5 w-10"></th>
                </tr>
              </thead>
              <tbody>
                {projectAgents.map(pa => (
                  <tr key={pa.agentId} className="border-b border-mc-border/30">
                    <td className="px-2 py-2 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold"
                        style={{ background: agentMap[pa.agentId]?.color || '#666' }}>
                        {(agentMap[pa.agentId]?.initials || pa.agentId[0] || '?').slice(0, 2)}
                      </span>
                      {agentMap[pa.agentId]?.displayName || pa.agentId}
                    </td>
                    <td className="px-2 py-2">
                      <select value={ROLES.includes(pa.role) ? pa.role : '__custom'} onChange={e => {
                        if (e.target.value !== '__custom') updateAgentRole(pa.agentId, e.target.value);
                      }} className="bg-mc-bg border border-mc-border rounded px-2 py-0.5 text-xs">
                        {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                        {!ROLES.includes(pa.role) && <option value="__custom">{pa.role}</option>}
                      </select>
                    </td>
                    <td className="px-2 py-2 text-center">
                      <button onClick={() => removeAgent(pa.agentId)} className="text-red-400 hover:text-red-300 text-xs">✕</button>
                    </td>
                  </tr>
                ))}
                {projectAgents.length === 0 && (
                  <tr><td colSpan={3} className="px-2 py-6 text-center text-mc-muted">No agents assigned</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TEAM TAB */}
        {tab === 'team' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-mc-text">Project Team</h3>
              <button onClick={() => setShowTeamBuilder(true)}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-sm font-semibold transition-colors">
                {(project as any).team?.length ? '✏️ Edit Team' : '🏗️ Add Team'}
              </button>
            </div>
            {(project as any).team?.length > 0 ? (
              <div className="space-y-2">
                {(project as any).team.map((member: any, i: number) => {
                  const agent = agentMap[member.agentId];
                  return (
                    <div key={i} className="bg-mc-bg border border-mc-border rounded-lg p-3">
                      <div className="flex items-center gap-3 mb-2">
                        {agent && (
                          <span className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0"
                            style={{ background: agent.color || '#666' }}>
                            {(agent.initials || '?').slice(0, 2)}
                          </span>
                        )}
                        <div className="flex-1">
                          <div className="text-sm font-medium text-mc-text">
                            {agent?.displayName || member.agentId || (member.pmAssign ? '🎯 PM will assign' : 'Unassigned')}
                          </div>
                          <div className="text-xs text-mc-accent">{member.roleTitle}</div>
                          {member.pmAssign && !member.agentId && (
                            <div className="text-[10px] text-yellow-400/70 mt-0.5">Project Manager determines who fills this role</div>
                          )}
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[10px] text-mc-muted">Model:</span>
                            <select
                              value={member.modelOverride || ''}
                              onChange={async (e) => {
                                const newTeam = (project as any).team.map((m: any, idx: number) =>
                                  idx === i ? { ...m, modelOverride: e.target.value || null } : m
                                );
                                await patchField('team', newTeam);
                              }}
                              className="bg-mc-bg border border-mc-border rounded px-1.5 py-0.5 text-[10px] text-mc-text"
                            >
                              <option value="">{agent?.model ? `${agent.model} (default)` : 'Default'}</option>
                              {AVAILABLE_MODELS.map(m => (
                                <option key={m} value={m}>{m}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <button onClick={async () => {
                          const newTeam = (project as any).team.filter((_: any, idx: number) => idx !== i);
                          await patchField('team', newTeam);
                        }} className="text-mc-muted hover:text-red-400 text-xs">✕</button>
                      </div>
                      {member.rules?.length > 0 && (
                        <div className="mb-2">
                          <div className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider mb-1">Rules</div>
                          <ul className="space-y-0.5">
                            {member.rules.map((r: string, j: number) => (
                              <li key={j} className="text-xs text-mc-text flex items-start gap-1.5">
                                <span className="text-indigo-400 mt-0.5 flex-shrink-0">•</span>{r}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {member.expectedDocuments?.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {member.expectedDocuments.map((d: string, j: number) => (
                            <span key={j} className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400">📄 {d}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center text-mc-muted py-8 text-sm">
                No team configured yet. Click &quot;Add Team&quot; to set up roles, rules, and auto-assign agents.
              </div>
            )}
          </div>
        )}

        {/* LIFECYCLE TAB */}
        {tab === 'lifecycle' && <ProjectLifecycle projectId={project.id} agentMap={agentMap} />}

        {/* TASKS TAB */}
        {tab === 'tasks' && (
          <div>
            {tasks.length === 0 ? (
              <div className="text-center text-mc-muted py-8">No tasks linked to this project yet.</div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-mc-muted border-b border-mc-border">
                    <th className="text-left px-2 py-1.5">Task</th>
                    <th className="text-left px-2 py-1.5">Status</th>
                    <th className="text-left px-2 py-1.5">Assignee</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map(t => (
                    <tr key={t.id} className="border-b border-mc-border/30">
                      <td className="px-2 py-2">{t.title}</td>
                      <td className="px-2 py-2 text-xs">
                        <span className={`px-2 py-0.5 rounded-full ${
                          t.column === 'complete' ? 'bg-green-500/20 text-green-400' :
                          t.column === 'in-progress' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-mc-bg text-mc-muted'
                        }`}>{t.column}</span>
                      </td>
                      <td className="px-2 py-2 text-xs text-mc-muted">{t.assignee || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <div className="mt-4 p-3 bg-mc-bg border border-mc-border rounded-lg">
              <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">Add Task</h4>
              <div className="flex gap-2">
                <input value={newTaskTitle} onChange={e => setNewTaskTitle(e.target.value)}
                  placeholder="Task title..." onKeyDown={e => e.key === 'Enter' && addTask()}
                  className="flex-1 bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm text-mc-text focus:outline-none focus:border-mc-accent" />
                <select value={newTaskAssignee} onChange={e => setNewTaskAssignee(e.target.value)}
                  className="bg-mc-surface border border-mc-border rounded px-3 py-1.5 text-sm text-mc-text">
                  <option value="">Assignee...</option>
                  {TASK_ASSIGNEES.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
                <button onClick={addTask} className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm">Add</button>
              </div>
            </div>
          </div>
        )}

        {/* STATS TAB */}
        {tab === 'stats' && (() => {
          const projectAgentIds = (project.agents || []).map(a => a.agentId);
          const agentUsage = usage.filter(u => projectAgentIds.includes(u.agentId || u.agent));
          const totalCost = agentUsage.reduce((s, u) => s + (u.cost || 0), 0);
          const totalTokens = agentUsage.reduce((s, u) => s + (u.tokens || u.totalTokens || 0), 0);
          const totalRequests = agentUsage.reduce((s, u) => s + (u.requests || u.count || 0), 0);
          const completedByAgent: Record<string, number> = {};
          tasks.filter(t => t.column === 'complete').forEach(t => {
            if (t.assignee) completedByAgent[t.assignee] = (completedByAgent[t.assignee] || 0) + 1;
          });
          return (
            <div className="space-y-4">
              {/* Cost Summary */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-mc-bg border border-mc-border rounded-lg p-3 text-center">
                  <div className="text-xs text-mc-muted mb-1">Total Cost</div>
                  <div className="text-lg font-bold text-mc-accent">${totalCost.toFixed(4)}</div>
                </div>
                <div className="bg-mc-bg border border-mc-border rounded-lg p-3 text-center">
                  <div className="text-xs text-mc-muted mb-1">Total Tokens</div>
                  <div className="text-lg font-bold text-mc-text">{totalTokens.toLocaleString()}</div>
                </div>
                <div className="bg-mc-bg border border-mc-border rounded-lg p-3 text-center">
                  <div className="text-xs text-mc-muted mb-1">Total Requests</div>
                  <div className="text-lg font-bold text-mc-text">{totalRequests.toLocaleString()}</div>
                </div>
              </div>

              {/* Agent Breakdown */}
              <div>
                <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">Agent Breakdown</h4>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-mc-muted border-b border-mc-border">
                      <th className="text-left px-2 py-1.5">Agent</th>
                      <th className="text-left px-2 py-1.5">Model</th>
                      <th className="text-right px-2 py-1.5">Tokens</th>
                      <th className="text-right px-2 py-1.5">Cost</th>
                      <th className="text-right px-2 py-1.5">Tasks Done</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projectAgentIds.map(aid => {
                      const au = agentUsage.filter(u => (u.agentId || u.agent) === aid);
                      const tokens = au.reduce((s, u) => s + (u.tokens || u.totalTokens || 0), 0);
                      const cost = au.reduce((s, u) => s + (u.cost || 0), 0);
                      const name = agentMap[aid]?.displayName || aid;
                      const done = completedByAgent[name] || completedByAgent[aid] || 0;
                      
                      // Get model used by this agent (prefer from actual usage data)
                      const modelsUsed = [...new Set(au.map(u => u.model).filter(Boolean))];
                      const modelDisplay = modelsUsed.length > 0 
                        ? modelsUsed.map(m => m.split('/').pop()).join(', ')
                        : (agentMap[aid]?.model ? agentMap[aid].model.split('/').pop() : '—');
                      
                      return (
                        <tr key={aid} className="border-b border-mc-border/30">
                          <td className="px-2 py-2">{name}</td>
                          <td className="px-2 py-2 text-xs text-mc-muted">{modelDisplay}</td>
                          <td className="px-2 py-2 text-right text-xs">{tokens.toLocaleString()}</td>
                          <td className="px-2 py-2 text-right text-xs">${cost.toFixed(4)}</td>
                          <td className="px-2 py-2 text-right text-xs">{done}</td>
                        </tr>
                      );
                    })}
                    {projectAgentIds.length === 0 && (
                      <tr><td colSpan={5} className="px-2 py-4 text-center text-mc-muted text-xs">No agents assigned</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Activity Timeline */}
              <div>
                <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">Recent Activity</h4>
                {projectActivity.length === 0 ? (
                  <div className="text-xs text-mc-muted text-center py-4">No recent activity for this project&apos;s agents</div>
                ) : (
                  <div className="space-y-1 max-h-48 overflow-y-auto">
                    {projectActivity.slice(0, 30).map((e, i) => {
                      // Validate timestamp - don't show future dates
                      let timeStr = '—';
                      try {
                        const date = new Date(e.timestamp);
                        const now = new Date();
                        if (date.getTime() <= now.getTime() + 60000) { // Allow 1 min tolerance
                          timeStr = date.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
                        } else {
                          timeStr = '⚠️ future';
                        }
                      } catch { timeStr = '—'; }
                      
                      return (
                        <div key={i} className="flex items-center gap-2 text-xs py-1 border-b border-mc-border/20">
                          <span className="text-mc-muted w-28 flex-shrink-0">{timeStr}</span>
                          <span className="font-medium text-mc-accent">{e.agent}</span>
                          <span className="text-mc-text truncate">{e.action || e.description || e.type}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Cost Breakdown from COST.md */}
              <div className="border-t border-mc-border pt-4">
                <h4 className="text-xs font-semibold text-mc-muted uppercase tracking-wider mb-2">💰 Cost Breakdown (COST.md)</h4>
                {!costData || !costData.table || !costData.table.rows || costData.table.rows.length === 0 ? (
                  <div className="text-xs text-mc-muted text-center py-4">No cost data yet — create a COST.md file in the project directory.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-mc-border text-mc-muted">
                          {(costData.table.headers || []).map((h, i) => (
                            <th key={i} className="text-left px-2 py-1.5 font-semibold uppercase tracking-wider">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(costData.table.rows || []).map((row, ri) => {
                          const isTotal = row.some(cell => /total/i.test(cell));
                          return (
                            <tr
                              key={ri}
                              className={`border-b border-mc-border/30 ${isTotal ? 'bg-mc-accent/10 font-bold text-mc-accent' : 'hover:bg-mc-bg/50'}`}
                            >
                              {row.map((cell, ci) => (
                                <td key={ci} className={`px-2 py-1.5 ${isTotal ? 'text-mc-accent' : 'text-mc-text'}`}>{cell}</td>
                              ))}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          );
        })()}

        {/* TESTS TAB */}
        {tab === 'tests' && <TestPlanTab projectId={project.id} projectTitle={project.title || project.name} />}

        {/* RISKS TAB */}
        {tab === 'risks' && <RiskAssessmentTab projectId={project.id} />}

        {/* PLAN TAB */}
        {tab === 'plan' && <PlayThePlanTab projectId={project.id} projectTitle={project.title || project.name} />}

        {tab === 'reports' && <ProjectReportsTab projectId={project.id} projectTitle={project.title || project.name} onNavigateTab={(tabId) => handleTabChange(tabId as typeof tab)} />}

        {tab === 'retrospective' && <RetrospectiveTab projectId={project.id} />}

        {/* DOCS TAB */}
        {tab === 'docs' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-mc-text">📁 Project Documents</h3>
              <button
                onClick={() => {
                  setDocsLoading(true);
                  fetch(`/api/projects/${projectId}/documents`)
                    .then(r => r.json())
                    .then(d => setDocs(d.documents || []))
                    .catch(() => {})
                    .finally(() => setDocsLoading(false));
                }}
                className="text-xs text-mc-muted hover:text-mc-accent"
                title="Refresh"
              >
                🔄 Refresh
              </button>
            </div>

            {docsLoading ? (
              <div className="text-center py-8 text-mc-muted text-sm">Loading documents...</div>
            ) : docs.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-4xl mb-3">📂</div>
                <div className="text-sm text-mc-muted">No documents found for this project yet.</div>
                <div className="text-xs text-mc-muted/60 mt-1">Documents like PLAN.md, TASKS.md, COST.md will appear here.</div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {docs.map(doc => {
                  const sizeKb = doc.size > 0 ? (doc.size / 1024).toFixed(1) : '0';
                  const mtime = doc.mtime
                    ? new Date(doc.mtime).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                    : '—';
                  const isMarkdown = doc.name.endsWith('.md');
                  return (
                    <div key={doc.name} className="bg-mc-bg border border-mc-border rounded-lg p-3 flex flex-col gap-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-lg flex-shrink-0">{isMarkdown ? '📝' : '📄'}</span>
                          <div className="min-w-0">
                            <div className="text-sm font-medium text-mc-text truncate">{doc.name}</div>
                            <div className="text-[10px] text-mc-muted">{sizeKb} KB · {mtime}</div>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={async () => {
                            try {
                              const r = await fetch(`/api/projects/${projectId}/documents/${encodeURIComponent(doc.name)}`);
                              const d = await r.json();
                              setDocModal({ name: doc.name, content: d.content || '' });
                            } catch {
                              setDocModal({ name: doc.name, content: 'Failed to load document.' });
                            }
                          }}
                          className="flex-1 px-2 py-1.5 bg-mc-accent/20 text-mc-accent rounded text-xs hover:bg-mc-accent/30 transition-colors"
                        >
                          👁 View
                        </button>
                        <a
                          href={`/api/projects/${projectId}/documents/${encodeURIComponent(doc.name)}?download=1`}
                          download={doc.name}
                          className="flex-1 px-2 py-1.5 bg-mc-surface border border-mc-border text-mc-text rounded text-xs hover:border-mc-accent/50 transition-colors text-center"
                          onClick={e => e.stopPropagation()}
                        >
                          ⬇ Download
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
      </div>{/* end flex wrapper */}

      {/* Project Chat moved outside details card in non-modal mode to prevent layout compression */}

      {/* Document Viewer Modal */}
      {docModal && (
        <DocumentViewerModal doc={docModal} onClose={() => setDocModal(null)} />
      )}

      {/* Team Builder Modal */}
      {showTeamBuilder && (
        <TeamBuilder
          projectId={project.id}
          agentMap={agentMap}
          allAgents={allAgents}
          onClose={() => setShowTeamBuilder(false)}
          onApply={async (team) => {
            await patchField('team', team);
            setShowTeamBuilder(false);
            handleTabChange('team');
          }}
        />
      )}
    </div>
  );

  if (modal) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
        <div className="w-full max-w-4xl mx-2" onClick={e => e.stopPropagation()}>
          {content}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <button onClick={onClose} className="text-mc-muted hover:text-mc-text text-sm mb-3 flex items-center gap-1">
        ← Back to Projects
      </button>
      {content}

      {/* Non-modal chat lives below the details card so it can never compress project content */}
      <div className="mt-3 bg-mc-surface border border-mc-border rounded-lg">
        <button
          onClick={() => setChatExpanded(v => !v)}
          className="w-full px-3 py-2 flex items-center justify-between text-xs text-mc-text hover:bg-mc-bg/30"
        >
          <span className="flex items-center gap-2"><span>💬</span><span className="font-semibold">Project Chat</span></span>
          <span className="text-mc-muted">{chatExpanded ? 'Hide' : 'Show'}</span>
        </button>
        {chatExpanded && (
          <div className="p-2 pt-0">
            <ProjectChat projectId={project.id} />
          </div>
        )}
      </div>
    </div>
  );
}
