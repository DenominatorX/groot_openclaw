'use client';
import { useState, useEffect } from 'react';
import MarkdownMessage from './MarkdownMessage';

interface Agent {
  id: string; name: string; displayName?: string; color: string; defaultModel?: string | null; capabilities?: string[];
}

interface Issue {
  id: string; issueNumber: string; title: string; description: string;
  category: string; status: string; priority: string; projectId: string | null;
  assignee: string; reporter: string; instructions: string; resolution: string;
  linkedProjectId: string | null; chatHistory: any[]; media: any[];
  createdAt: string; updatedAt: string;
  workflowStage?: string; proposedSolution?: string; executionLogs?: any[]; testCase?: string;
}

const CAT_ICONS: Record<string, string> = {
  defect: '🐛', question: '❓', 'design-discussion': '🎨', requirement: '📋',
  enhancement: '✨', task: '📌', reminder: '⏰',
};

const STATUS_COLORS: Record<string, string> = {
  open: 'bg-blue-500/20 text-blue-400',
  'in-progress': 'bg-yellow-500/20 text-yellow-400',
  resolved: 'bg-green-500/20 text-green-400',
  'needs-project': 'bg-purple-500/20 text-purple-400',
  closed: 'bg-gray-500/20 text-gray-400',
};

const PRIORITY_COLORS: Record<string, string> = {
  critical: 'text-red-400', high: 'text-orange-400', medium: 'text-yellow-400', low: 'text-blue-400',
};

export default function IssuesLog() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [version, setVersion] = useState('1.0.0');
  const [filter, setFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('non-closed');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Issue | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState('defect');
  const [newPriority, setNewPriority] = useState('medium');
  const [newInstructions, setNewInstructions] = useState('');
  const [playing, setPlaying] = useState<string | null>(null);
  const [showWorkflow, setShowWorkflow] = useState(false);
  const [workflowLogs, setWorkflowLogs] = useState<any[]>([]);
  const [workflowStage, setWorkflowStage] = useState<string>('');
  const [testCase, setTestCase] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [editingIssue, setEditingIssue] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [saving, setSaving] = useState(false);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<string>('');

  // Fetch available agents
  useEffect(() => {
    fetch('/api/agents').then(r => r.json()).then(d => {
      const agentList = d.agents || [];
      setAgents(agentList);
      if (agentList.length > 0) {
        const architect = agentList.find((a: Agent) => a.id === 'architect');
        const codingAgent = architect || agentList.find((a: Agent) => a.capabilities?.includes('coding'));
        setSelectedAgent(codingAgent?.id || agentList[0].id);
      }
    }).catch(() => {});
  }, []);

  const load = () => {
    fetch('/api/issues').then(r => r.json()).then(d => {
      setIssues(d.issues || []);
      setCategories(d.categories || []);
      setVersion(d.version || '1.0.0');
    }).catch(() => {});
  };
  useEffect(load, []);

  const filtered = issues
    .filter(i => filter === 'all' || i.category === filter)
    .filter(i => statusFilter === 'all' || (statusFilter === 'non-closed' ? i.status !== 'closed' : i.status === statusFilter))
    .filter(i => !search || i.title.toLowerCase().includes(search.toLowerCase()) || i.issueNumber.toLowerCase().includes(search.toLowerCase()));

  const createIssue = async () => {
    if (!newTitle.trim()) return;
    await fetch('/api/issues', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'create', title: newTitle, description: newDesc,
        category: newCategory, priority: newPriority, instructions: newInstructions,
      }),
    });
    setShowNew(false); setNewTitle(''); setNewDesc(''); setNewInstructions('');
    load();
  };

  const playIssue = async (id: string) => {
    // Find the issue and set as selected to show detail view
    const issue = issues.find(i => i.id === id);
    if (issue) {
      setSelected(issue);
    }
    
    // Check if already resolved - don't re-analyze
    if (issue?.status === 'resolved' || issue?.workflowStage === 'validated') {
      setShowWorkflow(true);
      setWorkflowStage('validated');
      setWorkflowLogs(issue.executionLogs || []);
      setTestCase(issue.testCase || '');
      return;
    }
    
    setPlaying(id);
    setShowWorkflow(true);
    const agent = agents.find(a => a.id === selectedAgent);
    setWorkflowLogs([{ time: new Date().toISOString(), message: `🔍 Analyzing issue with agent ${agent?.displayName || selectedAgent}...` }]);
    setWorkflowStage('analyzing');
    try {
      const r = await fetch('/api/issues', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'analyze', id, agentId: selectedAgent }),
      });
      const data = await r.json();
      if (data.success) {
        setWorkflowStage('proposed');
        setWorkflowLogs([{ time: new Date().toISOString(), message: '✅ Analysis complete. Review the proposed solution below.' }]);
        if (data.testCase) setTestCase(data.testCase);
        load();
        if (data.issue) setSelected(data.issue);
      } else {
        setWorkflowStage('failed');
        setWorkflowLogs([{ time: new Date().toISOString(), message: `❌ Error: ${data.error}` }]);
      }
    } catch (e: any) {
      setWorkflowStage('failed');
      setWorkflowLogs([{ time: new Date().toISOString(), message: `❌ Error: ${e.message}` }]);
    } finally { setPlaying(null); }
  };

  const approveSolution = async (approved: boolean) => {
    if (!selected) return;
    setPlaying(selected.id);
    try {
      const r = await fetch('/api/issues', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'approve', id: selected.id, approved }),
      });
      const data = await r.json();
      if (data.success) {
        if (approved) {
          setWorkflowStage('executing');
          setWorkflowLogs(prev => [...prev, { time: new Date().toISOString(), message: '🚀 Executing fix...' }]);
          // DON'T close flyout - execute and keep open
          executeFix(selected.id, true);
        } else {
          setWorkflowStage('rejected');
          setWorkflowLogs(prev => [...prev, { time: new Date().toISOString(), message: '❌ Solution rejected by user.' }]);
        }
        load();
      }
    } catch (e: any) {
      setWorkflowLogs(prev => [...prev, { time: new Date().toISOString(), message: `❌ Error: ${e.message}` }]);
    } finally { setPlaying(null); }
  };

  const executeFix = async (id: string, keepOpen: boolean = false) => {
    const agent = agents.find(a => a.id === selectedAgent);
    setWorkflowLogs(prev => [...prev, { time: new Date().toISOString(), message: `⚡ Executing fix with ${agent?.displayName || selectedAgent}...` }]);
    try {
      const r = await fetch('/api/issues', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'execute', id, agentId: selectedAgent }),
      });
      const data = await r.json();
      if (data.success) {
        setWorkflowStage('validated');
        setWorkflowLogs(prev => [
          ...prev,
          { time: new Date().toISOString(), message: '✅ Fix implemented successfully!' },
          { time: new Date().toISOString(), message: '🧪 Validation complete.' }
        ]);
        if (data.executionResult) {
          setWorkflowLogs(prev => [...prev, { 
            time: new Date().toISOString(), 
            message: '📝 Results:',
            result: data.executionResult 
          }]);
        }
        load();
        if (data.issue) setSelected(data.issue);
      } else {
        setWorkflowStage('failed');
        setWorkflowLogs(prev => [...prev, { time: new Date().toISOString(), message: `❌ Execution failed: ${data.error}` }]);
      }
    } catch (e: any) {
      setWorkflowStage('failed');
      setWorkflowLogs(prev => [...prev, { time: new Date().toISOString(), message: `❌ Error: ${e.message}` }]);
    }
  };

  const updateStatus = async (id: string, status: string) => {
    await fetch('/api/issues', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id, fields: { status } }),
    });
    load();
    if (selected?.id === id) setSelected({ ...selected, status });
  };

  const startEdit = (issue: Issue) => {
    setEditTitle(issue.title);
    setEditDesc(issue.description || '');
    setEditingIssue(true);
  };

  const cancelEdit = () => {
    setEditingIssue(false);
    setEditTitle('');
    setEditDesc('');
  };

  const saveEdit = async () => {
    if (!selected || !editTitle.trim()) return;
    setSaving(true);
    const res = await fetch('/api/issues', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id: selected.id, fields: { title: editTitle.trim(), description: editDesc } }),
    });
    const data = await res.json();
    if (data.success) {
      const updated = { ...selected, title: editTitle.trim(), description: editDesc, updatedAt: new Date().toISOString() };
      setSelected(updated);
      setIssues(prev => prev.map(i => i.id === selected.id ? { ...i, title: editTitle.trim(), description: editDesc } : i));
      setEditingIssue(false);
    }
    setSaving(false);
  };

  if (selected) {
    return (
      <div className="space-y-3">
        <button onClick={() => setSelected(null)} className="text-xs text-mc-accent hover:underline">← Back to Issues Log</button>
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-2xl">{CAT_ICONS[selected.category] || '📋'}</span>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-mc-muted">{selected.issueNumber}</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] ${STATUS_COLORS[selected.status] || ''}`}>{selected.status}</span>
                <span className={`text-[10px] capitalize ${PRIORITY_COLORS[selected.priority] || ''}`}>{selected.priority}</span>
              </div>
              {editingIssue ? (
                <input
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  className="font-bold text-lg bg-mc-bg border border-mc-accent rounded px-2 py-0.5 w-full focus:outline-none focus:ring-1 focus:ring-mc-accent"
                  autoFocus
                  onKeyDown={e => { if (e.key === 'Enter') saveEdit(); if (e.key === 'Escape') cancelEdit(); }}
                />
              ) : (
                <h2 className="font-bold text-lg">{selected.title}</h2>
              )}
            </div>
            <div className="flex gap-2 flex-shrink-0">
              {editingIssue ? (
                <>
                  <button onClick={saveEdit} disabled={saving}
                    className="px-3 py-1.5 bg-green-600/20 text-green-400 rounded text-sm hover:bg-green-600/30 disabled:opacity-50">
                    {saving ? '⏳ Saving…' : '💾 Save'}
                  </button>
                  <button onClick={cancelEdit}
                    className="px-3 py-1.5 bg-gray-600/20 text-gray-400 rounded text-sm hover:bg-gray-600/30">
                    ✕ Cancel
                  </button>
                </>
              ) : (
                <button onClick={() => startEdit(selected)}
                  className="px-3 py-1.5 bg-mc-bg border border-mc-border text-mc-muted rounded text-sm hover:text-mc-text hover:border-mc-accent transition-colors"
                  title="Edit title & description">
                  ✏️ Edit
                </button>
              )}
              {/* Issue Resolver button - opens flyout but doesn't auto-analyze */}
              <button onClick={() => { setShowWorkflow(true); setWorkflowStage(selected.workflowStage || 'ready'); setWorkflowLogs(selected.executionLogs || []); setTestCase(selected.testCase || ''); }}
                className="px-3 py-1.5 bg-purple-600/20 text-purple-400 rounded text-sm hover:bg-purple-600/30"
                title="Issue Resolver">
                🤖 Resolver
              </button>
              {/* Re-analyze button - forces fresh analysis */}
              <button onClick={async () => {
                if (!confirm('Re-analyze this issue? This will generate a new solution.')) return;
                setPlaying(selected.id);
                setShowWorkflow(true);
                setWorkflowLogs([{ time: new Date().toISOString(), message: '🔄 Re-analyzing issue...' }]);
                setWorkflowStage('analyzing');
                try {
                  const r = await fetch('/api/issues', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'analyze', id: selected.id, force: true, agentId: selectedAgent }),
                  });
                  const data = await r.json();
                  if (data.success) {
                    setWorkflowStage('proposed');
                    setWorkflowLogs([{ time: new Date().toISOString(), message: '✅ Re-analysis complete. Review the new proposed solution.' }]);
                    if (data.testCase) setTestCase(data.testCase);
                    load();
                    if (data.issue) setSelected(data.issue);
                  } else {
                    setWorkflowStage('failed');
                    setWorkflowLogs([{ time: new Date().toISOString(), message: `❌ Error: ${data.error}` }]);
                  }
                } catch (e: any) {
                  setWorkflowStage('failed');
                  setWorkflowLogs([{ time: new Date().toISOString(), message: `❌ Error: ${e.message}` }]);
                } finally { setPlaying(null); }
              }}
                className="px-3 py-1.5 bg-blue-600/20 text-blue-400 rounded text-sm hover:bg-blue-600/30"
                title="Re-analyze this issue">
                🔄 Re-analyze
              </button>
              {['open', 'in-progress', 'resolved', 'closed'].map(s => (
                <button key={s} onClick={() => updateStatus(selected.id, s)}
                  className={`px-2 py-1 rounded text-[10px] capitalize ${selected.status === s ? 'bg-mc-accent/20 text-mc-accent' : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3 text-xs">
            <div><span className="text-mc-muted">Assignee:</span> <span className="font-medium">🛡️ {selected.assignee}</span></div>
            <div><span className="text-mc-muted">Reporter:</span> <span className="font-medium">{selected.reporter}</span></div>
            <div><span className="text-mc-muted">Created:</span> <span>{new Date(selected.createdAt).toLocaleDateString()}</span></div>
            <div><span className="text-mc-muted">Updated:</span> <span>{new Date(selected.updatedAt).toLocaleDateString()}</span></div>
          </div>

          {(selected.description || editingIssue) && (
            <div className="mb-3">
              <h3 className="text-xs font-semibold text-mc-muted mb-1">Description</h3>
              {editingIssue ? (
                <textarea
                  value={editDesc}
                  onChange={e => setEditDesc(e.target.value)}
                  rows={6}
                  className="w-full bg-mc-bg border border-mc-accent rounded p-3 text-sm focus:outline-none focus:ring-1 focus:ring-mc-accent resize-y font-mono"
                  placeholder="Describe the issue…"
                />
              ) : (
                <div className="bg-mc-bg border border-mc-border rounded p-3 text-sm max-h-48 overflow-y-auto"><MarkdownMessage content={selected.description} /></div>
              )}
            </div>
          )}

          {selected.instructions && (
            <div className="mb-3">
              <h3 className="text-xs font-semibold text-mc-muted mb-1">Special Instructions</h3>
              <div className="bg-yellow-500/5 border border-yellow-500/20 rounded p-3 text-sm"><MarkdownMessage content={selected.instructions} /></div>
            </div>
          )}

          {selected.resolution && (
            <div className="mb-3">
              <h3 className="text-xs font-semibold text-green-400 mb-1">🛡️ Sentinel's Resolution</h3>
              <div className="bg-green-500/5 border border-green-500/20 rounded p-3 text-sm"><MarkdownMessage content={selected.resolution} /></div>
            </div>
          )}

          {selected.projectId && (
            <div className="text-xs text-mc-muted">📁 Linked to project: <span className="text-mc-accent">{selected.projectId}</span></div>
          )}
        </div>

        {/* Workflow Fly-out Panel */}
        {showWorkflow && (
          <div className="fixed inset-0 bg-black/50 z-50 flex justify-end" onClick={() => setShowWorkflow(false)}>
            <div className="w-full max-w-xl bg-mc-surface border-l border-mc-border h-full overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
              {/* Header */}
              <div className="p-4 border-b border-mc-border">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h2 className="font-bold text-lg">🔧 Issue Resolver</h2>
                    <span className="text-xs text-mc-muted">{selected?.issueNumber}</span>
                  </div>
                  <button onClick={() => setShowWorkflow(false)} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
                </div>
                
                {/* Agent Selector */}
                {(workflowStage === '' || workflowStage === 'ready') && agents.length > 0 && (
                  <div className="flex items-center gap-2 bg-mc-bg rounded-lg p-2">
                    <span className="text-xs text-mc-muted">🤖 Agent:</span>
                    <select 
                      value={selectedAgent} 
                      onChange={(e) => setSelectedAgent(e.target.value)}
                      className="flex-1 bg-transparent text-sm text-mc-text border-none outline-none cursor-pointer"
                    >
                      {(agents.some(a => a.capabilities?.includes('coding')) ? agents.filter(a => a.capabilities?.includes('coding')) : agents).map(agent => (
                        <option key={agent.id} value={agent.id}>
                          {agent.displayName || agent.name} {agent.defaultModel ? `(${agent.defaultModel})` : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Stage Indicator */}
              <div className="px-4 py-3 border-b border-mc-border">
                <div className="flex items-center justify-between text-xs">
                  <span className={`${workflowStage === 'analyzing' || workflowStage === 'ready' ? 'text-yellow-400' : workflowStage !== '' && workflowStage !== 'ready' ? 'text-green-400' : 'text-mc-muted'}`}>🔍 Analyze</span>
                  <span className={`${workflowStage === 'proposed' ? 'text-yellow-400' : ['executing', 'validated'].includes(workflowStage || '') ? 'text-green-400' : 'text-mc-muted'}`}>📋 Propose</span>
                  <span className={`${workflowStage === 'executing' ? 'text-yellow-400' : workflowStage === 'validated' ? 'text-green-400' : 'text-mc-muted'}`}>⚡ Execute</span>
                  <span className={`${workflowStage === 'validated' ? 'text-green-400' : 'text-mc-muted'}`}>✅ Validate</span>
                </div>
                <div className="h-1 bg-mc-bg rounded mt-2 overflow-hidden">
                  <div className={`h-full transition-all duration-500 ${
                    workflowStage === 'ready' || workflowStage === '' ? 'w-0' :
                    workflowStage === 'analyzing' ? 'w-1/4 bg-yellow-400' :
                    workflowStage === 'proposed' ? 'w-1/2 bg-yellow-400' :
                    workflowStage === 'executing' ? 'w-3/4 bg-yellow-400' :
                    workflowStage === 'validated' ? 'w-full bg-green-400' :
                    workflowStage === 'rejected' ? 'w-full bg-red-400' :
                    workflowStage === 'failed' ? 'w-full bg-red-400' :
                    'w-0'
                  }`} />
                </div>
              </div>

              {/* Content Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {/* Execution Logs */}
                {workflowLogs.length > 0 && (
                  <div className="bg-mc-bg border border-mc-border rounded-lg p-3">
                    <h3 className="text-xs font-semibold text-mc-muted mb-2">📜 Execution Log</h3>
                    <div className="space-y-2 text-xs font-mono max-h-40 overflow-y-auto">
                      {workflowLogs.map((log, i) => (
                        <div key={i} className="border-l-2 border-mc-accent pl-2">
                          <span className="text-mc-muted">{new Date(log.time).toLocaleTimeString()}</span>
                          <p className="text-mc-text">{log.message}</p>
                          {log.result && <pre className="text-mc-muted whitespace-pre-wrap mt-1">{log.result.substring(0, 500)}</pre>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Proposed Solution */}
                {selected?.proposedSolution && workflowStage !== 'analyzing' && (
                  <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-3">
                    <h3 className="text-xs font-semibold text-blue-400 mb-2">📋 Proposed Solution</h3>
                    <div className="text-sm max-h-64 overflow-y-auto"><MarkdownMessage content={selected.proposedSolution} /></div>
                  </div>
                )}

                {/* Test Case */}
                {testCase && (workflowStage === 'proposed' || workflowStage === 'executing' || workflowStage === 'validated') && (
                  <div className="bg-green-500/5 border border-green-500/20 rounded-lg p-3">
                    <h3 className="text-xs font-semibold text-green-400 mb-2">🧪 Test Case</h3>
                    <div className="text-sm max-h-32 overflow-y-auto"><MarkdownMessage content={testCase} /></div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="p-4 border-t border-mc-border flex gap-2">
                {/* Start Analysis button - when ready to analyze */}
                {(workflowStage === 'ready' || workflowStage === '') && (
                  <>
                    <button onClick={() => playIssue(selected!.id)} disabled={playing === selected?.id}
                      className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium">
                      {playing === selected?.id ? '⏳ Analyzing...' : '🚀 Start Analysis'}
                    </button>
                    <button onClick={() => setShowWorkflow(false)}
                      className="px-4 py-2 bg-mc-bg hover:bg-mc-border text-mc-text rounded-lg">
                      Cancel
                    </button>
                  </>
                )}
                {workflowStage === 'proposed' && (
                  <>
                    <button onClick={() => approveSolution(true)} disabled={playing === selected?.id}
                      className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium">
                      ✅ Approve & Execute
                    </button>
                    <button onClick={() => approveSolution(false)} disabled={playing === selected?.id}
                      className="px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg">
                      ❌ Reject
                    </button>
                  </>
                )}
                {workflowStage === 'validated' && (
                  <button onClick={() => { setShowWorkflow(false); updateStatus(selected!.id, 'closed'); }}
                    className="flex-1 px-4 py-2 bg-mc-accent hover:bg-mc-accent/80 text-white rounded-lg font-medium">
                    ✓ Close Issue
                  </button>
                )}
                {workflowStage === 'executing' && (
                  <div className="flex-1 text-center text-yellow-400 py-2">⏳ Executing fix...</div>
                )}
                {workflowStage === 'analyzing' && (
                  <div className="flex-1 text-center text-yellow-400 py-2">🔍 Analyzing issue...</div>
                )}
                {(workflowStage === 'rejected' || workflowStage === 'failed') && (
                  <button onClick={() => { setShowWorkflow(false); setWorkflowLogs([]); }}
                    className="flex-1 px-4 py-2 bg-mc-bg hover:bg-mc-border text-mc-text rounded-lg">
                    Close
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header row */}
      <div className="flex items-center gap-2">
        <span className="font-mono text-mc-accent text-sm">v{version}</span>
        <div className="flex-1" />
        <button onClick={() => setShowNew(true)}
          className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:bg-mc-accent/80">
          + New Issue
        </button>
      </div>

      {/* New issue form */}
      {showNew && (
        <div className="bg-mc-surface border border-mc-border rounded-lg p-4 space-y-3">
          <input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Issue title..."
            className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm" autoFocus />
          <textarea value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Description..."
            rows={3} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm resize-none" />
          <div className="flex gap-3">
            <select value={newCategory} onChange={e => setNewCategory(e.target.value)}
              className="bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm">
              {categories.map(c => <option key={c} value={c}>{CAT_ICONS[c] || ''} {c}</option>)}
            </select>
            <select value={newPriority} onChange={e => setNewPriority(e.target.value)}
              className="bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm">
              <option value="critical">🔴 Critical</option>
              <option value="high">🟠 High</option>
              <option value="medium">🟡 Medium</option>
              <option value="low">🔵 Low</option>
            </select>
          </div>
          <textarea value={newInstructions} onChange={e => setNewInstructions(e.target.value)}
            placeholder="Special instructions (optional)..."
            rows={2} className="w-full bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm resize-none" />
          <div className="flex gap-2">
            <button onClick={createIssue} className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm">Create Issue</button>
            <button onClick={() => setShowNew(false)} className="px-3 py-1.5 text-mc-muted text-sm">Cancel</button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search issues..."
          className="bg-mc-bg border border-mc-border rounded px-3 py-1.5 text-sm flex-1 min-w-[180px]" />
        <div className="flex gap-1">
          <button onClick={() => setFilter('all')} className={`px-2 py-1 rounded text-xs ${filter === 'all' ? 'bg-mc-accent/20 text-mc-accent' : 'text-mc-muted'}`}>All</button>
          {categories.map(c => (
            <button key={c} onClick={() => setFilter(c)}
              className={`px-2 py-1 rounded text-xs capitalize ${filter === c ? 'bg-mc-accent/20 text-mc-accent' : 'text-mc-muted hover:text-mc-text'}`}>
              {CAT_ICONS[c] || ''} {(c || '').replace('-', ' ')}
            </button>
          ))}
        </div>
      </div>
      <div className="flex gap-1">
        {['non-closed', 'all', 'open', 'in-progress', 'resolved', 'needs-project', 'closed'].map(s => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`px-2 py-1 rounded text-xs capitalize ${statusFilter === s ? 'bg-mc-accent/20 text-mc-accent' : 'text-mc-muted hover:text-mc-text'}`}>
            {s === 'all' ? 'All Status' : s === 'non-closed' ? 'Non-Closed' : s}
          </button>
        ))}
      </div>

      {/* Issues table */}
      <div className="bg-mc-surface border border-mc-border rounded-lg overflow-x-auto">
        <table className="w-full text-sm min-w-[500px]">
          <thead>
            <tr className="border-b border-mc-border text-mc-muted text-xs">
              <th className="text-left px-3 py-2 w-20 hidden md:table-cell">ID</th>
              <th className="text-left px-3 py-2">Title</th>
              <th className="text-left px-3 py-2 w-28">Category</th>
              <th className="text-left px-3 py-2 w-24">Status</th>
              <th className="text-left px-3 py-2 w-20 hidden md:table-cell">Priority</th>
              <th className="text-left px-3 py-2 w-24 hidden lg:table-cell">Created</th>
              <th className="text-left px-3 py-2 w-24 hidden lg:table-cell">Updated</th>
              <th className="text-center px-3 py-2 w-20">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(issue => (
              <tr key={issue.id} className="border-b border-mc-border/50 hover:bg-mc-bg/50 cursor-pointer"
                onClick={() => { setSelected(issue); setEditingIssue(false); }}>
                <td className="px-3 py-2 font-mono text-[10px] text-mc-muted hidden md:table-cell">{issue.issueNumber}</td>
                <td className="px-3 py-2 font-medium">{issue.title}</td>
                <td className="px-3 py-2 text-xs capitalize">{CAT_ICONS[issue.category] || ''} {(issue.category || '').replace('-', ' ')}</td>
                <td className="px-3 py-2"><span className={`px-2 py-0.5 rounded-full text-[10px] ${STATUS_COLORS[issue.status] || ''}`}>{issue.status}</span></td>
                <td className={`px-3 py-2 text-xs capitalize hidden md:table-cell ${PRIORITY_COLORS[issue.priority] || ''}`}>{issue.priority}</td>
                <td className="px-3 py-2 text-xs text-mc-muted hidden lg:table-cell">{issue.createdAt ? new Date(issue.createdAt).toLocaleDateString() : '-'}</td>
                <td className="px-3 py-2 text-xs text-mc-muted hidden lg:table-cell">{issue.updatedAt ? new Date(issue.updatedAt).toLocaleDateString() : '-'}</td>
                <td className="px-3 py-2 text-center">
                  <div className="flex items-center gap-1 justify-center">
                    <button onClick={e => { e.stopPropagation(); setSelected(issue); }}
                      className="px-2 py-0.5 bg-mc-bg text-mc-muted rounded text-[10px] hover:bg-mc-border"
                      title="View details">
                      👁
                    </button>
                    <button onClick={e => { e.stopPropagation(); playIssue(issue.id); }}
                      disabled={playing === issue.id}
                      className="px-2 py-0.5 bg-mc-accent/20 text-mc-accent rounded text-[10px] hover:bg-mc-accent/30 disabled:opacity-50"
                      title="Issue Resolver">
                      {playing === issue.id ? '⏳' : '🤖'}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={8} className="px-3 py-8 text-center text-mc-muted">No issues found. Looking clean! 🛡️</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="text-[10px] text-mc-muted text-right">{filtered.length} issue{filtered.length !== 1 ? 's' : ''} · Managed by 🛡️ Sentinel</div>
    </div>
  );
}
