'use client';
import { useState, useEffect } from 'react';

interface Device {
  name: string;
  model: string;
  mac: string;
  capabilities: string[];
  room: string;
}

interface Room {
  id: string;
  label: string;
  icon: string;
  devices: Device[];
}

const ROOMS: Room[] = [
  { id: 'kitchen', label: 'Kitchen', icon: '🍳', devices: [
    { name: 'K1', model: 'H6010', mac: '13:F2:D0:C9:07:0E:C0:9A', capabilities: ['turn','brightness','color','colorTem'], room: 'kitchen' },
    { name: 'K2', model: 'H6010', mac: '53:2B:D0:C9:07:0E:20:D8', capabilities: ['turn','brightness','color','colorTem'], room: 'kitchen' },
    { name: 'K3', model: 'H6010', mac: 'D3:B9:D0:C9:07:0E:42:5E', capabilities: ['turn','brightness','color','colorTem'], room: 'kitchen' },
    { name: 'K4', model: 'H6010', mac: '47:44:D0:C9:07:13:15:9A', capabilities: ['turn','brightness','color','colorTem'], room: 'kitchen' },
    { name: 'K5', model: 'H6010', mac: '5D:69:D0:C9:07:0D:F1:38', capabilities: ['turn','brightness','color','colorTem'], room: 'kitchen' },
    { name: 'K6', model: 'H6010', mac: '27:3E:D0:C9:07:13:18:EE', capabilities: ['turn','brightness','color','colorTem'], room: 'kitchen' },
  ]},
  { id: 'dining', label: 'Dining Room', icon: '🍽️', devices: [
    { name: 'Dining 1', model: 'H6006', mac: '30:AA:D0:C9:07:B6:68:60', capabilities: ['turn','brightness','color','colorTem'], room: 'dining' },
    { name: 'Dining 2', model: 'H6006', mac: '5E:45:D0:C9:07:B4:1E:C8', capabilities: ['turn','brightness','color','colorTem'], room: 'dining' },
    { name: 'Dining 3', model: 'H6006', mac: '5B:86:D0:C9:07:B6:68:B6', capabilities: ['turn','brightness','color','colorTem'], room: 'dining' },
    { name: 'Dining 4', model: 'H6006', mac: 'A6:8E:D0:C9:07:B2:04:62', capabilities: ['turn','brightness','color','colorTem'], room: 'dining' },
    { name: 'Dining 5', model: 'H6006', mac: 'C7:BA:D0:C9:07:B4:D3:9A', capabilities: ['turn','brightness','color','colorTem'], room: 'dining' },
  ]},
  { id: 'office', label: 'Office', icon: '💻', devices: [
    { name: 'Office Light Bar', model: 'H6047', mac: 'D0:CB:D6:32:34:38:34:95', capabilities: ['turn','brightness','color','colorTem'], room: 'office' },
    { name: 'Office Ceiling', model: 'H5080', mac: 'E7:8E:60:74:F4:E7:42:8A', capabilities: ['turn'], room: 'office' },
    { name: 'Office Wall', model: 'H5080', mac: '20:11:60:74:F4:E8:66:EC', capabilities: ['turn'], room: 'office' },
    { name: 'Office Brights', model: 'H5083', mac: 'D5:A6:98:17:3C:B4:7C:54', capabilities: ['turn'], room: 'office' },
    { name: 'Office Wind Machine', model: 'H5080', mac: '8D:EB:60:74:F4:DD:08:C4', capabilities: ['turn'], room: 'office' },
  ]},
  { id: 'loft', label: 'Loft', icon: '🎮', devices: [
    { name: 'Loft Light Bar', model: 'H6042', mac: '31:14:D0:C8:05:06:6F:39', capabilities: ['turn','brightness','color','colorTem'], room: 'loft' },
    { name: 'Loft TV', model: 'H6168', mac: '13:F5:D1:06:05:86:59:87', capabilities: ['turn','brightness','color','colorTem'], room: 'loft' },
    { name: 'Samsung Monitor', model: 'H6167', mac: '2C:6F:DB:E6:45:C6:2B:27', capabilities: ['turn','brightness','color','colorTem'], room: 'loft' },
  ]},
  { id: 'hallway', label: 'Hallways', icon: '🚪', devices: [
    { name: 'Front Doorway', model: 'H6006', mac: '52:79:D0:C9:07:B6:D8:CC', capabilities: ['turn','brightness','color','colorTem'], room: 'hallway' },
    { name: 'Hallway 1', model: 'H6006', mac: '22:41:D0:C9:07:AA:35:2A', capabilities: ['turn','brightness','color','colorTem'], room: 'hallway' },
    { name: 'Hallway 2', model: 'H6006', mac: '8C:B8:D0:C9:07:C4:5B:A0', capabilities: ['turn','brightness','color','colorTem'], room: 'hallway' },
    { name: 'Hallway 3', model: 'H6006', mac: 'B6:5C:D0:C9:07:37:3A:1A', capabilities: ['turn','brightness','color','colorTem'], room: 'hallway' },
    { name: 'Hallway 4', model: 'H6006', mac: '2B:00:D0:C9:07:42:43:E1', capabilities: ['turn','brightness','color','colorTem'], room: 'hallway' },
  ]},
  { id: 'bedroom', label: 'Bedroom', icon: '🛏️', devices: [
    { name: 'Bedroom Lamp', model: 'H6008', mac: '27:36:60:74:F4:B3:9A:A2', capabilities: ['turn','brightness','color','colorTem'], room: 'bedroom' },
    { name: 'Mickey Lamp', model: 'H6008', mac: '5F:23:60:74:F4:B8:F9:38', capabilities: ['turn','brightness','color','colorTem'], room: 'bedroom' },
  ]},
  { id: 'living', label: 'Living Room', icon: '📺', devices: [
    { name: 'TV Light', model: 'H6168', mac: 'DC:E6:D4:AD:FC:20:C0:96', capabilities: ['turn','brightness','color','colorTem'], room: 'living' },
    { name: 'TV Backlight', model: 'H605C', mac: 'A2:1C:CF:32:37:38:28:93', capabilities: ['turn','brightness','color','colorTem'], room: 'living' },
  ]},
  { id: 'outside', label: 'Outside', icon: '🌳', devices: [
    { name: 'Patio Lights', model: 'H7021', mac: 'E4:A5:C3:38:30:32:62:7B', capabilities: ['turn','brightness','color','colorTem'], room: 'outside' },
    { name: 'Permanent Lights', model: 'H705B', mac: 'A4:BD:C1:30:38:36:3D:5C', capabilities: ['turn','brightness','color','colorTem'], room: 'outside' },
  ]},
  { id: 'other', label: 'Other', icon: '🌿', devices: [
    { name: 'Plant Light Bars', model: 'H6056', mac: 'A9:05:D5:0E:C5:C6:4B:2D', capabilities: ['turn','brightness','color','colorTem'], room: 'other' },
    { name: 'Back Room Lamp', model: 'H5080', mac: 'BB:8B:60:74:F4:E6:8B:DE', capabilities: ['turn'], room: 'other' },
  ]},
];

const PRESET_COLORS: { name: string; r: number; g: number; b: number }[] = [
  { name: 'White', r: 255, g: 255, b: 255 },
  { name: 'Warm', r: 255, g: 180, b: 100 },
  { name: 'Red', r: 255, g: 0, b: 0 },
  { name: 'Green', r: 0, g: 255, b: 0 },
  { name: 'Blue', r: 0, g: 0, b: 255 },
  { name: 'Purple', r: 128, g: 0, b: 255 },
  { name: 'Orange', r: 255, g: 100, b: 0 },
  { name: 'Cyan', r: 0, g: 255, b: 255 },
  { name: 'Pink', r: 255, g: 105, b: 180 },
];

const FAVORITES_KEY = 'mc-govee-favorites';

function loadFavorites(): Set<string> {
  if (typeof window === 'undefined') return new Set();
  try {
    return new Set(JSON.parse(localStorage.getItem(FAVORITES_KEY) || '[]'));
  } catch { return new Set(); }
}

function saveFavorites(favs: Set<string>) {
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(Array.from(favs)));
}

function DeviceCard({ device, isFavorite, onToggleFav, loading, setLoading, showFeedback }: {
  device: Device;
  isFavorite: boolean;
  onToggleFav: () => void;
  loading: string | null;
  setLoading: (v: string | null) => void;
  showFeedback: (msg: string) => void;
}) {
  const [state, setState] = useState<'on' | 'off' | 'unknown'>('unknown');
  const [bright, setBright] = useState(50);
  const isPlug = device.capabilities.length === 1 && device.capabilities[0] === 'turn';
  const hasColorCap = device.capabilities.includes('color');
  const hasBrightness = device.capabilities.includes('brightness');
  const isLoading = loading === device.mac;

  const sendGovee = async (payload: any) => {
    const res = await fetch('/api/govee', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  };

  const toggle = async (action: 'on' | 'off') => {
    setLoading(device.mac);
    try {
      await sendGovee({ device: device.name, model: device.model, mac: device.mac, action });
      setState(action);
      showFeedback(`${device.name} → ${action.toUpperCase()}`);
    } catch { showFeedback('Error'); }
    setLoading(null);
  };

  const changeBrightness = async (val: number) => {
    setBright(val);
    try {
      await sendGovee({ device: device.name, model: device.model, mac: device.mac, action: 'brightness', value: val });
    } catch {}
  };

  const changeColor = async (r: number, g: number, b: number, name: string) => {
    setLoading(device.mac);
    try {
      await sendGovee({ device: device.name, model: device.model, mac: device.mac, action: 'color', r, g, b });
      showFeedback(`${device.name} → ${name}`);
    } catch { showFeedback('Error'); }
    setLoading(null);
  };

  return (
    <div className={`bg-mc-bg rounded-lg p-3 border transition-colors ${isFavorite ? 'border-yellow-500/40' : 'border-mc-border/30'}`}>
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${state === 'on' ? 'bg-green-500' : state === 'off' ? 'bg-gray-500' : 'bg-yellow-500/50'}`} />
          <span className="text-xs font-medium">{device.name}</span>
          <span className="text-[9px] text-mc-muted">{isPlug ? '🔌' : '💡'}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={onToggleFav} title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            className="text-xs hover:scale-110 transition-transform">
            {isFavorite ? '⭐' : '☆'}
          </button>
          <button onClick={() => toggle('on')} disabled={loading !== null}
            className={`text-[10px] px-2 py-0.5 rounded transition-colors ${state === 'on' ? 'bg-green-600 text-white' : 'bg-green-600/20 text-green-400 hover:bg-green-600/30'} disabled:opacity-50`}>
            ON
          </button>
          <button onClick={() => toggle('off')} disabled={loading !== null}
            className={`text-[10px] px-2 py-0.5 rounded transition-colors ${state === 'off' ? 'bg-gray-600 text-white' : 'bg-gray-600/20 text-gray-400 hover:bg-gray-600/30'} disabled:opacity-50`}>
            OFF
          </button>
        </div>
      </div>

      {hasBrightness && (
        <div className="flex items-center gap-2 mt-1.5">
          <span className="text-[9px] text-mc-muted w-4">☀️</span>
          <input type="range" min="1" max="100" value={bright}
            onChange={e => setBright(Number(e.target.value))}
            onMouseUp={e => changeBrightness(Number((e.target as HTMLInputElement).value))}
            onTouchEnd={e => changeBrightness(Number((e.target as HTMLInputElement).value))}
            className="flex-1 h-1 accent-mc-accent" />
          <span className="text-[9px] text-mc-muted w-7 text-right">{bright}%</span>
        </div>
      )}

      {hasColorCap && (
        <div className="flex gap-1 mt-1.5 flex-wrap">
          {PRESET_COLORS.map(c => (
            <button key={c.name} onClick={() => changeColor(c.r, c.g, c.b, c.name)}
              title={c.name} disabled={loading !== null}
              className="w-4 h-4 rounded-full border border-mc-border/50 hover:scale-125 transition-transform disabled:opacity-50"
              style={{ backgroundColor: `rgb(${c.r},${c.g},${c.b})` }} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function QuickActions() {
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState<string | null>(null);
  const [expandedRoom, setExpandedRoom] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => { setFavorites(loadFavorites()); }, []);

  const showFeedback = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 2000);
  };

  const toggleFavorite = (mac: string) => {
    setFavorites(prev => {
      const next = new Set(prev);
      if (next.has(mac)) next.delete(mac); else next.add(mac);
      saveFavorites(next);
      return next;
    });
  };

  const toggleRoom = async (roomId: string, action: 'on' | 'off') => {
    setLoading(`${roomId}-${action}`);
    try {
      await fetch('/api/govee', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room: roomId, action }),
      });
      const room = ROOMS.find(r => r.id === roomId);
      showFeedback(`${room?.label} → ${action.toUpperCase()}`);
    } catch { showFeedback('Error'); }
    setLoading(null);
  };

  // Collect all favorite devices
  const allDevices = ROOMS.flatMap(r => r.devices);
  const favDevices = allDevices.filter(d => favorites.has(d.mac));
  const totalDevices = allDevices.length;

  return (
    <div className="space-y-4">
      {feedback && (
        <div className="fixed top-4 right-4 bg-mc-accent text-white px-4 py-2 rounded-lg text-sm shadow-lg z-50 animate-pulse">
          {feedback}
        </div>
      )}

      {/* Favorites Section */}
      {favDevices.length > 0 && (
        <div className="bg-mc-surface border border-yellow-500/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold">⭐ Favorites</h3>
            <span className="text-xs text-mc-muted">{favDevices.length} device{favDevices.length !== 1 ? 's' : ''}</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {favDevices.map(device => (
              <DeviceCard key={device.mac} device={device} isFavorite={true}
                onToggleFav={() => toggleFavorite(device.mac)}
                loading={loading} setLoading={setLoading} showFeedback={showFeedback} />
            ))}
          </div>
        </div>
      )}

      {/* Room Cards */}
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-mc-muted">{totalDevices} devices · {ROOMS.length} rooms · ⭐ Star devices for quick access</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {ROOMS.map(room => {
          const isExpanded = expandedRoom === room.id;
          const plugCount = room.devices.filter(d => d.capabilities.length === 1 && d.capabilities[0] === 'turn').length;
          const lightCount = room.devices.length - plugCount;
          const favCount = room.devices.filter(d => favorites.has(d.mac)).length;

          return (
            <div key={room.id} className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
              <div className="flex items-center justify-between p-3 border-b border-mc-border/50">
                <button onClick={() => setExpandedRoom(isExpanded ? null : room.id)} className="flex items-center gap-2 flex-1 text-left">
                  <span className="text-lg">{room.icon}</span>
                  <div>
                    <div className="text-sm font-medium">
                      {room.label}
                      {favCount > 0 && <span className="ml-1 text-yellow-500 text-[10px]">⭐{favCount}</span>}
                    </div>
                    <div className="text-[10px] text-mc-muted">
                      {lightCount > 0 && `${lightCount} light${lightCount > 1 ? 's' : ''}`}
                      {lightCount > 0 && plugCount > 0 && ' · '}
                      {plugCount > 0 && `${plugCount} plug${plugCount > 1 ? 's' : ''}`}
                    </div>
                  </div>
                  <span className="text-mc-muted text-xs ml-auto mr-2">{isExpanded ? '▼' : '▶'}</span>
                </button>
                <div className="flex gap-1">
                  <button onClick={() => toggleRoom(room.id, 'on')} disabled={loading !== null}
                    className="text-xs px-2.5 py-1 rounded bg-green-600/20 text-green-400 hover:bg-green-600/30 disabled:opacity-50 transition-colors">
                    ON
                  </button>
                  <button onClick={() => toggleRoom(room.id, 'off')} disabled={loading !== null}
                    className="text-xs px-2.5 py-1 rounded bg-gray-600/20 text-gray-400 hover:bg-gray-600/30 disabled:opacity-50 transition-colors">
                    OFF
                  </button>
                </div>
              </div>

              {isExpanded && (
                <div className="p-2 space-y-1.5">
                  {room.devices.map(device => (
                    <DeviceCard key={device.mac} device={device} isFavorite={favorites.has(device.mac)}
                      onToggleFav={() => toggleFavorite(device.mac)}
                      loading={loading} setLoading={setLoading} showFeedback={showFeedback} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
