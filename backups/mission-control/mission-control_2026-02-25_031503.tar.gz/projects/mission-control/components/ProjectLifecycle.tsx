/* @ts-nocheck */
'use client';
import React, { useState, useEffect } from 'react';

interface LifecycleDocument {
  name: string; status: string; authorId: string; createdAt: string; summary: string;
}
interface Approval {
  documentName: string; approverId: string; approvedAt: string; notes: string;
}
interface Decision {
  id: string; title: string; decidedBy: string; date: string; rationale: string; dissentingOpinions: string[];
}
interface Conflict {
  id: string; description: string; parties: string[]; resolution: string; resolvedBy: string; resolvedAt: string;
}
interface Phase {
  id: string; name: string; status: 'not-started' | 'in-progress' | 'completed' | 'blocked';
  ownerId: string; startDate: string | null; endDate: string | null;
  documents: LifecycleDocument[]; approvals: Approval[]; decisions: Decision[]; conflicts: Conflict[];
}

interface Props {
  projectId: string;
  agentMap?: Record<string, any>;
}

const STATUS_STYLES: Record<string, { color: string; bg: string; label: string }> = {
  'not-started': { color: 'text-gray-500', bg: 'bg-gray-500', label: 'Not Started' },
  'in-progress': { color: 'text-blue-400', bg: 'bg-blue-500', label: 'In Progress' },
  'completed': { color: 'text-green-400', bg: 'bg-green-500', label: 'Completed' },
  'blocked': { color: 'text-red-400', bg: 'bg-red-500', label: 'Blocked' },
};

export default function ProjectLifecycle({ projectId, agentMap = {} }: Props) {
  const [phases, setPhases] = useState<Phase[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedPhase, setExpandedPhase] = useState<string | null>(null);
  const [addingDoc, setAddingDoc] = useState<string | null>(null);
  const [addingDecision, setAddingDecision] = useState<string | null>(null);
  const [addingConflict, setAddingConflict] = useState<string | null>(null);
  const [newDoc, setNewDoc] = useState({ name: '', authorId: '', summary: '' });
  const [newDecision, setNewDecision] = useState({ title: '', decidedBy: '', rationale: '' });
  const [newConflict, setNewConflict] = useState({ description: '', parties: '', resolution: '', resolvedBy: '' });

  const load = () => {
    fetch(`/api/lifecycle?projectId=${projectId}`).then(r => r.json())
      .then(d => { setPhases((d.phases || []).map((p: any) => ({ ...p, documents: p.documents || [], decisions: p.decisions || [], conflicts: p.conflicts || [], approvals: p.approvals || [] }))); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(load, [projectId]);

  const updatePhase = async (phaseId: string, updates: Partial<Phase>) => {
    const res = await fetch('/api/lifecycle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, action: 'update-phase', phaseId, updates }),
    });
    const d = await res.json();
    if (d.phases) setPhases(d.phases);
  };

  const addDocument = async (phaseId: string) => {
    if (!newDoc.name.trim()) return;
    const doc: LifecycleDocument = {
      name: newDoc.name, status: 'in-progress', authorId: newDoc.authorId || 'unknown',
      createdAt: new Date().toISOString(), summary: newDoc.summary,
    };
    const res = await fetch('/api/lifecycle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, action: 'add-document', phaseId, document: doc }),
    });
    const d = await res.json();
    if (d.phases) setPhases(d.phases);
    setNewDoc({ name: '', authorId: '', summary: '' });
    setAddingDoc(null);
  };

  const addDecisionFn = async (phaseId: string) => {
    if (!newDecision.title.trim()) return;
    const decision: Decision = {
      id: `dec-${Date.now()}`, title: newDecision.title, decidedBy: newDecision.decidedBy || 'unknown',
      date: new Date().toISOString(), rationale: newDecision.rationale, dissentingOpinions: [],
    };
    const res = await fetch('/api/lifecycle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, action: 'add-decision', phaseId, decision }),
    });
    const d = await res.json();
    if (d.phases) setPhases(d.phases);
    setNewDecision({ title: '', decidedBy: '', rationale: '' });
    setAddingDecision(null);
  };

  const addConflictFn = async (phaseId: string) => {
    if (!newConflict.description.trim()) return;
    const conflict: Conflict = {
      id: `conf-${Date.now()}`, description: newConflict.description,
      parties: newConflict.parties.split(',').map(s => s.trim()).filter(Boolean),
      resolution: newConflict.resolution, resolvedBy: newConflict.resolvedBy,
      resolvedAt: newConflict.resolution ? new Date().toISOString() : '',
    };
    const res = await fetch('/api/lifecycle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, action: 'add-conflict', phaseId, conflict }),
    });
    const d = await res.json();
    if (d.phases) setPhases(d.phases);
    setNewConflict({ description: '', parties: '', resolution: '', resolvedBy: '' });
    setAddingConflict(null);
  };

  const agentName = (id: string) => agentMap[id]?.displayName || agentMap[id]?.name || id || 'Unknown';

  if (loading) return <div className="text-mc-muted text-center py-8">Loading lifecycle...</div>;

  const completedCount = phases.filter(p => p.status === 'completed').length;
  const totalDocs = phases.reduce((s, p) => s + p.documents.length, 0);
  const totalDecisions = phases.reduce((s, p) => s + p.decisions.length, 0);
  const totalConflictsResolved = phases.reduce((s, p) => s + p.conflicts.filter(c => c.resolution).length, 0);

  return (
    <div className="space-y-4">
      {/* Summary Stats */}
      <div className="grid grid-cols-4 gap-2">
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-mc-text">{completedCount}/{phases.length}</div>
          <div className="text-[10px] text-mc-muted">Phases Complete</div>
        </div>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-mc-text">{totalDocs}</div>
          <div className="text-[10px] text-mc-muted">Documents</div>
        </div>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-mc-text">{totalDecisions}</div>
          <div className="text-[10px] text-mc-muted">Decisions</div>
        </div>
        <div className="bg-mc-bg border border-mc-border rounded-lg p-2 text-center">
          <div className="text-lg font-bold text-mc-text">{totalConflictsResolved}</div>
          <div className="text-[10px] text-mc-muted">Conflicts Resolved</div>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        {phases.map((phase, idx) => {
          const isExpanded = expandedPhase === phase.id;
          const style = STATUS_STYLES[phase.status] || STATUS_STYLES['not-started'];
          const isLast = idx === phases.length - 1;

          return (
            <div key={phase.id} className="relative flex gap-4">
              {/* Timeline line + dot */}
              <div className="flex flex-col items-center flex-shrink-0 w-8">
                <div className={`w-4 h-4 rounded-full ${style.bg} flex-shrink-0 z-10 mt-1`} />
                {!isLast && <div className="w-0.5 flex-1 bg-mc-border" />}
              </div>

              {/* Phase content */}
              <div className="flex-1 pb-4 min-w-0">
                <div
                  className="bg-mc-bg border border-mc-border rounded-lg overflow-hidden cursor-pointer hover:border-indigo-500/30 transition-colors"
                  onClick={() => setExpandedPhase(isExpanded ? null : phase.id)}
                >
                  <div className="flex items-center gap-3 p-3">
                    <span className={`text-xs font-semibold ${style.color}`}>{style.label}</span>
                    <span className="text-sm font-medium text-mc-text flex-1">{phase.name}</span>
                    {phase.ownerId && (
                      <span className="text-[10px] text-mc-muted">Owner: {agentName(phase.ownerId)}</span>
                    )}
                    <select
                      value={phase.status}
                      onClick={e => e.stopPropagation()}
                      onChange={e => updatePhase(phase.id, { status: e.target.value as Phase['status'] })}
                      className="text-[10px] bg-mc-surface border border-mc-border rounded px-1.5 py-0.5 text-mc-text"
                    >
                      <option value="not-started">Not Started</option>
                      <option value="in-progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="blocked">Blocked</option>
                    </select>
                    <span className="text-mc-muted text-xs">{isExpanded ? '▼' : '▶'}</span>
                  </div>

                  {/* Compact info */}
                  {!isExpanded && (phase.documents.length > 0 || phase.decisions.length > 0 || phase.conflicts.length > 0) && (
                    <div className="px-3 pb-2 flex gap-3 text-[10px] text-mc-muted">
                      {phase.documents.length > 0 && <span>📄 {phase.documents.length} docs</span>}
                      {phase.approvals.length > 0 && <span>✅ {phase.approvals.length} approvals</span>}
                      {phase.decisions.length > 0 && <span>⚖️ {phase.decisions.length} decisions</span>}
                      {phase.conflicts.length > 0 && <span>⚠️ {phase.conflicts.length} conflicts</span>}
                    </div>
                  )}
                </div>

                {/* Expanded content */}
                {isExpanded && (
                  <div className="mt-2 space-y-3" onClick={e => e.stopPropagation()}>
                    {/* Owner + Dates */}
                    <div className="flex gap-4 text-xs">
                      <div>
                        <span className="text-mc-muted">Owner: </span>
                        <input
                          value={phase.ownerId || ''}
                          onChange={e => updatePhase(phase.id, { ownerId: e.target.value })}
                          placeholder="Agent ID..."
                          className="bg-mc-bg border border-mc-border rounded px-2 py-0.5 text-xs text-mc-text w-32"
                        />
                      </div>
                      <div>
                        <span className="text-mc-muted">Start: </span>
                        <input type="date" value={phase.startDate?.split('T')[0] || ''}
                          onChange={e => updatePhase(phase.id, { startDate: e.target.value || null })}
                          className="bg-mc-bg border border-mc-border rounded px-2 py-0.5 text-xs text-mc-text" />
                      </div>
                      <div>
                        <span className="text-mc-muted">End: </span>
                        <input type="date" value={phase.endDate?.split('T')[0] || ''}
                          onChange={e => updatePhase(phase.id, { endDate: e.target.value || null })}
                          className="bg-mc-bg border border-mc-border rounded px-2 py-0.5 text-xs text-mc-text" />
                      </div>
                    </div>

                    {/* Documents */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider">📄 Documents</h4>
                        <button onClick={() => setAddingDoc(addingDoc === phase.id ? null : phase.id)}
                          className="text-[10px] text-indigo-400 hover:text-indigo-300">+ Add Document</button>
                      </div>
                      {phase.documents.map((doc, di) => (
                        <div key={di} className="bg-mc-surface border border-mc-border rounded p-2 mb-1 flex items-start gap-2">
                          <span className="text-xs">📄</span>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-medium text-mc-text">{doc.name}</div>
                            <div className="text-[10px] text-mc-muted">
                              {agentName(doc.authorId)} · {doc.createdAt ? new Date(doc.createdAt).toLocaleDateString() : '—'}
                            </div>
                            {doc.summary && <div className="text-[10px] text-mc-muted mt-0.5">{doc.summary}</div>}
                          </div>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${doc.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>
                            {doc.status}
                          </span>
                        </div>
                      ))}
                      {addingDoc === phase.id && (
                        <div className="bg-mc-surface border border-indigo-500/30 rounded p-2 space-y-1 mt-1">
                          <input value={newDoc.name} onChange={e => setNewDoc({ ...newDoc, name: e.target.value })}
                            placeholder="Document name..." className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          <div className="flex gap-1">
                            <input value={newDoc.authorId} onChange={e => setNewDoc({ ...newDoc, authorId: e.target.value })}
                              placeholder="Author ID..." className="flex-1 bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                            <input value={newDoc.summary} onChange={e => setNewDoc({ ...newDoc, summary: e.target.value })}
                              placeholder="Summary..." className="flex-1 bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          </div>
                          <div className="flex gap-1">
                            <button onClick={() => addDocument(phase.id)} className="px-2 py-0.5 bg-indigo-600 text-white rounded text-[10px]">Add</button>
                            <button onClick={() => setAddingDoc(null)} className="px-2 py-0.5 text-mc-muted text-[10px]">Cancel</button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Approvals */}
                    {phase.approvals.length > 0 && (
                      <div>
                        <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider mb-1">✅ Approvals</h4>
                        {phase.approvals.map((a, ai) => (
                          <div key={ai} className="flex items-center gap-2 text-xs text-mc-text py-0.5">
                            <span className="text-green-400">✓</span>
                            <span className="font-medium">{agentName(a.approverId)}</span>
                            <span className="text-mc-muted">approved</span>
                            <span className="text-mc-muted italic">{a.documentName}</span>
                            {a.notes && <span className="text-mc-muted">— {a.notes}</span>}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Decisions */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider">⚖️ Decisions</h4>
                        <button onClick={() => setAddingDecision(addingDecision === phase.id ? null : phase.id)}
                          className="text-[10px] text-indigo-400 hover:text-indigo-300">+ Add Decision</button>
                      </div>
                      {phase.decisions.map(dec => (
                        <details key={dec.id} className="bg-mc-surface border border-mc-border rounded p-2 mb-1">
                          <summary className="text-xs font-medium text-mc-text cursor-pointer flex items-center gap-2">
                            <span>⚖️</span> {dec.title}
                            <span className="text-[10px] text-mc-muted ml-auto">{agentName(dec.decidedBy)} · {dec.date ? new Date(dec.date).toLocaleDateString() : '—'}</span>
                          </summary>
                          <div className="mt-1 text-[10px] text-mc-muted">{dec.rationale}</div>
                          {(dec.dissentingOpinions || []).length > 0 && (
                            <div className="mt-1 text-[10px] text-red-400">Dissent: {(dec.dissentingOpinions || []).join('; ')}</div>
                          )}
                        </details>
                      ))}
                      {addingDecision === phase.id && (
                        <div className="bg-mc-surface border border-indigo-500/30 rounded p-2 space-y-1 mt-1">
                          <input value={newDecision.title} onChange={e => setNewDecision({ ...newDecision, title: e.target.value })}
                            placeholder="Decision title..." className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          <div className="flex gap-1">
                            <input value={newDecision.decidedBy} onChange={e => setNewDecision({ ...newDecision, decidedBy: e.target.value })}
                              placeholder="Decided by..." className="flex-1 bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          </div>
                          <textarea value={newDecision.rationale} onChange={e => setNewDecision({ ...newDecision, rationale: e.target.value })}
                            placeholder="Rationale..." rows={2} className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text resize-none" />
                          <div className="flex gap-1">
                            <button onClick={() => addDecisionFn(phase.id)} className="px-2 py-0.5 bg-indigo-600 text-white rounded text-[10px]">Add</button>
                            <button onClick={() => setAddingDecision(null)} className="px-2 py-0.5 text-mc-muted text-[10px]">Cancel</button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Conflicts */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-[10px] font-semibold text-mc-muted uppercase tracking-wider">⚠️ Conflicts</h4>
                        <button onClick={() => setAddingConflict(addingConflict === phase.id ? null : phase.id)}
                          className="text-[10px] text-indigo-400 hover:text-indigo-300">+ Log Conflict</button>
                      </div>
                      {phase.conflicts.map(conf => (
                        <details key={conf.id} className="bg-mc-surface border border-mc-border rounded p-2 mb-1">
                          <summary className="text-xs font-medium text-mc-text cursor-pointer flex items-center gap-2">
                            <span>⚠️</span> {conf.description}
                            {conf.resolution && <span className="text-[10px] text-green-400 ml-auto">Resolved</span>}
                          </summary>
                          <div className="mt-1 text-[10px] text-mc-muted">Parties: {conf.parties.join(', ')}</div>
                          {conf.resolution && (
                            <div className="mt-0.5 text-[10px] text-green-400">Resolution: {conf.resolution} (by {agentName(conf.resolvedBy)})</div>
                          )}
                        </details>
                      ))}
                      {addingConflict === phase.id && (
                        <div className="bg-mc-surface border border-indigo-500/30 rounded p-2 space-y-1 mt-1">
                          <input value={newConflict.description} onChange={e => setNewConflict({ ...newConflict, description: e.target.value })}
                            placeholder="Conflict description..." className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          <input value={newConflict.parties} onChange={e => setNewConflict({ ...newConflict, parties: e.target.value })}
                            placeholder="Parties (comma-separated)..." className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          <input value={newConflict.resolution} onChange={e => setNewConflict({ ...newConflict, resolution: e.target.value })}
                            placeholder="Resolution (if resolved)..." className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          <input value={newConflict.resolvedBy} onChange={e => setNewConflict({ ...newConflict, resolvedBy: e.target.value })}
                            placeholder="Resolved by..." className="w-full bg-mc-bg border border-mc-border rounded px-2 py-1 text-xs text-mc-text" />
                          <div className="flex gap-1">
                            <button onClick={() => addConflictFn(phase.id)} className="px-2 py-0.5 bg-indigo-600 text-white rounded text-[10px]">Add</button>
                            <button onClick={() => setAddingConflict(null)} className="px-2 py-0.5 text-mc-muted text-[10px]">Cancel</button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
