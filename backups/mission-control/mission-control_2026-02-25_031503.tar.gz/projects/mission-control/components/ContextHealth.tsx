'use client';
import { useState, useEffect, useCallback } from 'react';

interface SessionHealth {
  key: string;
  label: string;
  model: string;
  contextTokens: number;
  totalTokens: number;
  pct: number;
  status: 'green' | 'yellow' | 'red';
  sessionType: 'webchat' | 'discord' | 'agent' | 'subagent' | 'telegram' | 'other';
  updatedAt: number | null;
}

interface ContextHealthData {
  sessions: SessionHealth[];
  alerts: SessionHealth[];
  summary: {
    total: number;
    healthy: number;
    warning: number;
    critical: number;
  };
}

type FilterType = 'all' | 'warning' | 'critical';
type TypeFilter = 'all' | 'webchat' | 'discord' | 'agent' | 'sub-agent';
type SortBy = 'pct' | 'lastActive';

export default function ContextHealth({ embedded = false }: { embedded?: boolean }) {
  const [data, setData] = useState<ContextHealthData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterType>('all');
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all');
  const [sortBy, setSortBy] = useState<SortBy>('pct');
  const [compacting, setCompacting] = useState<string | null>(null);
  const [compactResult, setCompactResult] = useState<{ key: string; msg: string; ok: boolean } | null>(null);
  const [compactProgress, setCompactProgress] = useState<string | null>(null);
  const [showCompactModal, setShowCompactModal] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [models, setModels] = useState<Record<string, { contextWindow: number; maxOutput: number; name: string }>>({});
  const [showModelDropdown, setShowModelDropdown] = useState<string | null>(null);
  const [changingModel, setChangingModel] = useState<string | null>(null);
  const [bulkCompacting, setBulkCompacting] = useState(false);
  const [bulkResult, setBulkResult] = useState<{ success: number; failed: number } | null>(null);

  // Infer session type from key
  const getSessionType = (key: string): SessionHealth['sessionType'] => {
    if (key.includes('subagent')) return 'subagent';
    if (key.includes('discord')) return 'discord';
    if (key.includes('telegram')) return 'telegram';
    if (key.startsWith('agent:') && !key.includes(':main:')) return 'agent';
    return 'webchat';
  };

  const fetchData = useCallback(async () => {
    try {
      const [healthRes, modelsRes] = await Promise.all([
        fetch('/api/context-health'),
        fetch('/api/models'),
      ]);
      
      const healthData = await healthRes.json();
      if (!healthRes.ok) throw new Error(`Error: ${healthRes.status}`);
      
      const modelsData = await modelsRes.json();
      if (modelsRes.ok && modelsData.models) {
        setModels(modelsData.models);
      }
      
      // Add sessionType to each session
      const enrichedSessions = (healthData.sessions || []).filter((s: any) => !s.key?.includes('discord')).map((s: SessionHealth) => ({
        ...s,
        sessionType: getSessionType(s.key),
      }));
      
      setData({ ...healthData, sessions: enrichedSessions });
      setError(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60000); // Auto-refresh every 60 seconds
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleCompact = async (sessionKey: string) => {
    setCompacting(sessionKey);
    setCompactResult(null);
    setShowCompactModal(true);
    setCompactProgress('📝 Generating session summary...');
    
    try {
      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'compact', sessionKey }),
      });
      const result = await response.json();
      
      if (result.ok) {
        setCompactProgress('💾 Flushing memories to disk...');
        await new Promise(r => setTimeout(r, 1500));
        
        setCompactProgress('🔄 Resetting session...');
        await new Promise(r => setTimeout(r, 2000));
        
        setCompactProgress('🔃 Loading fresh session...');
        await new Promise(r => setTimeout(r, 1000));
        
        // Refresh the data
        await fetchData();
        
        setCompactResult({ 
          key: sessionKey, 
          msg: '✅ Complete! Summary → COMPACT_SUMMARY.md. Session reset to 0 tokens. Haiku ready. 🚀', 
          ok: true 
        });
        setCompactProgress(null);
      } else {
        setCompactResult({ key: sessionKey, msg: result.error || 'Failed', ok: false });
        setCompactProgress(null);
      }
    } catch (err: any) {
      setCompactResult({ key: sessionKey, msg: err.message, ok: false });
      setCompactProgress(null);
    }
    setCompacting(null);
    setTimeout(() => {
      setCompactResult(null);
      setShowCompactModal(false);
    }, 3000);
  };

  const handleDelete = async (sessionKey: string) => {
    if (!confirm('Delete this session permanently?')) return;
    setCompacting(sessionKey);
    setCompactResult(null);
    try {
      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', sessionKey }),
      });
      const result = await response.json();
      if (!response.ok) {
        setCompactResult({ key: sessionKey, msg: result.error || 'Failed', ok: false });
      } else {
        setCompactResult({ key: sessionKey, msg: 'Deleted ✓', ok: true });
        await fetchData();
      }
    } catch (err: any) {
      setCompactResult({ key: sessionKey, msg: err.message, ok: false });
    } finally {
      setCompacting(null);
      setTimeout(() => setCompactResult(null), 5000);
    }
  };

  const handleChangeModel = async (sessionKey: string, model: string) => {
    setChangingModel(sessionKey);
    try {
      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'change-model', sessionKey, model }),
      });
      const result = await response.json();
      if (result.ok) {
        await fetchData();
        setShowModelDropdown(null);
      } else {
        alert(result.error || 'Failed to change model');
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setChangingModel(null);
    }
  };

  const handleReset = async (sessionKey: string) => {
    if (!confirm('Reset this session? This will clear context but keep the session alive.')) return;
    setCompacting(sessionKey);
    try {
      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'compact', sessionKey }),
      });
      const result = await response.json();
      if (result.ok) {
        await fetchData();
      } else {
        alert(result.error || 'Failed to reset');
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setCompacting(null);
    }
  };

  const handleBulkCompact = async () => {
    if (!confirm('Compact all sessions over 80%? This may take a while.')) return;
    setBulkCompacting(true);
    setBulkResult(null);
    try {
      const response = await fetch('/api/context-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'bulk-compact-over-80' }),
      });
      const result = await response.json();
      if (result.ok) {
        setBulkResult({ success: result.results?.filter((r: any) => r.success).length || 0, failed: result.results?.filter((r: any) => !r.success).length || 0 });
        await fetchData();
      } else {
        alert(result.error || 'Bulk compact failed');
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setBulkCompacting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'green': return 'bg-green-500';
      case 'yellow': return 'bg-yellow-500';
      case 'red': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getBarColor = (status: string) => {
    switch (status) {
      case 'green': return 'bg-green-500';
      case 'yellow': return 'bg-yellow-500';
      case 'red': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  // Helper to get model context window
  const getModelContextWindow = (model: string): number => {
    const modelInfo = models[model];
    return modelInfo?.contextWindow || 200000;
  };

  const filteredSessions = (data?.sessions || [])
    .filter(session => {
      // Status filter
      if (filter === 'warning') return session.status === 'yellow' || session.status === 'red';
      if (filter === 'critical') return session.status === 'red';
      // Type filter
      if (typeFilter === 'webchat') return session.sessionType === 'webchat';
      if (typeFilter === 'discord') return session.sessionType === 'discord';
      if (typeFilter === 'agent') return session.sessionType === 'agent';
      if (typeFilter === 'sub-agent') return session.sessionType === 'subagent';
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'lastActive') {
        return (b.updatedAt || 0) - (a.updatedAt || 0);
      }
      return b.pct - a.pct;
    });

  if (loading) {
    return (
      <div className={`bg-mc-surface border border-mc-border rounded-lg p-4 ${embedded ? '' : 'animate-pulse'}`}>
        <div className="text-sm text-mc-muted">Loading context health...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="text-sm text-red-400">Error: {error}</div>
        <button onClick={fetchData} className="mt-2 text-xs text-mc-accent hover:underline">
          Retry
        </button>
      </div>
    );
  }

  const summary = data?.summary || { total: 0, healthy: 0, warning: 0, critical: 0 };

  return (
    <div className={`bg-mc-surface border border-mc-border rounded-lg overflow-hidden ${embedded ? '' : 'mb-4'}`}>
      {/* Header */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-mc-bg/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className="text-sm">🧠</span>
          <span className="text-sm font-semibold">Context Health</span>
          <span className="text-xs text-mc-muted">({summary.total} sessions)</span>
        </div>
        <div className="flex items-center gap-2">
          {/* Summary badges */}
          <span className="text-xs px-2 py-0.5 rounded bg-green-500/20 text-green-400">
            {summary.healthy} healthy
          </span>
          {summary.warning > 0 && (
            <span className="text-xs px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400">
              {summary.warning} warning
            </span>
          )}
          {summary.critical > 0 && (
            <span className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400">
              {summary.critical} critical
            </span>
          )}
          <span className="text-mc-muted">{collapsed ? '▶' : '▼'}</span>
        </div>
      </button>

      {/* Collapsible Content */}
      {!collapsed && (
        <div className="border-t border-mc-border">
          {/* Filter and Sort Bar */}
          <div className="px-4 py-2 flex flex-wrap gap-2 border-b border-mc-border/50 items-center">
            {/* Status filter */}
            {(['all', 'warning', 'critical'] as FilterType[]).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-2 py-1 text-xs rounded transition-colors ${
                  filter === f
                    ? 'bg-mc-accent/20 text-mc-accent'
                    : 'bg-mc-bg text-mc-muted hover:text-mc-text'
                }`}
              >
                {f === 'all' ? 'All' : f === 'warning' ? '⚠️ Warning+' : '🔴 Critical'}
              </button>
            ))}
            
            <span className="text-mc-border">|</span>
            
            {/* Type filter tabs */}
            {(['all', 'webchat', 'discord', 'agent', 'sub-agent'] as TypeFilter[]).map(f => (
              <button
                key={f}
                onClick={() => setTypeFilter(f)}
                className={`px-2 py-1 text-xs rounded transition-colors ${
                  typeFilter === f
                    ? 'bg-blue-500/20 text-blue-400'
                    : 'bg-mc-bg text-mc-muted hover:text-mc-text'
                }`}
              >
                {f === 'all' ? 'All' : f === 'webchat' ? '💬 Web' : f === 'discord' ? '📱 Discord' : f === 'agent' ? '🤖 Agent' : '🔸 Sub'}
              </button>
            ))}
            
            <span className="text-mc-border">|</span>
            
            {/* Sort */}
            <span className="text-[10px] text-mc-muted">Sort:</span>
            <button
              onClick={() => setSortBy('pct')}
              className={`px-2 py-1 text-xs rounded transition-colors ${sortBy === 'pct' ? 'bg-purple-500/20 text-purple-400' : 'bg-mc-bg text-mc-muted hover:text-mc-text'}`}
            >
              Token %
            </button>
            <button
              onClick={() => setSortBy('lastActive')}
              className={`px-2 py-1 text-xs rounded transition-colors ${sortBy === 'lastActive' ? 'bg-purple-500/20 text-purple-400' : 'bg-mc-bg text-mc-muted hover:text-mc-text'}`}
            >
              Last Active
            </button>
            
            {/* Global bulk compact button */}
            <button
              onClick={handleBulkCompact}
              disabled={bulkCompacting}
              className="ml-auto px-2 py-1 text-xs rounded bg-orange-500/20 text-orange-400 hover:bg-orange-500/30 disabled:opacity-50"
            >
              {bulkCompacting ? '⏳ Working...' : '⚡ Compact All Over 80%'}
            </button>
            
            <button
              onClick={fetchData}
              className="px-2 py-1 text-xs text-mc-muted hover:text-mc-accent"
              title="Refresh"
            >
              🔄
            </button>
          </div>
          
          {bulkResult && (
            <div className="px-4 py-1 text-xs text-orange-400 bg-orange-500/10">
              ✅ Bulk compact: {bulkResult.success} succeeded, {bulkResult.failed} failed
            </div>
          )}

          {/* Session grid */}
          <div className="p-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {filteredSessions.map((session) => (
              <div
                key={session.key}
                className={`bg-mc-bg border rounded-lg p-3 ${
                  session.status === 'red'
                    ? 'border-red-500/50'
                    : session.status === 'yellow'
                    ? 'border-yellow-500/50'
                    : 'border-mc-border'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">{session.label}</div>
                    <div className="text-[10px] text-mc-muted truncate">{session.model}</div>
                  </div>
                  <div className="text-lg font-bold ml-2">
                    <span className={session.status === 'red' ? 'text-red-400' : session.status === 'yellow' ? 'text-yellow-400' : 'text-green-400'}>
                      {session.pct}%
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="h-2 bg-mc-surface rounded-full overflow-hidden mb-2">
                  <div
                    className={`h-full ${getBarColor(session.status)} transition-all`}
                    style={{ width: `${Math.min(session.pct, 100)}%` }}
                  />
                </div>

                {/* Token info with tooltip */}
                <div className="flex items-center justify-between text-[10px] text-mc-muted mb-2 group relative">
                  <span title={`${session.totalTokens.toLocaleString()} / ${session.contextTokens.toLocaleString()} tokens (model max: ${(getModelContextWindow(session.model) / 1000).toFixed(0)}K)`}>
                    {(session.totalTokens / 1000).toFixed(1)}K / {(session.contextTokens / 1000).toFixed(0)}K tokens
                  </span>
                  {session.updatedAt && (
                    <span className="text-[9px]">
                      {new Date(session.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                </div>

                {/* Model selector */}
                <div className="mb-2 relative">
                  <button
                    onClick={() => setShowModelDropdown(showModelDropdown === session.key ? null : session.key)}
                    disabled={changingModel === session.key}
                    className="w-full px-2 py-1 text-[10px] bg-mc-surface border border-mc-border rounded text-mc-muted hover:text-mc-text text-left flex items-center justify-between"
                  >
                    <span className="truncate">{session.model}</span>
                    <span className="text-[8px]">▼</span>
                  </button>
                  {showModelDropdown === session.key && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setShowModelDropdown(null)} />
                      <div className="absolute left-0 right-0 top-full mt-1 bg-mc-surface border border-mc-border rounded-lg shadow-xl z-50 max-h-32 overflow-y-auto">
                        {Object.entries(models).map(([id, info]) => (
                          <button
                            key={id}
                            onClick={() => handleChangeModel(session.key, id)}
                            disabled={changingModel === session.key}
                            className={`w-full px-2 py-1 text-[10px] text-left hover:bg-mc-bg ${session.model === id ? 'text-mc-accent' : 'text-mc-text'}`}
                          >
                            {info.name || id}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>

                {/* Action buttons */}
                <div className="flex gap-1">
                  <button
                    onClick={() => handleCompact(session.key)}
                    disabled={compacting === session.key}
                    className={`flex-1 py-1.5 text-xs rounded transition-colors flex items-center justify-center gap-1 ${
                      session.status === 'red'
                        ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                        : session.status === 'yellow'
                        ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                        : 'bg-mc-surface text-mc-muted hover:text-mc-text'
                    } disabled:opacity-50`}
                  >
                    {compacting === session.key ? (
                      <><span className="animate-spin">⏳</span></>
                    ) : (
                      <>🔄 Compact</>
                    )}
                  </button>
                  <button
                    onClick={() => handleReset(session.key)}
                    disabled={compacting === session.key}
                    className="px-2 py-1.5 text-xs rounded bg-mc-surface text-mc-muted hover:text-mc-text disabled:opacity-50 transition-colors"
                    title="Reset session"
                  >
                    ↺
                  </button>
                  {session.pct >= 90 && (
                    <button
                      onClick={() => handleDelete(session.key)}
                      disabled={compacting === session.key}
                      className="px-2 py-1.5 text-xs rounded bg-red-500/20 text-red-400 hover:bg-red-500/40 disabled:opacity-50 transition-colors"
                      title="Delete session"
                    >
                      🗑️
                    </button>
                  )}
                </div>
                {compactResult?.key === session.key && (
                  <div className={`text-[10px] mt-1 text-center ${compactResult.ok ? 'text-green-400' : 'text-red-400'}`}>
                    {compactResult.msg}
                  </div>
                )}
              </div>
            ))}

            {filteredSessions.length === 0 && (
              <div className="col-span-full text-center py-8 text-mc-muted text-xs">
                No sessions match the current filter.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Compaction Progress Modal */}
      {showCompactModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-mc-surface border border-mc-border rounded-lg p-6 max-w-sm w-full mx-4 shadow-xl">
            <div className="text-center">
              <div className="text-3xl mb-4">🧹</div>
              <h3 className="text-lg font-bold text-mc-text mb-2">Context Compaction</h3>
              
              {compactProgress && (
                <div className="text-sm text-mc-muted mb-4">
                  {compactProgress}
                </div>
              )}
              
              {compactResult && (
                <div className={`text-sm mb-4 ${compactResult.ok ? 'text-green-400' : 'text-red-400'}`}>
                  {compactResult.msg}
                </div>
              )}
              
              {compacting && (
                <div className="flex justify-center mb-4">
                  <div className="animate-spin text-2xl">⏳</div>
                </div>
              )}
              
              <button 
                onClick={() => setShowCompactModal(false)}
                className="px-4 py-2 bg-mc-accent text-white rounded hover:bg-mc-accent/80"
              >
                {compactResult ? 'Close' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
