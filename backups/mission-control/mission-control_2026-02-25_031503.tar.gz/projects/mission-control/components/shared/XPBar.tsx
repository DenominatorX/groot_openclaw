interface XPBarProps {
  xp: number;
  xpToNextLevel: number;
  progress: number;
  level: number;
  levelLabel: string;
  compact?: boolean;
}

export default function XPBar({ xp, xpToNextLevel, progress, level, levelLabel, compact = false }: XPBarProps) {
  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-mc-bg rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-mc-accent to-blue-400 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
        <span className="text-[10px] text-mc-muted font-medium whitespace-nowrap">
          {xp.toLocaleString()} XP
        </span>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5">
          <span className="px-1.5 py-0.5 rounded bg-mc-accent/20 text-mc-accent font-semibold text-[10px]">
            LVL {level}
          </span>
          <span className="text-mc-muted">{levelLabel}</span>
        </div>
        <span className="text-mc-muted">
          {xp.toLocaleString()} / {(xp + xpToNextLevel).toLocaleString()} XP
        </span>
      </div>
      <div className="h-2 bg-mc-bg rounded-full overflow-hidden border border-mc-border/50">
        <div 
          className="h-full bg-gradient-to-r from-mc-accent via-blue-400 to-cyan-400 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>
      <div className="text-[10px] text-mc-muted text-right">
        {xpToNextLevel.toLocaleString()} XP to Level {level + 1}
      </div>
    </div>
  );
}
