'use client';
import { useEffect, useState } from 'react';

interface Project {
  id: string;
  title: string;
  status?: string;
}

interface TestCase {
  id: string;
  title: string;
  status: 'pass' | 'fail' | 'skip' | 'untested';
  category?: string;
  comment?: string;
}

interface ProjectTests {
  projectId: string;
  tests: TestCase[];
}

export default function TestsDashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectTests, setProjectTests] = useState<Record<string, TestCase[]>>({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'failing' | 'passing' | 'no-tests'>('all');
  const [search, setSearch] = useState('');
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set());
  const [scanning, setScanning] = useState<string | null>(null);
  const [running, setRunning] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch all projects
      const projectsRes = await fetch('/api/projects');
      const projectsData = await projectsRes.json();
      setProjects(projectsData.projects || []);

      // Fetch tests for each project
      const testsData: Record<string, TestCase[]> = {};
      for (const project of projectsData.projects || []) {
        try {
          const testsRes = await fetch(`/api/tests?projectId=${project.id}`);
          const testsJson = await testsRes.json();
          testsData[project.id] = testsJson.tests || [];
        } catch {
          testsData[project.id] = [];
        }
      }
      setProjectTests(testsData);
    } catch (e) {
      console.error('Failed to fetch data:', e);
    }
    setLoading(false);
  };

  const saveProjectTests = async (projectId: string, tests: TestCase[]) => {
    await fetch('/api/tests', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, tests }),
    });
    setProjectTests(prev => ({ ...prev, [projectId]: tests }));
  };

  const handleTestChange = (projectId: string, testId: string, status: 'pass' | 'fail' | 'skip' | 'untested') => {
    const tests = projectTests[projectId] || [];
    const updatedTests = tests.map(t => t.id === testId ? { ...t, status } : { ...t, status: t.status || 'untested' });
    saveProjectTests(projectId, updatedTests);
  };

  const handleScan = async (projectId: string) => {
    setScanning(projectId);
    const tests = projectTests[projectId] || [];
    try {
      const project = projects.find(p => p.id === projectId);
      const res = await fetch('/api/tests/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, projectTitle: project?.title || 'Unknown', tests }),
      });
      const data = await res.json();
      if (data.plan) {
        alert(`AI Defect Scan Complete:\n\n${data.plan.slice(0, 500)}...`);
      }
    } catch (e) {
      alert('Scan failed');
    }
    setScanning(null);
  };

  const handleRunTests = async (projectId: string) => {
    setRunning(projectId);
    // Simulate running tests - in production would call Sentinel
    setTimeout(() => {
      setRunning(null);
    }, 2000);
  };

  const toggleExpand = (projectId: string) => {
    setExpandedProjects(prev => {
      const next = new Set(prev);
      if (next.has(projectId)) {
        next.delete(projectId);
      } else {
        next.add(projectId);
      }
      return next;
    });
  };

  // Calculate stats
  const allTests = Object.values(projectTests).flat();
  const totalTests = allTests.length;
  const totalPassed = allTests.filter(t => t.status === 'pass').length;
  const totalFailed = allTests.filter(t => t.status === 'fail').length;
  const totalSkipped = allTests.filter(t => t.status === 'skip').length;
  const passRate = totalTests > 0 ? Math.round((totalPassed / totalTests) * 100) : 0;

  // Filter projects
  const filteredProjects = projects.filter(project => {
    const tests = projectTests[project.id] || [];
    const hasTests = tests.length > 0;
    const hasFailing = tests.some(t => t.status === 'fail');
    const hasPassing = tests.some(t => t.status === 'pass');

    if (filter === 'failing' && !hasFailing) return false;
    if (filter === 'passing' && !hasPassing) return false;
    if (filter === 'no-tests' && hasTests) return false;

    if (search) {
      const searchLower = search.toLowerCase();
      const projectMatch = project.title.toLowerCase().includes(searchLower);
      const testMatch = tests.some(t => t.title.toLowerCase().includes(searchLower));
      if (!projectMatch && !testMatch) return false;
    }

    return true;
  });

  const statusIcons: Record<string, string> = {
    pass: '✅',
    fail: '❌',
    skip: '⏭',
    untested: '⬜',
  };

  const statusColors: Record<string, string> = {
    pass: 'bg-green-500/20 text-green-400 border-green-500/30',
    fail: 'bg-red-500/20 text-red-400 border-red-500/30',
    skip: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    untested: 'bg-mc-bg text-mc-muted border-mc-border',
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-mc-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary Header */}
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-6">
            <div>
              <div className="text-xs text-mc-muted">Total Tests</div>
              <div className="text-2xl font-bold">{totalTests}</div>
            </div>
            <div>
              <div className="text-xs text-mc-muted">Pass Rate</div>
              <div className={`text-2xl font-bold ${passRate >= 80 ? 'text-green-400' : passRate >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                {passRate}%
              </div>
            </div>
            <div>
              <div className="text-xs text-mc-muted">Passed</div>
              <div className="text-xl font-medium text-green-400">{totalPassed}</div>
            </div>
            <div>
              <div className="text-xs text-mc-muted">Failed</div>
              <div className="text-xl font-medium text-red-400">{totalFailed}</div>
            </div>
            <div>
              <div className="text-xs text-mc-muted">Skipped</div>
              <div className="text-xl font-medium text-yellow-400">{totalSkipped}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex bg-mc-bg border border-mc-border rounded overflow-hidden">
              {(['all', 'failing', 'passing', 'no-tests'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 text-xs transition-colors ${
                    filter === f
                      ? 'bg-mc-accent/20 text-mc-accent font-medium'
                      : 'text-mc-muted hover:text-mc-text'
                  }`}
                >
                  {f === 'all' ? 'All' : f === 'failing' ? 'Failing' : f === 'passing' ? 'Passing' : 'No Tests'}
                </button>
              ))}
            </div>
            
            <input
              type="text"
              placeholder="Search tests..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="px-3 py-1.5 text-xs bg-mc-bg border border-mc-border rounded text-mc-text placeholder:text-mc-muted focus:outline-none focus:border-mc-accent"
            />
          </div>
        </div>
      </div>

      {/* Projects with Tests */}
      {filteredProjects.length === 0 ? (
        <div className="text-center py-12 text-mc-muted">
          <div className="text-3xl mb-2">🧪</div>
          <div className="text-sm">No projects found</div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredProjects.map((project) => {
            const tests = projectTests[project.id] || [];
            const hasTests = tests.length > 0;
            const passed = tests.filter(t => t.status === 'pass').length;
            const failed = tests.filter(t => t.status === 'fail').length;
            const skipped = tests.filter(t => t.status === 'skip').length;
            const total = tests.length;
            const isExpanded = expandedProjects.has(project.id);

            // Filter tests by search within project
            const filteredTests = search
              ? tests.filter(t => t.title.toLowerCase().includes(search.toLowerCase()))
              : tests;

            return (
              <div key={project.id} className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden">
                {/* Project Header */}
                <div 
                  className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-mc-bg transition-colors"
                  onClick={() => toggleExpand(project.id)}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{isExpanded ? '▼' : '▶'}</span>
                    <div>
                      <div className="text-sm font-medium">{project.title}</div>
                      <div className="text-xs text-mc-muted">
                        {hasTests ? `${total} test${total !== 1 ? 's' : ''}` : 'No tests'}
                      </div>
                    </div>
                  </div>
                  
                  {hasTests && (
                    <div className="flex items-center gap-4">
                      {/* Progress bar */}
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-mc-border rounded-full overflow-hidden flex">
                          <div className="h-full bg-green-500" style={{ width: `${total > 0 ? (passed/total)*100 : 0}%` }} />
                          <div className="h-full bg-red-500" style={{ width: `${total > 0 ? (failed/total)*100 : 0}%` }} />
                          <div className="h-full bg-yellow-500" style={{ width: `${total > 0 ? (skipped/total)*100 : 0}%` }} />
                        </div>
                        <span className="text-xs text-green-400">{passed}</span>
                        <span className="text-xs text-red-400">{failed}</span>
                        <span className="text-xs text-yellow-400">{skipped}</span>
                      </div>
                      
                      {/* Action buttons */}
                      <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => handleScan(project.id)}
                          disabled={scanning === project.id}
                          className="px-2 py-1 text-xs bg-blue-500/20 text-blue-400 rounded hover:bg-blue-500/30 disabled:opacity-50"
                        >
                          {scanning === project.id ? '🔍 Scanning...' : '🔍 AI Defect Scan'}
                        </button>
                        <button
                          onClick={() => handleRunTests(project.id)}
                          disabled={running === project.id}
                          className="px-2 py-1 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 disabled:opacity-50"
                        >
                          {running === project.id ? '⏳ Running...' : '▶ Run Tests'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Expanded Test List */}
                {isExpanded && hasTests && (
                  <div className="border-t border-mc-border">
                    {filteredTests.length === 0 ? (
                      <div className="px-4 py-3 text-xs text-mc-muted">No matching tests</div>
                    ) : (
                      <div className="divide-y divide-mc-border">
                        {filteredTests.map((test, idx) => (
                          <div key={test.id} className="flex items-center gap-3 px-4 py-2 hover:bg-mc-bg">
                            <span className="text-xs text-mc-muted w-6">{idx + 1}.</span>
                            
                            {/* Status buttons */}
                            <div className="flex gap-1">
                              {(['pass', 'fail', 'skip', 'untested'] as const).map((status) => (
                                <button
                                  key={status}
                                  onClick={() => handleTestChange(project.id, test.id, status)}
                                  className={`px-2 py-0.5 text-xs rounded border transition-all ${
                                    test.status === status 
                                      ? statusColors[status] 
                                      : 'border-transparent text-mc-muted hover:text-mc-text'
                                  }`}
                                  title={status.charAt(0).toUpperCase() + status.slice(1)}
                                >
                                  {statusIcons[status]}
                                </button>
                              ))}
                            </div>
                            
                            <span className={`text-sm flex-1 ${
                              test.status === 'pass' ? 'text-green-400' :
                              test.status === 'fail' ? 'text-red-400' :
                              test.status === 'skip' ? 'text-yellow-400' :
                              'text-mc-text'
                            }`}>
                              {test.title}
                            </span>
                            
                            {test.category && (
                              <span className="text-xs text-mc-muted px-2 py-0.5 bg-mc-bg rounded">
                                {test.category}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
