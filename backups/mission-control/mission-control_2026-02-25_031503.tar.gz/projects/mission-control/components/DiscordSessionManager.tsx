'use client';
import { useState, useEffect, useCallback } from 'react';
import { MessageSquare, RotateCcw, RefreshCw, AlertTriangle, Zap } from 'lucide-react';

interface DiscordSession {
  key: string;
  channelId: string;
  channelName: string;
  model: string;
  contextTokens: number;
  totalTokens: number;
  contextWindow: number;
  pct: number;
  lastActive: string;
  status: 'active' | 'idle' | 'error';
  autoCompact: boolean;
}

interface DiscordSessionsData {
  sessions: DiscordSession[];
  summary: {
    total: number;
    active: number;
    idle: number;
  };
}

const AVAILABLE_MODELS = [
  { id: 'anthropic/claude-sonnet-4-6', label: 'Sonnet 4.6' },
  { id: 'anthropic/claude-haiku-4-5', label: 'Haiku 4.5' },
  { id: 'anthropic/claude-opus-4-6', label: 'Opus 4.6' },
  { id: 'xai/grok-4', label: 'Grok 4' },
  { id: 'xai/grok-4-1-fast', label: 'Grok 4.1 Fast' },
  { id: 'openrouter/minimax/minimax-m2.5', label: 'MiniMax M2.5' },
  { id: 'openrouter/google/gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
];

function timeAgo(ts: string) {
  if (!ts) return 'Never';
  const diff = Date.now() - new Date(ts).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error'; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);
  
  return (
    <div className={`fixed bottom-4 right-4 px-4 py-3 rounded-lg shadow-xl z-50 flex items-center gap-2 ${
      type === 'success' ? 'bg-green-500/20 border border-green-500/50 text-green-400' : 'bg-red-500/20 border border-red-500/50 text-red-400'
    }`}>
      <span>{type === 'success' ? '✓' : '✕'}</span>
      <span className="text-sm">{message}</span>
    </div>
  );
}

export default function DiscordSessionManager({ embedded = false }: { embedded?: boolean }) {
  const [data, setData] = useState<DiscordSessionsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState<string | null>(null);
  const [showGlobalResetConfirm, setShowGlobalResetConfirm] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const response = await fetch('/api/discord-sessions');
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      const result = await response.json();
      setData(result);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      // Mock data for development
      setData({
        sessions: [
          {
            key: 'discord-1472849769050411101',
            channelId: '1472849769050411101',
            channelName: '#mission-control',
            model: 'anthropic/claude-sonnet-4-6',
            contextTokens: 45000,
            totalTokens: 85000,
            contextWindow: 200000,
            pct: 42,
            lastActive: new Date(Date.now() - 5 * 60000).toISOString(),
            status: 'active',
            autoCompact: true,
          },
          {
            key: 'discord-1472849771264741437',
            channelId: '1472849771264741437',
            channelName: '#ideas',
            model: 'anthropic/claude-haiku-4-5',
            contextTokens: 120000,
            totalTokens: 180000,
            contextWindow: 200000,
            pct: 90,
            lastActive: new Date(Date.now() - 30 * 60000).toISOString(),
            status: 'idle',
            autoCompact: false,
          },
          {
            key: 'discord-1472849770002513920',
            channelId: '1472849770002513920',
            channelName: '#development',
            model: 'xai/grok-4',
            contextTokens: 65000,
            totalTokens: 131000,
            contextWindow: 131000,
            pct: 100,
            lastActive: new Date(Date.now() - 2 * 3600000).toISOString(),
            status: 'idle',
            autoCompact: true,
          },
        ],
        summary: { total: 3, active: 1, idle: 2 },
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleCompact = async (sessionKey: string) => {
    setActionInProgress(`compact-${sessionKey}`);
    try {
      const response = await fetch(`/api/discord-sessions/${sessionKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'compact' }),
      });
      const result = await response.json();
      if (result.ok) {
        setToast({ message: `Compacted ${result.channelName || sessionKey} — ${result.savedTokens || 0}K tokens saved`, type: 'success' });
        await fetchData();
      } else {
        setToast({ message: result.error || 'Compaction failed', type: 'error' });
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
    setActionInProgress(null);
  };

  const handleReset = async (sessionKey: string) => {
    setActionInProgress(`reset-${sessionKey}`);
    setShowResetConfirm(null);
    try {
      const response = await fetch(`/api/discord-sessions/${sessionKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset' }),
      });
      const result = await response.json();
      if (result.ok) {
        setToast({ message: `Reset ${result.channelName || sessionKey}`, type: 'success' });
        await fetchData();
      } else {
        setToast({ message: result.error || 'Reset failed', type: 'error' });
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
    setActionInProgress(null);
  };

  const handleChangeModel = async (sessionKey: string, newModel: string) => {
    setActionInProgress(`model-${sessionKey}`);
    setShowModelDropdown(null);
    try {
      const response = await fetch(`/api/discord-sessions/${sessionKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'change-model', model: newModel }),
      });
      const result = await response.json();
      if (result.ok) {
        setToast({ message: `Model changed to ${newModel}`, type: 'success' });
        await fetchData();
      } else {
        setToast({ message: result.error || 'Model change failed', type: 'error' });
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
    setActionInProgress(null);
  };

  const handleAutoCompactToggle = async (session: DiscordSession) => {
    const newAutoCompact = !session.autoCompact;
    localStorage.setItem(`discord-auto-compact-${session.channelId}`, newAutoCompact ? 'true' : 'false');
    // Update local state immediately
    if (data) {
      setData({
        ...data,
        sessions: data.sessions.map(s => 
          s.key === session.key ? { ...s, autoCompact: newAutoCompact } : s
        ),
      });
    }
    setToast({ message: `Auto-compact ${newAutoCompact ? 'enabled' : 'disabled'} for ${session.channelName}`, type: 'success' });
  };

  const handleCompactAll = async () => {
    if (!data?.sessions.length) return;
    setActionInProgress('compact-all');
    try {
      for (const session of data.sessions) {
        await fetch(`/api/discord-sessions/${session.key}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'compact' }),
        });
      }
      setToast({ message: 'Compacted all Discord sessions', type: 'success' });
      await fetchData();
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
    setActionInProgress(null);
  };

  const handleResetAll = async () => {
    if (!data?.sessions.length) return;
    setShowGlobalResetConfirm(false);
    setActionInProgress('reset-all');
    try {
      for (const session of data.sessions) {
        await fetch(`/api/discord-sessions/${session.key}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'reset' }),
        });
      }
      setToast({ message: 'Reset all Discord sessions', type: 'success' });
      await fetchData();
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
    setActionInProgress(null);
  };

  const getStatusColor = (status: string, pct: number) => {
    if (status === 'error') return 'text-red-400';
    if (pct >= 80) return 'text-yellow-400';
    if (pct >= 90) return 'text-red-400';
    return 'text-green-400';
  };

  const getBarColor = (pct: number) => {
    if (pct >= 90) return 'bg-red-500';
    if (pct >= 80) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  if (loading) {
    return (
      <div className={`bg-mc-surface border border-mc-border rounded-lg p-4 ${embedded ? '' : 'animate-pulse'}`}>
        <div className="text-sm text-mc-muted">Loading Discord sessions...</div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="text-sm text-red-400">Error: {error}</div>
        <button onClick={fetchData} className="mt-2 text-xs text-mc-accent hover:underline">
          Retry
        </button>
      </div>
    );
  }

  const summary = data?.summary || { total: 0, active: 0, idle: 0 };
  const sessions = data?.sessions || [];

  return (
    <>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      
      <div className={`bg-mc-surface border border-mc-border rounded-lg overflow-hidden ${embedded ? '' : 'mb-4'}`}>
        {/* Header */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full px-4 py-3 flex items-center justify-between hover:bg-mc-bg/50 transition-colors"
        >
          <div className="flex items-center gap-2">
            <span className="text-sm">💬</span>
            <span className="text-sm font-semibold">Discord Sessions</span>
            <span className="text-xs text-mc-muted">({summary.total} channels)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2 py-0.5 rounded bg-green-500/20 text-green-400">
              {summary.active} active
            </span>
            {summary.idle > 0 && (
              <span className="text-xs px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400">
                {summary.idle} idle
              </span>
            )}
            <span className="text-mc-muted">{collapsed ? '▶' : '▼'}</span>
          </div>
        </button>

        {/* Collapsible Content */}
        {!collapsed && (
          <div className="border-t border-mc-border">
            {/* Global Actions */}
            <div className="px-4 py-2 flex gap-2 border-b border-mc-border/50">
              <button
                onClick={handleCompactAll}
                disabled={actionInProgress !== null}
                className="px-3 py-1.5 text-xs rounded bg-mc-accent/20 text-mc-accent hover:bg-mc-accent/30 transition-colors disabled:opacity-50 flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                Compact All
              </button>
              <button
                onClick={() => setShowGlobalResetConfirm(true)}
                disabled={actionInProgress !== null}
                className="px-3 py-1.5 text-xs rounded bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors disabled:opacity-50 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                Reset All
              </button>
              <button
                onClick={fetchData}
                className="ml-auto px-2 py-1.5 text-xs text-mc-muted hover:text-mc-accent"
                title="Refresh"
              >
                🔄
              </button>
            </div>

            {/* Session Cards */}
            <div className="p-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
              {sessions.map((session) => (
                <div
                  key={session.key}
                  className={`bg-mc-bg border rounded-lg p-3 ${
                    session.pct >= 90
                      ? 'border-red-500/50'
                      : session.pct >= 80
                      ? 'border-yellow-500/50'
                      : 'border-mc-border'
                  }`}
                >
                  {/* Channel Info */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium truncate flex items-center gap-1">
                        <MessageSquare className="w-3 h-3 text-indigo-400" />
                        {session.channelName}
                      </div>
                      <div className="text-[10px] text-mc-muted truncate">{session.model}</div>
                    </div>
                    <div className="text-lg font-bold ml-2">
                      <span className={getStatusColor(session.status, session.pct)}>
                        {session.pct}%
                      </span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="h-2 bg-mc-surface rounded-full overflow-hidden mb-2">
                    <div
                      className={`h-full ${getBarColor(session.pct)} transition-all`}
                      style={{ width: `${Math.min(session.pct, 100)}%` }}
                    />
                  </div>

                  {/* Token info with tooltip */}
                  <div className="text-[10px] text-mc-muted mb-2 flex items-center justify-between">
                    <span title={`Model context window: ${(session.contextWindow / 1000).toFixed(0)}K`}>
                      {(session.totalTokens / 1000).toFixed(1)}K / {(session.contextWindow / 1000).toFixed(0)}K tokens
                    </span>
                    <span className="text-mc-muted/60">{timeAgo(session.lastActive)}</span>
                  </div>

                  {/* Per-session actions */}
                  <div className="flex flex-wrap gap-1 mb-2">
                    <button
                      onClick={() => handleCompact(session.key)}
                      disabled={actionInProgress === `compact-${session.key}`}
                      className={`flex-1 py-1.5 text-xs rounded transition-colors flex items-center justify-center gap-1 ${
                        session.pct >= 80
                          ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                          : 'bg-mc-surface text-mc-muted hover:text-mc-text'
                      } disabled:opacity-50`}
                    >
                      {actionInProgress === `compact-${session.key}` ? (
                        <span className="animate-spin">⏳</span>
                      ) : (
                        <RefreshCw className="w-3 h-3" />
                      )}
                      Compact
                    </button>
                    <button
                      onClick={() => setShowResetConfirm(session.key)}
                      disabled={actionInProgress === `reset-${session.key}`}
                      className="px-2 py-1.5 text-xs rounded bg-red-500/20 text-red-400 hover:bg-red-500/30 disabled:opacity-50 transition-colors"
                      title="Reset session"
                    >
                      <RotateCcw className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Model dropdown and auto-compact toggle */}
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <button
                        onClick={() => setShowModelDropdown(showModelDropdown === session.key ? null : session.key)}
                        className="w-full px-2 py-1 text-xs bg-mc-surface border border-mc-border rounded text-mc-muted hover:text-mc-text flex items-center justify-between"
                      >
                        <span className="truncate">{session.model.split('/').pop()}</span>
                        <span className="text-[10px]">▼</span>
                      </button>
                      {showModelDropdown === session.key && (
                        <>
                          <div className="fixed inset-0 z-40" onClick={() => setShowModelDropdown(null)} />
                          <div className="absolute left-0 bottom-full mb-1 bg-mc-surface border border-mc-border rounded-lg shadow-xl z-50 w-full py-1 max-h-32 overflow-y-auto">
                            {AVAILABLE_MODELS.map(m => (
                              <button
                                key={m.id}
                                onClick={() => handleChangeModel(session.key, m.id)}
                                className={`w-full px-2 py-1 text-xs text-left hover:bg-mc-bg transition-colors ${
                                  session.model === m.id ? 'text-mc-accent font-medium' : 'text-mc-text'
                                }`}
                              >
                                {m.label}
                              </button>
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                    <button
                      onClick={() => handleAutoCompactToggle(session)}
                      className={`p-1.5 rounded transition-colors ${
                        session.autoCompact
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-mc-surface text-mc-muted'
                      }`}
                      title="Auto-compact"
                    >
                      <Zap className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Reset confirmation */}
                  {showResetConfirm === session.key && (
                    <div className="mt-2 p-2 bg-red-500/10 border border-red-500/30 rounded">
                      <div className="text-xs text-red-400 mb-2 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Reset {session.channelName}? This will clear all context.
                      </div>
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleReset(session.key)}
                          disabled={actionInProgress === `reset-${session.key}`}
                          className="px-2 py-1 text-xs bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                        >
                          Confirm Reset
                        </button>
                        <button
                          onClick={() => setShowResetConfirm(null)}
                          className="px-2 py-1 text-xs text-mc-muted hover:text-mc-text"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}

              {sessions.length === 0 && (
                <div className="col-span-full text-center py-8 text-mc-muted text-xs">
                  No Discord sessions found.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Global Reset Confirmation Modal */}
        {showGlobalResetConfirm && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
            <div className="bg-mc-surface border border-mc-border rounded-lg p-6 max-w-sm w-full mx-4 shadow-xl">
              <div className="text-center">
                <div className="text-3xl mb-4 text-red-400">⚠️</div>
                <h3 className="text-lg font-bold text-mc-text mb-2">Reset All Discord Sessions?</h3>
                <p className="text-sm text-mc-muted mb-4">
                  This will clear all context from all Discord channels. This action cannot be undone.
                </p>
                <div className="flex gap-2 justify-center">
                  <button 
                    onClick={handleResetAll}
                    disabled={actionInProgress === 'reset-all'}
                    className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                  >
                    Confirm Reset All
                  </button>
                  <button 
                    onClick={() => setShowGlobalResetConfirm(false)}
                    className="px-4 py-2 text-mc-muted hover:text-mc-text"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
