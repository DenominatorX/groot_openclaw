'use client';
import React from 'react';

interface Props { children: React.ReactNode; fallback?: React.ReactNode; }
interface State { hasError: boolean; error?: Error; }

export default class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError(error: Error) { return { hasError: true, error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) { console.error('ErrorBoundary caught:', error, info); }
  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="p-6 text-center">
          <div className="text-2xl mb-2">⚠️</div>
          <div className="text-sm text-red-400 mb-1">Something went wrong</div>
          <div className="text-xs text-mc-muted mb-3 font-mono">{this.state.error?.message}</div>
          <button onClick={() => this.setState({ hasError: false })}
            className="px-4 py-2 bg-mc-accent text-white rounded text-sm">Retry</button>
        </div>
      );
    }
    return this.props.children;
  }
}
