'use client';

import { useState, useEffect, useRef } from 'react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'agent';
  sender?: string;
  senderName?: string;
  content: string;
  timestamp: string;
}

interface ProjectChatProps {
  projectId: string;
}

export default function ProjectChat({ projectId }: ProjectChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  // Load messages
  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const res = await fetch(`/api/projects/${projectId}/chat`);
        const data = await res.json();
        setMessages(data.messages || []);
      } catch (e) {
        console.error('Failed to load chat:', e);
      } finally {
        setLoading(false);
      }
    };

    fetchMessages();
    
    // Poll for new messages every 5 seconds
    const interval = setInterval(fetchMessages, 5000);
    return () => clearInterval(interval);
  }, [projectId]);

  // Don't auto-scroll on message updates.
  // Kevin requested manual scrolling so project details stay stable.


  const sendMessage = async () => {
    if (!input.trim() || sending) return;
    
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      sender: 'kevin',
      senderName: 'Kevin (You)',
      content: input.trim(),
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSending(true);
    setError(null);

    try {
      const res = await fetch(`/api/projects/${projectId}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input.trim() }),
      });
      
      const data = await res.json();
      
      if (data.messages) {
        setMessages(data.messages);
      } else if (data.response) {
        // Add agent response
        const agentMessage: ChatMessage = {
          id: `msg-${Date.now()}-agent`,
          role: 'agent',
          sender: data.agentId || 'agent',
          senderName: data.agentName || 'Agent',
          content: data.response,
          timestamp: new Date().toISOString(),
        };
        setMessages(prev => [...prev, agentMessage]);
      }
    } catch (e) {
      setError('Failed to send message');
      console.error('Chat error:', e);
    } finally {
      setSending(false);
    }
  };

  const formatTime = (timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return '--:--';
    }
  };

  const getAvatarColor = (sender: string) => {
    const colors = ['bg-purple-500', 'bg-blue-500', 'bg-green-500', 'bg-orange-500', 'bg-pink-500', 'bg-teal-500'];
    const hash = sender.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return colors[hash % colors.length];
  };

  if (loading) {
    return (
      <div className="bg-mc-surface border border-mc-border rounded-lg p-4">
        <div className="animate-pulse text-xs text-mc-muted">Loading chat...</div>
      </div>
    );
  }

  return (
    <div className="bg-mc-surface border border-mc-border rounded-lg overflow-hidden flex flex-col h-80">
      {/* Header */}
      <div className="px-3 py-2 border-b border-mc-border flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-sm">💬</span>
          <span className="text-xs font-semibold text-mc-text">Project Chat</span>
        </div>
        <span className="text-[10px] text-mc-muted">{messages.length} messages</span>
      </div>

      {error && (
        <div className="px-3 py-1.5 bg-red-500/10 text-red-400 text-[10px]">
          {error}
        </div>
      )}

      {/* Messages - overflow-anchor:none prevents auto-scroll from moving the whole page */}
      <div ref={messagesContainerRef} className="flex-1 overflow-y-auto p-3 space-y-2" style={{ overflowAnchor: 'none' }}>
        {messages.length === 0 ? (
          <div className="text-center text-xs text-mc-muted py-6">
            No messages yet. Start the conversation!
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            const initials = (msg.senderName || msg.sender || '?').slice(0, 2).toUpperCase();
            const avatarColor = getAvatarColor(msg.sender || 'unknown');
            
            return (
              <div key={msg.id} className={`flex items-end gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}>
                {!isUser && (
                  <div className={`flex-shrink-0 w-6 h-6 rounded-full ${avatarColor} flex items-center justify-center text-[9px] font-bold text-white`}>
                    {initials}
                  </div>
                )}
                <div className={`max-w-[75%] rounded-lg px-3 py-2 text-xs ${
                  isUser 
                    ? 'bg-mc-accent/20 text-mc-accent' 
                    : 'bg-mc-bg border border-mc-border text-mc-text'
                }`}>
                  <div className={`text-[10px] font-semibold mb-0.5 ${
                    isUser ? 'text-mc-accent' : avatarColor.replace('bg-', 'text-').replace('-500', '-400')
                  }`}>
                    {msg.senderName || msg.sender}
                    <span className="text-[9px] text-mc-muted ml-2">
                      {formatTime(msg.timestamp)}
                    </span>
                  </div>
                  <div className="break-words">{msg.content}</div>
                </div>
              </div>
            );
          })
        )}
        <div />
      </div>

      {/* Input */}
      <div className="border-t border-mc-border p-2 flex-shrink-0">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder="Type a message..."
            disabled={sending}
            className="flex-1 bg-mc-bg border border-mc-border rounded px-3 py-2 text-xs text-mc-text placeholder-mc-muted focus:outline-none focus:border-mc-accent disabled:opacity-50"
          />
          <button
            onClick={sendMessage}
            disabled={sending || !input.trim()}
            className="px-3 py-2 bg-mc-accent text-white rounded text-xs font-semibold hover:opacity-80 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {sending ? '⏳' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
}
