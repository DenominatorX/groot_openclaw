'use client';
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import XPBar from './shared/XPBar';
import XPBadge from './shared/XPBadge';

const TIER_LABELS: Record<number, string> = {
  0: 'Owner', 1: 'Executive Board', 2: 'VP', 3: 'Director',
  4: 'Sr. Manager', 5: 'Manager', 6: 'Frontline',
};

const CHARACTER_EMOJIS: Record<string, string> = {
  lobster: '🦞', robot: '🤖', humanoid: '🧑', orb: '🔮',
  mech: '⚙️', ghost: '👻', cat: '🐱', tree: '🌳', bee: '🐝', dragonfly: '🪰', hillbilly: '🤠',
};

const TIER_BADGES: Record<number, { label: string; color: string }> = {
  0: { label: 'OWNER', color: 'text-yellow-400' },
  1: { label: 'EXEC', color: 'text-purple-400' },
  2: { label: 'VP', color: 'text-blue-400' },
  3: { label: 'DIR', color: 'text-cyan-400' },
  4: { label: 'SR', color: 'text-green-400' },
  5: { label: 'MGR', color: 'text-orange-400' },
  6: { label: 'FW', color: 'text-gray-400' },
};

interface Agent {
  id: string;
  name: string;
  displayName?: string;
  role: string;
  title?: string;
  tier: number;
  status: string;
  initials: string;
  color: string;
  avatarType?: string;
  isExecutiveBoard?: boolean;
  department?: string;
}

interface Props {
  collapsed: boolean;
  onToggle: () => void;
  onSelectAgent?: (agentId: string) => void;
  onShowOrgChart?: () => void;
}

export default function AgentsSidebar({ collapsed, onToggle, onSelectAgent, onShowOrgChart }: Props) {
  const { data: session } = useSession();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newAgent, setNewAgent] = useState({ name: '', role: '', tier: 6, parent: '', department: 'Operations', avatarType: 'lobster' });

  const [activeSessions, setActiveSessions] = useState<Record<string, {status: string; currentTask: string | null}>>({});
  const [agentXp, setAgentXp] = useState<Record<string, { xp: number; level: number; levelLabel: string; progress: number; efficiency: number }>>({});

  useEffect(() => {
    if (!session) return;
    const fetchAll = () => {
      fetch('/api/agents').then(r => r.json()).then(d => setAgents(d.agents || [])).catch(() => {});
      fetch('/api/dispatch').then(r => r.json()).then(d => {
        const map: Record<string, any> = {};
        (d.sessions || []).forEach((s: any) => { map[s.agentId] = { status: s.status, currentTask: s.currentTask }; });
        setActiveSessions(map);
      }).catch(() => {});
    };
    // Fetch XP data for all agents
    const fetchXp = () => {
      fetch('/api/leaderboard?period=all-time&limit=50').then(r => r.json()).then(d => {
        const xpMap: Record<string, any> = {};
        (d.leaderboard || []).forEach((entry: any) => {
          xpMap[entry.agentId] = {
            xp: entry.xp,
            level: entry.level,
            levelLabel: entry.levelLabel,
            progress: (entry.xp % 1000) / 10,
            efficiency: entry.efficiency,
          };
        });
        setAgentXp(xpMap);
      }).catch(() => {});
    };
    fetchAll();
    fetchXp();
    const interval = setInterval(fetchAll, 10000);
    return () => clearInterval(interval);
  }, [session]);

  const execBoard = agents.filter(a => a.isExecutiveBoard);
  const others = agents.filter(a => !a.isExecutiveBoard);

  // Gate: no session → show locked placeholder
  if (!session) {
    return (
      <div className={`flex flex-col bg-mc-surface border-r border-mc-border transition-all ${collapsed ? 'w-12' : 'w-[220px]'}`}>
        <div className="flex items-center justify-between px-3 py-2 border-b border-mc-border">
          {!collapsed && <span className="text-xs font-semibold text-mc-muted uppercase tracking-wide">Agents</span>}
          <button onClick={onToggle} className="text-mc-muted hover:text-mc-text text-sm">
            {collapsed ? '»' : '«'}
          </button>
        </div>
        {!collapsed && (
          <div className="flex-1 flex flex-col items-center justify-center px-3 py-8 text-center gap-2">
            <span className="text-2xl opacity-40">🔒</span>
            <p className="text-[11px] text-mc-muted">Sign in to see agents</p>
          </div>
        )}
      </div>
    );
  }

  const renderAgent = (agent: Agent) => {
    const emoji = CHARACTER_EMOJIS[agent.avatarType || 'lobster'] || '🦞';
    const tier = TIER_BADGES[agent.tier] || TIER_BADGES[6];
    const xp = agentXp[agent.id];

    return (
      <button
        key={agent.id}
        type="button"
        className={`w-full flex items-center gap-2 py-2 hover:bg-mc-bg transition-colors cursor-pointer group text-left ${collapsed ? 'justify-center px-0' : 'px-3'}`}
        onClick={() => onSelectAgent?.(agent.id)}
        title={collapsed ? `${agent.name} — ${agent.role}` : undefined}
      >
        <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-lg relative"
          style={{ backgroundColor: agent.color + '22', border: `2px solid ${agent.color}` }}>
          {emoji}
          <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-mc-surface ${
            (activeSessions[agent.id]?.status === 'working') ? 'bg-yellow-500 animate-pulse' :
            agent.status === 'active' ? 'bg-green-500' : 'bg-gray-500'
          }`} />
        </div>
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1">
              <span className="text-sm font-medium truncate group-hover:text-mc-accent transition-colors">
                {agent.name}{agent.model && <span className="text-[10px] text-mc-muted ml-1">({agent.model.split('/').pop()})</span>}
              </span>
              <span className={`text-[10px] font-bold ${tier.color}`}>{tier.label}</span>
            </div>
            <div className="text-[10px] text-mc-muted truncate">
              {activeSessions[agent.id]?.status === 'working' 
                ? <span className="text-yellow-400">⚡ {activeSessions[agent.id]?.currentTask?.slice(0, 40)}...</span>
                : agent.role}
            </div>
            {xp && (
              <div className="mt-1">
                <XPBar 
                  xp={xp.xp} 
                  xpToNextLevel={1000 - (xp.xp % 1000)} 
                  progress={xp.progress} 
                  level={xp.level} 
                  levelLabel={xp.levelLabel} 
                  compact 
                />
              </div>
            )}
          </div>
        )}
      </button>
    );
  };

  return (
    <div className={`flex flex-col bg-mc-surface border-r border-mc-border transition-all ${collapsed ? 'w-12' : 'w-[220px]'}`}>
      <div className="flex items-center justify-between px-3 py-2 border-b border-mc-border">
        {!collapsed && <span className="text-xs font-semibold text-mc-muted uppercase tracking-wide">Agents</span>}
        <button onClick={onToggle} className="text-mc-muted hover:text-mc-text text-sm">
          {collapsed ? '»' : '«'}
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {!collapsed && execBoard.length > 0 && (
          <div className="px-3 pt-2 pb-1">
            <span className="text-[10px] text-yellow-400/70 uppercase tracking-wider font-bold">⭐ Executive Board</span>
          </div>
        )}
        {execBoard.map(renderAgent)}

        {others.length > 0 && (
          <>
            {!collapsed && (
              <div className="px-3 pt-3 pb-1">
                <span className="text-[10px] text-mc-muted uppercase tracking-wider font-bold">Team</span>
              </div>
            )}
            {others.map(renderAgent)}
          </>
        )}
      </div>

      {/* Create Agent Form */}
      {!collapsed && showCreateForm && (
        <div className="px-3 py-2 border-t border-mc-border space-y-2 bg-mc-bg">
          <div className="text-[10px] text-mc-accent uppercase tracking-wider font-bold">➕ New Agent</div>
          <input value={newAgent.name} onChange={e => setNewAgent({ ...newAgent, name: e.target.value })}
            placeholder="Name" className="w-full px-2 py-1 bg-mc-surface border border-mc-border rounded text-xs" />
          <input value={newAgent.role} onChange={e => setNewAgent({ ...newAgent, role: e.target.value })}
            placeholder="Role" className="w-full px-2 py-1 bg-mc-surface border border-mc-border rounded text-xs" />
          <select value={newAgent.tier} onChange={e => setNewAgent({ ...newAgent, tier: parseInt(e.target.value) })}
            className="w-full px-2 py-1 bg-mc-surface border border-mc-border rounded text-xs">
            {Object.entries(TIER_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={newAgent.parent} onChange={e => setNewAgent({ ...newAgent, parent: e.target.value })}
            className="w-full px-2 py-1 bg-mc-surface border border-mc-border rounded text-xs">
            <option value="">No parent</option>
            {agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
          <select value={newAgent.department} onChange={e => setNewAgent({ ...newAgent, department: e.target.value })}
            className="w-full px-2 py-1 bg-mc-surface border border-mc-border rounded text-xs">
            {['Executive', 'Business', 'Health', 'Legal', 'Engineering', 'Research', 'Operations'].map(d =>
              <option key={d} value={d}>{d}</option>)}
          </select>
          <select value={newAgent.avatarType} onChange={e => setNewAgent({ ...newAgent, avatarType: e.target.value })}
            className="w-full px-2 py-1 bg-mc-surface border border-mc-border rounded text-xs">
            {Object.entries(CHARACTER_EMOJIS).map(([k, v]) => <option key={k} value={k}>{v} {k}</option>)}
          </select>
          <div className="flex gap-1">
            <button disabled={creating || !newAgent.name} onClick={async () => {
              setCreating(true);
              try {
                const id = newAgent.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
                const res = await fetch('/api/agents', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ ...newAgent, id, parent: newAgent.parent || null }),
                });
                const data = await res.json();
                if (data.ok) {
                  setAgents(prev => [...prev, data.agent]);
                  setNewAgent({ name: '', role: '', tier: 6, parent: '', department: 'Operations', avatarType: 'lobster' });
                  setShowCreateForm(false);
                }
              } catch {}
              setCreating(false);
            }} className="flex-1 px-2 py-1 text-xs bg-mc-accent text-white rounded hover:opacity-90 disabled:opacity-50">
              {creating ? '...' : 'Create'}
            </button>
            <button onClick={() => setShowCreateForm(false)}
              className="px-2 py-1 text-xs text-mc-muted hover:text-mc-text bg-mc-surface rounded">Cancel</button>
          </div>
        </div>
      )}

      <div className="px-3 py-2 border-t border-mc-border">
        {collapsed ? (
          <div className="text-[10px] text-mc-muted text-center">{agents.length}</div>
        ) : (
          <div className="space-y-1.5">
            <div className="text-[10px] text-mc-muted">
              {agents.filter(a => a.status === 'active').length} active · {agents.length} total
            </div>
            <div className="flex gap-1">
              <button onClick={() => setShowCreateForm(f => !f)}
                className="flex-1 px-2 py-1 text-[10px] text-mc-muted hover:text-mc-accent bg-mc-bg border border-mc-border rounded transition-colors">
                ➕ Create
              </button>
              <button onClick={() => onShowOrgChart?.()}
                className="flex-1 px-2 py-1 text-[10px] text-mc-muted hover:text-mc-accent bg-mc-bg border border-mc-border rounded transition-colors">
                📊 Org Chart
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
