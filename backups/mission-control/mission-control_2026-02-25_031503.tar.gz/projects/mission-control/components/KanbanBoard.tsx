'use client';
import { useEffect, useState } from 'react';
import TaskDetailPanel from './TaskDetailPanel';
import ProjectProfile from './ProjectProfile';

interface TeamMember {
  agentId: string;
  role: string;
  model: string;
  rationale: string;
}

interface AnalysisResult {
  viability: 'still_needed' | 'already_implemented' | 'superseded' | 'too_complex';
  existingFeatureMatch?: string;
  complexity: 'simple' | 'moderate' | 'complex' | 'very_complex';
  team: TeamMember[];
  gameplan: string;
  estimatedCost: string;
  analyzedAt: string;
}

interface Task {
  id: string;
  title: string;
  column: string;
  assignee: string;
  priority: string;
  tags: string[];
  created: string;
  description?: string;
  dueDate?: string;
  instructions?: string;
  teamComposition?: TeamMember[];
  analysisResult?: AnalysisResult;
  executionStatus?: 'idle' | 'running' | 'complete' | 'failed';
  pipelineStatus?: 'backlog' | 'active' | 'review' | 'done';
}

interface Phase {
  id: string;
  name: string;
  description: string;
  requirements: string[];
  status: string;
  tasks: any[];
}

interface Project {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  assignee: string;
  tags: string[];
  goals: string[];
  phases: Phase[];
  activity: any[];
  created: string;
  updated: string;
}

const COLUMNS = [
  { id: 'inbox', label: '📥 Inbox', color: 'border-blue-500', projStatus: 'planning' },
  { id: 'assigned', label: '👤 Assigned', color: 'border-purple-500', projStatus: 'planning' },
  { id: 'in-progress', label: '🔨 In Progress', color: 'border-yellow-500', projStatus: 'in-progress' },
  { id: 'review', label: '👁 Review', color: 'border-orange-500', projStatus: 'review' },
];

const PRIORITY_COLORS: Record<string, string> = {
  critical: 'bg-red-600/30 text-red-300 border-red-600/40',
  high: 'bg-red-500/20 text-red-400 border-red-500/30',
  medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  low: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
};

const PIPELINE_DOT: Record<string, string> = {
  backlog: 'bg-gray-400',
  active:  'bg-blue-400',
  review:  'bg-yellow-400',
  done:    'bg-green-400',
};

const STATUS_TO_COLUMN: Record<string, string> = {
  'planning': 'inbox',
  'in-progress': 'in-progress',
  'review': 'review',
  'complete': 'complete',
};

type ViewMode = 'all' | 'tasks' | 'projects';

function useIsMobile() {
  const [m, setM] = useState(false);
  useEffect(() => {
    const check = () => setM(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);
  return m;
}

export default function KanbanBoard() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [newTask, setNewTask] = useState('');
  const [dragId, setDragId] = useState<string | null>(null);
  const [dragType, setDragType] = useState<'task' | 'project' | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('all');
  const [addType, setAddType] = useState<'task' | 'project'>('task');
  const [mobileColumn, setMobileColumn] = useState(0);
  const [summaryData, setSummaryData] = useState<{activeAgents: number; projectsInProgress: number; messagesToday: number} | null>(null);
  const [expandedTasks, setExpandedTasks] = useState<Set<string>>(new Set());
  const [analyzeModal, setAnalyzeModal] = useState<any>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [showCompleted, setShowCompleted] = useState(false);
  const [confirmAction, setConfirmAction] = useState<{ show: boolean; suggestion: any; index: number } | null>(null);
  const [hoveredTask, setHoveredTask] = useState<string | null>(null);
  const [analyzingTaskId, setAnalyzingTaskId] = useState<string | null>(null);
  const [taskDetailTab, setTaskDetailTab] = useState<string | undefined>(undefined);
  const isMobile = useIsMobile();

  const toggleExpand = (id: string) => setExpandedTasks(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });

  const fetchTasks = () => fetch('/api/tasks').then(r => r.json()).then(d => setTasks(d.tasks || [])).catch(() => {});
  const fetchProjects = () => fetch('/api/projects').then(r => r.json()).then(d => setProjects(d.projects || [])).catch(() => {});

  useEffect(() => { fetchTasks(); fetchProjects(); }, []);

  useEffect(() => {
    Promise.all([
      fetch('/api/agents').then(r => r.json()).catch(() => ({ agents: [] })),
      fetch('/api/analytics').then(r => r.json()).catch(() => ({ summary: {} })),
    ]).then(([agentsData, analyticsData]) => {
      const agents = agentsData.agents || [];
      const summary = analyticsData.summary || {};
      setSummaryData({
        activeAgents: agents.filter((a: any) => a.status === 'active').length,
        projectsInProgress: summary.projectsInProgress || 0,
        messagesToday: summary.messagesToday || 0,
      });
    }).catch(() => {});
  }, []);

  const addTask = async () => {
    if (!newTask.trim()) return;
    if (addType === 'project') {
      await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create', title: newTask.trim(), description: '', priority: 'medium', assignee: 'Groot', tags: [] }),
      });
      setNewTask('');
      fetchProjects();
    } else {
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add', title: newTask.trim() }),
      });
      setNewTask('');
      fetchTasks();
    }
  };

  const moveTask = async (id: string, column: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, column } : t));
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'move', id, column }),
    });
  };

  const moveProject = async (id: string, column: string) => {
    const projStatus = COLUMNS.find(c => c.id === column)?.projStatus || 'planning';
    setProjects(prev => prev.map(p => p.id === id ? { ...p, status: projStatus } : p));
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id, updates: { status: projStatus }, updatedBy: 'Kevin' }),
    });
  };

  const updateTask = async (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id, updates }),
    });
  };

  const deleteTask = async (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete', id }),
    });
  };

  const updateProject = async (id: string, updates: Partial<Project>) => {
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', id, updates, updatedBy: 'Kevin' }),
    });
    fetchProjects();
  };

  const analyzeTask = async (task: Task, e: React.MouseEvent) => {
    e.stopPropagation();
    setAnalyzingTaskId(task.id);
    try {
      const r = await fetch('/api/tasks/analyze-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId: task.id, title: task.title, description: task.description, instructions: task.instructions }),
      });
      const d = await r.json();
      if (d.analysisResult || d.viability) {
        const result = d.analysisResult || d;
        await fetch('/api/tasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'update', id: task.id, updates: { analysisResult: result, teamComposition: result.team } }),
        });
        fetchTasks();
        setTaskDetailTab('analysis');
        setSelectedTask({ ...task, analysisResult: result, teamComposition: result.team });
      }
    } catch {}
    setAnalyzingTaskId(null);
  };

  const playTask = (task: Task, e: React.MouseEvent) => {
    e.stopPropagation();
    setTaskDetailTab('play');
    setSelectedTask(task);
  };

  const getProjectColumn = (p: Project) => STATUS_TO_COLUMN[p.status] || 'inbox';

  const isOverdue = (d?: string) => d && new Date(d) < new Date();

  const getColumnItems = (colId: string) => {
    const colTasks = (viewMode !== 'projects') ? tasks.filter(t => t.column === colId) : [];
    const colProjects = (viewMode !== 'tasks') ? projects.filter(p => getProjectColumn(p) === colId) : [];
    return { tasks: colTasks, projects: colProjects, total: colTasks.length + colProjects.length };
  };

  const statusCounts = COLUMNS.reduce((acc, col) => {
    acc[col.id] = tasks.filter(t => t.column === col.id).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="flex flex-col gap-3">
      {/* Inline Stats + Analyze */}
      <div className="flex items-center gap-2 md:gap-4 flex-wrap">
        {/* Stats — hidden on mobile, shown on desktop */}
        <div className="hidden md:flex gap-3 text-xs text-mc-muted">
          <span><span className="font-semibold text-mc-text">{tasks.length}</span> Tasks <span className="opacity-60">({statusCounts['inbox'] || 0} inbox · {statusCounts['in-progress'] || 0} active · {statusCounts['complete'] || 0} done)</span></span>
          <span className="opacity-30">|</span>
          <span><span className="font-semibold text-mc-text">{summaryData?.activeAgents ?? '—'}</span> Agents</span>
          <span className="opacity-30">|</span>
          <span><span className="font-semibold text-mc-text">{summaryData?.projectsInProgress ?? '—'}</span> Projects</span>
        </div>
        {/* Mobile: compact count */}
        <div className="md:hidden text-xs text-mc-muted">
          <span className="font-semibold text-mc-text">{tasks.length}</span> tasks · <span className="font-semibold text-mc-text">{projects.length}</span> projects
        </div>
        <button onClick={() => setShowCompleted(c => !c)}
          className="ml-auto px-2 md:px-3 py-1 text-xs bg-green-500/20 text-green-400 rounded hover:bg-green-500/30">
          ✅ {tasks.filter(t => t.column === 'complete').length + projects.filter(p => ['complete','completed'].includes(p.status)).length}
        </button>
        <button onClick={async () => {
          setAnalyzing(true);
          setAnalyzeModal({ loading: true, suggestions: [], taskCount: 0 });
          try {
            const res = await fetch('/api/projects/analyze', { method: 'POST' });
            const data = await res.json();
            setAnalyzeModal(data.ok ? data : { loading: false, suggestions: [], taskCount: 0, error: data.error || 'Analysis failed' });
          } catch (e: any) {
            setAnalyzeModal({ loading: false, suggestions: [], taskCount: 0, error: e.message });
          } finally { setAnalyzing(false); }
        }} disabled={analyzing}
          className="px-3 py-1 text-xs bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30 disabled:opacity-50">
          {analyzing ? '⏳ Analyzing...' : '🔍 Analyze & Optimize'}
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex gap-2">
        <input value={newTask} onChange={e => setNewTask(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && addTask()}
          placeholder={addType === 'task' ? 'Add a task...' : 'Add a project...'}
          className="flex-1 px-3 py-1.5 bg-mc-surface border border-mc-border rounded text-mc-text placeholder:text-mc-muted text-sm focus:outline-none focus:border-mc-accent" />
        <div className="flex bg-mc-surface border border-mc-border rounded overflow-hidden self-start relative z-10">
          {(['task', 'project'] as const).map(t => (
            <button key={t} onClick={() => setAddType(t)}
              className={`px-2 py-1.5 text-xs transition-colors cursor-pointer ${addType === t ? 'bg-mc-accent/20 text-mc-accent font-medium' : 'text-mc-muted hover:text-mc-text hover:bg-mc-bg'}`}>
              {t === 'task' ? '✅' : '📁'}
            </button>
          ))}
        </div>
        <button onClick={addTask} className="px-3 py-1.5 bg-mc-accent text-white rounded text-sm hover:opacity-90">+</button>
      </div>

      {/* Filter + Legend — desktop only */}
      <div className="hidden md:flex items-center gap-2">
        <div className="flex bg-mc-surface border border-mc-border rounded overflow-hidden relative z-10">
          {(['all', 'tasks', 'projects'] as ViewMode[]).map(m => (
            <button key={m} onClick={() => setViewMode(m)}
              className={`px-3 py-1 text-xs transition-colors ${viewMode === m ? 'bg-mc-accent/20 text-mc-accent font-medium' : 'text-mc-muted hover:text-mc-text'}`}>
              {m === 'all' ? '📋 All' : m === 'tasks' ? '✅ Tasks' : '📁 Projects'}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3 text-[10px] text-mc-muted ml-auto">
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-mc-bg border border-mc-border inline-block" /> Task</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-mc-accent/10 border border-mc-accent/30 inline-block" /> Project</span>
        </div>
      </div>

      {/* Mobile column switcher */}
      {isMobile && (
        <div className="flex gap-1 overflow-x-auto pb-1">
          {COLUMNS.map((col, idx) => {
            const items = getColumnItems(col.id);
            return (
              <button key={col.id} onClick={() => setMobileColumn(idx)}
                className={`px-2.5 py-1 rounded text-xs whitespace-nowrap flex-shrink-0 ${
                  mobileColumn === idx ? 'bg-mc-accent/20 text-mc-accent font-medium' : 'text-mc-muted bg-mc-surface border border-mc-border'
                }`}>
                {col.label} <span className="text-mc-muted">({items.total})</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Columns */}
      <div className={`${isMobile ? 'flex flex-col' : 'grid grid-cols-4'} gap-3 min-h-[300px] md:min-h-[400px]`}>
        {(isMobile ? [COLUMNS[mobileColumn]] : COLUMNS).map(col => {
          const items = getColumnItems(col.id);
          return (
            <div key={col.id}
              className={`flex flex-col bg-mc-surface rounded-lg border-t-2 ${col.color} border-x border-b border-mc-border`}
              onDragOver={e => { e.preventDefault(); e.currentTarget.classList.add('ring-2', 'ring-mc-accent/30'); }}
              onDragLeave={e => e.currentTarget.classList.remove('ring-2', 'ring-mc-accent/30')}
              onDrop={e => {
                e.currentTarget.classList.remove('ring-2', 'ring-mc-accent/30');
                if (dragId && dragType === 'task') moveTask(dragId, col.id);
                if (dragId && dragType === 'project') moveProject(dragId, col.id);
                setDragId(null); setDragType(null);
              }}>
              <div className="px-3 py-2 text-sm font-semibold border-b border-mc-border flex justify-between items-center">
                <span>{col.label}</span>
                <span className="text-mc-muted text-xs">{items.total}</span>
              </div>
              <div className="flex-1 p-2 space-y-2">
                {/* Projects first */}
                {items.projects.map(proj => {
                  const projPhases = Array.isArray(proj.phases) ? proj.phases : [];
                  const completed = projPhases.filter(p => p.status === 'complete').length;
                  const total = projPhases.length;
                  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
                  return (
                    <div key={proj.id} draggable
                      onDragStart={() => { setDragId(proj.id); setDragType('project'); }}
                      onDragEnd={() => { setDragId(null); setDragType(null); }}
                      onClick={() => setSelectedProject(proj)}
                      className={`p-2.5 rounded border border-mc-accent/30 bg-mc-accent/5 cursor-pointer hover:border-mc-accent/60 transition-colors ${dragId === proj.id ? 'opacity-50' : ''}`}>
                      <div className="flex items-start justify-between gap-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs">📁</span>
                          <span className="text-sm font-semibold">{proj.title}</span>
                        </div>
                      </div>
                      <p className="text-xs text-mc-muted mt-1 line-clamp-2">{proj.description}</p>
                      {/* Progress bar */}
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-[10px] text-mc-muted mb-0.5">
                          <span>{completed}/{total} phases</span>
                          <span>{pct}%</span>
                        </div>
                        <div className="h-1.5 bg-mc-bg rounded-full overflow-hidden">
                          <div className="h-full bg-mc-accent rounded-full transition-all" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                      <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border ${PRIORITY_COLORS[proj.priority] || PRIORITY_COLORS.medium}`}>
                          {proj.priority}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-mc-accent/20 text-mc-accent">
                          {proj.assignee}
                        </span>
                        {(Array.isArray(proj.tags) ? proj.tags : []).slice(0, 2).map(t => (
                          <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-mc-surface text-mc-muted">#{t}</span>
                        ))}
                      </div>
                    </div>
                  );
                })}

                {/* Tasks */}
                {items.tasks.map(task => {
                  const hasChildren = (task as any).childProjectIds?.length > 0 || tasks.some(t => (t as any).parentTaskId === task.id);
                  const isExpanded = expandedTasks.has(task.id);
                  const childProjs = isExpanded ? projects.filter(p => (task as any).childProjectIds?.includes(p.id)) : [];
                  const isHovered = hoveredTask === task.id;
                  const isAnalyzingThis = analyzingTaskId === task.id;
                  const hasAnalysis = !!task.analysisResult;
                  const viability = task.analysisResult?.viability;
                  const hasWarning = viability === 'already_implemented' || viability === 'too_complex';
                  const pipeline = task.pipelineStatus || 'backlog';
                  return (
                  <div key={task.id}>
                  <div draggable
                    onDragStart={() => { setDragId(task.id); setDragType('task'); }}
                    onDragEnd={() => { setDragId(null); setDragType(null); }}
                    onMouseEnter={() => setHoveredTask(task.id)}
                    onMouseLeave={() => setHoveredTask(null)}
                    onClick={() => { setTaskDetailTab(undefined); setSelectedTask(task); }}
                    className={`p-2.5 rounded border bg-mc-bg cursor-pointer transition-colors relative
                      ${dragId === task.id ? 'opacity-50' : ''}
                      ${hasWarning ? 'border-orange-500/40 hover:border-orange-400/60' : 'border-mc-border hover:border-mc-accent/50'}
                    `}>
                    {/* Title row */}
                    <div className="flex items-start justify-between gap-1">
                      <div className="flex items-center gap-1 min-w-0">
                        {hasChildren && (
                          <button onClick={(e) => { e.stopPropagation(); toggleExpand(task.id); }}
                            className="text-xs text-mc-muted hover:text-mc-accent flex-shrink-0">{isExpanded ? '▾' : '▸'}</button>
                        )}
                        <div className="text-sm font-medium leading-tight">{task.title}</div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {hasWarning && <span title={viability === 'already_implemented' ? 'Already implemented' : 'Too complex'} className="text-orange-400 text-xs">⚠️</span>}
                        {hasAnalysis && !hasWarning && <span title="Analyzed" className="text-[10px] text-green-400 font-semibold">✓</span>}
                        {task.assignee && (
                          <div className="w-5 h-5 rounded-full bg-mc-accent/30 text-mc-accent flex items-center justify-center text-[10px] font-bold">
                            {task.assignee.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase()}
                          </div>
                        )}
                      </div>
                    </div>

                    {task.description && <p className="text-xs text-mc-muted mt-1 line-clamp-2">{task.description}</p>}

                    {/* Tags / badges row */}
                    <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border ${PRIORITY_COLORS[task.priority] || PRIORITY_COLORS.medium}`}>
                        {task.priority}
                      </span>
                      {/* Pipeline badge */}
                      <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-mc-surface text-mc-muted">
                        <span className={`w-1.5 h-1.5 rounded-full ${PIPELINE_DOT[pipeline] || 'bg-gray-400'}`} />
                        {pipeline}
                      </span>
                      {task.assignee && <span className="text-[10px] px-1.5 py-0.5 rounded bg-mc-accent/20 text-mc-accent">{task.assignee}</span>}
                      {task.dueDate && (
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${isOverdue(task.dueDate) ? 'bg-red-500/20 text-red-400' : 'bg-mc-surface text-mc-muted'}`}>
                          📅 {new Date(task.dueDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </span>
                      )}
                      {task.tags?.slice(0, 2).map(tag => (
                        <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded bg-mc-surface text-mc-muted">#{tag}</span>
                      ))}
                    </div>

                    {/* Hover action buttons */}
                    {isHovered && (
                      <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-mc-border/50" onClick={e => e.stopPropagation()}>
                        <button
                          onClick={(e) => analyzeTask(task, e)}
                          disabled={isAnalyzingThis}
                          className="flex-1 px-2 py-1 text-[10px] bg-mc-surface border border-mc-border rounded hover:border-mc-accent/50 hover:text-mc-accent text-mc-muted transition-colors disabled:opacity-50"
                        >
                          {isAnalyzingThis ? '⏳ Analyzing…' : '🔍 Analyze'}
                        </button>
                        <button
                          onClick={(e) => playTask(task, e)}
                          className="flex-1 px-2 py-1 text-[10px] bg-green-600/10 border border-green-600/30 rounded hover:bg-green-600/20 text-green-400 transition-colors"
                        >
                          ▶ Play
                        </button>
                      </div>
                    )}
                  </div>
                  {isExpanded && childProjs.map(cp => (
                    <div key={cp.id} onClick={(e) => { e.stopPropagation(); setSelectedProject(cp); }}
                      className="ml-4 mt-1 p-2 rounded border border-mc-accent/20 bg-mc-accent/5 cursor-pointer hover:border-mc-accent/40 text-xs">
                      <span className="mr-1">📁</span>{cp.title}
                    </div>
                  ))}
                  </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modals */}
      {selectedTask && (
        <TaskDetailPanel
          task={selectedTask}
          onSave={updateTask}
          onDelete={deleteTask}
          onClose={() => { setSelectedTask(null); setTaskDetailTab(undefined); fetchTasks(); }}
          initialTab={taskDetailTab as any}
        />
      )}
      {selectedProject && (
        <ProjectProfile projectId={selectedProject.id} onClose={() => { setSelectedProject(null); fetchProjects(); }} modal />
      )}

      {/* Analyze & Optimize Modal */}
      {/* Completed Items View */}
      {showCompleted && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setShowCompleted(false)}>
          <div className="bg-mc-surface border border-mc-border rounded-lg w-[700px] max-w-[90vw] max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="px-4 py-3 border-b border-mc-border flex items-center justify-between flex-shrink-0">
              <h2 className="font-bold text-lg">✅ Completed Items</h2>
              <button onClick={() => setShowCompleted(false)} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {/* Completed Projects */}
              {projects.filter(p => ['complete','completed'].includes(p.status)).length > 0 && (
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-green-400 mb-2">📁 Completed Projects ({projects.filter(p => ['complete','completed'].includes(p.status)).length})</h3>
                  {projects.filter(p => ['complete','completed'].includes(p.status)).map(p => (
                    <div key={p.id} className="bg-mc-bg border border-mc-border rounded-lg p-3 mb-2 cursor-pointer hover:border-green-500/50" onClick={() => { setShowCompleted(false); setSelectedProject(p); }}>
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{p.title}</span>
                        <span className="text-[10px] text-mc-muted">{p.updated ? new Date(p.updated).toLocaleDateString() : ''}</span>
                      </div>
                      {p.description && <div className="text-xs text-mc-muted mt-1 line-clamp-1">{p.description}</div>}
                      <div className="flex items-center gap-2 mt-1">
                        {p.assignee && <span className="text-[10px] text-mc-muted">→ {p.assignee}</span>}
                        <span className="text-[10px] text-green-400">{(Array.isArray(p.phases) ? p.phases : []).filter((ph: any) => ph.status === 'complete').length}/{(Array.isArray(p.phases) ? p.phases : []).length} phases</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {/* Completed Tasks */}
              {tasks.filter(t => t.column === 'complete').length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-green-400 mb-2">✅ Completed Tasks ({tasks.filter(t => t.column === 'complete').length})</h3>
                  {tasks.filter(t => t.column === 'complete').map(t => (
                    <div key={t.id} className="bg-mc-bg border border-mc-border rounded-lg p-3 mb-2 cursor-pointer hover:border-green-500/50" onClick={() => { setShowCompleted(false); setSelectedTask(t); }}>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">{t.title}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                          t.priority === 'high' ? 'text-red-400' : t.priority === 'medium' ? 'text-yellow-400' : 'text-blue-400'
                        }`}>{t.priority}</span>
                      </div>
                      {t.assignee && <div className="text-[10px] text-mc-muted mt-1">→ {t.assignee}</div>}
                    </div>
                  ))}
                </div>
              )}
              {tasks.filter(t => t.column === 'complete').length === 0 && projects.filter(p => ['complete','completed'].includes(p.status)).length === 0 && (
                <div className="text-center py-12 text-mc-muted">
                  <div className="text-3xl mb-2">🎯</div>
                  <div className="text-sm">No completed items yet. Keep going!</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {analyzeModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => { if (!analyzeModal.loading) { setAnalyzeModal(null); setConfirmAction(null); fetchTasks(); fetchProjects(); } }}>
          <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-3xl max-h-[85vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold">🔍 Analyze & Optimize</h3>
                <p className="text-xs text-mc-muted">
                  {analyzeModal.loading ? 'AI is reviewing your tasks and projects…' : `${analyzeModal.taskCount ?? 0} tasks analyzed`}
                </p>
              </div>
              {!analyzeModal.loading && (
                <button onClick={() => { setAnalyzeModal(null); setConfirmAction(null); fetchTasks(); fetchProjects(); }} className="text-mc-muted hover:text-mc-text text-xl">✕</button>
              )}
            </div>

            {analyzeModal.loading && (
              <div className="flex flex-col items-center justify-center py-16 gap-4">
                <div className="w-10 h-10 border-4 border-mc-accent/30 border-t-mc-accent rounded-full animate-spin" />
                <p className="text-sm text-mc-muted">Scanning tasks, projects, and implemented features…</p>
                <p className="text-xs text-mc-muted/60">Checking for duplicates, overlaps, and already-implemented work</p>
              </div>
            )}

            {!analyzeModal.loading && analyzeModal.error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 text-sm text-red-400">
                ❌ {analyzeModal.error}
              </div>
            )}

            {!analyzeModal.loading && !analyzeModal.error && analyzeModal.suggestions?.length > 0 ? (
              <div className="space-y-3">
                {analyzeModal.suggestions.map((s: any, i: number) => (
                  <div key={i} className={`bg-mc-bg border rounded-lg p-4 text-sm ${
                    s.action === 'already_implemented' ? 'border-orange-500/50' :
                    s.action === 'create' ? 'border-purple-500/50' :
                    s.action === 'add_to_existing' ? 'border-blue-500/50' :
                    s.action === 'merge_tasks' ? 'border-yellow-500/50' :
                    'border-mc-border'
                  }`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                            s.action === 'already_implemented' ? 'bg-orange-500/20 text-orange-400' :
                            s.action === 'create' ? 'bg-purple-500/20 text-purple-400' :
                            s.action === 'add_to_existing' ? 'bg-blue-500/20 text-blue-400' :
                            s.action === 'merge_tasks' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-gray-500/20 text-gray-400'
                          }`}>
                            {s.action === 'already_implemented' ? '✅ Already Implemented' :
                             s.action === 'create' ? '📁 Create Project' :
                             s.action === 'add_to_existing' ? '➕ Add to Project' :
                             s.action === 'merge_tasks' ? '🔀 Merge Duplicate' :
                             '✅ Keep as Task'}
                          </span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                            s.confidence === 'high' ? 'bg-green-500/20 text-green-400' :
                            s.confidence === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-gray-500/20 text-gray-400'
                          }`}>{s.confidence || 'low'} confidence</span>
                        </div>
                        <div className="font-medium">{s.taskTitle}</div>
                        <div className="text-xs text-mc-muted mt-1">{s.reason}</div>
                        
                        {s.action === 'already_implemented' && s.existingFeatureMatch && (
                          <div className="mt-2 text-xs bg-orange-500/10 border border-orange-500/30 rounded p-2">
                            <span className="text-orange-400">Covered by feature:</span> {s.existingFeatureMatch}
                          </div>
                        )}
                        {s.action === 'create' && s.newProjectTitle && (
                          <div className="mt-2 text-xs bg-purple-500/10 border border-purple-500/30 rounded p-2">
                            <span className="text-purple-400">New Project:</span> {s.newProjectTitle}
                          </div>
                        )}
                        {s.action === 'add_to_existing' && s.existingProjectTitle && (
                          <div className="mt-2 text-xs bg-blue-500/10 border border-blue-500/30 rounded p-2">
                            <span className="text-blue-400">Add to:</span> {s.existingProjectTitle}
                          </div>
                        )}
                        {s.action === 'merge_tasks' && s.mergeWithTaskTitle && (
                          <div className="mt-2 text-xs bg-yellow-500/10 border border-yellow-500/30 rounded p-2 space-y-1">
                            <div><span className="text-yellow-400">Keep:</span> {s.mergeWithTaskTitle}</div>
                            <div><span className="text-yellow-400">Remove:</span> {s.taskTitle}</div>
                            {s.mergedTitle && <div><span className="text-yellow-400">Merged title:</span> {s.mergedTitle}</div>}
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col gap-2">
                        {s.action === 'already_implemented' && (
                          <button
                            onClick={() => setConfirmAction({ show: true, suggestion: s, index: i })}
                            className="px-3 py-1.5 text-xs bg-orange-500/20 text-orange-400 rounded hover:bg-orange-500/30 whitespace-nowrap"
                          >
                            Got it — Dismiss
                          </button>
                        )}
                        {s.action === 'create' && (
                          <>
                            <button
                              onClick={() => setConfirmAction({ show: true, suggestion: s, index: i })}
                              className="px-3 py-1.5 text-xs bg-purple-500/20 text-purple-400 rounded hover:bg-purple-500/30 whitespace-nowrap"
                            >
                              ✅ Create
                            </button>
                            <button
                              onClick={() => setConfirmAction({ show: true, suggestion: { ...s, action: 'keep_as_task' }, index: i })}
                              className="px-3 py-1.5 text-xs bg-gray-500/20 text-gray-400 rounded hover:bg-gray-500/30 whitespace-nowrap"
                            >
                              ❌ Keep Task
                            </button>
                          </>
                        )}
                        {s.action === 'add_to_existing' && (
                          <>
                            <button
                              onClick={() => setConfirmAction({ show: true, suggestion: s, index: i })}
                              className="px-3 py-1.5 text-xs bg-blue-500/20 text-blue-400 rounded hover:bg-blue-500/30 whitespace-nowrap"
                            >
                              ✅ Add
                            </button>
                            <button
                              onClick={() => setConfirmAction({ show: true, suggestion: { ...s, action: 'keep_as_task' }, index: i })}
                              className="px-3 py-1.5 text-xs bg-gray-500/20 text-gray-400 rounded hover:bg-gray-500/30 whitespace-nowrap"
                            >
                              ❌ Keep Task
                            </button>
                          </>
                        )}
                        {s.action === 'merge_tasks' && (
                          <>
                            <button
                              onClick={() => setConfirmAction({ show: true, suggestion: s, index: i })}
                              className="px-3 py-1.5 text-xs bg-yellow-500/20 text-yellow-400 rounded hover:bg-yellow-500/30 whitespace-nowrap"
                            >
                              🔀 Merge
                            </button>
                            <button
                              onClick={() => setConfirmAction({ show: true, suggestion: { ...s, action: 'keep_as_task' }, index: i })}
                              className="px-3 py-1.5 text-xs bg-gray-500/20 text-gray-400 rounded hover:bg-gray-500/30 whitespace-nowrap"
                            >
                              ❌ Keep Both
                            </button>
                          </>
                        )}
                        {s.action === 'keep_as_task' && (
                          <button
                            onClick={() => setConfirmAction({ show: true, suggestion: s, index: i })}
                            className="px-3 py-1.5 text-xs bg-green-500/20 text-green-400 rounded hover:bg-green-500/30 whitespace-nowrap"
                          >
                            ✅ OK
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              !analyzeModal.loading && !analyzeModal.error && (
                <div className="py-8 space-y-4">
                  <div className="text-center">
                    <div className="text-3xl mb-2">✅</div>
                    <div className="font-medium text-mc-text">No consolidation opportunities found</div>
                    <p className="text-xs text-mc-muted mt-1">
                      {analyzeModal.taskCount
                        ? `Reviewed ${analyzeModal.taskCount} task${analyzeModal.taskCount !== 1 ? 's' : ''} — all are unique, viable, and not covered by existing features or projects.`
                        : 'No unassigned tasks found to analyze.'}
                    </p>
                  </div>
                  {analyzeModal.summary && (
                    <div className="grid grid-cols-3 gap-3 text-center text-xs">
                      <div className="bg-mc-bg border border-mc-border rounded p-3">
                        <div className="text-lg font-bold text-mc-text">{analyzeModal.summary.tasksReviewed ?? 0}</div>
                        <div className="text-mc-muted">Tasks reviewed</div>
                      </div>
                      <div className="bg-mc-bg border border-mc-border rounded p-3">
                        <div className="text-lg font-bold text-green-400">{analyzeModal.summary.featuresChecked ?? 0}</div>
                        <div className="text-mc-muted">Features checked</div>
                      </div>
                      <div className="bg-mc-bg border border-mc-border rounded p-3">
                        <div className="text-lg font-bold text-blue-400">{analyzeModal.summary.projectsChecked ?? 0}</div>
                        <div className="text-mc-muted">Projects checked</div>
                      </div>
                    </div>
                  )}
                </div>
              )
            )}

            {!analyzeModal.loading && (
            <div className="mt-4 pt-4 border-t border-mc-border">
              <button onClick={() => { setAnalyzeModal(null); setConfirmAction(null); fetchTasks(); fetchProjects(); }} className="w-full px-4 py-2 bg-mc-accent/20 text-mc-accent rounded hover:bg-mc-accent/30">
                Done
              </button>
            </div>
            )}
          </div>

          {/* Confirm Action Modal (F2) — layered on top of analyzeModal */}
          {confirmAction?.show && (
            <div className="fixed inset-0 z-[60] bg-black/70 flex items-center justify-center p-4" onClick={e => e.stopPropagation()}>
              <div className="bg-mc-surface border border-mc-border rounded-xl w-full max-w-md p-6 shadow-2xl">
                <h3 className="text-base font-bold mb-1">
                  {confirmAction.suggestion.action === 'create' && '📁 Confirm: Create Project'}
                  {confirmAction.suggestion.action === 'add_to_existing' && '➕ Confirm: Add to Project'}
                  {confirmAction.suggestion.action === 'keep_as_task' && '✅ Confirm: Keep as Task'}
                  {confirmAction.suggestion.action === 'already_implemented' && '✅ Confirm: Dismiss Task'}
                  {confirmAction.suggestion.action === 'merge_tasks' && '🔀 Confirm: Merge Duplicate'}
                </h3>
                <div className="text-xs text-mc-muted mb-4">Review before applying this action</div>

                <div className="bg-mc-bg border border-mc-border rounded-lg p-4 space-y-2 text-sm mb-5">
                  <div><span className="text-mc-muted text-xs">Task:</span><br /><span className="font-medium">&ldquo;{confirmAction.suggestion.taskTitle}&rdquo;</span></div>
                  <div><span className="text-mc-muted text-xs">Action:</span><br />
                    {confirmAction.suggestion.action === 'create' && <span>Move task to Done and create new project: <strong>{confirmAction.suggestion.newProjectTitle}</strong></span>}
                    {confirmAction.suggestion.action === 'add_to_existing' && <span>Move task to Done and add it to project: <strong>{confirmAction.suggestion.existingProjectTitle}</strong></span>}
                    {confirmAction.suggestion.action === 'keep_as_task' && <span>Keep this as a standalone task (no project change)</span>}
                    {confirmAction.suggestion.action === 'already_implemented' && <span>Dismiss — this is already covered by an existing feature. Task will be marked done.</span>}
                    {confirmAction.suggestion.action === 'merge_tasks' && <span>Keep <strong>{confirmAction.suggestion.mergeWithTaskTitle}</strong> and mark <strong>{confirmAction.suggestion.taskTitle}</strong> as done (duplicate removed).</span>}
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setConfirmAction(null)}
                    className="flex-1 px-4 py-2 text-sm border border-mc-border text-mc-muted rounded hover:border-mc-accent/50 hover:text-mc-text"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={async () => {
                      const s = confirmAction.suggestion;
                      const idx = confirmAction.index;
                      setConfirmAction(null);
                      const body: any = { taskId: s.taskId, action: s.action };
                      if (s.action === 'create')       body.newProjectTitle = s.newProjectTitle;
                      if (s.action === 'add_to_existing') body.existingProjectId = s.existingProjectId;
                      if (s.action === 'already_implemented') body.action = 'keep_as_task'; // dismiss = keep_as_task server-side
                      await fetch('/api/projects/analyze', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                      });
                      setAnalyzeModal((prev: any) => ({ ...prev, suggestions: prev.suggestions.filter((_: any, i: number) => i !== idx) }));
                      fetchTasks(); fetchProjects();
                    }}
                    className="flex-1 px-4 py-2 text-sm bg-mc-accent text-white rounded hover:opacity-90 font-medium"
                  >
                    Confirm
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
