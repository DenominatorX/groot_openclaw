# Mission Control v3 — Product Requirements Document

**Version:** 3.0  
**Date:** February 10, 2026  
**Author:** Groot  
**Status:** ACTIVE  
**Owner:** Kevin Lane

---

## 1. Vision

A personal command center with three layers:
1. **2D Dashboard** — Kanban board, health panel, agent activity, quick actions
2. **3D Visualization** — Isometric scene where agents walk around, clickable, directable
3. **Health HQ** — Oura Ring + OMI device integration, CK tracking, supplement management

Think: a game-like HQ where you see your agents working, drag tasks on a board, and monitor your body — all in one place.

## 2. What Failed Before

V1/V2 got bloated — 100+ agents, org charts nobody used, enterprise features for a one-person operation. Today we paused everything and cleaned house.

**This time:** Start with a working Kanban + Health panel. Add the 3D scene as the visual layer on top. Grow organically.

## 3. Core Principles

1. **Kevin uses it every day** — or it's wrong
2. **Simple first, fancy second** — Kanban works before 3D renders
3. **Local-first** — runs on BigMac, data stays home
4. **Mobile-ready** — usable from iPhone
5. **Modular** — panels and views can be added/removed

---

## 4. Features

### 4A. Kanban Board (2D)
The primary work surface. Inspired by the SiteGPT Mission Control screenshot.

| Column | Purpose |
|--------|---------|
| **Inbox** | New tasks, ideas, requests |
| **Assigned** | Given to an agent or Kevin |
| **In Progress** | Actively being worked |
| **Review** | Done but needs Kevin's eyes |
| **Complete** | Shipped / verified |

**Capabilities:**
- Drag-and-drop between columns
- Task cards show: title, assignee (agent or Kevin), priority, due date, tags
- Click card → detail panel (description, comments, attachments, agent session link)
- Filter by: agent, priority, tag, date
- Quick-add: type a task and hit enter
- Persist to local JSON (no database)

### 4B. 3D Isometric Visualization
A Three.js scene showing Kevin's "office" — agents as voxel characters moving around, working at stations.

| Feature | Description |
|---------|-------------|
| **Scene** | Isometric view of a virtual HQ / office space |
| **Agents** | Voxel-style characters (like the RoundtableSpace demo) |
| **States** | Idle, working, reporting, waiting — visual cues |
| **Click** | Click an agent → see their profile, current task, recent activity |
| **Direct** | Point/assign tasks to agents from the 3D view |
| **Sub-agents** | See child agents spawned by parent agents |
| **Ambient** | Agents wander, sit at desks, gather in meeting areas |

**Phase 1 scope:** Static scene with positioned agents + click-to-inspect. Animation and directing come in Phase 2.

### 4C. Health Section
Dedicated health monitoring panel integrating Kevin's wearables and genetic context.

| Data Source | Integration | What It Shows |
|-------------|-------------|---------------|
| **Oura Ring** | OAuth API (Client ID: `173a1f34...`) | Sleep score, readiness, HRV, activity, body temp |
| **OMI Device** | API Key (`omi_dev_28cc...`) | Voice transcripts, memory captures, real-time status |
| **CK Tracker** | ~~Deferred~~ — no home reading available yet | — |
| **Supplements** | Checklist (local JSON) | Daily supplement tracking, RhabdoReducer protocol |
| **Exercise Log** | Manual entry | Type, duration, intensity, 48h recovery tracking |
| **Genetic Context** | Static display | AMPD1 + AGK variants, safe exercise ranges |

**Alerts:**
- CK trending up → amber/red warning
- Missed supplements → gentle nudge
- Poor sleep score → suggest light day
- Exercise too soon after last session → recovery warning

### 4D. Agent Activity Feed
Live feed of what agents are doing.

| Feature | Description |
|---------|-------------|
| Real-time log | Agent name, action, timestamp, cost |
| Session links | Click to view full agent conversation |
| Cost tracking | Per-agent and total API spend |
| Sub-agent tree | See which agents spawned sub-agents |
| Filters | By agent, time range, cost threshold |

### 4E. Quick Actions Bar
One-tap controls for common operations.

| Action | What It Does |
|--------|-------------|
| 🏠 Lights | Room-by-room Govee control (32 devices) |
| 🤖 Message Agent | Quick-send to any active agent session |
| ➕ New Task | Add to Kanban inbox |
| 📊 System Status | Gateway health, CPU, memory, disk |
| 🌤 Weather | Current conditions + forecast |

### 4F. Status Bar
Always visible. Shows: time, date, system health, gateway status, Oura readiness score, active agent count.

---

## 5. Tech Stack

| Layer | Choice | Rationale |
|-------|--------|-----------|
| Framework | Next.js 14 (App Router) | Proven, fast, SSR |
| UI | Tailwind CSS + shadcn/ui | Clean, dark mode native |
| 3D | Three.js + React Three Fiber | Industry standard, React integration |
| Kanban | @dnd-kit or react-beautiful-dnd | Drag-and-drop |
| Charts | Recharts or Chart.js | Health trends, cost graphs |
| State | Local JSON files + API routes | No database — files are the DB |
| Wearables | Oura Cloud API + OMI API | Direct REST calls |
| Smart Home | Govee v1 API | Via tools/govee.sh or direct |
| Build | Claude Code CLI v2.1.38 | Autonomous coding agent |

## 6. Design

- **Dark mode default** — Kevin's preference
- **Multiple color schemes** — switchable themes (dark, light, neon, earth tones)
- **Dense but readable** — no wasted space
- **Two main views:**
  1. **Dashboard view** — Kanban + Health + Activity (2D, productive)
  2. **HQ view** — 3D isometric scene (visual, fun, impressive)
- **Responsive** — 1440p monitor primary, iPhone secondary
- **Agent sidebar** — collapsible list of active agents with status indicators

## 7. Phases

### Phase 1: Working Dashboard (THIS WEEK)
**Goal:** Kanban board + Health panel + Agent activity — functional, daily-usable.

| Deliverable | Description | Estimate |
|-------------|-------------|----------|
| Project scaffold | Next.js 14 + Tailwind + shadcn/ui | 30 min |
| Kanban board | 5 columns, drag-drop, local JSON persistence | 2 hrs |
| Health panel | Oura data display, CK tracker, supplement checklist | 2 hrs |
| Agent activity | Pull from OpenClaw sessions API, cost display | 1 hr |
| Status bar | System health, time, gateway status | 30 min |
| Quick actions | Govee room controls, new task button | 1 hr |
| Dark mode + theming | Default dark, theme switcher | 30 min |

**Total estimate:** ~8 hours of Claude Code work  
**Deliverable:** `localhost:4000` — fully functional 2D dashboard

### Phase 2: 3D Scene + Polish (WEEK 2)
| Deliverable | Description |
|-------------|-------------|
| Three.js isometric scene | Office/HQ environment |
| Voxel agents | Positioned at stations, status indicators |
| Click interaction | Click agent → profile/task overlay |
| Agent profiles | Settings, persona, history, current assignment |
| OMI integration | Live transcription feed, memory display |
| Sub-agent visualization | Parent → child relationships visible |

### Phase 3: Intelligence + Automation (WEEK 3+)
| Deliverable | Description |
|-------------|-------------|
| Health trends | Charts: sleep, CK, HRV over time |
| Cost analytics | Spend by agent, daily/weekly burn rate |
| Task automation | Auto-assign based on agent capabilities |
| Agent directing | Drag tasks to agents in 3D view |
| PWA | Install on iPhone home screen |
| Notifications | Browser + Telegram alerts |

---

## 8. Data Architecture

```
projects/mission-control/data/
├── tasks.json          ← Kanban board state
├── health/
│   ├── ck-log.json     ← CK level entries
│   ├── supplements.json ← Daily checklist
│   ├── exercise.json   ← Exercise log
│   └── oura-cache.json ← Cached Oura data
├── agents/
│   ├── registry.json   ← Agent profiles & personas
│   └── activity.json   ← Cached session activity
└── settings.json       ← Theme, preferences, API keys
```

## 9. API Integrations

| Service | Auth | Endpoint |
|---------|------|----------|
| OpenClaw Gateway | Token: `4f09d1a6...` | `localhost:18789` |
| Govee | API Key: `f0fea3e7...` | `developer-api.govee.com/v1` |
| Oura Ring | OAuth (Client: `173a1f34...`, Secret in Keychain) | `api.ouraring.com/v2` |
| OMI Device | API Key: `omi_dev_28cc...` | TBD (check OMI docs) |

## 10. Success Criteria

| Metric | Target |
|--------|--------|
| Daily usage | Kevin opens it every day |
| Load time | < 2 seconds |
| Kanban tasks | 20+ tasks managed in first week |
| Health logging | CK + supplements tracked daily |
| 3D scene | Renders at 60fps on M4 Mac Mini |

## 11. Non-Goals (For Now)

- ❌ Multi-user / authentication
- ❌ Cloud deployment
- ❌ SQL/NoSQL database
- ❌ 100+ agent org charts (keep it lean — 10-20 agents max)
- ❌ Template marketplace
- ❌ DenominatorX integration (deferred)

---

## 12. Reference Material

- **3D Inspiration:** RoundtableSpace/0xMarioNawfal (Three.js voxel agents, Dominik Scholz)
- **Kanban Inspiration:** SiteGPT Mission Control (pbteja1998), manish-raana/openclaw-mission-control
- **Health Inspiration:** Oura app, Apple Health dashboard
- **Prior work:** `BigMac/Dashboard/` (v1/v2 — archived, reusable components)

---

*Ship the 2D dashboard first. Make it useful. Then make it beautiful with 3D.*
